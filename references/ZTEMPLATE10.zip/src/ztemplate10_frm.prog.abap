
FORM SHOW_ALV .
  DATA:LT_DOCNO TYPE  ZTRS_PAYMORDER_TAB.
  DATA::S_BCATE TYPE TABLE OF ZTRS_RANGE_BCATE.
  DATA: LV_TAB TYPE CHAR5.

  MOVE-CORRESPONDING MYTAB TO S_SCREEN.
  EXPORT S_SCREEN TO MEMORY ID 'S_SCREEN'.



  PERFORM CREATE_STRU.

  IF SY-BATCH = 'X' .
    PERFORM SET_ALL_SELECTED USING 'X'.
    PERFORM PF_PRO."调用接口

    RETURN.
  ENDIF.


  PERFORM DISPLAY_ALV.


  CALL SCREEN 9001.

ENDFORM.                    "show_alv
*&---------------------------------------------------------------------*
*& Form CREATE_STRU
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
FORM CREATE_STRU.


  DATA LT_STRUCTURE TYPE LVC_T_FCAT.

  CLEAR: GT_STRUCTURE,
         GT_STRUCTURE[],
         WA_STRUCTURE.

  BULID_FIELDLOG
  'ZSEL' '选择' '' '' 'X' '' '' '' 'X'.
  BULID_FIELDLOG
  'STATU' '状态' 'ICON' 'NAME' '' '' '' '' 'X'.
  BULID_FIELDLOG
  'MESSAGE' '消息' '' '' '' '' '' '' 'X'.
  BULID_FIELDLOG:
        'MATNR' '物料号' 'MAKT' 'MATNR' '' '' '' '' 'X'.
  BULID_FIELDLOG
  'MAKTX' '物料描述' 'MAKT' 'MAKTX' '' '' '' '' 'X'.

*  LOOP AT GT_STRUCTURE ASSIGNING FIELD-SYMBOL(<STRUCTURE>).
*    CASE <STRUCTURE>-FIELDNAME.
*      WHEN 'DB_KEY'.
*
*      WHEN OTHERS.
*        <STRUCTURE>-KEY = ''.
*    ENDCASE.
*  ENDLOOP.

*  SORT GT_STRUCTURE BY COL_POS.

  " 设置行格式
  CLEAR WA_LAYOUT.
  WA_LAYOUT-CWIDTH_OPT = 'X'.
  WA_LAYOUT-NO_MERGING = 'X'.
  WA_LAYOUT-STYLEFNAME = 'CELLSTYLES'.
  WA_LAYOUT-ZEBRA      = 'X'.
  WA_LAYOUT-SEL_MODE   = 'A'.
  WA_LAYOUT-BOX_FNAME  = 'ZSEL'.

  CLEAR S_DISVARIANT.
  S_DISVARIANT-REPORT   = SY-REPID.
  S_DISVARIANT-USERNAME = SY-UNAME.
*  s_disvariant-log_group = 'LG'.
ENDFORM.
*&---------------------------------------------------------------------*
*& Form DISPLAY_ALV
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
FORM DISPLAY_ALV .
  DATA: LT_TOOLS     TYPE TABLE OF SY-UCOMM.   "用于排除按钮

  IF G_DOCKING IS INITIAL.
    CREATE OBJECT G_DOCKING
      EXPORTING
        REPID                       = SY-REPID
        DYNNR                       = '9001'
        SIDE                        = CL_GUI_DOCKING_CONTAINER=>DOCK_AT_TOP
*       SIDE                        = 10
        EXTENSION                   = 99999
      EXCEPTIONS
        CNTL_ERROR                  = 1
        CNTL_SYSTEM_ERROR           = 2
        CREATE_ERROR                = 3
        LIFETIME_ERROR              = 4
        LIFETIME_DYNPRO_DYNPRO_LINK = 5
        OTHERS                      = 6.
    IF SY-SUBRC <> 0.
      MESSAGE S001(00) WITH '屏幕初始化失败'.
      LEAVE LIST-PROCESSING.
    ENDIF.

    CREATE OBJECT GR_GRID
      EXPORTING
        I_PARENT = G_DOCKING.
*
    SET HANDLER LCL_EVENT_RECEIVER=>TOOLBAR FOR GR_GRID.
    SET HANDLER LCL_EVENT_RECEIVER=>AFTER_USER_COMMAND FOR GR_GRID.
    SET HANDLER LCL_EVENT_RECEIVER=>HANDLE_DOUBLE_CLICK FOR GR_GRID.
    IF SY-BATCH <> 'X'.
      CALL METHOD GR_GRID->REGISTER_EDIT_EVENT
        EXPORTING
          I_EVENT_ID = CL_GUI_ALV_GRID=>MC_EVT_MODIFIED.


      CLEAR LT_TOOLS[].
      APPEND '&LOCAL&DELETE_ROW' TO LT_TOOLS.
      APPEND '&LOCAL&COPY_ROW' TO LT_TOOLS.
      APPEND '&LOCAL&COPY' TO LT_TOOLS.
      APPEND '&LOCAL&APPEND' TO LT_TOOLS.
      APPEND '&LOCAL&INSERT_ROW' TO LT_TOOLS.
      APPEND '&LOCAL&CUT' TO LT_TOOLS.
      APPEND '&LOCAL&PASTE_NEW_ROW' TO LT_TOOLS.
      APPEND '&LOCAL&PASTE' TO LT_TOOLS.
      APPEND '&LOCAL&UNDO' TO LT_TOOLS.
      APPEND '&PRINT' TO LT_TOOLS.
      APPEND '&GRAPH ' TO LT_TOOLS.
      APPEND '&INFO' TO LT_TOOLS.

      CALL METHOD GR_GRID->SET_TABLE_FOR_FIRST_DISPLAY
        EXPORTING
          IS_LAYOUT            = WA_LAYOUT
          I_SAVE               = 'A'
          IS_VARIANT           = S_DISVARIANT
          IT_TOOLBAR_EXCLUDING = LT_TOOLS
        CHANGING
          IT_FIELDCATALOG      = GT_STRUCTURE
          IT_OUTTAB            = GT_ALV[].
    ENDIF.
  ENDIF.

ENDFORM.                    "display_alv
*&---------------------------------------------------------------------*
*& Form FRM_EVENT_TOOLBAR
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
FORM FRM_EVENT_TOOLBAR  USING    E_OBJECT  TYPE REF TO CL_ALV_EVENT_TOOLBAR_SET
      E_INTERACTIVE TYPE C.

  PERFORM SET_TOOLBAR USING '&ALL' ICON_SELECT_ALL ' ' '全选' '' '' 6 E_OBJECT.
  PERFORM SET_TOOLBAR USING '&SAL' ICON_DESELECT_ALL ' ' '取消全选' '' '' 7 E_OBJECT.
  PERFORM SET_TOOLBAR USING '&SALL' ICON_SELECT_BLOCK ' ' '块选择' '' '' 8 E_OBJECT.
  PERFORM SET_TOOLBAR USING '' '' ' ' '' '' 3 22 E_OBJECT.
  PERFORM SET_TOOLBAR USING '&PRO' ICON_EXECUTE_OBJECT ' ' '数据处理' '数据处理' '' 23 E_OBJECT.



ENDFORM.                    "frm_event_toolbar
*&---------------------------------------------------------------------*
*& Form SET_TOOLBAR
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
FORM SET_TOOLBAR  USING    P_FUNCTION P_ICON
      P_DISABLED P_QUICKINFO
      P_TEXT P_TYPE P_POS
      E_OBJECT TYPE REF TO CL_ALV_EVENT_TOOLBAR_SET.

  DATA: LS_TOOLBAR  TYPE STB_BUTTON.

  CLEAR LS_TOOLBAR.
  MOVE P_FUNCTION TO LS_TOOLBAR-FUNCTION.
  MOVE P_ICON  TO LS_TOOLBAR-ICON.
*  move '更改'(111)  to ls_toolbar-quickinfo.
*  move '更改'  to ls_toolbar-text.
  MOVE P_DISABLED   TO LS_TOOLBAR-DISABLED.
  MOVE P_QUICKINFO TO LS_TOOLBAR-QUICKINFO.
  MOVE P_TYPE TO LS_TOOLBAR-BUTN_TYPE.
  MOVE P_TEXT  TO LS_TOOLBAR-TEXT.
  INSERT LS_TOOLBAR INTO E_OBJECT->MT_TOOLBAR INDEX P_POS.

  FREE: LS_TOOLBAR.

ENDFORM.                    "set_toolbar
*&---------------------------------------------------------------------*
*& Form SET_ALL_SELECTED
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
FORM SET_ALL_SELECTED  USING    P_VALUE.

  DATA: L_STATU TYPE FLAG.

  FIELD-SYMBOLS: <F_ALV> TYPE TY_ALV.

  LOOP AT GT_ALV ASSIGNING <F_ALV>.

    PERFORM GET_ZSEL_STATU USING  <F_ALV> CHANGING L_STATU.
    IF L_STATU EQ ''.
      CONTINUE.
    ENDIF.

    IF <F_ALV>-ZSEL EQ P_VALUE.
      CONTINUE.
    ENDIF.

    <F_ALV>-ZSEL = P_VALUE.

  ENDLOOP.

  UNASSIGN: <F_ALV>.

  PERFORM REFRESH_ALV.

  FREE: L_STATU.

ENDFORM.                    "set_all_selected
*&---------------------------------------------------------------------*
*& Form GET_MARK_STATU
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
FORM SET_SALL_SELECTED .
  DATA ET_ROW_NO     TYPE LVC_T_ROID.

  DATA: L_STATU TYPE FLAG.

  FIELD-SYMBOLS: <F_ALV> TYPE TY_ALV.

  GR_GRID->GET_SELECTED_ROWS(
  IMPORTING
    ET_ROW_NO     = ET_ROW_NO
    ).

  LOOP AT ET_ROW_NO INTO DATA(LS_ROW) WHERE ROW_ID > 0.
    CLEAR:L_STATU.
    READ TABLE GT_ALV  ASSIGNING <ALV>  INDEX   LS_ROW-ROW_ID.
    IF SY-SUBRC = 0 .
      PERFORM GET_ZSEL_STATU USING  <ALV> CHANGING L_STATU.
      IF L_STATU EQ ''.
        CONTINUE.
      ENDIF.
      <ALV>-ZSEL = 'X'.
    ENDIF.
  ENDLOOP.



  UNASSIGN: <F_ALV>.

  PERFORM REFRESH_ALV.

  FREE: L_STATU.

ENDFORM.                    "set_all_selected
FORM GET_ZSEL_STATU  USING  P_ALV TYPE TY_ALV
                      CHANGING E_STATU TYPE FLAG.


  DATA: LS_CELL       TYPE LVC_S_STYL,
        IT_CELLSTYLES TYPE LVC_T_STYL.

  IT_CELLSTYLES = P_ALV-CELLSTYLES.

  E_STATU = 'X'.

  CLEAR LS_CELL.
  READ TABLE IT_CELLSTYLES INTO LS_CELL WITH KEY FIELDNAME = 'ZSEL'.
  CHECK SY-SUBRC EQ 0.

  IF LS_CELL-STYLE EQ '00100000'.
    E_STATU = ''.
  ENDIF.

ENDFORM.                    "get_mark_statu
*&---------------------------------------------------------------------*
*& Form REFRESH_ALV
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
FORM REFRESH_ALV .

  DATA: STBL TYPE LVC_S_STBL.

  CHECK SY-BATCH <> 'X'.
  CHECK GR_GRID IS NOT INITIAL.

  STBL-ROW = 'X'." 基于行的稳定刷新
  STBL-COL = 'X'." 基于列的稳定刷新

  CALL METHOD GR_GRID->SET_FRONTEND_LAYOUT
    EXPORTING
      IS_LAYOUT = WA_LAYOUT.

  CALL METHOD GR_GRID->REFRESH_TABLE_DISPLAY
    EXPORTING
      IS_STABLE = STBL.

  FREE: STBL.

ENDFORM.                    " REFRESH_ALV
*&---------------------------------------------------------------------*
*& Form CONFIRM_DATA
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
FORM CONFIRM_DATA .



  PERFORM REFRESH_ALV.

ENDFORM.                    "confirm_data
*&---------------------------------------------------------------------*
*& Form SET_STYLE
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
FORM SET_STYLE  USING   FIELDNAME
      STYLE TYPE STRING
CHANGING   IT_STYLES TYPE LVC_T_STYL.

  DATA: LS_STYLE TYPE LVC_S_STYL.
  CLEAR LS_STYLE.

  LS_STYLE-FIELDNAME = FIELDNAME.
  IF STYLE EQ 'ENABLE'.
    LS_STYLE-STYLE = CL_GUI_ALV_GRID=>MC_STYLE_ENABLED.
  ELSE.
    LS_STYLE-STYLE = CL_GUI_ALV_GRID=>MC_STYLE_DISABLED.
  ENDIF.
  READ TABLE IT_STYLES TRANSPORTING NO FIELDS WITH KEY FIELDNAME = FIELDNAME.
  IF SY-SUBRC EQ 0.
    MODIFY IT_STYLES FROM LS_STYLE INDEX SY-TABIX.
  ELSE.
    INSERT LS_STYLE INTO TABLE IT_STYLES.
  ENDIF.

  FREE: LS_STYLE.

ENDFORM.                    "set_style
*&---------------------------------------------------------------------*
*& Form SET_ERROR_MESSAGE
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*

FORM PF_SET_ERROR_MESSAGE  USING P_MESSAGE
                              P_CHANGE_ENA" '',DIS,EN
                      CHANGING WA_ALV TYPE TY_ALV.

  WA_ALV-STATU = ICON_RED_LIGHT.
  WA_ALV-MESSAGE = P_MESSAGE.

  "  PERFORM PF_CREATE_LOG_1 USING WA_ALV-OBJKEY WA_ALV-MESSAGE 'E'.
  IF P_CHANGE_ENA = 'DIS'.
    PERFORM SET_STYLE USING 'ZSEL' 'DISABLE' CHANGING WA_ALV-CELLSTYLES.
  ENDIF.

ENDFORM.                    "set_error_message
*&---------------------------------------------------------------------*
*& Form CALL_BDC
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*

*&---------------------------------------------------------------------*
*& Form DILL_DOUBLE_CLICK
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
FORM DILL_DOUBLE_CLICK  USING    P_ROW TYPE LVC_S_ROW
                               P_COLUMN TYPE LVC_S_COL.
  DATA: LT_LOG TYPE TABLE OF MASSMSG,
        LS_LOG TYPE MASSMSG.

  DATA: LS_ALV TYPE TY_ALV.
  FIELD-SYMBOLS: <FS>    TYPE ANY,
                 <ERRID> TYPE ANY.
  DATA: L_OBJKEY TYPE TY_ALV-OBJKEY.

  CLEAR LS_ALV.
  READ TABLE GT_ALV ASSIGNING <ALV>  INDEX P_ROW-INDEX.
*  CHECK SY-SUBRC EQ 0.
  LS_ALV = <ALV>.
  ASSIGN COMPONENT P_COLUMN-FIELDNAME OF STRUCTURE LS_ALV TO <FS>.

  IF <FS> IS INITIAL.
    RETURN.
  ENDIF.



  CASE P_COLUMN-FIELDNAME.
    WHEN 'SQDOCNO'."申请单号
      PERFORM PFM_OPTEN_DH USING P_COLUMN-FIELDNAME <FS>.
    WHEN 'QRDOCNO'."确认单号
      PERFORM PFM_OPTEN_DH USING P_COLUMN-FIELDNAME <FS>.
    WHEN 'RFHA'."交易 ，投资合同
      PERFORM PFM_OPTEN_DH USING P_COLUMN-FIELDNAME <FS>.
    WHEN 'SHDOCNO'."赎回单号
      PERFORM PFM_OPTEN_DH USING P_COLUMN-FIELDNAME <FS>.
    WHEN 'DOCNO'."收款单
      PERFORM PFM_OPTEN_DH USING P_COLUMN-FIELDNAME <FS>.


    WHEN 'MATNR'.
      SET PARAMETER ID 'MAT' FIELD <FS>.
      CALL TRANSACTION 'MM03' AND SKIP FIRST SCREEN.
    WHEN 'EBELN' OR 'ZFYDD'.
      CALL FUNCTION 'ME_DISPLAY_PURCHASE_DOCUMENT'
        EXPORTING
          I_EBELN              = <FS>
        EXCEPTIONS
          NOT_FOUND            = 1
          NO_AUTHORITY         = 2
          INVALID_CALL         = 3
          PREVIEW_NOT_POSSIBLE = 4
          OTHERS               = 5.
    WHEN 'vgbel'.
      SET PARAMETER ID 'AUN' FIELD <FS> .
      CALL TRANSACTION 'VA03' AND SKIP FIRST SCREEN .
    WHEN 'vbeln_'.
      SET PARAMETER ID 'VL' FIELD <FS> .
      CALL TRANSACTION 'VL03N' AND SKIP FIRST SCREEN .
    WHEN 'LIFNR' OR 'ZDPBH'.
      CALL FUNCTION 'MMPUR_VENDOR_DISPLAY'
        EXPORTING
          IM_LIFNR = <FS>
*         IM_EKORG = 'B000'
        .
    WHEN 'INFNR'.
      CALL FUNCTION 'MMPUR_INFO_RECORD_DISPLAY'
        EXPORTING
          IM_INFNR = <FS>
          IM_EKORG = ''
          IM_WERKS = ''.
    WHEN 'WERKS'.
      DATA: LS_VT001W TYPE V_T001W.
      LS_VT001W-MANDT = SY-MANDT.
      LS_VT001W-WERKS = <FS>.
      CALL FUNCTION 'VIEW_MAINTENANCE_SINGLE_ENTRY'
        EXPORTING
          ACTION    = 'SHOW'
          VIEW_NAME = 'V_T001W'
        CHANGING
          ENTRY     = LS_VT001W.
    WHEN 'BELNR'.
*      SET PARAMETER ID 'BLN' FIELD <FS> .
*      SET PARAMETER ID 'BUK' FIELD LS_ALV-BUKRS.
*      SET PARAMETER ID 'GJR' FIELD LS_ALV-GJAHR.
*      CALL TRANSACTION 'FB03' AND SKIP FIRST SCREEN .
    WHEN 'XBLNR2'.
*      SET PARAMETER ID 'BLN' FIELD <FS> .
*      SET PARAMETER ID 'BUK' FIELD LS_ALV-BUKRS.
*      SET PARAMETER ID 'GJR' FIELD LS_ALV-GJAHR.
*      CALL TRANSACTION 'FB03' AND SKIP FIRST SCREEN .
    WHEN 'AUGBL'.
*      SET PARAMETER ID 'BLN' FIELD <FS> .
*      SET PARAMETER ID 'BUK' FIELD LS_ALV-BUKRS.
*      SET PARAMETER ID 'GJR' FIELD SY-DATUM(4).
*      CALL TRANSACTION 'FB03' AND SKIP FIRST SCREEN .
    WHEN 'STATU' OR 'MESSAGE'.
      ASSIGN COMPONENT 'OBJKEY' OF STRUCTURE LS_ALV TO <ERRID>.
      CHECK SY-SUBRC = 0.
      CHECK <ERRID> IS NOT INITIAL.
      LT_LOG[] = GT_LOG[].
      DELETE LT_LOG WHERE OBJKEY <> <ERRID>.
      CHECK LT_LOG IS NOT INITIAL.
      CALL FUNCTION 'ZWINDOW_OF_LOG'
        TABLES
          IT_LOG = LT_LOG.

    WHEN OTHERS.
      "显示明细
      PERFORM PF_SHOW_ITEM USING LS_ALV.
  ENDCASE.
ENDFORM.                    "dill_double_click
*&---------------------------------------------------------------------*
*&      Form  PF_SHOW_ITEM
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_LS_ALV  text
*----------------------------------------------------------------------*
FORM PF_SHOW_ITEM  USING    P_ALV TYPE TY_ALV.
  DATA: LT_ALV_I TYPE TABLE OF TY_ALV_I,
        LS_ALV_I TYPE TY_ALV_I.
  DATA: ALV     TYPE REF TO CL_SALV_TABLE,
        ALV_EXC TYPE REF TO CX_SALV_MSG.
  LT_ALV_I = GT_ALV_I.
*  DELETE LT_ALV_I WHERE IDKEY = P_ALV-IDKEY.

  CHECK LT_ALV_I IS NOT INITIAL.

  TRY.
      CL_SALV_TABLE=>FACTORY(
        IMPORTING R_SALV_TABLE = ALV
        CHANGING T_TABLE = LT_ALV_I ).
      ALV->DISPLAY( ).
    CATCH CX_SALV_MSG INTO ALV_EXC.
      MESSAGE ALV_EXC TYPE 'I' DISPLAY LIKE 'E'.
  ENDTRY.

ENDFORM.                    " PF_SHOW_ITEM
*&---------------------------------------------------------------------*
*&      Form  PF_SHOW_ZHTBH
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_ALV      text
*----------------------------------------------------------------------*

*      -->P_MSGV4    text
*----------------------------------------------------------------------*
FORM PF_CREATE_LOG TABLES PT_RETURN1  STRUCTURE BAPIRET2
                          PT_RETURN2  STRUCTURE BAPIRETURN1
                    USING P_OBJKEY  TYPE  CHAR79
                          P_MSGTY TYPE  MSGTY
                          P_MSGID TYPE  ARBGB
                          P_MSGNO TYPE  SYMSGNO
                          P_MSGV1 TYPE  SYMSGV
                          P_MSGV2 TYPE  SYMSGV
                          P_MSGV3 TYPE  SYMSGV
                          P_MSGV4 TYPE  SYMSGV.

  IF P_MSGID IS INITIAL.
    P_MSGID = 'ZDX_001'.
  ENDIF.

  IF P_MSGNO IS INITIAL.
    P_MSGNO = '100'.
  ENDIF.


  CALL FUNCTION 'ZFM_CREATE_LOG'
    EXPORTING
      I_OBJKEY   = P_OBJKEY
      I_MSGTY    = P_MSGTY
      I_MSGID    = P_MSGID
      I_MSGNO    = P_MSGNO
      I_MSGV1    = P_MSGV1
      I_MSGV2    = P_MSGV2
      I_MSGV3    = P_MSGV3
      I_MSGV4    = P_MSGV4
    TABLES
      LT_LOG     = GT_LOG
      LT_RETURN1 = PT_RETURN1
      LT_RETURN2 = PT_RETURN2.
ENDFORM.                    "PF_CREATE_LOG


*&---------------------------------------------------------------------*
*&      Form  PF_CREATE_LOG_1
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_OBJKEY   text
*      -->P_MSGTX    text
*      -->P_MSGTY    text
*----------------------------------------------------------------------*
FORM PF_CREATE_LOG_1 USING P_OBJKEY  TYPE  CHAR79
                         P_MSGTX TYPE MSGTX
                         P_MSGTY TYPE  MSGTY .
  DATA: L_MSGTX TYPE SYMSGV.

  L_MSGTX = P_MSGTX.
  CALL FUNCTION 'ZFM_CREATE_LOG'
    EXPORTING
      I_OBJKEY = P_OBJKEY
      I_MSGTY  = P_MSGTY
      I_MSGV1  = L_MSGTX
    TABLES
      LT_LOG   = GT_LOG.
ENDFORM.                    "PF_CREATE_LOG_1


*&---------------------------------------------------------------------*
*&      Form  ADD_FUNCKEY
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM ADD_FUNCKEY .

  DATA: LV_FUNCTION_KEY TYPE SMP_DYNTXT.         "功能按钮

  CLEAR LV_FUNCTION_KEY.

  LV_FUNCTION_KEY-ICON_ID   = ICON_READ_FILE.

  LV_FUNCTION_KEY-ICON_TEXT = '模版下载'.

  LV_FUNCTION_KEY-QUICKINFO = '代收款费用入账_货款清账批导模板下载'.

  SSCRFIELDS-FUNCTXT_01 = LV_FUNCTION_KEY.

ENDFORM.                    "ADD_FUNCKEY

*&---------------------------------------------------------------------*

*& Form FRM_EXCEL_DOWN

*&---------------------------------------------------------------------*

*& text

*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  PF_GET_DEFAULT_STRUCTURE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      <--P_IT_FIELDCATALOG  text
*----------------------------------------------------------------------*
FORM PF_GET_DEFAULT_STRUCTURE  CHANGING PT_FIELDCATALOG TYPE LVC_T_FCAT.

  DATA:
    LS_VARIANT   TYPE DISVARIANT,       " 变式信息
    LT_FCAT      TYPE LVC_T_FCAT,       " 字段目录
    LT_FCAT_VIS  TYPE LVC_T_FCAT,       " 可见字段目录
    LT_EXCLUDING TYPE TABLE OF LVC_S_EXCL. " 隐藏字段列表

  IF SY-BATCH = 'X'.
    PT_FIELDCATALOG = GT_STRUCTURE.
  ELSE.
*
    " 1. 获取ALV当前的字段目录（包含显示状态）
    GR_GRID->GET_FRONTEND_FIELDCATALOG( IMPORTING ET_FIELDCATALOG = PT_FIELDCATALOG ).

  ENDIF.
  " 2. 过滤出可见字段（排除隐藏字段和技术字段）
  DELETE PT_FIELDCATALOG WHERE   NO_OUT = 'X'    " 隐藏字段
                                OR TECH = 'X'.  " 技术字段


ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  PFM_OPTEN_DH
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_P_COLUMN_FIELDNAME  text
*      -->P_<FS>  text
*----------------------------------------------------------------------*
FORM PFM_OPTEN_DH  USING    P_FIELDNAME
                            P_FS .
  DATA: L_APPLICATION TYPE  WDY_APPLICATION_NAME,
        L_STARTGUI    TYPE FLAG VALUE 'X',
        L_OUT_URL     TYPE  STRING,
        L_PARAM       TYPE CHAR100.

  CASE P_FIELDNAME.
    WHEN 'SQDOCNO'."申请单号
      L_APPLICATION = 'ZWDC_TR_9300'.
      L_PARAM = 'ACTION=03&SQDOCNO=' && P_FS.
    WHEN 'QRDOCNO'."确认单号
      L_APPLICATION = 'ZWDC_TR_9323'.
      L_PARAM = 'ACTION=03&QRDOCNO=' && P_FS.

    WHEN 'SHDOCNO'."赎回单号
      L_APPLICATION = 'ZWDC_TR_9403_1'.
      L_PARAM = 'ACTION=D&SHDOCNO=' && P_FS.

    WHEN 'DOCNO'."收款单
       L_APPLICATION = 'ZWDA_TR_0100'.
      L_PARAM = 'MODE=03&DOCNO=' && P_FS.
   WHEN OTHERS.
      RETURN.
  ENDCASE.

  CHECK L_APPLICATION IS NOT INITIAL.

  CALL FUNCTION 'ZWDY_EXECUTE_IN_PLACE'
    EXPORTING
      INTERNALMODE        = ''
      APPLICATION         = L_APPLICATION
      SUPPRESS_OUTPUT     = 'X'
    IMPORTING
      OUT_URL             = L_OUT_URL
    EXCEPTIONS
      INVALID_APPLICATION = 1
      BROWSER_NOT_STARTED = 2
      ACTION_CANCELLED    = 3
      OTHERS              = 4.
  IF SY-SUBRC <> 0.
    MESSAGE ID SY-MSGID TYPE 'W' NUMBER SY-MSGNO
                WITH SY-MSGV1 SY-MSGV2 SY-MSGV3 SY-MSGV4 DISPLAY LIKE SY-MSGTY.
  ENDIF.
  CHECK L_OUT_URL IS NOT INITIAL .
  L_OUT_URL = L_OUT_URL && '&' && L_PARAM.

  CALL FUNCTION 'ZURL_EXECUTE_IN_PLACE'
    EXPORTING
      IN_URL              = L_OUT_URL
    EXCEPTIONS
      INVALID_APPLICATION = 1
      BROWSER_NOT_STARTED = 2
      ACTION_CANCELLED    = 3
      OTHERS              = 4.
  IF SY-SUBRC <> 0.
*            MESSAGE ID sy-msgid TYPE 'W' NUMBER sy-msgno
*                        WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 DISPLAY LIKE sy-msgty.
  ENDIF.
ENDFORM.
