
DATA:BEGIN OF S_SCREEN,
       DYNNR          LIKE SY-DYNNR,
       ACTIVETAB(132),
       PROG           LIKE SY-REPID,
     END OF S_SCREEN .

"TYPES TY_ZTYPE TYPE ZLM_CRTYPE.

SELECTION-SCREEN BEGIN OF SCREEN 100 AS SUBSCREEN.
SELECTION-SCREEN BEGIN OF BLOCK BL10 WITH FRAME TITLE TEXT-T01.
SELECT-OPTIONS: S_MATNR FOR MAKT-MATNR.
.

SELECTION-SCREEN END OF BLOCK BL10.


*PARAMETERS: P_CHK10 AS CHECKBOX .
SELECTION-SCREEN END OF SCREEN 100.




* STANDARD SELECTION SCREEN
SELECTION-SCREEN: BEGIN OF TABBED BLOCK MYTAB FOR 10 LINES,
                  TAB (20) BUTTON1 USER-COMMAND PUSH1,
                  END OF BLOCK MYTAB.


INITIALIZATION.
  PERFORM INI_DEFAULT.

AT SELECTION-SCREEN OUTPUT.
  PERFORM SET_SCREEN."依据屏幕变化设置屏幕元素的相关属性



AT SELECTION-SCREEN.
  PERFORM CHECK_PAR." 检查输入的选择屏幕参数的有效性



START-OF-SELECTION.

  PERFORM GET_DATA. "读取数据


END-OF-SELECTION.

  PERFORM SHOW_ALV. "ALV显示


*&---------------------------------------------------------------------*
*&      Form  INI_DEFAULT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM INI_DEFAULT.
  BUTTON1 = TEXT-010.
*  BUTTON2 = TEXT-020.
  MYTAB-PROG = SY-REPID.
  IMPORT S_SCREEN TO S_SCREEN FROM MEMORY ID 'S_SCREEN'  .
  IF S_SCREEN-PROG = MYTAB-PROG AND SY-BATCH <> 'X'.
    MOVE-CORRESPONDING S_SCREEN TO MYTAB.
  ELSE.
    MYTAB-DYNNR = 100.
    MYTAB-ACTIVETAB = 'PUSH1'.
  ENDIF.
*





ENDFORM.                    "INI_DEFAULT


*&---------------------------------------------------------------------*
*&      Form  SET_SCREEN
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM SET_SCREEN .


ENDFORM.                    " SET_SCREEN
*&---------------------------------------------------------------------*
*&      Form  CHECK_PAR
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM CHECK_PAR .
  IF SY-UCOMM = 'ONLI' ."执行时
*    IF  P_CHK01 = 'X'.
*      IF P_ZGZRQ IS INITIAL
*          OR P_HKONT1 IS INITIAL
*          OR P_RSTGR IS INITIAL.
*        MESSAGE E105(ZDX_001).
*
*      ENDIF.

*    ENDIF.

  ENDIF.


  CASE SY-DYNNR.
    WHEN 1000.
      CASE SY-UCOMM.
        WHEN 'PUSH1'.
          MYTAB-DYNNR = 100.
          MYTAB-ACTIVETAB = 'PUSH1'.
        WHEN 'PUSH2'.
          MYTAB-DYNNR = 200.
          MYTAB-ACTIVETAB = 'PUSH2'.
        WHEN 'PUSH3'.
          MYTAB-DYNNR = 300.
          MYTAB-ACTIVETAB = 'PUSH3'.
        WHEN 'PUSH4'.
          MYTAB-DYNNR = 400.
          MYTAB-ACTIVETAB = 'PUSH4'.
        WHEN 'PUSH5'.
          MYTAB-DYNNR = 500.
          MYTAB-ACTIVETAB = 'PUSH5'.
      ENDCASE.
  ENDCASE.




ENDFORM.                    " CHECK_PAR
