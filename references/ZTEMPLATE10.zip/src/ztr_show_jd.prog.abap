*&---------------------------------------------------------------------*
*&  包含                ZTR_SHOW_JD
*&---------------------------------------------------------------------*
*1.FROM schedule为显示处理进度，使用时
*	    DATA: i_percent TYPE I.
*        l_lines = LINES( P_DATA ).
*	  LOOP AT P_DATA INTO WA.
*         i_percent =  sy-tabix * 100 / l_lines .
*         perform schedule using '正在写入数据:' i_percent .
*        ENDLOOP.
*2.FORM window_of_log 为SAP标准的错误窗口显示错误信息。
*--------------------------------------------------------------------*


DATA:IL_BEF_PERCENT TYPE INT4.  " 上一次使用的点比,如是本次与上一次一样,则直接返回
DATA:LS_MSGNO TYPE MSGNO.

*&---------------------------------------------------------------------*
*&      Form  schedule
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->C_MESSAGE  text
*      -->I_PERCENT  text
*----------------------------------------------------------------------*
FORM FM_SHOW_TEXT USING C_MESSAGE TYPE C.
  DATA: C_SCHE(204).
  DATA:I_PERCENT TYPE I.

  IF SY-BATCH = 'X'."后台执行，不显示进度
    RETURN.
  ENDIF.

  I_PERCENT = IL_BEF_PERCENT.

  IL_BEF_PERCENT = I_PERCENT .

  IF I_PERCENT <= 0 OR I_PERCENT > 100 .
    I_PERCENT = 1.
  ENDIF.

  DATA: C_PERCENT(4),
        C_BLOCK(6)   TYPE C VALUE '■',
        I_BLOCKLEN   TYPE I,
        I_COUNT      TYPE I,
        I_COL        TYPE I,
        I_LEN        TYPE I,
        I_TEMP       TYPE I VALUE 0,
        I_MOD        TYPE I.
  I_BLOCKLEN = STRLEN( C_BLOCK ).
  C_PERCENT = I_PERCENT.
  CONDENSE C_PERCENT.
  C_PERCENT+3(1) = '%'.
*  c_sche = c_percent.
  I_COUNT = I_PERCENT / 4.
  DO I_COUNT TIMES.
*    i_col = ( i_temp * i_blocklen ) + 4.
    I_COL = ( I_TEMP * I_BLOCKLEN ).
    C_SCHE+I_COL(I_BLOCKLEN) = C_BLOCK.
    I_TEMP = I_TEMP + 1.
  ENDDO.
  I_LEN = STRLEN( C_MESSAGE ).
  I_MOD = I_LEN MOD 2.
  IF I_MOD = 1.
    I_LEN = I_LEN + 1.
  ENDIF.
*  if i_len > 0.
*    c_sche+4(i_len) = c_message.
*  endif.

  CONCATENATE C_PERCENT C_MESSAGE C_SCHE INTO C_SCHE.

  I_LEN = STRLEN( C_SCHE ).

  CALL FUNCTION 'SAPGUI_PROGRESS_INDICATOR'
    EXPORTING
      PERCENTAGE = 0
      TEXT       = C_SCHE
    EXCEPTIONS
      OTHERS     = 1.
ENDFORM.


FORM SCHEDULE USING
C_MESSAGE TYPE C
I_PERCENT TYPE I.
  DATA: C_SCHE(204).

  IF SY-BATCH = 'X'."后台执行，不显示进度
    RETURN.
  ENDIF.
  IF I_PERCENT = IL_BEF_PERCENT AND I_PERCENT <> 100.
    RETURN.
  ENDIF.

  IL_BEF_PERCENT = I_PERCENT .

  IF I_PERCENT <= 0 OR I_PERCENT > 100 .
    I_PERCENT = 1.
  ENDIF.

  DATA: C_PERCENT(4),
        C_BLOCK(6)   TYPE C VALUE '■',
        I_BLOCKLEN   TYPE I,
        I_COUNT      TYPE I,
        I_COL        TYPE I,
        I_LEN        TYPE I,
        I_TEMP       TYPE I VALUE 0,
        I_MOD        TYPE I.
  I_BLOCKLEN = STRLEN( C_BLOCK ).
  C_PERCENT = I_PERCENT.
  CONDENSE C_PERCENT.
  C_PERCENT+3(1) = '%'.
*  c_sche = c_percent.
  I_COUNT = I_PERCENT / 4.
  DO I_COUNT TIMES.
*    i_col = ( i_temp * i_blocklen ) + 4.
    I_COL = ( I_TEMP * I_BLOCKLEN ).
    C_SCHE+I_COL(I_BLOCKLEN) = C_BLOCK.
    I_TEMP = I_TEMP + 1.
  ENDDO.
  I_LEN = STRLEN( C_MESSAGE ).
  I_MOD = I_LEN MOD 2.
  IF I_MOD = 1.
    I_LEN = I_LEN + 1.
  ENDIF.
*  if i_len > 0.
*    c_sche+4(i_len) = c_message.
*  endif.

  CONCATENATE C_PERCENT C_MESSAGE C_SCHE INTO C_SCHE.

  I_LEN = STRLEN( C_SCHE ).

  CALL FUNCTION 'SAPGUI_PROGRESS_INDICATOR'
    EXPORTING
      PERCENTAGE = 0
      TEXT       = C_SCHE
    EXCEPTIONS
      OTHERS     = 1.
ENDFORM. " SCHEDULE
