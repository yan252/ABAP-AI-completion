class ZCL_TEST_01 definition
  public
  final
  create public .

public section.
protected section.
private section.

  methods ZTEST
    importing
      !IV_MATNR type MATNR
    exporting
      !EX_SUCC type FLAG .
ENDCLASS.



CLASS ZCL_TEST_01 IMPLEMENTATION.


  method ZTEST.
    ex_succ = 'X'.

  endmethod.
ENDCLASS.
