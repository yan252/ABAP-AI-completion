

MODULE USER_COMMAND_9001 INPUT.
  LEAVE TO SCREEN 0.
ENDMODULE.                 " USER_EXIT  INPUT
*&---------------------------------------------------------------------*
*&      Module  STATUS_9001  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE STATUS_9001 OUTPUT.

  DATA: LV_TITLE TYPE STRING.
  LV_TITLE = LINES( GT_ALV[] ).
*  lv_title = '销售价格查询报表 条目数【' && lv_title && '】'.
  CONCATENATE SY-TITLE ' 条目数【' LV_TITLE   '】'
        INTO LV_TITLE .

  SET PF-STATUS 'ZST'.
  SET TITLEBAR 'TITLE' WITH LV_TITLE.

ENDMODULE.                 " STATUS_9001  OUTPUT
