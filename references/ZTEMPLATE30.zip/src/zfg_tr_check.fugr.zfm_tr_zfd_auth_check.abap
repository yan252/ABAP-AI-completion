FUNCTION ZFM_TR_ZFD_AUTH_CHECK.
**"--------------------------------------------------------------------
**"*"局部接口：
**"  IMPORTING
**"     REFERENCE(BUKRS) TYPE  BUKRS
**"     REFERENCE(ZZFS) TYPE  ZTR_ZFD_ZFS
**"  EXCEPTIONS
**"      ERR
**"--------------------------------------------------------------------
*DATA: lv_zzftype TYPE ztr_zftype,
*        lv_string  TYPE string.
*  CHECK zcl_tr_3024_gui=>auth = abap_true OR sy-sysid = 'ERP'.
*
*  CASE zzfs.
*    WHEN '10'.
*      lv_zzftype = 'P003'.
*    WHEN '20' OR '30' OR '31' OR '32' OR '33' OR '99'.
*      lv_zzftype = 'P002'.
*    WHEN  '51' OR '52' OR '53' OR '54'.
*      lv_zzftype = 'P005'.
*    WHEN OTHERS.
*      MESSAGE e219(ztr05) WITH bukrs  RAISING err.
*  ENDCASE.
*
*  AUTHORITY-CHECK OBJECT 'Z_TR303'
*   ID 'BUKRS' FIELD bukrs
*   ID 'ZTR_ZFTYPE' FIELD lv_zzftype.
*  IF sy-subrc <> 0.
*    zcl_wd_common=>get_dom_value(
*      EXPORTING
*        im_domnam = 'ZDM_TR_ZFTYPE'
*        im_domval = lv_zzftype
*      RECEIVING
*        ex_desc   = lv_string
*    ).
*    MESSAGE e219(ztr05) WITH bukrs lv_string  RAISING err.
*  ENDIF.
*
*



ENDFUNCTION.
