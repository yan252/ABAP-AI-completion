FUNCTION ZFM_TR_CREATE_ZFSQD.
**"--------------------------------------------------------------------
**"*"局部接口：
**"  IMPORTING
**"     VALUE(I_HEAD) TYPE  ZTRT2500_1
**"     VALUE(I_ITEMS) TYPE  ZTRT2500_2T OPTIONAL
**"  EXPORTING
**"     VALUE(E_DOCNO) TYPE  ZTR_DOCNO
**"     VALUE(E_RTCODE) TYPE  FINB_GN_ERROR_CODE
**"     VALUE(E_MSG) TYPE  TTET_ERRMESSAGE_COM
**"--------------------------------------------------------------------
*DATA lt_ddt TYPE TABLE OF dd03vt WITH HEADER LINE.
*  DATA ls_dd07t TYPE  dd07t  .
*  DATA lv_sum TYPE  wrbtr  .
*  DATA ls_log_h TYPE ztrt2500_1_log.
*  DATA ls_log_i TYPE ztrt2500_2_log.
*  DATA lt_log_i TYPE TABLE OF ztrt2500_2_log.
*  DATA: lv_projk TYPE ps_posnr."WBS
*  DATA e_return  TYPE  bapiret2.
*
*  DEFINE  req_check.
*    IF &1-&2  IS INITIAL AND e_msg IS INITIAL.
*      CLEAR lt_ddt.
*      READ TABLE lt_ddt WITH  KEY  fieldname = '&2'.
*      e_rtcode = '11'.
*      e_msg = '必输字段' && '&2' && lt_ddt-ddtext && '信息未输入'.
*     " RETURN.
*    ENDIF.
*  END-OF-DEFINITION.
*  CLEAR lv_sum.
*
*  MOVE-CORRESPONDING i_head TO ls_log_h.
*  MOVE-CORRESPONDING i_items[] TO lt_log_i.
*
*  "   获取字段及描述
*  SELECT DISTINCT fieldname ddtext INTO CORRESPONDING FIELDS OF TABLE lt_ddt
*  FROM dd03vt
*  WHERE ddlanguage = '1' AND tabname LIKE 'ZTRT2500%'.
*  req_check:i_head     bukrs,
*            i_head     bcate,
*            i_head     zzfstatus,
*            i_head     ztr_bpt,
*            i_head     ztr_bp,
*            i_head     betdt,
*            i_head     zskfs,
*            i_head     waers,
*            i_head     zzfje,
*            i_head     bvtyp
**            i_head     erdat,
**            i_head     ernam
*            .
*
*
*  CASE i_head-bcate.
*    WHEN '21'."关税支付申请
*      req_check:i_head     prctr,
*            i_head     fund_flow,
*                i_head     ref01.
*
*      IF i_head-ref_docno IS INITIAL AND i_head-docno IS NOT INITIAL.
*        i_head-ref_docno  = i_head-docno.
*      ENDIF.
*    WHEN '22'."暂借款申请
*      req_check:
*            i_head     fund_flow,
*            i_head     ref02.
*      IF i_head-ref02 NE '2'."其他类型暂借的利润中心在明细里面
*        req_check:i_head     prctr.
*      ENDIF.
*      req_check:
*            i_head     fund_flow,
*            i_head     yjhk_date.
*    WHEN '25'."工资支付申请
*      req_check:
*            i_head     fund_flow,
*            i_head     gzzfzq.
*      req_check:i_head     prctr.
*    WHEN '12'."退款通知单
*      req_check:
*            i_head     fund_flow,
*            i_head     tklx,
*               i_head     vkorg,
*               i_head     vtweg,
*               i_head     mbz02.
*
*    WHEN '13'.
*      req_check: i_head     tklx.
*    WHEN OTHERS.
*      e_rtcode = '11'.
*      e_msg = '函数暂时不支持此类型的单据'.
*      " RETURN.
*  ENDCASE.
*  req_check:     i_head     ref_docno.
*
**--------------校验WBS必输---------------------------
**  IF i_head-fund_flow = 'D11' .
**    req_check:     i_head     projk.
**  ENDIF.
*
*  IF i_head-fund_flow = 'D11' .
*    IF i_head-projk IS NOT INITIAL AND  i_head-projk  NE '00000000'.
**      CALL FUNCTION 'NUMERIC_CHECK'
**        EXPORTING
**          string_in        = i_head-projk
**       IMPORTING
***         STRING_OUT       = STRING_OUT
**          HTYPE            = data(HTYPE)
**                .
*      IF  i_head-projk   CO '0123456789 ' .
*        lv_projk = i_head-projk.
*        CALL FUNCTION 'CONVERSION_EXIT_ABPSP_OUTPUT'
*          EXPORTING
*            input  = i_head-projk
*          IMPORTING
*            output = i_head-projk.
*      ELSE.
*        CALL FUNCTION 'CONVERSION_EXIT_ABPSP_INPUT'
*          EXPORTING
*            input     = i_head-projk
*          IMPORTING
*            output    = lv_projk
*          EXCEPTIONS
*            not_found = 1
*            OTHERS    = 2.
*        IF sy-subrc <> 0.
*          e_rtcode = '14'.
*          e_msg = |'WBS元素 { i_head-projk } 不存在'|.
*          "  RETURN.
*        ENDIF.
*      ENDIF.
*    ENDIF.
*
*    CALL FUNCTION 'ZFM_TR_COMMONCHECK_PSPNR'
*      EXPORTING
*        bukrs    = i_head-bukrs
*        pspnr    = lv_projk
*      IMPORTING
*        e_return = e_return
*      EXCEPTIONS
*        error    = 1
*        OTHERS   = 2.
*    IF sy-subrc <> 0.
*      e_rtcode = '14'.
*      e_msg = e_return-message.
*      " RETURN.
*    ENDIF.
*
*  ENDIF.
*
*  " 检查外部单据号是否重复
*  SELECT SINGLE docno INTO @DATA(lv_ref)
*    FROM ztrt2500_1
*          WHERE ref_docno = @i_head-ref_docno
*        AND ref_docno NE ''
*        AND bukrs =  @i_head-bukrs
*        AND bcate =  @i_head-bcate
*        AND dflag = @space.
*  IF sy-subrc = 0 AND e_msg IS INITIAL.
*    e_rtcode = '13'.
*    e_msg = '该关联单据号已存在记录，业务单据号：' && lv_ref.
*    e_docno = lv_ref.
*    " RETURN.
*  ENDIF.
*
*  "检查有效值
*  "单据类型
*  SELECT SINGLE * FROM dd07t INTO  CORRESPONDING FIELDS OF ls_dd07t
*    WHERE domname  = 'ZTRDM_BILL_CATE'
*      AND domvalue_l = i_head-bcate.
*  IF sy-subrc <> 0 AND e_msg IS INITIAL.
*    e_rtcode = '14'.
*    e_msg =   '单据类型bcate字段' &&  i_head-bcate && '不是有效值' .
*    " RETURN.
*  ENDIF.
*  "单据状态
*  SELECT SINGLE * FROM dd07t  INTO  CORRESPONDING FIELDS OF   ls_dd07t
*  WHERE domname  = 'ZTRDM_APPRO'
*  AND domvalue_l = i_head-zzfstatus.
*  IF sy-subrc <> 0 AND e_msg IS INITIAL.
*    e_rtcode = '14'.
*    e_msg =   '单据状态zzfstatus字段' &&  i_head-zzfstatus && '不是有效值' .
*    " RETURN.
*  ENDIF.
*  "收款方标识
*  SELECT SINGLE * FROM dd07t  INTO  CORRESPONDING FIELDS OF   ls_dd07t
*  WHERE domname  = 'ZDM_TR_ZFMARK'
*  AND domvalue_l = i_head-ztr_bpt.
*  IF sy-subrc <> 0 AND e_msg IS INITIAL.
*    e_rtcode = '14'.
*    e_msg =   '收款方标识ZTR_BPT字段' &&  i_head-ztr_bpt && '不是有效值' .
*    " RETURN.
*  ENDIF.
*
*  "收款方编号 ,对方开户行类型
*
*
*  CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
*    EXPORTING
*      input  = i_head-ztr_bp
*    IMPORTING
*      output = i_head-ztr_bp.
*  IF i_head-ztr_bpt = '10'.
*    SELECT SINGLE kunnr INTO i_head-ztr_bp
*      FROM kna1
*      WHERE kunnr = i_head-ztr_bp.
*    IF sy-subrc = 0.
*      SELECT SINGLE bvtyp INTO i_head-bvtyp
*         FROM knbk
*        WHERE  bvtyp = i_head-bvtyp
*        AND kunnr = i_head-ztr_bp.
*      IF sy-subrc <> 0 AND e_msg IS INITIAL.
*        e_rtcode = '14'.
*        e_msg =   '开户行类型BVTYP字段' &&  i_head-bvtyp && '不是有效值' .
*        " RETURN.
*      ENDIF.
*    ELSE.
*      e_rtcode = '14'.
*      e_msg =   '收款方编号ZTR_BP字段' &&  i_head-ztr_bp && '不存在' .
*      " RETURN.
*    ENDIF.
*  ELSEIF  i_head-ztr_bpt = '20'.
*    SELECT SINGLE lifnr INTO i_head-ztr_bp
*    FROM lfa1
*    WHERE lifnr = i_head-ztr_bp.
*    IF sy-subrc = 0.
*      SELECT SINGLE bvtyp INTO i_head-bvtyp
*      FROM lfbk
*      WHERE  bvtyp = i_head-bvtyp
*      AND lifnr = i_head-ztr_bp.
*      IF sy-subrc <> 0 AND e_msg IS INITIAL.
*        e_rtcode = '14'.
*        e_msg =   '开户行类型BVTYP字段' &&  i_head-bvtyp && '不是有效值' .
*        "  RETURN.
*      ENDIF.
*    ELSE.
*      e_rtcode = '14'.
*      e_msg =   '收款方编号ZTR_BP字段' &&  i_head-ztr_bp && '不存在' .
*      " RETURN.
*    ENDIF.
*  ENDIF.
*
*
*
*
*  IF i_head-zterm IS INITIAL.
*    i_head-zterm = 'ZZZZ'.
*  ENDIF.
*
*  PERFORM curr_amount_bapi_to_sap USING i_head-waers   i_head-bcate CHANGING i_head-zzfje.
*
*  IF i_head-sjzfje =  0.
*    i_head-sjzfje = i_head-zzfje.
*  ELSE.
*    PERFORM curr_amount_bapi_to_sap USING i_head-waers  i_head-bcate  CHANGING i_head-sjzfje.
*  ENDIF.
*
*  IF i_head-jhzfe =  0.
*    i_head-jhzfe = i_head-zzfje.
*  ELSE.
*    PERFORM curr_amount_bapi_to_sap USING i_head-waers   i_head-bcate  CHANGING i_head-jhzfe.
*  ENDIF.
*
*
*
*  i_head-erdat = sy-datum.
*  i_head-erzet = sy-uzeit.
*  i_head-ernam = sy-uname.
*  LOOP AT  i_items ASSIGNING FIELD-SYMBOL(<fs_item>).
*    <fs_item>-bcate = i_head-bcate.
*
*    PERFORM curr_amount_bapi_to_sap USING i_head-waers  i_head-bcate   CHANGING <fs_item>-subzfje.
*    PERFORM curr_amount_bapi_to_sap USING i_head-waers  i_head-bcate  CHANGING <fs_item>-wrbtr.
*
*    req_check:<fs_item>     bcate,
*              <fs_item>     itemno.
*
*    CASE i_head-bcate.
*      WHEN '21'."关税支付申请
*        req_check:
*    <fs_item>     prctr,
*    <fs_item>     zlsch,
*    <fs_item>     rstgr,
*    <fs_item>     sgtxt.
*
*      WHEN '22'."暂借款申请
*        IF i_head-ref02 = '2'.
*          req_check:
*          <fs_item>     prctr,
*          <fs_item>     name,
*          <fs_item>     banks,
*          <fs_item>     bankl ,
*          <fs_item>     banka,
*          <fs_item>     bankn,
*          <fs_item>     subzfje .
*
*          SELECT SINGLE bankl  INTO   <fs_item>-bankl
*            FROM bnka
*             WHERE banks = <fs_item>-banks
*            AND bankl = <fs_item>-bankl.
*          IF sy-subrc <> 0 AND e_msg IS INITIAL.
*            e_rtcode = '14'.
*            e_msg =   '收款银行码BANKL字段' && <fs_item>-bankl && '不是有效值' .
*            " RETURN.
*          ENDIF.
*
*          IF <fs_item>-wrbtr = 0 AND <fs_item>-subzfje NE 0.
*            <fs_item>-wrbtr = <fs_item>-subzfje.
*          ENDIF.
*        ENDIF.
*
*      WHEN '25'."工资支付申请
*        req_check: <fs_item>     prctr,
*                   <fs_item>     subzfje,
*                   <fs_item>     hktid,
*                   <fs_item>     hbkid.
*        SELECT COUNT(*) FROM ztrt0013 WHERE hktid = <fs_item>-hktid AND hbkid = <fs_item>-hbkid AND bukrs = i_head-bukrs.
*        IF sy-subrc <> 0.
*          e_rtcode = '16'.
*          e_msg = '所选付款银行不存在'.
*        ENDIF.
*
*
*      WHEN '12'."退款通知单
*        req_check:  <fs_item>     belnr,
*                    <fs_item>     buzei,
*                    <fs_item>     gjahr ,
*                    <fs_item>     subzfje ,
*                   " <fs_item>     prctr,
*                    <fs_item>     wrbtr,
*                  "  <fs_item>     zlsch,
*                  "  <fs_item>     rstgr,
*                    <fs_item>     sgtxt.
*        IF <fs_item>-wrbtr < <fs_item>-subzfje .
*          e_rtcode = '12'.
*          e_msg = '本次支付金额大于需付款金额'.
*          " RETURN.
*        ENDIF.
*      WHEN '13'."退款
*        req_check:  <fs_item>     belnr,
*                    <fs_item>     buzei,
*                    <fs_item>     gjahr ,
*                    <fs_item>     subzfje ,
*                   " <fs_item>     prctr,
*                    <fs_item>     banks,
*                    <fs_item>     bankl,
*                    <fs_item>     banka,
*                    <fs_item>     bankn,
*                    <fs_item>     swift,
*                    <fs_item>     wrbtr,
*                   " <fs_item>     rstgr,
*                  "  <fs_item>     zlsch,
*                    <fs_item>     name.
*        "  <fs_item>     sgtxt.
*        SELECT COUNT(*) FROM bnka
*          WHERE banks = <fs_item>-banks
*          AND bankl = <fs_item>-bankl
*          AND swift = <fs_item>-swift
*          .
*        IF sy-subrc <> 0.
*          e_rtcode = '17'.
*          e_msg =  '明细行' && <fs_item>-itemno && '银行主记录不存在'.
*        ENDIF.
*
*
*
*      WHEN OTHERS.
*
*        IF <fs_item>-wrbtr = 0 AND <fs_item>-subzfje NE 0.
*          <fs_item>-wrbtr = <fs_item>-subzfje.
*        ENDIF.
*    ENDCASE.
*    IF <fs_item>-belnr IS NOT INITIAL.
*      SELECT SINGLE a~waers,wrbtr,prctr,zlsch,rstgr INTO @DATA(lv_bseg) FROM bkpf
*            AS a INNER JOIN bseg AS b ON a~gjahr = b~gjahr AND a~bukrs = b~bukrs AND a~belnr = b~belnr
*           WHERE a~belnr = @<fs_item>-belnr AND a~bukrs = @i_head-bukrs AND a~gjahr = @<fs_item>-gjahr AND buzei = @<fs_item>-buzei.
*      IF sy-subrc <> 0 OR lv_bseg-waers NE i_head-waers.
*        e_rtcode = '18'.
*        e_msg =  '明细行' && <fs_item>-itemno && '凭证币种与支付申请币种不一致'.
*
*      ELSE.
*        <fs_item>-prctr = lv_bseg-prctr.
*        <fs_item>-zlsch = lv_bseg-zlsch.
*        <fs_item>-rstgr = lv_bseg-rstgr.
*      ENDIF.
*    ENDIF.
*
*    ADD <fs_item>-subzfje TO lv_sum .
*  ENDLOOP.
*
*  IF  i_items[] IS  INITIAL AND  i_head-bcate = '22'  AND i_head-ref02 = '2'.
*    e_rtcode = '15'.
*    e_msg = '明细表金额汇总与抬头表金额不相等'.
*    "RETURN.
*
*  ELSEIF i_items[] IS  INITIAL."为了方便做关联视图，将明细表也填入值，明细序号为空
*    APPEND VALUE ztrt2500_2( bcate  = i_head-bcate
*                            subzfje = i_head-jhzfe
*                            wrbtr   = i_head-jhzfe
*                            prctr   = i_head-prctr
*                            rstgr   = i_head-fund_flow
*                            zlsch   = i_head-zskfs )
*    TO i_items.
*    lv_sum = i_head-sjzfje.
*  ENDIF.
**  ENDIF.
*
*
*  IF i_items[] IS NOT INITIAL.
*    IF lv_sum NE i_head-sjzfje.
*      e_rtcode = '15'.
*      e_msg = '明细表金额汇总与抬头表金额不相等'.
*      " RETURN.
*    ENDIF.
*  ENDIF.
*
*  IF e_msg IS INITIAL."正确的保存
*
*    CALL FUNCTION 'ZFM_GET_RANGE_NR'
*      EXPORTING
*        iv_doctype     = 'PY01'
*        iv_config_type = 'P1'
*      IMPORTING
*        ev_docno       = i_head-docno.
*
*
*
*    LOOP AT  i_items ASSIGNING  <fs_item> .
*      <fs_item>-docno = i_head-docno.
*      <fs_item>-erdat = sy-datum.
*      <fs_item>-erzet = sy-uzeit.
*      <fs_item>-ernam = sy-uname.
*    ENDLOOP.
*
*    MODIFY ztrt2500_1 FROM i_head.
*    MODIFY ztrt2500_2 FROM TABLE i_items.
*
*    COMMIT WORK AND WAIT.
*    DO 3 TIMES.
*      SELECT SINGLE docno FROM ztrt2500_1 INTO e_docno
*      WHERE docno = i_head-docno .
*      IF sy-subrc = 0.
*        RETURN.
*      ELSE.
*        WAIT UP TO 1 SECONDS.
*      ENDIF.
*    ENDDO.
*
*    "没有从表中获取到
*
*    e_rtcode = '16'.
*    e_msg = '保存失败,请重试'.
*  ENDIF.
*
*  IF  e_msg IS NOT INITIAL. "错误的记日志
*
*    ls_log_h-db_key   =   /bobf/cl_frw_factory=>get_new_key( ) ..
*    ls_log_h-e_msg    = e_msg.
*    ls_log_h-docno    = i_head-docno..
*    ls_log_h-e_rtcode = e_rtcode.
*    ls_log_h-erdat = sy-datum.
*    ls_log_h-erzet = sy-uzeit.
*
*    LOOP AT  lt_log_i  ASSIGNING FIELD-SYMBOL(<fs_log>) .
*      <fs_log>-db_key   =  ls_log_h-db_key.
*    ENDLOOP.
*    MODIFY ztrt2500_1_log FROM ls_log_h.
*    MODIFY ztrt2500_2_log FROM TABLE lt_log_i.
*  ENDIF.
*  COMMIT WORK AND WAIT.
*
*
*
*
*FORM curr_amount_bapi_to_sap USING i_curr LIKE tcurc-waers  i_bcate TYPE ztr_bill_cate
*                     CHANGING e_idoc.
*  DATA sap_amount  TYPE bapicurr-bapicurr.
*
*
*  IF e_idoc = 0 .
*    RETURN.
*  ENDIF.
*
*  IF i_bcate NE '13' AND i_bcate NE '22'  . "暂时发现外销退款有外币（日币），后续发现有转换问题再加
*    RETURN.
*  ENDIF.
*
*  CALL FUNCTION 'CURRENCY_AMOUNT_BAPI_TO_SAP'
*    EXPORTING
*      currency              = i_curr
*      bapi_amount           = CONV bapicurr-bapicurr( e_idoc )
*    IMPORTING
*      sap_amount            = sap_amount
*    EXCEPTIONS
*      bapi_amount_incorrect = 1
*      OTHERS                = 2.
*  IF sy-subrc <> 0.
*  ELSE.
*    e_idoc = sap_amount.
*  ENDIF.
*
*
*
*ENDFORM.
*




ENDFUNCTION.
