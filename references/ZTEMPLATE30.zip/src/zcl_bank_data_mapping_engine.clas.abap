class ZCL_BANK_DATA_MAPPING_ENGINE definition
  public
  final
  create public .

public section.

  constants YES type FLAG value 'X' ##NO_TEXT.
  constants NO type FLAG value SPACE ##NO_TEXT.

  class-methods SAP_TO_DMEE_FILE
    importing
      value(IM_TREE_TYPE) type ZTR_TREE_TYPE
      value(IM_TREE_ID) type ZTR_TREE_ID
      value(IM_SAP_DATA) type STANDARD TABLE
      value(IM_ENCODING) type ZTR_ENCODING optional
    exporting
      value(EX_CFILE) type ref to DATA
      value(EX_XFILE) type ref to DATA
      value(ET_RETURN_ERRORS) type BAPIRET2_TAB .
  class-methods CONVERT_XML_TO_SAP
    importing
      !IM_XML_XSTRING type XSTRING optional
      !IM_XML_STRING type STRING optional
      !IM_XML_STRUCTURE type TABNAME
      !IM_XML_TRANSFORMATION type ZTR_RESPONSE_TRANSFORMATION
    returning
      value(RE_DATA_REFERENCE) type ref to DATA .
  class-methods RESET_ELEMENT_VALUE
    importing
      !IM_T_ELEMENT_VALUES type ZTRS_XML_ELEMENT_VALUE_TAB
    exporting
      !ET_RETURN_ERRORS type BAPIRET2_TAB
    changing
      !CH_XML_XSTRING type XSTRING optional
      !CH_XML_STRING type STRING optional .
  class-methods RESET_ELEMENT_VALUE_FROM_XML
    importing
      !IM_XML_STRING_SOURCE type STRING optional
      !IM_XML_XSTRING_SOURCE type XSTRING optional
      !IM_T_FIELDNAME type ZTRS_FIELDNAME_TAB
    exporting
      !EX_T_RETURN_ERRORS type BAPIRET2_TAB
    changing
      !CH_XML_STRING_TARGET type STRING optional
      !CH_XML_XSTRING_TARGET type XSTRING optional .
  class-methods ADD_ELEMENTS
    importing
      !IM_XML_STRING type STRING
      !IM_XML_XSTRING type XSTRING
      !IM_T_ADDING_ELEMENTS type ZTRS_ADD_XML_ELEMENT_TAB
    exporting
      !EX_XML_STRING type STRING
      !EX_XML_XSTRING type XSTRING
      !EX_T_RETURN_ERRORS type BAPIRET2_TAB .
  class-methods GET_ELEMENT_VALUE
    importing
      !IM_XML_STRING type STRING optional
      !IM_XML_XSTRING type XSTRING optional
      !IM_T_FIELDNAME type ZTRS_FIELDNAME_TAB
    exporting
      !EX_T_RETURN_ERRORS type BAPIRET2_TAB
      !EX_T_ELEMENT_VALUES type ZTRS_XML_ELEMENT_VALUE_TAB .
  class-methods CREATE_XML_DOCUMENT_BY_STRING
    importing
      !IM_XML_STRING type STRING optional
      !IM_XML_XSTRING type XSTRING optional
    exporting
      !EX_O_XML type ref to IF_IXML
      !EX_O_DOCUMENT type ref to IF_IXML_DOCUMENT
      !EX_O_STREAM_FACTORY type ref to IF_IXML_STREAM_FACTORY
      !EX_O_PARSER type ref to IF_IXML_PARSER
      !EX_T_ERRORS type ZTRS_XML_ERROR_TAB
      !EX_O_ISTREAM type ref to IF_IXML_ISTREAM .
  class-methods ENCODE_STRING_TO_XSTRING
    importing
      !IM_ENCODING_CHARSET type STRING
      !IM_XML_STRING type STRING
    returning
      value(RE_XML_XSTRING) type XSTRING .
  class-methods SET_ELEMENT_ATTRIBUTE_VALUES
    importing
      !IM_T_ATTRIBUTE_VALUES type ZTRS_XML_ATTRIBUTE_VALUE_TAB
    exporting
      !ET_RETURN_ERRORS type BAPIRET2_TAB
    changing
      !CH_XML_XSTRING type XSTRING
      !CH_XML_STRING type STRING .
  class-methods SET_ELEMENT_ATTRIBUTE_VALUE
    importing
      !IM_XML_ELEMENT type STRING
      !IM_ATTRIBUTE_NAME type STRING
      !IM_ATTRIBUTE_VALUE type STRING
    exporting
      !ET_RETURN_ERRORS type BAPIRET2_TAB
    changing
      !CH_XML_XSTRING type XSTRING
      !CH_XML_STRING type STRING .
  class-methods SET_XML_STANDALONE
    exporting
      !ET_RETURN_ERRORS type BAPIRET2_TAB
    changing
      !CH_XML_CSTRING type STRING
      !CH_XML_XSTRING type XSTRING .
protected section.
private section.

  class-methods CONVERT_TO_DMEE_PLAINTEXT_FILE
    importing
      value(IM_TREE_TYPE) type ZTR_TREE_TYPE
      value(IM_TREE_ID) type ZTR_TREE_ID
      value(IM_SAP_DATA) type STANDARD TABLE
    exporting
      value(EX_CFILE) type ref to DATA .
  class-methods CONVERT_TO_DMEE_XML_FILE
    importing
      value(IM_TREE_TYPE) type ZTR_TREE_TYPE
      value(IM_TREE_ID) type ZTR_TREE_ID
      value(IM_SAP_DATA) type STANDARD TABLE
      value(IM_ENCODING) type ZTR_ENCODING optional
    exporting
      value(EX_CFILE) type ref to DATA
      value(EX_XFILE) type ref to DATA
      value(ET_RETURN_ERRORS) type BAPIRET2_TAB .
  class-methods SAP_TO_DMEE_XML
    importing
      value(IM_TREE_TYPE) type ZTR_TREE_TYPE
      value(IM_TREE_ID) type ZTR_TREE_ID
      value(IM_SAP_DATA) type STANDARD TABLE
      value(IM_ENCODING) type ZTR_ENCODING optional
    exporting
      value(EX_XML_STRING) type STRING
      value(EX_T_ERRORS) type ZTRS_XML_ERROR_TAB
      value(EX_XML_XSTRING) type XSTRING .
  class-methods CONVERT_SAP_TO_DMEE_OUTPUT
    importing
      !IM_TREE_TYPE type ZTR_TREE_TYPE
      !IM_TREE_ID type ZTR_TREE_ID
      !IM_SAP_DATA type STANDARD TABLE
    returning
      value(RT_DMEE_OUTPUT) type TAB_DMEE_OUTPUT_FILE .
  class-methods CONVERT_TO_DMEE_XML
    importing
      !IM_TREE_TYPE type ZTR_TREE_TYPE
      !IM_TREE_ID type ZTR_TREE_ID
      !IM_SAP_DATA type STANDARD TABLE
    returning
      value(RE_XML) type STRING .
  class-methods CHECK_XML_BY_PARSER
    importing
      !IM_O_PARSER type ref to IF_IXML_PARSER
    returning
      value(RT_ERRORS) type ZTRS_XML_ERROR_TAB .
  class-methods CONVERT_XML_ERROR_TO_BAPIRET
    importing
      !IM_T_XML_ERROR type ZTRS_XML_ERROR_TAB
    returning
      value(RT_RETURN_ERRORS) type BAPIRET2_TAB .
ENDCLASS.



CLASS ZCL_BANK_DATA_MAPPING_ENGINE IMPLEMENTATION.


METHOD add_elements.
    DATA: l_field_string TYPE string.

    zcl_bank_data_mapping_engine=>create_xml_document_by_string(
             EXPORTING
               im_xml_string       = im_xml_string
               im_xml_xstring      = im_xml_xstring
             IMPORTING
               ex_o_document       = DATA(lo_document)
               ex_o_stream_factory = DATA(lo_stream_factory)
               ex_o_xml            = DATA(lo_xml)
*               ex_o_parser         = DATA(lo_paser)
*               ex_o_istream        = DATA(lo_istream)
               ex_t_errors         = DATA(lt_xml_error) ).
    IF lt_xml_error IS NOT INITIAL.
*      不应该出现错误
*      RETURN.
      ex_t_return_errors = convert_xml_error_to_bapiret( lt_xml_error ).
      RETURN.
    ENDIF.

*    LOOP AT im_t_fieldname INTO DATA(l_fieldname).
*     APPEND VALUE #( name = l_fieldname-name
*                     data = lo_document->find_from_name_ns( l_fieldname-name )->get_value( ) )
*                  TO ex_t_element_values.
*    ENDLOOP.

    DATA(lo_iterator) = lo_document->create_iterator( ).
    DATA(lo_node) = lo_iterator->get_next( ).
    IF lo_node IS NOT BOUND.
      RETURN.
    ENDIF.

    WHILE lo_node IS BOUND.
      CASE lo_node->get_type( ).
        WHEN if_ixml_node=>co_node_element.
          READ TABLE im_t_adding_elements INTO DATA(ls_adding_element)
               WITH KEY parent_name = lo_node->get_name( ).
          IF sy-subrc = 0.
            lo_document->create_simple_element_ns(
                                  name = ls_adding_element-name
                                  parent = lo_node
                                  value = ls_adding_element-data ).

          ENDIF.

      ENDCASE.

      FREE lo_node.
      lo_node = lo_iterator->get_next( ).
    ENDWHILE.

    lo_xml->create_renderer(
                ostream = lo_stream_factory->create_ostream_cstring( EX_XML_STRING )
                document = lo_document
                                       )->render( ).

    ex_xml_xstring = encode_string_to_xstring(
                          im_encoding_charset = lo_document->get_encoding( )->get_character_set( )
                          im_xml_string = ex_xml_string ).
  ENDMETHOD.


METHOD check_xml_by_parser.
    DO im_o_parser->num_errors( ) TIMES.
      APPEND VALUE #( LET lo_error = im_o_parser->get_error( sy-index - 1 ) IN
                          line   = lo_error->get_line( )
                          column = lo_error->get_column( )
                          reason = lo_error->get_reason( ) )
                 TO rt_errors.
    ENDDO.
  ENDMETHOD.


METHOD convert_sap_to_dmee_output.

    CALL FUNCTION 'DMEE_START'
      EXPORTING
        i_tree_type = im_tree_type
        i_tree_id   = im_tree_id
        item        = im_sap_data. "not meaningful

    LOOP AT im_sap_data ASSIGNING
                        FIELD-SYMBOL(<fs_sap_data>).
      CALL FUNCTION 'DMEE_PUT_ITEM'
        EXPORTING
          item        = <fs_sap_data>
        TABLES
          file_output = rt_dmee_output.
    ENDLOOP.

    CALL FUNCTION 'DMEE_END'
      TABLES
        file_output = rt_dmee_output.

  ENDMETHOD.


METHOD convert_to_dmee_plaintext_file.
    FIELD-SYMBOLS <ft_dmee_table> TYPE tab_dmee_output_file.

    CREATE DATA ex_cfile TYPE tab_dmee_output_file.
    ASSIGN ex_cfile->* TO <ft_dmee_table>.

    <ft_dmee_table> = zcl_bank_data_mapping_engine=>convert_sap_to_dmee_output(
                                                            im_tree_type   = im_tree_type
                                                            im_tree_id     = im_tree_id
                                                            im_sap_data    = im_sap_data ).
  ENDMETHOD.


METHOD convert_to_dmee_xml.
    LOOP AT convert_sap_to_dmee_output(
                     im_tree_type = im_tree_type
                     im_tree_id = im_tree_id
                     im_sap_data = im_sap_data )
             INTO DATA(ls_output_line).
      re_xml = re_xml && ls_output_line-line.
    ENDLOOP.
  ENDMETHOD.


METHOD CONVERT_TO_DMEE_XML_FILE.

    CREATE DATA ex_cfile TYPE string.
    ASSIGN ex_cfile->* TO FIELD-SYMBOL(<f_xml_string>).

    CREATE DATA ex_xfile TYPE xstring.
    ASSIGN ex_xfile->* TO FIELD-SYMBOL(<f_xml_xstring>).

    zcl_bank_data_mapping_engine=>sap_to_dmee_xml(
                        EXPORTING
                            im_tree_type = im_tree_type
                            im_tree_id = im_tree_id
                            im_encoding = im_encoding
                            im_sap_data = im_sap_data
                        IMPORTING
                            ex_xml_string = <f_xml_string>
                            ex_xml_xstring = <f_xml_xstring>
                            ex_t_errors = DATA(lt_xml_error) ) .
    IF lt_xml_error IS NOT INITIAL.
      LOOP AT lt_xml_error INTO DATA(ls_xml_error).
        MESSAGE e057(ztr_bank_application)
                WITH ls_xml_error-line
                     ls_xml_error-column
                     ls_xml_error-reason
                     INTO DATA(l_dummy_message).
        APPEND VALUE #( type = sy-msgty
                        id = sy-msgid
                        number = sy-msgno
                        message = l_dummy_message
                        message_v1 = sy-msgv1
                        message_v2 = sy-msgv2
                        message_v3 = sy-msgv3
                        message_v4 = sy-msgv4 )
                        TO et_return_errors.
      ENDLOOP.
    ENDIF.
  ENDMETHOD.


METHOD convert_xml_error_to_bapiret.
    LOOP AT im_t_xml_error INTO DATA(ls_xml_error).
      MESSAGE e057(ztr_bank_application)
              WITH ls_xml_error-line
                   ls_xml_error-column
                   ls_xml_error-reason
         INTO DATA(l_dummy_message).
      APPEND VALUE #( type       = sy-msgty
                      id         = sy-msgid
                      number     = sy-msgno
                      message    = l_dummy_message
                      message_v1 = sy-msgv1
                      message_v2 = sy-msgv2
                      message_v3 = sy-msgv3
                      message_v4 = sy-msgv4 )
                      TO rt_return_errors.
    ENDLOOP.
  ENDMETHOD.


METHOD convert_xml_to_sap.
    FIELD-SYMBOLS: <f_xml_string> TYPE any,
                   <f_data>       TYPE any.

    DATA lo_exception             TYPE REF TO cx_xslt_exception.
  "  DATA lo_error                 TYPE REF TO cx_xslt_runtime_error.

    CREATE DATA re_data_reference TYPE (im_xml_structure).
    ASSIGN re_data_reference->* TO <f_data>.

    IF im_xml_xstring IS INITIAL AND
       im_xml_string IS INITIAL.
      RETURN.
    ENDIF.

    IF im_xml_xstring IS NOT INITIAL.
      ASSIGN im_xml_xstring TO <f_xml_string>.
    ELSE.
      ASSIGN im_xml_string TO <f_xml_string>.
    ENDIF.

    CREATE DATA re_data_reference TYPE (im_xml_structure).
    ASSIGN re_data_reference->* TO <f_data>.
    TRY.
        CALL TRANSFORMATION (im_xml_transformation)
                SOURCE XML <f_xml_string>
                RESULT     response = <f_data>.
      CATCH CX_XSLT_RUNTIME_ERROR.
        " cx_xslt_exception INTO lo_exception.
       " lo_error ?= lo_exception.
    ENDTRY.


  ENDMETHOD.


METHOD create_xml_document_by_string.
     ex_o_xml            = cl_ixml=>create( ).
     ex_o_stream_factory = ex_o_xml->create_stream_factory( ).
     ex_o_document       = ex_o_xml->create_document( ).

     IF im_xml_xstring IS NOT INITIAL.
       ex_o_istream = ex_o_stream_factory->create_istream_xstring( im_xml_xstring ).

       ex_o_parser = ex_o_xml->create_parser(
                                document       = ex_o_document
                                stream_factory = ex_o_stream_factory
                                istream        = ex_o_istream ).


     ELSE.
       ex_o_istream = ex_o_stream_factory->create_istream_string( im_xml_string  ).
       ex_o_parser = ex_o_xml->create_parser(
                                document       = ex_o_document
                                stream_factory = ex_o_stream_factory
                                istream        = ex_o_istream ).
     ENDIF.

     IF ex_o_parser->parse( ) <> 0.
       ex_t_errors = check_xml_by_parser( ex_o_parser ).
     ENDIF.
   ENDMETHOD.


METHOD encode_string_to_xstring.
    CALL TRANSFORMATION epic_xslt_encode_str2xstr
       SOURCE XML im_xml_string
       RESULT XML re_xml_xstring
       PARAMETERS encoding = im_encoding_charset .
  ENDMETHOD.


METHOD get_element_value.
    DATA: l_field_string TYPE string.

    zcl_bank_data_mapping_engine=>create_xml_document_by_string(
             EXPORTING
               im_xml_string       = im_xml_string
               im_xml_xstring      = im_xml_xstring
             IMPORTING
               ex_o_document       = DATA(lo_document)
*               ex_o_stream_factory = DATA(lo_stream_factory)
*               ex_o_xml            = DATA(lo_xml)
*               ex_o_parser         = DATA(lo_paser)
*               ex_o_istream        = DATA(lo_istream)
               ex_t_errors         = DATA(lt_xml_error) ).
    IF lt_xml_error IS NOT INITIAL.
*      不应该出现错误
*      RETURN.
      ex_t_return_errors = convert_xml_error_to_bapiret( lt_xml_error ).
      RETURN.
    ENDIF.

*    LOOP AT im_t_fieldname INTO DATA(l_fieldname).
*     APPEND VALUE #( name = l_fieldname-name
*                     data = lo_document->find_from_name_ns( l_fieldname-name )->get_value( ) )
*                  TO ex_t_element_values.
*    ENDLOOP.

    DATA(lo_iterator) = lo_document->create_iterator( ).
    DATA(lo_node) = lo_iterator->get_next( ).
    IF lo_node IS NOT BOUND.
      RETURN.
    ENDIF.


    WHILE lo_node IS BOUND.
      data(l_name) = lo_node->get_name( ).
      CASE lo_node->get_type( ).
        WHEN if_ixml_node=>co_node_element.
          READ TABLE im_t_fieldname INTO DATA(ls_fieldname)
                 WITH KEY name = lo_node->get_name( ).
          IF sy-subrc = 0.
            APPEND VALUE #( name = ls_fieldname-name
                            data = lo_node->get_value( ) )
                         TO ex_t_element_values.
          ENDIF.
*        WHEN if_ixml_node=>co_node_text OR
*              if_ixml_node=>co_node_cdata_section.
      ENDCASE.

      FREE lo_node.
      lo_node = lo_iterator->get_next( ).
    ENDWHILE.
  ENDMETHOD.


METHOD reset_element_value.
    DATA: l_xml_string  TYPE string,
          l_xml_xstring TYPE xstring.

    zcl_bank_data_mapping_engine=>create_xml_document_by_string(
             EXPORTING
               im_xml_string       = ch_xml_string
               im_xml_xstring      = ch_xml_xstring
             IMPORTING
               ex_o_document       = DATA(lo_document)
               ex_o_stream_factory = DATA(lo_stream_factory)
               ex_o_xml            = DATA(lo_xml)
               ex_o_parser         = DATA(lo_paser)
               ex_o_istream        = DATA(lo_istream)
               ex_t_errors         = DATA(lt_xml_error) ).

    IF lt_xml_error IS NOT INITIAL.
*      不应该出现错误
*      RETURN.
      et_return_errors = convert_xml_error_to_bapiret( lt_xml_error ).
      RETURN.
    ENDIF.

*仅支持单个节点的替换
*如果有相同层级的重复节点，CH_XML_STRING和CH_XML_XSTRING需要传入父节点，不能传入整个XML
*例如下面的，应该按照每一个item传入进行替换
*   <body>
*       <item>
*            <order>123456</order>
*            <material>BK00001</material>
*            <quantity>123</quantity>
*       </item>
*       <item>
*            <order>88877711</order>
*            <material>MN00002</material>
*            <quantity>10</quantity>
*       </item>
*   </body>
    LOOP AT im_t_element_values INTO DATA(ls_element_value).
      lo_document->find_from_name_ns( ls_element_value-name )->set_value( ls_element_value-data ).
    ENDLOOP.

    lt_xml_error = zcl_bank_data_mapping_engine=>check_xml_by_parser( lo_paser ).
    IF lt_xml_error IS NOT INITIAL.
*      不应该出现错误
      et_return_errors = convert_xml_error_to_bapiret( lt_xml_error ).
      RETURN.
    ENDIF.

    IF ch_xml_string IS NOT INITIAL.
      lo_xml->create_renderer(
                      ostream  = lo_stream_factory->create_ostream_cstring( l_xml_string )
                      document = lo_document
                                             )->render( ).
      ch_xml_string = l_xml_string.
    ENDIF.

    IF ch_xml_xstring IS NOT INITIAL.
      lo_xml->create_renderer(
                  ostream  = lo_stream_factory->create_ostream_xstring( l_xml_xstring )
                  document = lo_document
                                         )->render( ).
      ch_xml_xstring = l_xml_xstring.
    ENDIF.
  ENDMETHOD.


METHOD reset_element_value_from_xml.
    zcl_bank_data_mapping_engine=>get_element_value(
             EXPORTING
               im_xml_string        = im_xml_string_source
               im_xml_xstring       = im_xml_xstring_source
               im_t_fieldname       = im_t_fieldname
             IMPORTING
               ex_t_return_errors   = ex_t_return_errors
               ex_t_element_values  = DATA(lt_source_element_values) ).
    IF ex_t_return_errors IS NOT INITIAL.
      RETURN.
    ENDIF.

    zcl_bank_data_mapping_engine=>reset_element_value(
                EXPORTING
                  im_t_element_values  = lt_source_element_values
                IMPORTING
                  et_return_errors     = ex_t_return_errors
                CHANGING
                  ch_xml_xstring       = ch_xml_xstring_target
                  ch_xml_string        = ch_xml_string_target ).

  ENDMETHOD.


METHOD sap_to_dmee_file.
    SELECT SINGLE xml_tree INTO @DATA(l_xml_format)
           FROM dmee_tree
           WHERE tree_type = @im_tree_type
           AND   tree_id = @im_tree_id.
    IF sy-subrc <> 0.
*     it should not happend at this point
*      remove the error by testing
      MESSAGE e076(ztr_bank_application)
              WITH im_tree_type
                   im_tree_id.
    ENDIF.

    IF l_xml_format = yes.
      zcl_bank_data_mapping_engine=>convert_to_dmee_xml_file(
                EXPORTING
                    im_tree_type     = im_tree_type
                    im_tree_id       = im_tree_id
                    im_sap_data      = im_sap_data
                    im_encoding      = im_encoding
                 IMPORTING
                    ex_cfile         = ex_cfile
                    ex_xfile         = ex_xfile
                    et_return_errors = et_return_errors ).
    ELSE.
*      目前银企直连没有使用这个模式
      zcl_bank_data_mapping_engine=>convert_to_dmee_plaintext_file(
                EXPORTING
                    im_tree_type    = im_tree_type
                    im_tree_id      = im_tree_id
                    im_sap_data     = im_sap_data
                 IMPORTING
                    ex_cfile        = ex_cfile ).
    ENDIF.



  ENDMETHOD.


METHOD sap_to_dmee_xml.
    DATA: l_charset TYPE string.

    zcl_bank_data_mapping_engine=>create_xml_document_by_string(
             EXPORTING
               im_xml_string       = zcl_bank_data_mapping_engine=>convert_to_dmee_xml(
                                                                      im_tree_id = im_tree_id
                                                                      im_tree_type = im_tree_type
                                                                      im_sap_data = im_sap_data )
             IMPORTING
               ex_o_document       = DATA(lo_document)
               ex_o_stream_factory = DATA(lo_stream_factory)
               ex_o_xml            = DATA(lo_xml)
               ex_o_istream = DATA(lo_istream)
               ex_t_errors         = ex_t_errors ).
    IF ex_t_errors IS NOT INITIAL.
*      不应该出现错误
*      如果有错误可能是DMEE配置有问题
*      应该通过测试避免发生这个错误
      RETURN.
    ENDIF.

    lo_xml->create_renderer(
                ostream = lo_stream_factory->create_ostream_cstring( ex_xml_string )
                document = lo_document
                                       )->render( ).

    IF im_encoding IS NOT INITIAL.
      l_charset = im_encoding.
    ELSE.
      l_charset = lo_document->get_encoding( )->get_character_set( ).
    ENDIF.

    ex_xml_xstring = encode_string_to_xstring(
                          im_encoding_charset = l_charset
                          im_xml_string = ex_xml_string ).

  ENDMETHOD.


METHOD SET_ELEMENT_ATTRIBUTE_VALUE.
    DATA: l_xml_string  TYPE string,
          l_xml_xstring TYPE xstring.

    zcl_bank_data_mapping_engine=>create_xml_document_by_string(
             EXPORTING
               im_xml_string       = ch_xml_string
               im_xml_xstring      = ch_xml_xstring
             IMPORTING
               ex_o_document       = DATA(lo_document)
               ex_o_stream_factory = DATA(lo_stream_factory)
               ex_o_xml            = DATA(lo_xml)
               ex_o_parser         = DATA(lo_paser)
               ex_o_istream        = DATA(lo_istream)
               ex_t_errors         = DATA(lt_xml_error) ).

    IF lt_xml_error IS NOT INITIAL.
*      不应该出现错误
*      RETURN.
      et_return_errors = convert_xml_error_to_bapiret( lt_xml_error ).
      RETURN.
    ENDIF.

    lo_document->find_from_name_ns( im_xml_element )->set_attribute(
                                                              name = im_attribute_name
                                                              value = im_attribute_value ).

    lt_xml_error = zcl_bank_data_mapping_engine=>check_xml_by_parser( lo_paser ).
    IF lt_xml_error IS NOT INITIAL.
*      不应该出现错误
      et_return_errors = convert_xml_error_to_bapiret( lt_xml_error ).
      RETURN.
    ENDIF.

    IF ch_xml_string IS NOT INITIAL.
      lo_xml->create_renderer(
                      ostream  = lo_stream_factory->create_ostream_cstring( l_xml_string )
                      document = lo_document
                                             )->render( ).
      ch_xml_string = l_xml_string.
    ENDIF.

    IF ch_xml_xstring IS NOT INITIAL.
      lo_xml->create_renderer(
                  ostream  = lo_stream_factory->create_ostream_xstring( l_xml_xstring )
                  document = lo_document
                                         )->render( ).
      ch_xml_xstring = l_xml_xstring.
    ENDIF.
  ENDMETHOD.


METHOD set_element_attribute_values.
    DATA: l_xml_string  TYPE string,
          l_xml_xstring TYPE xstring.

    zcl_bank_data_mapping_engine=>create_xml_document_by_string(
             EXPORTING
               im_xml_string       = ch_xml_string
               im_xml_xstring      = ch_xml_xstring
             IMPORTING
               ex_o_document       = DATA(lo_document)
               ex_o_stream_factory = DATA(lo_stream_factory)
               ex_o_xml            = DATA(lo_xml)
               ex_o_parser         = DATA(lo_paser)
               ex_o_istream        = DATA(lo_istream)
               ex_t_errors         = DATA(lt_xml_error) ).

    IF lt_xml_error IS NOT INITIAL.
*      不应该出现错误
*      RETURN.
      et_return_errors = convert_xml_error_to_bapiret( lt_xml_error ).
      RETURN.
    ENDIF.

    LOOP AT im_t_attribute_values INTO DATA(ls_attribute).
      lo_document->find_from_name_ns( ls_attribute-element_name )->set_attribute(
                                                                name = ls_attribute-attribute_name
                                                                value = ls_attribute-value ).
    ENDLOOP.

    lt_xml_error = zcl_bank_data_mapping_engine=>check_xml_by_parser( lo_paser ).
    IF lt_xml_error IS NOT INITIAL.
*      不应该出现错误
      et_return_errors = convert_xml_error_to_bapiret( lt_xml_error ).
      RETURN.
    ENDIF.

    IF ch_xml_string IS NOT INITIAL.
      lo_xml->create_renderer(
                      ostream  = lo_stream_factory->create_ostream_cstring( l_xml_string )
                      document = lo_document
                                             )->render( ).
      ch_xml_string = l_xml_string.
    ENDIF.

    IF ch_xml_xstring IS NOT INITIAL.
      lo_xml->create_renderer(
                  ostream  = lo_stream_factory->create_ostream_xstring( l_xml_xstring )
                  document = lo_document
                                         )->render( ).
      ch_xml_xstring = l_xml_xstring.
    ENDIF.
  ENDMETHOD.


method SET_XML_STANDALONE.
    DATA: l_xml_string  TYPE string,
          l_xml_xstring TYPE xstring.

    zcl_bank_data_mapping_engine=>create_xml_document_by_string(
             EXPORTING
               im_xml_string       = ch_xml_cstring
               im_xml_xstring      = ch_xml_xstring
             IMPORTING
               ex_o_document       = DATA(lo_document)
               ex_o_stream_factory = DATA(lo_stream_factory)
               ex_o_xml            = DATA(lo_xml)
               ex_o_parser         = DATA(lo_paser)
               ex_o_istream        = DATA(lo_istream)
               ex_t_errors         = DATA(lt_xml_error) ).

    IF lt_xml_error IS NOT INITIAL.
*      不应该出现错误
      et_return_errors = convert_xml_error_to_bapiret( lt_xml_error ).
      RETURN.
    ENDIF.

    lo_document->set_standalone( STANDALONE = 'X' ).

    IF ch_xml_cstring IS NOT INITIAL.
      lo_xml->create_renderer(
                      ostream  = lo_stream_factory->create_ostream_cstring( l_xml_string )
                      document = lo_document
                                             )->render( ).
      ch_xml_cstring = l_xml_string.
    ENDIF.

    IF ch_xml_xstring IS NOT INITIAL.
      lo_xml->create_renderer(
                  ostream  = lo_stream_factory->create_ostream_xstring( l_xml_xstring )
                  document = lo_document
                                         )->render( ).
      ch_xml_xstring = l_xml_xstring.
    ENDIF.

  endmethod.
ENDCLASS.
