class ZCL_BANK_FUNCTION_ACCBALANCE definition
  public
  inheriting from ZCL_ABSTRACT_BANK_FUNCTION
  create public .

public section.
protected section.

  methods PROCESSING_RESPONSE_BY_DBTABLE
    importing
      !IM_DATA_DB_TABLE type TABNAME
      !IM_DETAIL_RESPONSE_COMPONENT type CLIKE
      !IM_STATUSCODE_COMPONNET type CLIKE
      !IM_STATUSTEXT_COMPONENT type CLIKE
      !IM_DB_ACCOUNT_NUMBER_FIELD type CLIKE
      !IM_BANK_ENTRY_ACCNUMBER_FIELD type CLIKE .

  methods CONVERT_DATA_TO_DMEE_TYPE
    redefinition .
private section.
ENDCLASS.



CLASS ZCL_BANK_FUNCTION_ACCBALANCE IMPLEMENTATION.


METHOD convert_data_to_dmee_type.
    general_acc_dmee_convert.
  ENDMETHOD.


METHOD processing_response_by_dbtable.
    INCLUDE ztr_bank_acc_generalquery_res.
  ENDMETHOD.
ENDCLASS.
