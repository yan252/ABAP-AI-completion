FUNCTION ZFM_TR_LOCK_BANK.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     REFERENCE(IM_BANK_IND) TYPE  ZTR_BANK_INDICATOR
*"  EXCEPTIONS
*"      FOREIGN_LOCK
*"      SYSTEM_FAILURE
*"--------------------------------------------------------------------
READ TABLE gt_lock_bank INTO DATA(ls_bank)
       WITH KEY bank_ind = im_bank_ind.
  IF sy-subrc = 0.
*    被当前SESSION锁定,不再执行锁定
    RETURN.
  ENDIF.

  APPEND VALUE #( bank_ind = im_bank_ind ) TO gt_lock_bank.

CALL FUNCTION 'ENQUEUE_EZTRS_BANK_LOCK'
 EXPORTING
   MODE_ZTRS_BANK_LOCK       = 'E'
   MANDT                     = SY-MANDT
   BANK_IND                  = im_bank_ind
   X_BANK_IND                = ' '
   _SCOPE                    = '2'
   _WAIT                     = ' '
   _COLLECT                  = ' '
 EXCEPTIONS
   FOREIGN_LOCK              = 1
   SYSTEM_FAILURE            = 2
   OTHERS                    = 3.
  CASE sy-subrc.
    WHEN 0.
      RETURN.
    WHEN 1.
      DELETE gt_lock_bank
             WHERE bank_ind = im_bank_ind.
      MESSAGE id sy-msgid
              type sy-msgty
              number sy-msgno
              with sy-msgv1
                   sy-msgv2
                   sy-msgv3
                   sy-msgv4
              RAISING foreign_lock.
    WHEN 2.
      DELETE gt_lock_bank
             WHERE bank_ind = im_bank_ind.
      MESSAGE id sy-msgid
              type sy-msgty
              number sy-msgno
              with sy-msgv1
                   sy-msgv2
                   sy-msgv3
                   sy-msgv4
              RAISING system_failure.
  ENDCASE.





ENDFUNCTION.
