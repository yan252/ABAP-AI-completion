class ZCL_TR_3023_GUI definition
  public
  final
  create public .

public section.

  class-methods DEMO_METHOD
    importing
      !IV_WAERS type WAERS optional
      !IT_DATA type ISSR_ALSMEX_TABLINE
    exporting
      !ET_DATA type ANY TABLE
      !ET_MSG type ZTRT_ZJMSG
      !ET_CDATA type ISSR_ALSMEX_TABLINE
    exceptions
      ERR .
  class-methods DELE_QUOT_METHOD
    importing
      !IV_WAERS type WAERS optional
      value(IT_DATA) type ISSR_ALSMEX_TABLINE
    exporting
      !ET_CDATA type ISSR_ALSMEX_TABLINE
      !ET_DATA type ANY TABLE
      !ET_MSG type ZTRT_ZJMSG
    exceptions
      ERR .
protected section.
private section.
ENDCLASS.



CLASS ZCL_TR_3023_GUI IMPLEMENTATION.


METHOD dele_quot_method.
    DATA cv_mark TYPE char01 VALUE '"'.
    DATA fix_col TYPE kcd_ex_col_n.

    LOOP AT it_data ASSIGNING FIELD-SYMBOL(<fs_data>).
      DATA(indx) = sy-tabix.
      IF <fs_data>-value(1) = cv_mark.
        SHIFT <fs_data>-value BY 1 PLACES."去除
        IF  <fs_data>-value = space."只有占位符，则此单元格为多出的单元格
          "连续2个占位符的时候需要保留一个空单元格
          READ TABLE it_data INTO DATA(ls_data) INDEX indx + 1.
          IF sy-subrc = 0 AND ls_data-value(1) = cv_mark.
            DELETE it_data INDEX indx + 1.
            <fs_data>-col =  <fs_data>-col - fix_col.
            fix_col = fix_col + 1.
          ELSE.
            fix_col = fix_col + 1.
            DELETE it_data INDEX indx.
          ENDIF.
          CONTINUE.
        ENDIF.
      ENDIF.
      <fs_data>-col =  <fs_data>-col - fix_col.
      AT END OF row.
        CLEAR fix_col.
      ENDAT.
    ENDLOOP.
    et_cdata = it_data.


  ENDMETHOD.


method DEMO_METHOD.
  endmethod.
ENDCLASS.
