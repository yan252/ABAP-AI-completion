class ZCL_TR_3020_GUI definition
  public
  final
  create public .

public section.

  class-methods CRT_AGN_BY_WITEM
    importing
      !IV_BUKRS type BUKRS
      !IT_W_ITEM type ZTRT_3018_02
      !IV_SAVE type BOOLEAN optional
      !IV_ZMPLV type ZTR_MPLV optional
    exporting
      !ET_ASN type ZTRT_AMT_AGN
    exceptions
      ERR .
  class-methods CRT_AGN_BY_WITEM_10
    importing
      !IV_BUKRS type BUKRS
      !IT_W_ITEM type ZTRT_3018_02
      !IV_SAVE type BOOLEAN optional
      !IV_ZMPLV type ZTR_MPLV optional
    exporting
      !ET_ASN type ZTRT_AMT_AGN
    exceptions
      ERR .
  class-methods CRT_AGN_BY_WITEM_20
    importing
      !IV_BUKRS type BUKRS
      !IT_W_ITEM type ZTRT_3018_02
      !IV_SAVE type BOOLEAN optional
      !IV_ZMPLV type ZTR_MPLV optional
    exporting
      !ET_ASN type ZTRT_AMT_AGN
    exceptions
      ERR .
  class-methods CRT_AGN_BY_WITEM_21
    importing
      !IV_BUKRS type BUKRS
      !IT_W_ITEM type ZTRT_3018_02
      !IV_SAVE type BOOLEAN optional
      !IV_ZMPLV type ZTR_MPLV optional
    exporting
      !ET_ASN type ZTRT_AMT_AGN
    exceptions
      ERR .
  class-methods CRT_AGN_BY_WITEM_30
    importing
      !IV_BUKRS type BUKRS
      !IT_W_ITEM type ZTRT_3018_02
      !IV_SAVE type BOOLEAN optional
      !IV_ZMPLV type ZTR_MPLV optional
    exporting
      !ET_ASN type ZTRT_AMT_AGN
    exceptions
      ERR .
  class-methods CHG_AGN_BY_WITEM
    importing
      !IV_BUKRS type BUKRS
      !IT_W_ITEM type ZTRT_3018_02
      !IT_D_ITEM type ZTRT_3018_02 optional
      !IV_ZMPLV type ZTR_MPLV optional
      !IV_SAVE type BOOLEAN optional
    exporting
      !ET_ASN type ZTRT_AMT_AGN
    exceptions
      ERR .
  class-methods CHG_AGN_BY_WITEM_10
    importing
      !IV_BUKRS type BUKRS
      !IT_W_ITEM type ZTRT_3018_02
      !IT_D_ITEM type ZTRT_3018_02 optional
      !IV_ZMPLV type ZTR_MPLV optional
      !IV_SAVE type BOOLEAN optional
    exporting
      !ET_ASN type ZTRT_AMT_AGN
    exceptions
      ERR .
  class-methods CHG_AGN_BY_WITEM_21
    importing
      !IV_BUKRS type BUKRS
      !IT_W_ITEM type ZTRT_3018_02
      !IT_D_ITEM type ZTRT_3018_02 optional
      !IV_ZMPLV type ZTR_MPLV optional
      !IV_SAVE type BOOLEAN optional
    exporting
      !ET_ASN type ZTRT_AMT_AGN
    exceptions
      ERR .
  class-methods CHG_AGN_BY_WITEM_20
    importing
      !IV_BUKRS type BUKRS
      !IT_W_ITEM type ZTRT_3018_02
      !IT_D_ITEM type ZTRT_3018_02 optional
      !IV_ZMPLV type ZTR_MPLV optional
      !IV_SAVE type BOOLEAN optional
    exporting
      !ET_ASN type ZTRT_AMT_AGN
    exceptions
      ERR .
  class-methods CHG_AGN_BY_WITEM_30
    importing
      !IV_BUKRS type BUKRS
      !IT_W_ITEM type ZTRT_3018_02
      !IT_D_ITEM type ZTRT_3018_02 optional
      !IV_ZMPLV type ZTR_MPLV optional
      !IV_SAVE type BOOLEAN optional
    exporting
      !ET_ASN type ZTRT_AMT_AGN
    exceptions
      ERR .
  class-methods DEL_AGN_BY_WITEM
    importing
      !IV_BUKRS type BUKRS
      !IT_W_ITEM type ZTRT_3018_02
      !IV_SAVE type BOOLEAN optional
    exporting
      !ET_ASN type ZTRT_AMT_AGN
    exceptions
      ERR .
  class-methods GET_UNAGN_AMT_10
    importing
      !IV_BUKRS type BUKRS
      !IV_GJAHR type GJAHR
      !IV_BELNR type BELNR_D
      !IV_BUZEI type BUZEI
      !IV_BGUID type GUID_32 optional
      !IV_ITEMN type ZTR_ITEMN optional
      !IV_ZMPLV type ZTR_MPLV optional
      !IV_LOCK type BOOLEAN optional
      !IV_JJBILLN type ZTR_JBILLN optional
      !IV_JJITEMN type ZTR_ITEMXH optional
    exporting
      !E_AMT type ANY .
  class-methods GET_UNAGN_AMT_20
    importing
      !IV_BGUID type GUID_32 optional
      !IV_ITEMN type ZTR_ITEMN optional
      !IV_ZMPLV type ZTR_MPLV optional
      !IV_LOCK type BOOLEAN optional
      !IV_JJBILLN type ZTR_JBILLN optional
      !IV_JJITEMN type ZTR_ITEMXH optional
      !IV_ZBELNR1 type ZYFKSQNO
    exporting
      !E_AMT type ANY .
  class-methods GET_UNAGN_AMT_30
    importing
      !IV_BGUID type GUID_32 optional
      !IV_ITEMN type ZTR_ITEMN optional
      !IV_ZMPLV type ZTR_MPLV optional
      !IV_LOCK type BOOLEAN optional
      !IV_BILLN type ZTR_BILLN
      !IV_BITEMN type ZTR_ITEMNO
    exporting
      !E_AMT type ANY .
  class-methods GET_UNAGN_AMT_12
    importing
      !IV_BUKRS type BUKRS
      !IV_GJAHR type GJAHR
      !IV_BELNR type BELNR_D
      !IV_BUZEI type BUZEI
      !IV_BGUID type GUID_32 optional
      !IV_ITEMN type ZTR_ITEMN optional
      !IV_ZMPLV type ZTR_MPLV optional
      !IV_LOCK type BOOLEAN optional
      !IV_JJBILLN type ZTR_JBILLN optional
      !IV_JJITEMN type ZTR_ITEMXH optional
      !IV_ZTR_BPT type ZTR_BPT default '20'
      !IV_ZBELNR1 type ZYFKSQNO
      !IV_SQDXH type ZTR_SQSXH
    exporting
      !E_AMT type ANY .
  class-methods GET_UNAGN_AMT_21
    importing
      !IV_BGUID type GUID_32 optional
      !IV_ITEMN type ZTR_ITEMN optional
      !IV_ZMPLV type ZTR_MPLV optional
      !IV_LOCK type BOOLEAN optional
      !IV_JJBILLN type ZTR_JBILLN optional
      !IV_JJITEMN type ZTR_ITEMXH optional
      !IV_ZBELNR1 type ZYFKSQNO
      !IV_SQDXH type ZTR_SQSXH optional
    exporting
      !E_AMT type ANY .
  class-methods GET_UNAGN_AMT_A0
    importing
      !IV_BUKRS type BUKRS
      !IV_GJAHR type GJAHR
      !IV_BELNR type BELNR_D
      !IV_BUZEI type BUZEI
      !IV_BGUID type GUID_32 optional
      !IV_ITEMN type ZTR_ITEMN optional
      !IV_ZMPLV type ZTR_MPLV optional
      !IV_LOCK type BOOLEAN optional
    exporting
      !E_AMT type ANY .
  class-methods LOCK_AGN
    importing
      !IS_W_ITEM type ZTRT3018_02
    exceptions
      ERR .
  class-methods UNLOCK_AGN
    importing
      !IS_W_ITEM type ZTRT3018_02
    exceptions
      ERR .
  class-methods RELEASE_AGN
    importing
      !IS_W_ITEM type ZTRT3018_02
      !IV_COMMIT type ABAP_BOOL optional
    exporting
      !ET_RLT type ANY TABLE
    exceptions
      ERR .
  class-methods RELEASE_AGN_ZF
    importing
      !IT_W_ITEM type ZTRT_3018_02
      !IV_COMMIT type ABAP_BOOL default ABAP_TRUE
    exceptions
      ERR .
  class-methods GET_MAGN
    importing
      !IT_W_ITEM type ZTRT_3018_02 optional
      !IT_AGN type ZTRT_AMT_AGN optional
    exporting
      !ET_AGN type ZTRT_AMT_AGN .
  class-methods GET_AGN
    importing
      !IT_W_ITEM type ZTRT_3018_02 optional
      !IT_AGN type ZTRT_AMT_AGN optional
    exporting
      !ET_AGN type ZTRT_AMT_AGN .
  class-methods CHECK_FUNDFLOW_AMT_30
    importing
      !IT_W_ITEM type ZTRT_3018_02
    exceptions
      ERR
      WRN .
  class-methods GET_AGN_AMT_BY_MAGN
    importing
      !IV_BUKRS type BUKRS
      !IV_GJAHR type GJAHR optional
      !IV_BELNR type BELNR_D optional
      !IV_BUZEI type BUZEI optional
      !IV_ZBELNR1 type ZYFKSQNO optional
      !IV_SQDXH type ZTR_SQSXH optional
      !IV_ZWKPLV type ZTR_WPLV
      !IV_ZMPLV type ZTR_MPLV
      !IV_SJZFJE type ZTR_SJZFJE
      !IV_RANL type RANLD optional
      !IV_FLOW type ZTR_FUND_FLOW optional
      !IV_SBEWART type SBEWART optional
    exporting
      !EV_JHZFE type ZTR_JHZFE
      !EV_MAGN type ZTR_SJZFJE
    exceptions
      ERR
      WRN .
  class-methods CHECK_FUNDFLOW_AMT
    importing
      !IT_W_ITEM type ZTRT_3018_02
    exceptions
      ERR
      WRN .
  class-methods CRT_AGN_BY_JJITEM_10
    importing
      !IV_BUKRS type BUKRS
      !IT_W_ITEM type ZTRTT3020_02
      !IV_SAVE type BOOLEAN optional
    exporting
      !ET_ASN type ZTRT_AMT_AGN
    exceptions
      ERR .
  class-methods CRT_AGN_BY_JJITEM_21
    importing
      !IV_BUKRS type BUKRS
      !IT_W_ITEM type ZTRTT3020_02
      !IV_SAVE type BOOLEAN optional
    exporting
      !ET_ASN type ZTRT_AMT_AGN
    exceptions
      ERR .
  class-methods CRT_AGN_BY_JJITEM_20
    importing
      !IV_BUKRS type BUKRS
      !IT_W_ITEM type ZTRTT3020_02
      !IV_SAVE type BOOLEAN optional
    exporting
      !ET_ASN type ZTRT_AMT_AGN
    exceptions
      ERR .
  class-methods CHG_AGN_BY_JJITEM_10
    importing
      !IV_BUKRS type BUKRS
      !IT_W_ITEM type ZTRTT3020_02
      !IT_D_ITEM type ZTRTT3020_02 optional
      !IV_SAVE type BOOLEAN optional
    exporting
      !ET_ASN type ZTRT_AMT_AGN
    exceptions
      ERR .
  class-methods CHG_AGN_BY_JJITEM_21
    importing
      !IV_BUKRS type BUKRS
      !IT_W_ITEM type ZTRTT3020_02
      !IT_D_ITEM type ZTRTT3020_02 optional
      !IV_SAVE type BOOLEAN optional
    exporting
      !ET_ASN type ZTRT_AMT_AGN
    exceptions
      ERR .
  class-methods CHG_AGN_BY_JJITEM_20
    importing
      !IV_BUKRS type BUKRS
      !IT_W_ITEM type ZTRTT3020_02
      !IT_D_ITEM type ZTRTT3020_02 optional
      !IV_SAVE type BOOLEAN optional
    exporting
      !ET_ASN type ZTRT_AMT_AGN
    exceptions
      ERR .
  class-methods LOCK_JJAGN
    importing
      !IS_W_ITEM type ZTRT3020_02
    exceptions
      ERR .
  class-methods UNLOCK_JJAGN
    importing
      !IS_W_ITEM type ZTRT3020_02
    exceptions
      ERR .
  class-methods CHG_AGN_BY_JJ_WITEM
    importing
      !IV_BUKRS type BUKRS
      !IT_W_ITEM type ZTRT_3018_02
      !IV_SAVE type BOOLEAN optional
    exporting
      !ET_ASN type ZTRT_AMT_AGN
    exceptions
      ERR .
  class-methods RELEASE_WPLAN
    importing
      !IV_BUKRS type BUKRS
      !IV_ZWKPLV type ZTR_WPLV
    exceptions
      ERR .
  class-methods GET_AMT_CLEAR_10
    importing
      !I_BUKRS type BUKRS
      !I_GJAHR type GJAHR
      !I_BELNR type BELNR_D
      !I_BUZEI type BUZEI
    returning
      value(E_AMT) type WRBTR .
  class-methods RELEASE_WPLAN_DELETE_ZFD
    importing
      !IV_BUKRS type BUKRS
      !IV_ZWKPLV type ZTR_WPLV
      !IV_UPD type CHAR1 default 'X'
    exceptions
      ERR .
  class-methods GET_AMTCONTROL_CONF
    importing
      !IV_BUKRS type BUKRS optional
    returning
      value(ES_3018_03) type ZTRT3018_03 .
protected section.
private section.

  class-data MS_AGN type ZTRV_AMT_AGN .
  class-data:
    mt_03 TYPE TABLE OF ztrt3018_03 .
  class-data MS_CONF03 type ZTRT3018_03 .

  class-methods GET_TOTAL_AGN_AMT
    importing
      !IV_BUKRS type BUKRS
      !IT_AGN type ZTRT_AMT_AGN
    exporting
      !ET_AGN type ZTRT_AMT_AGN .
  class-methods GET_AMT_10
    importing
      !I_BUKRS type BUKRS
      !I_GJAHR type GJAHR
      !I_BELNR type BELNR_D
      !I_BUZEI type BUZEI
    exporting
      !E_AMT type WRBTR .
  class-methods GET_AMT_20
    importing
      !I_ZBELNR1 type ZYFKSQNO
    exporting
      !E_AMT type WRBTR .
  class-methods GET_AMT_30
    importing
      !I_BILLN type ZTR_BILLN
      !I_ITEMN type ZTR_ITEMNO
    exporting
      !E_AMT type WRBTR .
  class-methods GET_AMT_21
    importing
      !I_ZBELNR1 type ZYFKSQNO
      !I_SQDXH type ZTR_SQSXH optional
    exporting
      !E_AMT type WRBTR .
ENDCLASS.



CLASS ZCL_TR_3020_GUI IMPLEMENTATION.


METHOD check_fundflow_amt.

    DATA : ls_03 TYPE ztrs3018_03,
           lt_03 TYPE TABLE OF ztrs3018_03.

    DATA: BEGIN OF ls_agn .
        INCLUDE TYPE ztrv_amt_agn .
    DATA:END OF ls_agn ,
    lt_agn LIKE TABLE OF ls_agn.


    READ TABLE it_w_item INTO DATA(ls_w_item) INDEX 1 .
    IF sy-subrc <>  0  .
      RETURN.
    ELSE.
      SELECT SINGLE waers FROM t001 INTO @DATA(lv_waers) WHERE bukrs = @ls_w_item-bukrs.     "本位币
    ENDIF.

*  获取配置表
    SELECT * FROM ztrt3018_03 INTO CORRESPONDING FIELDS OF TABLE mt_03  WHERE zly = space AND fund_flow ne ''  ORDER BY bukrs zly fund_flow.
    IF sy-subrc <> 0 . RETURN . ENDIF.

*  有关的现金流量表项目
    LOOP AT it_w_item INTO DATA(ls_item) WHERE dflag = space.
      CLEAR ls_03 .
      ls_03-bukrs = ls_item-bukrs.
      CASE ls_item-bcate .
        WHEN  '30'  OR  '31' OR '32'  OR  '33' .
          CONTINUE .   " 预估逻辑不同
        WHEN  OTHERS  .  ls_03-zly = space .
      ENDCASE .
      ls_03-fund_flow = ls_item-fund_flow.
      ls_03-waers = lv_waers .
      COLLECT ls_03 INTO lt_03.
    ENDLOOP.

    IF lt_03 IS INITIAL . RETURN . ELSE. SORT lt_03 BY bukrs zly fund_flow . ENDIF.

*  有关的周资金计划\
    SELECT SINGLE zmplv FROM ztrt3018_01 INTO @DATA(lv_zmplv)
      WHERE bguid = @ls_w_item-bguid .

    IF sy-subrc <> 0 . RAISE err.  ENDIF.  " 不可能

    SELECT  a~bukrs a~fund_flow a~waers a~wrbtr_agn a~bguid a~witemn FROM ztrv_amt_agn  AS a
      INNER JOIN ztrt3018_02 AS b
         ON a~bguid = b~bguid
        AND a~witemn = b~itemn
      INNER JOIN  ztrt3018_01 AS c
         ON b~bguid = c~bguid
        INTO  CORRESPONDING FIELDS OF  TABLE lt_agn
        FOR ALL ENTRIES IN lt_03
      WHERE a~fund_flow = lt_03-fund_flow
        AND a~dflag = space
        AND b~dflag = space
        AND c~dflag = space
        AND ( b~bcate <> '30' AND bcate <> '31' AND  bcate <> '32'  AND bcate <> '33'  )
        AND c~zmplv =   lv_zmplv
        AND c~zjjhbb = '01'
        AND c~bukrs =   ls_w_item-bukrs
        AND c~dflag  =  abap_false.

    DATA(lt_w_item) = it_w_item .

    LOOP AT lt_agn  INTO ls_agn.

      READ TABLE lt_03 ASSIGNING FIELD-SYMBOL(<fs_03>)  WITH KEY bukrs  = ls_agn-bukrs
                                                                  zly   =  space
                                                              fund_flow =  ls_agn-fund_flow BINARY SEARCH .
      IF sy-subrc <> 0 . CONTINUE .  ENDIF.

      READ TABLE lt_w_item INTO ls_w_item WITH KEY bguid = ls_agn-bguid itemn = ls_agn-witemn .
      IF sy-subrc <> 0 .
        CALL METHOD zcl_tr_3019_gui=>cvt_amt
          EXPORTING
            iv_amt      = ls_agn-wrbtr_agn
            iv_from_cur = ls_agn-waers
            iv_to_cur   = <fs_03>-waers
            iv_bukrs    = ls_agn-bukrs
          IMPORTING
            ev_amt      = ls_agn-wrbtr_agn
          EXCEPTIONS
            err         = 1
            OTHERS      = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
        ENDIF.

      ELSE.

        DELETE lt_w_item INDEX sy-tabix.
        CALL METHOD zcl_tr_3019_gui=>cvt_amt
          EXPORTING
            iv_amt      = ls_w_item-jhzfe
            iv_from_cur = ls_w_item-waers
            iv_to_cur   = <fs_03>-waers
            iv_bukrs    = ls_agn-bukrs
          IMPORTING
            ev_amt      = ls_agn-wrbtr_agn
          EXCEPTIONS
            err         = 1
            OTHERS      = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
        ENDIF.


      ENDIF.
      <fs_03>-dmbtr = <fs_03>-dmbtr + ls_agn-wrbtr_agn.

    ENDLOOP.

    LOOP AT lt_w_item INTO ls_w_item .

      READ TABLE lt_03 ASSIGNING <fs_03>  WITH KEY bukrs  = ls_agn-bukrs
                                                    zly   =  space
                                                fund_flow =  ls_agn-fund_flow BINARY SEARCH .
      IF sy-subrc <> 0 . CONTINUE .  ENDIF.

      CALL METHOD zcl_tr_3019_gui=>cvt_amt
        EXPORTING
          iv_amt      = ls_w_item-jhzfe
          iv_from_cur = ls_w_item-waers
          iv_to_cur   = <fs_03>-waers
          iv_bukrs    = ls_agn-bukrs
        IMPORTING
          ev_amt      = ls_w_item-jhzfe
        EXCEPTIONS
          err         = 1
          OTHERS      = 2.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
          WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
      ENDIF.
      <fs_03>-dmbtr = <fs_03>-dmbtr + ls_w_item-jhzfe .
    ENDLOOP.


*  取月资金计划
    SELECT  i~bguid , itemn , bcate , fund_flow ,waers, jhzfe  FROM ztrt3017_02 AS i
      INNER JOIN ztrt3017_01 AS h
     ON  i~bguid = h~bguid
      INTO TABLE @DATA(lt_37)
      FOR ALL ENTRIES IN @lt_03
    WHERE h~zmplv = @lv_zmplv
      AND h~bukrs = @ls_w_item-bukrs
      AND h~zjjhbb = '01'
      AND i~fund_flow = @lt_03-fund_flow
      AND h~dflag = @space
      AND i~dflag = @space
      AND i~bcate <> '30' .
    IF sy-subrc <>  0 .
      MESSAGE s228(ztr01) RAISING err.
    ELSE.
      LOOP AT lt_37 INTO DATA(ls_37) .
        READ TABLE lt_03 ASSIGNING <fs_03>  WITH KEY bukrs  = ls_w_item-bukrs
                                                      zly   =  space
                                                  fund_flow =  ls_37-fund_flow BINARY SEARCH .
        IF sy-subrc <> 0 . CONTINUE .  ENDIF.

        CALL METHOD zcl_tr_3019_gui=>cvt_amt
          EXPORTING
            iv_amt      = ls_37-jhzfe
            iv_from_cur = ls_37-waers
            iv_to_cur   = lv_waers
            iv_bukrs    = ls_w_item-bukrs
          IMPORTING
            ev_amt      = ls_37-jhzfe
          EXCEPTIONS
            err         = 1
            OTHERS      = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
        ENDIF.

        <fs_03>-dmbtr_plan = <fs_03>-dmbtr_plan + ls_37-jhzfe.
      ENDLOOP.
    ENDIF.

    LOOP AT lt_03 INTO ls_03.
      READ TABLE  mt_03 INTO DATA(ms_03) WITH KEY bukrs  = ls_03-bukrs
                                                  zly   =  space
                                              fund_flow =  ls_03-fund_flow BINARY SEARCH .
      IF sy-subrc <> 0 .ms_03-zkzfs = '2' . ENDIF.  " 没有维护就是严格控制

      IF  ms_03-zkzfs =  space. CONTINUE . ENDIF.

      IF ms_03-zkzfs  = '1'.

        DATA(lv_plan_amt) = ls_03-dmbtr_plan * ( 1 + ms_03-zrcz / 100 ) .

        IF lv_plan_amt  < ls_03-dmbtr.
          ls_03-dmbtr = ls_03-dmbtr - lv_plan_amt .
          MESSAGE s227(ztr01) WITH ls_03-waers  ls_03-dmbtr  RAISING err.
        ELSE.
          IF ls_03-dmbtr_plan  < ls_03-dmbtr .
            ls_03-dmbtr = ls_03-dmbtr - ls_03-dmbtr_plan  .
            MESSAGE s774(ztr01) WITH ls_03-waers  ls_03-dmbtr  RAISING wrn.
          ENDIF.
        ENDIF.
      ELSEIF ms_03-zkzfs = '2'.

        IF ls_03-dmbtr_plan  < ls_03-dmbtr .
          ls_03-dmbtr = ls_03-dmbtr - ls_03-dmbtr_plan  .
          MESSAGE s774(ztr01) WITH ls_03-waers  ls_03-dmbtr  RAISING err.
        ENDIF.

      ENDIF.
    ENDLOOP.
  ENDMETHOD.


METHOD check_fundflow_amt_30.

    DATA: ls_03 TYPE ztrs3018_04,
          lt_03 TYPE TABLE OF ztrs3018_04.


    DATA: ls_agn TYPE ztrv_amt_agn,
          lt_agn TYPE TABLE OF ztrv_amt_agn.

    READ TABLE it_w_item INTO DATA(ls_w_item) INDEX 1.
    IF sy-subrc <> 0 .
      RETURN .
    ELSE.
      SELECT SINGLE zmplv FROM ztrt3018_01 INTO @DATA(lv_zmplv) WHERE bguid = @ls_w_item-bguid .
    ENDIF.

*  获取配置表
    SELECT * FROM ztrt3018_03 INTO CORRESPONDING FIELDS OF TABLE mt_03  WHERE zly = '1' ORDER BY bukrs zly fund_flow .

*  有关的现金流量表项目
    LOOP AT it_w_item INTO DATA(ls_item) WHERE dflag = space.
      READ TABLE lt_03 INTO ls_03  WITH KEY bukrs = ls_item-bukrs
                                            billn = ls_item-billn
                                            itemn = ls_item-bilitmn .
      IF sy-subrc = 0 . CONTINUE .ENDIF.

      CLEAR ls_03 .
      ls_03-bukrs = ls_item-bukrs.
      ls_03-fund_flow = ls_item-fund_flow .
      ls_03-billn = ls_item-billn.
      ls_03-itemn = ls_item-bilitmn .
      SELECT SINGLE waers  zygspwrbtr FROM ztrt0031 INTO ( ls_03-waers  , ls_03-dmbtr_plan ) WHERE billn = ls_item-billn
                                                                                               AND itemn = ls_item-bilitmn.
      IF sy-subrc NE 0.
        CONTINUE.
      ENDIF.
      APPEND ls_03 TO lt_03.

    ENDLOOP.

    IF lt_03 IS INITIAL . RETURN . ELSE. SORT lt_03 BY bukrs billn itemn . ENDIF.

    SELECT bguid FROM ztrt3018_01 INTO @DATA(lv_bguid)
     WHERE zmplv    = @lv_zmplv
       AND zjjhbb   = '01'
       AND bukrs    = @ls_w_item-bukrs
       AND dflag    = @abap_false.

      SELECT a~bukrs    a~waers    a~wrbtr_agn     a~bguid    a~witemn    FROM ztrv_amt_agn  AS a
        INNER JOIN ztrt3018_02 AS b
           ON a~bguid = b~bguid
          AND a~witemn = b~itemn
          APPENDING CORRESPONDING FIELDS OF  TABLE lt_agn
          FOR ALL ENTRIES IN lt_03
       WHERE a~bguid =  lv_bguid
         AND a~dflag = space
         AND b~dflag = space
         AND b~billn = lt_03-billn
         AND b~bilitmn = lt_03-itemn
         AND ( b~bcate = '31' OR b~bcate = '32' OR b~bcate = '33' ) .

    ENDSELECT .

    DATA(lt_w_item) = it_w_item .

    LOOP AT lt_agn  INTO ls_agn.


      READ TABLE lt_03 ASSIGNING FIELD-SYMBOL(<fs_03>)  WITH KEY bukrs  = ls_agn-bukrs
                                                                 billn = ls_item-billn
                                                                 itemn = ls_item-bilitmn BINARY SEARCH.
      IF sy-subrc <> 0 . CONTINUE .  ENDIF.

      READ TABLE lt_w_item INTO ls_w_item WITH KEY bguid = ls_agn-bguid itemn = ls_agn-witemn .
      IF sy-subrc <> 0 .
        CALL METHOD zcl_tr_3019_gui=>cvt_amt
          EXPORTING
            iv_amt      = ls_agn-wrbtr_agn
            iv_from_cur = ls_agn-waers
            iv_to_cur   = <fs_03>-waers
            iv_bukrs    = ls_agn-bukrs
          IMPORTING
            ev_amt      = ls_agn-wrbtr_agn
          EXCEPTIONS
            err         = 1
            OTHERS      = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
        ENDIF.

      ELSE.

        DELETE lt_w_item INDEX sy-tabix.
        CALL METHOD zcl_tr_3019_gui=>cvt_amt
          EXPORTING
            iv_amt      = ls_w_item-jhzfe
            iv_from_cur = ls_w_item-waers
            iv_to_cur   = <fs_03>-waers
            iv_bukrs    = ls_agn-bukrs
          IMPORTING
            ev_amt      = ls_agn-wrbtr_agn
          EXCEPTIONS
            err         = 1
            OTHERS      = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
        ENDIF.


      ENDIF.
      <fs_03>-dmbtr = <fs_03>-dmbtr + ls_agn-wrbtr_agn.
    ENDLOOP.

    LOOP AT lt_w_item INTO ls_w_item .

      READ TABLE lt_03 ASSIGNING <fs_03>  WITH KEY bukrs = ls_w_item-bukrs
                                                   billn = ls_w_item-billn
                                                   itemn = ls_w_item-bilitmn BINARY SEARCH.
      IF sy-subrc <> 0 . CONTINUE .  ENDIF.

      CALL METHOD zcl_tr_3019_gui=>cvt_amt
        EXPORTING
          iv_amt      = ls_w_item-jhzfe
          iv_from_cur = ls_w_item-waers
          iv_to_cur   = <fs_03>-waers
          iv_bukrs    = ls_w_item-bukrs
        IMPORTING
          ev_amt      = ls_w_item-jhzfe
        EXCEPTIONS
          err         = 1
          OTHERS      = 2.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
          WITH  <fs_03>-waers sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
      ENDIF.
      <fs_03>-dmbtr = <fs_03>-dmbtr + ls_w_item-jhzfe .
    ENDLOOP.


    LOOP AT lt_03 INTO ls_03.
      READ TABLE  mt_03 INTO DATA(ms_03) WITH KEY bukrs  = ls_03-bukrs
                                                   zly   =  '1'
                                               fund_flow =  ls_03-fund_flow BINARY SEARCH .

      IF sy-subrc <> 0 .ms_03-zkzfs = '2' . ENDIF.  " 没有维护就是严格控制

      IF  ms_03-zkzfs =  space. CONTINUE . ENDIF.

      IF ms_03-zkzfs  = '1'.

        DATA(lv_plan_amt) = ls_03-dmbtr_plan * ( 1 + ms_03-zrcz / 100 ) .

        IF lv_plan_amt  < ls_03-dmbtr.
          ls_03-dmbtr = ls_03-dmbtr - lv_plan_amt .
          MESSAGE s227(ztr01) WITH ls_03-waers  ls_03-dmbtr  RAISING err.
        ELSE.
          IF ls_03-dmbtr_plan  < ls_03-dmbtr .
            ls_03-dmbtr = ls_03-dmbtr - ls_03-dmbtr_plan  .
            MESSAGE s774(ztr01) WITH ls_03-waers  ls_03-dmbtr  RAISING wrn.
          ENDIF.
        ENDIF.
      ELSEIF ms_03-zkzfs = '2'.

        IF ls_03-dmbtr_plan  < ls_03-dmbtr .
          ls_03-dmbtr = ls_03-dmbtr - ls_03-dmbtr_plan  .
          MESSAGE s774(ztr01) WITH ls_03-waers  ls_03-dmbtr  RAISING err.
        ENDIF.

      ENDIF.


    ENDLOOP.
  ENDMETHOD.


METHOD chg_agn_by_jjitem_10.

    DATA : lt_w_item TYPE ztrtt3020_02.
* DEL
    IF it_d_item IS NOT INITIAL .
      SELECT * FROM ztrv_amt_agn INTO TABLE  @DATA(lt_del)
        FOR ALL ENTRIES IN @it_d_item
        WHERE jjbilln = @it_d_item-billn
          AND jjitemn = @it_d_item-itemn
          AND dflag = @abap_false.
      IF sy-subrc = 0 .
        SORT lt_del BY db_key .
      ENDIF.
    ENDIF.

    LOOP AT it_w_item INTO DATA(ls_w_item) WHERE zzfje > 0 .
      IF sy-tabix = 1 .
        DATA(lt_item_col) = VALUE  ztrt_amt_agn(  ( bukrs = ls_w_item-bukrs
                                                    gjahr = ls_w_item-gjahr
                                                    belnr = ls_w_item-belnr
                                                    buzei = ls_w_item-buzei )  ) .
      ELSE.
        READ TABLE lt_item_col INTO DATA(ls_item_col) WITH KEY bukrs = ls_w_item-bukrs
                                                               gjahr = ls_w_item-gjahr
                                                               belnr = ls_w_item-belnr
                                                               buzei = ls_w_item-buzei .
        IF sy-subrc <> 0 .

          lt_item_col = VALUE #( BASE lt_item_col (  bukrs = ls_w_item-bukrs
                                                     gjahr = ls_w_item-gjahr
                                                     belnr = ls_w_item-belnr
                                                     buzei = ls_w_item-buzei ) ).
        ENDIF.
      ENDIF.
    ENDLOOP.

    CALL METHOD zcl_tr_3020_gui=>get_agn
      EXPORTING
        it_agn = lt_item_col
      IMPORTING
        et_agn = DATA(lt_agn_db_all).


    MOVE it_w_item TO lt_w_item  .
    SORT lt_w_item BY billn itemn. .

    LOOP AT lt_item_col  INTO ls_item_col .

      CALL METHOD zcl_tr_3020_gui=>get_amt_10
        EXPORTING
          i_bukrs = iv_bukrs
          i_gjahr = ls_item_col-gjahr
          i_belnr = ls_item_col-belnr
          i_buzei = ls_item_col-buzei
        IMPORTING
          e_amt   = DATA(lv_wrbtr).

      LOOP AT lt_agn_db_all INTO DATA(ls_agn_db) WHERE bukrs = iv_bukrs
                                                    AND belnr = ls_item_col-belnr
                                                    AND gjahr = ls_item_col-gjahr
                                                    AND buzei =  ls_item_col-buzei .
        READ TABLE lt_w_item INTO ls_w_item WITH KEY billn = ls_agn_db-jjbilln
                                                     itemn = ls_agn_db-jjitemn .
*         binary search .
        IF sy-subrc <> 0 .
          READ TABLE lt_del INTO DATA(ls_del) WITH KEY db_key = ls_agn_db-db_key BINARY SEARCH .
          IF sy-subrc <> 0 .
            lv_wrbtr = lv_wrbtr - ls_agn_db-wrbtr_agn.
          ENDIF.
        ENDIF.
      ENDLOOP.


      LOOP AT lt_w_item INTO ls_w_item WHERE bukrs = iv_bukrs
                                          AND belnr = ls_item_col-belnr
                                          AND gjahr = ls_item_col-gjahr
                                          AND buzei =  ls_item_col-buzei .
        lv_wrbtr = lv_wrbtr - ls_w_item-jhzfe .
      ENDLOOP.

      IF lv_wrbtr < 0 .
        MESSAGE e095(ztr01) WITH  ls_w_item-gjahr ls_w_item-belnr ls_w_item-buzei  RAISING  err..
      ENDIF.

      LOOP AT lt_w_item INTO  ls_w_item WHERE bukrs = iv_bukrs
                                           AND belnr = ls_item_col-belnr
                                           AND gjahr = ls_item_col-gjahr
                                           AND buzei =  ls_item_col-buzei .

        READ TABLE lt_agn_db_all INTO ls_agn_db WITH KEY jjbilln = ls_w_item-billn
                                                         jjitemn = ls_w_item-itemn .

        IF sy-subrc <>  0 .

          et_asn = VALUE #( BASE et_asn (
                db_key      =  /bobf/cl_frw_factory=>get_new_key( )
                bukrs       =  iv_bukrs
                gjahr       =  ls_w_item-gjahr
                belnr       =  ls_w_item-belnr
                buzei       =  ls_w_item-buzei
                waers       =  ls_w_item-waers
                wrbtr_agn   =  ls_w_item-jhzfe
                jjbilln     =  ls_w_item-billn
                jjitemn     =  ls_w_item-itemn
                fund_flow   =  ls_w_item-fund_flow
                aedat       = sy-datum
                aezet       = sy-uzeit
                aenam       = sy-uname  ) ) .
        ELSE.
          ls_agn_db-wrbtr_agn = ls_w_item-jhzfe .
          ls_agn_db-fund_flow   =  ls_w_item-fund_flow .
          ls_agn_db-aedat = sy-datum .
          ls_agn_db-aezet = sy-uzeit .
          ls_agn_db-aenam = sy-uname .
          APPEND ls_agn_db TO et_asn .
        ENDIF.
      ENDLOOP.
    ENDLOOP.

    LOOP AT lt_del INTO ls_del .
      ls_del-dflag = abap_true.
      APPEND ls_del TO et_asn .
    ENDLOOP.

  ENDMETHOD.


METHOD chg_agn_by_jjitem_20.

    DATA : lt_w_item TYPE ztrtt3020_02.

* DEL
    IF it_d_item IS NOT INITIAL .
      SELECT * FROM ztrv_amt_agn INTO TABLE  @DATA(lt_del)
        FOR ALL ENTRIES IN @it_d_item
        WHERE jjbilln = @it_d_item-billn
          AND jjitemn = @it_d_item-itemn
          AND dflag = @abap_false.
      IF sy-subrc = 0 .
        SORT lt_del BY db_key .
      ENDIF.
    ENDIF.

    LOOP AT it_w_item INTO DATA(ls_w_item) WHERE zzfje > 0 .
      IF sy-tabix = 1 .
        DATA(lt_item_col) = VALUE  ztrt_amt_agn(  ( bukrs = ls_w_item-bukrs
                                                    zbelnr1 = ls_w_item-zbelnr1  )  ) .
      ELSE.
        READ TABLE lt_item_col INTO DATA(ls_item_col) WITH KEY bukrs = ls_w_item-bukrs
                                                             zbelnr1 = ls_w_item-zbelnr1
                                                                .
        IF sy-subrc <> 0 .

          lt_item_col = VALUE #( BASE lt_item_col (  bukrs = ls_w_item-bukrs
                                                     zbelnr1 = ls_w_item-zbelnr1  ) ).
        ENDIF.
      ENDIF.
    ENDLOOP.

    CALL METHOD zcl_tr_3020_gui=>get_agn
      EXPORTING
        it_agn = lt_item_col
      IMPORTING
        et_agn = DATA(lt_agn_db_all).


    MOVE it_w_item TO lt_w_item  .
    SORT lt_w_item BY billn itemn .

    LOOP AT lt_item_col  INTO ls_item_col .

      CALL METHOD zcl_tr_3020_gui=>get_amt_20
        EXPORTING
          i_zbelnr1 = ls_item_col-zbelnr1
        IMPORTING
          e_amt     = DATA(lv_wrbtr).

      LOOP AT lt_agn_db_all INTO DATA(ls_agn_db) WHERE bukrs = iv_bukrs
                                                    AND zbelnr1 = ls_item_col-zbelnr1.
        READ TABLE lt_w_item INTO ls_w_item WITH KEY billn = ls_agn_db-jjbilln
                                                     itemn = ls_agn_db-jjitemn .
*         binary search .
        IF sy-subrc <> 0 .
          READ TABLE lt_del INTO DATA(ls_del) WITH KEY db_key = ls_agn_db-db_key BINARY SEARCH .
          IF sy-subrc <> 0 .
            lv_wrbtr = lv_wrbtr - ls_agn_db-wrbtr_agn.
          ENDIF.
        ENDIF.
      ENDLOOP.


      LOOP AT lt_w_item INTO ls_w_item WHERE bukrs = iv_bukrs
                                          AND zbelnr1 = ls_item_col-zbelnr1 .
        lv_wrbtr = lv_wrbtr - ls_w_item-jhzfe .
      ENDLOOP.

      IF lv_wrbtr < 0 .
        MESSAGE e113(ztr01) WITH  ls_w_item-zbelnr1  RAISING  err..
      ENDIF.

      LOOP AT lt_w_item INTO  ls_w_item WHERE bukrs = iv_bukrs
                                           AND zbelnr1 = ls_item_col-zbelnr1.

        READ TABLE lt_agn_db_all INTO ls_agn_db WITH KEY jjbilln = ls_w_item-billn
                                                         jjitemn = ls_w_item-itemn .

        IF sy-subrc <>  0 .

          et_asn = VALUE #( BASE et_asn (
                db_key      =  /bobf/cl_frw_factory=>get_new_key( )
                zbelnr1       =  ls_w_item-zbelnr1
                waers       =  ls_w_item-waers
                wrbtr_agn   =  ls_w_item-jhzfe
                jjbilln       =  ls_w_item-billn
                jjitemn     =  ls_w_item-itemn
                fund_flow   =  ls_w_item-fund_flow
                 aedat       = sy-datum
                aezet       = sy-uzeit
                aenam       = sy-uname    ) ) .
        ELSE.
          ls_agn_db-wrbtr_agn   = ls_w_item-jhzfe .
          ls_agn_db-fund_flow   =  ls_w_item-fund_flow .
          ls_agn_db-aedat = sy-datum .
          ls_agn_db-aezet = sy-uzeit .
          ls_agn_db-aenam = sy-uname .
          APPEND ls_agn_db TO et_asn .
        ENDIF.
      ENDLOOP.
    ENDLOOP.

    LOOP AT lt_del INTO ls_del .
      ls_del-dflag = abap_true.
      APPEND ls_del TO et_asn .
    ENDLOOP.

  ENDMETHOD.


METHOD chg_agn_by_jjitem_21.

    DATA : lt_w_item TYPE ztrtt3020_02.

* DEL
    IF it_d_item IS NOT INITIAL .
      SELECT * FROM ztrv_amt_agn INTO TABLE  @DATA(lt_del)
        FOR ALL ENTRIES IN @it_d_item
        WHERE jjbilln = @it_d_item-billn
          AND jjitemn = @it_d_item-itemn
          AND dflag = @abap_false.
      IF sy-subrc = 0 .
        SORT lt_del BY db_key .
      ENDIF.
    ENDIF.

    LOOP AT it_w_item INTO DATA(ls_w_item) WHERE zzfje > 0 .
      IF sy-tabix = 1 .
        DATA(lt_item_col) = VALUE  ztrt_amt_agn(  ( bukrs = iv_bukrs
                                                    zbelnr1 = ls_w_item-zbelnr1
                                                    sqdxh = ls_w_item-sqdxh
                                                      gjahr = ls_w_item-gjahr
                                                      belnr = ls_w_item-belnr
                                                      buzei = ls_w_item-buzei
                                                     )  ) .
      ELSE.
        READ TABLE lt_item_col INTO DATA(ls_item_col) WITH KEY bukrs = ls_w_item-bukrs
                                                             zbelnr1 = ls_w_item-zbelnr1
                                                    sqdxh = ls_w_item-sqdxh
                                                                .
        IF sy-subrc <> 0 .

          lt_item_col = VALUE #( BASE lt_item_col (  bukrs = iv_bukrs
                                                     zbelnr1 = ls_w_item-zbelnr1
                                                       sqdxh = ls_w_item-sqdxh
                                                       gjahr = ls_w_item-gjahr
                                                       belnr = ls_w_item-belnr
                                                       buzei = ls_w_item-buzei
                                                        ) ).
        ENDIF.
      ENDIF.
    ENDLOOP.

    CALL METHOD zcl_tr_3020_gui=>get_agn
      EXPORTING
        it_agn = lt_item_col
      IMPORTING
        et_agn = DATA(lt_agn_db_all).


    MOVE it_w_item TO lt_w_item  .
    SORT lt_w_item BY billn itemn .

    LOOP AT lt_item_col  INTO ls_item_col .

      CALL METHOD zcl_tr_3020_gui=>get_amt_21
        EXPORTING
          i_zbelnr1 = ls_item_col-zbelnr1
          i_sqdxh   = ls_item_col-sqdxh
        IMPORTING
          e_amt     = DATA(lv_wrbtr).

      LOOP AT lt_agn_db_all INTO DATA(ls_agn_db) WHERE bukrs = iv_bukrs
                                                    AND zbelnr1 = ls_item_col-zbelnr1
                                                     AND    sqdxh = ls_item_col-sqdxh .
        READ TABLE lt_w_item INTO ls_w_item WITH KEY billn = ls_agn_db-jjbilln
                                                     itemn = ls_agn_db-jjitemn .
*         binary search .
        IF sy-subrc <> 0 .
          READ TABLE lt_del INTO DATA(ls_del) WITH KEY db_key = ls_agn_db-db_key BINARY SEARCH .
          IF sy-subrc <> 0 .
            lv_wrbtr = lv_wrbtr - ls_agn_db-wrbtr_agn.
          ENDIF.
        ENDIF.
      ENDLOOP.


      LOOP AT lt_w_item INTO ls_w_item WHERE bukrs = iv_bukrs
                                          AND zbelnr1 = ls_item_col-zbelnr1
                                         AND    sqdxh = ls_item_col-sqdxh .
        lv_wrbtr = lv_wrbtr - ls_w_item-jhzfe .
      ENDLOOP.

      IF lv_wrbtr < 0 .
        MESSAGE e113(ztr01) WITH  ls_w_item-zbelnr1  RAISING  err..
      ENDIF.

      LOOP AT lt_w_item INTO  ls_w_item WHERE bukrs = iv_bukrs
                                           AND zbelnr1 = ls_item_col-zbelnr1
                                          AND    sqdxh = ls_item_col-sqdxh .

        READ TABLE lt_agn_db_all INTO ls_agn_db WITH KEY jjbilln = ls_w_item-billn
                                                         jjitemn = ls_w_item-itemn .

        IF sy-subrc <>  0 .

          et_asn = VALUE #( BASE et_asn (
                db_key      =  /bobf/cl_frw_factory=>get_new_key( )
                zbelnr1       =  ls_w_item-zbelnr1
                sqdxh       =  ls_w_item-sqdxh
                bukrs = iv_bukrs
                 gjahr = ls_w_item-gjahr
                 belnr = ls_w_item-belnr
                 buzei = ls_w_item-buzei
                waers       =  ls_w_item-waers
                wrbtr_agn   =  ls_w_item-jhzfe
                jjbilln       =  ls_w_item-billn
                jjitemn     =  ls_w_item-itemn
                fund_flow   =  ls_w_item-fund_flow
                 aedat       = sy-datum
                aezet       = sy-uzeit
                aenam       = sy-uname    ) ) .
        ELSE.
          ls_agn_db-wrbtr_agn   = ls_w_item-jhzfe .
          ls_agn_db-fund_flow   =  ls_w_item-fund_flow .
          ls_agn_db-aedat = sy-datum .
          ls_agn_db-aezet = sy-uzeit .
          ls_agn_db-aenam = sy-uname .
          APPEND ls_agn_db TO et_asn .
        ENDIF.
      ENDLOOP.
    ENDLOOP.

    LOOP AT lt_del INTO ls_del .
      ls_del-dflag = abap_true.
      APPEND ls_del TO et_asn .
    ENDLOOP.

  ENDMETHOD.


METHOD chg_agn_by_jj_witem.

    IF it_w_item IS INITIAL . RETURN . ENDIF.

    SELECT * FROM ztrv_amt_agn APPENDING TABLE et_asn
       FOR ALL ENTRIES IN it_w_item
    WHERE jjbilln = it_w_item-jjbilln
      AND jjitemn = it_w_item-jjitemn
      AND dflag   = abap_false .

    IF sy-subrc <> 0 .
      MESSAGE e321(ztr01)  RAISING  err.
    ENDIF.

    LOOP AT  it_w_item INTO DATA(ls_item) .
      READ TABLE  et_asn ASSIGNING FIELD-SYMBOL(<fs_asn>) WITH KEY jjbilln = ls_item-jjbilln jjitemn = ls_item-jjitemn .
      IF sy-subrc = 0 .
        IF ls_item-dflag = abap_true .
          CLEAR :<fs_asn>-bguid , <fs_asn>-witemn .
        ELSE.
          <fs_asn>-bguid  = ls_item-bguid .
          <fs_asn>-witemn = ls_item-itemn .
        ENDIF.
      ELSE.
        MESSAGE e321(ztr01)  RAISING  err.
      ENDIF.
    ENDLOOP.


  ENDMETHOD.


METHOD chg_agn_by_witem.

    DATA : lt_w_item TYPE ztrt_3018_02,
           lt_d_item TYPE ztrt_3018_02.

    LOOP AT it_w_item INTO DATA(ls_item) WHERE bcate = '10' OR  bcate = '11'  .
      APPEND ls_item TO lt_w_item .
    ENDLOOP.

    LOOP AT it_d_item INTO ls_item WHERE bcate = '10' OR bcate = '11'  .
      APPEND ls_item TO lt_d_item .
    ENDLOOP.

    IF lt_w_item  IS NOT INITIAL  OR lt_d_item IS NOT INITIAL .

      CALL METHOD zcl_tr_3020_gui=>chg_agn_by_witem_10
        EXPORTING
          iv_bukrs  = iv_bukrs
          it_w_item = lt_w_item
          it_d_item = lt_d_item
          iv_zmplv  = iv_zmplv
          iv_save   = iv_save
        IMPORTING
          et_asn    = DATA(lt_asn)
        EXCEPTIONS
          err       = 1
          OTHERS    = 2.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
          WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
      ENDIF.

      APPEND LINES OF lt_asn TO et_asn .
    ENDIF.


    CLEAR :lt_w_item , lt_d_item , lt_asn .
    LOOP AT it_w_item INTO ls_item WHERE bcate = '20'.
      APPEND ls_item TO lt_w_item .
    ENDLOOP.

    LOOP AT it_d_item INTO ls_item WHERE bcate = '20'.
      APPEND ls_item TO lt_d_item .
    ENDLOOP.

    IF lt_w_item  IS NOT INITIAL  OR lt_d_item IS NOT INITIAL .

      CALL METHOD zcl_tr_3020_gui=>chg_agn_by_witem_20
        EXPORTING
          iv_bukrs  = iv_bukrs
          it_w_item = lt_w_item
          it_d_item = lt_d_item
          iv_zmplv  = iv_zmplv
          iv_save   = iv_save
        IMPORTING
          et_asn    = lt_asn
        EXCEPTIONS
          err       = 1
          OTHERS    = 2.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
          WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
      ENDIF.

      APPEND LINES OF lt_asn TO et_asn .
    ENDIF.


    CLEAR :lt_w_item , lt_d_item , lt_asn .
    LOOP AT it_w_item INTO ls_item WHERE bcate = '30'.
      APPEND ls_item TO lt_w_item .
    ENDLOOP.

    LOOP AT it_d_item INTO ls_item WHERE bcate = '30'.
      APPEND ls_item TO lt_d_item .
    ENDLOOP.

    IF lt_w_item  IS NOT INITIAL  OR lt_d_item IS NOT INITIAL .

      CALL METHOD zcl_tr_3020_gui=>chg_agn_by_witem_30
        EXPORTING
          iv_bukrs  = iv_bukrs
          it_w_item = lt_w_item
          it_d_item = lt_d_item
          iv_zmplv  = iv_zmplv
          iv_save   = iv_save
        IMPORTING
          et_asn    = lt_asn
        EXCEPTIONS
          err       = 1
          OTHERS    = 2.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
          WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
      ENDIF.

      APPEND LINES OF lt_asn TO et_asn .
    ENDIF.
    "add 20200608 支付申请单逻辑同30.
    CLEAR :lt_w_item , lt_d_item , lt_asn .
    LOOP AT it_w_item INTO ls_item WHERE bcate IN zcl_tr_3019_gui=>get_zfsqd_range(  ).
      APPEND ls_item TO lt_w_item .
    ENDLOOP.

    LOOP AT it_d_item INTO ls_item WHERE bcate IN zcl_tr_3019_gui=>get_zfsqd_range(  ).
      APPEND ls_item TO lt_d_item .
    ENDLOOP.

    IF lt_w_item  IS NOT INITIAL  OR lt_d_item IS NOT INITIAL .

      CALL METHOD zcl_tr_3020_gui=>chg_agn_by_witem_21
        EXPORTING
          iv_bukrs  = iv_bukrs
          it_w_item = lt_w_item
          it_d_item = lt_d_item
          iv_zmplv  = iv_zmplv
          iv_save   = iv_save
        IMPORTING
          et_asn    = lt_asn
        EXCEPTIONS
          err       = 1
          OTHERS    = 2.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
        WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
      ENDIF.

      APPEND LINES OF lt_asn TO et_asn .
    ENDIF.

    LOOP AT et_asn ASSIGNING FIELD-SYMBOL(<fs_asn>) .
      <fs_asn>-aedat = sy-datum .
      <fs_asn>-aezet = sy-uzeit .
      <fs_asn>-aenam = sy-uname .
    ENDLOOP .

  ENDMETHOD.


METHOD chg_agn_by_witem_10.

    DATA : lt_w_item TYPE ztrt_3018_02.
* DEL
    IF it_d_item IS NOT INITIAL .
      IF iv_zmplv  IS INITIAL .
        SELECT * FROM ztrv_amt_agn INTO TABLE  @DATA(lt_del)
          FOR ALL ENTRIES IN @it_d_item
          WHERE bguid = @it_d_item-bguid
            AND witemn = @it_d_item-itemn
            AND dflag = @abap_false.
        IF sy-subrc = 0 .
          SORT lt_del BY db_key .
        ENDIF.
      ELSE.
        SELECT * FROM ztrv_mamt_agn INTO TABLE  lt_del
         FOR ALL ENTRIES IN it_d_item
         WHERE bguid = it_d_item-bguid
           AND witemn = it_d_item-itemn
           AND dflag = abap_false.
        IF sy-subrc = 0 .
          SORT lt_del BY db_key .
        ENDIF.
      ENDIF.
    ENDIF.

    LOOP AT it_w_item INTO DATA(ls_w_item) WHERE zzfje > 0 .
      IF sy-tabix = 1 .
        DATA(lt_item_col) = VALUE  ztrt_amt_agn(  ( bukrs = ls_w_item-bukrs
                                                    gjahr = ls_w_item-gjahr
                                                    belnr = ls_w_item-belnr
                                                    buzei = ls_w_item-buzei )  ) .
      ELSE.
        READ TABLE lt_item_col INTO DATA(ls_item_col) WITH KEY bukrs = ls_w_item-bukrs
                                                               gjahr = ls_w_item-gjahr
                                                               belnr = ls_w_item-belnr
                                                               buzei = ls_w_item-buzei .
        IF sy-subrc <> 0 .

          lt_item_col = VALUE #( BASE lt_item_col (  bukrs = ls_w_item-bukrs
                                                     gjahr = ls_w_item-gjahr
                                                     belnr = ls_w_item-belnr
                                                     buzei = ls_w_item-buzei ) ).
        ENDIF.
      ENDIF.
    ENDLOOP.

    CALL METHOD zcl_tr_3020_gui=>get_agn
      EXPORTING
        it_agn = lt_item_col
      IMPORTING
        et_agn = DATA(lt_agn_db_all).


    IF iv_zmplv IS NOT INITIAL.
      CALL METHOD zcl_tr_3020_gui=>get_magn
        EXPORTING
          it_agn = lt_item_col
        IMPORTING
          et_agn = DATA(lt_agn_db_m_all).
      SORT lt_agn_db_m_all BY bguid witemn .
    ENDIF.

    IF iv_zmplv IS NOT INITIAL AND lt_agn_db_all IS NOT INITIAL .
      LOOP AT  lt_agn_db_all  INTO DATA(ls_db) .
        SELECT COUNT(*) FROM ztrt3018_01 WHERE bguid = ls_db-bguid AND zmplv < iv_zmplv  AND dflag = space.
        IF sy-subrc <> 0 .
          DELETE lt_agn_db_all WHERE  bguid = ls_db-bguid.
        ENDIF.
      ENDLOOP.
    ENDIF.

    SORT lt_agn_db_all BY bguid witemn .

    MOVE it_w_item TO lt_w_item  .
    SORT lt_w_item BY bguid itemn .

    DATA(lt_w_copy) = it_w_item.
    SORT lt_w_copy BY bukrs belnr  gjahr buzei.

    IF lt_del[] IS NOT INITIAL.
      DATA(lt_del_w) = lt_agn_db_all.
      SORT lt_del_w BY bukrs belnr  gjahr buzei.
    ENDIF.

    LOOP AT lt_item_col  INTO ls_item_col .

      CALL METHOD zcl_tr_3020_gui=>get_amt_10
        EXPORTING
          i_bukrs = iv_bukrs
          i_gjahr = ls_item_col-gjahr
          i_belnr = ls_item_col-belnr
          i_buzei = ls_item_col-buzei
        IMPORTING
          e_amt   = DATA(lv_wrbtr).

      READ TABLE lt_del_w INTO  DATA(ls_agn_db1) WITH   KEY  bukrs = iv_bukrs
                                                             belnr = ls_item_col-belnr
                                                             gjahr = ls_item_col-gjahr
                                                             buzei = ls_item_col-buzei BINARY SEARCH.
      IF sy-subrc = 0.
        LOOP AT lt_del_w INTO DATA(ls_agn_db) FROM sy-tabix  .
          IF ls_agn_db-belnr NE ls_agn_db1-belnr OR  ls_agn_db-gjahr NE ls_agn_db1-gjahr
             OR ls_agn_db-buzei NE ls_agn_db1-buzei.
            EXIT.
          ENDIF.
          IF ls_agn_db-wrbtr_agn = 0.
            CONTINUE.
          ENDIF.
          READ TABLE lt_w_item INTO ls_w_item WITH KEY bguid = ls_agn_db-bguid
                                                       itemn = ls_agn_db-witemn BINARY SEARCH.
          IF sy-subrc <> 0 .
            READ TABLE lt_del INTO DATA(ls_del) WITH KEY db_key = ls_agn_db-db_key BINARY SEARCH .
            IF sy-subrc <> 0 .
              lv_wrbtr = lv_wrbtr - ls_agn_db-wrbtr_agn.
            ENDIF.
          ENDIF.
        ENDLOOP.

      ENDIF.

      READ TABLE lt_w_copy INTO DATA(is_w_item) WITH  KEY bukrs = iv_bukrs
                                                          belnr = ls_item_col-belnr
                                                          gjahr = ls_item_col-gjahr
                                                          buzei = ls_item_col-buzei BINARY SEARCH.
      IF sy-subrc = 0.

        LOOP AT lt_w_copy INTO ls_w_item  FROM sy-tabix.
          IF     ls_w_item-belnr NE is_w_item-belnr
              OR  ls_w_item-gjahr NE is_w_item-gjahr
               OR ls_w_item-buzei NE is_w_item-buzei.
            EXIT.
          ENDIF.
          lv_wrbtr = lv_wrbtr - ls_w_item-jhzfe .
*        ENDLOOP.
*      ENDIF.
*      IF lv_wrbtr < 0 .
*        MESSAGE e095(ztr01) WITH  ls_w_item-gjahr ls_w_item-belnr ls_w_item-buzei  RAISING  err..
*      ENDIF.

*      LOOP AT lt_w_item INTO  ls_w_item WHERE bukrs = iv_bukrs
*                                           AND belnr = ls_item_col-belnr
*                                           AND gjahr = ls_item_col-gjahr
*                                           AND buzei =  ls_item_col-buzei .
          IF iv_zmplv IS  INITIAL .
            READ TABLE lt_agn_db_all INTO ls_agn_db WITH KEY bguid = ls_w_item-bguid   witemn = ls_w_item-itemn BINARY SEARCH .

            IF sy-subrc <>  0 .

              et_asn = VALUE #( BASE et_asn (
                    db_key      =  /bobf/cl_frw_factory=>get_new_key( )
                    bukrs       =  iv_bukrs
                    gjahr       =  ls_w_item-gjahr
                    belnr       =  ls_w_item-belnr
                    buzei       =  ls_w_item-buzei
                    waers       =  ls_w_item-waers
                    wrbtr_agn   =  ls_w_item-jhzfe
                    bguid       =  ls_w_item-bguid
                    witemn      =  ls_w_item-itemn
                    fund_flow   =  ls_w_item-fund_flow
                    aedat       =  sy-datum
                    aezet       =  sy-uzeit
                    aenam       =  sy-uname ) ) .
            ELSE.
              ls_agn_db-wrbtr_agn = ls_w_item-jhzfe .
              ls_agn_db-fund_flow   =  ls_w_item-fund_flow .
              APPEND ls_agn_db TO et_asn .
            ENDIF.
          ELSE.
            READ TABLE lt_agn_db_m_all INTO ls_agn_db WITH KEY bguid = ls_w_item-bguid   witemn = ls_w_item-itemn BINARY SEARCH .

            IF sy-subrc <>  0 .

              et_asn = VALUE #( BASE et_asn (
                    db_key      =  /bobf/cl_frw_factory=>get_new_key( )
                    bukrs       =  iv_bukrs
                    gjahr       =  ls_w_item-gjahr
                    belnr       =  ls_w_item-belnr
                    buzei       =  ls_w_item-buzei
                    waers       =  ls_w_item-waers
                    wrbtr_agn   =  ls_w_item-jhzfe
                    bguid       =  ls_w_item-bguid
                    witemn      =  ls_w_item-itemn
                    fund_flow   =  ls_w_item-fund_flow
                    aedat       =  sy-datum
                    aezet       =  sy-uzeit
                    aenam       =  sy-uname ) ) .
            ELSE.
              ls_agn_db-wrbtr_agn = ls_w_item-jhzfe .
              ls_agn_db-fund_flow   =  ls_w_item-fund_flow .
              APPEND ls_agn_db TO et_asn .
            ENDIF.
          ENDIF.
        ENDLOOP.

      ENDIF.
      IF lv_wrbtr < 0 .
        CLEAR et_asn.
        MESSAGE e095(ztr01) WITH  ls_w_item-gjahr ls_w_item-belnr ls_w_item-buzei  RAISING  err..
      ENDIF.
    ENDLOOP.

    LOOP AT lt_del INTO ls_del .
      ls_del-dflag = abap_true.
      APPEND ls_del TO et_asn .
    ENDLOOP.

  ENDMETHOD.


METHOD chg_agn_by_witem_20.

    DATA : lt_w_item TYPE ztrt_3018_02.

* DEL
    IF it_d_item IS NOT INITIAL .
      IF iv_zmplv IS INITIAL .
        SELECT * FROM ztrv_amt_agn INTO TABLE  @DATA(lt_del)
          FOR ALL ENTRIES IN @it_d_item
          WHERE bguid = @it_d_item-bguid
            AND witemn = @it_d_item-itemn
            AND dflag = @abap_false.
        IF sy-subrc = 0 .
          SORT lt_del BY db_key .
        ENDIF.
      ELSE.
        SELECT * FROM ztrv_mamt_agn INTO TABLE  lt_del
         FOR ALL ENTRIES IN it_d_item
   WHERE bguid = it_d_item-bguid
     AND witemn = it_d_item-itemn
     AND dflag = abap_false.
        IF sy-subrc = 0 .
          SORT lt_del BY db_key .
        ENDIF.
      ENDIF.
    ENDIF.

    LOOP AT it_w_item INTO DATA(ls_w_item) WHERE zzfje > 0 .
      IF sy-tabix = 1 .
        DATA(lt_item_col) = VALUE  ztrt_amt_agn(  ( bukrs = ls_w_item-bukrs
                                                    zbelnr1 = ls_w_item-zbelnr1  )  ) .
      ELSE.
        READ TABLE lt_item_col INTO DATA(ls_item_col) WITH KEY bukrs = ls_w_item-bukrs
                                                             zbelnr1 = ls_w_item-zbelnr1
                                                                .
        IF sy-subrc <> 0 .

          lt_item_col = VALUE #( BASE lt_item_col (  bukrs = ls_w_item-bukrs
                                                     zbelnr1 = ls_w_item-zbelnr1  ) ).
        ENDIF.
      ENDIF.
    ENDLOOP.


    IF iv_zmplv IS NOT INITIAL .
      CALL METHOD zcl_tr_3020_gui=>get_magn
        EXPORTING
          it_agn = lt_item_col
        IMPORTING
          et_agn = DATA(lt_agn_db_m_all).
      SORT lt_agn_db_m_all BY bguid witemn .
    ENDIF.

    CALL METHOD zcl_tr_3020_gui=>get_agn
      EXPORTING
        it_agn = lt_item_col
      IMPORTING
        et_agn = DATA(lt_agn_db_all).

    IF iv_zmplv IS NOT INITIAL AND lt_agn_db_all IS NOT INITIAL .
      LOOP AT  lt_agn_db_all  INTO DATA(ls_db) .
        SELECT COUNT(*) FROM ztrt3018_01 WHERE bguid = ls_db-bguid AND zmplv < iv_zmplv  AND dflag = space.
        IF sy-subrc <> 0 .
          DELETE lt_agn_db_all WHERE bguid = ls_db-bguid.
        ENDIF.
      ENDLOOP.
    ENDIF.
    SORT lt_agn_db_all BY bguid witemn .


    MOVE it_w_item TO lt_w_item  .
    SORT lt_w_item BY bguid itemn .

    LOOP AT lt_item_col  INTO ls_item_col .

      CALL METHOD zcl_tr_3020_gui=>get_amt_20
        EXPORTING
          i_zbelnr1 = ls_item_col-zbelnr1
        IMPORTING
          e_amt     = DATA(lv_wrbtr).

      LOOP AT lt_agn_db_all INTO DATA(ls_agn_db) WHERE bukrs = iv_bukrs
                                                    AND zbelnr1 = ls_item_col-zbelnr1.
        READ TABLE lt_w_item INTO ls_w_item WITH KEY bguid = ls_agn_db-bguid
                                                     itemn = ls_agn_db-witemn .
*         binary search .
        IF sy-subrc <> 0 .
          READ TABLE lt_del INTO DATA(ls_del) WITH KEY db_key = ls_agn_db-db_key BINARY SEARCH .
          IF sy-subrc <> 0 .
            lv_wrbtr = lv_wrbtr - ls_agn_db-wrbtr_agn.
          ENDIF.
        ENDIF.
      ENDLOOP.


      LOOP AT lt_w_item INTO ls_w_item WHERE bukrs = iv_bukrs
                                          AND zbelnr1 = ls_item_col-zbelnr1 .
        lv_wrbtr = lv_wrbtr - ls_w_item-jhzfe .
      ENDLOOP.

      IF lv_wrbtr < 0 .
        MESSAGE e113(ztr01) WITH  ls_w_item-zbelnr1  RAISING  err..
      ENDIF.

      LOOP AT lt_w_item INTO  ls_w_item WHERE bukrs = iv_bukrs
                                           AND zbelnr1 = ls_item_col-zbelnr1.
        IF iv_zmplv IS  INITIAL .

          READ TABLE lt_agn_db_all INTO ls_agn_db WITH KEY bguid = ls_w_item-bguid
                                                           witemn = ls_w_item-itemn BINARY SEARCH .

          IF sy-subrc <>  0 .
            et_asn = VALUE #( BASE et_asn (
                  db_key      =  /bobf/cl_frw_factory=>get_new_key( )
                  zbelnr1       =  ls_w_item-zbelnr1
                  waers       =  ls_w_item-waers
                  wrbtr_agn   =  ls_w_item-jhzfe
                  bguid       =  ls_w_item-bguid
                  witemn      =  ls_w_item-itemn
                  fund_flow   =  ls_w_item-fund_flow
                  aedat       =  sy-datum
                  aezet       =  sy-uzeit
                  aenam       =  sy-uname ) ) .
          ELSE.
            ls_agn_db-wrbtr_agn   = ls_w_item-jhzfe .
            ls_agn_db-fund_flow   =  ls_w_item-fund_flow .
            APPEND ls_agn_db TO et_asn .
          ENDIF.
        ELSE.

          READ TABLE lt_agn_db_m_all INTO ls_agn_db WITH KEY bguid = ls_w_item-bguid
                                                              witemn = ls_w_item-itemn BINARY SEARCH .

          IF sy-subrc <>  0 .
            et_asn = VALUE #( BASE et_asn (
                  db_key      =  /bobf/cl_frw_factory=>get_new_key( )
                  zbelnr1       =  ls_w_item-zbelnr1
                  waers       =  ls_w_item-waers
                  wrbtr_agn   =  ls_w_item-jhzfe
                  bguid       =  ls_w_item-bguid
                  witemn      =  ls_w_item-itemn
                  fund_flow   =  ls_w_item-fund_flow
                  aedat       =  sy-datum
                  aezet       =  sy-uzeit
                  aenam       =  sy-uname ) ) .
          ELSE.
            ls_agn_db-wrbtr_agn   = ls_w_item-jhzfe .
            ls_agn_db-fund_flow   =  ls_w_item-fund_flow .
            APPEND ls_agn_db TO et_asn .
          ENDIF.

        ENDIF.
      ENDLOOP.
    ENDLOOP.

    LOOP AT lt_del INTO ls_del .
      ls_del-dflag = abap_true.
      APPEND ls_del TO et_asn .
    ENDLOOP.

  ENDMETHOD.


METHOD chg_agn_by_witem_21.

    DATA : lt_w_item TYPE ztrt_3018_02.

* DEL
    IF it_d_item IS NOT INITIAL .
      IF iv_zmplv IS INITIAL .
        SELECT * FROM ztrv_amt_agn INTO TABLE  @DATA(lt_del)
          FOR ALL ENTRIES IN @it_d_item
          WHERE bguid = @it_d_item-bguid
            AND witemn = @it_d_item-itemn
            AND dflag = @abap_false.
        IF sy-subrc = 0 .
          SORT lt_del BY db_key .
        ENDIF.
      ELSE.
        SELECT * FROM ztrv_mamt_agn INTO TABLE  lt_del
         FOR ALL ENTRIES IN it_d_item
   WHERE bguid = it_d_item-bguid
     AND witemn = it_d_item-itemn
     AND dflag = abap_false.
        IF sy-subrc = 0 .
          SORT lt_del BY db_key .
        ENDIF.
      ENDIF.
    ENDIF.

    LOOP AT it_w_item INTO DATA(ls_w_item) WHERE zzfje > 0 .
      IF sy-tabix = 1 .
        DATA(lt_item_col) = VALUE  ztrt_amt_agn(  ( bukrs = iv_bukrs
                                                     gjahr = ls_w_item-gjahr
                                                     belnr = ls_w_item-belnr
                                                     buzei = ls_w_item-buzei
                                                    zbelnr1 = ls_w_item-zbelnr1
                                                    sqdxh = ls_w_item-sqdxh

                                                    )  ) .
      ELSE.
        READ TABLE lt_item_col INTO DATA(ls_item_col) WITH KEY bukrs = iv_bukrs
                                                             zbelnr1 = ls_w_item-zbelnr1
                                                               sqdxh = ls_w_item-sqdxh
                                                                .
        IF sy-subrc <> 0 .

          lt_item_col = VALUE #( BASE lt_item_col (  bukrs = iv_bukrs
                                                      gjahr = ls_w_item-gjahr
                                                      belnr = ls_w_item-belnr
                                                      buzei = ls_w_item-buzei
                                                     zbelnr1 = ls_w_item-zbelnr1
                                                    sqdxh = ls_w_item-sqdxh ) ).
        ENDIF.
      ENDIF.
    ENDLOOP.


    IF iv_zmplv IS NOT INITIAL .
      CALL METHOD zcl_tr_3020_gui=>get_magn
        EXPORTING
          it_agn = lt_item_col
        IMPORTING
          et_agn = DATA(lt_agn_db_m_all).
      SORT lt_agn_db_m_all BY bguid witemn .
    ENDIF.

    CALL METHOD zcl_tr_3020_gui=>get_agn
      EXPORTING
        it_agn = lt_item_col
      IMPORTING
        et_agn = DATA(lt_agn_db_all).

    IF iv_zmplv IS NOT INITIAL AND lt_agn_db_all IS NOT INITIAL .
      LOOP AT  lt_agn_db_all  INTO DATA(ls_db) .
        SELECT COUNT(*) FROM ztrt3018_01 WHERE bguid = ls_db-bguid AND zmplv < iv_zmplv  AND dflag = space.
        IF sy-subrc <> 0 .
          DELETE lt_agn_db_all WHERE bguid = ls_db-bguid .
        ENDIF.
      ENDLOOP.
    ENDIF.
    SORT lt_agn_db_all BY bguid witemn .


    MOVE it_w_item TO lt_w_item  .
    SORT lt_w_item BY bguid itemn .

    LOOP AT lt_item_col  INTO ls_item_col .

      CALL METHOD zcl_tr_3020_gui=>get_amt_21
        EXPORTING
          i_zbelnr1 = ls_item_col-zbelnr1
          i_sqdxh   = ls_item_col-sqdxh
        IMPORTING
          e_amt     = DATA(lv_wrbtr).

      LOOP AT lt_agn_db_all INTO DATA(ls_agn_db) WHERE bukrs = iv_bukrs
                                                    AND zbelnr1 = ls_item_col-zbelnr1
                                                    AND  sqdxh = ls_item_col-sqdxh .
        READ TABLE lt_w_item INTO ls_w_item WITH KEY bguid = ls_agn_db-bguid
                                                     itemn = ls_agn_db-witemn .
*         binary search .
        IF sy-subrc <> 0 .
          READ TABLE lt_del INTO DATA(ls_del) WITH KEY db_key = ls_agn_db-db_key BINARY SEARCH .
          IF sy-subrc <> 0 .
            lv_wrbtr = lv_wrbtr - ls_agn_db-wrbtr_agn.
          ENDIF.
        ENDIF.
      ENDLOOP.


      LOOP AT lt_w_item INTO ls_w_item WHERE bukrs = iv_bukrs
                                          AND zbelnr1 = ls_item_col-zbelnr1
                                           AND  sqdxh = ls_item_col-sqdxh .
        lv_wrbtr = lv_wrbtr - ls_w_item-jhzfe .
      ENDLOOP.

      IF lv_wrbtr < 0 .
        MESSAGE e401(ztr05) WITH  ls_w_item-zbelnr1  ls_w_item-sqdxh  RAISING  err..
      ENDIF.

      LOOP AT lt_w_item INTO  ls_w_item WHERE bukrs = iv_bukrs
                                           AND zbelnr1 = ls_item_col-zbelnr1
                                           AND  sqdxh = ls_item_col-sqdxh ..
        IF iv_zmplv IS  INITIAL .

          READ TABLE lt_agn_db_all INTO ls_agn_db WITH KEY bguid = ls_w_item-bguid
                                                           witemn = ls_w_item-itemn BINARY SEARCH .

          IF sy-subrc <>  0 .
            et_asn = VALUE #( BASE et_asn (
                  db_key      =  /bobf/cl_frw_factory=>get_new_key( )
                  bukrs = iv_bukrs
                  zbelnr1       =  ls_w_item-zbelnr1
                  sqdxh     = ls_w_item-sqdxh
                                                      gjahr = ls_w_item-gjahr
                                                      belnr = ls_w_item-belnr
                                                      buzei = ls_w_item-buzei
                  waers       =  ls_w_item-waers
                  wrbtr_agn   =  ls_w_item-jhzfe
                  bguid       =  ls_w_item-bguid
                  witemn      =  ls_w_item-itemn
                  fund_flow   =  ls_w_item-fund_flow
                  aedat       =  sy-datum
                  aezet       =  sy-uzeit
                  aenam       =  sy-uname ) ) .
          ELSE.
            ls_agn_db-wrbtr_agn   = ls_w_item-jhzfe .
            ls_agn_db-fund_flow   =  ls_w_item-fund_flow .
            APPEND ls_agn_db TO et_asn .
          ENDIF.
        ELSE.

          READ TABLE lt_agn_db_m_all INTO ls_agn_db WITH KEY bguid = ls_w_item-bguid
                                                              witemn = ls_w_item-itemn BINARY SEARCH .

          IF sy-subrc <>  0 .
            et_asn = VALUE #( BASE et_asn (
                  db_key      =  /bobf/cl_frw_factory=>get_new_key( )
                 bukrs =  iv_bukrs
                  zbelnr1       =  ls_w_item-zbelnr1
                  sqdxh     = ls_w_item-sqdxh
                                                      gjahr = ls_w_item-gjahr
                                                      belnr = ls_w_item-belnr
                                                      buzei = ls_w_item-buzei
                  waers       =  ls_w_item-waers
                  wrbtr_agn   =  ls_w_item-jhzfe
                  bguid       =  ls_w_item-bguid
                  witemn      =  ls_w_item-itemn
                  fund_flow   =  ls_w_item-fund_flow
                  aedat       =  sy-datum
                  aezet       =  sy-uzeit
                  aenam       =  sy-uname ) ) .
          ELSE.
            ls_agn_db-wrbtr_agn   = ls_w_item-jhzfe .
            ls_agn_db-fund_flow   =  ls_w_item-fund_flow .
            APPEND ls_agn_db TO et_asn .
          ENDIF.

        ENDIF.
      ENDLOOP.
    ENDLOOP.

    LOOP AT lt_del INTO ls_del .
      ls_del-dflag = abap_true.
      APPEND ls_del TO et_asn .
    ENDLOOP.

  ENDMETHOD.


METHOD chg_agn_by_witem_30.

    DATA : lt_w_item TYPE ztrt_3018_02.

* DEL
    IF it_d_item IS NOT INITIAL .
      IF iv_zmplv IS INITIAL .
        SELECT * FROM ztrv_amt_agn INTO TABLE  @DATA(lt_del)
          FOR ALL ENTRIES IN @it_d_item
          WHERE bguid = @it_d_item-bguid
            AND witemn = @it_d_item-itemn
            AND dflag = @abap_false.
        IF sy-subrc = 0 .
          SORT lt_del BY db_key .
        ENDIF.
      ELSE.
        SELECT * FROM ztrv_mamt_agn INTO TABLE  lt_del
        FOR ALL ENTRIES IN it_d_item
        WHERE bguid = it_d_item-bguid
          AND witemn = it_d_item-itemn
          AND dflag = abap_false.
        IF sy-subrc = 0 .
          SORT lt_del BY db_key .
        ENDIF.
      ENDIF.
    ENDIF.

    LOOP AT it_w_item INTO DATA(ls_w_item) WHERE zzfje > 0 .
      IF sy-tabix = 1 .
        DATA(lt_item_col) = VALUE  ztrt_amt_agn(  ( bukrs = ls_w_item-bukrs
                                                    billn = ls_w_item-billn
                                                    itemn = ls_w_item-bilitmn )  ) .
      ELSE.
        READ TABLE lt_item_col INTO DATA(ls_item_col) WITH KEY bukrs = ls_w_item-bukrs
                                                               billn = ls_w_item-billn
                                                               itemn = ls_w_item-bilitmn .
        .
        IF sy-subrc <> 0 .

          lt_item_col = VALUE #( BASE lt_item_col (  bukrs = ls_w_item-bukrs
                                                     billn = ls_w_item-billn
                                                     itemn = ls_w_item-bilitmn  ) ).
        ENDIF.
      ENDIF.
    ENDLOOP.

    IF iv_zmplv IS NOT INITIAL .
      CALL METHOD zcl_tr_3020_gui=>get_magn
        EXPORTING
          it_agn = lt_item_col
        IMPORTING
          et_agn = DATA(lt_agn_db_m_all).
      SORT lt_agn_db_m_all BY bguid itemn .
    ENDIF.


    CALL METHOD zcl_tr_3020_gui=>get_agn
      EXPORTING
        it_agn = lt_item_col
      IMPORTING
        et_agn = DATA(lt_agn_db_all).

    IF iv_zmplv IS NOT INITIAL AND lt_agn_db_all IS NOT INITIAL .
      LOOP AT  lt_agn_db_all  INTO DATA(ls_db) .
        SELECT COUNT(*) FROM ztrt3018_01 WHERE bguid = ls_db-bguid AND zmplv < iv_zmplv  AND dflag = space.
        IF sy-subrc <> 0 .
          DELETE lt_agn_db_all .
        ENDIF.
      ENDLOOP.
    ENDIF.

    SORT lt_agn_db_all  BY bguid itemn .

    MOVE it_w_item TO lt_w_item  .
    SORT lt_w_item BY bguid itemn .

    LOOP AT lt_item_col  INTO ls_item_col .

      CALL METHOD zcl_tr_3020_gui=>get_amt_30
        EXPORTING
          i_billn = ls_item_col-billn
          i_itemn = ls_item_col-itemn
        IMPORTING
          e_amt   = DATA(lv_wrbtr).

      LOOP AT lt_agn_db_all INTO DATA(ls_agn_db) WHERE bukrs = iv_bukrs
                                                    AND billn = ls_item_col-billn
                                                    AND itemn = ls_item_col-itemn .
        READ TABLE lt_w_item INTO ls_w_item WITH KEY bguid = ls_agn_db-bguid
                                                     itemn = ls_agn_db-witemn .
*         binary search .
        IF sy-subrc <> 0 .
          READ TABLE lt_del INTO DATA(ls_del) WITH KEY db_key = ls_agn_db-db_key BINARY SEARCH .
          IF sy-subrc <> 0 .
            lv_wrbtr = lv_wrbtr - ls_agn_db-wrbtr_agn.
          ENDIF.
        ENDIF.
      ENDLOOP.


      LOOP AT lt_w_item INTO ls_w_item WHERE bukrs = iv_bukrs
                                          AND billn = ls_item_col-billn
                                          AND bilitmn = ls_item_col-itemn.
        lv_wrbtr = lv_wrbtr - ls_w_item-jhzfe .
      ENDLOOP.

      IF lv_wrbtr < 0 .
        MESSAGE e177(ztr01) WITH  ls_w_item-billn  ls_w_item-bilitmn RAISING  err..
      ENDIF.

      LOOP AT lt_w_item INTO  ls_w_item WHERE bukrs = iv_bukrs
                                         AND billn = ls_item_col-billn
                                         AND bilitmn = ls_item_col-itemn .
        IF iv_zmplv IS INITIAL .
          READ TABLE lt_agn_db_all INTO ls_agn_db WITH KEY bguid = ls_w_item-bguid
                                                           witemn = ls_w_item-itemn BINARY SEARCH .
          IF sy-subrc <>  0 .

            et_asn = VALUE #( BASE et_asn (
                  db_key      =  /bobf/cl_frw_factory=>get_new_key( )
                  billn       =  ls_w_item-billn
                  itemn       =  ls_w_item-bilitmn
                  waers       =  ls_w_item-waers
                  wrbtr_agn   =  ls_w_item-jhzfe
                  bguid       =  ls_w_item-bguid
                  witemn      =  ls_w_item-itemn
                  fund_flow   =  ls_w_item-fund_flow
                  aedat       =  sy-datum
                  aezet       =  sy-uzeit
                  aenam       =  sy-uname   ) ) .
          ELSE.
            ls_agn_db-wrbtr_agn = ls_w_item-jhzfe .
            ls_agn_db-fund_flow   =  ls_w_item-fund_flow  .
            APPEND ls_agn_db TO et_asn .
          ENDIF.
        ELSE.
          READ TABLE lt_agn_db_m_all INTO ls_agn_db WITH KEY bguid = ls_w_item-bguid
                                                             witemn = ls_w_item-itemn BINARY SEARCH .
          IF sy-subrc <>  0 .

            et_asn = VALUE #( BASE et_asn (
                  db_key      =  /bobf/cl_frw_factory=>get_new_key( )
                  billn       =  ls_w_item-billn
                  itemn       =  ls_w_item-bilitmn
                  waers       =  ls_w_item-waers
                  wrbtr_agn   =  ls_w_item-jhzfe
                  bguid       =  ls_w_item-bguid
                  witemn      =  ls_w_item-itemn
                  fund_flow   =  ls_w_item-fund_flow
                  aedat       =  sy-datum
                  aezet       =  sy-uzeit
                  aenam       =  sy-uname   ) ) .
          ELSE.
            ls_agn_db-wrbtr_agn = ls_w_item-jhzfe .
            ls_agn_db-fund_flow   =  ls_w_item-fund_flow  .
            APPEND ls_agn_db TO et_asn .
          ENDIF.
        ENDIF.
      ENDLOOP.
    ENDLOOP.

    LOOP AT lt_del INTO ls_del .
      ls_del-dflag = abap_true.
      APPEND ls_del TO et_asn .
    ENDLOOP.

  ENDMETHOD.


METHOD crt_agn_by_jjitem_10.
    DATA : ls_save LIKE LINE OF et_asn .

    LOOP AT it_w_item INTO DATA(ls_w_item) .
      IF sy-tabix = 1 .
        DATA(lt_item_col) = VALUE  ztrt_amt_agn(  ( gjahr = ls_w_item-gjahr
                                                    belnr = ls_w_item-belnr
                                                    buzei = ls_w_item-buzei )  ) .
      ELSE.
        lt_item_col = VALUE #( BASE lt_item_col (  gjahr = ls_w_item-gjahr
                                                   belnr = ls_w_item-belnr
                                                   buzei = ls_w_item-buzei ) ).
      ENDIF.
    ENDLOOP.

* 获取和财务凭证有关的全部周资金计划
    CALL METHOD zcl_tr_3020_gui=>get_total_agn_amt
      EXPORTING
        iv_bukrs = iv_bukrs
        it_agn   = lt_item_col
      IMPORTING
        et_agn   = DATA(lt_agn_db_all).


    LOOP AT it_w_item INTO ls_w_item  .

      CALL METHOD zcl_tr_3020_gui=>get_amt_10
        EXPORTING
          i_bukrs = iv_bukrs
          i_gjahr = ls_w_item-gjahr
          i_belnr = ls_w_item-belnr
          i_buzei = ls_w_item-buzei
        IMPORTING
          e_amt   = DATA(lv_wrbtr).

      IF lv_wrbtr >   0 .

        READ TABLE lt_agn_db_all INTO DATA(ls_agn_all) WITH KEY bukrs = iv_bukrs
                                                                gjahr = ls_w_item-gjahr
                                                                belnr = ls_w_item-belnr
                                                                buzei = ls_w_item-buzei BINARY SEARCH .

        IF ( lv_wrbtr < ls_w_item-jhzfe + ls_agn_all-wrbtr_agn AND sy-subrc = 0 )
        OR ( lv_wrbtr < ls_w_item-jhzfe  AND sy-subrc <> 0 ).
          MESSAGE e095(ztr01) WITH  ls_w_item-gjahr ls_w_item-belnr ls_w_item-buzei  RAISING  err.
        ENDIF.
      ENDIF.

      ls_save-db_key      =  /bobf/cl_frw_factory=>get_new_key( ) .
      ls_save-bukrs       =  iv_bukrs .
      ls_save-gjahr       =  ls_w_item-gjahr .
      ls_save-belnr       =  ls_w_item-belnr .
      ls_save-buzei       =  ls_w_item-buzei .
      ls_save-waers       =  ls_w_item-waers .
      IF ls_w_item-jhzfe >= 0 .
        ls_save-wrbtr_agn   =  ls_w_item-jhzfe .
      ELSE.
        ls_save-wrbtr_agn  = 0 .
      ENDIF.
      ls_save-jjbilln     =  ls_w_item-billn .
      ls_save-jjitemn     =  ls_w_item-itemn .
      ls_save-fund_flow   =  ls_w_item-fund_flow .
      ls_save-erdat = sy-datum .
      ls_save-erzet = sy-uzeit .
      ls_save-ernam = sy-uname .
      APPEND ls_save TO et_asn .

    ENDLOOP.
    .
    IF iv_save = abap_true.
      MODIFY ztrv_amt_agn FROM TABLE et_asn .
      IF sy-subrc = 0 .
        COMMIT WORK AND WAIT .
      ELSE.
        ROLLBACK WORK .
        MESSAGE e093(ztr01)  RAISING  err.
      ENDIF.
    ENDIF.


  ENDMETHOD.


METHOD crt_agn_by_jjitem_20.
    DATA : ls_save LIKE LINE OF et_asn .

    LOOP AT it_w_item INTO DATA(ls_w_item) .
      IF sy-tabix = 1 .
        DATA(lt_item_col) = VALUE  ztrt_amt_agn(  ( zbelnr1 = ls_w_item-zbelnr1 ) ) .
      ELSE.
        lt_item_col = VALUE #( BASE lt_item_col (  zbelnr1 = ls_w_item-zbelnr1 ) ).
      ENDIF.
    ENDLOOP.

* 获取和财务凭证有关的全部周资金计划
    CALL METHOD zcl_tr_3020_gui=>get_total_agn_amt
      EXPORTING
        iv_bukrs = iv_bukrs
        it_agn   = lt_item_col
      IMPORTING
        et_agn   = DATA(lt_agn_db_all).


    LOOP AT it_w_item INTO ls_w_item  .

      CALL METHOD zcl_tr_3020_gui=>get_amt_20
        EXPORTING
          i_zbelnr1 = ls_w_item-zbelnr1
        IMPORTING
          e_amt     = DATA(lv_wrbtr).

      IF lv_wrbtr >   0 .
        READ TABLE lt_agn_db_all INTO DATA(ls_agn_all) WITH KEY bukrs = iv_bukrs
                                                                zbelnr1 = ls_w_item-zbelnr1
                                                                BINARY SEARCH .

        IF ( lv_wrbtr < ls_w_item-jhzfe + ls_agn_all-wrbtr_agn AND sy-subrc = 0 )
         OR ( lv_wrbtr < ls_w_item-jhzfe  AND sy-subrc <> 0 ).
          MESSAGE e113(ztr01) WITH ls_w_item-zbelnr1 RAISING  err.
        ENDIF.
      ENDIF.

      ls_save-db_key      =  /bobf/cl_frw_factory=>get_new_key( ) .
      ls_save-bukrs       =  iv_bukrs .
      ls_save-zbelnr1      =  ls_w_item-zbelnr1 .
      ls_save-waers       =  ls_w_item-waers .
      IF ls_w_item-jhzfe >= 0 .
        ls_save-wrbtr_agn   =  ls_w_item-jhzfe .
      ELSE.
        ls_save-wrbtr_agn  = 0 .
      ENDIF.
      ls_save-jjbilln     =  ls_w_item-billn .
      ls_save-jjitemn     =  ls_w_item-itemn .
      ls_save-fund_flow   =  ls_w_item-fund_flow .
      ls_save-erdat = sy-datum .
      ls_save-erzet = sy-uzeit .
      ls_save-ernam = sy-uname .
      APPEND ls_save TO et_asn .

    ENDLOOP.
    .
    IF iv_save = abap_true.
      MODIFY ztrv_amt_agn FROM TABLE et_asn .
      IF sy-subrc = 0 .
        COMMIT WORK AND WAIT .
      ELSE.
        ROLLBACK WORK .
        MESSAGE e093(ztr01)  RAISING  err.
      ENDIF.
    ENDIF.


  ENDMETHOD.


METHOD crt_agn_by_jjitem_21.
    DATA : ls_save LIKE LINE OF et_asn .

    LOOP AT it_w_item INTO DATA(ls_w_item) .
      IF sy-tabix = 1 .
        DATA(lt_item_col) = VALUE  ztrt_amt_agn(  (  gjahr   = ls_w_item-gjahr
                                                     belnr   = ls_w_item-belnr
                                                     buzei   = ls_w_item-buzei
                                                     zbelnr1 = ls_w_item-zbelnr1
                                                     sqdxh   = ls_w_item-sqdxh ) ) .
      ELSE.
        lt_item_col = VALUE #( BASE lt_item_col (           gjahr = ls_w_item-gjahr      belnr = ls_w_item-belnr      buzei = ls_w_item-buzei
         zbelnr1 = ls_w_item-zbelnr1  sqdxh = ls_w_item-sqdxh ) ).
      ENDIF.
    ENDLOOP.

* 获取和财务凭证有关的全部周资金计划
    CALL METHOD zcl_tr_3020_gui=>get_total_agn_amt
      EXPORTING
        iv_bukrs = iv_bukrs
        it_agn   = lt_item_col
      IMPORTING
        et_agn   = DATA(lt_agn_db_all).

    LOOP AT it_w_item INTO ls_w_item  .

      CALL METHOD zcl_tr_3020_gui=>get_amt_21
        EXPORTING
          i_zbelnr1 = ls_w_item-zbelnr1
          i_sqdxh   = ls_w_item-sqdxh
        IMPORTING
          e_amt     = DATA(lv_wrbtr).

      IF lv_wrbtr >   0 .
        READ TABLE lt_agn_db_all INTO DATA(ls_agn_all) WITH KEY bukrs = iv_bukrs
                                                                zbelnr1 = ls_w_item-zbelnr1
                                                                sqdxh   = ls_w_item-sqdxh
                                                                BINARY SEARCH .

        IF ( lv_wrbtr < ls_w_item-jhzfe + ls_agn_all-wrbtr_agn AND sy-subrc = 0 )
         OR ( lv_wrbtr < ls_w_item-jhzfe  AND sy-subrc <> 0 ).
          MESSAGE e113(ztr01) WITH ls_w_item-zbelnr1 RAISING  err.
        ENDIF.
      ENDIF.

      ls_save-db_key      =  /bobf/cl_frw_factory=>get_new_key( ) .
      ls_save-bukrs       =  iv_bukrs .
      ls_save-zbelnr1      =  ls_w_item-zbelnr1 .
      ls_save-sqdxh   = ls_w_item-sqdxh.
      ls_save-gjahr = ls_w_item-gjahr.
      ls_save-belnr = ls_w_item-belnr.
      ls_save-buzei = ls_w_item-buzei.
      ls_save-waers       =  ls_w_item-waers .
      IF ls_w_item-jhzfe >= 0 .
        ls_save-wrbtr_agn   =  ls_w_item-jhzfe .
      ELSE.
        ls_save-wrbtr_agn  = 0 .
      ENDIF.
      ls_save-jjbilln     =  ls_w_item-billn .
      ls_save-jjitemn     =  ls_w_item-itemn .
      ls_save-fund_flow   =  ls_w_item-fund_flow .
      ls_save-erdat = sy-datum .
      ls_save-erzet = sy-uzeit .
      ls_save-ernam = sy-uname .
      APPEND ls_save TO et_asn .

    ENDLOOP.
    .
    IF iv_save = abap_true.
      MODIFY ztrv_amt_agn FROM TABLE et_asn .
      IF sy-subrc = 0 .
        COMMIT WORK AND WAIT .
      ELSE.
        ROLLBACK WORK .
        MESSAGE e093(ztr01)  RAISING  err.
      ENDIF.
    ENDIF.


  ENDMETHOD.


METHOD crt_agn_by_witem.
    DATA : lt_item1 TYPE ztrt_3018_02.
    DATA : lt_item2 TYPE ztrt_3018_02.
    DATA : lt_item3 TYPE ztrt_3018_02.
    DATA : lt_item4 TYPE ztrt_3018_02.
    DATA : lt_item5 TYPE ztrt_3018_02.
    DATA : lt_item6 TYPE ztrt_3018_02.
    DATA : lt_item7 TYPE ztrt_3018_02.
    DATA : lt_item8 TYPE ztrt_3018_02.

    CLEAR: lt_item1,lt_item2,lt_item3 ,lt_item4,lt_item5,lt_item6,lt_item7,lt_item8.
    LOOP AT it_w_item INTO DATA(ls_item)
     " WHERE bcate  = '10' or  bcate = '11' or  bcate = '20' or  bcate = '30'
      WHERE  jhzfe > 0  .
      CASE ls_item-bcate.
        WHEN '10' OR  '11' OR '31' OR '33'.
          APPEND ls_item TO lt_item1 .
        WHEN '20' OR '32'."预付款申请
          APPEND ls_item TO lt_item2 .
        WHEN '30'.
          APPEND ls_item TO lt_item3 .
          " WHEN '21' OR '22' OR '25' or '12'.
        WHEN OTHERS.
          IF ls_item-bcate IN zcl_tr_3019_gui=>get_zfsqd_range(   ).
            APPEND ls_item TO lt_item4.
          ENDIF.
      ENDCASE.
    ENDLOOP.

    IF lt_item1[] IS NOT INITIAL .
      CALL METHOD zcl_tr_3020_gui=>crt_agn_by_witem_10
        EXPORTING
          iv_bukrs  = iv_bukrs
          it_w_item = lt_item1
          iv_zmplv  = iv_zmplv
        IMPORTING
          et_asn    = DATA(lt_asn)
        EXCEPTIONS
          err       = 1
          OTHERS    = 2.
      IF sy-subrc <> 0 .
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
        WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
      ENDIF.

      APPEND LINES OF lt_asn TO et_asn .
      CLEAR lt_asn .
    ENDIF.
    CLEAR : lt_item1  , lt_asn.
*    LOOP AT it_w_item INTO ls_item WHERE bcate = '20'.
*      APPEND ls_item TO lt_item .
*    ENDLOOP.

    IF lt_item2[] IS NOT INITIAL .
      CALL METHOD zcl_tr_3020_gui=>crt_agn_by_witem_20
        EXPORTING
          iv_bukrs  = iv_bukrs
          it_w_item = lt_item2
          iv_zmplv  = iv_zmplv
        IMPORTING
          et_asn    = lt_asn
        EXCEPTIONS
          err       = 1
          OTHERS    = 2.
      IF sy-subrc <> 0 .
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
          WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
      ENDIF.

      APPEND LINES OF lt_asn TO et_asn .
      CLEAR lt_asn .
    ENDIF.


    CLEAR : lt_item2  , lt_asn.
*    LOOP AT it_w_item INTO ls_item WHERE bcate = '30'.
*      APPEND ls_item TO lt_item .
*    ENDLOOP.

    IF lt_item3[] IS NOT INITIAL .
      CALL METHOD zcl_tr_3020_gui=>crt_agn_by_witem_30
        EXPORTING
          iv_bukrs  = iv_bukrs
          it_w_item = lt_item3
          iv_zmplv  = iv_zmplv
        IMPORTING
          et_asn    = lt_asn
        EXCEPTIONS
          err       = 1
          OTHERS    = 2.
      IF sy-subrc <> 0 .
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
          WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
      ENDIF.

      APPEND LINES OF lt_asn TO et_asn .
      CLEAR lt_asn .
    ENDIF.

    CLEAR : lt_item3  , lt_asn.

    IF lt_item4[] IS NOT INITIAL .
      CALL METHOD zcl_tr_3020_gui=>crt_agn_by_witem_21
        EXPORTING
          iv_bukrs  = iv_bukrs
          it_w_item = lt_item4
          iv_zmplv  = iv_zmplv
        IMPORTING
          et_asn    = lt_asn
        EXCEPTIONS
          err       = 1
          OTHERS    = 2.
      IF sy-subrc <> 0 .
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
        WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
      ENDIF.

      APPEND LINES OF lt_asn TO et_asn .
      CLEAR lt_asn .
    ENDIF.
*    LOOP AT et_asn ASSIGNING FIELD-SYMBOL(<fs_asn>) .
*      <fs_asn>-erdat = sy-datum .
*      <fs_asn>-erzet = sy-uzeit .
*      <fs_asn>-ernam = sy-uname .
*    ENDLOOP .
  ENDMETHOD.


METHOD crt_agn_by_witem_10.
    DATA : ls_save LIKE LINE OF et_asn .

    LOOP AT it_w_item INTO DATA(ls_w_item) .
      IF sy-tabix = 1 .
        DATA(lt_item_col) = VALUE  ztrt_amt_agn(  ( gjahr = ls_w_item-gjahr
                                                    belnr = ls_w_item-belnr
                                                    buzei = ls_w_item-buzei
                                                    zbelnr1 = ls_w_item-zbelnr1
                                                    sqdxh = ls_w_item-sqdxh

                                                      )  ) .
      ELSE.
        lt_item_col = VALUE #( BASE lt_item_col (  gjahr = ls_w_item-gjahr
                                                   belnr = ls_w_item-belnr
                                                    buzei = ls_w_item-buzei
                                                    zbelnr1 = ls_w_item-zbelnr1
                                                    sqdxh = ls_w_item-sqdxh
       ) ).
      ENDIF.
    ENDLOOP.

* 获取和财务凭证有关的全部周资金计划
    CALL METHOD zcl_tr_3020_gui=>get_total_agn_amt
      EXPORTING
        iv_bukrs = iv_bukrs
        it_agn   = lt_item_col
      IMPORTING
        et_agn   = DATA(lt_agn_db_all).


    IF iv_zmplv IS NOT INITIAL AND lt_agn_db_all IS NOT INITIAL .
      LOOP AT  lt_agn_db_all  INTO DATA(ls_db) .
        SELECT COUNT(*) FROM ztrt3018_01 WHERE bguid = ls_db-bguid AND zmplv < iv_zmplv  AND dflag = space.
        IF sy-subrc <> 0 .
          DELETE lt_agn_db_all  WHERE bguid = ls_db-bguid.
        ENDIF.
      ENDLOOP.
    ENDIF.


    LOOP AT it_w_item INTO ls_w_item  .

      CALL METHOD zcl_tr_3020_gui=>get_amt_10
        EXPORTING
          i_bukrs = iv_bukrs
          i_gjahr = ls_w_item-gjahr
          i_belnr = ls_w_item-belnr
          i_buzei = ls_w_item-buzei
        IMPORTING
          e_amt   = DATA(lv_wrbtr).

      IF lv_wrbtr >   0 .

        READ TABLE lt_agn_db_all INTO DATA(ls_agn_all) WITH KEY bukrs = iv_bukrs
                                                                gjahr = ls_w_item-gjahr
                                                                belnr = ls_w_item-belnr
                                                                buzei = ls_w_item-buzei BINARY SEARCH .

        IF ( lv_wrbtr < ls_w_item-jhzfe + ls_agn_all-wrbtr_agn AND sy-subrc = 0 )
        OR ( lv_wrbtr < ls_w_item-jhzfe  AND sy-subrc <> 0 ).
          MESSAGE e095(ztr01) WITH  ls_w_item-gjahr ls_w_item-belnr ls_w_item-buzei  RAISING  err.
        ENDIF.
      ENDIF.

      ls_save-db_key      =  /bobf/cl_frw_factory=>get_new_key( ) .
      ls_save-bukrs       =  iv_bukrs .
      ls_save-gjahr       =  ls_w_item-gjahr .
      ls_save-belnr       =  ls_w_item-belnr .
      ls_save-buzei       =  ls_w_item-buzei .
      ls_save-sqdxh       =  ls_w_item-sqdxh .
      ls_save-zbelnr1       =  ls_w_item-zbelnr1 .

      ls_save-waers       =  ls_w_item-waers .
      IF ls_w_item-jhzfe >= 0 .
        ls_save-wrbtr_agn   =  ls_w_item-jhzfe .
      ELSE.
        ls_save-wrbtr_agn  = 0 .
      ENDIF.
      ls_save-bguid       =  ls_w_item-bguid  .
      ls_save-witemn      =  ls_w_item-itemn .
      ls_save-fund_flow   =  ls_w_item-fund_flow .
      ls_save-erdat     =  sy-datum .
      ls_save-erzet     =  sy-uzeit .
      ls_save-ernam     =  sy-uname  .

      APPEND ls_save TO et_asn .

    ENDLOOP.
    .
    IF iv_save = abap_true.
      MODIFY ztrv_amt_agn FROM TABLE et_asn .
      IF sy-subrc = 0 .
        COMMIT WORK AND WAIT .
      ELSE.
        ROLLBACK WORK .
        MESSAGE e093(ztr01)  RAISING  err.
      ENDIF.
    ENDIF.


  ENDMETHOD.


METHOD crt_agn_by_witem_20.
    DATA : ls_save LIKE LINE OF et_asn .

    LOOP AT it_w_item INTO DATA(ls_w_item) .
      IF sy-tabix = 1 .
        DATA(lt_item_col) = VALUE  ztrt_amt_agn(  ( zbelnr1 = ls_w_item-zbelnr1 ) ) .
      ELSE.
        lt_item_col = VALUE #( BASE lt_item_col (  zbelnr1 = ls_w_item-zbelnr1 ) ).
      ENDIF.
    ENDLOOP.

* 获取和财务凭证有关的全部周资金计划
    CALL METHOD zcl_tr_3020_gui=>get_total_agn_amt
      EXPORTING
        iv_bukrs = iv_bukrs
        it_agn   = lt_item_col
      IMPORTING
        et_agn   = DATA(lt_agn_db_all).

    IF iv_zmplv IS NOT INITIAL AND lt_agn_db_all IS NOT INITIAL .
      LOOP AT  lt_agn_db_all  INTO DATA(ls_db) .
        SELECT COUNT(*) FROM ztrt3018_01 WHERE bguid = ls_db-bguid AND zmplv < iv_zmplv  AND dflag = space.
        IF sy-subrc <> 0 .
          DELETE lt_agn_db_all .
        ENDIF.
      ENDLOOP.
    ENDIF.

    LOOP AT it_w_item INTO ls_w_item  .

      CALL METHOD zcl_tr_3020_gui=>get_amt_20
        EXPORTING
          i_zbelnr1 = ls_w_item-zbelnr1
        IMPORTING
          e_amt     = DATA(lv_wrbtr).

      IF lv_wrbtr >   0 .
        READ TABLE lt_agn_db_all INTO DATA(ls_agn_all) WITH KEY bukrs = iv_bukrs
                                                                zbelnr1 = ls_w_item-zbelnr1
                                                                BINARY SEARCH .

        IF ( lv_wrbtr < ls_w_item-jhzfe + ls_agn_all-wrbtr_agn AND sy-subrc = 0 )
         OR ( lv_wrbtr < ls_w_item-jhzfe  AND sy-subrc <> 0 ).
          MESSAGE e113(ztr01) WITH ls_w_item-zbelnr1 RAISING  err.
        ENDIF.
      ENDIF.

      ls_save-db_key      =  /bobf/cl_frw_factory=>get_new_key( ) .
      ls_save-bukrs       =  iv_bukrs .
      ls_save-zbelnr1      =  ls_w_item-zbelnr1 .
      ls_save-waers       =  ls_w_item-waers .
      IF ls_w_item-jhzfe >= 0 .
        ls_save-wrbtr_agn   =  ls_w_item-jhzfe .
      ELSE.
        ls_save-wrbtr_agn  = 0 .
      ENDIF.
      ls_save-bguid       =  ls_w_item-bguid  .
      ls_save-witemn      =  ls_w_item-itemn .
      ls_save-fund_flow   =  ls_w_item-fund_flow .
      ls_save-erdat     =  sy-datum .
      ls_save-erzet  =  sy-uzeit .
      ls_save-ernam   =  sy-uname  .


      APPEND ls_save TO et_asn .

    ENDLOOP.
    .
    IF iv_save = abap_true.
      MODIFY ztrv_amt_agn FROM TABLE et_asn .
      IF sy-subrc = 0 .
        COMMIT WORK AND WAIT .
      ELSE.
        ROLLBACK WORK .
        MESSAGE e093(ztr01)  RAISING  err.
      ENDIF.
    ENDIF.


  ENDMETHOD.


METHOD crt_agn_by_witem_21.
    DATA : ls_save LIKE LINE OF et_asn .

    LOOP AT it_w_item INTO DATA(ls_w_item) .
      IF sy-tabix = 1 .
        DATA(lt_item_col) = VALUE  ztrt_amt_agn(  (  gjahr = ls_w_item-gjahr
                                                     belnr = ls_w_item-belnr
                                                     buzei = ls_w_item-buzei
                                                    zbelnr1 = ls_w_item-zbelnr1
                                                    sqdxh = ls_w_item-sqdxh ) ) .
      ELSE.
        lt_item_col = VALUE #( BASE lt_item_col (  gjahr = ls_w_item-gjahr      belnr = ls_w_item-belnr     buzei = ls_w_item-buzei
        zbelnr1 = ls_w_item-zbelnr1 sqdxh = ls_w_item-sqdxh ) ).
      ENDIF.
    ENDLOOP.

* 获取和财务凭证有关的全部周资金计划
    CALL METHOD zcl_tr_3020_gui=>get_total_agn_amt
      EXPORTING
        iv_bukrs = iv_bukrs
        it_agn   = lt_item_col
      IMPORTING
        et_agn   = DATA(lt_agn_db_all).

    IF iv_zmplv IS NOT INITIAL AND lt_agn_db_all IS NOT INITIAL .
      LOOP AT  lt_agn_db_all  INTO DATA(ls_db) .
        SELECT COUNT(*) FROM ztrt3018_01 WHERE bguid = ls_db-bguid AND zmplv < iv_zmplv  AND dflag = space.
        IF sy-subrc <> 0 .
          DELETE lt_agn_db_all  WHERE bguid = ls_db-bguid.
        ENDIF.
      ENDLOOP.
    ENDIF.

    LOOP AT it_w_item INTO ls_w_item  .

      CALL METHOD zcl_tr_3020_gui=>get_amt_21
        EXPORTING
          i_zbelnr1 = ls_w_item-zbelnr1
          i_sqdxh   = ls_w_item-sqdxh
        IMPORTING
          e_amt     = DATA(lv_wrbtr).

      IF lv_wrbtr >   0 .
        READ TABLE lt_agn_db_all INTO DATA(ls_agn_all) WITH KEY bukrs = iv_bukrs
                                                                zbelnr1 = ls_w_item-zbelnr1
                                                                sqdxh = ls_w_item-sqdxh
                                                                BINARY SEARCH .

        IF ( lv_wrbtr < ls_w_item-jhzfe + ls_agn_all-wrbtr_agn AND sy-subrc = 0 )
         OR ( lv_wrbtr < ls_w_item-jhzfe  AND sy-subrc <> 0 ).
          MESSAGE e113(ztr01) WITH ls_w_item-zbelnr1 RAISING  err.
        ENDIF.
      ENDIF.

      ls_save-db_key      =  /bobf/cl_frw_factory=>get_new_key( ) .
      ls_save-bukrs       =  iv_bukrs .
      ls_save-zbelnr1      =  ls_w_item-zbelnr1 .
      ls_save-sqdxh = ls_w_item-sqdxh.

      ls_save-gjahr = ls_w_item-gjahr.
      ls_save-belnr = ls_w_item-belnr.
      ls_save-buzei = ls_w_item-buzei.
      ls_save-waers       =  ls_w_item-waers .
      IF ls_w_item-jhzfe >= 0 .
        ls_save-wrbtr_agn   =  ls_w_item-jhzfe .
      ELSE.
        ls_save-wrbtr_agn  = 0 .
      ENDIF.
      ls_save-bguid       =  ls_w_item-bguid  .
      ls_save-witemn      =  ls_w_item-itemn .
      ls_save-fund_flow   =  ls_w_item-fund_flow .
      ls_save-erdat     =  sy-datum .
      ls_save-erzet  =  sy-uzeit .
      ls_save-ernam   =  sy-uname  .


      APPEND ls_save TO et_asn .
      CLEAR ls_w_item.
    ENDLOOP.
    .
    IF iv_save = abap_true.
      MODIFY ztrv_amt_agn FROM TABLE et_asn .
      IF sy-subrc = 0 .
        COMMIT WORK AND WAIT .
      ELSE.
        ROLLBACK WORK .
        MESSAGE e093(ztr01)  RAISING  err.
      ENDIF.
    ENDIF.


  ENDMETHOD.


METHOD crt_agn_by_witem_30.
    DATA : ls_save LIKE LINE OF et_asn .

    LOOP AT it_w_item INTO DATA(ls_w_item) .
      IF sy-tabix = 1 .
        DATA(lt_item_col) = VALUE  ztrt_amt_agn(  ( billn = ls_w_item-billn  itemn = ls_w_item-bilitmn ) ) .
      ELSE.
        lt_item_col = VALUE #( BASE lt_item_col (  billn = ls_w_item-billn  itemn = ls_w_item-bilitmn  ) ) .
      ENDIF.
    ENDLOOP.

* 获取和财务凭证有关的全部周资金计划
    CALL METHOD zcl_tr_3020_gui=>get_total_agn_amt
      EXPORTING
        iv_bukrs = iv_bukrs
        it_agn   = lt_item_col
      IMPORTING
        et_agn   = DATA(lt_agn_db_all).

    IF iv_zmplv IS NOT INITIAL AND lt_agn_db_all IS NOT INITIAL .
      LOOP AT  lt_agn_db_all  INTO DATA(ls_db) .
        SELECT COUNT(*) FROM ztrt3018_01 WHERE bguid = ls_db-bguid AND zmplv < iv_zmplv  AND dflag = space.
        IF sy-subrc <> 0 .
          DELETE lt_agn_db_all .
        ENDIF.
      ENDLOOP.
    ENDIF.

    LOOP AT it_w_item INTO ls_w_item  .

      CALL METHOD zcl_tr_3020_gui=>get_amt_30
        EXPORTING
          i_billn = ls_w_item-billn
          i_itemn = ls_w_item-bilitmn
        IMPORTING
          e_amt   = DATA(lv_wrbtr).

      IF lv_wrbtr >   0 .
        READ TABLE lt_agn_db_all INTO DATA(ls_agn_all) WITH KEY bukrs = iv_bukrs
                                                                billn =  ls_w_item-billn
                                                                itemn =  ls_w_item-bilitmn
                                                                BINARY SEARCH .

        IF ( lv_wrbtr < ls_w_item-jhzfe + ls_agn_all-wrbtr_agn AND sy-subrc = 0 )
         OR ( lv_wrbtr < ls_w_item-jhzfe  AND sy-subrc <> 0 ).
          MESSAGE e177(ztr01) WITH  ls_w_item-billn ls_w_item-bilitmn   RAISING  err.
        ENDIF.
      ENDIF.

      ls_save-db_key      =  /bobf/cl_frw_factory=>get_new_key( ) .
      ls_save-bukrs       =  iv_bukrs .
      ls_save-billn       =  ls_w_item-billn .
      ls_save-itemn       =  ls_w_item-bilitmn .
      ls_save-waers       =  ls_w_item-waers .
      IF ls_w_item-jhzfe >= 0 .
        ls_save-wrbtr_agn   =  ls_w_item-jhzfe .
      ELSE.
        ls_save-wrbtr_agn  = 0 .
      ENDIF.
      ls_save-bguid       =  ls_w_item-bguid  .
      ls_save-witemn      =  ls_w_item-itemn .
      ls_save-fund_flow   =  ls_w_item-fund_flow .
      ls_save-erdat       =  sy-datum .
      ls_save-erzet       =  sy-uzeit .
      ls_save-ernam       =  sy-uname  .

      APPEND ls_save TO et_asn .

    ENDLOOP.
    .
    IF iv_save = abap_true.
      MODIFY ztrv_amt_agn FROM TABLE et_asn .
      IF sy-subrc = 0 .
        COMMIT WORK AND WAIT .
      ELSE.
        ROLLBACK WORK .
        MESSAGE e093(ztr01)  RAISING  err.
      ENDIF.
    ENDIF.


  ENDMETHOD.


METHOD del_agn_by_witem.
    RETURN .
  ENDMETHOD.


METHOD get_agn.

    IF it_w_item IS NOT INITIAL .
      SELECT * FROM ztrv_amt_agn APPENDING TABLE et_agn
         FOR ALL ENTRIES IN it_w_item
       WHERE bguid  = it_w_item-bguid
         AND witemn = it_w_item-itemn
         AND dflag = abap_false .
    ENDIF.

    IF it_agn IS NOT INITIAL .
      SELECT * FROM ztrv_amt_agn APPENDING TABLE et_agn
       FOR ALL ENTRIES IN it_agn
      WHERE bukrs = it_agn-bukrs
        AND gjahr = it_agn-gjahr
        AND belnr = it_agn-belnr
        AND buzei = it_agn-buzei
        AND zbelnr1 = it_agn-zbelnr1
        AND billn  = it_agn-billn
        AND itemn  = it_agn-itemn
        AND dflag = abap_false .
    ENDIF.


    IF et_agn IS NOT INITIAL .
      SORT et_agn BY db_key .
    ENDIF.

  ENDMETHOD.


METHOD get_agn_amt_by_magn.
    DATA lv_magn TYPE wrbtr .

* 只检查更改剩余支付金额大于0 的项目
    IF iv_sjzfje <= 0.
      ev_magn = iv_sjzfje.
      RETURN.
    ENDIF.

** 1.获取配置表信息  GET_AMTCONTROL_CONF
*    IF   ms_conf03-zkzfs = ''.
*
*      RETURN.
*    ENDIF.
*1.  有关的月资金计划金额
    SELECT SINGLE jhzfe INTO ev_magn
      FROM ztrt3017_01 AS a INNER JOIN ztrt3017_02 AS b
    ON a~bguid = b~bguid
   WHERE   zmplv =   iv_zmplv
      AND  zjjhbb = '01'
      AND  a~bukrs =   iv_bukrs
      AND  gjahr =   iv_gjahr
      AND  belnr =   iv_belnr
      AND  buzei =   iv_buzei
      AND  zbelnr1 =   iv_zbelnr1
      AND  sqdxh  =   iv_sqdxh

      AND  fund_flow  =   iv_flow
      AND  ranl       =   iv_ranl
      AND  sbewart    =   iv_sbewart

      AND a~dflag = space
      AND b~dflag = space.

    IF  ev_magn <= 0  .
      ev_jhzfe = ev_magn .
      RETURN.
    ENDIF.
*2. 有关的周资金计划已占用金额

    SELECT SUM( a~wrbtr_agn ) INTO lv_magn
      FROM ztrv_amt_agn  AS a
     INNER JOIN ztrt3018_02 AS b
        ON a~bguid = b~bguid
        AND a~witemn = b~itemn
      INNER JOIN  ztrt3018_01 AS c
        ON b~bguid = c~bguid
     WHERE  a~dflag = space
        AND b~dflag = space
        AND c~dflag = space
        AND ( b~bcate <> '30' AND bcate <> '31' AND  bcate <> '32'  AND bcate <> '33'  )
        AND c~zmplv =   iv_zmplv
        AND c~zjjhbb = '01'
        AND c~bukrs =   iv_bukrs
        AND c~dflag  =  abap_false
         AND a~gjahr =   iv_gjahr
         AND a~belnr =   iv_belnr
         AND a~buzei =   iv_buzei
         AND a~zbelnr1 =   iv_zbelnr1
          AND  b~fund_flow  =   iv_flow
          AND  ranl       =   iv_ranl
          AND  sbewart    =   iv_sbewart

         AND a~sqdxh =   iv_sqdxh
         AND c~zwkplv < iv_zwkplv
 .
    ev_magn = ev_magn - lv_magn.
    IF iv_sjzfje > ev_magn.
      ev_jhzfe = ev_magn.
    ENDIF.
  ENDMETHOD.


METHOD get_amtcontrol_conf.
    CLEAR ms_conf03.
    SELECT SINGLE * FROM ztrt3018_03
      INTO ms_conf03
      WHERE bukrs = iv_bukrs
      AND zly = ''
      AND fund_flow = ''.


    es_3018_03 = ms_conf03.
  ENDMETHOD.


METHOD get_amt_10.

    SELECT SINGLE
     CASE WHEN  shkzg = 'H' THEN wrbtr WHEN  shkzg = 'S' THEN wrbtr * ( -1 ) END
       AS wrbtr
     FROM bsik INTO @e_amt
    WHERE bukrs = @i_bukrs
      AND belnr = @i_belnr
      AND gjahr = @i_gjahr
      AND buzei = @i_buzei .
**       20190807 hjj change ERDK931274
*       存在: 拉入月计划，但是用预估支付申请拉入上个月的周计划进行付款清账操作，会导致凭证不在bsik中
*       在此情况发生时到bsak 或者 bseg中重新获取凭证金额
    IF sy-subrc NE 0.
      SELECT SINGLE
      CASE WHEN  shkzg = 'H' THEN wrbtr WHEN  shkzg = 'S' THEN wrbtr * ( -1 ) END
      AS wrbtr
      FROM bseg INTO @e_amt
      WHERE  bukrs = @i_bukrs
         AND belnr = @i_belnr
         AND gjahr = @i_gjahr
         AND buzei = @i_buzei .
    ENDIF.
**        20190807 hjj change ERDK931274
  ENDMETHOD.


METHOD get_amt_20.

*      select single
*        case when  shkzg = 'H' then wrbtr when  shkzg = 'S' then wrbtr * ( -1 ) end
*         as wrbtr
*       from bseg into @e_amt
*      where bukrs = @i_bukrs
*        and belnr = @i_belnr
*        and gjahr = @i_gjahr
*        and buzei = @i_buzei .

    SELECT SINGLE zbrtwr6 FROM zrtrt00040 INTO e_amt
      WHERE zbelnr1 = i_zbelnr1.

  ENDMETHOD.


METHOD GET_AMT_21.

*      select single
*        case when  shkzg = 'H' then wrbtr when  shkzg = 'S' then wrbtr * ( -1 ) end
*         as wrbtr
*       from bseg into @e_amt
*      where bukrs = @i_bukrs
*        and belnr = @i_belnr
*        and gjahr = @i_gjahr
*        and buzei = @i_buzei .

    SELECT SINGLE ZFJE_I FROM  ZTRCDSZFSQD_AGN INTO e_amt
      WHERE docno = i_zbelnr1
      AND ITEMNO = i_sqdxh.
      "AND bukrs = i_bukrs.

  ENDMETHOD.


METHOD get_amt_30.

    SELECT SINGLE zygspwrbtr FROM ztrt0031 INTO e_amt
      WHERE billn = i_billn
        AND itemn = i_itemn .

  ENDMETHOD.


METHOD get_amt_clear_10.
    DATA l_wrbtr TYPE wrbtr.
*    SELECT SUM( wrbtr )  INTO E_AMT
*    FROM ztrcds3020a
*    WHERE  bukrs = i_bukrs
*    AND belnr = i_belnr
*    AND gjahr = i_gjahr
*    AND buzei = i_buzei
*    AND rebzg NE space.

*计算非TR支付程序生成的部分支付金额
    "20191128 支付单部分支付上线后，需去除2011,2014程序部分清账 支付凭证生成的凭证，导致重复扣除清账金额
    "2020.2.10 支付单生成的部分清账凭证可能被其他程序清掉，然后用2011清账，导致手工清账凭证存在部分金额已锁定到agn中。要控制，，，或者清账时重新计算agn.
    SELECT  * INTO @DATA(ls_cdsa)"金额为负
      FROM ztrcds3020a
            WHERE bukrs = @i_bukrs
            AND belnr = @i_belnr
            AND gjahr = @i_gjahr
            AND buzei = @i_buzei
            AND rebzg NE @space
            AND rebzg NE 'V'
      .
*      "1.去除期初刷数据的数据
      DATA: lv_clr_zfd TYPE WRBTR.

*      SELECT  SUM( wrbtr_zf ) INTO lv_clr_zfd
*         FROM  ztrtps_clr_2011 AS a
*                         INNER JOIN ztrt2004 AS b ON a~docno = b~docno
*                              "   AND   a~belnr_zf = b~belnr  AND a~gjahr_zf = b~gjahr AND a~buzei_zf = b~buzei
*                     WHERE a~belnr = @ls_cdsa-rebzg
*                      AND  a~gjahr = @ls_cdsa-rebzj
*                      AND  a~bukrs = @ls_cdsa-bukrs
*                      AND  a~docno NE @space
*                      AND a~belnr_r EQ @space
*                     AND b~belnr = @i_belnr
*                     AND b~gjahr = @i_gjahr
*                     AND b~buzei = @i_buzei
        .

      "2.判断部分清账凭证是否在支付单过账记录中,如果在，则不计算。
*      SELECT SINGLE belnr INTO  ls_cdsa-rebzg
*        FROM ztrt2001
*        WHERE belnr =  ls_cdsa-rebzg
*        AND gjahr =  ls_cdsa-rebzj
*        AND bukrs =  ls_cdsa-bukrs .
*      "3 退回过账的支付单的过账凭证不在2001上，记录
*      IF  sy-subrc <> 0.
      SELECT SINGLE a~belnr INTO ls_cdsa-rebzg
        FROM ztrt2000_post AS a
    INNER JOIN ztrt2001 AS b  ON a~docno = b~docno
      WHERE  a~belnr =  ls_cdsa-rebzg
      AND a~gjahr =  ls_cdsa-rebzj
        AND bukrs =  ls_cdsa-bukrs
      AND action in ( 'P','B' ) .
      IF  sy-subrc <> 0.
        e_amt = e_amt + ls_cdsa-wrbtr + lv_clr_zfd.
      ENDIF.
*      ENDIF.
      CLEAR lv_clr_zfd.
      CLEAR ls_cdsa-wrbtr.
    ENDSELECT.
  ENDMETHOD.


METHOD get_magn.

    IF it_w_item IS NOT INITIAL .
      SELECT * FROM ztrv_mamt_agn APPENDING TABLE et_agn
         FOR ALL ENTRIES IN it_w_item
       WHERE bguid  = it_w_item-bguid
         AND witemn = it_w_item-itemn
         AND dflag = abap_false .
    ENDIF.

    IF it_agn IS NOT INITIAL .
      SELECT * FROM ztrv_mamt_agn APPENDING TABLE et_agn
       FOR ALL ENTRIES IN it_agn
      WHERE bukrs = it_agn-bukrs
        AND gjahr = it_agn-gjahr
        AND belnr = it_agn-belnr
        AND buzei = it_agn-buzei
        AND zbelnr1 = it_agn-zbelnr1
        AND billn  = it_agn-billn
        AND itemn  = it_agn-itemn
        AND dflag = abap_false .
    ENDIF.


    IF et_agn IS NOT INITIAL .
      SORT et_agn BY db_key .
    ENDIF.

  ENDMETHOD.


METHOD get_total_agn_amt.


    IF it_agn IS INITIAL . RETURN . ENDIF.
    SELECT * FROM ztrcdsagn
      INTO CORRESPONDING FIELDS OF TABLE et_agn
      FOR ALL ENTRIES IN it_agn
      WHERE bukrs = iv_bukrs
        AND gjahr = it_agn-gjahr
        AND belnr = it_agn-belnr
        AND buzei = it_agn-buzei
        AND zbelnr1 = it_agn-zbelnr1
        AND SQDXH = it_agn-SQDXH
        AND billn = it_agn-billn
        AND itemn = it_agn-itemn .
    IF sy-subrc = 0 .
      SORT et_agn BY bukrs zbelnr1 SQDXH gjahr belnr buzei  billn itemn .
    ENDIF.

  ENDMETHOD.


METHOD get_unagn_amt_10.

*  查询凭证金额
    DATA(ls_agn) = VALUE ztrv_amt_agn(  bukrs  =  iv_bukrs
                                        gjahr  =  iv_gjahr
                                        belnr  =  iv_belnr
                                        buzei  =  iv_buzei ).

    CALL METHOD zcl_tr_3020_gui=>get_amt_10
      EXPORTING
        i_bukrs = iv_bukrs
        i_gjahr = iv_gjahr
        i_belnr = iv_belnr
        i_buzei = iv_buzei
      IMPORTING
        e_amt   = DATA(lv_amt).

*{------** change  部分清账sjzfje需减去已清金额  20190726  ERDK931273 金额为负
    DATA(lv_amt_c) = zcl_tr_3020_gui=>get_amt_clear_10(  " 计算已清金额 不包含支付单过账清账
                                         EXPORTING
                                                 i_bukrs = iv_bukrs
                                                 i_gjahr = iv_gjahr
                                                 i_belnr = iv_belnr
                                                 i_buzei = iv_buzei ).
*}------** change  部分清账需减去已清金额  20190726  ERDK931273
*{------** change  如果是部分清账的凭证，则将金额设置为0
    SELECT SINGLE * INTO @DATA(lv_bsik)
     FROM bsik
     WHERE bukrs = @iv_bukrs
     AND belnr = @iv_belnr
     AND gjahr = @iv_gjahr
     AND buzei = @iv_buzei
     AND rebzg NE '' AND rebzj NE '0000' AND rebzz NE '000'
     AND shkzg = 'S'
      .
    IF  sy-subrc = 0.
*      判断原凭证是否已清,如已清，则此部分清账正常处理
      SELECT SINGLE belnr INTO lv_bsik-rebzg FROM bsik
          WHERE bukrs =  lv_bsik-bukrs
            AND belnr =   lv_bsik-rebzg
            AND gjahr =   lv_bsik-rebzj
            AND buzei =   lv_bsik-rebzz.
      IF sy-subrc = 0.
        e_amt = 0. RETURN.
      ENDIF.
    ENDIF.
*}------** change  如果是部分清账的凭证，则将金额设置为0

*  得到凭证行项目的总的分配金额

    IF  iv_zmplv IS INITIAL .
      SELECT SUM( wrbtr_agn ) FROM ztrcdsagn
        INTO e_amt
        WHERE bukrs = iv_bukrs
          AND gjahr = iv_gjahr
          AND belnr = iv_belnr
          AND buzei = iv_buzei .
    ELSE.
      SELECT SUM( wrbtr_agn ) FROM ztrv_amt_agn AS a INNER JOIN ztrt3018_01 AS h
          ON a~bguid = h~bguid
        INTO e_amt
       WHERE a~bukrs = iv_bukrs
         AND a~gjahr = iv_gjahr
         AND a~belnr = iv_belnr
         AND a~buzei = iv_buzei
         AND a~dflag = space
         AND h~dflag = space
         AND h~zmplv < iv_zmplv
         AND a~jjbilln = space .

      SELECT SUM( wrbtr_agn ) FROM ztrcdsagn02 AS a INNER JOIN ztrt3020_01 AS h
          ON a~jjbilln = h~billn
        INTO @DATA(lv_tmp_amt)
       WHERE a~bukrs = @iv_bukrs
         AND a~gjahr = @iv_gjahr
         AND a~belnr = @iv_belnr
         AND a~buzei = @iv_buzei
         AND h~dflag = @space
         AND h~zmplv < @iv_zmplv .

      e_amt = lv_tmp_amt + e_amt.
    ENDIF.

    IF sy-subrc <> 0 . e_amt = 0 . ENDIF.

**  支付单生成的部分清账凭证可能会被手动清其他的贷方凭证，导致agn金额比部分支付偏大2020.2.11
** 修正值 判断支付凭证是否已清，已清则需释放此金额
*    SELECT b~docno, b~wrbtr_zf  INTO TABLE @DATA(lt_bsak)
*      FROM ztrt2001 AS a INNER JOIN ztrt2004  AS b ON a~docno = b~docno
*                         INNER JOIN bsak AS c ON a~bukrs = c~bukrs
*          AND c~belnr = a~belnr AND a~gjahr = c~gjahr AND b~wrbtr_zf = c~wrbtr
*    WHERE b~belnr = @iv_belnr AND b~buzei = @iv_buzei AND a~gjahr = @iv_gjahr
*        AND a~bukrs = @iv_bukrs AND zzfstatus = '16' AND c~shkzg = 'S'.
*    SORT lt_bsak BY docno.
*    DELETE ADJACENT DUPLICATES FROM lt_bsak COMPARING docno.
*    LOOP AT lt_bsak INTO DATA(ls_bsak).
*      e_amt = e_amt - ls_bsak-wrbtr_zf.
*    ENDLOOP.
*
**  支付单生成的部分清账凭证可能会被手动清其他的贷方凭证，导致agn金额比部分支付偏大2020.2.11
*2020.3.13 注释掉，发现此修正值会导致周资金计划无法创建，因为agnz分配金额超出凭证金额.


    IF iv_bguid  IS INITIAL  AND iv_jjbilln IS INITIAL .  " 为空
      e_amt = lv_amt - e_amt + lv_amt_c.  "凭证未占用额
    ELSEIF    iv_bguid  IS NOT INITIAL .               " 考虑这条记录在表里已经有记录了，修改的时候，考虑增量的影响

      SELECT SINGLE  wrbtr_agn INTO @DATA(lv_wrbtr_agn) FROM ztrcdsagn01
        WHERE bguid  = @iv_bguid
          AND witemn = @iv_itemn .

      IF sy-subrc <> 0 .
        e_amt = lv_amt - e_amt + lv_amt_c.                        "凭证金额 减 占用额度
      ELSE.
        SELECT SUM( wrbtr_agn ) INTO @DATA(lv_copy_wrbtr_agn) FROM ztrv_amt_agn AS a
          INNER JOIN ztrt3018_02 AS b
          ON a~bguid = b~bguid
          AND a~witemn = b~itemn
          INNER JOIN ztrt3018_02 AS c
          ON  c~bguid = b~bguid
          AND c~itemn = b~copyfrom
         WHERE c~bguid  = @iv_bguid
          AND c~itemn = @iv_itemn
          AND c~dflag = @abap_false
          AND b~dflag = @abap_false
          AND a~dflag = @abap_false.

        e_amt = lv_amt - e_amt + lv_wrbtr_agn + lv_copy_wrbtr_agn  + lv_amt_c.
      ENDIF.
    ELSEIF iv_jjbilln IS  NOT INITIAL .
      SELECT SINGLE  wrbtr_agn INTO lv_wrbtr_agn  FROM ztrv_amt_agn
        WHERE jjbilln  = iv_jjbilln
          AND jjitemn  = iv_jjitemn
          AND dflag    = abap_false.

      IF sy-subrc <> 0 .
        e_amt = lv_amt - e_amt  + lv_amt_c .
      ELSE.
        e_amt = lv_amt - e_amt    + lv_wrbtr_agn  + lv_amt_c .
      ENDIF.
    ENDIF.


  ENDMETHOD.


METHOD get_unagn_amt_12.
    DATA lv_amt TYPE wrbtr.
    IF iv_ztr_bpt = '10'.
      DATA(lv_table) = 'BSID'.
    ELSE.
      lv_table = 'BSIK'.
    ENDIF.
*  1.查询凭证金额
    DATA(ls_agn) = VALUE ztrv_amt_agn(  bukrs  =  iv_bukrs
                                        gjahr  =  iv_gjahr
                                        belnr  =  iv_belnr
                                        buzei  =  iv_buzei ).

    SELECT SINGLE
      wrbtr
    FROM (lv_table) INTO @lv_amt
    WHERE bukrs = @iv_bukrs
    AND belnr = @iv_belnr
    AND gjahr = @iv_gjahr
    AND buzei = @iv_buzei
    AND  shkzg = 'H' .
    IF sy-subrc NE 0.
**      SELECT SINGLE wrbtr
**      FROM bseg INTO @lv_amt
**      WHERE  bukrs = @iv_bukrs
**      AND belnr = @iv_belnr
**      AND gjahr = @iv_gjahr
**      AND buzei = @iv_buzei
**      AND  shkzg = 'H'.
      e_amt = 0. RETURN.

    ENDIF.
*2.查询退款通知单金额，以较小的金额为准
    CALL METHOD zcl_tr_3020_gui=>get_amt_21
      EXPORTING
        i_zbelnr1 = iv_zbelnr1
        i_sqdxh   = iv_sqdxh
      IMPORTING
        e_amt     = DATA(lv_amt_tk).
    IF lv_amt_tk < lv_amt.
      lv_amt = lv_amt_tk.
    ENDIF.

*{------** change  如果是部分清账的凭证，则将金额设置为0
    IF iv_ztr_bpt = '20'.

      DATA(lv_amt_c) = zcl_tr_3020_gui=>get_amt_clear_10(  " 计算已清金额 不包含支付单过账清账
      EXPORTING
        i_bukrs = iv_bukrs
        i_gjahr = iv_gjahr
        i_belnr = iv_belnr
        i_buzei = iv_buzei ).

      SELECT SINGLE * INTO @DATA(lv_bsik)
       FROM bsik
       WHERE bukrs = @iv_bukrs
       AND belnr = @iv_belnr
       AND gjahr = @iv_gjahr
       AND buzei = @iv_buzei
       AND rebzg NE '' AND rebzj NE '0000' AND rebzz NE '000'
       AND shkzg = 'S' .
      IF  sy-subrc = 0.
*      判断原凭证是否已清,如已清，则此部分清账正常处理
        SELECT SINGLE belnr INTO lv_bsik-rebzg FROM bsik
            WHERE bukrs =  lv_bsik-bukrs
              AND belnr =   lv_bsik-rebzg
              AND gjahr =   lv_bsik-rebzj
              AND buzei =   lv_bsik-rebzz.
        IF sy-subrc = 0.
          e_amt = 0. RETURN.
        ENDIF.
      ENDIF.
    ENDIF.
*}------** change  如果是部分清账的凭证，则将金额设置为0

*  得到凭证行项目的总的分配金额

    IF  iv_zmplv IS INITIAL .
      SELECT SUM( wrbtr_agn ) FROM ztrcdsagn
        INTO e_amt
        WHERE bukrs = iv_bukrs
          AND gjahr = iv_gjahr
          AND belnr = iv_belnr
          AND buzei = iv_buzei .
    ELSE.
      SELECT SUM( wrbtr_agn ) FROM ztrv_amt_agn AS a INNER JOIN ztrt3018_01 AS h
          ON a~bguid = h~bguid
        INTO e_amt
       WHERE a~bukrs = iv_bukrs
         AND a~gjahr = iv_gjahr
         AND a~belnr = iv_belnr
         AND a~buzei = iv_buzei
         AND a~dflag = space
         AND h~dflag = space
         AND h~zmplv < iv_zmplv
         AND a~jjbilln = space .

      SELECT SUM( wrbtr_agn ) FROM ztrcdsagn02 AS a INNER JOIN ztrt3020_01 AS h
          ON a~jjbilln = h~billn
        INTO @DATA(lv_tmp_amt)
       WHERE a~bukrs = @iv_bukrs
         AND a~gjahr = @iv_gjahr
         AND a~belnr = @iv_belnr
         AND a~buzei = @iv_buzei
         AND h~dflag = @space
         AND h~zmplv < @iv_zmplv .

      e_amt = lv_tmp_amt + e_amt.
    ENDIF.

    IF sy-subrc <> 0 . e_amt = 0 . ENDIF.

    IF iv_bguid  IS INITIAL  AND iv_jjbilln IS INITIAL .  " 为空
      e_amt = lv_amt - e_amt + lv_amt_c.  "凭证未占用额
    ELSEIF    iv_bguid  IS NOT INITIAL .               " 考虑这条记录在表里已经有记录了，修改的时候，考虑增量的影响

      SELECT SINGLE  wrbtr_agn INTO @DATA(lv_wrbtr_agn) FROM ztrcdsagn01
        WHERE bguid  = @iv_bguid
          AND witemn = @iv_itemn .

      IF sy-subrc <> 0 .
        e_amt = lv_amt - e_amt + lv_amt_c.                        "凭证金额 减 占用额度
      ELSE.
        SELECT SUM( wrbtr_agn ) INTO @DATA(lv_copy_wrbtr_agn) FROM ztrv_amt_agn AS a
          INNER JOIN ztrt3018_02 AS b
          ON a~bguid = b~bguid
          AND a~witemn = b~itemn
          INNER JOIN ztrt3018_02 AS c
          ON  c~bguid = b~bguid
          AND c~itemn = b~copyfrom
         WHERE c~bguid  = @iv_bguid
          AND c~itemn = @iv_itemn
          AND c~dflag = @abap_false
          AND b~dflag = @abap_false
          AND a~dflag = @abap_false.

        e_amt = lv_amt - e_amt + lv_wrbtr_agn + lv_copy_wrbtr_agn  + lv_amt_c.
      ENDIF.
    ELSEIF iv_jjbilln IS  NOT INITIAL .
      SELECT SINGLE  wrbtr_agn INTO lv_wrbtr_agn  FROM ztrv_amt_agn
        WHERE jjbilln  = iv_jjbilln
          AND jjitemn  = iv_jjitemn
          AND dflag    = abap_false.

      IF sy-subrc <> 0 .
        e_amt = lv_amt - e_amt  + lv_amt_c .
      ELSE.
        e_amt = lv_amt - e_amt    + lv_wrbtr_agn  + lv_amt_c .
      ENDIF.
    ENDIF.


  ENDMETHOD.


METHOD get_unagn_amt_20.

*  查询凭证金额
    DATA(ls_agn) = VALUE ztrv_amt_agn( zbelnr1  =  iv_zbelnr1 ).

    CALL METHOD zcl_tr_3020_gui=>get_amt_20
      EXPORTING
        i_zbelnr1 = iv_zbelnr1
      IMPORTING
        e_amt     = DATA(lv_amt).

*  得到凭证行项目的总的分配金额
    IF iv_zmplv IS INITIAL .
      SELECT SUM( wrbtr_agn ) FROM ztrcdsagn
        INTO e_amt
        WHERE zbelnr1 = iv_zbelnr1 .
    ELSE.
      SELECT SUM( wrbtr_agn ) FROM ztrv_amt_agn AS a INNER JOIN ztrt3018_01 AS h
        ON a~bguid = h~bguid
      INTO e_amt
     WHERE a~zbelnr1 = iv_zbelnr1
      AND a~dflag = space
      AND h~dflag = space
      AND h~zmplv < iv_zmplv
      AND jjbilln = space.


      SELECT SUM( wrbtr_agn ) FROM ztrv_amt_agn AS a INNER JOIN ztrt3020_01 AS h
          ON a~jjbilln = h~billn
        INTO @DATA(lv_tmp_amt)
       WHERE a~zbelnr1 = @iv_zbelnr1
         AND a~dflag = @space
         AND h~dflag = @space
         AND h~zmplv < @iv_zmplv
         AND a~jjbilln <> @space .

      e_amt = lv_tmp_amt + e_amt.

    ENDIF.

    IF iv_bguid  IS INITIAL  AND iv_jjbilln IS INITIAL . " 为空
      e_amt = lv_amt - e_amt.
    ELSE.                     " 考虑这条记录在表里已经有记录了，修改的时候，考虑增量的影响

      SELECT SINGLE  wrbtr_agn INTO @DATA(lv_wrbtr_agn) FROM ztrv_amt_agn
        WHERE bguid  = @iv_bguid
          AND witemn = @iv_itemn
          AND dflag = @abap_false.

      IF sy-subrc <> 0 .
        e_amt = lv_amt - e_amt.
      ELSEIF iv_bguid IS NOT INITIAL .
        SELECT SUM( wrbtr_agn ) INTO @DATA(lv_copy_wrbtr_agn) FROM ztrv_amt_agn AS a
          INNER JOIN ztrt3018_02 AS b
          ON a~bguid = b~bguid
          AND a~witemn = b~itemn
          INNER JOIN ztrt3018_02 AS c
          ON  c~bguid = b~bguid
          AND c~itemn = b~copyfrom
         WHERE c~bguid  = @iv_bguid
          AND c~itemn = @iv_itemn
          AND c~dflag = @abap_false
          AND b~dflag = @abap_false
          AND a~dflag = @abap_false.

        e_amt = lv_amt - e_amt + lv_wrbtr_agn + lv_copy_wrbtr_agn .
      ELSEIF iv_jjbilln IS NOT INITIAL .
        SELECT SINGLE  wrbtr_agn INTO lv_wrbtr_agn  FROM ztrv_amt_agn
         WHERE jjbilln  = iv_jjbilln
           AND jjitemn  = iv_jjitemn
           AND dflag    = abap_false.

        IF sy-subrc <> 0 .
          e_amt = lv_amt - e_amt.
        ELSE.
          e_amt = lv_amt - e_amt + lv_wrbtr_agn .
        ENDIF.
      ENDIF.
    ENDIF.

  ENDMETHOD.


METHOD GET_UNAGN_AMT_21.

*  查询 金额
 "   DATA(ls_agn) = VALUE ztrv_amt_agn( zbelnr1  =  iv_zbelnr1  sqdxh = IV_SQDXH ).

    CALL METHOD zcl_tr_3020_gui=>get_amt_21
      EXPORTING
        i_zbelnr1 = iv_zbelnr1
        i_sqdxh = IV_SQDXH
      IMPORTING
        e_amt     = DATA(lv_amt).

*  得到凭证行项目的总的分配金额
    IF iv_zmplv IS INITIAL .
      SELECT SUM( wrbtr_agn ) FROM ztrcdsagn
        INTO e_amt
        WHERE zbelnr1 = iv_zbelnr1
           AND sqdxh = IV_SQDXH .
    ELSE.
      SELECT SUM( wrbtr_agn ) FROM ztrv_amt_agn AS a INNER JOIN ztrt3018_01 AS h
        ON a~bguid = h~bguid
      INTO e_amt
     WHERE a~zbelnr1 = iv_zbelnr1
           AND sqdxh = IV_SQDXH
      AND a~dflag = space
      AND h~dflag = space
      AND h~zmplv < iv_zmplv
      AND jjbilln = space.


      SELECT SUM( wrbtr_agn ) FROM ztrv_amt_agn AS a INNER JOIN ztrt3020_01 AS h
          ON a~jjbilln = h~billn
        INTO @DATA(lv_tmp_amt)
       WHERE a~zbelnr1 = @iv_zbelnr1
           AND sqdxh = @IV_SQDXH
         AND a~dflag = @space
         AND h~dflag = @space
         AND h~zmplv < @iv_zmplv
         AND a~jjbilln <> @space .

      e_amt = lv_tmp_amt + e_amt.

    ENDIF.

    IF iv_bguid  IS INITIAL  AND iv_jjbilln IS INITIAL . " 为空
      e_amt = lv_amt - e_amt.
    ELSE.                     " 考虑这条记录在表里已经有记录了，修改的时候，考虑增量的影响

      SELECT SINGLE  wrbtr_agn INTO @DATA(lv_wrbtr_agn) FROM ztrv_amt_agn
        WHERE bguid  = @iv_bguid
          AND witemn = @iv_itemn
          AND dflag = @abap_false.

      IF sy-subrc <> 0 .
        e_amt = lv_amt - e_amt.
      ELSEIF iv_bguid IS NOT INITIAL .
        SELECT SUM( wrbtr_agn ) INTO @DATA(lv_copy_wrbtr_agn) FROM ztrv_amt_agn AS a
          INNER JOIN ztrt3018_02 AS b
          ON a~bguid = b~bguid
          AND a~witemn = b~itemn
          INNER JOIN ztrt3018_02 AS c
          ON  c~bguid = b~bguid
          AND c~itemn = b~copyfrom
         WHERE c~bguid  = @iv_bguid
          AND c~itemn = @iv_itemn
          AND c~dflag = @abap_false
          AND b~dflag = @abap_false
          AND a~dflag = @abap_false.

        e_amt = lv_amt - e_amt + lv_wrbtr_agn + lv_copy_wrbtr_agn .
      ELSEIF iv_jjbilln IS NOT INITIAL .
        SELECT SINGLE  wrbtr_agn INTO lv_wrbtr_agn  FROM ztrv_amt_agn
         WHERE jjbilln  = iv_jjbilln
           AND jjitemn  = iv_jjitemn
           AND dflag    = abap_false.

        IF sy-subrc <> 0 .
          e_amt = lv_amt - e_amt.
        ELSE.
          e_amt = lv_amt - e_amt + lv_wrbtr_agn .
        ENDIF.
      ENDIF.
    ENDIF.

  ENDMETHOD.


METHOD get_unagn_amt_30.

*  查询凭证金额
    DATA(ls_agn) = VALUE ztrv_amt_agn( billn = iv_billn
                                       itemn = iv_bitemn  ).

    CALL METHOD zcl_tr_3020_gui=>get_amt_30
      EXPORTING
        i_billn = iv_billn
        i_itemn = iv_bitemn
      IMPORTING
        e_amt   = DATA(lv_amt).

*  得到凭证行项目的总的分配金额
    IF iv_zmplv IS INITIAL .

      SELECT SUM( wrbtr_agn ) FROM ztrcdsagn
        INTO e_amt
        WHERE billn = iv_billn
          AND itemn = iv_bitemn .
    ELSE.

      SELECT SUM( wrbtr_agn ) FROM ztrv_amt_agn AS a INNER JOIN ztrt3018_01 AS h
        ON a~bguid = h~bguid
      INTO e_amt
     WHERE a~billn = iv_billn
       AND a~itemn = iv_bitemn
       AND a~dflag = space
       AND h~dflag = space
       AND h~zmplv < iv_zmplv
       AND jjbilln = space .

      SELECT SUM( wrbtr_agn ) FROM ztrv_amt_agn AS a INNER JOIN ztrt3020_01 AS h
          ON a~jjbilln = h~billn
        INTO @DATA(lv_tmp_amt)
       WHERE  a~billn = @iv_billn
         AND a~itemn = @iv_bitemn
         AND a~dflag = @space
         AND h~dflag = @space
         AND h~zmplv < @iv_zmplv
         AND a~jjbilln <> @space .

      e_amt = lv_tmp_amt + e_amt.
    ENDIF.

    IF iv_bguid  IS INITIAL .  " 为空
      e_amt = lv_amt - e_amt.
    ELSE.                     " 考虑这条记录在表里已经有记录了，修改的时候，考虑增量的影响

      SELECT SINGLE  wrbtr_agn INTO @DATA(lv_wrbtr_agn) FROM ztrv_amt_agn
        WHERE bguid  = @iv_bguid
          AND witemn = @iv_itemn
          AND dflag = @abap_false.

      IF sy-subrc <> 0 .
        e_amt = lv_amt - e_amt.
      ELSE.
        SELECT SUM( wrbtr_agn ) INTO @DATA(lv_copy_wrbtr_agn) FROM ztrv_amt_agn AS a
          INNER JOIN ztrt3018_02 AS b
          ON a~bguid = b~bguid
          AND a~witemn = b~itemn
          INNER JOIN ztrt3018_02 AS c
          ON  c~bguid = b~bguid
          AND c~itemn = b~copyfrom
         WHERE c~bguid  = @iv_bguid
          AND c~itemn = @iv_itemn
          AND c~dflag = @abap_false
          AND b~dflag = @abap_false
          AND a~dflag = @abap_false.

        e_amt = lv_amt - e_amt + lv_wrbtr_agn + lv_copy_wrbtr_agn .
      ENDIF.
    ENDIF.

  ENDMETHOD.


METHOD get_unagn_amt_a0.

*  查询凭证金额
    DATA(ls_agn) = VALUE ztrv_amt_agn(  bukrs  =  iv_bukrs
                                        gjahr  =  iv_gjahr
                                        belnr  =  iv_belnr
                                        buzei  =  iv_buzei ).

    CALL METHOD zcl_tr_3020_gui=>get_amt_10
      EXPORTING
        i_bukrs = iv_bukrs
        i_gjahr = iv_gjahr
        i_belnr = iv_belnr
        i_buzei = iv_buzei
      IMPORTING
        e_amt   = DATA(lv_amt).

    lv_amt = lv_amt * ( -1 ) .
*  得到凭证行项目的总的分配金额

    IF  iv_zmplv IS INITIAL .
      SELECT SUM( wrbtr_agn ) FROM ztrcdsagn
        INTO e_amt
        WHERE bukrs = iv_bukrs
          AND gjahr = iv_gjahr
          AND belnr = iv_belnr
          AND buzei = iv_buzei .
    ELSE.
      SELECT SUM( wrbtr_agn ) FROM ztrv_amt_agn AS a INNER JOIN ztrt3018_01 AS h
          ON a~bguid = h~bguid
        INTO e_amt
       WHERE a~bukrs = iv_bukrs
         AND a~gjahr = iv_gjahr
         AND a~belnr = iv_belnr
         AND a~buzei = iv_buzei
         AND a~dflag = space
         AND h~dflag = space
         AND h~zmplv < iv_zmplv
         AND a~jjbilln = space .

      SELECT SUM( wrbtr_agn ) FROM ztrv_amt_agn AS a INNER JOIN ztrt3020_01 AS h
          ON a~jjbilln = h~billn
        INTO @DATA(lv_tmp_amt)
       WHERE a~bukrs = @iv_bukrs
         AND a~gjahr = @iv_gjahr
         AND a~belnr = @iv_belnr
         AND a~buzei = @iv_buzei
         AND a~dflag = @space
         AND h~dflag = @space
         AND h~zmplv < @iv_zmplv
         AND jjbilln <> @space .

      e_amt = lv_tmp_amt + e_amt.
    ENDIF.

    IF sy-subrc <> 0 . e_amt = 0 . ENDIF.


    IF iv_bguid  IS INITIAL  .
      e_amt = lv_amt - e_amt.
    ELSEIF    iv_bguid  IS NOT INITIAL .               " 考虑这条记录在表里已经有记录了，修改的时候，考虑增量的影响

      SELECT SINGLE  wrbtr_agn INTO @DATA(lv_wrbtr_agn) FROM ztrv_amt_agn
        WHERE bguid  = @iv_bguid
          AND witemn = @iv_itemn
          AND dflag  = @abap_false.

      IF sy-subrc <> 0 .
        e_amt = lv_amt - e_amt.
      ELSE.
        SELECT SUM( wrbtr_agn ) INTO @DATA(lv_copy_wrbtr_agn) FROM ztrv_amt_agn AS a
          INNER JOIN ztrt3018_02 AS b
          ON a~bguid = b~bguid
          AND a~witemn = b~itemn
          INNER JOIN ztrt3018_02 AS c
          ON  c~bguid = b~bguid
          AND c~itemn = b~copyfrom
         WHERE c~bguid  = @iv_bguid
          AND c~itemn = @iv_itemn
          AND c~dflag = @abap_false
          AND b~dflag = @abap_false
          AND a~dflag = @abap_false.

        e_amt = lv_amt - e_amt + lv_wrbtr_agn + lv_copy_wrbtr_agn .
      ENDIF.
    ENDIF.


  ENDMETHOD.


METHOD lock_agn.

    SELECT SINGLE db_key FROM ztrv_amt_agn
      WHERE bguid = @is_w_item-bguid
        AND witemn = @is_w_item-itemn
        AND dflag = @abap_false
      INTO @DATA(lv_key).

    IF sy-subrc = 0 .
      CALL FUNCTION 'ENQUEUE_EZZTRV_AMT_AGN'
        EXPORTING
          mode_ztrv_amt_agn = 'E'
          db_key            = lv_key
          _scope            = '3'
        EXCEPTIONS
          foreign_lock      = 1
          system_failure    = 2
          OTHERS            = 3.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
          WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD lock_jjagn.

    SELECT SINGLE db_key FROM ztrv_amt_agn
      WHERE jjbilln = @is_w_item-billn
        AND jjitemn = @is_w_item-itemn
        AND dflag = @abap_false
      INTO @DATA(lv_key).

    IF sy-subrc = 0 .
      CALL FUNCTION 'ENQUEUE_EZZTRV_AMT_AGN'
        EXPORTING
          mode_ztrv_amt_agn = 'E'
          db_key            = lv_key
          _scope            = '3'
        EXCEPTIONS
          foreign_lock      = 1
          system_failure    = 2
          OTHERS            = 3.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
          WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD release_agn.
*    IS_W_ITEM  Importing Type  ZTRT3018_02

    CALL METHOD zcl_tr_3019_gui=>lock_witem
      EXPORTING
        iv_bguid = is_w_item-bguid
        iv_itemn = is_w_item-itemn
        iv_agn   = abap_true
      EXCEPTIONS
        err      = 1
        OTHERS   = 2.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
        WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
    ENDIF.

    DATA : lt_item TYPE TABLE OF ztr_s_bgui .
    DATA(ls_item) =  VALUE ztr_s_bgui( bguid = is_w_item-bguid  itemn = is_w_item-itemn ).
    APPEND ls_item TO lt_item.

    DATA lt_rlt TYPE TABLE OF ztr_s_zfje .

    CALL FUNCTION 'ZFM_GET_ZFJE'
      TABLES
        items  = lt_item
        result = lt_rlt.

    et_rlt = lt_rlt.

    DATA: lv_error TYPE  char1,
          lv_msg   TYPE  string.
    LOOP AT lt_rlt INTO DATA(ls_rlt) .
      IF sy-tabix = 1 .
        DATA(lv_amt) = ls_rlt-wrbtr_zf .
      ELSE.
        lv_amt = ls_rlt-wrbtr_zf + lv_amt.
      ENDIF.

      CALL FUNCTION 'ZFM_LOCK_ZTRT2001'
        EXPORTING
          iv_docno = ls_rlt-docno
        IMPORTING
          ev_error = lv_error
          ev_msg   = lv_msg.

      IF lv_error = abap_true .
        MESSAGE  e000(ztr01) WITH lv_msg RAISING err .
      ENDIF.
    ENDLOOP.

    DATA : lt_w_item TYPE TABLE OF ztrt3018_02 .
    DATA : lt_agn TYPE ztrt_amt_agn .
    APPEND is_w_item TO lt_w_item .

    CALL METHOD zcl_tr_3020_gui=>get_agn
      EXPORTING
        it_w_item = lt_w_item
      IMPORTING
        et_agn    = lt_agn.

    READ TABLE lt_agn ASSIGNING FIELD-SYMBOL(<ls_agn>) INDEX 1 .
    IF sy-subrc <> 0 .
      MESSAGE  e000(ztr01) WITH TEXT-e01 RAISING err .  " RELEASE的时候,AGN表是必须有值的
    ENDIF.

    READ TABLE lt_agn ASSIGNING <ls_agn> INDEX 2 .
    IF sy-subrc = 0 .
      MESSAGE  e000(ztr01) WITH TEXT-e01 RAISING err .  " 不可能2条
    ENDIF.

    <ls_agn>-wrbtr_agn = lv_amt.
    <ls_agn>-rflag = abap_true.
    <ls_agn>-aedat = sy-datum .
    <ls_agn>-aezet = sy-uzeit .
    <ls_agn>-aenam = sy-uname.
    MODIFY ztrv_amt_agn FROM TABLE lt_agn.
    IF sy-subrc = 0.
      UPDATE ztrt3018_02 SET zinactive = abap_true WHERE bguid = is_w_item-bguid
                                                     AND itemn = is_w_item-itemn .
    ELSE.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4      RAISING err .
    ENDIF.
    IF iv_commit = abap_true.
      COMMIT WORK AND WAIT .


      CALL METHOD zcl_tr_3019_gui=>unlock_witem
        EXPORTING
          iv_bguid = is_w_item-bguid
          iv_itemn = is_w_item-itemn
          iv_agn   = abap_true
        EXCEPTIONS
          err      = 1
          OTHERS   = 2.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
          WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
      ENDIF.

      LOOP AT lt_rlt INTO ls_rlt .
        CALL FUNCTION 'ZFM_UNLOCK_ZTRT2001'
          EXPORTING
            iv_docno = ls_rlt-docno.
      ENDLOOP.
    ENDIF.
******************释放时同步更新对应的预估申请单状态  20190829************************
    SELECT SINGLE pbilln INTO @DATA(pbilln) FROM ztrt3018_02 WHERE bguid = @is_w_item-bguid
                                                               AND itemn = @is_w_item-itemn .
    IF pbilln IS NOT INITIAL.

      SELECT COUNT(*) INTO @DATA(lv_num) FROM ztrt3018_02 WHERE bguid      = @is_w_item-bguid
                                                             AND pbilln    = @pbilln
                                                             AND zinactive = @abap_false
                                                             AND dflag     = @abap_false.
      IF   lv_num = 0 .
*      OR ( lv_num = 1 AND    iv_commit = abap_false ).
        UPDATE ztrt3019_01 SET  status = '29'
                                dflag  = abap_true
          WHERE billn = pbilln.
      ENDIF.
    ENDIF.
********************释放时同步更新对应的预估申请单状态  20190829**********************

  ENDMETHOD.


METHOD release_agn_zf.

    IF it_w_item IS NOT INITIAL .
      CALL METHOD zcl_tr_3020_gui=>get_agn
        EXPORTING
          it_w_item = it_w_item
        IMPORTING
          et_agn    = DATA(lt_agn).
      SORT lt_agn BY bguid itemn .
    ELSE.
      RETURN .
    ENDIF.


    LOOP AT it_w_item INTO DATA(ls_w_item) .

      READ TABLE lt_agn INTO DATA(ls_agn) WITH KEY bguid = ls_w_item-bguid  witemn = ls_w_item-itemn ."BINARY SEARCH .

      IF sy-subrc <> 0 . CONTINUE. ENDIF.

      IF ls_agn-rflag = abap_true .

        CALL METHOD zcl_tr_3020_gui=>release_agn
          EXPORTING
            is_w_item = ls_w_item
            iv_commit = iv_commit
          EXCEPTIONS
            err       = 1
            OTHERS    = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
        ENDIF.
      ENDIF.
    ENDLOOP.

  ENDMETHOD.


METHOD release_wplan.
    SELECT SINGLE bguid  FROM ztrt3018_01 INTO @DATA(lv_bguid)
     WHERE bukrs = @iv_bukrs  AND  zwkplv = @iv_zwkplv AND status_w = '19' AND dflag = @abap_false AND zjjhbb = '01'.
    IF sy-subrc <> 0 .
*      MESSAGE e459(ztr01) WITH iv_bukrs iv_zwkplv  RAISING  err.
      EXIT.
    ENDIF.

*  选取可能开支付单的程序  逻辑参考程序ZTRE03021

*
    SELECT * FROM ztrt3018_02 AS a
      INTO TABLE  @DATA(lt_02)
     WHERE a~bguid = @lv_bguid
       AND ( ( ( fund_flow LIKE 'B%' OR  fund_flow LIKE 'D%' OR fund_flow = 'ZZ4' OR fund_flow = 'ZZ5' )  AND ( bcate <> 'Z%'  ) )
          OR ( fund_flow LIKE 'F%' AND  bcate <> 'Z%' AND  bcate <> '70' ) )
       AND a~jhzfe     > 0
       AND a~zinactive = @space
       AND a~dflag     = @space .


    LOOP AT lt_02 INTO DATA(ls_02) WHERE jhzfe > 0 .
      IF sy-tabix = 1  .
        DATA(lt_kitem) = VALUE ztrt_s_bgui(  ( bguid = ls_02-bguid itemn = ls_02-itemn ) ) .
      ELSE.
        lt_kitem = VALUE #( BASE lt_kitem ( bguid = ls_02-bguid    itemn = ls_02-itemn ) ) .
      ENDIF.
    ENDLOOP.

*  去有效支付单金额
    DATA : lt_rlt TYPE ztrt_s_zfje .
    CALL FUNCTION 'ZFM_GET_ZFJE'
      TABLES
        items  = lt_kitem
        result = lt_rlt.

    LOOP AT lt_02 INTO ls_02 .
      READ TABLE lt_rlt INTO DATA(ls_rlt) WITH KEY bguid = ls_02-bguid
                                                   itemn = ls_02-itemn.
      IF sy-subrc = 0 AND ls_rlt-wrbtr_zf = ls_02-jhzfe  .
        CONTINUE .   "有支付单且全部用完计划支付金额，就不用释放了
      ENDIF.

      CALL METHOD zcl_tr_3020_gui=>release_agn
        EXPORTING
          is_w_item = ls_02
          iv_commit = 'X'
        EXCEPTIONS
          err       = 1
          OTHERS    = 2.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
          WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
      ENDIF.

    ENDLOOP .




* 获取生成状态的预估支付申请单，作废掉
    SELECT a~billn FROM ztrt3019_01  AS a  INTO @DATA(lv_billn)
          WHERE status = '10' AND zwkplv = @iv_zwkplv AND bukrs = @iv_bukrs.

      UPDATE ztrt3019_01 SET dflag = 'X' status = '29'  aedat = sy-datum  aezet = sy-uzeit aenam = sy-uname WHERE billn = lv_billn.
      UPDATE ztrt3018_02 SET dflag = 'X' WHERE pbilln = lv_billn.

      SELECT * FROM   ztrt3018_02  INTO  ls_02
            WHERE pbilln = lv_billn .
        UPDATE ztrv_amt_agn SET dflag = abap_true wrbtr_agn = 0
        WHERE bguid = ls_02-bguid
        AND witemn = ls_02-itemn.
      ENDSELECT .
    ENDSELECT .

  ENDMETHOD.


METHOD release_wplan_delete_zfd.
    SELECT SINGLE bguid  FROM ztrt3018_01 INTO @DATA(lv_bguid)
     WHERE bukrs = @iv_bukrs  AND  zwkplv = @iv_zwkplv AND status_w = '19' AND dflag = @abap_false AND zjjhbb = '01'.
    IF sy-subrc <> 0 .
*      MESSAGE e459(ztr01) WITH iv_bukrs iv_zwkplv  RAISING  err.
      EXIT.
    ENDIF.
    DATA lt_02 TYPE TABLE OF ztrt3018_02.
*选取作废的支付单再次验证
    SELECT c~bguid  c~itemn
       INTO CORRESPONDING FIELDS OF TABLE  lt_02
       FROM ztrt2001 AS a
      INNER JOIN ztrt2004 AS b  ON a~docno = b~docno
      INNER JOIN ztrt3018_02 AS c  ON b~bguid = c~bguid AND b~zwe_flowd = c~itemn
      INNER JOIN ztrv_amt_agn AS d ON b~bguid = d~bguid AND b~zwe_flowd = d~witemn
      WHERE a~zzfstatus IN ( '21','29','23','31','57','64','65' )
      AND b~bguid = lv_bguid
      AND d~wrbtr_agn > 0
      AND d~rflag = 'X'
      AND c~zinactive = 'X'
      AND c~jhzfe > 0.

    SELECT c~bguid  c~itemn
    APPENDING CORRESPONDING FIELDS OF TABLE  lt_02
    FROM ztrt2001 AS a
    INNER JOIN ztrt2005 AS b  ON a~docno = b~docno
    INNER JOIN ztrt3018_02 AS c  ON b~bguid = c~bguid AND b~zwe_flowd = c~itemn
    INNER JOIN ztrv_amt_agn AS d ON b~bguid = d~bguid AND b~zwe_flowd = d~witemn
    WHERE a~zzfstatus IN ( '21','29','23','31','57','64','65' )
    AND b~bguid = lv_bguid
    AND d~wrbtr_agn > 0
    AND d~rflag = 'X'
    AND c~zinactive = 'X'
    AND c~jhzfe > 0.


    LOOP AT lt_02 INTO DATA(ls_02) WHERE jhzfe > 0 .
      IF sy-tabix = 1  .
        DATA(lt_kitem) = VALUE ztrt_s_bgui(  ( bguid = ls_02-bguid itemn = ls_02-itemn ) ) .
      ELSE.
        lt_kitem = VALUE #( BASE lt_kitem ( bguid = ls_02-bguid    itemn = ls_02-itemn ) ) .
      ENDIF.
    ENDLOOP.

*  去有效支付单金额
    DATA : lt_rlt TYPE ztrt_s_zfje .
    DATA : lt_rlts TYPE ztrt_s_zfje .
    CALL FUNCTION 'ZFM_GET_ZFJE'
      TABLES
        items  = lt_kitem
        result = lt_rlts.
    CLEAR lt_rlt.
    LOOP AT lt_rlts INTO DATA(ls_rlts).
      CLEAR ls_rlts-zzfstatus.
      CLEAR ls_rlts-docno.
      COLLECT ls_rlts INTO lt_rlt.
    ENDLOOP.

    LOOP AT lt_02 INTO ls_02 .
      READ TABLE lt_rlt INTO ls_rlts WITH KEY bguid = ls_02-bguid
                                                   itemn = ls_02-itemn.
      IF sy-subrc = 0 AND ls_rlts-wrbtr_zf = ls_02-jhzfe  .
        CONTINUE .   "有支付单且全部用完计划支付金额，就不用释放了
      ENDIF.

      CALL METHOD zcl_tr_3020_gui=>release_agn
        EXPORTING
          is_w_item = ls_02
          iv_commit = 'X'
        EXCEPTIONS
          err       = 1
          OTHERS    = 2.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
          WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
      ENDIF.

    ENDLOOP .
  ENDMETHOD.


METHOD unlock_agn.
    SELECT  db_key FROM ztrv_amt_agn
     WHERE bguid = @is_w_item-bguid
       AND dflag = @abap_false
      INTO @DATA(lv_key).

      CALL FUNCTION 'DEQUEUE_EZZTRV_AMT_AGN'
        EXPORTING
          mode_ztrv_amt_agn = 'E'
          db_key            = lv_key
          _scope            = '3'.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
          WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
      ENDIF.

    ENDSELECT.
  ENDMETHOD.


METHOD unlock_jjagn.
    SELECT db_key FROM ztrv_amt_agn
     WHERE jjbilln = @is_w_item-billn
       AND dflag = @abap_false
      INTO @DATA(lv_key).

      CALL FUNCTION 'DEQUEUE_EZZTRV_AMT_AGN'
        EXPORTING
          mode_ztrv_amt_agn = 'E'
          db_key            = lv_key
          _scope            = '3'.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
          WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
      ENDIF.

    ENDSELECT .
  ENDMETHOD.
ENDCLASS.
