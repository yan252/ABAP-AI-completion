class ZCL_MESSAGE_COLLECTOR definition
  public
  final
  create public .

public section.

*  types RECEIVER type ref to lcl_receiver .
  data PUBLISHED_MESSAGES type ZTAB_BAPIRET2 .
  constants FULLSCREEN_MODE type CHAR01 value 'A' ##NO_TEXT.
  constants DIALOGBOX_MODE type CHAR01 value 'D' ##NO_TEXT.
  constants INTERNAL_MODE type CHAR01 value 'I' ##NO_TEXT.

  methods CONSTRUCTOR
    importing
      !I_MESSAGE_KEY type ANY
      !I_MAIN_PROGRAM type SYREPID default SY-REPID
      !I_CLASS type SYMSGID .
  methods IMPORT_MESSAGES
    importing
      !IT_MESSAGES type ZTAB_BAPIRET2
      !I_ERROR_REPLACING_TYPE type SYMSGTY optional .
  methods ADD_MESSAGE_SET
    importing
      !IT_MESSAGES type BAPIRET2_T
      !I_ERROR_REPLACING_TYPE type SYMSGTY optional .
  methods ADD_MESSAGE
    importing
      !I_CLASS type SYMSGID optional
      !I_NUMBER type SYMSGNO
      !I_TYPE type SYMSGTY optional
      !I_VAR1 type ANY optional
      !I_VAR2 type ANY optional
      !I_VAR3 type ANY optional
      !I_VAR4 type ANY optional
      !I_ERROR_REPLACING_TYPE type SYMSGTY optional .
  methods APPEND_MESSAGE
    importing
      !IS_BAPIRET2 type BAPIRET2
      !I_ERROR_REPLACING_TYPE type SYMSGTY optional .
  methods PUBLISH_MESSAGES
    importing
      !I_EXCLUDED_TYPE type SYMSGTY optional
      !I_CLEAR_MESSAGE type FLAG optional
      !I_PUBLISHED_MODE type CHAR01 default 'D'
      !I_RESET_STRUCTURE type TABNAME optional
    exporting
      !ET_MESSAGES type ZTAB_BAPIRET2 .
  methods EXPORT_MESSAGE_BAPIRETURN
    returning
      value(RT_RETURN) type BAPIRET2_TAB .
  methods CLEAR_MESSAGES
    importing
      !I_BACKUP type FLAG default SPACE
      !I_RESTORE type FLAG default SPACE
      !I_CLEAR_BACKUP type FLAG default SPACE
    preferred parameter I_BACKUP .
  methods CREATE_MESSAGE_ICON
    returning
      value(R_ICON) type ICON_TEXT .
  methods IF_ERROR
    importing
      !I_BY_ORIGINAL_TYPE type FLAG optional
    returning
      value(R_ERROR) type FLAG .
  methods IF_WARNING
    returning
      value(R_WARNING) type FLAG .
  methods MESSAGES_COPY_FROM_OBJECT
    importing
      !I_CLEAR_OLD type FLAG default SPACE
      !IO_OBJECT type ref to OBJECT
      !I_ERROR_REPLACING_TYPE type SYMSGTY optional
    preferred parameter I_CLEAR_OLD .
  methods BACKUP_MESSAGES
    importing
      !I_CLEAR_MESSAGES type FLAG default SPACE
      !I_CLEAR_BACKUP type FLAG default SPACE
      !I_SUCCESS type FLAG default 'X'
      !I_ERROR type FLAG default 'X'
      !I_WARNING type FLAG default 'X'
      !I_INFORMATION type FLAG default 'X'
      !I_EXCEPTION type FLAG default 'X'
      !I_TERMINATION type FLAG default 'X' .
  methods RESTORE
    importing
      !I_CLEAR_BACKUP type FLAG default SPACE .
  methods CLEAR_BACKUP .
  methods RETURNERROR_FROM_RFC
    importing
      value(I_MESSAGE) type CLIKE
      value(I_SUBRC) type SYSUBRC
      !I_RFC type CLIKE
      !I_RECEIVING type FLAG default SPACE
      !I_ERROR_REPLACING_TYPE type SYMSGTY optional .
  methods RETURN_RFC_MESSAGE
    exporting
      !EX_S_MESSAGE type ZINTF_MESSAGE
      !EX_T_MESSAGES type ZINTF_MESSAGE_TAB .
  methods ADD_SYSTEM_MESSAGE
    importing
      value(IM_S_SYST) type SYST
      !I_ERROR_REPLACING_TYPE type SYMSGTY optional .
  methods COLLECT_INTF_MESSAGES
    importing
      !IM_S_MESSAGE type ZINTF_MESSAGE optional
      !IM_T_MESSAGES type ZINTF_MESSAGE_TAB optional
      !I_ERROR_REPLACING_TYPE type SYMSGTY optional .
  methods CONCATENATE
    importing
      !IM_ONLY_ERROR type FLAG default 'X'
      !IM_SEPERATOR type CHAR01 default '/'
    returning
      value(RE_MSG_STRING) type STRING .
  methods HAS_MESSAGES
    returning
      value(RE_FLAG) type FLAG .
protected section.
private section.

  data CLASS type SYMSGID .
  data PROGRAM type SYREPID .
  data MESSAGE_KEY type CHAR100 .
  constants YES type CHAR01 value 'X' ##NO_TEXT.
  constants NO type CHAR01 value SPACE ##NO_TEXT.
  constants ERROR type SYMSGTY value 'E' ##NO_TEXT.
  constants SUCCESS type SYMSGTY value 'S' ##NO_TEXT.
  constants INFORMATION type SYMSGTY value 'I' ##NO_TEXT.
  constants WARNING type SYMSGTY value 'W' ##NO_TEXT.
  constants TERMINATION type SYMSGTY value 'A' ##NO_TEXT.
  constants EXCEPTION type SYMSGTY value 'X' ##NO_TEXT.
  data MESSAGES type ZTAB_BAPIRET2 .
  data MESSAGES_BACKUP type ZTAB_BAPIRET2 .
  data MESSAGE_COUNT type I .
  data MESSAGE_COUNT_BACKUP type I .
  data DEFAULT_MESSAGE_CLASS type SYMSGID value 'ZCAMESSAGE' ##NO_TEXT.
  data RECEIVER type ref to LCL_RECEIVER .

  methods ADD_MESSAGE_COUNT
    returning
      value(R_COUNT) type I .
  methods CREATE_ICON_BY_TYPE
    importing
      !I_TYPE type MSGTY
    returning
      value(R_ICON) type ICON_TEXT .
  methods COLOR_BY_TYPE
    importing
      !I_TYPE type MSGTY
    returning
      value(R_COLOR) type CHAR04 .
  methods CALL_MESSAGE_DIALOG
    importing
      !I_RESET_STRUCTURE type TABNAME optional .
ENDCLASS.



CLASS ZCL_MESSAGE_COLLECTOR IMPLEMENTATION.


METHOD add_message.
    DATA: lv_class  TYPE symsgid,
          lv_type   TYPE symsgty,
          lv_var1   TYPE syst-msgv1,
          lv_var2   TYPE syst-msgv2,
          lv_var3   TYPE syst-msgv3,
          lv_var4   TYPE syst-msgv4,
          ls_return TYPE bapiret2.

    IF i_class IS SUPPLIED.
      lv_class = i_class.
    ELSE.
      lv_class = class.
    ENDIF.

    IF i_type IS SUPPLIED.
      lv_type = i_type.
    ELSE.
      lv_type = error.
    ENDIF.

    lv_var1 = i_var1.
    lv_var2 = i_var2.
    lv_var3 = i_var3.
    lv_var4 = i_var4.

    CALL FUNCTION 'BALW_BAPIRETURN_GET2'
      EXPORTING
        type   = lv_type
        cl     = lv_class
        number = i_number
        par1   = lv_var1
        par2   = lv_var2
        par3   = lv_var3
        par4   = lv_var4
      IMPORTING
        return = ls_return.

    append_message(
         EXPORTING
           is_bapiret2            = ls_return
           i_error_replacing_type = i_error_replacing_type ).
  ENDMETHOD.


METHOD add_message_count.
    ADD 1 TO message_count.
    r_count = message_count.
  ENDMETHOD.


METHOD add_message_set.
    LOOP AT it_messages INTO data(ls_message).
      append_message(
          EXPORTING
            is_bapiret2            = ls_message
            i_error_replacing_type = i_error_replacing_type ).
    ENDLOOP.

  ENDMETHOD.


METHOD add_system_message.
    add_message(
        i_class                = im_s_syst-msgid
        i_type                 = im_s_syst-msgty
        i_number               = im_s_syst-msgno
        i_var1                 = im_s_syst-msgv1
        i_var2                 = im_s_syst-msgv2
        i_var3                 = im_s_syst-msgv3
        i_var4                 = im_s_syst-msgv4
        i_error_replacing_type = i_error_replacing_type ).
  ENDMETHOD.


METHOD append_message.
    READ TABLE messages TRANSPORTING NO FIELDS
             WITH KEY repid       = program
                      message_key = message_key
                      type        = is_bapiret2-type
                      id          = is_bapiret2-id
                      number      = is_bapiret2-number
                      message_v1  = is_bapiret2-message_v1
                      message_v2  = is_bapiret2-message_v2
                      message_v3  = is_bapiret2-message_v3
                      message_v4  = is_bapiret2-message_v4.
    IF sy-subrc NE 0.
      APPEND INITIAL LINE TO messages ASSIGNING FIELD-SYMBOL(<fs_message>).
      <fs_message>-repid            = program.
      <fs_message>-message_key      = message_key.
      <fs_message>-line_number      = add_message_count( ).
      <fs_message>-return           = is_bapiret2.
      IF <fs_message>-MESSAGE IS INITIAL.
        MESSAGE ID <fs_message>-return-ID
                TYPE is_bapiret2-type
                NUMBER is_bapiret2-number
                WITH is_bapiret2-message_v1
                     is_bapiret2-message_v2
                     is_bapiret2-message_v3
                     is_bapiret2-message_v4
                INTO <fs_message>-MESSAGE.
        ENDIF.
      <fs_message>-color            = color_by_type( <fs_message>-return-type ).
      <fs_message>-original_type    = <fs_message>-type.
      IF i_error_replacing_type IS NOT INITIAL AND
         <fs_message>-type    = error OR
         <fs_message>-type    = exception OR
        <fs_message>-type     = termination.
        <fs_message>-type     = i_error_replacing_type.
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD backup_messages.
*    DATA: ls_message TYPE zstr_bapiret2.
*    DATA: lt_messages TYPE ztab_bapiret2.

    data(lt_messages)          = messages.
    message_count_backup = message_count.

    IF i_clear_messages EQ yes.
*    CLEAR messages.
      clear_messages( ).
    ENDIF.

    IF i_clear_backup EQ yes.
      CLEAR messages_backup.
      CLEAR message_count_backup.
    ENDIF.

    IF i_success EQ no.
      DELETE lt_messages WHERE type EQ success.
    ENDIF.

    IF i_error EQ no.
      DELETE lt_messages WHERE type EQ error.
    ENDIF.

    IF i_warning EQ no.
      DELETE lt_messages WHERE type EQ warning.
    ENDIF.

    IF i_information EQ no.
      DELETE lt_messages WHERE type EQ information.
    ENDIF.

    IF i_exception EQ no.
      DELETE lt_messages WHERE type EQ exception.
    ENDIF.

    IF i_termination EQ no.
      DELETE lt_messages WHERE type EQ termination.
    ENDIF.

    LOOP AT lt_messages INTO data(ls_message).
      READ TABLE messages_backup TRANSPORTING NO FIELDS
                  WITH KEY message_key   = ls_message-message_key
                           repid         = ls_message-repid
                           line_number   = ls_message-line_number
                           type          = ls_message-type
                           id            = ls_message-id
                           number        = ls_message-number
                           message_v1    = ls_message-message_v1
                           message_v2    = ls_message-message_v2
                           message_v3    = ls_message-message_v3
                           message_v4    = ls_message-message_v4.
      IF sy-subrc NE 0.
        APPEND ls_message TO messages_backup.
      ENDIF.
    ENDLOOP.
    FREE lt_messages.
    CHECK messages_backup IS NOT INITIAL.
    SORT messages_backup DESCENDING BY line_number.
    READ TABLE messages_backup INTO ls_message INDEX 1.
    message_count_backup = ls_message-line_number.

  ENDMETHOD.


METHOD call_message_dialog.
    DATA ls_layout TYPE lvc_s_layo.
    DATA: lt_fcat       TYPE lvc_t_fcat,
          lt_fcat_reset TYPE lvc_t_fcat.

    IF receiver->container IS INITIAL.
      CREATE OBJECT receiver->container
        EXPORTING
          width  = 850
          height = 200
          top    = 100
          left   = 300
        EXCEPTIONS
          OTHERS = 1.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
      ENDIF.
      receiver->container->set_visible( EXPORTING visible = yes ).
    ELSE.
      receiver->container->set_visible( EXPORTING visible = yes ).
    ENDIF.

    IF receiver->grid IS INITIAL.
      CALL FUNCTION 'LVC_FIELDCATALOG_MERGE'
        EXPORTING
          i_structure_name       = 'ZSTR_BAPIRET2'
        CHANGING
          ct_fieldcat            = lt_fcat
        EXCEPTIONS
          inconsistent_interface = 1
          program_error          = 2
          OTHERS                 = 3.


      IF i_reset_structure IS NOT INITIAL.
        CALL FUNCTION 'LVC_FIELDCATALOG_MERGE'
          EXPORTING
            i_structure_name       = i_reset_structure
          CHANGING
            ct_fieldcat            = lt_fcat_reset
          EXCEPTIONS
            inconsistent_interface = 1
            program_error          = 2
            OTHERS                 = 3.
        LOOP AT lt_fcat ASSIGNING FIELD-SYMBOL(<fs_fcat>).
          READ TABLE lt_fcat_reset INTO DATA(ls_fcat_reset)
               WITH KEY fieldname = <fs_fcat>-fieldname.
          IF sy-subrc <> 0.
            <fs_fcat>-tech = yes.
            CLEAR <fs_fcat>-col_pos.
          ELSE.
            <fs_fcat>-col_pos = ls_fcat_reset-col_pos.
          ENDIF.
        ENDLOOP.
      ENDIF.

      CREATE OBJECT receiver->grid
        EXPORTING
          i_parent = receiver->container
        EXCEPTIONS
          OTHERS   = 1.

      ls_layout-zebra = abap_true.
      ls_layout-cwidth_opt = abap_true.

      receiver->grid->set_table_for_first_display( EXPORTING is_layout = ls_layout
                                                  i_structure_name = 'ZSTR_BAPIRET2'
                                         CHANGING it_outtab = published_messages
                                                  it_fieldcatalog = lt_fcat ).
      SET HANDLER receiver->on_close FOR receiver->container.

    ELSE.
      CALL METHOD receiver->grid->refresh_table_display.
    ENDIF.
  ENDMETHOD.


METHOD clear_backup.
    CLEAR: messages_backup,
          message_count_backup.
  ENDMETHOD.


METHOD clear_messages.
    IF i_backup EQ no.
      IF i_restore EQ yes.
        restore( i_clear_backup ).
      ELSE.
        IF i_clear_backup EQ yes.
          clear_backup( ).
        ENDIF.
      ENDIF.
      CLEAR: messages,
             message_count.
    ELSE.
      IF i_clear_backup EQ yes.
        clear_backup( ).
      ENDIF.
      backup_messages( ).
      CLEAR: messages,
             message_count.
    ENDIF.
  ENDMETHOD.


METHOD collect_intf_messages.
    DATA: ls_message      TYPE bapiret2.

    IF im_s_message IS NOT INITIAL.
      MOVE-CORRESPONDING im_s_message TO ls_message.
      append_message(
         EXPORTING
           is_bapiret2            = ls_message
           i_error_replacing_type = i_error_replacing_type ).
    ENDIF.

    LOOP AT im_t_messages INTO data(ls_intf_message).
      MOVE-CORRESPONDING ls_intf_message TO ls_message.
      append_message(
          EXPORTING
            is_bapiret2            = ls_message
            i_error_replacing_type = i_error_replacing_type ).
    ENDLOOP.
  ENDMETHOD.


METHOD color_by_type.
    CASE i_type.
      WHEN error OR
           exception OR
           termination.
        r_color = 'C610'.
      WHEN information.
        r_color = 'C410'.
      WHEN warning.
        r_color = 'C310'.
      WHEN success.
        r_color = 'C510'.
    ENDCASE.
  ENDMETHOD.


METHOD concatenate.
    LOOP AT messages INTO DATA(ls_message).
      IF im_only_error = yes.
        CHECK ls_message-type = error OR
              ls_message-type = termination OR
              ls_message-type = exception.
      ENDIF.
      re_msg_string = re_msg_string &&
                      im_seperator &&
                      ls_message-message.
    ENDLOOP.
  ENDMETHOD.


METHOD constructor.
    message_key    = i_message_key.
    program        = i_main_program.
    class          = i_class.
      create OBJECT receiver.
  ENDMETHOD.


METHOD create_icon_by_type.
    DATA: lv_icon_name TYPE icon-name.

    CASE i_type.
      WHEN error.
        lv_icon_name = 'ICON_LED_RED'.
      WHEN warning.
        lv_icon_name = 'ICON_LED_YELLOW'.
      WHEN information.
        lv_icon_name = 'ICON_INFORMATION'.
      WHEN success OR space.
        lv_icon_name = 'ICON_LED_GREEN'.
    ENDCASE.

    CALL FUNCTION 'ICON_CREATE'
      EXPORTING
        name                  = lv_icon_name
      IMPORTING
        result                = r_icon
      EXCEPTIONS
        icon_not_found        = 1
        outputfield_too_short = 2
        OTHERS                = 3.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid
              TYPE sy-msgty
              NUMBER sy-msgno
              WITH sy-msgv1
                   sy-msgv2
                   sy-msgv3
                   sy-msgv4.
    ENDIF.
  ENDMETHOD.


METHOD create_message_icon.
    DATA: lv_type    TYPE bapiret2-type VALUE success.

    LOOP AT messages INTO data(ls_message)
                   WHERE type NE success.
      CASE ls_message-type.
        WHEN error OR
             exception OR
             termination.
          IF lv_type NE error.
            lv_type = error.
          ENDIF.
          EXIT.
        WHEN warning.
          IF lv_type NE warning.
            lv_type = warning.
          ENDIF.
        WHEN information.
          IF lv_type NE information AND
             lv_type NE warning.
            lv_type = information.
          ENDIF.
      ENDCASE.
    ENDLOOP.

    r_icon = create_icon_by_type( lv_type ).
  ENDMETHOD.


METHOD export_message_bapireturn.
    MOVE-CORRESPONDING messages to rt_return.
  ENDMETHOD.


METHOD has_messages.
    IF lines( messages ) > 0.
      re_flag = yes.
    ENDIF.
  ENDMETHOD.


METHOD if_error.
    IF i_by_original_type = no.
      LOOP AT messages TRANSPORTING NO FIELDS
               WHERE type = error
               OR    type = termination
               OR    type = exception.
        r_error = yes.
        EXIT.
      ENDLOOP.
    ELSE.
      LOOP AT messages TRANSPORTING NO FIELDS
               WHERE original_type = error
               OR    original_type = termination
               OR    original_type = exception
               OR    original_type = space.
        r_error = yes.
        EXIT.
      ENDLOOP.
    ENDIF.
  ENDMETHOD.


METHOD if_warning.
    READ TABLE messages TRANSPORTING NO FIELDS
              WITH KEY type = warning.
    IF sy-subrc EQ 0.
      r_warning = yes.
    ENDIF.
  ENDMETHOD.


METHOD import_messages.
    LOOP AT it_messages INTO data(ls_message).

      IF ls_message-original_type IS INITIAL .
        ls_message-original_type = ls_message-type.
      ENDIF.
      IF i_error_replacing_type IS NOT INITIAL AND
        ( ls_message-type = error OR
          ls_message-type = exception OR
          ls_message-type = termination ).
        ls_message-type   = i_error_replacing_type.
      ENDIF.

      READ TABLE messages TRANSPORTING NO FIELDS
                     WITH KEY message_key = ls_message-message_key
                              repid       = ls_message-repid
*                            line_number = ls_message-line_number
                              type        = ls_message-type
                              id          = ls_message-id
                              number      = ls_message-number
                              message_v1  = ls_message-message_v1
                              message_v2  = ls_message-message_v2
                              message_v3  = ls_message-message_v3
                              message_v4  = ls_message-message_v4.
      CHECK sy-subrc NE 0.
      ls_message-line_number = add_message_count( ).
      APPEND ls_message TO messages.
    ENDLOOP.
  ENDMETHOD.


METHOD messages_copy_from_object.
    DATA: lv_publish_method TYPE seocpdname VALUE 'PUBLISH_MESSAGES'.
    DATA: lt_messages TYPE ztab_bapiret2.

    IF i_clear_old EQ yes.
      clear_messages( ).
    ENDIF.

    TRY.
        CALL METHOD io_object->(lv_publish_method)
          EXPORTING
            i_published_mode = internal_mode
          IMPORTING
            et_messages      = lt_messages.
      CATCH cx_sy_dyn_call_error INTO data(lo_exc_ref).
*  TECHICAL ERROR
*  SHOULD BE AVOID BY TESTING
        MESSAGE lo_exc_ref->get_text( ) TYPE 'I'.
    ENDTRY.

    IF lt_messages IS NOT INITIAL.
      import_messages(
         EXPORTING
           it_messages            = lt_messages
           i_error_replacing_type = i_error_replacing_type ).
    ENDIF.
  ENDMETHOD.


METHOD publish_messages.
*    FIELD-SYMBOLS <message> TYPE zstr_bapiret2.


    published_messages = messages.

    LOOP AT published_messages ASSIGNING FIELD-SYMBOL(<message>).
      <message>-color   = color_by_type( <message>-type ).
      <message>-icon    = create_icon_by_type( <message>-type ).
    ENDLOOP.
    IF i_excluded_type IS NOT INITIAL.
      DELETE published_messages
             WHERE type = i_excluded_type.
    ENDIF.

    IF i_clear_message EQ yes.
      CLEAR messages.
    ENDIF.

    IF published_messages IS INITIAL.
      IF i_published_mode NE internal_mode.
        MESSAGE 'No publishable messages......'(001)
                TYPE success.
      ENDIF.
      EXIT.
    ENDIF.

    SORT published_messages BY line_number.

    CASE i_published_mode.
      WHEN dialogbox_mode or fullscreen_mode.
*        CALL FUNCTION 'ZDISPLAY_MESSAGE_DIALOG'
*          EXPORTING
*            i_mode      = i_published_mode
*            i_structure = 'ZSTR_BAPIRET2'
*            it_messages = published_messages.
        call_message_dialog(
             EXPORTING
               i_reset_structure = i_reset_structure ).
      WHEN internal_mode.
        et_messages = published_messages.
    ENDCASE.
    FREE published_messages.

  ENDMETHOD.


METHOD restore.
    messages      = messages_backup.
    message_count = message_count_backup.
    IF i_clear_backup EQ yes.
      clear_backup( ).
    ENDIF.
  ENDMETHOD.


METHOD returnerror_from_rfc.
    IF i_receiving EQ yes.
      DATA(lv_process) = 'RECEIVING'.
    ELSE.
      lv_process = 'CALLING'.
    ENDIF.
    IF i_message IS NOT INITIAL.
      IF 1 EQ 2.
        MESSAGE e016(zcamessage) WITH i_message lv_process i_rfc.
      ELSE.
        add_message(
                  i_class                = 'ZCAMESSAGE'
                  i_type                 = error
                  i_number               = '016'
                  i_var1                 = i_message
                  i_var2                 = lv_process
                  i_var3                 = i_rfc
                  i_error_replacing_type = i_error_replacing_type ).
      ENDIF.
    ELSE.
      IF i_subrc NE 0.
        IF 1 EQ 2.
          MESSAGE e017(zcamessage) WITH i_subrc lv_process i_rfc.
        ELSE.
          add_message(
                    i_class                = 'ZCAMESSAGE'
                    i_type                 = error
                    i_number               = '017'
                    i_var1                 = i_subrc
                    i_var2                 = lv_process
                    i_var3                 = i_rfc
                    i_error_replacing_type = i_error_replacing_type ).
        ENDIF.
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD return_rfc_message.

    MOVE-CORRESPONDING messages TO ex_t_messages.

    IF if_error( ) = yes.
      ex_s_message-type        = error.
      ex_s_message-id          = default_message_class.
      ex_s_message-number      = '000'(001).
      MESSAGE e000 INTO ex_s_message-message.
    ELSE.
      ex_s_message-type        = success.
      ex_s_message-id          = default_message_class.
      ex_s_message-number      = '001'.
      MESSAGE e001 INTO ex_s_message-message.
    ENDIF.
  ENDMETHOD.
ENDCLASS.
