class ZCL_CITIC_ENHANCEMENT definition
  public
  final
  create public .

public section.

  class-methods SET_CITYFLAG
    importing
      !IM_S_FPAYH type FPAYH
    returning
      value(RE_VALUE) type CHAR01 .
  class-methods SET_PAY_TYPE
    importing
      !IM_S_FPAYH type FPAYH
    returning
      value(RE_VALUE) type CHAR02 .
  class-methods SET_CITIC_BANKFLAG
    importing
      !IM_S_FPAYH type FPAYH
    returning
      value(RE_VALUE) type CHAR01 .
  class-methods CONVERT_DEBIT_AND_CREDIT_FLAG
    importing
      !IM_CITIC_VALUE type CLIKE
    returning
      value(RE_SAP_VALUE) type SHKZG .
  class-methods GET_USER_NAME
    returning
      value(RE_USER_NAME) type EPIC_BC_USER .
protected section.
private section.
ENDCLASS.



CLASS ZCL_CITIC_ENHANCEMENT IMPLEMENTATION.


METHOD CONVERT_DEBIT_AND_CREDIT_FLAG.
    CASE im_citic_value.
      WHEN 'D'.
*        银行借方相当于企业贷方
        re_sap_value = 'H'.
      WHEN 'C'.
*        银行贷方相当于企业借方
        re_sap_value = 'S'.
    ENDCASE.
  ENDMETHOD.


METHOD get_user_name.
*    SELECT SINGLE guid
*           INTO @DATA(l_guid)
*           FROM ztrt_bank_ass
*           WHERE bank_ind = 'CITIC'.
*    IF sy-subrc <> 0.
*      RETURN.
*    ENDIF.
*
*    DATA(lo_user) = NEW cl_epic_bank_comm_logon( l_guid ).
*
*    TRY.
*        re_user_name = lo_user->get_commuser( ).
*      CATCH cx_epic_bank_comm_logon.
*    ENDTRY.
    CALL FUNCTION 'ZFM_TR_BANK_LOGON_USER'
      EXPORTING
        im_bank_indicator = 'CITIC'
      IMPORTING
        ex_user           = re_user_name.

  ENDMETHOD.


method SET_CITIC_BANKFLAG.
    IF zcl_bank_cnaps_code=>if_same_bank(
                              EXPORTING
                                im_code1 = im_s_fpayh-zbnky
                                im_code2 = im_s_fpayh-bnkl1 ) = 'X'.
      re_value = '0'. "中信
    ELSE.
      re_value = '1'. "他行
    ENDIF.
  endmethod.


METHOD set_cityflag.

    IF zcl_bank_cnaps_code=>if_same_bank(
                              EXPORTING
                                im_code1 = im_s_fpayh-zbnky
                                im_code2 = im_s_fpayh-bnkl1 ) = 'X'.
*   中信同行不设置
      CLEAR re_value.
    ELSE.
      IF zcl_bank_cnaps_code=>if_same_city(
                                    EXPORTING
                                      im_code1 = im_s_fpayh-zbnky
                                      im_code2 = im_s_fpayh-bnkl1 ) = 'X'.
        re_value = '0'. "同城”
      ELSE.
        re_value = '1'." 异地
      ENDIF.
    ENDIF.

  ENDMETHOD.


METHOD set_pay_type.
*    IF im_s_fpayh-rwbtr <= '50000.00'.
*      IF zcl_bank_cnaps_code=>if_same_bank(
*                                EXPORTING
*                                  im_code1 = im_s_fpayh-zbnky
*                                  im_code2 = im_s_fpayh-bnkl1 ) = 'X'.
***      中信内部转账：收款账户必须为中信银行的公司账户，交易实时到账。手续费同城免费，
***      异地视金额大小收取5.5至200.5元。
*        re_value = '01'. "中信行内
*      ELSE.
*** 小额支付：收款账户必须为非中信银行的他行账户，交易金额限5万元以下（含5万）。
***小额支付方式7×24小时开放。资金非实时清算，而是每天4次定时汇总组包发出，
***或累积一定数量后组包发出。手续费每笔1元。
*        re_value = '03'. "小额支付
*      ENDIF.
*    ELSE.
*      IF zcl_bank_cnaps_code=>if_same_bank(
*                                EXPORTING
*                                  im_code1 = im_s_fpayh-zbnky
*                                  im_code2 = im_s_fpayh-bnkl1 ) = 'X'.
***      中信内部转账：收款账户必须为中信银行的公司账户，交易实时到账。手续费同城免费，
***      异地视金额大小收取5.5至200.5元。
*        re_value = '01'. "中信行内
*      ELSE.
**          大额支付：收款账户必须为非中信银行的他行账户，仅在工作日9点至17点开放，
**          资金实时清算到对方账户开户行，不限金额大小。手续费视金额大小收取5.5至200.5元。
**          另外，直联系统大额系统开放时间与柜台是同步的，偶尔情况下，
**          柜台受理大额业务的系统开放时间会比9点略有延后，此时提交直联交易会交易失败。
**          如某时点柜台已经可以受理大额交易，则直联交易也不会有任何问题。
*        re_value = '03'. "大额支付
*      ENDIF.
*    ENDIF.

************************************************************
**20181126:中信银行采用了新的转账支付接口，PAYTYPE也做了调整
************************************************************
    IF zcl_bank_cnaps_code=>if_same_bank(
                              EXPORTING
                                im_code1 = im_s_fpayh-zbnky
                                im_code2 = im_s_fpayh-bnkl1 ) = 'X'.
      re_value = zif_citic_constants=>same_bank.
    ELSE.
      re_value = zif_citic_constants=>cross_bank.
    ENDIF.
  ENDMETHOD.
ENDCLASS.
