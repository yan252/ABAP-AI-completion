FUNCTION-POOL ZTRT9011                   MESSAGE-ID SV.

* INCLUDE LZTRT9011D...                      " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZTRT9011T00                            . "view rel. data dcl.
