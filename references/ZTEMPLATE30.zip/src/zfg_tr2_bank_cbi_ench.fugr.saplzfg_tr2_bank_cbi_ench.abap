*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_TR2_BANK_CBI_ENCHTOP.         " Global Declarations
  INCLUDE LZFG_TR2_BANK_CBI_ENCHUXX.         " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_TR2_BANK_CBI_ENCHF...         " Subroutines
* INCLUDE LZFG_TR2_BANK_CBI_ENCHO...         " PBO-Modules
* INCLUDE LZFG_TR2_BANK_CBI_ENCHI...         " PAI-Modules
* INCLUDE LZFG_TR2_BANK_CBI_ENCHE...         " Events
* INCLUDE LZFG_TR2_BANK_CBI_ENCHP...         " Local class implement.
* INCLUDE LZFG_TR2_BANK_CBI_ENCHT99.         " ABAP Unit tests

INCLUDE lzfg_tr2_bank_cbi_enchf01.
