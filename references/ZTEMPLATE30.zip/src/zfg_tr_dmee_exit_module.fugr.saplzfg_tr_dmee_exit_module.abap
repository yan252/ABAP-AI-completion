*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_TR_DMEE_EXIT_MODULETOP.       " Global Declarations
  INCLUDE LZFG_TR_DMEE_EXIT_MODULEUXX.       " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_TR_DMEE_EXIT_MODULEF...       " Subroutines
* INCLUDE LZFG_TR_DMEE_EXIT_MODULEO...       " PBO-Modules
* INCLUDE LZFG_TR_DMEE_EXIT_MODULEI...       " PAI-Modules
* INCLUDE LZFG_TR_DMEE_EXIT_MODULEE...       " Events
* INCLUDE LZFG_TR_DMEE_EXIT_MODULEP...       " Local class implement.
* INCLUDE LZFG_TR_DMEE_EXIT_MODULET99.       " ABAP Unit tests
