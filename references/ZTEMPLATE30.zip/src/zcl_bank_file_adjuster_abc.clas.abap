class ZCL_BANK_FILE_ADJUSTER_ABC definition
  public
  inheriting from ZCL_BANK_FILE_ADJUSTER
  final
  create public .

public section.

  class-methods GET_PAYMENT_FILES_LENGTH
    importing
      !CH_DATA type ZTRS_BANK_SENDING_FILE_TAB
    exporting
      !LENTH type I .

  methods ZIF_SENDING_FILE_ADJUSTER~ADJUST
    redefinition .
  methods ZIF_RESPONSE_FILE_ADJUSTER~ADJUST
    redefinition .
protected section.
private section.
ENDCLASS.



CLASS ZCL_BANK_FILE_ADJUSTER_ABC IMPLEMENTATION.


METHOD get_payment_files_length.

    LOOP AT ch_data ASSIGNING FIELD-SYMBOL(<fs_sending_file>).
      ASSIGN <fs_sending_file>-cfile->* TO FIELD-SYMBOL(<f_string>).

      lenth = lenth + strlen( <f_string> ).

    ENDLOOP.

  ENDMETHOD.


METHOD zif_response_file_adjuster~adjust.
*CALL METHOD SUPER->ZIF_RESPONSE_FILE_ADJUSTER~ADJUST
*  EXPORTING
*    IM_ACTION         =
*    IM_STEP           =
*    IM_ORIGINAL_CDATA =
*    IM_ORIGINAL_XDATA =
**  IMPORTING
**    ex_t_return       =
**    ex_cdata          =
**    ex_xdata          =
*    .

    DATA:cr(8),
         st(2).
    ex_cdata = im_original_cdata.
    st = ex_cdata+0(2) .
    cr = ex_cdata+2(7) .
    REPLACE ex_cdata+0(10) WITH '' INTO ex_cdata.
    SHIFT ex_cdata LEFT DELETING LEADING space.

*    CALL FUNCTION 'SCMS_STRING_TO_XSTRING'
*      EXPORTING
*        text   = ex_cdata
*      IMPORTING
*        buffer = ex_xdata
*      EXCEPTIONS
*        failed = 1
*        OTHERS = 2.

    "  ex_xdata = im_original_xdata.
ex_xdata = ex_cdata.

  ENDMETHOD.


METHOD zif_sending_file_adjuster~adjust.

*    DATA:lenth   TYPE i,
*         ln      TYPE i,
*         ln1     TYPE i,
*         t(1),
*         st      TYPE char2000,
*         st2     TYPE char2000,
*         st3(20),
*         st1(20),
*         lt(7) .
*
*    get_payment_files_length(
*      EXPORTING
*        ch_data = ch_data
*      IMPORTING
*        lenth = lenth
*       ).
**
**    CASE im_action.
**      WHEN '001'.
***        支付业务
***
**        lt = '1' && lenth.
**
**      WHEN OTHERS.
***        其他业务，目前一般是查询类
**        lt = '0' && lenth.
**    ENDCASE.
**
**    CONDENSE lt NO-GAPS.
**
**    ln = strlen( lt ).
*
*    LOOP AT ch_data  ASSIGNING FIELD-SYMBOL(<fs_sending_file>) .
*
*      ASSIGN <fs_sending_file>-xfile->* TO FIELD-SYMBOL(<f_xstring>).
*
**      IF t IS INITIAL.
*      ASSIGN <fs_sending_file>-cfile->* TO FIELD-SYMBOL(<f_string>).
*      st = <f_string>.
*      REPLACE '<?xml' WITH ''  INTO st LENGTH 50.
*      REPLACE 'version="1.0"' WITH ''  INTO st LENGTH 50.
*      REPLACE 'encoding="utf-16"' WITH ''  INTO st LENGTH 50.
*      REPLACE '?>' WITH ''  INTO st LENGTH 50.
*      st1 = st+0(20).
*      st2 = st+20(1980).
*      SHIFT st1 LEFT  DELETING LEADING  ''.
*      CONDENSE st1.
*      st3 = st1+2(16).
*
**        IF ln < 7.
**          ln1 = ln - 1.
**          lt+6(1) = 'A'.
**          st = lt && st3 && st2.
**          REPLACE 'A' WITH ''  INTO st LENGTH 7.
**          <f_string> = st.
**
**        ELSEIF ln = 7.
**          st = lt && st3 && st2.
**          <f_string> = st.
**
**        ENDIF.
**        t = 'A'.
**      ENDIF.
*      st =  st3 && st2.
*      <f_string> = st.
*      CLEAR:<f_xstring>.    "
*      CALL FUNCTION 'SCMS_STRING_TO_XSTRING'
*        EXPORTING
*          text   = <f_string>
*        IMPORTING
*          buffer = <f_xstring>
*        EXCEPTIONS
*          failed = 1
*          OTHERS = 2.
*
*    ENDLOOP.

  ENDMETHOD.
ENDCLASS.
