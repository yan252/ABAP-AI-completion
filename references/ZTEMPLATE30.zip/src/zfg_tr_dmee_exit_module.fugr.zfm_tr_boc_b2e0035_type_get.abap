FUNCTION ZFM_TR_BOC_B2E0035_TYPE_GET.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     VALUE(I_TREE_TYPE) TYPE  DMEE_TREETYPE_ABA
*"     VALUE(I_TREE_ID) TYPE  DMEE_TREEID_ABA
*"     VALUE(I_ITEM)
*"     VALUE(I_PARAM)
*"     VALUE(I_UPARAM)
*"  EXPORTING
*"     REFERENCE(O_VALUE)
*"     REFERENCE(C_VALUE)
*"     REFERENCE(N_VALUE)
*"     REFERENCE(P_VALUE)
*"  TABLES
*"      I_TAB
*"--------------------------------------------------------------------
ASSIGN COMPONENT 'ZTRS_DMEE_ACCOUNT_LIST-START_DATE' OF STRUCTURE i_item TO FIELD-SYMBOL(<f_date>).

  c_value = zcl_boc_enhancement=>get_b2e0035_checking_type( <f_date> ).





ENDFUNCTION.
