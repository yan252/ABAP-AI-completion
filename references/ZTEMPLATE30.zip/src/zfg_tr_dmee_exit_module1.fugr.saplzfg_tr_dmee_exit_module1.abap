*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_TR_DMEE_EXIT_MODULE1TOP.      " Global Declarations
  INCLUDE LZFG_TR_DMEE_EXIT_MODULE1UXX.      " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_TR_DMEE_EXIT_MODULE1F...      " Subroutines
* INCLUDE LZFG_TR_DMEE_EXIT_MODULE1O...      " PBO-Modules
* INCLUDE LZFG_TR_DMEE_EXIT_MODULE1I...      " PAI-Modules
* INCLUDE LZFG_TR_DMEE_EXIT_MODULE1E...      " Events
* INCLUDE LZFG_TR_DMEE_EXIT_MODULE1P...      " Local class implement.
* INCLUDE LZFG_TR_DMEE_EXIT_MODULE1T99.      " ABAP Unit tests
