class ZCL_BANK_BOC_B2E0001 definition
  public
  inheriting from ZCL_ABSTRACT_BANK_FUNCTION
  final
  create public .

public section.

  interfaces ZIF_BOC_FUNCTION .

  methods GET_CURRENT_TOKEN
    returning
      value(RS_TOKEN) type ZTRT_BOC_TOKEN .
  methods CONVERT_TOKEN_TO_DB_FORMAT .

  methods ZIF_BANK_FUNCTION~GET_RESPONSE_HEADER_STATUS
    redefinition .
  methods ZIF_BANK_FUNCTION~IF_STOP
    redefinition .
  methods ZIF_BANK_FUNCTION~SET_SENDING_DATA_REFERENCE
    redefinition .
protected section.

  methods CONVERT_DATA_TO_DMEE_TYPE
    redefinition .
  methods PROCESS_RESPONSE_INTERNAL
    redefinition .
private section.

  aliases RAISE_B2EERROR
    for ZIF_BOC_FUNCTION~RAISE_B2EERROR .

  data TOKEN type ZTRT_BOC_TOKEN .

  methods LOCK_TOCKEN .
  methods DELOCK_TOCKEN .
  methods IF_TOCKEN_REQUIRE
    returning
      value(RE_REQUIRE) type FLAG .
ENDCLASS.



CLASS ZCL_BANK_BOC_B2E0001 IMPLEMENTATION.


  METHOD convert_data_to_dmee_type.

    FIELD-SYMBOLS: <ft_b2e0001>   TYPE STANDARD TABLE,
                   <ft_dmee_data> TYPE STANDARD TABLE,
                   <fs_b2e0001>   TYPE ztrs_boc_token_request_medium.

    CREATE DATA re_dmee_table_ref TYPE ztrs_boc_b2e0001_request_tab.

    ASSIGN re_dmee_table_ref->* TO <ft_dmee_data>.

    APPEND INITIAL LINE TO <ft_dmee_data> ASSIGNING FIELD-SYMBOL(<fs_dmee_data>).
    ASSIGN COMPONENT 'ZTRS_BOC_TOKEN_REQUEST' OF STRUCTURE <fs_dmee_data> TO FIELD-SYMBOL(<fs_request>).

    ASSIGN sending_data_reference->* TO <ft_b2e0001>.
    READ TABLE <ft_b2e0001> INDEX 1 ASSIGNING <fs_b2e0001>.

    MOVE-CORRESPONDING <fs_b2e0001> TO <fs_request>.
*
  ENDMETHOD.


  METHOD convert_token_to_db_format.
    FIELD-SYMBOLS: <fs_response> TYPE ztrs_boc_b2e0001_response.

    DATA(ls_response) = get_current_response_data( ).

    ASSIGN ls_response-response_ref->* TO <fs_response>.

    token-bank_ind = bank_indicator.
    token-cusopr = <fs_response>-head-cusopr.
    token-termid = <fs_response>-head-termid.
    token-custid = <fs_response>-head-custid.
    token-cusopr = <fs_response>-head-cusopr.
    token-token = <fs_response>-head-token.
    token-serverdt = <fs_response>-trans-serverdt.

    MODIFY ztrt_boc_token FROM token.
    COMMIT WORK AND WAIT .

    delock_tocken( ).
  ENDMETHOD.


  METHOD delock_tocken.
    CALL FUNCTION 'DEQUEUE_EZTRT_BOC_TOKEN'
      EXPORTING
        mode_ztrt_boc_token = 'E'
        mandt               = sy-mandt
        bank_ind            = bank_indicator
        x_bank_ind          = ' '
        _scope              = '3'
        _synchron           = ' '
        _collect            = ' '.
  ENDMETHOD.


  METHOD GET_CURRENT_TOKEN.
    rs_token = token.
  ENDMETHOD.


  METHOD if_tocken_require.
    DATA: l_timestamp TYPE timestampl.
    DATA: l_old_date TYPE sydatum,
          l_old_time TYPE syuzeit.
*    中国银行签到间隔建议为15分钟（900秒）,但考虑到程序运行可能需要一些是时间
*    我们将这个间隔调小一点
    DATA: l_boc_tocken_interval TYPE i VALUE 800.

    SELECT SINGLE * INTO token
            FROM ztrt_boc_token
            WHERE bank_ind = bank_indicator.
    IF sy-subrc <> 0.
*      需要重新签到
      re_require = yes.
      RETURN.
    ENDIF.

    l_old_date = token-serverdt+0(8).
    l_old_time = token-serverdt+8(6).

    cl_abap_tstmp=>td_subtract(
                      EXPORTING
                        date1 = sy-datum
                        time1 = sy-uzeit
                        date2 = l_old_date
                        time2 = l_old_time
                      IMPORTING
                        res_secs = DATA(l_differece) ).
*****正常来说l_differece不会小于零
    IF l_differece < 0 OR
       l_differece >= l_boc_tocken_interval.
*      需要重新签到
      re_require = yes.
    ELSE.
*        不需要重新签到
      re_require = no.
    ENDIF.
  ENDMETHOD.


  METHOD lock_tocken.
    DATA: l_lock_by_other TYPE flag,
          ls_syst         TYPE syst.
    DO 300 TIMES.
      CALL FUNCTION 'ENQUEUE_EZTRT_BOC_TOKEN'
        EXPORTING
          mode_ztrt_boc_token = 'E'
          mandt               = sy-mandt
          bank_ind            = bank_indicator
          x_bank_ind          = ' '
          _scope              = '2'
          _wait               = ' '
          _collect            = ' '
        EXCEPTIONS
          foreign_lock        = 1
          system_failure      = 2
          OTHERS              = 3.
      IF sy-subrc <> 0.
        ls_syst = sy.
        l_lock_by_other = yes.
        WAIT UP TO 1 SECONDS."等待别热的解锁
      ELSE.
*      当前session锁定
        CLEAR ls_syst.
        l_lock_by_other = no.
        EXIT.
      ENDIF.

    ENDDO.

    IF l_lock_by_other = yes.
*  等待了300秒都无法锁定，报错
      MESSAGE ID ls_syst-msgid
              TYPE ls_syst-msgno
              NUMBER ls_syst-msgno
              WITH ls_syst-msgv1
                   ls_syst-msgv2
                   ls_syst-msgv3
                   ls_syst-msgv4
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = instance_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator
                        bank_func    = function_config-bank_func
                        step         = step ) ).
    ENDIF.
  ENDMETHOD.


  METHOD process_response_internal.
    super->process_response_internal( ).
    boc_response_header.

    FIELD-SYMBOLS:<fs_boc_header_status> TYPE ztrs_boc_header_res_status.

    ASSIGN COMPONENT 'H_STATUS' OF STRUCTURE <fs_response> TO <fs_boc_header_status>.

    IF zcl_bank_enviroment=>create(
                                     im_bank_indicator = bank_indicator
                                     im_action = action )->get_bank_return_code_type(
                                                                im_bank_func =  <f_transaction>
                                                                im_return_code =  <fs_boc_header_status>-rspcod
                                                                im_request_status = space    "BOC没有这个字段
                                                                im_request_result = space )  "BOC没有这个字段
                           <> zcl_bank_enviroment=>bank_return_code_is_success.
*中国银行的指令发送前需要向前置机签到，或检查是否已经签到
*只有签到成功或目前还处在签到状态的情况下，才能发送业务指令
*银行前置机返回S类型的返回代码，视同成功
*返回其他类型的代码视同不成功，在返回签到步骤报错，让实例退出发送业务指令
*        start log
      MESSAGE e068(ztr_bank_application)
              WITH <fs_boc_header_status>-rspcod
                   <fs_boc_header_status>-rspmsg
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = instance_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator
                        bank_func    = function_config-bank_func
                        step         = step ) ).
*        end log
      RETURN.
    ELSE.
      convert_token_to_db_format( ).
    ENDIF.
  ENDMETHOD.


  METHOD zif_bank_function~get_response_header_status.
*    没有什么可以实施的
    RETURN.
  ENDMETHOD.


  METHOD zif_bank_function~if_stop.
    lock_tocken( ).
    IF if_error( ) = yes.
      RETURN.
    ENDIF.

    IF if_tocken_require( ) = yes.
*      需要签到
      re_stop = no.
    ELSE.
*      不需要重新签到
      re_stop = yes.
      delock_tocken( ).
    ENDIF.

  ENDMETHOD.


  METHOD zif_bank_function~set_sending_data_reference.
    FIELD-SYMBOLS: <ft_b2e0001> TYPE STANDARD TABLE,
                   <fs_b2e0001> TYPE ztrs_boc_token_request_medium.

    CREATE DATA sending_data_reference TYPE TABLE OF (function_config-struc_in) .
    ASSIGN sending_data_reference->* TO <ft_b2e0001>.

    SELECT SINGLE termid,
                  custid,
                  trnid,
                  guid
                  INTO @DATA(ls_bank_access)
                  FROM ztrt_bank_ass
                  WHERE bank_ind = @bank_indicator.
    IF sy-subrc <> 0.
*        start log
      MESSAGE e059(ztr_bank_application)
              WITH bank_indicator
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = instance_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator
                        bank_func    = function_config-bank_func
                        step         = step ) ).
*        end log
      RETURN.
*      add_system_msg_and_return_01 059
*                                   bank_indicator.
    ENDIF.

    DATA(lo_user) = NEW cl_epic_bank_comm_logon( ls_bank_access-guid ).

    APPEND INITIAL LINE TO <ft_b2e0001> ASSIGNING <fs_b2e0001>.
    MOVE-CORRESPONDING ls_bank_access TO <fs_b2e0001>.

    TRY.
        <fs_b2e0001>-cusopr = lo_user->get_commuser( ).
      CATCH cx_epic_bank_comm_logon.
    ENDTRY.


    TRY.
        <fs_b2e0001>-oprpwd = lo_user->get_user_secstore( ).
      CATCH cx_epic_bank_comm_logon.
    ENDTRY.

    <fs_b2e0001>-custdt = sy-datlo && sy-timlo.
    <fs_b2e0001>-trncod = 'B2E0001'.
  ENDMETHOD.


  METHOD zif_boc_function~raise_b2eerror.
    raise_b2eerror.
  ENDMETHOD.
ENDCLASS.
