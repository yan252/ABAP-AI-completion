class ZCL_BANK_ACCOUNT_ABC definition
  public
  inheriting from ZCL_ABSTRACT_BANK_ACCOUNT
  final
  create public .

public section.
protected section.

  methods BANK_BALANCE_TO_SAP
    redefinition .
  methods BANK_TRANSACTIONS_TO_SAP
    redefinition .
  methods SET_ACCOUNT_BALANCE_CORE
    redefinition .
  methods SET_ACCOUNT_TABNAME
    redefinition .
  methods SET_TRANSACTIONS_CORE
    redefinition .
  methods DEQUEUE_TRANSACTION
    redefinition .
private section.
ENDCLASS.



CLASS ZCL_BANK_ACCOUNT_ABC IMPLEMENTATION.


  method BANK_BALANCE_TO_SAP.
*CALL METHOD SUPER->BANK_BALANCE_TO_SAP
*  RECEIVING
*    RT_BALANCE =
*    .
  FIELD-SYMBOLS: <ft_new_account_balance> TYPE STANDARD TABLE.
  DATA: ls_balance_ext TYPE ztrt_ABC_acbal.

  ASSIGN new_account_balance->* TO <ft_new_account_balance>.
  IF <ft_new_account_balance> IS NOT ASSIGNED OR
  <ft_new_account_balance> IS INITIAL.
    RETURN.
  ENDIF.

  LOOP AT <ft_new_account_balance> INTO ls_balance_ext.
    APPEND VALUE #(
    bukrs        = ls_balance_ext-sap_bukrs
    hbkid        = ls_balance_ext-sap_hbkid
    hktid        = ls_balance_ext-sap_hktid
*    yhzh         = ls_balance_ext-DBPROV && ls_balance_ext-DBaccno
    yhzh         = ls_balance_ext-DBaccno  "ys 20210519
    bank_ind     = bank_indicator
    zyue_ttl     = ls_balance_ext-BAL
    zyue_frz     = ( ls_balance_ext-BAL - ls_balance_ext-AVAILBAL )
    zyue         = ls_balance_ext-AVAILBAL
    waers        = GET_ACCOUNT_CURRENCY( ls_balance_ext-sap_fields )
    ) TO rt_balance.

  ENDLOOP.
  endmethod.


METHOD bank_transactions_to_sap.
*CALL METHOD SUPER->BANK_TRANSACTIONS_TO_SAP
*  RECEIVING
*    RT_TRANSACTIONS =
*    .
    FIELD-SYMBOLS: <ft_new_transactions> TYPE STANDARD TABLE.
    DATA: ls_transactions_ext TYPE ztrt_abc_trns.

    DATA: BEGIN OF ls_account,
            bzbnka TYPE ztrt_bank_trans-bzbnka,
            bzbnkn TYPE ztrt_bank_trans-bzbnkn,
            bkoinh TYPE ztrt_bank_trans-bkoinh,
          END OF ls_account.
    DATA:jd TYPE char1.
    ASSIGN new_transactions->* TO <ft_new_transactions>.
    IF <ft_new_transactions> IS NOT ASSIGNED OR
    <ft_new_transactions> IS INITIAL.
      RETURN.
    ENDIF.

    LOOP AT <ft_new_transactions> INTO ls_transactions_ext.
*    对于冲补帐根据发生额标志，ERP在对帐的时候，可以运算如下：
*    红字：－1
*    蓝字：  1
*    将此标示×发生额就可以理解了。
      IF ls_transactions_ext-amtindex =  '1'."红字

        ls_transactions_ext-amt = ls_transactions_ext-amt * ( -1 ).


      ENDIF.

      "根据金额判断来往帐
      IF ls_transactions_ext-amt > 0.
        jd = '1'.

      ELSE.

        jd = '2'.

      ENDIF.


      DATA(l_shkzg) = zcl_abc_enhancement=>convert_debit_and_credit_flag( jd ).

      DATA(ls_paymentkey) = get_paymkey_from_transaction( ls_transactions_ext-custref ).

      APPEND VALUE ztrt_bank_trans(
            bukrs        = ls_transactions_ext-sap_bukrs
            hbkid        = ls_transactions_ext-sap_hbkid
            hktid        = ls_transactions_ext-sap_hktid
            yhzh         = ls_transactions_ext-dbaccno
            trxno        = ls_transactions_ext-timestab
            bank_ind     = bank_indicator
            trxdate      = ls_transactions_ext-trdate+0(4) &&
            ls_transactions_ext-trdate+4(2) &&
            ls_transactions_ext-trdate+6(2)
            trxtime      = ls_transactions_ext-timestab
            shkzg        = l_shkzg

            trxamt       = ls_transactions_ext-amt

            bkfse        = convert_transamt_by_shkzg( im_shkzg        = l_shkzg
                                                       im_original_amt = ls_transactions_ext-amt )

            balamt       = ls_transactions_ext-bal
            waers        = ls_transactions_ext-sap_waers
            bzbnka       = ls_transactions_ext-oppname
            bzbnkn       = ls_transactions_ext-OPPPROV && ls_transactions_ext-oppaccno
            bkoinh       = ls_transactions_ext-oppname
            abstract_txt = ls_transactions_ext-abs && ls_transactions_ext-postscript
            paymentkey   = ls_paymentkey
            zref_doc = ls_paymentkey-paymorder
            intfdate     = system_info-datum
            intftime     = system_info-uzeit
*                       kunnr2       = set_customer_code_by_name( ls_transactions_ext-opacntname )
*                       lifnr        = set_vendor_code_by_name( ls_transactions_ext-opacntname )
            partner      = set_partner_by_name( ls_transactions_ext-oppname )
            ) TO rt_transactions.

    ENDLOOP.
    finished_sap_tranx_fields(
    CHANGING
      ch_t_tranx = rt_transactions ).
  ENDMETHOD.


METHOD dequeue_transaction.
*CALL METHOD SUPER->DEQUEUE_TRANSACTION
*  EXPORTING
*    IM_T_TRANSACTIONS =
*    .
    DATA:ls_transaction TYPE ztrt_abc_trns.

    LOOP AT im_t_transactions INTO ls_transaction.
      dequeue_transaction_core(
      im_bukrs = ls_transaction-sap_bukrs
      im_hbkid = ls_transaction-sap_hbkid
      im_hktid = ls_transaction-sap_hktid
      im_yhzh = ls_transaction-dbaccno
      im_trxno = ls_transaction-timestab ).
    ENDLOOP.
  ENDMETHOD.


METHOD set_account_balance_core.
*CALL METHOD SUPER->SET_ACCOUNT_BALANCE_CORE
*  EXPORTING
*    IM_DATA =
*    .


    FIELD-SYMBOLS: <ft_acc_balance> TYPE ztrt_abc_acbal_tab.
    FIELD-SYMBOLS:<ft_new_entries> TYPE ztrt_abc_acbal_tab.
    DATA: l_new     TYPE flag,
          l_changed TYPE flag.


    ASSIGN im_data->* TO <ft_acc_balance>.

    ASSIGN new_account_balance->* TO <ft_new_entries>.


    IF <ft_acc_balance> IS INITIAL.
      RETURN.
    ENDIF.
    LOOP AT <ft_new_entries> INTO DATA(fs).
      DATA(zh) = fs-dbprov && fs-dbaccno.
      SELECT * APPENDING TABLE @DATA(lt_old_data)
          FROM ztrt_abc_acbal
       "   FOR ALL ENTRIES IN @<ft_acc_balance>
        WHERE dbaccno = @zh.
    ENDLOOP.
    LOOP AT <ft_acc_balance> INTO DATA(ls_acc_balance).
      DATA(zhp) = ls_acc_balance-dbprov && ls_acc_balance-dbaccno.
      CLEAR:ls_acc_balance-dbaccno.
      ls_acc_balance-dbaccno = zhp.
      CHECK filter_accbal_by_shifton_date(
      EXPORTING
        im_s_sap_field = ls_acc_balance-sap_fields ) = 'X'.
      READ TABLE lt_old_data INTO DATA(ls_old_data)
            WITH KEY dbaccno = ls_acc_balance-dbaccno.
      IF sy-subrc <> 0.
*      new
        l_new = 'X'.
      ELSE.
        IF ls_acc_balance-acc_field <> ls_old_data-acc_field.
          l_changed = 'X'.
        ENDIF.
      ENDIF.

      IF l_new = 'X' OR
      l_changed = 'X'.
        ls_acc_balance-dbadmin = ls_old_data-dbadmin.
        set_admin_fields(
        EXPORTING
          im_new_entry = l_new
        CHANGING
          cs_admin = ls_acc_balance-dbadmin ).
        APPEND ls_acc_balance TO <ft_new_entries>.
      ENDIF.

      CLEAR: l_new,
      l_changed.
    ENDLOOP.

  ENDMETHOD.


method SET_ACCOUNT_TABNAME.
*CALL METHOD SUPER->SET_ACCOUNT_TABNAME
*    .
  transaction_db_tabname = 'ZTRT_ABC_TRNS'.
  account_balance_db_tabname = 'ZTRT_ABC_ACBAL'.
  super->set_account_tabname( ).
  endmethod.


METHOD set_transactions_core.
*CALL METHOD SUPER->SET_TRANSACTIONS_CORE
*  EXPORTING
*    IM_DATA =
*    .
    FIELD-SYMBOLS: <ft_transactions> TYPE ztrt_abc_trns_tab.
    FIELD-SYMBOLS: <ft_new_entries> TYPE ztrt_abc_trns_tab.
    DATA: l_new     TYPE flag,
          l_changed TYPE flag.

    ASSIGN im_data->* TO <ft_transactions>.

    ASSIGN new_transactions->* TO <ft_new_entries>.

    IF <ft_transactions> IS NOT ASSIGNED OR
    <ft_transactions> IS INITIAL.
      RETURN.
    ENDIF.

    SELECT * INTO TABLE @DATA(lt_old_data)
          FROM ztrt_abc_trns
          FOR ALL ENTRIES IN @<ft_transactions>
          WHERE dbaccno =  @<ft_transactions>-dbaccno  AND
                timestab  = @<ft_transactions>-timestab.

    LOOP AT <ft_transactions> INTO DATA(ls_transactions).
      CHECK filter_trans_by_shifton_date(
      EXPORTING
        im_s_sap_field = ls_transactions-sap_fields
        im_transaction_date = ls_transactions-trdate+0(4) &&
        ls_transactions-trdate+4(2) &&
        ls_transactions-trdate+6(2) ) = 'X'.
      enqueue_transaction_core(
      EXPORTING
        im_bukrs = ls_transactions-sap_bukrs
        im_hbkid = ls_transactions-sap_hbkid
        im_hktid = ls_transactions-sap_hktid
        im_yhzh = ls_transactions-dbaccno
        im_trxno = ls_transactions-timestab

      IMPORTING
      ex_enqueue_failed = DATA(l_enqueue_failed) ).
      IF l_enqueue_failed = yes.
*        被锁定，不纳入本次处理
        CLEAR l_enqueue_failed.
        CONTINUE.
      ENDIF.

      READ TABLE lt_old_data INTO DATA(ls_old_data)
            WITH KEY dbaccno = ls_transactions-dbaccno
                     timestab  = ls_transactions-timestab.
      IF sy-subrc <> 0.
*      new
        l_new = 'X'.
      ELSE.
        IF ls_transactions-trns_field <> ls_old_data-trns_field.
          l_changed = 'X'.
        ENDIF.
      ENDIF.

      IF l_new = 'X' OR
      l_changed = 'X'.
        ls_transactions-dbadmin = ls_old_data-dbadmin.
        set_admin_fields(
        EXPORTING
          im_new_entry = l_new
        CHANGING
          cs_admin = ls_transactions-dbadmin ).
        APPEND ls_transactions TO <ft_new_entries>.
      ELSE.
        dequeue_transaction_core(
        EXPORTING
          im_bukrs = ls_transactions-sap_bukrs
          im_hbkid = ls_transactions-sap_hbkid
          im_hktid = ls_transactions-sap_hktid
          im_yhzh = ls_transactions-dbaccno
          im_trxno = ls_transactions-timestab ).
      ENDIF.

      CLEAR: l_new,
      l_changed,
      ls_old_data.
    ENDLOOP.
  ENDMETHOD.
ENDCLASS.
