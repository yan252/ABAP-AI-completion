FUNCTION ZFM_TR_BZJ_BAPI.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     REFERENCE(DOCNO) TYPE  ZTR_ZFDOCNO
*"  EXPORTING
*"     REFERENCE(RFHA) TYPE  TB_RFHA
*"  TABLES
*"      RETURN STRUCTURE  BAPIRET2
*"--------------------------------------------------------------------
*  DATA: ls_hd     TYPE ztrt2104,
*        ls_2002   TYPE ztrt2002,
*        ls_2104   TYPE ztrt2104,
*        ls_header TYPE ztrt2101.
*
*  SELECT SINGLE * INTO ls_hd FROM ztrt2104
*    WHERE docno = docno.
*
*  SELECT SINGLE *  INTO ls_header FROM  ztrt2101
*    WHERE docno = docno.
*
*  SELECT SINGLE *  INTO ls_2002 FROM  ztrt2002
*    WHERE docno = docno.
*
*  SELECT SINGLE * INTO ls_2104 FROM ztrt2104
*    WHERE docno = docno.
*
*
**创建TR
*  DATA:ls_irate  TYPE bapi_ftr_create_irate,
*       ls_gen    TYPE bapi_ftr_create,
*       ls_return TYPE bapiret2.
*
*
*  ls_irate-currency = ls_header-zzfwaers.
*  ls_irate-start_term = ls_hd-begda.
*  ls_irate-end_term = ls_hd-endda.
*  ls_irate-nominal_amount = ls_header-zzfwrbtr.
*  ls_irate-interest_rate_structure = '1'.
*  ls_irate-interest_condition_type = '1200'.
*  ls_irate-interest_rate = ls_hd-zsjll."实际利率
*  ls_irate-interest_calc_meth = '2'.
*  ls_irate-frequency_category = '1'.
*
*
*  ls_gen-valuation_class = '0001'.
*  ls_gen-company_code = ls_header-bukrs.
*  ls_gen-product_type = 'Z01'.
*  ls_gen-transaction_type = '100'.
*  ls_gen-partner = ls_2002-partner.
*  ls_gen-profit_center = ls_2104-prctr. "利润中心
*  ls_gen-valuation_class = '0001'.
*
*  CALL FUNCTION 'BAPI_FTR_IRATE_CREATE'
*    EXPORTING
*      interestrateinstrument = ls_irate
*      generalcontractdata    = ls_gen
**     CONDITION_COMPLETE_INDICATOR       = 'X'
**     MIRRORING              =
**     TESTRUN                = ' '
*    IMPORTING
*      financialtransaction   = rfha
**     COMPANYCODE            =
*    TABLES
**     SCALE                  =
**     SCALE_FORMULAVARIABLES =
*      return                 = return.
*
*  READ TABLE return WITH KEY type = 'E'.
*  IF sy-subrc <> 0.
*    UPDATE ztrt2101 SET rfha = rfha
*    WHERE docno = docno.
*    COMMIT WORK.
**更新保证金相关自定义字段
*    UPDATE vtbfha SET zzprctr = ls_2104-prctr zzdocno = ls_header-docno
*                      zzftype = ls_header-zzftype
*                 WHERE bukrs = ls_header-bukrs AND rfha = rfha.
*    COMMIT WORK.
*  ELSE.
*    ROLLBACK WORK.
*  ENDIF.
*
*
*  DATA: ls_pay   TYPE bapi_ftr_paydet_create,
*        ls_fk    TYPE ztrt2003,
*        ls_t012  TYPE t012k,
*        lv_len   TYPE i,
*        lv_left  TYPE i,
*        lv_bnkn  TYPE bankn,
*        lv_bnkn2 TYPE bnkn2.
*
*  SELECT SINGLE * INTO ls_fk FROM ztrt2003 WHERE docno = docno.
**创建出入帐
**1.保证金支付-付款银行支出
*  lv_len = strlen( ls_fk-zfkbnkn ) .
*  IF lv_len > 18.
*    lv_bnkn = ls_fk-zfkbnkn+0(18).
*    lv_left = lv_len - 18.
*    lv_bnkn2 = ls_fk-zfkbnkn+18(lv_left).
*  ELSE.
*    lv_bnkn = ls_fk-zfkbnkn.
*  ENDIF.
*
*  IF lv_len > 18.
*    SELECT SINGLE * INTO ls_t012 FROM t012k
*      WHERE bukrs = ls_header-bukrs AND bankn = lv_bnkn AND bnkn2 = lv_bnkn2.
*  ELSE.
*    SELECT SINGLE * INTO ls_t012 FROM t012k
*     WHERE bukrs = ls_header-bukrs AND bankn = lv_bnkn.
*  ENDIF.
*
*  ls_pay-direction = '-'.
*  ls_pay-payment_currency = ls_header-zzfwaers.
*  ls_pay-effective_date = ls_hd-begda.
*  ls_pay-flow_type = '1100'.
*  ls_pay-house_bank = ls_t012-hbkid.
*  ls_pay-account_id = ls_t012-hktid.
*
*  CLEAR return[].
*
*  CALL FUNCTION 'BAPI_FTR_PAYDET_CREATE'
*    EXPORTING
*      companycodein          = ls_header-bukrs
*      financialtransactionin = rfha
*      directionin            = '-'
*      paymentcurrencyin      = ls_header-zzfwaers
*      effectivedatein        = ls_hd-endda
*      flowtypein             = '1100'
*      paymentdetail          = ls_pay
**     TESTRUN                = 'X'
**   IMPORTING
**     FLOWTYPE               =
**     EFFECTIVEDATE          =
**     DIRECTION              =
**     PAYMENTCURRENCY        =
**     FINANCIALTRANSACTION   =
**     COMPANYCODE            =
*    TABLES
*      return                 = return.
*
*  READ TABLE return WITH KEY type = 'E'.
*  IF sy-subrc <> 0.
*    COMMIT WORK.
*  ELSE.
*    ROLLBACK WORK.
*  ENDIF.

*  CLEAR: ls_pay,return[],ls_t012,lv_bnkn,lv_bnkn2.
**保证金到期，收款银行收入保证金和利息
*  lv_len = strlen( ls_sk-zskbnkn ) .
*  IF lv_len > 18.
*    lv_bnkn = ls_sk-zskbnkn+0(18).
*    lv_left = lv_len - 18.
*    lv_bnkn2 = ls_sk-zskbnkn+18(lv_left).
*  ELSE.
*    lv_bnkn = ls_sk-zskbnkn.
*  ENDIF.
*
*  IF lv_len > 18.
*    SELECT SINGLE * INTO ls_t012 FROM t012k
*      WHERE bukrs = ls_header-bukrs AND bankn = lv_bnkn AND bnkn2 = lv_bnkn2.
*  ELSE.
*    SELECT SINGLE * INTO ls_t012 FROM t012k
*     WHERE bukrs = ls_header-bukrs AND bankn = lv_bnkn.
*  ENDIF.
**保证金到期
*  ls_pay-direction = '+'.
*  ls_pay-payment_currency = ls_header-zzfwaers.
*  ls_pay-effective_date = ls_hd-endda.
*  ls_pay-flow_type = '1120'.
*  ls_pay-house_bank = ls_t012-hbkid.
*  ls_pay-account_id = ls_t012-hktid.
*
*  CALL FUNCTION 'BAPI_FTR_PAYDET_CREATE'
*    EXPORTING
*      companycodein          = ls_header-bukrs
*      financialtransactionin = rfha
*      directionin            = '+'
*      paymentcurrencyin      = ls_header-zzfwaers
*      effectivedatein        = ls_hd-endda
*      flowtypein             = '1120'
*      paymentdetail          = ls_pay
**     TESTRUN                = 'X'
**   IMPORTING
**     FLOWTYPE               =
**     EFFECTIVEDATE          =
**     DIRECTION              =
**     PAYMENTCURRENCY        =
**     FINANCIALTRANSACTION   =
**     COMPANYCODE            =
*    TABLES
*      return                 = return.
*
*  READ TABLE return WITH KEY type = 'E'.
*  IF sy-subrc <> 0.
*    COMMIT WORK.
*  ELSE.
*    ROLLBACK WORK.
*  ENDIF.
*
**保证金利息
*  ls_pay-flow_type = '1200'.
*  CALL FUNCTION 'BAPI_FTR_PAYDET_CREATE'
*    EXPORTING
*      companycodein          = ls_header-bukrs
*      financialtransactionin = rfha
*      directionin            = '+'
*      paymentcurrencyin      = ls_header-zzfwaers
*      effectivedatein        = ls_hd-endda
*      flowtypein             = '1200'
*      paymentdetail          = ls_pay
**     TESTRUN                = 'X'
**   IMPORTING
**     FLOWTYPE               =
**     EFFECTIVEDATE          =
**     DIRECTION              =
**     PAYMENTCURRENCY        =
**     FINANCIALTRANSACTION   =
**     COMPANYCODE            =
*    TABLES
*      return                 = return.
*
*  READ TABLE return WITH KEY type = 'E'.
*  IF sy-subrc <> 0.
*    COMMIT WORK.
*  ELSE.
*    ROLLBACK WORK.
*  ENDIF.





ENDFUNCTION.
