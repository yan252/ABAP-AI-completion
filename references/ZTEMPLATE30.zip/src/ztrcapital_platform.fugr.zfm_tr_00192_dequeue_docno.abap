FUNCTION ZFM_TR_00192_DEQUEUE_DOCNO.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     REFERENCE(IM_DOCNO) TYPE  ZTR_0192_DOCNO
*"--------------------------------------------------------------------
READ TABLE gt_docno TRANSPORTING NO FIELDS
        WITH KEY docno = im_docno.
  IF sy-subrc <> 0.
    RETURN.
  ENDIF.

  CALL FUNCTION 'DEQUEUE_EZTRT0192H'
    EXPORTING
      mode_ztrt0192h = 'E'
      mandt          = sy-mandt
      docno          = im_docno
      x_docno        = ' '
      _scope         = '3'
      _synchron      = ' '
      _collect       = ' '.

  DELETE gt_docno WHERE docno = im_docno .





ENDFUNCTION.
