@AbapCatalog.sqlViewName: 'ZTRCDS3020H'
@AbapCatalog.compiler.compareFilter: true
@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'BISK贷方数据'
define view ZDDL_RT3020H as select from bsik as A inner join
                                   bseg as b on b.mandt = A.mandt
                                            and b.bukrs = A.bukrs
                                            and b.belnr = A.belnr
                                            and b.gjahr = A.gjahr
                                            and b.buzei = A.buzei{
A.mandt,
A.bukrs,
A.belnr,
A.gjahr,
A.buzei,
A.lifnr,
A.zlsch,
A.waers,
A.zterm,
A.sgtxt,
A.bvtyp,
A.hkont,
b.rstgr,
A.shkzg,
A.zlspr,
A.blart,
A.dmbtr,
A.wrbtr,
( case
  when ( b.koart = 'D' and b.shkzg = 'H' ) or ( b.koart = 'K' and b.shkzg = 'S' ) and b.rebzg = '' and A.zfbdt <> '00000000' then A.zfbdt 
  when ( b.koart = 'D' and b.shkzg = 'H' ) or ( b.koart = 'K' and b.shkzg = 'S' ) and b.rebzg = '' and A.zfbdt = '00000000' then A.bldat
  when A.zfbdt <> '00000000' and A.zbd3t <> 0                  then dats_add_days(A.zfbdt,CEIL(A.zbd3t),'NULL') 
  when A.zfbdt <> '00000000' and A.zbd3t = 0 and A.zbd2t <> 0  then dats_add_days(A.zfbdt,CEIL(A.zbd2t),'NULL') 
  when A.zfbdt <> '00000000' and A.zbd3t = 0 and A.zbd2t = 0   then dats_add_days(A.zfbdt,CEIL(A.zbd1t),'NULL') 
  when A.zfbdt  = '00000000' and A.zbd3t <> 0                  then dats_add_days(A.bldat,CEIL(A.zbd3t),'NULL') 
  when A.zfbdt  = '00000000' and A.zbd3t = 0 and A.zbd2t <> 0  then dats_add_days(A.bldat,CEIL(A.zbd2t),'NULL') 
  when A.zfbdt  = '00000000' and A.zbd3t = 0 and A.zbd2t = 0   then dats_add_days(A.bldat,CEIL(A.zbd1t),'NULL') 
  else A.zfbdt
  end ) as zfbdt
}  
 
  
 