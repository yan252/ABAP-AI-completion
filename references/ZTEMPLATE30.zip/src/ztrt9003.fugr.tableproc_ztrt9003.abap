*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZTRT9003
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZTRT9003            .

  PERFORM TABLEPROC.

ENDFUNCTION.
