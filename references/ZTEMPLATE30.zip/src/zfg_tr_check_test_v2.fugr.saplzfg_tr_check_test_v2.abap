*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_TR_CHECK_TEST_V2TOP.                  " Global Declarations
  INCLUDE LZFG_TR_CHECK_TEST_V2UXX.                  " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_TR_CHECKF...                  " Subroutines
* INCLUDE LZFG_TR_CHECKO...                  " PBO-Modules
* INCLUDE LZFG_TR_CHECKI...                  " PAI-Modules
* INCLUDE LZFG_TR_CHECKE...                  " Events
* INCLUDE LZFG_TR_CHECKP...                  " Local class implement.
* INCLUDE LZFG_TR_CHECKT99.                  " ABAP Unit tests

INCLUDE LZFG_TR_CHECK_TEST_V2F01.



*INCLUDE LZFG_TR_CHECK_TESTF01.
*INCLUDE LZFG_TR_CHECKF01.
