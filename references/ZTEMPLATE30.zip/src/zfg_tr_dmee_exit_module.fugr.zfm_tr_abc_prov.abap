FUNCTION ZFM_TR_ABC_PROV.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     VALUE(I_TREE_TYPE) TYPE  DMEE_TREETYPE_ABA
*"     VALUE(I_TREE_ID) TYPE  DMEE_TREEID_ABA
*"     VALUE(I_ITEM)
*"     VALUE(I_PARAM)
*"     VALUE(I_UPARAM)
*"  EXPORTING
*"     REFERENCE(O_VALUE)
*"     REFERENCE(C_VALUE)
*"     REFERENCE(N_VALUE)
*"     REFERENCE(P_VALUE)
*"  TABLES
*"      I_TAB
*"--------------------------------------------------------------------
FIELD-SYMBOLS <fs_fpayhx> TYPE fpayhx.

  ASSIGN COMPONENT 'FPAYHX' OF STRUCTURE i_item TO <fs_fpayhx>.

  c_value = CONV #( zcl_abc_enhancement=>get_accno_prov( im_s_fpayhx = <fs_fpayhx> ) ).





ENDFUNCTION.
