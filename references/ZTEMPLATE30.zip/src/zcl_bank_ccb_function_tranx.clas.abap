class ZCL_BANK_CCB_FUNCTION_TRANX definition
  public
  inheriting from ZCL_BANK_FUNCTION_TRANSACTIONS
  final
  create public .

public section.
protected section.

  methods CHECK_RESPONSE_IF_FINISHED
    redefinition .
  methods PROCESSING_RESPONSE_INTL_CORE
    redefinition .
private section.
ENDCLASS.



CLASS ZCL_BANK_CCB_FUNCTION_TRANX IMPLEMENTATION.


METHOD check_response_if_finished.
*    FIELD-SYMBOLS: <fs_response>        TYPE ztrs_ccb_6wy101_response.
*
*    DATA(ls_response_data) = get_current_response_data( ).
*    ASSIGN ls_response_data-response_ref->* TO <fs_response>.
*
*    IF <fs_response>-body-page >= <fs_response>-body-total_page OR
*       <fs_response>-body-details IS INITIAL.
**当前页码等于或大于总页码，说明查询的交易明细结束
*      current_response_is_finished = yes.
*      RETURN.
*    ENDIF.
*
*    DATA(ls_sending_xml_ref) = get_sending_file_by_sequence( current_sending_sequence ).
*    ASSIGN ls_sending_xml_ref-cfile->* TO FIELD-SYMBOL(<f_xml_string>).
*    ASSIGN ls_sending_xml_ref-xfile->* TO FIELD-SYMBOL(<f_xml_xstring>).
*
**建行的报文前有'requestXml='前缀字符串
*    REPLACE zif_ccb_constants=>sending_message_prefix WITH space INTO <f_xml_string>.
*    CONDENSE <f_xml_string>.
**    16进制
*    <f_xml_xstring> = cl_abap_codepage=>convert_to( <f_xml_string> ).
*
*    zcl_bank_data_mapping_engine=>reset_element_value(
*                                     EXPORTING
*                                       im_t_element_values = VALUE #( ( name = zif_ccb_constants=>page_element_name
*                                                                        data = <fs_response>-body-page + 1 )
*                                                                      ( name = zif_ccb_constants=>position_string_element_name
*                                                                        data = <fs_response>-body-poststr )
*                                                                      ( name = zif_ccb_constants=>request_sn_element_name
*                                                                        data = zcl_ccb_enhancement=>generate_request_sn( ) ) )
*                                     IMPORTING
*                                       et_return_errors = DATA(lt_return_errors)
*                                     CHANGING
*                                       ch_xml_xstring = <f_xml_xstring>
*                                       ch_xml_string = <f_xml_string> ).
*
*    IF lt_return_errors IS NOT INITIAL.
*      messages->add_message_set( lt_return_errors ).
*      current_response_is_finished = yes.
*      RETURN.
*    ELSE.
**    替换之后再将'requestXml='前缀字符串接回去
*    <f_xml_xstring> = cl_abap_codepage=>convert_to( zif_ccb_constants=>sending_message_prefix ) && <f_xml_xstring>.
*    <f_xml_string> = zif_ccb_constants=>sending_message_prefix && <f_xml_string>.
*
*      current_response_is_finished = no.
*    ENDIF.
*
**COMMIT WORK AND WAIT.

************************************************************************************************
*读取建行的交易明细时，如果查询的范围内超过一页，那么从第二页开始无法获得完整的反馈（XML不完整），
*从而导致XML转换报错。
*这个问题曾经咨询过建行，但是也无法获得解决的办法，从SAP的角度也无法解决第二页开始XML不完整的问题
*因此建行的交易明细加了一个控制，就是每次只读取一页，每页200个交易明细。如果反馈获得的交易明细
*少于200个记录，本次查询范围还没完成，如果达到了200个记录，视为本次查询的页码已满
*但不管是那一个情况，都视为本次读取结束，并将页码信息更新到数据库表ztrt_ccb_trns_p

*下一次读取的时候，将从ztrt_ccb_trns_p中取得已经处理页码的信息。
*如果上次处理的页码尚未完全读取，那么继续从那个页码开始查询，如果已经读取完成了（达到200个记录）
*那么从下一页开始读取
*(详情查看DMEE出口函数ZFM_TR_CCB_SET_TRX_DETAIL_PAGE)

************************************************************************************************
    FIELD-SYMBOLS: <fs_response>     TYPE ztrs_ccb_6wy101_response.

    DATA: ls_trans_page TYPE ztrt_ccb_trns_p.

*    设置反馈完成了
    current_response_is_finished = yes.

    DATA(ls_response_data) = get_current_response_data( ).
    ASSIGN ls_response_data-response_ref->* TO <fs_response>.

    DATA(ls_sending_xml_ref) = get_sending_file_by_sequence( current_sending_sequence ).
    ASSIGN ls_sending_xml_ref-cfile->* TO FIELD-SYMBOL(<f_xml_string>).
    ASSIGN ls_sending_xml_ref-xfile->* TO FIELD-SYMBOL(<f_xml_xstring>).

    zcl_bank_data_mapping_engine=>get_element_value(
                                     EXPORTING
                                       im_xml_string = <f_xml_string>
                                       im_xml_xstring = <f_xml_xstring>
                                       im_t_fieldname = VALUE #( ( name = zif_ccb_constants=>start_date_element_name )
                                                                 ( name = zif_ccb_constants=>end_date_element_name )
                                                                 ( name = zif_ccb_constants=>page_element_name ) )
                                     IMPORTING
                                       ex_t_element_values = DATA(lt_element_values) ).
    ls_trans_page-bank_ind = bank_indicator.
    ls_trans_page-yhzh = <fs_response>-body-accno1.
    READ TABLE lt_element_values INTO DATA(ls_element_value)
                WITH KEY name = zif_ccb_constants=>start_date_element_name.
    IF sy-subrc = 0.
      ls_trans_page-start_date = ls_element_value-data.
    ENDIF.
    READ TABLE lt_element_values INTO ls_element_value
                WITH KEY name = zif_ccb_constants=>end_date_element_name.
    IF sy-subrc = 0.
      ls_trans_page-end_date = ls_element_value-data.
    ENDIF.

    READ TABLE lt_element_values INTO ls_element_value
                WITH KEY name = zif_ccb_constants=>page_element_name.
    IF sy-subrc = 0.
      ls_trans_page-zpage = ls_element_value-data.
    ENDIF.

    IF lines( <fs_response>-body-details ) = function_config-max_resp_item.
      ls_trans_page-page_full = yes.
    ELSE.
      ls_trans_page-page_full = no.
    ENDIF.

    CALL FUNCTION 'ZFM_TR_CCB_UPDATE_TRANS_PAGE' IN UPDATE TASK
      EXPORTING
        im_s_page = ls_trans_page.

  ENDMETHOD.


METHOD processing_response_intl_core.
    processing_response_by_dbtable(
                im_data_db_table = 'ZTRT_CCB_TRNS'
                im_detail_response_component = 'BODY-DETAILS'
                im_statuscode_componnet = 'HEADER-RETURN_CODE'
                im_statustext_component = 'HEADER-RETURN_MSG'
                im_db_account_number_field = 'ACCNO1'
                im_bank_entry_accnumber_field = ''  ).
  ENDMETHOD.
ENDCLASS.
