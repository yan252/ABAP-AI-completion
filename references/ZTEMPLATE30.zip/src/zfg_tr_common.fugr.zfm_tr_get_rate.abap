FUNCTION ZFM_TR_GET_RATE.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     VALUE(FBFROM) LIKE  SY-DATUM
*"     VALUE(FBTILL) LIKE  SY-DATUM OPTIONAL
*"     VALUE(RATE) TYPE  DZINSSATZ
*"     VALUE(INTEREST_REF) LIKE  T056P-REFERENZ
*"     VALUE(SZSREFVZ) TYPE  SZSREFVZ OPTIONAL
*"  TABLES
*"      INTEREST_RATES_TAB STRUCTURE  INT_TAB
*"--------------------------------------------------------------------
DATA interest_add       TYPE t056a-zuschlzins.
  REFRESH interest_rates_tab.
  IF fbtill IS INITIAL ."可能当前日期的利率尚未维护，取最靠近的日期的利率
    fbtill = sy-datum.
  ENDIF.
  IF interest_ref IS INITIAL."szsrefvz IS INITIAL ."AND 固定利率
    interest_rates_tab-date_t   = fbfrom.
    interest_rates_tab-int_rate = rate.
    APPEND interest_rates_tab.
    RETURN.
* 参考利率
  ELSE.
    IF szsrefvz = '+'.
      interest_add = rate.
    ELSEIF  szsrefvz = '-'.
      interest_add = - rate.
    ENDIF.
    CALL FUNCTION 'CREDIT_INT_RATE_DETERMINE'
      EXPORTING
        fbfrom             = fbfrom
        fbtill             = fbtill
        interest_add       = interest_add
        interest_ref       = interest_ref
      TABLES
        interest_rates_tab = interest_rates_tab
      EXCEPTIONS
        err_t056p          = 1
        err_zinss_neg      = 2
        OTHERS             = 3.
    IF sy-subrc <> 0.
* Implement suitable error handling here
      interest_rates_tab-int_rate = interest_add.
      APPEND interest_rates_tab.
    ENDIF.
    IF  szsrefvz = '*'.
      LOOP AT interest_rates_tab.
        interest_rates_tab-int_rate = interest_rates_tab-int_rate * rate / 100.
        MODIFY interest_rates_tab.
      ENDLOOP.
    ENDIF.
  ENDIF.
  SORT interest_rates_tab BY date_t DESCENDING.





ENDFUNCTION.
