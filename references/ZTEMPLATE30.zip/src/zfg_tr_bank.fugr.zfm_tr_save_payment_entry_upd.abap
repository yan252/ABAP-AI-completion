FUNCTION ZFM_TR_SAVE_PAYMENT_ENTRY_UPD.
*"--------------------------------------------------------------------
*"*"更新函数模块：
*"
*"*"局部接口：
*"  IMPORTING
*"     VALUE(IM_S_PAYMENT_ENTRY) TYPE  ZTRT_PAYMENT
*"     VALUE(IM_S_PAYMENT_LINKAGE) TYPE  ZTRT_PAYMLINK
*"     VALUE(IM_S_SEQUENCE_ENTRY) TYPE  ZTRT_DSEQ
*"--------------------------------------------------------------------
IF im_s_payment_entry IS NOT INITIAL.
    MODIFY ztrt_payment FROM im_s_payment_entry.
  ENDIF.

  IF im_s_sequence_entry IS NOT INITIAL.
    MODIFY ztrt_dseq FROM im_s_sequence_entry.
  ENDIF.

  IF im_s_payment_linkage IS NOT INITIAL.
    MODIFY ztrt_paymlink FROM  im_s_payment_linkage.
  ENDIF.





ENDFUNCTION.
