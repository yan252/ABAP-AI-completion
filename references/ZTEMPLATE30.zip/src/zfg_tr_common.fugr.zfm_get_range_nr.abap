FUNCTION ZFM_GET_RANGE_NR.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     REFERENCE(IV_DOCTYPE) TYPE  ZTR_DOCTYPE
*"     REFERENCE(IV_CONFIG_TYPE) TYPE  ZTR_CONFIG_TYPE
*"  EXPORTING
*"     REFERENCE(EV_DOCNO) TYPE  ZTR_DOCNO
*"--------------------------------------------------------------------
data lv_return type inri-returncode.
  data lv_nrnr   type inri-nrrangenr.
  select single nrnr  into lv_nrnr
    from ztrt9002
   where doctype = iv_doctype
     and config_type = iv_config_type.


  call function 'NUMBER_GET_NEXT'
    exporting
      nr_range_nr = lv_nrnr
      object      = 'ZTR_NR_001'
    importing
      number      = ev_docno
      returncode  = lv_return.





ENDFUNCTION.
