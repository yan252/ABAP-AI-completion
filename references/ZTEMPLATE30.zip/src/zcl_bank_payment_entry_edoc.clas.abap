class ZCL_BANK_PAYMENT_ENTRY_EDOC definition
  public
  inheriting from ZCL_BANK_PAYMENT_ENTRY
  final
  create public .

public section.
protected section.

  methods CHECK_FOR_NEW_ENTRY_CORE
    redefinition .
  methods READ_PAYMENTORDER_PAYER_DATA
    redefinition .
private section.

  methods READ_EDOC
    exporting
      !EX_S_S2009 type ZTRS_EDRAFT .
  methods RESET_ENTRY_FIELDS .
  methods RESET_PAYER_ACCOUNT .
  methods CHECK_BY_CHECKER .
  methods SET_AUTO_ACCEPTANCE .
  methods SET_AUTO_RECEIVE .
ENDCLASS.



CLASS ZCL_BANK_PAYMENT_ENTRY_EDOC IMPLEMENTATION.


  METHOD check_by_checker.
    zcl_bank_logger_protocal=>import_messages(
                        im_t_messages              =  NEW zcl_paymententry_edoc_checker(
                                                                 im_action          = bank_action
                                                                 im_S_payment_entry = payment_entry )->check( )
                        im_uuid                    = entry_uuid
                        im_s_log_businessdata_data = VALUE #(
                                       bank_ind        = payment_entry-bank_ind
                                       bank_action     = bank_action
                                       log_obj         = entry_uuid
                                       log_obj_type    = zcl_bank_application_logger=>log_object_type_payment_entry
                                       paymorder       = payment_order-paymorder
                                                            )
                                              ).
  ENDMETHOD.


  METHOD check_for_new_entry_core.
    super->check_for_new_entry_core( ).
    IF if_error( ) = yes.
      RETURN.
    ENDIF.

    check_by_checker( ).


  ENDMETHOD.


  METHOD read_edoc.
    SELECT SINGLE * INTO @DATA(ls_2009)
            FROM ztrt2009
            WHERE docno = @payment_order-paymorder
            AND   zxh = @payment_order-draft_zxh.

    IF sy-subrc <> 0.
*    start log
      MESSAGE e267(ztr_bank_application)
              WITH entry_uuid
                   payment_order-paymorder
                   payment_order-draft_zxh
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = entry_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = bank_action
                        log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                        log_obj      = entry_uuid
                        paymorder    = payment_order-paymorder ) ).
*    end log
      RETURN.
    ENDIF.

    MOVE: ls_2009-zdq_date     TO ex_s_s2009-draft_duedate,
          ls_2009-zcp_date     TO ex_s_s2009-draft_bookdate,
          ls_2009-zpj_type     TO ex_s_s2009-drafttype,
          ls_2009-zpj_no       TO ex_s_s2009-draft_zpj_no,
          ls_2009-docno_key    TO ex_s_s2009-draft_docno_key,
          ls_2009-zjsno        TO ex_s_s2009-draft_zjsno,
          ls_2009-zxh          TO ex_s_s2009-draft_zxh,
          ls_2009-zhpje        TO ex_s_s2009-draft_wrbtr.

    SELECT SINGLE zbskl INTO ex_s_s2009-draft_zbskl
           FROM ztrt2001
           WHERE docno = payment_order-paymorder.

  ENDMETHOD.


  METHOD read_paymentorder_payer_data.
    IF bank_action = zif_bank_action=>action_is_create_edoc.
*      只要开立汇票的时候需要读取支付单的付款账户
      super->read_paymentorder_payer_data(
            IMPORTING
              ex_s_s2003 = ex_s_s2003 ).
*    ELSE.
*      背书的会通过RESET_PAYER_ACCOUNT重置
    ENDIF.
  ENDMETHOD.


  METHOD reset_entry_fields.
**    用汇票的金额覆盖支付条目的金额
**    支付条目的金额本来应该从支付单抬头取得，但由于一个支付单可能含有多个汇票
**    因此在发送给银行的时候应该以汇票的为准
    MOVE: payment_entry-draft_wrbtr TO payment_entry-rwbtr. "
*一个支付单可能含有多个汇票记录
*提供给银行的参考号码需要带上每个汇票记录的序号
    payment_entry-doc1r = payment_entry-paymorder && payment_entry-draft_zxh.
    IF bank_action = zif_bank_action=>action_is_create_edoc.
      MOVE: payment_entry-bnkl1 TO payment_entry-acceptor_bankl,
*            payment_entry-bnkn1 TO payment_entry-acceptor_bankn,
            payment_entry-pzhmc TO payment_entry-acceptor_name.
      IF payment_entry-drafttype = '25'.
*      商票
        MOVE payment_entry-bnkn1 TO payment_entry-acceptor_bankn.
      ENDIF.
    ENDIF.

  ENDMETHOD.


  METHOD reset_payer_account.
*****        目前还没确定
*****        先按照汇票从接收票据台账中读取票据的账户
*    IF payment_entry-zbukr IS INITIAL OR
*       payment_entry-draft_docno_key IS INITIAL OR
*       payment_entry-draft_zjsno IS INITIAL.
*      RETURN.
*    ENDIF.
*
*    SELECT SINGLE * INTO @DATA(ls_0070)
*           FROM ztrt0070
*           WHERE docno_key = @payment_entry-draft_docno_key
*           AND   bukrs = @payment_entry-zbukr
*           AND   zjsno = @payment_entry-draft_zjsno.
*    IF sy-subrc <> 0.
*      MESSAGE e279(ztr_bank_application)
*              WITH payment_entry-draft_docno_key
*                   payment_entry-zbukr
*                  payment_entry-draft_zjsno
*              INTO dummy_message.
*      zcl_bank_logger_protocal=>add_log(
*               VALUE #( uuid         = entry_uuid
*                        msgid        = sy-msgid
*                        msgno        = sy-msgno
*                        msgty        = sy-msgty
*                        msgv1        = sy-msgv1
*                        msgv2        = sy-msgv2
*                        msgv3        = sy-msgv3
*                        msgv4        = sy-msgv4
*                        message      = dummy_message
*                        bank_action  = bank_action
*                        log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
*                        log_obj      = entry_uuid
*                        paymorder    = payment_order-paymorder ) ).
*      RETURN.
*    ENDIF.
*
*
*    SELECT SINGLE * INTO @DATA(ls_0013)
*           FROM ztrt0013
*           WHERE bukrs = @ls_0070-bukrs
*           AND   hbkid = @ls_0070-hbkid
*           AND   hktid = @ls_0070-hktid.
*    IF sy-subrc <> 0.
*      MESSAGE e287(ztr_bank_application)
*              WITH ls_0070-bukrs
*                   ls_0070-hbkid
*                   ls_0070-hktid
*              INTO dummy_message.
*      zcl_bank_logger_protocal=>add_log(
*               VALUE #( uuid         = entry_uuid
*                        msgid        = sy-msgid
*                        msgno        = sy-msgno
*                        msgty        = sy-msgty
*                        msgv1        = sy-msgv1
*                        msgv2        = sy-msgv2
*                        msgv3        = sy-msgv3
*                        msgv4        = sy-msgv4
*                        message      = dummy_message
*                        bank_action  = bank_action
*                        log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
*                        log_obj      = entry_uuid
*                        paymorder    = payment_order-paymorder ) ).
*      RETURN.
*    ENDIF.
*
*    MOVE: ls_0070-hbkid TO payment_entry-hbkid,
*          ls_0070-hktid TO payment_entry-hktid,
*          ls_0013-bank_ind TO payment_entry-bank_ind,
*          ls_0013-banks TO payment_entry-bnks1,
*          ls_0013-bankl TO payment_entry-bnkl1,
*          ls_0013-yhzh TO payment_entry-bnkn1.

  ENDMETHOD.


  method SET_AUTO_ACCEPTANCE.
*    目前全部设置提示承兑
    payment_entry-draft_autoacp = yes.
  endmethod.


  method SET_AUTO_RECEIVE.
*    目前全部设置提示收票
    payment_entry-draft_autorec = yes.
  endmethod.
ENDCLASS.
