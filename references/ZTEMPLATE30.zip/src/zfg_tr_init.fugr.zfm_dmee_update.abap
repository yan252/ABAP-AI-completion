FUNCTION ZFM_DMEE_UPDATE.
*"----------------------------------------------------------------------
*"*"本地接口：
*默认不输入参数，自动从D:/DMEE目录下取出所有的DMEE导入
*"  IMPORTING
*"     VALUE(IM_PATH) TYPE  BDCDATA-FVAL OPTIONAL
*"     REFERENCE(IM_TREE_TYPE) TYPE  DMEE_TREEID_ABA OPTIONAL
*"  TABLES
*"      IT_DMEE STRUCTURE  ZTRS_DMEE
*"----------------------------------------------------------------------
  DATA: L_PATH  TYPE BDCDATA-FVAL, "保存目录
        L_SUBRC TYPE SY-SUBRC,
        L_MODE  TYPE CHAR1 VALUE 'N'.
*  FIELD-SYMBOLS:  <DMEE> STRUCTURE ZTRS_DMEE DEFAULT ZTRS_DMEE.
  DATA: LT_MESSTAB LIKE  TABLE OF BDCMSGCOLL,
        LS_MESSTAB LIKE  BDCMSGCOLL.
  DATA: LS_MSGTX TYPE MSGTX.

  IF IM_PATH IS INITIAL.
    IM_PATH = 'D:\DMEE\'."此路径地址最好不要太长，因为DMEE下载路径长度有限制
  ENDIF.
  CLEAR:  IT_DMEE.

  DATA G_PATH TYPE STRING.
  DATA: TAB_G_FILETAB  TYPE STANDARD TABLE OF FILE_INFO WITH HEADER LINE,
        TAB_G_FILETAB2 TYPE STANDARD TABLE OF FILE_INFO WITH HEADER LINE.

  DATA G_FILTER TYPE STRING  VALUE '*'.
  DATA G_COUNT TYPE I.
  DATA PATH_LJ TYPE STRING.  "文件路径

  CLEAR:TAB_G_FILETAB,TAB_G_FILETAB[].

  G_PATH = IM_PATH.
  CALL METHOD CL_GUI_CFW=>FLUSH.

  CALL METHOD CL_GUI_FRONTEND_SERVICES=>DIRECTORY_LIST_FILES
    EXPORTING
      DIRECTORY                   = G_PATH
      FILTER                      = G_FILTER
    CHANGING
      FILE_TABLE                  = TAB_G_FILETAB[]
      COUNT                       = G_COUNT
    EXCEPTIONS
      CNTL_ERROR                  = 1
      DIRECTORY_LIST_FILES_FAILED = 2
      WRONG_PARAMETER             = 3
      ERROR_NO_GUI                = 4
      NOT_SUPPORTED_BY_GUI        = 5
      OTHERS                      = 6.
  LOOP AT TAB_G_FILETAB INTO DATA(LS_DATA) WHERE ISDIR = 1.
    G_PATH = IM_PATH &&  LS_DATA-FILENAME.
    CLEAR:TAB_G_FILETAB2,TAB_G_FILETAB2[].
    CALL METHOD CL_GUI_FRONTEND_SERVICES=>DIRECTORY_LIST_FILES
      EXPORTING
        DIRECTORY                   = G_PATH
        FILTER                      = G_FILTER
      CHANGING
        FILE_TABLE                  = TAB_G_FILETAB2[]
        COUNT                       = G_COUNT
      EXCEPTIONS
        CNTL_ERROR                  = 1
        DIRECTORY_LIST_FILES_FAILED = 2
        WRONG_PARAMETER             = 3
        ERROR_NO_GUI                = 4
        NOT_SUPPORTED_BY_GUI        = 5
        OTHERS                      = 6.
    LOOP AT TAB_G_FILETAB2 INTO DATA(LS_DATA2) WHERE ISDIR = 0.
      L_PATH = G_PATH && '\' && LS_DATA2-FILENAME.
*BDC 导入文件

*      CALL FUNCTION 'ZFM_DMEE_UPDATE1'
*        EXPORTING
**         CTU               = 'X'
*          MODE              = L_MODE
**         UPDATE            = 'L'
**         GROUP             =
**         USER              =
**         KEEP              =
**         HOLDDATE          =
**         NODATA            = '/'
**         G_LOCATION_001    = 'P'
*          G_XMLFILENAME_002 = L_PATH
*        IMPORTING
*          SUBRC             = L_SUBRC
*        TABLES
*          MESSTAB           = LT_MESSTAB.
*      IF L_SUBRC = 0.
*        IT_DMEE-SUCC = 'X'.
*      ELSE.
*        IT_DMEE-SUCC = ''.
      CALL FUNCTION 'ZFM_DMEE_UPDATE3'
        EXPORTING
*         CTU               = 'X'
          MODE              = L_MODE
*         UPDATE            = 'L'
*         GROUP             =
*         USER              =
*         KEEP              =
*         HOLDDATE          =
*         NODATA            = '/'
*         G_LOCATION_001    = 'P'
          G_XMLFILENAME_004 = L_PATH
        IMPORTING
          SUBRC             = L_SUBRC
        TABLES
          MESSTAB           = LT_MESSTAB.
      IF L_SUBRC = 0.
        IT_DMEE-SUCC = 'X'.
      ELSE.
        IT_DMEE-SUCC = ''.

        LOOP AT LT_MESSTAB INTO LS_MESSTAB.
          MESSAGE ID LS_MESSTAB-MSGID TYPE 'S'  NUMBER LS_MESSTAB-MSGNR
            INTO LS_MSGTX
           WITH LS_MESSTAB-MSGV1 LS_MESSTAB-MSGV2
                LS_MESSTAB-MSGV3 LS_MESSTAB-MSGV4.

          IT_DMEE-MSGTX = IT_DMEE-MSGTX && '|' && LS_MSGTX.
        ENDLOOP.
        IT_DMEE-MSGTX(1) = ''.

      ENDIF.

      IT_DMEE-TREE_TYPE = LS_DATA-FILENAME.
      IT_DMEE-TREE_ID   = LS_DATA2-FILENAME.

      APPEND IT_DMEE.
      CLEAR:  IT_DMEE.

    ENDLOOP.
  ENDLOOP.



ENDFUNCTION.
