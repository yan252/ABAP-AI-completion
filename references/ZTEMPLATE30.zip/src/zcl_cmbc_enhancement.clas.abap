class ZCL_CMBC_ENHANCEMENT definition
  public
  final
  create public .

public section.

  class-methods SET_LOCALFLAG
    importing
      !IM_S_FPAYH type FPAYH
    returning
      value(RE_VALUE) type CHAR01 .
  class-methods SET_CLIENTID
    returning
      value(RE_VALUE) type STRING .
  class-methods SET_USERID
    returning
      value(RE_VALUE) type EPIC_BC_USER .
  class-methods SET_USERPSWD
    returning
      value(RE_VALUE) type STRING .
  class-methods SET_EXTERNBANK
    importing
      !IM_S_FPAYH type FPAYH
    returning
      value(RE_VALUE) type CHAR01 .
  class-methods CONVERT_DEBIT_AND_CREDIT_FLAG
    importing
      !IM_TYPE type CHAR01
    returning
      value(RE_SAP_VALUE) type SHKZG .
  class-methods SET_RCVCUSTTYPE
    importing
      !IM_S_FPAYH type FPAYH
    returning
      value(RE_VALUE) type CHAR01 .
  class-methods WAIT
    changing
      !CH_INTERACTION_COUNT type I .
protected section.
private section.
ENDCLASS.



CLASS ZCL_CMBC_ENHANCEMENT IMPLEMENTATION.


method CONVERT_DEBIT_AND_CREDIT_FLAG.
    CASE im_type.
      WHEN '1'.
*        银行借方相当于企业贷方
        re_sap_value = 'H'.
      WHEN '2'.
*        银行贷方相当于企业借方
        re_sap_value = 'S'.
    ENDCASE.
  endmethod.


method SET_CLIENTID.
    SELECT SINGLE * INTO @DATA(ls_bank_assignment)
          FROM ztrt_bank_ass
          WHERE bank_ind = 'CMBC'.
    IF sy-subrc <> 0.
*      the error should be remove by testing phase
      RETURN.
    ENDIF.

    SELECT COUNT( * ) INTO @DATA(l_count)
           FROM epic_bc_ud
           WHERE guid = @ls_bank_assignment-guid.
    IF l_count < 1.
*      the error should be remove by testing phase
      RETURN.
    ENDIF.

    re_value = ls_bank_assignment-custid.
  endmethod.


METHOD set_externbank.
    IF zcl_bank_cnaps_code=>if_same_bank(
                              EXPORTING
                                im_code1 = im_s_fpayh-zbnky
                                im_code2 = im_s_fpayh-bnkl1 ) = space.
      re_value = '1'."跨行
    ELSE.
      re_value = '0'."同行
    ENDIF.
  ENDMETHOD.


METHOD set_localflag.
    IF zcl_bank_cnaps_code=>if_same_bank(
                                im_code1 = im_s_fpayh-zbnky
                                im_code2 = im_s_fpayh-bnkl1 ) = 'X'.
*      同行
*同行转账交易的汇路只有本地或异地(0)的区分(1)
      IF zcl_bank_cnaps_code=>if_same_city(
                                   im_code1 = im_s_fpayh-zbnky
                                   im_code2 = im_s_fpayh-bnkl1 ) = 'X'.
*        同城
        re_value = '0'.
      ELSE.
*          异地
        re_value = '1'.
      ENDIF.

      RETURN.
    ENDIF.

*    跨行的情况
*0-同城票交（部分地区已经关闭）
*1-民生银行文档说暂时不用
*2-不落地小额(金额小于或等于五万，7*24小时，大约两小时到账，文档说手续费按人行电子划汇八折执行)
*3-不落地大额（任意非零金额，工作日上午9：00到下午17：00，大约半小时到账，文档说手续费按人行电子划汇八折执行）
*4-上海同城
*5-网银互联(金额小于或等于五万，文档说暂时免手续费，实时到账，7*24小时)
*6-北京同城
*7深圳同城
******对于跨行，SAP只使用小额和大额汇路
    IF im_s_fpayh-rwbtr <= '50000.00'.
*      IF im_s_fpayh-zbnky IS NOT INITIAL AND
*          im_s_fpayh-zbnka IS NOT INITIAL.
**        支付信息包含收款行号和行名，使用网银互联
*        re_value = '5'.
*      ELSE.
**        小额
*        re_value = '2'.
*      ENDIF.
      re_value = '2'.
    ELSE.
      re_value = '3'.
    ENDIF.
  ENDMETHOD.


METHOD set_rcvcusttype.
    IF im_s_fpayh-gpa1t = '12'."顾问设置的11 为供应商，实际上是用的12为供应商、20200727 BY JMJ.
*      供应商
      SELECT SINGLE ktokk INTO @DATA(l_ktokk)
              FROM lfa1
              WHERE lifnr = @im_s_fpayh-gpa1r.
      IF l_ktokk = 'S004'.
*        员工，对私
        re_value = '2'.
      ENDIF.
    ENDIF.

    IF re_value IS INITIAL.
      re_value = '1'.
    ENDIF.
  ENDMETHOD.


METHOD set_userid.
    CALL FUNCTION 'ZFM_TR_BANK_LOGON_USER'
      EXPORTING
        im_bank_indicator = 'CMBC'
      IMPORTING
        ex_user           = re_value.
  ENDMETHOD.


METHOD set_userpswd.
    CALL FUNCTION 'ZFM_TR_BANK_LOGON_USER'
      EXPORTING
        im_bank_indicator = 'CMBC'
      IMPORTING
        ex_pasword        = re_value.
  ENDMETHOD.


METHOD wait.

*    民生银行对查询的交互频率要求比较高
*    目前设定每秒只能查询三个信息，如果当前实例的查询超高3次，那么每达到/超过一次系统等待1秒钟再继续

    ch_interaction_count = ch_interaction_count + 1.

    IF ch_interaction_count >= zif_cmbc_constant=>interaction_frequency.
      WAIT UP TO 1 SECONDS.
      CLEAR ch_interaction_count.
    ENDIF.

  ENDMETHOD.
ENDCLASS.
