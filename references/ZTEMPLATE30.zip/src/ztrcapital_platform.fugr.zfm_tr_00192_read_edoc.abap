FUNCTION ZFM_TR_00192_READ_EDOC.
*"----------------------------------------------------------------------
*"*"本地接口：
*"  IMPORTING
*"     REFERENCE(IM_S_SELECTION) TYPE  ZTRS_0004_SELECTION
*"     REFERENCE(IM_FROM_SEARCH_HELP) TYPE  FLAG OPTIONAL
*"----------------------------------------------------------------------











ENDFUNCTION.
