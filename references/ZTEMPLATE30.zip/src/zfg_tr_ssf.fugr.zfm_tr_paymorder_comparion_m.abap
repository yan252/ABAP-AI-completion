FUNCTION ZFM_TR_PAYMORDER_COMPARION_M.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     REFERENCE(IM_T_PAYMORDERS) TYPE  ZTRS_PAYMORDER_TAB
*"     REFERENCE(IM_ZZFTYPE) TYPE  ZTRT2001-ZZFTYPE OPTIONAL
*"  EXCEPTIONS
*"      ERROR
*"--------------------------------------------------------------------
LOOP AT im_t_paymorders INTO DATA(ls_order).

    CALL FUNCTION 'ZFM_TR_PAYMORDER_COMPARION_S'
      EXPORTING
        im_docno   = ls_order-docno
        im_zzftype = im_zzftype
      EXCEPTIONS
        error      = 1
        OTHERS     = 2.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid
              TYPE 'E'
              NUMBER sy-msgno
              WITH sy-msgv1
                   sy-msgv2
                   sy-msgv3
                   sy-msgv4
                   RAISING error.
    ENDIF.

  ENDLOOP.





ENDFUNCTION.
