class ZCL_BANK_ACTION_CMBC_CNAPS definition
  public
  inheriting from ZCL_BANK_ABSTRACT_ACTION
  final
  create public .

public section.
protected section.

  methods FEEDBACK_FROM_BANK_CORE
    redefinition .
  methods RUN_FOR_SPECIFIC_ACTION_CORE
    redefinition .
private section.
ENDCLASS.



CLASS ZCL_BANK_ACTION_CMBC_CNAPS IMPLEMENTATION.


METHOD FEEDBACK_FROM_BANK_CORE.
*    DATA: lt_response_entries TYPE ztrs_acc_data_from_bank_tab.
*    LOOP AT banks_list INTO DATA(ls_bank_list)
*          WHERE instance IS BOUND.
*      ls_bank_list-instance->export_after_processed(
*        IMPORTING
*          et_entries = lt_response_entries ).
*      LOOP AT lt_response_entries INTO DATA(ls_response_entries)
*               WHERE bank_ind = ls_bank_list-bank_ind.
*        zcl_abstract_bank_account=>create(
*                                    im_bank_indicator = ls_response_entries-bank_ind
*                                    im_action         = action
*                                       )->set_data( ls_response_entries-data_value_list ).
*      ENDLOOP.
*    ENDLOOP.
  ENDMETHOD.


METHOD RUN_FOR_SPECIFIC_ACTION_CORE.

      create_bank( 'CMBC' ).

  ENDMETHOD.
ENDCLASS.
