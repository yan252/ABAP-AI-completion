FUNCTION ZFM_TR_ZFD_AUTH_307.
**"--------------------------------------------------------------------
**"*"局部接口：
**"  IMPORTING
**"     REFERENCE(BUKRS) TYPE  BUKRS
**"     REFERENCE(ACTIVE) TYPE  ZTR_KL_ACTION
**"     REFERENCE(ZZFS) TYPE  ZTR_ZFD_ZFS
**"     REFERENCE(STATS) TYPE  ZTRDM_APPRO
**"  EXCEPTIONS
**"      ERR
**"--------------------------------------------------------------------
*DATA: lv_msgv1 TYPE string,
*        lv_msgv2 TYPE string,
*        lv_msgv3 TYPE string.
*
*  IF NOT  ( zcl_tr_3024_gui=>auth = abap_true OR sy-sysid = 'ERP' ).
*    sy-subrc = 0.
*    RETURN.
*  ENDIF.
*  AUTHORITY-CHECK OBJECT 'Z_TR307'
*    ID 'BUKRS' FIELD bukrs
*    ID 'ZTR_KLACT' FIELD active
*    ID 'ZTR_KLZFFS' FIELD zzfs
*    ID 'ZTR_KLSTAT' FIELD stats.
*  IF sy-subrc <> 0.
*    zcl_wd_common=>get_dom_value(
*      EXPORTING
*        im_domnam = 'ZDMTR_KL_ACTION'
*        im_domval = active
*      RECEIVING
*        ex_desc   = lv_msgv1
*    ).
*
*    zcl_wd_common=>get_dom_value(
*      EXPORTING
*        im_domnam = 'ZDMTR_KL_ZFFS'
*        im_domval = zzfs
*      RECEIVING
*        ex_desc   = lv_msgv2
*    ).
*
*    zcl_wd_common=>get_dom_value(
*      EXPORTING
*        im_domnam = 'ZTRDM_APPRO'
*        im_domval = stats
*      RECEIVING
*        ex_desc   = lv_msgv3
*    ).
*    MESSAGE e225(ztr05) WITH lv_msgv1 bukrs lv_msgv3 lv_msgv2 RAISING err.
*  ENDIF.





ENDFUNCTION.
