class ZCL_PAYMORDER_MEMORY_ROOT definition
  public
  final
  create public
  shared memory enabled .

public section.

  methods GET_ORDER
    exporting
      !EX_S_2001 type ZTRT2001
      !EX_S_2002 type ZTRT2002
      !EX_S_2003 type ZTRT2003
      !EX_S_2101 type ZTRT2101
      !EX_ZZFTYPE type ZTRT2001-ZZFTYPE
      !EX_SSFUUID type ZTR_ENCRYPTION_UUID
      !EX_COMPLETION type FLAG
      !EX_S_SYST type SYST .
  methods SET_ORDER
    importing
      !IM_S_2001 type ZTRT2001 optional
      !IM_S_2002 type ZTRT2002 optional
      !IM_S_2003 type ZTRT2003 optional
      !IM_S_2101 type ZTRT2101 optional
      !IM_ZZFTYPE type ZTRT2001-ZZFTYPE optional .
  methods DELETE_ORDER .
  class-methods ENQUEUE
    exceptions
      ERROR .
  class-methods DEQUEUE .
  methods AFTER_PROCESS
    importing
      !IM_SSFUUID type ZTRT2001-SSFUUID optional
      !IM_S_SYST type SYST optional
      !IM_COMPLETION type FLAG optional .
protected section.
private section.

  data MS_2001 type ZTRT2001 .
  data MS_2002 type ZTRT2002 .
  data MS_2003 type ZTRT2003 .
  data MS_2101 type ZTRT2101 .
  data M_ZZFTYPE type ZTRT2001-ZZFTYPE .
  data M_ENCRYPTION_COMPLETION type FLAG .
  data M_DECRYPTION_COMPLETION type FLAG .
  data MS_ERROR_MESSAGE type SYST .
  data ORDERS_MEMORY type ZTRS_PAYMORD_SHAREMEMORY_TAB .
ENDCLASS.



CLASS ZCL_PAYMORDER_MEMORY_ROOT IMPLEMENTATION.


METHOD after_process.


    READ TABLE orders_memory ASSIGNING FIELD-SYMBOL(<fs_order_memory>)
              WITH KEY clientcode = sy-mandt
                       uname = sy-uname
                       datum = sy-datum.

    IF sy-subrc <> 0.
      RETURN.
    ENDIF.

    <fs_order_memory>-ssfuuid = im_ssfuuid.
    <fs_order_memory>-completion = im_completion.
    <fs_order_memory>-syst = im_s_syst.

  ENDMETHOD.


METHOD delete_order.
    DELETE orders_memory WHERE uname = sy-uname
                         AND   datum = sy-datum.
  ENDMETHOD.


METHOD dequeue.
    CALL FUNCTION 'DEQUEUE_EZTRS_PAYMORD_M'
      EXPORTING
        mode_ztrs_paymord_sharememor00 = 'E'
        clientcode                     = sy-mandt
        uname                          = sy-uname
        datum                          = sy-datum
        x_clientcode                   = ' '
        x_uname                        = ' '
        x_datum                        = ' '
        _scope                         = '3'
        _synchron                      = ' '
        _collect                       = ' '.

  ENDMETHOD.


METHOD enqueue.
    CALL FUNCTION 'ENQUEUE_EZTRS_PAYMORD_M'
      EXPORTING
        mode_ztrs_paymord_sharememor00 = 'E'
        clientcode                     = sy-mandt
        uname                          = sy-uname
        datum                          = sy-datum
        x_clientcode                   = ' '
        x_uname                        = ' '
        x_datum                        = ' '
        _scope                         = '2'
        _wait                          = ' '
        _collect                       = ' '
      EXCEPTIONS
        foreign_lock                   = 1
        system_failure                 = 2
        OTHERS                         = 3.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid
              TYPE sy-msgty
              NUMBER sy-msgno
              WITH sy-msgv1
                   sy-msgv2
                   sy-msgv3
                   sy-msgv4
              RAISING error.
    ENDIF.

  ENDMETHOD.


METHOD get_order.
    DATA: l_count TYPE i.
    DATA: l_dummy TYPE flag.

    LOOP AT orders_memory INTO DATA(ls_order_memory)
          WHERE CLIENTCODE = sy-mandt
          and   uname = sy-uname
          AND   datum = sy-datum.
      ADD 1 TO l_count.
    ENDLOOP.

    CASE l_count.
      WHEN 0.
        MESSAGE e329(ztr_bank_application)
                WITH sy-uname
                      sy-datum
                INTO l_dummy.
        ex_s_syst = sy.
        ex_completion = 'X'.
      WHEN 1.
        ex_s_2001 = ls_order_memory-ztrt2001.
        ex_s_2002 = ls_order_memory-ztrt2002.
        ex_s_2003 = ls_order_memory-ztrt2003.
        ex_s_2101 = ls_order_memory-ztrt2101.
        ex_s_syst = ls_order_memory-syst.
        ex_completion = ls_order_memory-completion.
        ex_ssfuuid = ls_order_memory-ssfuuid.
      WHEN OTHERS.
        MESSAGE e330(ztr_bank_application)
                WITH sy-uname
                      sy-datum
                INTO l_dummy.
        ex_s_syst = sy.
        ex_completion = 'X'.
    ENDCASE.
  ENDMETHOD.


METHOD set_order.
    READ TABLE orders_memory ASSIGNING FIELD-SYMBOL(<fs_order_memory>)
         WITH KEY CLIENTCODE = sy-mandt
                  uname = sy-uname
                  datum = sy-datum.
    IF sy-subrc = 0.
*      程序错误，用户只能在webdynpro中处理一个支付单，处理结束后从内存清除掉
*      在处理一个支付单时，内存中不应该存在一个没处理结束的记录
      <fs_order_memory>-completion = 'X'.
      MESSAGE e328(ztr_bank_application)
              WITH sy-uname
                   sy-datum
              INTO DATA(l_dummy).
      <fs_order_memory>-syst = sy.
      RETURN.
    ENDIF.

    APPEND INITIAL LINE TO orders_memory ASSIGNING <fs_order_memory>.
    <fs_order_memory>-clientcode = sy-mandt.
    <fs_order_memory>-datum = sy-datum.
    <fs_order_memory>-uname = sy-uname.
    <fs_order_memory>-ztrt2001 = im_s_2001.
    <fs_order_memory>-ztrt2002 = im_s_2002.
    <fs_order_memory>-ztrt2003 = im_s_2003.
    <fs_order_memory>-ztrt2101 = im_s_2101.
    <fs_order_memory>-zzftype = im_zzftype.

  ENDMETHOD.
ENDCLASS.
