class ZCL_BANK_APPLICATION_LOGGER definition
  public
  final
  create public .

public section.

  interfaces ZIF_BANK_LOGGER_PROTOCAL .

  aliases ADD_LOG
    for ZIF_BANK_LOGGER_PROTOCAL~ADD_LOG .
  aliases ADD_MESSAGE_COLLECTOR
    for ZIF_BANK_LOGGER_PROTOCAL~ADD_MESSAGE_COLLECTOR .
  aliases GET_MESSAGE_COLLECTOR
    for ZIF_BANK_LOGGER_PROTOCAL~GET_MESSAGE_COLLECTOR .
  aliases IMPORT_MESSAGES
    for ZIF_BANK_LOGGER_PROTOCAL~IMPORT_MESSAGES .
  aliases LOG_FILE
    for ZIF_BANK_LOGGER_PROTOCAL~LOG_FILE .
  aliases SAVE
    for ZIF_BANK_LOGGER_PROTOCAL~SAVE .

  class-data LOG_OBJECT_TYPE_PAYMENT_ENTRY type ZTR_BANK_LOG_OBJ_TYPE value '1' ##NO_TEXT.
  class-data LOG_OBJECT_TYPE_PAYMENT_ORDER type ZTR_BANK_LOG_OBJ_TYPE value '3' ##NO_TEXT.
  class-data LOG_OBJECT_TYPE_BANK_ACCOUNT type ZTR_BANK_LOG_OBJ_TYPE value '2' ##NO_TEXT.

  methods CONSTRUCTOR
    exceptions
      CREATE_UUID_ERROR .
  methods IF_ERROR
    importing
      !IM_UUID type SYSUUID_C22
    returning
      value(RE_ERROR) type FLAG .
protected section.
private section.

  data MESSAGES type ZTRS_MESSAGE_COLLECTOR_TAB .
  data LOGS type ZTRT_BANK_LOG_TAB .
  data LOGGER_UUID type SYSUUID_C22 .
  data FILE_LOGS type ZTRT_BANK_FILE_TAB .

  methods GET_LOG_ADMIN
    returning
      value(RE_LOG_ADMIN) type ZTRS_BANK_LOG_ADAMIN .
  methods GET_LOG_CALLSTACK
    returning
      value(RE_CALLSTACK) type ZTRS_BANK_LOG_STACK .
ENDCLASS.



CLASS ZCL_BANK_APPLICATION_LOGGER IMPLEMENTATION.


  METHOD constructor.
    TRY.
        logger_uuid = cl_system_uuid=>if_system_uuid_static~create_uuid_c22( ).
      CATCH cx_uuid_error.
        MESSAGE e001(ztr_bank_application)
         RAISING create_uuid_error.
    ENDTRY.
  ENDMETHOD.


  METHOD get_log_admin.
    DATA(ls_system_info) = zcl_global_technical_service=>get_system_info( )..

    MOVE: ls_system_info-datum     TO re_log_admin-erdat,
          ls_system_info-uzeit     TO re_log_admin-erzet,
          ls_system_info-uname     TO re_log_admin-ernam,
          ls_system_info-tcode     TO re_log_admin-tcode,
          ls_system_info-timestamp TO re_log_admin-update_timestamp,
          ls_system_info-timezone  TO re_log_admin-update_timezone.
  ENDMETHOD.


  METHOD get_log_callstack.
    DATA lt_call_stack TYPE abap_callstack.

    CALL FUNCTION 'SYSTEM_CALLSTACK'
      EXPORTING
        max_level = 0
      IMPORTING
        callstack = lt_call_stack.

    DELETE  lt_call_stack WHERE mainprogram = 'ZCL_BANK_APPLICATION_LOGGER===CP'
                          OR    mainprogram = 'ZCL_BANK_LOGGER_PROTOCAL======CP'.

    READ TABLE lt_call_stack INTO DATA(ls_call_stack) INDEX 1.

    MOVE: ls_call_stack-mainprogram TO re_callstack-mainprogram,
          ls_call_stack-blockname   TO re_callstack-blockname,
          ls_call_stack-blocktype   TO re_callstack-blocktype,
          ls_call_stack-flag_system TO re_callstack-flag_system,
          ls_call_stack-include     TO re_callstack-include.
  ENDMETHOD.


  method IF_ERROR.
  endmethod.


  METHOD zif_bank_logger_protocal~add_log.
    get_message_collector( im_s_fields-uuid )->add_message(
                                            i_class  = im_s_fields-msgid
                                            i_number = im_s_fields-msgno
                                            i_type   = im_s_fields-msgty
                                            i_var1   = im_s_fields-msgv1
                                            i_var2   = im_s_fields-msgv2
                                            i_var3   = im_s_fields-msgv3
                                            i_var4   = im_s_fields-msgv4 ).

    APPEND VALUE #( loguuid         = logger_uuid
                    logitem         = lines( logs ) + 1
                    mtype           = im_s_fields-msgty
                    mid             = im_s_fields-msgid
                    mnumber         = im_s_fields-msgno
                    message         = im_s_fields-message
                    bussinessdata   = im_s_fields-bussinessdata
                    admin           = get_log_admin( )
                    callstack       = get_log_callstack( ) )
                    TO logs.

  ENDMETHOD.


  METHOD zif_bank_logger_protocal~add_message_collector.
    READ TABLE messages ASSIGNING FIELD-SYMBOL(<fs_message>)
         WITH KEY uuid = im_uuid.
    IF sy-subrc <> 0.
      APPEND VALUE ztrs_message_collector(
                           uuid     = im_uuid
                           instance = NEW #( i_message_key  = im_uuid
                                             i_main_program = im_mainprogram
                                             i_class        = im_default_message_class ) )
                    TO messages
                    ASSIGNING <fs_message>.
    ENDIF.

    ro_instance = <fs_message>-instance.
  ENDMETHOD.


  METHOD zif_bank_logger_protocal~get_message_collector.
    READ TABLE messages INTO DATA(ls_message)
         WITH KEY uuid = im_uuid.
    ro_message_collector = ls_message-instance.
  ENDMETHOD.


  METHOD zif_bank_logger_protocal~import_messages.

    DATA(lo_message_collector) = get_message_collector( im_uuid ).

    LOOP AT im_t_messages INTO DATA(ls_message).
      lo_message_collector->add_message(
                                  i_class  = ls_message-id
                                  i_number = ls_message-number
                                  i_type   = ls_message-type
                                  i_var1   = ls_message-message_v1
                                  i_var2   = ls_message-message_v2
                                  i_var3   = ls_message-message_v3
                                  i_var4   = ls_message-message_v4 ).

      APPEND VALUE #( loguuid         = logger_uuid
                      logitem         = lines( logs ) + 1
                      mtype           = ls_message-type
                      mid             = ls_message-id
                      mnumber         = ls_message-number
                      message         = ls_message-message
                      bussinessdata   = im_s_log_businessdata_data
                      admin           = get_log_admin( )
                      callstack       = get_log_callstack( ) )
                      TO logs.
    ENDLOOP.
  ENDMETHOD.


  METHOD zif_bank_logger_protocal~log_file.
    READ TABLE file_logs ASSIGNING FIELD-SYMBOL(<fs_file>)
         WITH KEY file_uuid = im_file_uuid.
    IF sy-subrc <> 0.
      APPEND INITIAL LINE TO file_logs ASSIGNING <fs_file>.
    ENDIF.
    <fs_file>-file_uuid = im_file_uuid.
    <fs_file>-bank_ind = im_bank_indicator.
    <fs_file>-bank_func = im_function.
    <fs_file>-bank_action = im_action.
    <fs_file>-file_direction = im_file_direction.
    <fs_file>-step = im_step.
    <fs_file>-admin = get_log_admin( ).
    ASSIGN im_cfile->* TO FIELD-SYMBOL(<f_cfile>).
    IF sy-subrc = 0.
      <fs_file>-cfile = <f_cfile>.
    ENDIF.

    ASSIGN im_xfile->* TO FIELD-SYMBOL(<f_xfile>).
    IF sy-subrc = 0.
      <fs_file>-xfile = <f_xfile>.
    ENDIF.

  ENDMETHOD.


  METHOD zif_bank_logger_protocal~save.
    MODIFY ztrt_bank_log FROM TABLE logs.
    MODIFY ztrt_bank_file FROM TABLE file_logs.
  ENDMETHOD.
ENDCLASS.
