FUNCTION ZFM_TR_SET_PAYMEDOC_ABSTRACT.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     VALUE(I_TREE_TYPE) TYPE  DMEE_TREETYPE_ABA
*"     VALUE(I_TREE_ID) TYPE  DMEE_TREEID_ABA
*"     VALUE(I_ITEM)
*"     VALUE(I_PARAM)
*"     VALUE(I_UPARAM)
*"  EXPORTING
*"     REFERENCE(O_VALUE)
*"     REFERENCE(C_VALUE)
*"     REFERENCE(N_VALUE)
*"     REFERENCE(P_VALUE)
*"  TABLES
*"      I_TAB
*"--------------------------------------------------------------------
ASSIGN COMPONENT 'ZTRS_DMEE_ECD_LIST-DOC1R' OF STRUCTURE i_item TO FIELD-SYMBOL(<f_doc1r>).
  CONCATENATE zcl_bank_payment_entry=>transaction_reference_prefix "'APPTRANSACTIONREFERENCE'
              <f_doc1r>
              INTO c_value.





ENDFUNCTION.
