FUNCTION ZFM_TR_00192_EXP_BENEFICIARY.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  EXPORTING
*"     REFERENCE(EX_S_BENEFICIARY) TYPE  ZTRS_00192_BENEFICIARY
*"--------------------------------------------------------------------
ex_s_beneficiary = ztrs_00192_beneficiary.
  IF selector IS BOUND.
    DATA(l_init_bukrs) = selector->get_initiating_bukrs( ).
    SELECT SINGLE * INTO @DATA(ls_0189_3)
          FROM ztrt0189_3_view
          WHERE ibukrs = @l_init_bukrs
          AND   bukrs = @ex_s_beneficiary-bbukrs
          AND   account_usage = '3'.
    IF sy-subrc = 0.
      MOVE: ls_0189_3-bank_ind TO ex_s_beneficiary-bbank_ind,
            ls_0189_3-bankl TO ex_s_beneficiary-zskbankl,
            ls_0189_3-banka TO ex_s_beneficiary-zskbanka,
            ls_0189_3-banks TO ex_s_beneficiary-bbanks,
            ls_0189_3-hbkid TO ex_s_beneficiary-bhbkid,
            ls_0189_3-hktid TO ex_s_beneficiary-bhktid,
            ls_0189_3-yhzh TO ex_s_beneficiary-zskbnkn,
            ls_0189_3-zhmc TO ex_s_beneficiary-bzhmc.
    ENDIF.
  ENDIF.





ENDFUNCTION.
