class ZCL_BANK_BOC_FUNCTION_M03 definition
  public
  inheriting from ZCL_BANK_FUNCTION_TRANSACTIONS
  final
  create public .

public section.

  interfaces ZIF_BOC_FUNCTION .

  aliases RAISE_B2EERROR
    for ZIF_BOC_FUNCTION~RAISE_B2EERROR .

  methods ZIF_BANK_FUNCTION~SET_SENDING_DATA_REFERENCE
    redefinition .
protected section.

  methods CHECK_RESPONSE_IF_FINISHED
    redefinition .
  methods PROCESSING_RESPONSE_INTL_CORE
    redefinition .
private section.

  methods SET_DOMAIN_VALUE_TO_QUERY
    importing
      !IM_DOMAIN_NAME type CLIKE
      !IM_FIELDNAME type CLIKE .
ENDCLASS.



CLASS ZCL_BANK_BOC_FUNCTION_M03 IMPLEMENTATION.


  METHOD CHECK_RESPONSE_IF_FINISHED.
    FIELD-SYMBOLS: <fs_response>        TYPE ztrs_boc_b2e0035_response.
    CONSTANTS: c_startrecord TYPE string VALUE 'begnum',
               c_pagenumber  TYPE string VALUE 'recnum'.

    DATA(ls_sending_xml_ref) = get_sending_file_by_sequence( current_sending_sequence ).
    ASSIGN ls_sending_xml_ref-cfile->* TO FIELD-SYMBOL(<f_xml_string>).
    ASSIGN ls_sending_xml_ref-xfile->* TO FIELD-SYMBOL(<f_xml_xstring>).

    zcl_bank_data_mapping_engine=>get_element_value(
                                     EXPORTING
                                       im_xml_string = <f_xml_string>
                                       im_t_fieldname = VALUE ztrs_fieldname_tab( ( name = c_startrecord )
                                                                                  ( name = c_pagenumber ) )
                                     IMPORTING
                                       ex_t_return_errors = DATA(lt_return_errors)
                                       ex_t_element_values = DATA(lt_element_values) ).

    IF lt_return_errors IS NOT INITIAL.
      messages->add_message_set( lt_return_errors ).
      current_response_is_finished = yes.
      RETURN.
    ENDIF.

    READ TABLE lt_element_values ASSIGNING FIELD-SYMBOL(<fs_startrecord>)
         WITH KEY name = c_startrecord.

    READ TABLE lt_element_values ASSIGNING FIELD-SYMBOL(<fs_pagenumber>)
         WITH KEY name = c_pagenumber.

    DATA(ls_response_data) = get_current_response_data( ).
    ASSIGN ls_response_data-response_ref->* TO <fs_response>.

    IF ( <fs_response>-totalnum < <fs_pagenumber>-data ) OR
        ( <fs_response>-trans IS INITIAL ) or
       ( <fs_response>-h_status-rspcod = 'B001' or
         <fs_response>-h_status-rspcod = 'B003' ).
*      当前没有返回明细记录，或返回明细记录小于请求的条目数，视为完成
      current_response_is_finished = yes.
      RETURN.
    ELSE.
*  not finished
      <fs_startrecord>-data = <fs_startrecord>-data + function_config-max_resp_item.
      SHIFT <fs_startrecord>-data LEFT DELETING LEADING '0'.
      CONDENSE <fs_startrecord>-data.
      <fs_pagenumber>-data = function_config-max_resp_item.
      SHIFT <fs_pagenumber>-data LEFT DELETING LEADING '0'.
      CONDENSE <fs_pagenumber>-data.

      zcl_bank_data_mapping_engine=>reset_element_value(
                                       EXPORTING
                                         im_t_element_values = lt_element_values
                                       IMPORTING
                                         et_return_errors = lt_return_errors
                                       CHANGING
                                         ch_xml_xstring = <f_xml_xstring>
                                         ch_xml_string = <f_xml_string> ).
      IF lt_return_errors IS NOT INITIAL.
        messages->add_message_set( lt_return_errors ).
        current_response_is_finished = yes.
        RETURN.
      ELSE.
        current_response_is_finished = no.
      ENDIF.
    ENDIF.


  ENDMETHOD.


  METHOD PROCESSING_RESPONSE_INTL_CORE.
    current_response_is_finished = yes.
*    processing_response_by_dbtable(
*                im_data_db_table = 'ZTRT_BOC_TRNS'
*                im_detail_response_component = 'TRANS'
*                im_statuscode_componnet = 'H_STATUS-RSPCOD'
*                im_statustext_component = 'H_STATUS-RSPMSG'
*                IM_ACCOUNT_NUMBER_FIELD = 'ACTACN'  ).
  ENDMETHOD.


  METHOD set_domain_value_to_query.
    FIELD-SYMBOLS: <ft_data> TYPE ztrs_boc_edoc_list_medium_t.
    DATA: lt_data TYPE ztrs_boc_edoc_list_medium_t.

    DATA(lt_boc_domain_values) = zcl_global_technical_service=>get_domain_values( im_domain_name ).

    ASSIGN sending_data_reference->* TO <ft_data>.

    LOOP AT <ft_data> INTO DATA(ls_data).
      LOOP AT lt_boc_domain_values INTO DATA(ls_boc_domain_value).
        ASSIGN COMPONENT im_fieldname OF STRUCTURE ls_data TO FIELD-SYMBOL(<f_field>).
        IF sy-subrc = 0.
          <f_field> = ls_boc_domain_value-domvalue_l.
        ENDIF.
        APPEND ls_data TO lt_data.
      ENDLOOP.
    ENDLOOP.

    <ft_data> = lt_data.
  ENDMETHOD.


  METHOD zif_bank_function~set_sending_data_reference.
    super->set_sending_data_reference( im_data_reference ).

    set_domain_value_to_query(
                  im_domain_name = 'ZTRDM_BOC_DRAFTTYPE'
                  im_fieldname = 'DRAFTTYPE' ).


    set_domain_value_to_query(
                  im_domain_name = 'ZDM_TR_BOC_0102_ACTTYP'
                  im_fieldname = 'ACTTYP' ).

  ENDMETHOD.


  METHOD ZIF_BOC_FUNCTION~RAISE_B2EERROR.
    raise_b2eerror.
    check_response_if_finished( ).
  ENDMETHOD.
ENDCLASS.
