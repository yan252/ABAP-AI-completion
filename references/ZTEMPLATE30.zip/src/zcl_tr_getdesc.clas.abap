class ZCL_TR_GETDESC definition
  public
  final
  create public .

public section.

  class-methods GET_BUKRS_DESC
    importing
      !IV_BUKRS type ANY
    returning
      value(EV_BUTXT) type STRING .
  class-methods GET_BANK_DETAIL
    importing
      !IV_BUKRS type BUKRS
      !IV_WAERS type WAERS optional
      !IV_HBKID type HBKID
      !IV_HKTID type HKTID
      !IV_LANGU type SY-LANGU
    exporting
      value(EV_TEXT1) type CHAR50
      value(EV_TEXT2) type BANKA .
  class-methods GET_BTYPE_DESC
    importing
      !IV_BTYPE type ZTR_DOCTYPE
    returning
      value(ES_9002) type ZTRT9002 .
  class-methods GET_KUNNR_DESC
    importing
      !IV_KUNNR type KUNNR
    returning
      value(EV_NAME1) type NAME1_GP .
  class-methods GET_LIFNR_DESC
    importing
      !IV_LIFNR type LIFNR
    returning
      value(EV_NAME1) type NAME1_GP .
  class-methods GET_FUND_DESC
    importing
      !IV_FUND type ZTR_FUND_FLOW
    returning
      value(EV_FUND_D) type ZTR_FUND_FLOWD .
  class-methods GET_MATNR_DESC
    importing
      !IV_MATNR type MATNR
    returning
      value(EV_MAKTX) type MAKTX .
  class-methods GET_BANKL_DESC
    importing
      !IV_BANKS type BANKS optional
      !IV_BANKL type BANKK
    returning
      value(EV_BANKA) type BANKA .
  class-methods GET_DOMAIN_DESE
    importing
      !IV_DOMNAME type DOMNAME
      !IV_LANGU type DDLANGUAGE
      !IV_VALUE type DOMVALUE_L
    returning
      value(EV_DDTEXT) type VAL_TEXT .
  class-methods GET_FKTK_DESC
    importing
      !IV_ZTERM type DZTERM
    returning
      value(EV_TEXT1) type TEXT1_052 .
  class-methods GET_FKFS_DESC
    importing
      !IV_BUKRS type BUKRS
      !IV_ZLSCH type DZLSCH
    returning
      value(EV_TEXT1) type TEXT1_042Z .
  class-methods GET_YHZH_DESC
    importing
      !IV_BUKRS type BUKRS
      !IV_HBKID type HBKID
      !IV_HKTID type HKTID
    exporting
      !EV_YHZH type ZTR_YHZH
      !EV_TEXT1 type FIBL_TXT50
      !EV_BANKS type BANKS
      !EV_BANKL type BANKL
      !EV_BANKA type BANKA .
  class-methods GET_PRCTR_DESC
    importing
      !IV_PRCTR type PRCTR
    returning
      value(EV_LTEXT) type LTEXT .
  class-methods GET_KOSTL_DESC
    importing
      !IV_KOKRS type KOKRS
      !IV_KOSTL type KOSTL
    returning
      value(EV_KTEXT) type KTEXT .
  class-methods GET_RSTGR_DESC
    importing
      !IV_BUKRS type BUKRS
      !IV_RSTGR type RSTGR
    returning
      value(EV_TXT20) type TXT20_053 .
  class-methods GET_RANL_FROM_DOCNO
    importing
      !IV_DOCNO type ZTR_DOCNO
    returning
      value(EV_RANL) type RANL .
  class-methods GET_VKORG_DESC
    importing
      !IV_VKORG type ANY
    returning
      value(EV_VTEXT) type STRING .
  class-methods GET_VTWEG_DESC
    importing
      !IV_VTWEG type ANY
    returning
      value(EV_VTEXT) type STRING .
  class-methods GET_KKBER_DESC
    importing
      !IV_KKBER type KKBER
    returning
      value(EV_KKBTX) type KKBTX .
  class-methods GET_TVKBZ_DESC
    importing
      !IV_VKBUR type VKBUR
    returning
      value(EV_BEZEI) type BEZEI .
  class-methods GET_KXXZ_DESC
    importing
      !IV_KXXZ type ZTR_KXXZ
    returning
      value(EV_KXXZT) type ZTR_KXXZ_T .
  class-methods GET_BP_NAME
    importing
      !IV_BP type PARTNER
    returning
      value(EV_NAME) type BU_NAMEOR1 .
  class-methods GET_WAERS_DESC
    importing
      !IV_WAERS type WAERS_CURC
    returning
      value(EV_KTEXT) type KTEXT_CURT .
  class-methods GET_HKONT_DESC
    importing
      !SAKNR type SAKNR optional
    exporting
      !TXT20 type TXT20_SKAT .
  class-methods GET_ZLSCH_DESC
    importing
      !ZLSCH type ZTR_ZSKFS
    exporting
      !ZLSCHT type ZTR_ZSKFS .
  class-methods GET_ZDJZT_SK_DESC
    importing
      !IV_ZDJZT type ZTR_DJZT_SKD
    exporting
      !EV_ZDJZT_T type ZDJZTMS .
  class-methods GET_WERKS_DESC
    importing
      !IV_WERKS type WERKS_D
    exporting
      !EV_WERKS_T type WERKSTXT .
  class-methods GET_LGORT_DESC
    importing
      !IV_WERKS type WERKS_D
      !IV_LGORT type LGORT_D
    exporting
      !EV_LGORT_T type ZTR_LGORT .
  class-methods GET_FLOW_CODE_DESC
    importing
      !IV_BUKRS type BUKRS
      !IV_FLOW_CODE type ZTR_FLOWCODE
    returning
      value(RV_FLOW_CODE_TXT) type ZTR_FLOWCODE_TEXT .
protected section.
private section.
ENDCLASS.



CLASS ZCL_TR_GETDESC IMPLEMENTATION.


METHOD get_bankl_desc.
    DATA lv_bankl TYPE bankl.
    lv_bankl = iv_bankl.

    CONDENSE lv_bankl.

    CHECK lv_bankl IS NOT INITIAL.
    IF iv_banks IS NOT INITIAL.

      SELECT SINGLE banka INTO ev_banka
        FROM bnka
       WHERE banks = iv_banks
         AND bankl = lv_bankl.

    ELSE.
      SELECT SINGLE banka INTO ev_banka
        FROM bnka
*     where banks = iv_banks
       WHERE   bankl = iv_bankl.
    ENDIF.
  ENDMETHOD.


METHOD get_bank_detail.

    SELECT SINGLE text1 INTO ev_text1 "账户的描述
      FROM t012t
     WHERE spras = sy-langu
       AND bukrs = iv_bukrs
       AND hbkid = iv_hbkid
       AND hktid = iv_hktid.


    SELECT SINGLE b~banka INTO ev_text2
      FROM t012 AS a INNER JOIN bnka AS b ON a~banks = b~banks AND a~bankl = b~bankl
     WHERE a~bukrs = iv_bukrs
       AND a~hbkid = iv_hbkid.


  ENDMETHOD.


METHOD get_bp_name.

    SELECT SINGLE name_org1 FROM but000 INTO ev_name WHERE partner = iv_bp.

  ENDMETHOD.


METHOD get_btype_desc.
    SELECT SINGLE * INTO es_9002 FROM ztrt9002 WHERE doctype = iv_btype.
  ENDMETHOD.


METHOD get_bukrs_desc.
    CHECK iv_bukrs IS NOT INITIAL.

    SELECT SINGLE butxt
      INTO ev_butxt
      FROM t001
     WHERE bukrs = iv_bukrs.
  ENDMETHOD.


METHOD get_domain_dese.
    SELECT SINGLE ddtext INTO ev_ddtext
      FROM dd07t
     WHERE domname = iv_domname
       AND ddlanguage = iv_langu
       AND domvalue_l = iv_value.
  ENDMETHOD.


METHOD get_fkfs_desc.

*    SELECT SINGLE land1 INTO @DATA(lv_land1)
*      FROM t001
*     WHERE bukrs = @iv_bukrs.
*
*    SELECT SINGLE text1 INTO @ev_text1
*      FROM t042z
*     WHERE land1 = @lv_land1
*       AND zlsch = @iv_zlsch.
*
*    "从配置表ZTRT0120_COL中取数
*    IF ev_text1 IS INITIAL.
*      SELECT SINGLE zlsch_t INTO @ev_text1
*        FROM ztrt0120_col
*      WHERE zlsch = @iv_zlsch.
*    ENDIF.

  ENDMETHOD.


METHOD get_fktk_desc.
    SELECT SINGLE text1 INTO ev_text1
      FROM t052u
     WHERE zterm = iv_zterm
       AND spras = sy-langu.

  ENDMETHOD.


METHOD get_flow_code_desc.
    SELECT SINGLE txt20 INTO rv_flow_code_txt FROM t053s WHERE bukrs = iv_bukrs
                                                           AND rstgr = iv_flow_code
                                                           AND spras = sy-langu.
  ENDMETHOD.


METHOD get_fund_desc.
*    SELECT SINGLE fund_flowd INTO ev_fund_d FROM ztrt9026 WHERE fund_flow = iv_fund.
  ENDMETHOD.


METHOD get_hkont_desc.


    SELECT SINGLE txt20 FROM skat INTO txt20 WHERE saknr = saknr AND spras = sy-langu.

  ENDMETHOD.


METHOD get_kkber_desc.

    SELECT SINGLE kkbtx FROM t014t INTO ev_kkbtx WHERE kkber = iv_kkber AND spras = sy-langu.

  ENDMETHOD.


METHOD get_kostl_desc.

    SELECT SINGLE ktext INTO ev_ktext
       FROM csks AS a INNER JOIN cskt AS b ON a~kokrs = b~kokrs AND a~kostl = b~kostl
      WHERE a~kokrs = iv_kokrs
        AND a~kostl = iv_kostl
        AND a~datbi GE sy-datum.

  ENDMETHOD.


METHOD get_kunnr_desc.
    DATA lv_kunnr TYPE kunnr.

    CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
      EXPORTING
        input  = iv_kunnr
      IMPORTING
        output = lv_kunnr.

    SELECT SINGLE name1 INTO ev_name1 FROM kna1 WHERE kunnr = lv_kunnr.
  ENDMETHOD.


METHOD get_kxxz_desc.

*    SELECT SINGLE zkxxz_t INTO ev_kxxzt
*     FROM ztrc0003
*     WHERE zkxxz = iv_kxxz
*       AND spras = sy-langu.

  ENDMETHOD.


METHOD get_lgort_desc.

    SELECT SINGLE lgobe FROM t001l INTO ev_lgort_t WHERE werks = iv_werks AND lgort = iv_lgort.

  ENDMETHOD.


METHOD get_lifnr_desc.

    DATA lv_linfr TYPE lifnr.

    CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
      EXPORTING
        input  = iv_lifnr
      IMPORTING
        output = lv_linfr.


    SELECT SINGLE name1 INTO ev_name1 FROM lfa1 WHERE lifnr = lv_linfr.
  ENDMETHOD.


METHOD get_matnr_desc.
    SELECT SINGLE maktx INTO ev_maktx FROM makt WHERE matnr = iv_matnr
                                                  AND spras = sy-langu.
  ENDMETHOD.


METHOD get_prctr_desc.
    SELECT SINGLE ktext INTO ev_ltext
      FROM cepct
     WHERE spras = sy-langu
       AND prctr = iv_prctr
       AND datbi >= sy-datum.
  ENDMETHOD.


METHOD get_ranl_from_docno.
*
*    SELECT SINGLE ranl INTO ev_ranl
*      FROM ztrt_vdarl_01
*     WHERE ztrbilln = iv_docno.
  ENDMETHOD.


METHOD get_rstgr_desc.
    DATA lv_text20 TYPE char20.
    SELECT SINGLE txt20 INTO lv_text20
      FROM t053s
     WHERE spras = sy-langu
       AND bukrs = iv_bukrs
       AND rstgr = iv_rstgr.

    ev_txt20 = lv_text20.
  ENDMETHOD.


METHOD get_tvkbz_desc.

    SELECT SINGLE bezei
      FROM tvkbt
      INTO ev_bezei
      WHERE vkbur = iv_vkbur
        AND spras = 1.

  ENDMETHOD.


METHOD get_vkorg_desc.

    SELECT SINGLE vtext
      FROM tvkot
      INTO ev_vtext
      WHERE vkorg = iv_vkorg
        AND spras = 1.

  ENDMETHOD.


METHOD get_vtweg_desc.

    SELECT SINGLE vtext
      FROM tvtwt
      INTO ev_vtext
      WHERE vtweg = iv_vtweg
        AND spras = 1.

  ENDMETHOD.


METHOD get_waers_desc.

    SELECT SINGLE ktext FROM tcurt INTO ev_ktext WHERE waers = iv_waers AND spras = sy-langu.

  ENDMETHOD.


METHOD get_werks_desc.

    SELECT SINGLE name1 FROM t001w INTO ev_werks_t WHERE werks = iv_werks.

  ENDMETHOD.


METHOD get_yhzh_desc.
    SELECT SINGLE banks bankl yhzh text1 INTO ( ev_banks,ev_bankl,ev_yhzh, ev_text1 )
      FROM ztrt0013
     WHERE bukrs = iv_bukrs
       AND hbkid = iv_hbkid
       AND hktid = iv_hktid.

    CHECK sy-subrc = 0.

    get_bankl_desc(
      EXPORTING
        iv_banks =  ev_banks   " 银行国家代码
        iv_bankl =  ev_bankl   " 银行代码
      RECEIVING
        ev_banka =  ev_banka   " 银行名称
    ).

  ENDMETHOD.


METHOD get_zdjzt_sk_desc.

    zcl_tr_getdesc=>get_domain_dese(
    EXPORTING
      iv_domname =  'ZDM_TR_DJZT_SKD'
      iv_langu   = sy-langu
      iv_value   =  |{ iv_zdjzt }|
    RECEIVING
      ev_ddtext  = ev_zdjzt_t ).


  ENDMETHOD.


METHOD get_zlsch_desc.

    zcl_tr_getdesc=>get_domain_dese(
     EXPORTING
      iv_domname =  'ZDM_SK_METHOD'
      iv_langu   = sy-langu
      iv_value   =  |{ zlsch }|
     RECEIVING
      ev_ddtext  = zlscht ).

  ENDMETHOD.
ENDCLASS.
