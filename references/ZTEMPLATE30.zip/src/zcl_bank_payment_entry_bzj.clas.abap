class ZCL_BANK_PAYMENT_ENTRY_BZJ definition
  public
  inheriting from ZCL_BANK_PAYMENT_ENTRY
  final
  create public .

public section.
protected section.

  methods CHECK_ORDER_STATUS
    redefinition .
  methods LOG_STATUS
    redefinition .
  methods READ_PAYMENTORDER_HEADER
    redefinition .
private section.
ENDCLASS.



CLASS ZCL_BANK_PAYMENT_ENTRY_BZJ IMPLEMENTATION.


METHOD check_order_status.
    IF if_error( ) = yes.
      RETURN.
    ENDIF.

    SELECT SINGLE * INTO @DATA(ls_order)
           FROM ztrt2101
           WHERE docno = @payment_entry-paymorder.
    IF sy-subrc <> 0.
*  if_error的时候就已经应该退出了
*  不应该再来到这一步
      RETURN.
    ENDIF.

    SELECT COUNT( * ) INTO @DATA(l_count)
           FROM ztrt_pmordstatus
           WHERE config_type = 'P0'
           AND   zzftype = @payment_entry-zzftype
           AND   zzffs = @payment_entry-zzffs
           AND   zbskl = @payment_entry-draft_zbskl
           AND   zappro = @ls_order-zzfstatus.
    IF l_count < 1.
      MESSAGE e270(ztr_bank_application)
              WITH payment_entry-entuuid
                   payment_order-paymorder
                  ls_order-zzfstatus
              INTO dummy_message.
*    start log
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = entry_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = bank_action
                        log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                        log_obj      = entry_uuid
                        bank_ind     = payment_entry-bank_ind
                        paymorder    = payment_order-paymorder ) ).
    ENDIF.
  ENDMETHOD.


method LOG_STATUS.
  SELECT SINGLE entstatus INTO @DATA(l_entry_db_status)
           FROM ztrt_payment
           WHERE entuuid = @entry_uuid.
    SELECT SINGLE ltext INTO @DATA(l_entry_db_status_text)
           FROM ztrt_entstatust
           WHERE entstatus = @l_entry_db_status
           and   spras = @sy-langu.
    SELECT SINGLE zzfstatus INTO @DATA(l_paymorder_status)
            FROM ztrt2101
            WHERE docno = @payment_entry-paymorder.
    SELECT SINGLE zapprod INTO @DATA(l_paymorder_status_text)
           FROM ztrt9036
           WHERE doctype = 'P002'
           AND   zappro = @l_paymorder_status.
    SELECT SINGLE ordstatus INTO @DATA(l_linkage_status)
           FROM ztrt_paymlink
           WHERE paymorder = @payment_entry-paymorder
           and   draft_zxh = @payment_entry-draft_zxh.
    SELECT SINGLE zapprod INTO @DATA(l_linkage_status_text)
           FROM ztrt9036
           WHERE doctype = 'P002'
           AND   zappro = @l_linkage_status.
    CONCATENATE '当前状态:支付条目-'
                l_entry_db_status
                '('
                l_entry_db_status_text
                '),'
                '支付单-'
                l_paymorder_status
                '('
                l_paymorder_status_text
                '),'
                '状态连接-'
                l_linkage_status
                '('
                l_linkage_status_text
                ').'
                INTO dummy_message.
    CONDENSE dummy_message NO-GAPS.

*    start log
    MESSAGE i995(ztr_bank_application)
            WITH dummy_message
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = entry_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = bank_action
                      bank_ind     = payment_entry-bank_ind
                      log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                      log_obj      = entry_uuid
                      paymorder    = payment_order-paymorder ) ).
*    end log
  endmethod.


METHOD read_paymentorder_header.
    SELECT SINGLE docno
                  bukrs
                  butxt
                  zzfstatus
                  zzfwaers
                  zzfwrbtr
                  zzftype
                  zzffs
                  del_flg
                  remark
            INTO CORRESPONDING FIELDS OF ex_s_s2001
            FROM ztrt2101
            WHERE docno = payment_order-paymorder.
    IF sy-subrc <> 0.
      ex_not_exited = yes.
      ex_s_s2001-docno = payment_order-paymorder.

      MESSAGE e118(ztr_bank_application)
              WITH entry_uuid
                   payment_order-paymorder
*                   '30'
              INTO dummy_message.
*    start log
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = entry_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = bank_action
                        log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                        log_obj      = entry_uuid
                        bank_ind     = payment_entry-bank_ind
                        paymorder    = payment_order-paymorder ) ).
      RETURN.
*    end log
    ELSE.

      ex_not_exited = no.

      ex_s_s2001-zsbukrs = ex_s_s2001-bukrs."保证金都是在同一个公司内转账
      ex_s_s2001-zzftype = 'P004'. "保证金支付单的类型统一为P004

      IF ex_s_s2001-del_flg = yes.
        MESSAGE e266(ztr_bank_application)
                WITH entry_uuid
                     payment_order-paymorder
                INTO dummy_message.
        zcl_bank_logger_protocal=>add_log(
                 VALUE #( uuid         = entry_uuid
                          msgid        = sy-msgid
                          msgno        = sy-msgno
                          msgty        = sy-msgty
                          msgv1        = sy-msgv1
                          msgv2        = sy-msgv2
                          msgv3        = sy-msgv3
                          msgv4        = sy-msgv4
                          message      = dummy_message
                          bank_action  = bank_action
                          log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                          log_obj      = entry_uuid
                          bank_ind     = payment_entry-bank_ind
                          paymorder    = payment_order-paymorder ) ).
      ENDIF.
    ENDIF.
  ENDMETHOD.
ENDCLASS.
