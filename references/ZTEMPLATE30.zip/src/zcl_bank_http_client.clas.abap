class ZCL_BANK_HTTP_CLIENT definition
  public
  create public .

public section.

  interfaces ZIF_BANK_HTTP_CLIENT .

  aliases CLOSE
    for ZIF_BANK_HTTP_CLIENT~CLOSE .
  aliases GET_DESTINATION
    for ZIF_BANK_HTTP_CLIENT~GET_DESTINATION .
  aliases GET_RESPONSE_CDATA
    for ZIF_BANK_HTTP_CLIENT~GET_RESPONSE_CDATA .
  aliases GET_RESPONSE_DATA
    for ZIF_BANK_HTTP_CLIENT~GET_RESPONSE_DATA .
  aliases INIT_FOR_POSTING
    for ZIF_BANK_HTTP_CLIENT~INIT_FOR_POSTING .
  aliases RECEIVE
    for ZIF_BANK_HTTP_CLIENT~RECEIVE .
  aliases SEND
    for ZIF_BANK_HTTP_CLIENT~SEND .
  aliases SET_REQUEST_CDATA
    for ZIF_BANK_HTTP_CLIENT~SET_REQUEST_CDATA .
  aliases SET_REQUEST_DATA
    for ZIF_BANK_HTTP_CLIENT~SET_REQUEST_DATA .
  aliases SET_RESPONSE_CDATA
    for ZIF_BANK_HTTP_CLIENT~SET_RESPONSE_CDATA .
  aliases SET_RESPONSE_DATA
    for ZIF_BANK_HTTP_CLIENT~SET_RESPONSE_DATA .

  methods CONSTRUCTOR
    importing
      !IM_BANK_INDICATOR type ZTR_BANK_INDICATOR
      !IM_DESTINATION type ZTR_RFCDEST
      !IM_CREATE_BY_URL type FLAG optional
      !IM_URL type STRING optional
    exceptions
      ARGUMENT_NOT_FOUND
      DESTINATION_NOT_FOUND
      DESTINATION_NO_AUTHORITY
      PLUGIN_NOT_ACTIVE
      INTERNAL_ERROR
      UNKNOW_ERROR .
protected section.

  data BANK_INDICATOR type ZTR_BANK_INDICATOR .
  data DESTINATION type ZTR_RFCDEST .
  data CLIENT type ref to IF_HTTP_CLIENT .
  data HTTP_RFC_CONFIG type ZTRT_HTTPRFCDEST .

  methods ADJUST_RESPONSE
    importing
      !IM_ACTION type ZTR_APP_ACTION_FOR_BANK
      !IM_STEP type ZTR_APP_ACTION_STEP .
private section.

  methods BEFORE_SEND .
  methods SET_REQUEST_CONTENT_LENGTH .
  methods SET_REQUEST_CONTENT_TYPE .
  methods READ_RFC_CONFIG .
  methods SET_HTTP_VERSION .
ENDCLASS.



CLASS ZCL_BANK_HTTP_CLIENT IMPLEMENTATION.


  METHOD adjust_response.

    DATA: l_string  TYPE string,
          l_xstring TYPE xstring.
    DATA(lo_adjuster) = zcl_bank_file_adjuster=>get_response_adjuster( bank_indicator ).
    IF lo_adjuster IS NOT BOUND.
      RETURN.
    ENDIF.


    lo_adjuster->adjust(
             EXPORTING
               im_action = im_action
               im_step = im_step
               im_original_cdata = client->response->get_cdata( )
               im_original_xdata = client->response->get_data( vscan_scan_always = 'A' )
             IMPORTING
*               ex_t_return = DATA(lt_returns)
               ex_cdata = l_string
               ex_xdata = l_xstring ) .

*这个地方必须要让adjuster的开发员知道client response对调整后数据的处理
    IF l_xstring IS NOT INITIAL.
      client->response->set_data( l_xstring ).
    ELSE.
      IF l_string IS NOT INITIAL.
        client->response->set_cdata( l_string ).
      ENDIF.
    ENDIF.

  ENDMETHOD.


  METHOD before_send.
    set_request_content_length( ).
    set_request_content_type( ).
  ENDMETHOD.


  METHOD constructor.

    MOVE: im_bank_indicator TO bank_indicator,
          im_destination TO destination.

    IF im_create_by_url = 'X'.
      cl_http_client=>create_by_url(
            EXPORTING
               url                 = im_url
            IMPORTING
               client              = client
            EXCEPTIONS
               argument_not_found  = 1001
               plugin_not_active   = 4001
               internal_error      = 5001
               OTHERS              = 6001 ).
    ELSE.
      cl_http_client=>create_by_destination(
        EXPORTING
          destination              = destination
        IMPORTING
          client                   = client
        EXCEPTIONS
          argument_not_found       = 1001
          destination_not_found    = 2001
          destination_no_authority = 3001
          plugin_not_active        = 4001
          internal_error           = 5001
          OTHERS                   = 6001 ).
    ENDIF.
    CASE sy-subrc.
      WHEN 0.
        read_rfc_config( ).
      WHEN 1001.
##NO_TEXT
        MESSAGE e048(ztr_bank_application)
                   WITH bank_indicator
                        destination
                        'argument_not_found'
                   RAISING argument_not_found.

      WHEN 2001.
##NO_TEXT
        MESSAGE e048(ztr_bank_application)
                   WITH bank_indicator
                        destination
                        'destination_not_found'
                   RAISING destination_not_found.
      WHEN 3001.
##NO_TEXT
        MESSAGE e048(ztr_bank_application)
                   WITH bank_indicator
                        destination
                        'destination_no_authority'
                   RAISING destination_no_authority.
      WHEN 4001.
##NO_TEXT
        MESSAGE e048(ztr_bank_application)
                   WITH bank_indicator
                        destination
                        'plugin_not_active'
                   RAISING plugin_not_active.
      WHEN 5001.
##NO_TEXT
        MESSAGE e048(ztr_bank_application)
                   WITH bank_indicator
                        destination
                        'internal_error'
                   RAISING internal_error.
      WHEN 6001.
##NO_TEXT
        MESSAGE e048(ztr_bank_application)
                   WITH bank_indicator
                        destination
                        'unknow_error'
                   RAISING unknow_error.
    ENDCASE.
  ENDMETHOD.


  METHOD read_rfc_config.
    SELECT SINGLE * INTO http_rfc_config
           FROM ztrt_httprfcdest
           WHERE destination = destination.
  ENDMETHOD.


  METHOD set_http_version.
    DATA: l_version TYPE rfcdisplay-rfctype.

    CALL FUNCTION 'RFC_READ_HTTP_DESTINATION'
      EXPORTING
        destination             = destination
        authority_check         = space
      IMPORTING
        http_version            = l_version
      EXCEPTIONS
        authority_not_available = 1
        destination_not_exist   = 2
        information_failure     = 3
        internal_failure        = 4
        no_http_destination     = 5
        OTHERS                  = 6.
    IF sy-subrc <> 0.
      RETURN.
    ENDIF.

    IF l_version = '1'.
      CALL METHOD client->request->set_header_field
        EXPORTING
          name  = '~server_protocol'
          value = 'HTTP/1.1'.
    ELSE.
      CALL METHOD client->request->set_header_field
        EXPORTING
          name  = '~server_protocol'
          value = 'HTTP/1.0'.
    ENDIF.
  ENDMETHOD.


  METHOD set_request_content_length.

    IF http_rfc_config-content_len = ''.
      RETURN.
    ENDIF.

##NO_TEXT
    client->request->set_header_field(
             name = 'Content-Length'
             value = CONV #( xstrlen( client->request->get_data( ) ) ) ).
  ENDMETHOD.


  METHOD set_request_content_type.
    IF http_rfc_config-content_type IS INITIAL.
      RETURN.
    ENDIF.

##NO_TEXT
    client->request->set_header_field(
               name = 'Content-Type'
               value = CONV #( http_rfc_config-content_type ) ).

  ENDMETHOD.


  method ZIF_BANK_HTTP_CLIENT~CLOSE.
    IF client IS BOUND.
      client->close( ).
    ENDIF.
  endmethod.


  method ZIF_BANK_HTTP_CLIENT~GET_DESTINATION.
    re_name = DESTINATION.
  endmethod.


  method ZIF_BANK_HTTP_CLIENT~GET_RESPONSE_CDATA.
    re_xml_string = client->response->get_cdata( ).
  endmethod.


  method ZIF_BANK_HTTP_CLIENT~GET_RESPONSE_DATA.
    re_xml_xstring = client->response->get_data( ).
  endmethod.


  METHOD zif_bank_http_client~init_for_posting.
    DATA: l_dummy_xml_xstring TYPE xstring.
    client->request->set_method( if_http_request=>co_request_method_post ). "设置POST
    client->request->set_data( l_dummy_xml_xstring ). "清空数据
    client->refresh_response( ).
    set_http_version( ).
  ENDMETHOD.


  METHOD zif_bank_http_client~receive.
    DATA: l_exception_message TYPE string,
          l_exception         TYPE string,
          l_action_text       TYPE ztr_app_action_for_bank_ltext.

    SELECT SINGLE ltext INTO l_action_text
           FROM ztrt_actiont
           WHERE bank_action = im_action
           AND   spras = sy-langu.
    DO 5 TIMES.
      client->receive(
        EXCEPTIONS
          http_communication_failure = 1
          http_invalid_state         = 2
          http_processing_failed     = 3
          OTHERS                     = 4 ).
      IF sy-subrc = 0.
        EXIT.
      ENDIF.
      WAIT UP TO 1 SECONDS.
    ENDDO.
    CASE sy-subrc.
      WHEN 0.

        adjust_response( im_action = im_action
                         im_step = im_step ).

      WHEN 1.
        l_exception_message = TEXT-002.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH bank_indicator.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH destination.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH im_action.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH l_action_text.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH im_step.
        l_exception = 'http_communication_failure'.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH l_exception.
        DATA(lenth) = strlen( l_exception_message ) - 50.
        IF lenth > 0.
          l_exception = l_exception_message+50(lenth).
        ELSE.
          CLEAR l_exception.
        ENDIF.
        MESSAGE e994(ztr_bank_application)
               WITH l_exception_message l_exception
               RAISING http_communication_failure.

      WHEN 2.
        l_exception_message = TEXT-002.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH bank_indicator.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH destination.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH im_action.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH l_action_text.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH im_step.
        l_exception = 'http_invalid_state'.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH l_exception.
        lenth  = strlen( l_exception_message ) - 50.
        IF lenth > 0.
          l_exception = l_exception_message+50(lenth).
        ELSE.
          CLEAR l_exception.
        ENDIF.
        MESSAGE e994(ztr_bank_application)
               WITH l_exception_message l_exception
               RAISING http_invalid_state.

      WHEN 3.
        l_exception_message = TEXT-002.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH bank_indicator.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH destination.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH im_action.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH l_action_text.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH im_step.
        l_exception = 'http_processing_failed'.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH l_exception.
        lenth  = strlen( l_exception_message ) - 50.
        IF lenth > 0.
          l_exception = l_exception_message+50(lenth).
        ELSE.
          CLEAR l_exception.
        ENDIF.
        MESSAGE e994(ztr_bank_application)
               WITH l_exception_message l_exception
               RAISING http_processing_failed.

      WHEN 4.
        l_exception_message = TEXT-002.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH bank_indicator.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH destination.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH im_action.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH l_action_text.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH im_step.
        l_exception = 'unknow_error'.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH l_exception.
        lenth  = strlen( l_exception_message ) - 50.
        IF lenth > 0.
          l_exception = l_exception_message+50(lenth).
        ELSE.
          CLEAR l_exception.
        ENDIF.
        MESSAGE e994(ztr_bank_application)
               WITH l_exception_message l_exception
               RAISING unknow_error.

    ENDCASE.
  ENDMETHOD.


  METHOD zif_bank_http_client~send.

    DATA: l_exception_message TYPE string,
          l_exception         TYPE string,
          l_action_text       TYPE ztr_app_action_for_bank_ltext.

    SELECT SINGLE ltext INTO l_action_text
           FROM ztrt_actiont
           WHERE bank_action = im_action
           AND   spras = sy-langu.
    before_send( ).

    client->send(
                  EXPORTING
                    timeout                    = if_http_client=>co_timeout_default
                  EXCEPTIONS
                    http_communication_failure = 1
                    http_invalid_state         = 2
                    http_processing_failed     = 3
                    http_invalid_timeout       = 4
                    OTHERS                     = 5 ).
    CASE sy-subrc.
      WHEN 0.
        RETURN.
      WHEN 1.
        l_exception_message = TEXT-001.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH bank_indicator.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH destination.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH im_action.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH l_action_text.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH im_step.
        l_exception = 'http_communication_failure'.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH l_exception.
        DATA(lenth)  = strlen( l_exception_message ) - 50.
        IF lenth > 0.
          l_exception = l_exception_message+50(lenth).
        ELSE.
          CLEAR l_exception.
        ENDIF.
        MESSAGE e994(ztr_bank_application)
               WITH l_exception_message l_exception
               RAISING http_communication_failure.

      WHEN 2.
        l_exception_message = TEXT-001.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH bank_indicator.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH destination.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH im_action.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH l_action_text.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH im_step.
        l_exception = 'http_invalid_state'.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH l_exception.
        lenth  = strlen( l_exception_message ) - 50.
        IF lenth > 0.
          l_exception = l_exception_message+50(lenth).
        ELSE.
          CLEAR l_exception.
        ENDIF.
        MESSAGE e994(ztr_bank_application)
               WITH l_exception_message l_exception
               RAISING http_invalid_state.

      WHEN 3.
        l_exception_message = TEXT-001.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH bank_indicator.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH destination.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH im_action.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH l_action_text.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH im_step.
        l_exception = 'http_processing_failed'.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH l_exception.
        lenth  = strlen( l_exception_message ) - 50.
        IF lenth > 0.
          l_exception = l_exception_message+50(lenth).
        ELSE.
          CLEAR l_exception.
        ENDIF.
        MESSAGE e994(ztr_bank_application)
               WITH l_exception_message l_exception
               RAISING http_processing_failed.

      WHEN 4.
        l_exception_message = TEXT-001.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH bank_indicator.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH destination.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH im_action.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH l_action_text.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH im_step.
        l_exception = 'http_invalid_timeout'.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH l_exception.
        lenth  = strlen( l_exception_message ) - 50.
        IF lenth > 0.
          l_exception = l_exception_message+50(lenth).
        ELSE.
          CLEAR l_exception.
        ENDIF.
        MESSAGE e994(ztr_bank_application)
               WITH l_exception_message l_exception
               RAISING http_invalid_timeout.

      WHEN 5.
        l_exception_message = TEXT-001.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH bank_indicator.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH destination.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH im_action.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH l_action_text.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH im_step.
        l_exception = 'unknow_error'.
        REPLACE FIRST OCCURRENCE OF '&' IN l_exception_message WITH l_exception.
        lenth  = strlen( l_exception_message ) - 50.
        IF lenth > 0.
          l_exception = l_exception_message+50(lenth).
        ELSE.
          CLEAR l_exception.
        ENDIF.
        MESSAGE e994(ztr_bank_application)
               WITH l_exception_message l_exception
               RAISING unknow_error.

    ENDCASE.
  ENDMETHOD.


  METHOD zif_bank_http_client~set_request_cdata.
    client->request->set_cdata( im_data ).
  ENDMETHOD.


  METHOD zif_bank_http_client~set_request_data.
    client->request->set_data( im_data ).
  ENDMETHOD.


  method ZIF_BANK_HTTP_CLIENT~SET_RESPONSE_CDATA.
    client->response->set_cdata( im_data ).
  endmethod.


  method ZIF_BANK_HTTP_CLIENT~SET_RESPONSE_DATA.
    client->response->set_data( im_data ).
  endmethod.
ENDCLASS.
