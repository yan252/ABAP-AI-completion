class ZCL_BANK_FUNCTION_PAYMENT definition
  public
  inheriting from ZCL_ABSTRACT_BANK_FUNCTION
  create public .

public section.

  interfaces ZIF_BANK_FUNCTION_PAYM_RELATE .

  methods ZIF_BANK_FUNCTION~SET_SENDING_DATA_REFERENCE
    redefinition .
protected section.

  aliases UPDATE_PAYMENT_ENTRY
    for ZIF_BANK_FUNCTION_PAYM_RELATE~UPDATE_PAYMENT_ENTRY .

  methods LOG_RESPONSE_FOR_PAYMENT .
  methods UPDATE_STATUS_IN_INSTANCE
    importing
      !IM_S_STANDARD_RESPONSE type ZTRS_PAYMENT_BANK_RETURN .

  methods CONVERT_DATA_TO_DMEE_TYPE
    redefinition .
  methods END_PROCESSING_RESPONSE_INTL
    redefinition .
  methods LOG_FILE
    redefinition .
private section.
ENDCLASS.



CLASS ZCL_BANK_FUNCTION_PAYMENT IMPLEMENTATION.


  METHOD convert_data_to_dmee_type.
    DATA: BEGIN OF ls_entry,
            entuuid   TYPE ztr_payment_entry_uuid,
            paymorder TYPE ztr_zfdocno,
            log_obj   TYPE ztr_bank_log_obj,
          END OF ls_entry.

*    FIELD-SYMBOLS <ft_entries> TYPE STANDARD TABLE .
    FIELD-SYMBOLS: <ft_dmee_table> TYPE ztr_dmee_paym_if_type_tab.
    DATA: ls_dmee_type TYPE dmee_paym_if_type.

    CREATE DATA re_dmee_table_ref TYPE ztr_dmee_paym_if_type_tab.
    ASSIGN re_dmee_table_ref->* TO <ft_dmee_table>.

    LOOP AT im_t_raw_data ASSIGNING FIELD-SYMBOL(<fs_entry>).
      MOVE-CORRESPONDING <fs_entry> TO ls_dmee_type-fpayh.

*      支付账户
      ASSIGN COMPONENT 'BNKN1' OF STRUCTURE <fs_entry> TO FIELD-SYMBOL(<f_field>).
      IF sy-subrc = 0.
        ls_dmee_type-fpayhx-ref02 = <f_field>.
      ENDIF.
      UNASSIGN <f_field>.

      ASSIGN COMPONENT 'ZSJZFRQ' OF STRUCTURE <fs_entry> TO <f_field>.
      IF sy-subrc = 0.
        ls_dmee_type-fpayh-zaldt = <f_field>.
      ENDIF.
      IF ls_dmee_type-fpayh-zaldt IS INITIAL.
        ls_dmee_type-fpayh-zaldt = sy-datum.
      ENDIF.
      UNASSIGN <f_field>.

      ASSIGN COMPONENT 'ZSZHMC' OF STRUCTURE <fs_entry> TO <f_field>.
      IF sy-subrc = 0.
        IF <f_field> IS NOT INITIAL.
          ls_dmee_type-fpayh-koinh = <f_field>.
        ENDIF.
      ENDIF.
      ls_dmee_type-fpayh-laufi = bank_indicator.
      APPEND ls_dmee_type TO <ft_dmee_table>.
    ENDLOOP.

*start log
    LOOP AT im_t_raw_data ASSIGNING FIELD-SYMBOL(<fs_raw_data>).
      MOVE-CORRESPONDING <fs_raw_data> TO ls_entry.
      ls_entry-log_obj = ls_entry-entuuid.
      MESSAGE i166(ztr_bank_application)
              WITH ls_entry-paymorder
                   ls_entry-log_obj
                   function_config-bank_func
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = instance_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator
                        bank_func    = function_config-bank_func
                        step         = step
                        log_obj      = ls_entry-log_obj
                        log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                        paymorder    = ls_entry-paymorder ) ).
    ENDLOOP.
*end log
  ENDMETHOD.


  METHOD end_processing_response_intl.
    log_response_for_payment( ).
    super->end_processing_response_intl( ).
  ENDMETHOD.


  METHOD log_file.
    DATA: BEGIN OF ls_entry,
            entuuid   TYPE ztr_payment_entry_uuid,
            paymorder TYPE ztr_zfdocno,
            log_obj   TYPE ztr_bank_log_obj,
          END OF ls_entry.
    DATA: l_file_existed TYPE flag.

    super->log_file( im_uuid           = im_uuid
                     im_cref           = im_cref
                     im_xref           = im_xref
                     im_file_direction = im_file_direction ).

    ASSIGN im_xref->* TO FIELD-SYMBOL(<f_xfile>).
    ASSIGN im_cref->* TO FIELD-SYMBOL(<f_cfile>).
    IF ( <f_xfile> IS ASSIGNED AND
         <f_xfile> IS NOT INITIAL  ) OR
      ( <f_cfile> IS ASSIGNED AND
        <f_cfile> IS NOT INITIAL ).
      l_file_existed = yes.
    ENDIF.

    LOOP AT im_t_raw_data ASSIGNING FIELD-SYMBOL(<fs_raw_data>).
      MOVE-CORRESPONDING <fs_raw_data> TO ls_entry.
      ls_entry-log_obj = ls_entry-entuuid.
      CASE im_file_direction.
        WHEN 'C'.
          IF l_file_existed = no.
            MESSAGE e164(ztr_bank_application)
                    WITH ls_entry-paymorder
                         ls_entry-entuuid
                         bank_indicator
                         function_config-bank_func
                     INTO dummy_message.
          ELSE.
            MESSAGE i165(ztr_bank_application)
                    WITH ls_entry-paymorder
                         ls_entry-entuuid
                         bank_indicator
                         function_config-bank_func
                     INTO dummy_message.
          ENDIF.
        WHEN 'R'.

          IF l_file_existed = no.
            MESSAGE e182(ztr_bank_application)
                    WITH ls_entry-paymorder
                         ls_entry-entuuid
                         bank_indicator
                         function_config-bank_func
                     INTO dummy_message.
          ELSE.
            MESSAGE i183(ztr_bank_application)
                    WITH ls_entry-paymorder
                         ls_entry-entuuid
                         bank_indicator
                         function_config-bank_func
                     INTO dummy_message.
          ENDIF.

      ENDCASE.

      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = instance_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator
                        bank_func    = function_config-bank_func
                        step         = step
                        log_obj      = ls_entry-log_obj
                        log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                        paymorder    = ls_entry-paymorder
                        file_uuid    = im_uuid
                        file_direction = im_file_direction ) ).

      LOOP AT im_t_messages INTO DATA(ls_message).
        zcl_bank_logger_protocal=>add_log(
                 VALUE #( uuid         = instance_uuid
                          msgid        = ls_message-id
                          msgno        = ls_message-number
                          msgty        = ls_message-type
                          msgv1        = ls_message-message_v1
                          msgv2        = ls_message-message_v2
                          msgv3        = ls_message-message_v3
                          msgv4        = ls_message-message_v4
                          message      = ls_message-message
                          bank_action  = action
                          bank_ind     = bank_indicator
                          bank_func    = function_config-bank_func
                          step         = step
                          log_obj      = ls_entry-log_obj
                          log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                          paymorder    = ls_entry-paymorder
                          file_uuid    = im_uuid
                          file_direction = im_file_direction ) ).
      ENDLOOP.
    ENDLOOP.
  ENDMETHOD.


  METHOD log_response_for_payment.
    FIELD-SYMBOLS: <ft_formatted_data> TYPE ztrt_payment_entry_from_bank.
    FIELD-SYMBOLS: <ft_related_entries> TYPE STANDARD TABLE.
    DATA: BEGIN OF ls_entry,
            entuuid      TYPE ztr_payment_entry_uuid,
            paymorder    TYPE ztr_zfdocno,
            log_obj      TYPE ztr_bank_log_obj,
            log_obj_type TYPE ztr_bank_log_obj_type VALUE '1',
          END OF ls_entry.

    ASSIGN action_formatted_response_data->* TO <ft_formatted_data>.
    IF <ft_formatted_data> IS NOT ASSIGNED.
      RETURN.
    ENDIF.

    DATA(l_original_temp_ref) = get_original_entries( current_sending_sequence ).
    ASSIGN l_original_temp_ref->* TO <ft_related_entries>.
    IF <ft_related_entries> IS NOT ASSIGNED.
      RETURN.
    ENDIF.

    DATA(ls_sending_file) = get_current_sending_file( ).
    DATA(ls_response_file) = get_current_response_file( ).

    LOOP AT <ft_related_entries> ASSIGNING FIELD-SYMBOL(<fs_related_entry>).
      MOVE-CORRESPONDING <fs_related_entry> TO ls_entry.
      ls_entry-log_obj = ls_entry-entuuid.
      READ TABLE <ft_formatted_data> INTO DATA(ls_formatted_data)
           WITH KEY bank_ind = bank_indicator
                    entuuid = ls_entry-entuuid
                    paymorder = ls_entry-paymorder.
      CHECK sy-subrc = 0.
      CONCATENATE 'BANK_RTNCODE='
                  ls_formatted_data-bank_rtncode
                  '/BANK_REQSTS='
                  ls_formatted_data-bank_reqsts
                  '/BANK_RTNFLG='
                  ls_formatted_data-bank_rtnflg
                  INTO dummy_message.
      MESSAGE i192(ztr_bank_application)
              WITH ls_entry-paymorder
                   ls_entry-log_obj
                   function_config-bank_func
                   dummy_message
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = instance_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator
                        bank_func    = function_config-bank_func
                        step         = step
                        log_obj      = ls_entry-log_obj
                        log_obj_type = ls_entry-log_obj_type
                        paymorder    = ls_entry-paymorder
                        file_uuid = ls_response_file-file_uuid
                        counter_file_uuid = ls_sending_file-file_uuid
                        file_direction = 'R' ) ).
    ENDLOOP.
  ENDMETHOD.


  METHOD update_status_in_instance.
*    paym_update_in_instance ztrs_payment_entry_tab.

    FIELD-SYMBOLS: <ft_related_entries> TYPE ztrs_payment_entry_tab.
    INCLUDE ztri_payment_entry_from_bank.
  ENDMETHOD.


  METHOD zif_bank_function_paym_relate~update_payment_entry.
    DATA:lo_action_interface TYPE REF TO zif_bank_action_payment_relate.
    DATA(lo_action) = zcl_bank_abstract_action=>get_action( ).
    lo_action_interface ?= lo_action.

    IF lo_action_interface IS NOT BOUND.
      RETURN.
    ENDIF.

    lo_action_interface->update_entry_from_external(
                          EXPORTING
                            im_bank_indicator = bank_indicator
                            im_feedback_from_bank = im_feedback_from_bank
                            im_delete_entry_instance = yes ).
  ENDMETHOD.


  METHOD zif_bank_function~set_sending_data_reference.
*    FIELD-SYMBOLS: <ft_data> TYPE STANDARD TABLE.
    DATA: BEGIN OF ls_entry,
            entuuid   TYPE ztr_payment_entry_uuid,
            paymorder TYPE ztr_zfdocno,
            log_obj   TYPE ztr_bank_log_obj,
          END OF ls_entry.

    super->set_sending_data_reference( im_data_reference ).

*    start log
    IF sending_data_reference IS NOT BOUND.
      RETURN.
    ENDIF.
    DATA(ls_business_data) = VALUE ztrs_bank_log_businessdata(
                                          bank_ind = bank_indicator
                                          bank_action = action
                                          bank_func = function_config-bank_func
                                          step = step
                                          log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry ).
    LOOP AT im_data_reference INTO DATA(ls_data_reference)
      WHERE data IS BOUND.
      ASSIGN ls_data_reference-data->* TO FIELD-SYMBOL(<fs_source>).
      MOVE-CORRESPONDING <fs_source> TO ls_entry.
      ls_entry-log_obj   = ls_entry-entuuid.
      MOVE-CORRESPONDING ls_entry TO ls_business_data.
      MESSAGE i161(ztr_bank_application)
              WITH ls_business_data-paymorder
                   ls_business_data-log_obj
                   bank_indicator
                   function_config-bank_func
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = instance_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator
                        bank_func    = function_config-bank_func
                        step         = step
                        LOG_OBJ      = ls_business_data-log_obj
                        LOG_OBJ_TYPE = ls_business_data-log_obj_type
                        paymorder    = ls_business_data-paymorder ) ).
    ENDLOOP.
*end log
  ENDMETHOD.
ENDCLASS.
