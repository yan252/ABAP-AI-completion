FUNCTION ZFM_TR_CHECK_BZJTZ.
**"--------------------------------------------------------------------
**"*"局部接口：
**"  IMPORTING
**"     REFERENCE(DOCNO) TYPE  ZTR_ZFDOCNO OPTIONAL
**"     REFERENCE(IV_DOCNO_TZ) TYPE  ZTR_BZJ_TZ OPTIONAL
**"  EXPORTING
**"     REFERENCE(BZJ_TZ) TYPE  ZTR_BZJ_TZ
**"     REFERENCE(MSG) TYPE  STRING
**"--------------------------------------------------------------------
**----保证金台帐
*  SELECT SINGLE bzj_tz,tztype INTO @DATA(ls_tz)
*      FROM ztrt2199
*      WHERE ( docno = @docno OR bzj_tz = @iv_docno_tz )  AND
*       tztype IN ( 'B','P' )
*       AND fitype = '1'
*       AND bzj_tz NE ''.
*  IF sy-subrc <> 0.
*    MESSAGE s154(ztr05) INTO msg.
*    RETURN.
*  ENDIF.
*
**校验是否有进行中的退款单(过账，删除的除外)
*  SELECT SINGLE docno,zrfha,zzdocno INTO @DATA(ls_tk)
*    FROM ztrt2301
*    WHERE ztkstatus <> '30'
*     AND delflag = @abap_false AND zrfha = @ls_tz-bzj_tz.
*  IF sy-subrc = 0.
**    外汇保证金储蓄账户锁定时可以继续操作保证金台账20201015
*    SELECT SINGLE cclock INTO @DATA(lv_lock) FROM ztrt2101
*      WHERE docno = @ls_tk-zzdocno  .
*    IF sy-subrc = 0 AND lv_lock = 'X'.
*    ELSE.
*      MESSAGE s155(ztr05) WITH ls_tk-docno INTO msg.
*      RETURN.
*    ENDIF.
*  ENDIF.
*
**汇票兑付单检查
*  SELECT SINGLE i~docno INTO @DATA(lv_df_docno)
*    FROM ztrt0061_item AS i
*    INNER JOIN ztrt0061_head AS h
*    ON i~docno = h~docno
*    WHERE i~bzj_tzdh = @iv_docno_tz
*    AND i~itmst NE '10'
*    AND h~zstatus NE '30' AND h~zstatus NE '35'.
*
*  IF sy-subrc = 0.
*    MESSAGE s156(ztr05) WITH lv_df_docno INTO msg.
*    RETURN.
*  ENDIF.
*
*
*  "信用证兑付单
**{
*  SELECT SINGLE a~docno INTO @DATA(lv_docno)
*    FROM ztrt0082 AS a INNER JOIN ztrt0083 AS b
*                               ON a~docno = b~docno
*   WHERE zbzj_no = @ls_tz-bzj_tz
*     AND zdjzt <> '35'
*     AND zdjzt <> '25'
*     AND zdjzt <> '45'
*     AND zdjzt <> '55'
*     AND b~del_sign <> 'X'
*     AND b~zje_bzjdf <> ''
*     AND b~zje_bzjdf <> 0 . "当“保证金兑付金额”为空或“保证金兑付金额”有值但83表行项目有删除标识时，不校验被占用  Yang Xiaoyan  20200713
*
*  IF sy-subrc = 0.
*    MESSAGE s171(ztr05) WITH lv_docno INTO msg.
*    RETURN.
*  ENDIF.
**}
*
*  bzj_tz = ls_tk-docno.





ENDFUNCTION.
