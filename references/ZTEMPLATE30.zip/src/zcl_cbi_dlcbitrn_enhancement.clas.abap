class ZCL_CBI_DLCBITRN_ENHANCEMENT definition
  public
  final
  create public .

public section.

  methods CONSTRUCTOR
    importing
      !IV_DOCNO type ZTRT2010-DOCNO optional .
  methods SET_PREFLG
    returning
      value(EV_PREFLG) type ZTRT2010-YYZFBZ .
  methods SET_YQZFRQ
    returning
      value(EV_YQZFRQ) type ZTRT2010-YQZYRQ .
  methods SET_JYFS
    returning
      value(EV_JYFS) type ZTRT2010-JYFS .
  methods SET_FK_WAERS
    returning
      value(EV_WAERS_CITIC) type ZTRT9501-WAERS_CITIC .
  methods SET_SK_WAERS
    returning
      value(EV_WAERS_CITIC) type ZTRT9501-WAERS_CITIC .
  class-methods CONVERT_WAERS
    importing
      !IV_WAERS type ZTRT9501-WAERS
    returning
      value(EV_WAERS_CITIC) type ZTRT9501-WAERS_CITIC .
  methods SET_FYKCFS
    returning
      value(EV_FYKCFS) type ZTRT2010-FYKCFS .
  methods SET_ZJYHDH
    returning
      value(EV_ZJYHDH) type ZTRT2010-ZJYHDH .
  methods SET_ZJYHMC
    returning
      value(EV_ZJYHMC) type ZTRT2010-ZJYHMC .
  methods SET_YQZFSJ
    returning
      value(EV_YQZFSJ) type CHAR7 .
  methods SET_SKZHHH
    returning
      value(EV_SKZHHH) type CHAR10 .
  methods SET_JY_WAERS
    returning
      value(EV_WAERS_CITIC) type ZTRT9501-WAERS_CITIC .
  methods SET_FY
    returning
      value(EV_FY) type ZTRT2010-FY .
  methods SET_SK_BANKS
    returning
      value(EV_BANKS) type BNKA-BANKS .
  methods SET_REMARK
    returning
      value(EV_REMARK) type ZTRT2001-REMARK .
  methods SET_SK_BANKL
    returning
      value(EV_BANKL) type ZTRT2002-ZSKBANKL .
  methods SET_SK_BANKA
    importing
      !IV_TYPE type CHAR1
    returning
      value(EV_BANKA) type ZTRT2002-ZSKBANKA .
  methods SET_SKYHDH
    returning
      value(EV_SKYHDH) type ZTRT2010-SKYHDH .
  methods SET_SK_ADDRESS
    returning
      value(EV_ADDRESS) type CHAR70 .
  methods SET_SK_COUNTRY
    returning
      value(EV_COUNTRY) type CHAR35 .
  methods SET_USENO
    returning
      value(EV_USENO) type CHAR2 .
  methods SET_JZFS
    returning
      value(EV_JZFS) type ZTRT2010-JSFS .
  methods SET_BDATE
    returning
      value(EV_BDATE) type D .
  methods SET_EDATE
    returning
      value(EV_EDATE) type D .
  methods SET_RATE
    returning
      value(EV_RATE) type CHAR10 .
  class-methods CONVERT_WAERS_INTERNAL
    importing
      !IV_WAERS_CITIC type ZTRT9501-WAERS_CITIC
    returning
      value(EV_WAERS) type ZTRT9501-WAERS .
  methods SET_RBANKADD
    returning
      value(EV_RBANKADD) type STRING .
  methods SET_DQZH
    returning
      value(RV_DQZH) type ZTRT2010-DQZH .
  methods SET_ZQFS
    returning
      value(RV_ZQFS) type ZTRT2010-ZZQFS .
  methods SET_JQRQ
    returning
      value(RV_JQRQ) type CHAR10 .
protected section.
private section.

  data GS_2010 type ZTRT2010 .
  data GV_DOCNO type ZTRT2001-DOCNO .
  data GS_2001 type ZTRT2001 .
  data GS_2002 type ZTRT2002 .
  data GS_2003 type ZTRT2003 .

  methods GET_ZFD
    importing
      !IV_DOCNO type ZTRT2001-DOCNO .
ENDCLASS.



CLASS ZCL_CBI_DLCBITRN_ENHANCEMENT IMPLEMENTATION.


METHOD CONSTRUCTOR.
    gv_docno = iv_docno.
    me->get_zfd( iv_docno ).
  ENDMETHOD.


METHOD CONVERT_WAERS.
    SELECT SINGLE waers_citic
    INTO ev_waers_citic
    FROM ztrt9501
    WHERE waers = iv_waers.
  ENDMETHOD.


METHOD convert_waers_internal.
    SELECT SINGLE waers
    INTO ev_waers
    FROM ztrt9501
    WHERE waers_citic = iv_waers_citic.
  ENDMETHOD.


METHOD GET_ZFD.
    SELECT SINGLE * INTO CORRESPONDING FIELDS OF gs_2010 FROM ztrt2010
    WHERE docno = iv_docno.

    SELECT SINGLE * INTO CORRESPONDING FIELDS OF gs_2001 FROM ztrt2001 WHERE docno = iv_docno.
    SELECT SINGLE * INTO CORRESPONDING FIELDS OF gs_2002 FROM ztrt2002 WHERE docno = iv_docno.
    SELECT SINGLE * INTO CORRESPONDING FIELDS OF gs_2003 FROM ztrt2003 WHERE docno = iv_docno.
  ENDMETHOD.


METHOD set_bdate.

    ev_bdate = COND #( WHEN gs_2010-sdate >= sy-datum THEN gs_2010-sdate
                       ELSE sy-datum ).
  ENDMETHOD.


METHOD set_dqzh.
    rv_dqzh = gs_2010-dqzh.
  ENDMETHOD.


METHOD set_edate.
    ev_edate = gs_2010-mdate.
  ENDMETHOD.


METHOD SET_FK_WAERS.
    SELECT SINGLE waers
      INTO @DATA(lv_waers)
    FROM ztrt0013 AS y JOIN ztrt2003 AS z
      ON y~hbkid = z~hbkid
     AND y~hktid = z~hktid
    WHERE z~docno = @gv_docno
      AND bukrs = @gs_2001-bukrs.

    ev_waers_citic = me->convert_waers( lv_waers ).
  ENDMETHOD.


METHOD set_fy.
    IF gs_2010-jyfs NE '1'.
      ev_fy = gs_2010-fy && gs_2010-zfytsm.
    ENDIF.
  ENDMETHOD.


METHOD SET_FYKCFS.
    IF gs_2010-jyfs NE '1'.
      ev_fykcfs = gs_2010-fykcfs.
    ENDIF.
  ENDMETHOD.


METHOD set_jqrq.
    IF gs_2010-jqrq IS NOT INITIAL.
      rv_jqrq = gs_2010-jqrq.
    ENDIF.

  ENDMETHOD.


METHOD SET_JYFS.
    ev_jyfs = gs_2010-jyfs.
  ENDMETHOD.


METHOD SET_JY_WAERS.

    ev_waers_citic = me->convert_waers( gs_2001-zzfwaers ).
  ENDMETHOD.


METHOD set_jzfs.
    ev_jzfs = gs_2010-jsfs.
  ENDMETHOD.


METHOD SET_PREFLG.
    ev_preflg = gs_2010-yyzfbz.
  ENDMETHOD.


METHOD set_rate.
    IF gs_2010-ll > 0.
      ev_rate = gs_2010-ll.
    ENDIF.
    CONDENSE ev_rate NO-GAPS .
  ENDMETHOD.


METHOD set_rbankadd.
    SELECT SINGLE stras,
                  ort01
    INTO @DATA(ls_bnka)
    FROM bnka
    WHERE bankl = @gs_2002-zskbankl
      AND banks = @gs_2002-banks.

    ev_rbankadd = ls_bnka-stras && ls_bnka-ort01.
  ENDMETHOD.


METHOD set_remark.
    IF gs_2010-jyfs NE '2' AND gs_2010-jyfs NE '3'.
      ev_remark = gs_2001-remark.
    ENDIF.
  ENDMETHOD.


METHOD SET_SKYHDH.
    IF gs_2010-jyfs NE '1'.
      ev_skyhdh = gs_2010-skyhdh.
    ENDIF.
  ENDMETHOD.


METHOD SET_SKZHHH.
    IF gs_2010-jyfs = '1'.
      ev_skzhhh = 'CNCBIHK'.
    ENDIF.
  ENDMETHOD.


METHOD SET_SK_ADDRESS.
    IF gs_2001-zfmark = '10'.
      SELECT SINGLE street,
             str_suppl2,
             str_suppl3,
             location
      INTO @DATA(ls_adrc)
      FROM kna1 JOIN adrc
        ON kna1~adrnr = adrc~addrnumber
      WHERE kna1~kunnr = @gs_2001-zskno.
    ELSEIF gs_2001-zfmark = '20'.
      SELECT SINGLE street,
             str_suppl2,
             str_suppl3,
             location
      INTO @ls_adrc
      FROM lfa1 JOIN adrc
        ON lfa1~adrnr = adrc~addrnumber
      WHERE lfa1~lifnr = @gs_2001-zskno.
    ENDIF.
    ev_address = ls_adrc-street && ls_adrc-str_suppl2 && ls_adrc-str_suppl3 && ls_adrc-location.
  ENDMETHOD.


METHOD SET_SK_BANKA.
    IF iv_type = '1'.
      IF gs_2010-jyfs = '2' OR gs_2010-jyfs = '3'.
        ev_banka = gs_2002-zskbanka.
      ENDIF.
    ELSEIF iv_type = '2'.
      IF gs_2010-jyfs NE '1'.
        ev_banka = gs_2002-zskbanka.
      ENDIF.
    ENDIF.

  ENDMETHOD.


METHOD SET_SK_BANKL.
    IF gs_2010-jyfs = '4'.
      ev_bankl = gs_2002-zskbankl.
    ENDIF.
  ENDMETHOD.


METHOD SET_SK_BANKS.
    IF gs_2010-jyfs NE '1'.
      ev_banks = gs_2002-banks.
    ENDIF.
  ENDMETHOD.


METHOD set_sk_country.
    IF gs_2010-jyfs NE '1'.
      IF gs_2001-zfmark = '10'.
        SELECT SINGLE country
        INTO @ev_country
        FROM kna1 JOIN adrc
          ON kna1~adrnr = adrc~addrnumber
        WHERE kna1~kunnr = @gs_2001-zskno.
      ELSEIF gs_2001-zfmark = '20'.
        SELECT SINGLE country
        INTO @ev_country
        FROM lfa1 JOIN adrc
          ON lfa1~adrnr = adrc~addrnumber
        WHERE lfa1~lifnr = @gs_2001-zskno.
***ADD BY GWDEV27 20201023 START-
      ELSEIF  gs_2001-zfmark = ''.
        SELECT SINGLE banks
        INTO @ev_country
        FROM bnka
        WHERE bankl = @gs_2002-zskbankl.
***ADD BY GWDEV27 20201023 END.
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD set_sk_waers.
    IF gs_2010-jyfs = '1'.
      ev_waers_citic = me->convert_waers( gs_2002-zskwaers ).
    ENDIF.

  ENDMETHOD.


METHOD SET_USENO.
    IF gs_2010-jyfs = '4'.
      ev_useno = '20'.
    ENDIF.
  ENDMETHOD.


METHOD SET_YQZFRQ.
    IF gs_2010-yyzfbz = '1'.
      ev_yqzfrq = gs_2010-yqzyrq.
    ENDIF.
  ENDMETHOD.


METHOD SET_YQZFSJ.
    IF gs_2010-yyzfbz = '1'.
      ev_yqzfsj = '100000'.
    ENDIF.
  ENDMETHOD.


METHOD SET_ZJYHDH.
    IF gs_2010-jyfs = '3'.
      ev_zjyhdh = gs_2010-zjyhdh.
    ENDIF.
  ENDMETHOD.


METHOD SET_ZJYHMC.
    IF gs_2010-jyfs = '3'.
      ev_zjyhmc = gs_2010-zjyhmc.
    ENDIF.
  ENDMETHOD.


METHOD set_zqfs.
    rv_zqfs = gs_2010-zzqfs.
  ENDMETHOD.
ENDCLASS.
