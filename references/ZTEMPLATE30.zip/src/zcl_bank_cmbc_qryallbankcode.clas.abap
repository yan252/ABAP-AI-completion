class ZCL_BANK_CMBC_QRYALLBANKCODE definition
  public
  inheriting from ZCL_ABSTRACT_BANK_FUNCTION
  final
  create public .

public section.

  interfaces ZIF_CMBC_FUNCTION .

  methods ZIF_BANK_FUNCTION~SET_SENDING_DATA_REFERENCE
    redefinition .
protected section.

  aliases INTERACTION_COUNT
    for ZIF_CMBC_FUNCTION~INTERACTION_COUNT .
  aliases GET_CURRENT_PACKAGE_ID
    for ZIF_CMBC_FUNCTION~GET_CURRENT_PACKAGE_ID .
  aliases WAIT
    for ZIF_CMBC_FUNCTION~WAIT .

  methods CONVERT_DATA_TO_DMEE_TYPE
    redefinition .
private section.
ENDCLASS.



CLASS ZCL_BANK_CMBC_QRYALLBANKCODE IMPLEMENTATION.


  method CONVERT_DATA_TO_DMEE_TYPE.
    FIELD-SYMBOLS: <ft_dmee_data> TYPE STANDARD TABLE.

    CREATE DATA re_dmee_table_ref TYPE ztrs_boc_b2e0043_request_tab.

    ASSIGN re_dmee_table_ref->* TO <ft_dmee_data>.

    APPEND INITIAL LINE TO <ft_dmee_data>.

  endmethod.


  METHOD zif_bank_function~set_sending_data_reference.

    FIELD-SYMBOLS: <ft_data> TYPE STANDARD TABLE.
    DATA: l_line_ref TYPE REF TO data.

    CREATE DATA sending_data_reference
           TYPE STANDARD TABLE OF (function_config-struc_in).

    ASSIGN sending_data_reference->* TO <ft_data>.

    APPEND INITIAL LINE TO <ft_data>.

  ENDMETHOD.


  method ZIF_CMBC_FUNCTION~GET_CURRENT_PACKAGE_ID.

  endmethod.


  method ZIF_CMBC_FUNCTION~WAIT.
    zcl_cmbc_enhancement=>wait(
                    CHANGING
                      ch_interaction_count = interaction_count ).
  endmethod.
ENDCLASS.
