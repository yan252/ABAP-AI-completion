FUNCTION ZFM_STRANS_DOWNLOAD.
*"----------------------------------------------------------------------
*"*"本地接口：
*"  IMPORTING
*"     VALUE(IM_PATH) TYPE  BDCDATA-FVAL OPTIONAL
*"  TABLES
*"      IT_STRANS STRUCTURE  ZTRS_STRANS
*"----------------------------------------------------------------------
  DATA: L_PATH  TYPE STRING, "保存目录
        L_REGEX TYPE STRING,
        L_SUBRC TYPE SY-SUBRC,
        L_MODE  TYPE CHAR1 VALUE 'N'.
*  FIELD-SYMBOLS:  <DMEE> STRUCTURE ZTRS_DMEE DEFAULT ZTRS_DMEE.
  DATA: LT_MESSTAB LIKE  TABLE OF BDCMSGCOLL,
        LS_MESSTAB LIKE  BDCMSGCOLL.
  DATA: LS_MSGTX TYPE MSGTX.
  DATA: BEGIN OF ITAB OCCURS 0,
          LINE(250).
  DATA: END OF ITAB.

  IF IM_PATH IS INITIAL.
    IM_PATH = 'D:\STRANS\'."此路径地址最好不要太长，因为DMEE下载路径长度有限制
  ENDIF.
  IF IT_STRANS[] IS INITIAL.
    SELECT PROGNAME
      INTO CORRESPONDING FIELDS OF TABLE IT_STRANS
      FROM REPOSRC
      WHERE PROGNAME LIKE 'ZBANK%XT'
        AND PROGNAME NOT LIKE 'ZBANK%IXT'
        AND PROGNAME NOT LIKE 'ZBANK%=EXT'
        AND SUBC = 'X'
      .
  ENDIF.
  LOOP AT IT_STRANS ASSIGNING FIELD-SYMBOL(<STRANS>).

    L_SUBRC = 0.
    LS_MSGTX = ''.
    "去除结尾的====XT.
    CLEAR:  ITAB,ITAB[].
    READ REPORT <STRANS>-PROGNAME
      INTO ITAB.
    L_REGEX = '(=+XT)'.
    REPLACE REGEX L_REGEX IN <STRANS>-PROGNAME WITH ''.
*    REPLACE  ALL  OCCURRENCES  OF  REGEX  L_REGEX  IN  <STRANS>-PROGNAME  WITH  '' .
    L_PATH = IM_PATH && <STRANS>-PROGNAME .

    IF SY-SUBRC = 0.
      <STRANS>-SUCC = 'X'.
      CALL FUNCTION 'GUI_DOWNLOAD'
        EXPORTING
          FILENAME                = L_PATH
        TABLES
          DATA_TAB                = ITAB
        EXCEPTIONS
          FILE_WRITE_ERROR        = 1
          NO_BATCH                = 2
          GUI_REFUSE_FILETRANSFER = 3
          INVALID_TYPE            = 4
          NO_AUTHORITY            = 5
          UNKNOWN_ERROR           = 6
          HEADER_NOT_ALLOWED      = 7
          SEPARATOR_NOT_ALLOWED   = 8
          FILESIZE_NOT_ALLOWED    = 9
          HEADER_TOO_LONG         = 10
          DP_ERROR_CREATE         = 11
          DP_ERROR_SEND           = 12
          DP_ERROR_WRITE          = 13
          UNKNOWN_DP_ERROR        = 14
          ACCESS_DENIED           = 15
          DP_OUT_OF_MEMORY        = 16
          DISK_FULL               = 17
          DP_TIMEOUT              = 18
          FILE_NOT_FOUND          = 19
          DATAPROVIDER_EXCEPTION  = 20
          CONTROL_FLUSH_ERROR     = 21
          OTHERS                  = 22.
      IF SY-SUBRC = 0.
        <STRANS>-SUCC = 'X'.
      ELSE.
        <STRANS>-SUCC = ''.
      ENDIF.
    ELSE.
      <STRANS>-SUCC = ''.
    ENDIF.

  ENDLOOP.


ENDFUNCTION.
