METHOD ZZENHM_INSERT_USER_SECSTORE .
    TRY.
      insert_user_secstore( iv_password ).
    CATCH cx_epic_bank_comm_logon INTO DATA(lr_cx_epic_bank_comm_logon).
      RAISE EXCEPTION TYPE cx_epic_bank_comm_logon
        EXPORTING
          previous = lr_cx_epic_bank_comm_logon.
  ENDTRY.
ENDMETHOD.
