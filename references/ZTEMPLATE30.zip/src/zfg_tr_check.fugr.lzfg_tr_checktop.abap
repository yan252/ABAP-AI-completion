FUNCTION-POOL zfg_tr_check.                 "MESSAGE-ID ..

TYPES: BEGIN OF lty_s_lockw,"锁定的周资金计划的行项目
         bguid TYPE guid_32,
         itemn TYPE ztr_itemn,
       END OF lty_s_lockw,

       BEGIN OF lty_s_lockhp,"锁住的汇票
         docno_key TYPE ztr_docno_base,
         zjsno     TYPE ztr_jsno,
       END OF lty_s_lockhp.

* INCLUDE LZFG_TR_CHECKD...                  " Local class definition

DATA: ls_2001   TYPE ztrt2001, "支付单抬头
      ls_2002   TYPE ztrt2002, "支付单信息-收款银行信息
      ls_2003   TYPE ztrt2003, "支付单-付款银行信息
      lt_2004   TYPE STANDARD TABLE OF ztrt2004, "付款明细-挂账
      lt_2005   TYPE STANDARD TABLE OF ztrt2005, "付款明细-预付款
*      ls_2006 TYPE ztrt2006,"支付单-银行转账支付信息
*      ls_2007 TYPE ztrt2007,"
      ls_2008   TYPE ztrt2008, "支付单-汇票支付单抬头
      lt_return TYPE STANDARD TABLE OF bapiret2,
      lt_lockhp TYPE STANDARD TABLE OF lty_s_lockhp,
      lt_lockw  TYPE STANDARD TABLE OF lty_s_lockw,
      lt_2009   TYPE STANDARD TABLE OF ztrt2009. "支付单-汇票支付行项目
DATA auto_apro TYPE boolean."自动审批 发送付款指令标记

** 支付单状态查询函数展示内表
*TYPES: BEGIN OF ty_alv.
*    INCLUDE TYPE ztr_zfdq_gz.
*    INCLUDE TYPE ztr_zfdq_yfk.
*    INCLUDE TYPE ztr_qzfd_status.
*
*TYPES: zinactive TYPE ztrt3018_02-zinactive,
*       alv_key   TYPE char50,
*       bukrs     TYPE bukrs,
*       itemno    TYPE ztr_sqsxh,
*       wrbtr     TYPE wrbtr,
*       END OF ty_alv.
*DATA:gs_alv TYPE ty_alv,
*     gt_alv LIKE TABLE OF gs_alv.
*DATA: i_screen_start_column TYPE i,
*      i_screen_start_line   TYPE i,
*      i_screen_end_column   TYPE i,
*      i_screen_end_line     TYPE i,
*      lv_yx_only            TYPE int1. "0 看所有；1看锁定的状态；2看支付单

DATA:BEGIN OF gs_col,    "no_out 不显示的列
       yfpz    TYPE char1,
       yfk     TYPE char1,
       jjbilln TYPE char1,
       pbilln  TYPE char1,
       zwkplv  TYPE char1,
       zfd     TYPE char1,
       sumcol  TYPE i , "总列数
     END OF gs_col.
