class ZCL_BANK_FILE_ADJUSTER_CMBC definition
  public
  inheriting from ZCL_BANK_FILE_ADJUSTER
  final
  create public .

public section.

  methods ZIF_SENDING_FILE_ADJUSTER~ADJUST
    redefinition .
  methods ZIF_RESPONSE_FILE_ADJUSTER~ADJUST
    redefinition .
protected section.
private section.

  methods SET_REQUEST_DATA_ERROR
    importing
      !IM_ACTION type ZTR_APP_ACTION_FOR_BANK
      !IM_STEP type ZTR_APP_ACTION_STEP
      !IM_ORIGINAL_CDATA type ANY
      !IM_ORIGINAL_XDATA type ANY
    exporting
      !EX_T_RETURN type BAPIRET2_TAB
      !EX_CDATA type ANY
      !EX_XDATA type ANY .
  methods GET_PAYMENT_REFERENCE
    importing
      !IM_STEP type ZTR_APP_ACTION_STEP
    returning
      value(RE_DOC1R) type ZTRT_PAYMENT-DOC1R .
  methods ADJUST_CHECKPAYMENT_RESPONSE
    importing
      !IM_ACTION type ZTR_APP_ACTION_FOR_BANK
      !IM_STEP type ZTR_APP_ACTION_STEP
      !IM_ORIGINAL_CDATA type ANY
      !IM_ORIGINAL_XDATA type ANY
    exporting
      !EX_T_RETURN type BAPIRET2_TAB
      !EX_CDATA type ANY
      !EX_XDATA type ANY .
  methods ADJUST_PAYMENT_RELATED_CORE
    importing
      !IM_ACTION type ZTR_APP_ACTION_FOR_BANK
      !IM_STEP type ZTR_APP_ACTION_STEP
      !IM_ORIGINAL_CDATA type ANY
      !IM_ORIGINAL_XDATA type ANY
      !IM_CODE_ELEMENT_NAME type CLIKE
      !IM_ADJUSTCODE_ELEMENT_NAME type CLIKE
      !IM_ADJUSTCODE_PARENT_NAME type ANY
      !IM_ADJUSTCODE type CLIKE
    exporting
      !EX_T_RETURN type BAPIRET2_TAB
      !EX_CDATA type ANY
      !EX_XDATA type ANY .
  methods ADJUST_PAYMENT_RESPONSE
    importing
      !IM_ACTION type ZTR_APP_ACTION_FOR_BANK
      !IM_STEP type ZTR_APP_ACTION_STEP
      !IM_ORIGINAL_CDATA type ANY
      !IM_ORIGINAL_XDATA type ANY
    exporting
      !EX_T_RETURN type BAPIRET2_TAB
      !EX_CDATA type ANY
      !EX_XDATA type ANY .
ENDCLASS.



CLASS ZCL_BANK_FILE_ADJUSTER_CMBC IMPLEMENTATION.


METHOD adjust_checkpayment_response.
*  查询支付状态
*  民生银行的文档里列明了查询支付状态的返回码，我们也将这些代码配置在系统中
*  但针对文档中没有明确的返回码，文档里没有指引应如何处理
*  对于这个情况我们一律认为支付还在处理中
    DATA: l_string  TYPE string,
          l_xstring TYPE xstring.
*header的状态
    adjust_payment_related_core(
              EXPORTING
                im_action                  = im_action
                im_step                    = im_step
                im_original_cdata          = im_original_cdata
                im_original_xdata          = im_original_xdata
                im_code_element_name       = zif_cmbc_constant=>code_element_name
                im_adjustcode_element_name = zif_cmbc_constant=>xml_adjustcode_element_name
                im_adjustcode_parent_name  = zif_cmbc_constant=>xml_status_element_name
                im_adjustcode              = zif_cmbc_constant=>customized_processing_code
              IMPORTING
                ex_t_return                = ex_t_return
                ex_cdata                   = l_string
                ex_xdata                   = l_xstring ).
    IF ex_t_return IS NOT INITIAL.
      ex_cdata = im_original_cdata.
      ex_xdata = im_original_xdata.
      RETURN.
    ENDIF.

*BODY的状态
    adjust_payment_related_core(
              EXPORTING
                im_action                  = im_action
                im_step                    = im_step
                im_original_cdata          = l_string
                im_original_xdata          = l_xstring
                im_code_element_name       = zif_cmbc_constant=>statuscode_element_name
                im_adjustcode_element_name = zif_cmbc_constant=>xml_bodysadjustcode_name
                im_adjustcode_parent_name  = zif_cmbc_constant=>xml_statusid_element_name
                im_adjustcode              = zif_cmbc_constant=>customized_processing_code
              IMPORTING
                ex_t_return                = ex_t_return
                ex_cdata                   = ex_cdata
                ex_xdata                   = ex_xdata ).
    IF ex_t_return IS NOT INITIAL.
      ex_cdata = l_string.
      ex_xdata = l_xstring.
      RETURN.
    ENDIF.

  ENDMETHOD.


METHOD adjust_payment_related_core.

    zcl_bank_data_mapping_engine=>get_element_value(
                                   EXPORTING
                                     im_xml_string = im_original_cdata
                                     im_xml_xstring = im_original_xdata
                                     im_t_fieldname = VALUE #( ( name = im_code_element_name ) )
                                   IMPORTING
                                     ex_t_element_values = DATA(lt_element_value)
                                     ex_t_return_errors = ex_t_return ).
    IF ex_t_return IS NOT INITIAL OR
        lt_element_value IS INITIAL.
      ex_cdata = im_original_cdata.
      ex_xdata = im_original_xdata.
      RETURN.
    ENDIF.

    IF im_action = zif_cmbc_constant=>check_payment_action AND
       im_code_element_name = zif_cmbc_constant=>statuscode_element_name AND
       lt_element_value[ 1 ]-data IS INITIAL.
*      查询支付状态
*      XML XDATABODY没有返回状态数据，在XML抬头就返回了错误消息
*      这个情况下不再执行XDATABODY的状态调整
      ex_cdata = im_original_cdata.
      ex_xdata = im_original_xdata.
      RETURN.
    ENDIF.


    DATA(lo_enviroment) =
                     zcl_bank_enviroment=>create(
                                          im_bank_indicator = bank_indicator
                                          im_action = im_action ).

    DATA(ls_function_config) = lo_enviroment->get_function_by_step( im_step ).
    lo_enviroment->get_bank_return_code_info(
                      EXPORTING
                        im_bank_func = ls_function_config-bank_func
                        im_return_code = lt_element_value[ 1 ]-data
                        im_request_status = space
                        im_request_result = space
                      IMPORTING
                        ex_s_rtncode_info = DATA(ls_return_code)
                       EXCEPTIONS
                         return_code_not_found = 1 ).
    IF sy-subrc = 0.
*          找到返回码的配置，不再调整
      ex_cdata = im_original_cdata.
      ex_xdata = im_original_xdata.
      RETURN.
    ENDIF.

    zcl_bank_data_mapping_engine=>add_elements(
                                  EXPORTING
                                      im_xml_string = im_original_cdata
                                      im_xml_xstring = im_original_xdata
                                      im_t_adding_elements = VALUE #( ( parent_name = im_adjustcode_parent_name
                                                                        name = im_adjustcode_element_name
                                                                        data = im_adjustcode ) )
                                   IMPORTING
                                      ex_t_return_errors = ex_t_return
                                      ex_xml_string = DATA(l_new_xml_string)
                                      ex_xml_xstring = DATA(l_new_xml_xstring) ).
    IF ex_t_return IS INITIAL.
      ex_cdata = l_new_xml_string.
      ex_xdata = l_new_xml_xstring.
    ELSE.
      ex_cdata = im_original_cdata.
      ex_xdata = im_original_xdata.
    ENDIF.

  ENDMETHOD.


METHOD adjust_payment_response.
**  我们已经在系统中根据民生银行的文档配置了民生银行的返回码
**  对于支付来说，如果没有配置的返回码（民生银行没提供），按照文档的说法都可以认为是支付报错
    adjust_payment_related_core(
              EXPORTING
                im_action                  = im_action
                im_step                    = im_step
                im_original_cdata          = im_original_cdata
                im_original_xdata          = im_original_xdata
                im_code_element_name       = zif_cmbc_constant=>code_element_name
                im_adjustcode_element_name = zif_cmbc_constant=>xml_adjustcode_element_name
                im_adjustcode_parent_name  = zif_cmbc_constant=>xml_status_element_name
                im_adjustcode              = zif_cmbc_constant=>customized_error_code
              IMPORTING
                ex_t_return                = ex_t_return
                ex_cdata                   = ex_cdata
                ex_xdata                   = ex_xdata ).
  ENDMETHOD.


METHOD get_payment_reference.
    FIELD-SYMBOLS:<ft_entries> TYPE STANDARD TABLE.

    DATA(lo_function) =
           zcl_bank_abstract_action=>get_action(                    "get current running action
                             )->get_bank( bank_indicator         "get current running bank
                                        )->get_bank_function( im_step ).

    DATA(ls_function_config) = lo_function->get_function_config( ).
    DATA(lo_entries) = lo_function->get_sending_data_reference( ).
    ASSIGN lo_entries->* TO <ft_entries>.
    LOOP AT <ft_entries> ASSIGNING FIELD-SYMBOL(<fs_entry>).
      ASSIGN COMPONENT 'SEQNUMBER' OF STRUCTURE <fs_entry> TO FIELD-SYMBOL(<f_sequence>).
      IF <f_sequence> = lo_function->get_current_sending_sequence( ).
*        使用这个方法的只有转账支付功能Xfer和查询支付状态功能qryXfer
*        这两个功能都是单笔执行，一个支付单对应一个支付报文，因此发送条目里的序号和发送序号也是一一对应
        ASSIGN COMPONENT 'DOC1R' OF STRUCTURE <fs_entry> TO FIELD-SYMBOL(<f_doc1r>).
        re_doc1r = <f_doc1r>.
        EXIT.
      ENDIF.
    ENDLOOP.

  ENDMETHOD.


METHOD set_request_data_error.
    CASE im_action.
      WHEN zif_cmbc_constant=>payment_action OR "支付转账
            zif_cmbc_constant=>check_payment_action. "查询支付转账状态
        ex_cdata = zif_cmbc_constant=>response_cmbc_node_prefix &&
                   zif_cmbc_constant=>xml_key_element_prefix &&
                   get_payment_reference( im_step = im_step ) &&
                   zif_cmbc_constant=>xml_key_element_suffix &&
                   zif_cmbc_constant=>adjustcode_element_prefix &&
                   zif_cmbc_constant=>request_data_is_error_code &&
                   zif_cmbc_constant=>adjustcode_element_suffix &&
                   zif_cmbc_constant=>message_element_prefix &&
                   zif_cmbc_constant=>request_data_is_error_msg &&
                   zif_cmbc_constant=>message_element_suffix &&
                   zif_cmbc_constant=>response_cmbc_node_suffix.
      WHEN OTHERS.
        ex_cdata = zif_cmbc_constant=>response_cmbc_node_prefix &&
                   zif_cmbc_constant=>adjustcode_element_prefix &&
                   zif_cmbc_constant=>request_data_is_error_code &&
                   zif_cmbc_constant=>adjustcode_element_suffix &&
                   zif_cmbc_constant=>message_element_prefix &&
                   zif_cmbc_constant=>request_data_is_error_msg &&
                   zif_cmbc_constant=>message_element_suffix &&
                   zif_cmbc_constant=>response_cmbc_node_suffix.
    ENDCASE.

    CALL FUNCTION 'SCMS_STRING_TO_XSTRING'
      EXPORTING
        text   = ex_cdata
      IMPORTING
        buffer = ex_xdata
      EXCEPTIONS
        failed = 1
        OTHERS = 2.
    IF sy-subrc <> 0.
*let it be
    ENDIF.

  ENDMETHOD.


METHOD zif_response_file_adjuster~adjust.
    IF im_original_cdata = zif_cmbc_constant=>request_data_is_error_msg.
*      技术错误
      set_request_data_error(
                EXPORTING
                  im_action         = im_action
                  im_step           = im_step
                  im_original_cdata = im_original_cdata
                  im_original_xdata = im_original_xdata
                IMPORTING
                  ex_t_return       = ex_t_return
                  ex_cdata          = ex_cdata
                  ex_xdata          = ex_xdata ).
      RETURN.
    ENDIF.

    CASE im_action.
      WHEN zif_cmbc_constant=>payment_action.
        adjust_payment_response(
                  EXPORTING
                    im_action         = im_action
                    im_step           = im_step
                    im_original_cdata = im_original_cdata
                    im_original_xdata = im_original_xdata
                  IMPORTING
                    ex_t_return       = ex_t_return
                    ex_cdata          = ex_cdata
                    ex_xdata          = ex_xdata ).
      WHEN zif_cmbc_constant=>check_payment_action.
        adjust_checkpayment_response(
                  EXPORTING
                    im_action         = im_action
                    im_step           = im_step
                    im_original_cdata = im_original_cdata
                    im_original_xdata = im_original_xdata
                  IMPORTING
                    ex_t_return       = ex_t_return
                    ex_cdata          = ex_cdata
                    ex_xdata          = ex_xdata ).
      WHEN OTHERS.
        ex_cdata = im_original_cdata.
        ex_xdata = im_original_xdata.
    ENDCASE.
  ENDMETHOD.


METHOD zif_sending_file_adjuster~adjust.

****    发送文件不需要调整
****    发送文件不需要调整
****    发送文件不需要调整

*    DATA: l_xml_cstring TYPE string,
*          l_xml_xstring TYPE xstring.
**data: lt_attributes type ZTRS_XML_ATTRIBUTE_VALUE_TAB.
*    zcl_bank_enviroment=>s_get_function_by_step(
*                                   EXPORTING
*                                       im_bank_indicator = bank_indicator
*                                       im_action = im_action
*                                       im_step = im_step
*                                    IMPORTING
*                                      ex_s_bank_function = DATA(ls_function_config)
*                                    EXCEPTIONS
*                                      error = 1 ).
*    IF sy-subrc <> 0.
**      真正运行是不可能出现在这一步，如果是银行功能配置错误根本不会跑到这里
*      MESSAGE ID sy-msgid
*              TYPE sy-msgty
*              NUMBER sy-msgno
*              WITH sy-msgv1
*                   sy-msgv2
*                   sy-msgv3
*                   sy-msgv4
*              INTO DATA(l_dummy_message).
*      APPEND VALUE #( id = sy-msgid
*                      type = sy-msgty
*                      number = sy-msgno
*                      message_v1 = sy-msgv1
*                      message_v2 = sy-msgv2
*                      message_v3 = sy-msgv3
*                      message_v4 = sy-msgv4
*                      message = l_dummy_message )
*                  TO ex_t_return.
*      RETURN.
*    ENDIF.
*
*    DATA(lt_attributes) = VALUE ztrs_xml_attribute_value_tab(
**    header version
*                          ( element_name = zif_cmbc_constant=>header_element_name
*                            attribute_name = zif_cmbc_constant=>attribute_header_version_name
*                            value = zif_cmbc_constant=>file_header_version )
**   file version
*                          ( element_name = zif_cmbc_constant=>header_element_name
*                            attribute_name = zif_cmbc_constant=>attribute_version_name
*                            value = zif_cmbc_constant=>file_version )
**    security
*                          ( element_name = zif_cmbc_constant=>header_element_name
*                            attribute_name = zif_cmbc_constant=>attribute_security_name
*                            value = zif_cmbc_constant=>file_security )
**   lang
*                          ( element_name = zif_cmbc_constant=>header_element_name
*                            attribute_name = zif_cmbc_constant=>attribute_language_name
*                            value = zif_cmbc_constant=>file_language )
**   transaction code
*                          ( element_name = zif_cmbc_constant=>header_element_name
*                            attribute_name = zif_cmbc_constant=>attribute_trncode_name
*                            value = ls_function_config-bank_func ) ).
*
*    LOOP AT ch_data ASSIGNING FIELD-SYMBOL(<fs_file>).
*      IF <fs_file>-cfile IS BOUND.
*        ASSIGN <fs_file>-cfile->* TO FIELD-SYMBOL(<f_cstring>).
*        l_xml_cstring = <f_cstring>.
*      ENDIF.
*      IF <fs_file>-xfile IS BOUND.
*        ASSIGN <fs_file>-xfile->* TO FIELD-SYMBOL(<f_xstring>).
*        l_xml_xstring = <f_xstring>.
*      ENDIF.
*      zcl_bank_data_mapping_engine=>set_element_attribute_values(
*                                     EXPORTING
*                                          im_t_attribute_values = lt_attributes
*                                     IMPORTING
*                                          et_return_errors = ex_t_return
*                                     CHANGING
*                                          ch_xml_xstring = l_xml_xstring
*                                          ch_xml_string = l_xml_cstring ).
*      IF ex_t_return IS INITIAL.
*        IF <f_cstring> IS ASSIGNED .
*          <f_cstring> = l_xml_cstring.
*        ENDIF.
*
*        IF <f_xstring> IS ASSIGNED .
*          <f_xstring> = l_xml_xstring.
*        ENDIF.
*      ELSE.
*        RETURN.
*      ENDIF.
*
*    ENDLOOP.
  ENDMETHOD.
ENDCLASS.
