FUNCTION ZFM_TR_BANK_PAYMNT_CORE.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     VALUE(IM_T_ORDER_LIST) TYPE  ZTRS_PAYMENTORDER_LIST_TAB
*"     VALUE(IM_ACTION) TYPE  ZTR_APP_ACTION_FOR_BANK
*"--------------------------------------------------------------------
******  log
  IF zcl_bank_logger_protocal=>receive_paymorder_in_api(
                                im_action       = im_action
                                im_t_order_list = im_t_order_list ) = space.
    RETURN.
  ENDIF.
******  log end
  DATA(lo_action) = zcl_bank_abstract_action=>create( im_action ).
  IF lo_action IS BOUND.
    lo_action->set_entries( im_t_order_list ).
    lo_action->run( ).
  ENDIF.
  zcl_bank_logger_protocal=>end_logs( im_action ).





ENDFUNCTION.
