FUNCTION ZFM_TR_TO_RTR_BLOCK_GET.
*"----------------------------------------------------------------------
*"*"本地接口：
*"  IMPORTING
*"     VALUE(BUKRS) TYPE  BUKRS
*"     VALUE(BELNR) TYPE  ZTR_ZFDQ_GZ OPTIONAL
*"     VALUE(ZBELNR1) TYPE  ZBELNR1 OPTIONAL
*"  CHANGING
*"     VALUE(BLOCKED) TYPE  CHAR1 OPTIONAL
*"----------------------------------------------------------------------
*---------校验输入项，若都输入默认校验第一个

  IF belnr IS NOT INITIAL AND zbelnr1 IS NOT INITIAL.
    CLEAR zbelnr1.
  ENDIF.
  CLEAR BLOCKED.
*  10-应付凭证
  IF belnr IS NOT INITIAL.

    SELECT SINGLE zlspr INTO @DATA(zlspr) FROM bseg
        WHERE bukrs = @bukrs
        AND belnr  = @belnr-belnr
        AND gjahr  = @belnr-gjahr
        AND buzei  = @belnr-buzei.

    IF zlspr IS NOT INITIAL.
      blocked = 'X'.
    ENDIF.
    RETURN.
  ENDIF.
**  20-预付款申请单
*  IF zbelnr1 IS  NOT INITIAL .
*    SELECT SINGLE frgzu INTO @DATA(frgzu) FROM zrtrt00040
*      WHERE zbelnr1 = @zbelnr1.
*    IF frgzu NE 'F' AND sy-subrc = 0.
*      blocked = 'X'.
*    ENDIF.
*  ENDIF.
*
*



ENDFUNCTION.
