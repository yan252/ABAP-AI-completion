class ZCX_EPIC_BANK_COMM_LOGON definition
  public
  inheriting from CX_STATIC_CHECK
  final
  create public .

public section.

  interfaces IF_T100_MESSAGE .

  constants:
    begin of USER_NOT_EXITS,
      msgid type symsgid value 'ZTR_BANK_APPLICATION',
      msgno type symsgno value '052',
      attr1 type scx_attrname value '',
      attr2 type scx_attrname value '',
      attr3 type scx_attrname value '',
      attr4 type scx_attrname value '',
    end of USER_NOT_EXITS .
  constants:
    begin of ASSIGNMENT_EXITS,
      msgid type symsgid value 'EPIC_BANK_COMM',
      msgno type symsgno value '303',
      attr1 type scx_attrname value '',
      attr2 type scx_attrname value '',
      attr3 type scx_attrname value '',
      attr4 type scx_attrname value '',
    end of ASSIGNMENT_EXITS .
  constants:
    begin of SECURE_STORE,
      msgid type symsgid value 'EPIC_BANK_COMM',
      msgno type symsgno value '309',
      attr1 type scx_attrname value 'MV_ERROR',
      attr2 type scx_attrname value 'MV_MSGID',
      attr3 type scx_attrname value 'MV_MSGNO',
      attr4 type scx_attrname value '',
    end of SECURE_STORE .
  constants:
    begin of ENQUEUE_ERROR,
      msgid type symsgid value 'EPIC_BANK_COMM',
      msgno type symsgno value '308',
      attr1 type scx_attrname value 'MV_ZBUKR',
      attr2 type scx_attrname value 'MV_HBKID',
      attr3 type scx_attrname value 'MV_HKTID',
      attr4 type scx_attrname value 'MV_BCTYP',
    end of ENQUEUE_ERROR .
  constants:
    begin of REPEAT_PWD_WRONG,
      msgid type symsgid value 'EPIC_BANK_COMM',
      msgno type symsgno value '307',
      attr1 type scx_attrname value '',
      attr2 type scx_attrname value '',
      attr3 type scx_attrname value '',
      attr4 type scx_attrname value '',
    end of REPEAT_PWD_WRONG .
  constants:
    begin of OLD_PWD_WRONG,
      msgid type symsgid value 'EPIC_BANK_COMM',
      msgno type symsgno value '306',
      attr1 type scx_attrname value '',
      attr2 type scx_attrname value '',
      attr3 type scx_attrname value '',
      attr4 type scx_attrname value '',
    end of OLD_PWD_WRONG .
  constants:
    begin of NO_AUTHORIZATION,
      msgid type symsgid value 'EPIC_BANK_COMM',
      msgno type symsgno value '305',
      attr1 type scx_attrname value '',
      attr2 type scx_attrname value '',
      attr3 type scx_attrname value '',
      attr4 type scx_attrname value '',
    end of NO_AUTHORIZATION .
  constants:
    begin of NO_CHANGE,
      msgid type symsgid value 'EPIC_BANK_COMM',
      msgno type symsgno value '304',
      attr1 type scx_attrname value '',
      attr2 type scx_attrname value '',
      attr3 type scx_attrname value '',
      attr4 type scx_attrname value '',
    end of NO_CHANGE .
  constants:
    begin of ILLEGAL_CALLER,
      msgid type symsgid value 'EPIC_BANK_COMM',
      msgno type symsgno value '310',
      attr1 type scx_attrname value 'MV_CALLER',
      attr2 type scx_attrname value '',
      attr3 type scx_attrname value '',
      attr4 type scx_attrname value '',
    end of ILLEGAL_CALLER .
  data MV_ERROR type STRING .
  data MV_CALLER type SYREPID .
  data MV_MSGID type SY-MSGID .
  data MV_MSGNO type SY-MSGNO .

  methods CONSTRUCTOR
    importing
      !TEXTID like IF_T100_MESSAGE=>T100KEY optional
      !PREVIOUS like PREVIOUS optional
      !MV_ERROR type STRING optional
      !MV_CALLER type SYREPID optional
      !MV_MSGID type SY-MSGID optional
      !MV_MSGNO type SY-MSGNO optional .
protected section.
private section.
ENDCLASS.



CLASS ZCX_EPIC_BANK_COMM_LOGON IMPLEMENTATION.


  method CONSTRUCTOR.
CALL METHOD SUPER->CONSTRUCTOR
EXPORTING
PREVIOUS = PREVIOUS
.
me->MV_ERROR = MV_ERROR .
me->MV_CALLER = MV_CALLER .
me->MV_MSGID = MV_MSGID .
me->MV_MSGNO = MV_MSGNO .
clear me->textid.
if textid is initial.
  IF_T100_MESSAGE~T100KEY = IF_T100_MESSAGE=>DEFAULT_TEXTID.
else.
  IF_T100_MESSAGE~T100KEY = TEXTID.
endif.
  endmethod.
ENDCLASS.
