class ZCL_3023_FACTORY definition
  public
  final
  create public .

public section.

  class-methods CREATE_BANK
    importing
      !IV_BANKS type BANKS
      !IV_BANK_IND type ZTR_BANK_INDICATOR
      !IV_BUKRS type BUKRS optional
      !IV_HBKID type HBKID optional
      !IV_HKTID type HKTID optional
      !IV_VERSNO type VERSNO optional
    returning
      value(EO_BANK) type ref to ZIF_3023_BANK .
protected section.
private section.
ENDCLASS.



CLASS ZCL_3023_FACTORY IMPLEMENTATION.


METHOD create_bank.

*    if iv_banks = 'X' and iv_bank_ind = 'X' and iv_bank_ind = 'X'  and iv_hbkid = 'X'.
    IF 1 = 2 .
      CREATE OBJECT eo_bank TYPE zcl_3023_bank01
        EXPORTING
          iv_banks    = iv_banks
          iv_bank_ind = iv_bank_ind
          iv_bukrs    = iv_bukrs
          iv_hbkid    = iv_hbkid
          iv_versno   = iv_versno.
      RETURN .
    ENDIF.
*    endif.

    CREATE OBJECT eo_bank TYPE zcl_3023_bank
      EXPORTING
        iv_banks    = iv_banks
        iv_bank_ind = iv_bank_ind
        iv_bukrs    = iv_bukrs
        iv_hbkid    = iv_hbkid
        iv_hktid    = iv_hktid
        iv_versno   = iv_versno.
    RETURN .
  ENDMETHOD.
ENDCLASS.
