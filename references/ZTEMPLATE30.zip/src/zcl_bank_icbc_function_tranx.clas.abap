class ZCL_BANK_ICBC_FUNCTION_TRANX definition
  public
  inheriting from ZCL_BANK_FUNCTION_TRANSACTIONS
  final
  create public .

public section.

  interfaces ZIF_ICBC_FUNCTION .

  aliases GET_CURRENT_PACKAGE_ID
    for ZIF_ICBC_FUNCTION~GET_CURRENT_PACKAGE_ID .
protected section.

  methods CHECK_RESPONSE_IF_FINISHED
    redefinition .
  methods PROCESSING_RESPONSE_INTL_CORE
    redefinition .
private section.
ENDCLASS.



CLASS ZCL_BANK_ICBC_FUNCTION_TRANX IMPLEMENTATION.


  METHOD check_response_if_finished.
    FIELD-SYMBOLS: <fs_response>        TYPE ztrs_icbc_qhisd_response.
    DATA: l_leading_xml_string TYPE string,
          l_real_xml_string    TYPE string,
          l_real_xml_xstring   TYPE xstring.
    CONSTANTS: c_nexttag TYPE string VALUE 'NextTag'.

    DATA(ls_response_data) = get_current_response_data( ).
    ASSIGN ls_response_data-response_ref->* TO <fs_response>.

    IF <fs_response>-out-nexttag IS INITIAL.
*当前返回的nexttag为空值，说明本账户本次查询结束
      current_response_is_finished = yes.
      RETURN.
    ELSE.
*  not finished
      DATA(ls_sending_xml_ref) = get_sending_file_by_sequence( current_sending_sequence ).
      ASSIGN ls_sending_xml_ref-cfile->* TO FIELD-SYMBOL(<f_xml_string>).
      ASSIGN ls_sending_xml_ref-xfile->* TO FIELD-SYMBOL(<f_xml_xstring>).
*********工商银行发送的报文前有'reqData='前缀和其他信息，在替换节点值前先需要将这些信息去掉
      SPLIT <f_xml_string> AT zif_icbc_constant=>xml_okay_prefix_code
                           INTO l_leading_xml_string
                                l_real_xml_string.
*      真正的报文
      l_real_xml_string = cl_http_utility=>unescape_url( l_real_xml_string ).

*重置nexttag
      zcl_bank_data_mapping_engine=>reset_element_value(
                                       EXPORTING
                                         im_t_element_values = VALUE #( ( name = c_nexttag
                                                                          data = <fs_response>-out-nexttag ) )
                                       IMPORTING
                                         et_return_errors = DATA(lt_return_errors)
                                       CHANGING
                                         ch_xml_xstring = l_real_xml_xstring
                                         ch_xml_string = l_real_xml_string ).
      IF lt_return_errors IS NOT INITIAL.
        messages->add_message_set( lt_return_errors ).
        current_response_is_finished = yes.
        RETURN.
      ELSE.
*再重新组合发送的消息
        <f_xml_string> = l_leading_xml_string &&
                         zif_icbc_constant=>xml_okay_prefix_code &&
                         cl_http_utility=>escape_url( l_real_xml_string ).
        CALL FUNCTION 'SCMS_STRING_TO_XSTRING'
          EXPORTING
            text   = <f_xml_string>
          IMPORTING
            buffer = <f_xml_xstring>
          EXCEPTIONS
            failed = 1
            OTHERS = 2.
        current_response_is_finished = no.
      ENDIF.
    ENDIF.


  ENDMETHOD.


  METHOD processing_response_intl_core.
    processing_response_by_dbtable(
                im_data_db_table = 'ZTRT_ICBC_TRNS'
                im_detail_response_component = 'OUT-RD'
                im_statuscode_componnet = 'PUB-RETCODE'
                im_statustext_component = 'PUB-RETMSG'
                im_db_account_number_field = ''
                IM_BANK_ENTRY_ACCNUMBER_FIELD = space  ).
  ENDMETHOD.


  method ZIF_ICBC_FUNCTION~GET_CURRENT_PACKAGE_ID.
    INCLUDE ztri_bank_icbc_func_packageid.
  endmethod.
ENDCLASS.
