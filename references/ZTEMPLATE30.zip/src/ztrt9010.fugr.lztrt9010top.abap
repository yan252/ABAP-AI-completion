FUNCTION-POOL ZTRT9010                   MESSAGE-ID SV.

* INCLUDE LZTRT9010D...                      " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZTRT9010T00                            . "view rel. data dcl.
