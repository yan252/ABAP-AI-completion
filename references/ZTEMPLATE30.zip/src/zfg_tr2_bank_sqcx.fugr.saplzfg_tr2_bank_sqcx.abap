*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_TR2_BANK_SQCXTOP.             " Global Declarations
  INCLUDE LZFG_TR2_BANK_SQCXUXX.             " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_TR2_BANK_SQCXF...             " Subroutines
* INCLUDE LZFG_TR2_BANK_SQCXO...             " PBO-Modules
* INCLUDE LZFG_TR2_BANK_SQCXI...             " PAI-Modules
* INCLUDE LZFG_TR2_BANK_SQCXE...             " Events
* INCLUDE LZFG_TR2_BANK_SQCXP...             " Local class implement.
* INCLUDE LZFG_TR2_BANK_SQCXT99.             " ABAP Unit tests
