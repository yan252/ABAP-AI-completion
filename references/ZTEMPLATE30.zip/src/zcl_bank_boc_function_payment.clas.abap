class ZCL_BANK_BOC_FUNCTION_PAYMENT definition
  public
  inheriting from ZCL_BANK_FUNCTION_PAYMENT
  final
  create public .

public section.

  interfaces ZIF_BOC_FUNCTION .
protected section.

  methods PROCESSING_RESPONSE_INTL_CORE
    redefinition .
private section.

  aliases RAISE_B2EERROR
    for ZIF_BOC_FUNCTION~RAISE_B2EERROR .
ENDCLASS.



CLASS ZCL_BANK_BOC_FUNCTION_PAYMENT IMPLEMENTATION.


  METHOD processing_response_intl_core.
    FIELD-SYMBOLS: <fs_response>        TYPE ztrs_boc_b2e0009_response.
    DATA: ls_bank_payment_return TYPE ztrs_payment_bank_return.

    super->processing_response_intl_core( ).

    DATA(ls_response_data) = get_current_response_data( ).
    ASSIGN ls_response_data-response_ref->* TO <fs_response>.

    MOVE: <fs_response>-h_status-rspcod TO ls_bank_payment_return-header-bank_rtncode,
          <fs_response>-h_status-rspmsg  TO ls_bank_payment_return-header-bank_rtnmsg.
    LOOP AT <fs_response>-trans INTO DATA(ls_transaction).
      APPEND VALUE #( paymorder = ls_transaction-insid
                      doc1r = ls_transaction-insid
                      bank_rtncode = ls_transaction-rspcod
                      bank_rtnmsg = ls_transaction-rspmsg
                      bank_tran_number = ls_transaction-obssid )
                   TO ls_bank_payment_return-items.
    ENDLOOP.

    update_status_in_instance( ls_bank_payment_return ).
  ENDMETHOD.


  METHOD zif_boc_function~raise_b2eerror.
    raise_b2eerror.
    check_response_if_finished( ).
  ENDMETHOD.
ENDCLASS.
