class ZCL_GLOBAL_TECHNICAL_SERVICE definition
  public
  final
  create public .

public section.

  constants YES type FLAG value 'X' ##NO_TEXT.
  constants NO type FLAG value SPACE ##NO_TEXT.

  class-methods GET_DOMAIN_VALUES
    importing
      !IM_DOMAIN_NAME type CLIKE
    returning
      value(RT_VALUES) type DD07V_TAB .
  class-methods CHECK_DOMAIN_VALUE
    importing
      !IM_DOMAIN_NAME type CLIKE
      !IM_DOMAIN_VALUE type ANY
      !IM_ALLOW_INITIAL_VALUE type FLAG default SPACE
    exceptions
      NOT_VALID .
  class-methods GET_DOMAIN_TEXT
    importing
      !IM_INGNORE_ERROR type FLAG default SPACE
      !IM_DOMAIN_NAME type CLIKE
      !IM_DOMAIN_VALUE type ANY
    returning
      value(R_TEXT) type DD07V-DDTEXT .
  class-methods GET_SYSTEM_INFO
    returning
      value(RS_SYSTEM_INFO) type ZBCS_SYSTEM_INFO .
  class-methods CHECK_TABLE
    importing
      !IM_TABNAME type TABNAME
    exceptions
      NOT_FOUND .
  class-methods SET_LISTBOX_BY_DOMAINVALUES
    importing
      !IM_DOMAIN type CLIKE
      !IM_LIST_NAME type CLIKE
      !IM_EXCLUDE_VALUES type ZTRS_VRM_KEY_VALUE_TAB optional .
  class-methods SET_LISTBOX_FROM_TABLE
    importing
      !IM_ITAB type STANDARD TABLE
      !IM_KEY_FIELD type CLIKE
      !IM_TEXT_FIELD type CLIKE
      !IM_LIST_NAME type CLIKE .
  class-methods SET_LISTBOX
    importing
      !IM_LIST_NAME type CLIKE
      !IM_LIST_VALUE type VRM_VALUES .
  class-methods CONVERT_TABLE_INTO_LISTBOX
    importing
      !IM_ITAB type STANDARD TABLE
      !IM_KEY_FIELD type CLIKE
      !IM_TEXT_FIELD type CLIKE
      !IM_EXCLUDE_VALUES type ZTRS_VRM_KEY_VALUE_TAB optional
    returning
      value(RT_LIST_VALUES) type VRM_VALUES .
protected section.
private section.
ENDCLASS.



CLASS ZCL_GLOBAL_TECHNICAL_SERVICE IMPLEMENTATION.


METHOD check_domain_value.

    IF im_allow_initial_value = no AND
       im_domain_value IS INITIAL.
      MESSAGE e103(zcamessage)
              WITH im_domain_name
              RAISING not_valid.
    ENDIF.

    DATA(lt_dd07v) = get_domain_values( im_domain_name = im_domain_name ).
    IF lt_dd07v IS INITIAL.
      MESSAGE e102(zcamessage)
              WITH im_domain_name
              RAISING not_valid.
    ENDIF.

    LOOP AT lt_dd07v TRANSPORTING NO FIELDS
          WHERE  ( domvalue_l <= im_domain_value   AND
                   domvalue_h >= im_domain_value ) OR
                 ( domvalue_l =  im_domain_value ).
      EXIT.
    ENDLOOP.
    IF sy-subrc <> 0.
*        not valid
      MESSAGE e101(zcamessage)
              WITH im_domain_name
                   im_domain_value
              RAISING not_valid.
    ENDIF.

  ENDMETHOD.


METHOD check_table.
    SELECT COUNT( * ) INTO @DATA(l_count)
      FROM dd02l
      WHERE tabname = @im_tabname
      AND   as4local = 'A'
       AND  as4vers = '0000'.
    IF l_count <= 0.
      MESSAGE e029(zcamessage)
              WITH im_tabname
              RAISING not_found.
    ENDIF.
  ENDMETHOD.


METHOD convert_table_into_listbox.
    DATA: ls_value      TYPE vrm_value.
    LOOP AT im_itab ASSIGNING FIELD-SYMBOL(<fs_line_data>).
      ASSIGN COMPONENT im_key_field OF STRUCTURE <fs_line_data> TO FIELD-SYMBOL(<f_field>).
      IF sy-subrc = 0.
        ls_value-key = <f_field>.
      ENDIF.
      ASSIGN COMPONENT im_text_field OF STRUCTURE <fs_line_data> TO <f_field>.
      IF sy-subrc = 0.
        ls_value-text = <f_field>.
      ENDIF.
      CHECK ls_value IS NOT INITIAL.
      IF im_exclude_values IS NOT INITIAL.
        READ TABLE im_exclude_values TRANSPORTING NO FIELDS
             WITH KEY key = ls_value-key.
        CHECK sy-subrc <> 0.
      ENDIF.
      APPEND ls_value TO rt_list_values.
      CLEAR ls_value.
    ENDLOOP.
  ENDMETHOD.


METHOD get_domain_text.
    DATA: l_domain_name  TYPE dd07v-domname,
          l_domain_value TYPE dd07v-domvalue_l.

    MOVE: im_domain_name TO l_domain_name,
          im_domain_value TO l_domain_value.

    CALL FUNCTION 'DOMAIN_VALUE_GET'
      EXPORTING
        i_domname  = l_domain_name
        i_domvalue = l_domain_value
      IMPORTING
        e_ddtext   = r_text
      EXCEPTIONS
        not_exist  = 1
        OTHERS     = 2.
    IF sy-subrc <> 0.
      IF im_ingnore_error = no.
        MESSAGE ID sy-msgid
                TYPE sy-msgty
                NUMBER sy-msgno
                WITH sy-msgv1
                     sy-msgv2
                     sy-msgv3
                     sy-msgv4.
      ENDIF.
    ENDIF.

  ENDMETHOD.


METHOD get_domain_values.
    DATA: l_domain_name  TYPE dd01l-domname.

    MOVE: im_domain_name TO l_domain_name.

    CALL FUNCTION 'DD_DOMVALUES_GET'
      EXPORTING
        domname        = l_domain_name
        text           = 'X'
        langu          = sy-langu
      TABLES
        dd07v_tab      = rt_values
      EXCEPTIONS
        wrong_textflag = 0.

  ENDMETHOD.


method GET_SYSTEM_INFO.
*time stamp
  GET TIME STAMP FIELD rs_system_info-timestamp.

*time zone
  SELECT SINGLE tzonesys
         INTO rs_system_info-timezone
         FROM ttzcu.

*date and time
  CONVERT TIME STAMP rs_system_info-timestamp
          TIME ZONE rs_system_info-timezone
          INTO DATE rs_system_info-datum
               TIME rs_system_info-uzeit.

*user name
  rs_system_info-uname = sy-uname.

*transaction code
  rs_system_info-tcode = sy-tcode.
  endmethod.


METHOD set_listbox.
*    DATA l_list_name TYPE vrm_id.

*    l_list_name = im_list_name.

    CALL FUNCTION 'VRM_SET_VALUES'
      EXPORTING
        id              = im_list_name
        values          = im_list_value
      EXCEPTIONS
        id_illegal_name = 1
        OTHERS          = 2.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid
              TYPE sy-msgty
              NUMBER sy-msgno
              WITH sy-msgv1
                   sy-msgv2
                   sy-msgv3
                   sy-msgv4.
    ENDIF.
  ENDMETHOD.


METHOD set_listbox_by_domainvalues.
    set_listbox( im_list_name = im_list_name
                 im_list_value = convert_table_into_listbox(
                                        im_itab = zcl_global_technical_service=>get_domain_values( im_domain )
                                        im_key_field = 'DOMVALUE_L'
                                        im_text_field = 'DDTEXT'
                                        im_exclude_values = im_exclude_values ) ).
  ENDMETHOD.


METHOD set_listbox_from_table.
    set_listbox(
            im_list_value = convert_table_into_listbox(
                                   im_itab = im_itab
                                   im_key_field = im_key_field
                                   im_text_field = im_text_field )
            im_list_name = im_list_name ).
  ENDMETHOD.
ENDCLASS.
