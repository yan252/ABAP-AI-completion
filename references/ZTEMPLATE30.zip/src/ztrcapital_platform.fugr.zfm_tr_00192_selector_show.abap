FUNCTION ZFM_TR_00192_SELECTOR_SHOW.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     REFERENCE(IM_O_SELECTOR) TYPE
*"EF TO ZCL_0192_RAW_ITEM_SELECTER
*"--------------------------------------------------------------------
selector = im_o_selector.
  CALL SCREEN '0100'.





ENDFUNCTION.
