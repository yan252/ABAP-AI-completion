class ZCL_TR_VAR definition
  public
  final
  create public .

public section.

  class-data MV_PRD type CHAR01 .

  class-methods ZVAR001
    exporting
      !EV_STATUS type ZTR_WPLAN_STATUS .
  class-methods ZVAR002
    exporting
      !EV_FLG type CHAR01 .
  class-methods ZVAR003
    exporting
      !EV_FLG type CHAR01 .
protected section.
private section.
ENDCLASS.



CLASS ZCL_TR_VAR IMPLEMENTATION.


method ZVAR001.
     ev_status = '19'.
  endmethod.


METHOD zvar002.
    ev_flg = abap_false . " 不检查。
  ENDMETHOD.


METHOD ZVAR003.
    ev_flg = abap_false . " 不检查。
  ENDMETHOD.
ENDCLASS.
