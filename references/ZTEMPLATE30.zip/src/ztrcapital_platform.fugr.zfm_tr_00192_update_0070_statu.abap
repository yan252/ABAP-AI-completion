FUNCTION ZFM_TR_00192_UPDATE_0070_STATU.
*"--------------------------------------------------------------------
*"*"更新函数模块：
*"
*"*"局部接口：
*"  IMPORTING
*"     VALUE(IM_NEW_STATUS) TYPE  ZTR_ZTRAN_STATUS
*"     VALUE(IM_DOCNO_KEY) TYPE  ZTR_DOCNO_BASE
*"     VALUE(IM_BUKRS) TYPE  BUKRS
*"     VALUE(IM_ZJSNO) TYPE  ZTR_JSNO
*"--------------------------------------------------------------------
SELECT SINGLE  ztran_status INTO @DATA(l_db_status)
         FROM ztrt0070
         WHERE docno_key = @im_docno_key
         AND   bukrs = @im_bukrs
         AND   zjsno = @im_zjsno.

  IF sy-subrc <> 0 OR
     l_db_status = im_new_status.
    RETURN.
  ENDIF.

  UPDATE ztrt0070 SET ztran_status = im_new_status
                      aedat = sy-datum
                      aezet = sy-uzeit
                      aenam = sy-uname
                  WHERE docno_key = im_docno_key
                  AND   bukrs = im_bukrs
                  AND   zjsno = im_zjsno.





ENDFUNCTION.
