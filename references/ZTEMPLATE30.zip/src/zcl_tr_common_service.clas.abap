class ZCL_TR_COMMON_SERVICE definition
  public
  final
  create public .

public section.

  constants YES type FLAG value 'X' ##NO_TEXT.
  constants NO type FLAG value SPACE ##NO_TEXT.
  class-data BUKRS_9040 type ZTRS_9040_TAB .

  class-methods IF_VALID_COMPANY_CODE
    importing
      !IM_BUKRS type BUKRS
    exceptions
      NOT_VALID .
  class-methods IF_CENTERIZED_INITIATING_BUKRS
    importing
      !IM_BUKRS type BUKRS
    exceptions
      NOT_VALID .
  class-methods GET_BUKRS_TEXT
    importing
      !IM_BUKRS type BUKRS
    returning
      value(RE_TEXT) type BUTXT .
  class-methods READ_9040_COMPANY_CODES
    importing
      !IM_INTEGRATION_MODE type ZTR_BP_MODE optional
      !IM_BUKRS_TYPE type ZTR_BURKS_TYPE optional
      !IM_EXCLUDE_INTEGRATION_MODE type ZTR_BP_MODE optional
      !IM_EXCLUDE_BUKRS_TYPE type ZTR_BURKS_TYPE optional
      !IM_ONLY_0189_CONFIGED_BUKRS type FLAG optional
    returning
      value(RT_VALUES) type ZTRS_9040_TAB .
  class-methods IF_VALID_COMPANY_CODE_IN_TR
    importing
      !IM_BUKRS type BUKRS
    exceptions
      NOT_VALID .
  class-methods INIT_9040_BUKRS .
  class-methods READ_SINGLE_9040_BUKRS
    importing
      !IM_BUKRS type BUKRS
    exporting
      value(EX_S_VALUE) type ZTRS_9040
    exceptions
      NOT_FOUND .
  class-methods GET_PAYMENTMETHOD_BY_ZBOETY
    importing
      !IM_ZBOETY type ZTR_PJ_TYPE
    returning
      value(RE_PAYMENT_METHOD) type ZTR_ZFD_ZFS .
  class-methods GET_VENDOR_CODE_BY_BUKRS
    importing
      !IM_BUKRS type BUKRS
    exporting
      !EX_CODE type LFA1-LIFNR
      !EX_NAME type LFA1-NAME1
    exceptions
      NOT_FOUND .
protected section.
private section.
ENDCLASS.



CLASS ZCL_TR_COMMON_SERVICE IMPLEMENTATION.


METHOD get_bukrs_text.
    DATA: ls_t001 TYPE t001.

    CALL FUNCTION 'T001_SINGLE_READ'
      EXPORTING
        bukrs      = im_bukrs
      IMPORTING
        wt001      = ls_t001
      EXCEPTIONS
        not_found  = 1
        wrong_call = 2
        OTHERS     = 3.
    IF sy-subrc <> 0.
      IF im_bukrs = 'ZZ01'.
        re_text = '内贸公司'.
      ENDIF.
      RETURN.
    ELSE.
      re_text = ls_t001-butxt.
    ENDIF.

  ENDMETHOD.


METHOD get_paymentmethod_by_zboety.
    CASE im_zboety.
      WHEN '10' OR '15'.
*        银票
        "re_payment_method = '52'.
        re_payment_method = '54'.
      WHEN '20' OR '25'.
*        商票
       " re_payment_method = '51'.
        re_payment_method = '53'.

    ENDCASE.
  ENDMETHOD.


METHOD get_vendor_code_by_bukrs.
    DATA: l_vbund TYPE vbund.

    CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
      EXPORTING
        input  = im_bukrs
      IMPORTING
        output = l_vbund.

    SELECT * INTO TABLE @DATA(lt_lfa1)
           FROM lfa1
           WHERE vbund = @l_vbund
*           AND   ktokk = 'S003'"公司代码供应商,实际 运用中需要增加此账户组
*           AND   lifnr LIKE '%0'"20191107 被MDG增加新的虚拟供应商以区别发货工厂
            .
    IF sy-subrc = 0.
      IF lines( lt_lfa1 ) = 1.
        ex_code = lt_lfa1[ 1 ]-lifnr.
        ex_name = lt_lfa1[ 1 ]-name1.
      ELSE.
        MESSAGE e200(ztr04)
                WITH im_bukrs
                RAISING not_found.
      ENDIF.
    ELSE.
      MESSAGE e106(ztr04)
              WITH im_bukrs
              RAISING not_found.

    ENDIF.
  ENDMETHOD.


METHOD if_centerized_initiating_bukrs.
    if_valid_company_code(
               EXPORTING
                 im_bukrs = im_bukrs
               EXCEPTIONS
                 not_valid = 1 ).
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid
              TYPE sy-msgty
              NUMBER sy-msgno
              WITH sy-msgv1
                   sy-msgv2
                   sy-msgv3
                   sy-msgv4
             RAISING not_valid.
    ENDIF.

    SELECT COUNT( * ) INTO @DATA(l_count)
           FROM ztrt0189a
           WHERE ibukrs = @im_bukrs.
    IF l_count < 1.
      MESSAGE e006(ztr04)
              WITH im_bukrs
              RAISING not_valid.
    ENDIF.
  ENDMETHOD.


METHOD if_valid_company_code.
    CALL FUNCTION 'T001_SINGLE_READ'
      EXPORTING
        bukrs      = im_bukrs
      EXCEPTIONS
        not_found  = 1
        wrong_call = 2
        OTHERS     = 3.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid
              TYPE sy-msgty
              NUMBER sy-msgno
              WITH sy-msgv1
                   sy-msgv2
                   sy-msgv3
                   sy-msgv4
             RAISING not_valid.
    ENDIF.

  ENDMETHOD.


METHOD if_valid_company_code_in_tr.
    if_valid_company_code(
           EXPORTING
             im_bukrs = im_bukrs
           EXCEPTIONS
             not_valid = 1 ).
    IF sy-subrc = 0.
      read_single_9040_bukrs(
                EXPORTING
                  im_bukrs = im_bukrs
                EXCEPTIONS
                  not_found = 1 ).
    ENDIF.

    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid
              TYPE sy-msgty
              NUMBER sy-msgno
              WITH sy-msgv1
                   sy-msgv2
                   sy-msgv3
                   sy-msgv4
             RAISING not_valid.
    ENDIF.

  ENDMETHOD.


METHOD init_9040_bukrs.
    SELECT a~bukrs
             a~burks_type AS bukrs_type
             a~bp_mode
             b~butxt
             APPENDING CORRESPONDING FIELDS OF TABLE bukrs_9040
             FROM ztrt9040_1 AS a
             INNER JOIN t001 AS b
             ON a~bukrs = b~bukrs.

    SELECT a~bukrs
           a~burks_type AS bukrs_type
           a~bp_mode
           b~butxt
           APPENDING CORRESPONDING FIELDS OF TABLE bukrs_9040
           FROM ztrt9040_2 AS a
           INNER JOIN t001 AS b
           ON a~bukrs = b~bukrs.

    SELECT a~bukrs
           a~burks_type AS bukrs_type
           a~bp_mode
           b~butxt
           APPENDING CORRESPONDING FIELDS OF TABLE bukrs_9040
           FROM ztrt9040_3 AS a
           INNER JOIN t001 AS b
           ON a~bukrs = b~bukrs.

    SELECT a~bukrs
           a~burks_type AS bukrs_type
           a~bp_mode
           b~butxt
           APPENDING CORRESPONDING FIELDS OF TABLE bukrs_9040
           FROM ztrt9040_4 AS a
           INNER JOIN t001 AS b
           ON a~bukrs = b~bukrs.

    SELECT a~bukrs
           a~burks_type AS bukrs_type
           a~bp_mode
           b~butxt
           APPENDING CORRESPONDING FIELDS OF TABLE bukrs_9040
           FROM ztrt9040_5 AS a
           INNER JOIN t001 AS b
           ON a~bukrs = b~bukrs.

    SORT bukrs_9040 BY bukrs.
    DELETE ADJACENT DUPLICATES FROM bukrs_9040 COMPARING bukrs.
  ENDMETHOD.


METHOD read_9040_company_codes.
    IF bukrs_9040 IS INITIAL.
      init_9040_bukrs( ).
    ENDIF.
    rt_values = bukrs_9040.

    IF im_integration_mode IS SUPPLIED.
      DELETE rt_values WHERE bp_mode <> im_integration_mode.
    ENDIF.


    IF im_bukrs_type IS SUPPLIED.
      DELETE rt_values WHERE bukrs_type <> im_bukrs_type.
    ENDIF.

    IF im_exclude_integration_mode IS SUPPLIED.
      DELETE rt_values WHERE bp_mode = im_exclude_integration_mode.
    ENDIF.

    IF im_exclude_bukrs_type IS SUPPLIED.
      DELETE rt_values WHERE bukrs_type = im_exclude_bukrs_type.
    ENDIF.

    IF im_only_0189_configed_bukrs = yes.
      LOOP AT rt_values INTO DATA(ls_9040).
        zcl_tr_common_service=>if_centerized_initiating_bukrs(
                       EXPORTING
                         im_bukrs = ls_9040-bukrs
                      EXCEPTIONS
                         not_valid = 1 ).
        IF sy-subrc <> 0.
          DELETE rt_values WHERE bukrs = ls_9040-bukrs.
        ENDIF.
      ENDLOOP.
    ENDIF.
  ENDMETHOD.


METHOD read_single_9040_bukrs.
    IF bukrs_9040 IS INITIAL.
      init_9040_bukrs( ).
    ENDIF.

    READ TABLE bukrs_9040 INTO ex_s_value
         WITH KEY bukrs = im_bukrs.
    IF sy-subrc <> 0.
      MESSAGE e026(ztr04) WITH im_bukrs
              RAISING not_found.
    ENDIF.
  ENDMETHOD.
ENDCLASS.
