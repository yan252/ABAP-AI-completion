FUNCTION ZFM_DMEE_DOWNLOAD1.
*"----------------------------------------------------------------------
*"*"本地接口：
*"  IMPORTING
*"     VALUE(CTU) LIKE  APQI-PUTACTIVE DEFAULT 'X'
*"     VALUE(MODE) LIKE  APQI-PUTACTIVE DEFAULT 'N'
*"     VALUE(UPDATE) LIKE  APQI-PUTACTIVE DEFAULT 'L'
*"     VALUE(GROUP) LIKE  APQI-GROUPID OPTIONAL
*"     VALUE(USER) LIKE  APQI-USERID OPTIONAL
*"     VALUE(KEEP) LIKE  APQI-QERASE OPTIONAL
*"     VALUE(HOLDDATE) LIKE  APQI-STARTDATE OPTIONAL
*"     VALUE(NODATA) LIKE  APQI-PUTACTIVE DEFAULT '/'
*"     VALUE(IM_TREE_TYPE) TYPE  DMEE_TREETYPE_ABA DEFAULT 'PAYM'
*"     VALUE(IM_TREE_ID) TYPE  DMEE_TREEID_ABA DEFAULT 'Z**_310201'
*"     VALUE(IM_XMLFILENAME) LIKE  BDCDATA-FVAL DEFAULT
*"       'C:\Users\Admin\**'
*"  EXPORTING
*"     VALUE(SUBRC) LIKE  SYST-SUBRC
*"  TABLES
*"      MESSTAB STRUCTURE  BDCMSGCOLL OPTIONAL
*"----------------------------------------------------------------------

subrc = 0.

perform bdc_nodata      using NODATA.

perform open_group      using GROUP USER KEEP HOLDDATE CTU.

perform bdc_dynpro      using 'SAPMDMEE_ABA' '0200'.
perform bdc_field       using 'BDC_CURSOR'
                              'DMEE_HEAD_ABA-TREE_ID'.
perform bdc_field       using 'BDC_OKCODE'
                              '=DOWNLOAD'.
perform bdc_field       using 'DMEE_HEAD_ABA-TREE_TYPE'
                              IM_TREE_TYPE.
perform bdc_field       using 'DMEE_HEAD_ABA-TREE_ID'
                              IM_TREE_ID.
perform bdc_dynpro      using 'SAPLSPO2' '0100'.
perform bdc_field       using 'BDC_OKCODE'
                              '=OPT1'.
perform bdc_dynpro      using 'SAPLDMEE1_ABA' '0241'.
perform bdc_field       using 'BDC_CURSOR'
                              'G_XMLFILENAME'.
perform bdc_field       using 'BDC_OKCODE'
                              '=ENTER'.
perform bdc_field       using 'DMEE_HEAD_ABA-TREE_TYPE'
                              IM_TREE_TYPE.
perform bdc_field       using 'DMEE_HEAD_ABA-TREE_ID'
                              IM_TREE_ID.
perform bdc_field       using 'G_XMLFILENAME'
                              IM_XMLFILENAME.
perform bdc_dynpro      using 'SAPMDMEE_ABA' '0200'.
perform bdc_field       using 'BDC_CURSOR'
                              'DMEE_HEAD_ABA-TREE_TYPE'.
perform bdc_field       using 'BDC_OKCODE'
                              '=BACK'.
perform bdc_field       using 'DMEE_HEAD_ABA-TREE_TYPE'
                              IM_TREE_TYPE.
perform bdc_field       using 'DMEE_HEAD_ABA-TREE_ID'
                              IM_TREE_ID.
perform bdc_transaction tables messtab
using                         'DMEE'
                              CTU
                              MODE
                              UPDATE.
if sy-subrc <> 0.
  subrc = sy-subrc.
  exit.
endif.

perform close_group using     CTU.





ENDFUNCTION.
INCLUDE BDCRECXY .
