class ZCL_ZOKT_MDU_EEW_BP definition
  public
  final
  create public .

public section.

  interfaces IF_BUPA_MASSUPDATE .

  class-methods MAP_DATE2TMSTMP_INTERVAL
    importing
      !IV_FIELD_SOURCE type FIELDNAME
      !IV_FIELD_TARGET type FIELDNAME
    changing
      !CS_SELOPT type RSDSSELOPT .
protected section.
private section.

  class-data GT_BUT_EEW type ZZOKTMDUTABTYP .
  class-data GS_FLD_UPD type ZBSTC0000V3TENSX .

  class-methods REFRESH_GLOBAL_DATA .
ENDCLASS.



CLASS ZCL_ZOKT_MDU_EEW_BP IMPLEMENTATION.


method IF_BUPA_MASSUPDATE~CHANGE_DATA.
  endmethod.


method IF_BUPA_MASSUPDATE~CHANGE_OBJECT.


  data:
     lr_request      type ref to   cl_bupa_navigation_request,
     lr_options      type ref to   cl_bupa_dialog_joel_options.


  data:
    lv_activity     type          bus_dialog-activity,
    lv_partner      type          bu_partner.

  field-symbols:
    <lv_any>        type any.


  create object lr_request.
  create object lr_options.

  assign component cl_bupa_const_mass=>gc_partner
         of structure record to <lv_any>.

  if sy-subrc = 0.

    lv_partner = <lv_any>.

    lr_request->set_partner_number( lv_partner ).

    lv_activity = cl_bupa_navigation_request=>gc_activity_change.

    lr_request->set_bupa_activity( lv_activity ).

    call method cl_bupa_dialog_joel=>start_with_navigation
      exporting
        iv_request = lr_request
        iv_options = lr_options
      exceptions
        others     = 1.

  endif.

  endmethod.


method IF_BUPA_MASSUPDATE~CHANGE_SELECTION.

  constants:
     lc_change    type mass_selection-key_sel value 'CHAN',
     lc_str       type tablename value
                       'ZZOKTMDUSTR'.

  field-symbols:
    <ls_selection>       type mass_selection,
    <ls_sel_range>       type rsds_range,
    <ls_frange>          type rsds_frange,
    <ls_selopt>          type rsdsselopt.

****select item of change mode
  read table selection
       assigning <ls_selection>
       with key key_sel = lc_change.

  check sy-subrc is initial.

  read table <ls_selection>-sel_range
       assigning <ls_sel_range> with key  tablename = lc_str."#EC


  check sy-subrc is initial.

  loop at <ls_sel_range>-frange_t
             assigning <ls_frange>.

    case <ls_frange>-fieldname.
      when  'SCRDATE_TO'.
        <ls_frange>-fieldname = 'DATE_TO'.
        loop at <ls_frange>-selopt_t
                 assigning <ls_selopt>.
          call method map_date2tmstmp_interval
            exporting
              iv_field_source = 'DATE_TO'
              iv_field_target = 'SCRDATE_TO'
            changing
              cs_selopt       = <ls_selopt>.
        endloop.
      when  'SCRDATE_FROM'.
        <ls_frange>-fieldname = 'DATE_FROM'.
        loop at <ls_frange>-selopt_t
                   assigning <ls_selopt>.
          call method map_date2tmstmp_interval
            exporting
              iv_field_source = 'DATE_FROM'
              iv_field_target = 'SCRDATE_FROM'
            changing
              cs_selopt       = <ls_selopt>.
        endloop.
    endcase.
  endloop.



  endmethod.


method IF_BUPA_MASSUPDATE~CHECK_DATA.
  endmethod.


method IF_BUPA_MASSUPDATE~DESCR_TEXT.


  data:
    ls_fields                like line of d_fields,
    ls_bus000flds            type bus_mass_description.

  constants:
    lc_struc_descr type dcobjdef-name value 'BUS_MASS_DESCRIPTION',
    lc_descrip               type name_feld       value 'DESCRIP'.

  field-symbols:
    <fs1>                    type any,
    <lv_partner>             type bu_partner.


  ls_fields-name   = lc_descrip.
  append ls_fields to d_fields.
  d_struct         = lc_struc_descr.

  loop at selection
         assigning <fs1>.
    assign component cl_bupa_const_mass=>gc_partner
       of structure <fs1> to <lv_partner>.

    call function 'BUP_PARTNER_DESCRIPTION_GET'
      exporting
        i_partner         = <lv_partner>
      importing
        e_description     = ls_bus000flds-descrip
      exceptions
        partner_not_found = 1
        wrong_parameters  = 2
        internal_error    = 3
        others            = 4.

    if not sy-subrc is initial.
      clear: description,
             d_struct,
             d_fields.
      exit.
    endif.

    ls_bus000flds-partner = <lv_partner>.
    append ls_bus000flds to description.

  endloop.

  endmethod.


method IF_BUPA_MASSUPDATE~DISPLAY_OBJECT.
 data:
     lr_request      type ref to   cl_bupa_navigation_request,
     lr_options      type ref to   cl_bupa_dialog_joel_options.


  data:
    lv_activity     type          bus_dialog-activity,
    lv_partner      type          bu_partner.

  field-symbols:
    <lv_any>        type any.

  create object lr_request.
  create object lr_options.

  assign component cl_bupa_const_mass=>gc_partner
         of structure record to <lv_any>.

  if sy-subrc = 0.

    lv_partner = <lv_any>.

    lr_request->set_partner_number( lv_partner ).

    lv_activity = cl_bupa_navigation_request=>gc_activity_display.

    lr_request->set_bupa_activity( lv_activity ).

    call method cl_bupa_dialog_joel=>start_with_navigation
      exporting
        iv_request = lr_request
        iv_options = lr_options
      exceptions
        others     = 1.

  endif.

  endmethod.


method IF_BUPA_MASSUPDATE~INITIAL_CHECK.
  endmethod.


method IF_BUPA_MASSUPDATE~LIMIT_FIELDS.
  endmethod.


method IF_BUPA_MASSUPDATE~LIMIT_OUTPUT.
  endmethod.


method IF_BUPA_MASSUPDATE~LIMIT_SEL_FIELDS.
  endmethod.


method IF_BUPA_MASSUPDATE~MARK_FIELDS.
  endmethod.


method IF_BUPA_MASSUPDATE~MSG_SHOW_DETAIL.
  endmethod.


method IF_BUPA_MASSUPDATE~NEW_SEGMENTS_DIALOG.
  endmethod.


method IF_BUPA_MASSUPDATE~PREPARE_UPDATE.
 data :
      ls_massgenchange      like line of  it_massgenchange,
      lv_partner            type          bu_partner,
      lt_partner            type table of bu_partner,
      ls_fieldnames         type          ddobjname,
      lv_fieldname          type          ddobjname,
      lv_str                type          string,
      lv_message            type          c.               "#EC NEEDED
 field-symbols:
     <lv_any>               type          any,
     <ls_any>               type          any,
     <lt_any>               type          any table,
     <ls_seldata>           type          mass_wa_tabdata,
     <lt_upd>               type          any.
 constants:
      lc_str                type tablename
                            value 'ZZOKTMDUSTR'.

****=====*****
call method
   zcl_zokt_mdu_eew_bp=>refresh_global_data.

****=====*****
*****=====*****
**READ the selected table*

 loop at it_seldata
      assigning <ls_seldata>
      where not fieldnames is initial.
   case: <ls_seldata>-tabname-name_db.
     when  lc_str.
*****API UPDATE STRUCTURE FOR API IF FILLED AND IT WILL BE PASSED
       loop at <ls_seldata>-fieldnames into lv_fieldname.

         concatenate 'GS_FLD_UPD-' lv_fieldname into lv_str.
         assign (lv_str) to <lt_upd>.
         <lt_upd> = cl_bupa_const_mass=>gc_x.
       endloop.
   endcase.
 endloop.

*****=====*****

*****=====*****
*****Read the changed data*
 loop at it_massgenchange into ls_massgenchange
               where name = lc_str.
   assign ls_massgenchange-data->* to <lt_any>.
   loop at <lt_any> assigning <ls_any>.
     assign component 'PARTNER' of structure <ls_any> to <lv_any>.
     lv_partner = <lv_any>.
     append lv_partner to lt_partner.
     append <ls_any>   to gt_but_eew.
   endloop.
 endloop.
*****=====*****

*****=====*****

 if not lt_partner[] is initial.
   sort lt_partner.
   delete adjacent duplicates from lt_partner.
 endif.
 et_partner[] = lt_partner[].
****=====*****
  endmethod.


method IF_BUPA_MASSUPDATE~UPDATE.

 data: lt_partner         type table of bu_partner,
       ls_apistr          type zbstc0000v3tensa,
       et_return          type table of bapiret2,
       ls_return          type bapiret2,
       ls_msg             type mass_msg,
       lv_partner         type          bu_partner.
 field-symbols:
       <ls_table>         type
                          zzoktmdustr.

****=====*****


*Moving global data to local data structure*
 lt_partner[] = it_partner[].

****=====*****

 loop at lt_partner into lv_partner.
   loop at gt_but_eew assigning <ls_table>
                  where partner = lv_partner.

       clear ls_apistr.
move-corresponding <ls_table> to ls_apistr.
     call function 'ZZOKT_BUPA_DTL_CHANGE'
       exporting
         iv_partner      = lv_partner
       iv_zzbkitem        = <ls_table>-zzbkitem
*      iv_valid_date   = <ls_table>-SCRDATE_TO
         is_zbstc0000v3tensa    = ls_apistr
         is_zbstc0000v3tensx    = gs_fld_upd
         iv_x_save       = cl_bupa_const_mass=>gc_x
       tables
         et_return       = et_return.



     loop at et_return into ls_return
           where type = 'E' or type = 'A'.
       ls_msg-objkey = lv_partner.
       ls_msg-msgid  = ls_return-id.
       ls_msg-msgty  = ls_return-type.
       ls_msg-msgno  = ls_return-number.
       ls_msg-msgv1  = ls_return-message_v1.
       ls_msg-msgv2  = ls_return-message_v2.
       ls_msg-msgv3  = ls_return-message_v3.
       ls_msg-msgv4  = ls_return-message_v4.
       append ls_msg to et_msg.
     endloop.
   endloop.
 endloop.

  endmethod.


method MAP_DATE2TMSTMP_INTERVAL.

  constants:
        lc_timezone  type ttzz-tzone value 'UTC',
        lc_timezero  type t value '000000',
        lc_timemax   type t value '235959',
        lc_datestart type d value '00010101'.

  data:
    lv_timestamp  type bu_bp_valid_from.


  if     cs_selopt-high is initial and
     not cs_selopt-low  is initial.
****single value end range date
    convert date cs_selopt-low time lc_timemax
            into time stamp lv_timestamp
            time zone lc_timezone.

    cs_selopt-high = lv_timestamp.
***start range date
    convert date cs_selopt-low time lc_timezero
            into time stamp lv_timestamp
            time zone lc_timezone.

    cs_selopt-low    = lv_timestamp.
    cs_selopt-option = 'BT'.
  else.

***start range date
    if not cs_selopt-low is initial.
      convert date cs_selopt-low time lc_timezero
              into time stamp lv_timestamp
              time zone lc_timezone.
    else.
      convert date lc_datestart time lc_timezero
              into time stamp lv_timestamp
              time zone lc_timezone.
    endif.
    cs_selopt-low = lv_timestamp.

***end range date
    convert date cs_selopt-high time lc_timemax
            into time stamp lv_timestamp
            time zone lc_timezone.

    cs_selopt-high = lv_timestamp.
  endif.
  endmethod.


method REFRESH_GLOBAL_DATA.

****=====*****
*Clearing and Refreshing tables.

clear gt_but_eew.
clear gs_fld_upd.
refresh gt_but_eew.

****=====*****
  endmethod.
ENDCLASS.
