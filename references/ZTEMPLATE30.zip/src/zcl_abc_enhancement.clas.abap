class ZCL_ABC_ENHANCEMENT definition
  public
  final
  create public .

public section.

  class-methods CONVERT_DEBIT_AND_CREDIT_FLAG
    importing
      !IM_DIRECTION type CHAR01
    returning
      value(RE_SAP_VALUE) type SHKZG .
  class-methods SET_ABCFLAG
    importing
      !IM_S_FPAYH type FPAYH
    returning
      value(RE_VALUE) type CHAR01 .
  class-methods GET_ACCNO_PROV
    importing
      !IM_S_FPAYH type FPAYH optional
      !IM_S_FPAYHX type FPAYHX optional
    returning
      value(PROV) type CHAR2 .
  class-methods GET_ABC_ACCNO
    importing
      !IM_S_FPAYH type FPAYH optional
      !IM_S_FPAYHX type FPAYHX optional
    returning
      value(ACCNO) type CHAR35 .
  class-methods GET_ABC_CURCODE
    importing
      !IM_S_FPAYH type FPAYH
    returning
      value(CURCODE) type ZTR_ABC_CODE .
protected section.
private section.
ENDCLASS.



CLASS ZCL_ABC_ENHANCEMENT IMPLEMENTATION.


METHOD CONVERT_DEBIT_AND_CREDIT_FLAG.

    CASE im_direction.
      WHEN '1'.
*        来账
        re_sap_value = 'S'.
      WHEN '2'.
*        往账
        re_sap_value = 'H'.
    ENDCASE.



  ENDMETHOD.


METHOD get_abc_accno.
*    1)农行的公司账号：
*  我行公司账号由17位组成AA-BBBBCCJJSSSSSSD。
*  当账号是付款账号时，交易报文中的字段值是<DbProv>AA</DbProv><DbAccNo>BBBBCCJJSSSSSSD</DbAccNo></DbAccNo><DbLogAccNo>借方逻辑账号</DbLogAccNo>
*  当账号是收款账号时，交易报文中的字段值是<CrProv>AA</CrProv><CrAccNo>BBBBCCJJSSSSSSD</CrAccNo><CrLogAccNo>贷方逻辑账号</CrLogAccNo>
*  <DbLogAccNo>或<CrLogAccNo>的值是多级账簿的值，是10位数字。如果企业没有多级账簿，此值为空。
*  2)农行的个人账号：
*  农行的个人账号分为卡账号和存折类账号。
*  卡帐号由16位或19位组成，交易报文中的字段值是<CrProv></CrProv><CrAccNo>16位（或19位）卡账号</CrAccNo>，<CrProv>字段是空值。
*  农行的存折类账号由17位组成AA-BBBBCCJJSSSSSSD，交易报文中的字段值是<CrProv>AA</CrProv><CrAccNo>BBBBCCJJSSSSSSD</CrAccNo>。
    DATA(an) = im_s_fpayhx-ref02.
    IF an IS INITIAL.
      DATA(ah) = im_s_fpayh-zbnkn.
      CONDENSE ah NO-GAPS.
      DATA(lt1) = strlen( ah ).

      IF lt1 = 17 AND im_s_fpayh-laufi = 'ABC'.

        accno = ah+2(15).
      ELSE.
        accno = ah.
      ENDIF.
    ELSE.
      CONDENSE an NO-GAPS.
      DATA(lt) = strlen( an ).

      IF lt = 17.

        accno = an+2(15).
      ELSE.
        accno = an.
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD get_abc_curcode.
    CLEAR:curcode.
    SELECT SINGLE curcode
      INTO curcode
      FROM ztrt_abc_cur
      WHERE cur = im_s_fpayh-WAERS.


  ENDMETHOD.


METHOD get_accno_prov.
*  1)农行的公司账号：
*  我行公司账号由17位组成AA-BBBBCCJJSSSSSSD。
*  当账号是付款账号时，交易报文中的字段值是<DbProv>AA</DbProv><DbAccNo>BBBBCCJJSSSSSSD</DbAccNo></DbAccNo><DbLogAccNo>借方逻辑账号</DbLogAccNo>
*  当账号是收款账号时，交易报文中的字段值是<CrProv>AA</CrProv><CrAccNo>BBBBCCJJSSSSSSD</CrAccNo><CrLogAccNo>贷方逻辑账号</CrLogAccNo>
*  <DbLogAccNo>或<CrLogAccNo>的值是多级账簿的值，是10位数字。如果企业没有多级账簿，此值为空。
*  2)农行的个人账号：
*  农行的个人账号分为卡账号和存折类账号。
*  卡帐号由16位或19位组成，交易报文中的字段值是<CrProv></CrProv><CrAccNo>16位（或19位）卡账号</CrAccNo>，<CrProv>字段是空值。
*  农行的存折类账号由17位组成AA-BBBBCCJJSSSSSSD，交易报文中的字段值是<CrProv>AA</CrProv><CrAccNo>BBBBCCJJSSSSSSD</CrAccNo>。
    DATA(an) = im_s_fpayhx-ref02.
    IF an IS INITIAL.
      DATA(ah) = im_s_fpayh-zbnkn.
      CONDENSE ah NO-GAPS.
      DATA(lt1) = strlen( ah ).

      IF lt1 = 17 AND im_s_fpayh-laufi = 'ABC'.
        prov = ah+0(2).
    "    accno1 = ah+2(15).
     " ELSE.
     "   accno1 = ah.
      ENDIF.
    ELSE.
      CONDENSE an NO-GAPS.
      DATA(lt) = strlen( an ).

      IF lt = 17.
        prov = an+0(2).
    "    accno1 = an+2(15).
    "  ELSE.
      "  accno1 = an.
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD SET_ABCFLAG.
    IF zcl_bank_cnaps_code=>if_same_bank(
                              EXPORTING
                                im_code1 = im_s_fpayh-zbnky
                                im_code2 = im_s_fpayh-bnkl1 ) = 'X'.
*      收付款方都是农行行账户
      re_value = '0'.
    ELSE.
*      付款方不是农行账户
      re_value = '1'.
    ENDIF.
  ENDMETHOD.
ENDCLASS.
