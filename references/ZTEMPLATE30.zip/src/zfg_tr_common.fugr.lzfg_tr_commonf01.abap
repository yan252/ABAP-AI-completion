**----------------------------------------------------------------------*
****INCLUDE LZFG_TR_COMMONF01.
**----------------------------------------------------------------------*
**&---------------------------------------------------------------------*
**&      Form  FRM_PRO_DO_A
**&---------------------------------------------------------------------*
**       text
**----------------------------------------------------------------------*
**      <--P_ET_TABLE  text
**----------------------------------------------------------------------*
*FORM frm_pro_do_a  TABLES ct_table STRUCTURE ztrs0100_3.
*
*  DATA: BEGIN OF ls_prctr,
*          vbeln TYPE vbap-vbeln,
*          prctr TYPE vbap-prctr,
*          netwr TYPE vbap-netwr,
*        END OF ls_prctr.
*
*  DATA: BEGIN OF ls_bwtar,
*          vbeln   TYPE vbap-vbeln,
*          bwtar   TYPE vbap-bwtar,
*          netwr   TYPE vbap-netwr,
*          matnr   TYPE vbap-matnr,
*          bklas   TYPE mbew-bklas,
*          newbw   TYPE zrtrt00160-newbw,
*          zfylxmc TYPE zrtrt00160-zfylxmc,
*        END OF ls_bwtar.
*
*  DATA ls_prctr_c LIKE ls_prctr.
*  DATA ls_bwtar_c LIKE ls_bwtar.
*  DATA lt_prctr   LIKE TABLE OF ls_prctr.
*  DATA lt_prctr_c LIKE TABLE OF ls_prctr.
*  DATA lt_bwtar   LIKE TABLE OF ls_bwtar.
*  DATA lt_bwtar_c LIKE TABLE OF ls_bwtar.
*  DATA lt_table_a TYPE TABLE OF ztrs0100_3.
*  DATA lt_table_b TYPE TABLE OF ztrs0100_3.
*
*
**  到VBAP 销售凭证:项目数据表里的NETWR订单项目的“凭证货币净值金额”按利润中心字段计算合计，取金额值最大的利润中心字段值；
**  显示利润中心编码及描述
**
**  到VBAP 销售凭证:项目数据表里的NETWR订单项目的“凭证货币净值金额”按评估类型字段计算合计，
**  取金额值最大的BWTAR 评估类型字段值；再依据该值并到自定义表ZRTRT00160公司级评估类与费用类型对照表中查找BKLAS
**  评估类型对应的NEWBW 费用类型值作为现金流量代码值；显示现金流量代码及描述
*
*  LOOP AT ct_table INTO DATA(ls_table).
*    SELECT SINGLE jelx INTO @DATA(lv_jelx) FROM zotct00460 WHERE vbeln = @ls_table-vbeln.
*    IF lv_jelx = 'A'.  "金额类型 A销售订单
*      APPEND ls_table TO lt_table_a.
*    ELSE.             "金额类型 B交货单
*      APPEND ls_table TO lt_table_b.
*    ENDIF.
*  ENDLOOP.
*
*  IF ct_table[] IS NOT INITIAL.
*    IF lt_table_a[] IS NOT INITIAL.
*
*      SELECT * INTO CORRESPONDING FIELDS OF TABLE lt_prctr
*        FROM vbap FOR ALL ENTRIES IN lt_table_a
*       WHERE vbeln = lt_table_a-vbeln.
*
*      SELECT * INTO CORRESPONDING FIELDS OF TABLE lt_bwtar
*        FROM vbap FOR ALL ENTRIES IN lt_table_a
*       WHERE vbeln = lt_table_a-vbeln.
*
*    ENDIF.
*
*    IF lt_table_b[] IS NOT INITIAL.
*
*      SELECT * APPENDING CORRESPONDING FIELDS OF TABLE lt_prctr
*        FROM lips FOR ALL ENTRIES IN lt_table_b
*       WHERE vbeln = lt_table_b-vbeln.
*
*      SELECT * APPENDING CORRESPONDING FIELDS OF TABLE lt_bwtar
*        FROM lips FOR ALL ENTRIES IN lt_table_b
*       WHERE vbeln = lt_table_b-vbeln.
*
*    ENDIF.
*
*    SORT lt_prctr BY vbeln prctr.
*    SORT lt_bwtar BY vbeln bwtar.
*
*    LOOP AT lt_prctr INTO ls_prctr.
*      ls_prctr_c = ls_prctr.
*      AT END OF prctr.
*        SUM .
*        ls_prctr-vbeln = ls_prctr_c-vbeln.
*        ls_prctr-prctr = ls_prctr_c-prctr.
*        APPEND ls_prctr TO lt_prctr_c.
*      ENDAT.
*    ENDLOOP.
*
*
*    LOOP AT lt_bwtar INTO ls_bwtar.
*      ls_bwtar_c = ls_bwtar.
*
*      AT END OF bwtar.
*        SUM .
*        ls_bwtar-vbeln = ls_bwtar_c-vbeln.
*        ls_bwtar-bwtar = ls_bwtar_c-bwtar.
*        ls_bwtar-matnr = ls_bwtar_c-matnr.
*        CLEAR:ls_bwtar-newbw,ls_bwtar-zfylxmc.
*        APPEND ls_bwtar TO lt_bwtar_c.
*      ENDAT.
*    ENDLOOP.
*
*    SORT lt_prctr_c  BY vbeln ASCENDING  netwr DESCENDING.
*    SORT lt_bwtar_c BY vbeln ASCENDING  netwr DESCENDING.
*
*    DELETE ADJACENT DUPLICATES FROM lt_prctr_c COMPARING vbeln.
*    DELETE ADJACENT DUPLICATES FROM lt_bwtar_c COMPARING vbeln.
*
*    LOOP AT lt_bwtar_c ASSIGNING FIELD-SYMBOL(<lf_bwtar1>).
*      IF <lf_bwtar1>-matnr IS NOT INITIAL.
*        SELECT SINGLE bklas INTO <lf_bwtar1>-bklas
*          FROM mbew
*         WHERE matnr = <lf_bwtar1>-matnr.
*      ENDIF.
*    ENDLOOP.
*
*    LOOP AT lt_bwtar_c ASSIGNING FIELD-SYMBOL(<lf_bwtar>).
*      IF <lf_bwtar>-bwtar IS NOT INITIAL.
*        SELECT SINGLE newbw zfylxmc INTO ( <lf_bwtar>-newbw,<lf_bwtar>-zfylxmc )
*          FROM zrtrt00160
*         WHERE bklas = <lf_bwtar>-bklas
*           AND koart = 'S'.
*      ENDIF.
*    ENDLOOP.
*  ENDIF.
*
*  CLEAR: ls_prctr,ls_bwtar.
*  LOOP AT  ct_table ASSIGNING FIELD-SYMBOL(<ls_data>) .
*    READ TABLE lt_prctr_c INTO ls_prctr WITH KEY vbeln = <ls_data>-vbeln.
*    IF sy-subrc = 0.
*      <ls_data>-prctr = ls_prctr-prctr.    "利润中心
*      <ls_data>-prctrt = zcl_tr_getdesc=>get_prctr_desc( iv_prctr = <ls_data>-prctr ).
*      "利润中心描述
*    ENDIF.
*
*    READ TABLE lt_bwtar_c INTO ls_bwtar WITH KEY vbeln = <ls_data>-vbeln.
*    IF sy-subrc = 0.
*      <ls_data>-newbw  = ls_bwtar-newbw.   "现金流量代码
*      <ls_data>-newbwt = ls_bwtar-zfylxmc. "描述
*    ENDIF.
**   付款条件
*    <ls_data>-zfktkt = zcl_tr_getdesc=>get_fktk_desc( iv_zterm = <ls_data>-zterm ).
**   付款方式
*    <ls_data>-zfkfst = zcl_tr_getdesc=>get_fkfs_desc(
*                       iv_bukrs = <ls_data>-bukrs
*                       iv_zlsch = |{ <ls_data>-zlsch }|
*                   ).
**   客户描述
*    <ls_data>-kunnrt = zcl_tr_getdesc=>get_kunnr_desc( iv_kunnr = <ls_data>-kunnr ).
**   本次收款金额
*    <ls_data>-zbcskje = <ls_data>-wrbtr.
**   本次收款金额可编辑
*    <ls_data>-read_only = 'X'.
*
**   去销售组织和分销渠道
*    SELECT SINGLE  vkorg vtweg INTO ( <ls_data>-vkorg, <ls_data>-vtweg )
*      FROM vbak
*     WHERE vbeln = <ls_data>-vbeln.
*
*    <ls_data>-zddskje = COND #( WHEN <ls_data>-wrbtr - <ls_data>-zsjskje GT 0 THEN <ls_data>-wrbtr - <ls_data>-zsjskje
*                                WHEN <ls_data>-wrbtr - <ls_data>-zsjskje LE 0 THEN 0 ELSE <ls_data>-zddskje ).
*
*  ENDLOOP.
*ENDFORM.
**----------------------------------------------------------------------*
****INCLUDE LZFG_TR_COMMONF01.
**----------------------------------------------------------------------*
**&---------------------------------------------------------------------*
**&      Form  FRM_PRO_DO_A
**&---------------------------------------------------------------------*
**       text
**----------------------------------------------------------------------*
**      <--P_ET_TABLE  text
**----------------------------------------------------------------------*
*FORM frm_pro_do_b  TABLES ct_table STRUCTURE ztrs0100_3.
*  DATA ls_bsid    TYPE  bsid.
*  DATA ls_due_inp TYPE  faede.
*  DATA ls_due_oup TYPE  faede.
*  DATA ls_item    TYPE  rfposxext.
*  DATA: gd_icon_before TYPE ico_due       VALUE icon_resubmission,
*        gd_icon_dueday TYPE ico_due       VALUE icon_alarm,
*        gd_icon_past   TYPE ico_due       VALUE icon_alert.
*
*  PERFORM frm_icon_create USING 'ICON_RESUBMISSION' TEXT-008 gd_icon_before.
*  PERFORM frm_icon_create USING 'ICON_ALARM'        TEXT-009 gd_icon_dueday.
*  PERFORM frm_icon_create USING '~ICON_ALERT'        TEXT-010 gd_icon_past.
*
*
*  LOOP AT  ct_table ASSIGNING FIELD-SYMBOL(<ls_data>) .
*
*    <ls_data>-prctrt = zcl_tr_getdesc=>get_prctr_desc( iv_prctr = <ls_data>-prctr ).
*    "利润中心描述
*
**    read table lt_bwtar_c into ls_bwtar with key vbeln = <ls_data>-vbeln.
**    if sy-subrc = 0.
**      <ls_data>-newbw  = ls_bwtar-newbw.   "现金流量代码
**      <ls_data>-newbwt = ls_bwtar-zfylxmc. "描述
**    endif.
*
**   去到期日
*    SELECT SINGLE zfbdt INTO <ls_data>-betdt
*      FROM ztrcdsbsid
*     WHERE bukrs = <ls_data>-bukrs
*       AND belnr = <ls_data>-belnr
*       AND gjahr = <ls_data>-gjahr
*       AND buzei = <ls_data>-buzei.
*
**   逾期标识逻辑
*    SELECT SINGLE * INTO CORRESPONDING FIELDS OF ls_item
*      FROM bsid
*     WHERE bukrs = <ls_data>-bukrs
*       AND belnr = <ls_data>-belnr
*       AND gjahr = <ls_data>-gjahr
*       AND buzei = <ls_data>-buzei.
*
*    ls_item-koart = 'D'.
*
*    MOVE-CORRESPONDING ls_item TO ls_due_inp.
*    IF NOT ls_due_inp-zfbdt IS INITIAL.
*      CALL FUNCTION 'DETERMINE_DUE_DATE'
*        EXPORTING
*          i_faede    = ls_due_inp
*          i_gl_faede = 'X'
*        IMPORTING
*          e_faede    = ls_due_oup
*        EXCEPTIONS
*          OTHERS     = 1.
*      IF sy-subrc = 0.
*        ls_item-faedt = ls_due_oup-netdt.
*        ls_item-zaldt = ls_due_oup-sk1dt.
*      ENDIF.
*
*      CALL FUNCTION 'ITEM_OVERDUE_DAYS'
*        EXPORTING
*          key_date          = sy-datum
*          pay_date          = ls_item-zaldt
*          due_date          = ls_item-faedt
*          clear_date        = ls_item-augdt
*        IMPORTING
*          over_skonto1_days = ls_item-verz1
*          overdue_days      = ls_item-verzn.
*
*      IF ls_item-augdt IS INITIAL OR ls_item-augdt = '00000000' OR
*         ls_item-augdt > sy-datum.
*        IF ls_item-verzn < 0.
*          <ls_data>-ico_due1 = gd_icon_before.
*          <ls_data>-yq_flag = 10. "未逾期
*        ELSEIF ls_item-verzn = 0.
*          <ls_data>-ico_due1 = gd_icon_dueday.
*          <ls_data>-yq_flag = 20. "到期
*        ELSE.
*          <ls_data>-ico_due1 = gd_icon_past.
*          <ls_data>-yq_flag = 30. "逾期
*        ENDIF.
*      ENDIF.
*    ENDIF.
*
*
**   现金流量代码描述
*    <ls_data>-newbwt = zcl_tr_getdesc=>get_rstgr_desc(
*                        iv_bukrs = <ls_data>-bukrs
*                        iv_rstgr = |{ <ls_data>-newbw }|
*                    ).
**   金额(如为‘H’为贷方，为负数)
*    IF <ls_data>-shkzg = 'H' .
*      <ls_data>-wrbtr = <ls_data>-wrbtr * -1.
*      <ls_data>-yq_flag = 10.
*    ENDIF.
*
**   本次收款金额
*    IF <ls_data>-wrbtr <= 0.
**      <ls_data>-zbcskje = 0.
*      <ls_data>-read_only = 'X'.
*      <ls_data>-zbcskje = <ls_data>-wrbtr.
*    ELSE.
*      <ls_data>-zbcskje = <ls_data>-wrbtr.
*    ENDIF.
*
**   付款条件
*    <ls_data>-zfktkt = zcl_tr_getdesc=>get_fktk_desc( iv_zterm = <ls_data>-zterm ).
**   付款方式
*    <ls_data>-zfkfst = zcl_tr_getdesc=>get_fkfs_desc(
*                       iv_bukrs = <ls_data>-bukrs
*                       iv_zlsch = |{ <ls_data>-zlsch }|
*                   ).
*
**   客户描述
*    <ls_data>-kunnrt = zcl_tr_getdesc=>get_kunnr_desc( iv_kunnr = <ls_data>-kunnr ).
*
**   去销售组织和分销渠道
**================================begin of 201903=======================================
**    select single  vkorg vtweg into ( <ls_data>-vkorg, <ls_data>-vtweg )
**      from vbak
**     where vbeln = <ls_data>-vbeln.
**    if sy-subrc <> 0.
**      select single  vkorg vtweg into ( <ls_data>-vkorg, <ls_data>-vtweg )
**        from vbak
**       where vbeln = <ls_data>-vbel2.
**    endif.
*
*    SELECT SINGLE vkorg vtweg  INTO ( <ls_data>-vkorg, <ls_data>-vtweg )
*      FROM vbrk
*     WHERE vbeln = <ls_data>-vbelk.
*
**================================end   of 201903=======================================
*  ENDLOOP.
*
*
*ENDFORM.
*
**----------------------------------------------------------------------*
****INCLUDE LZFG_TR_COMMONF01.
**----------------------------------------------------------------------*
**&---------------------------------------------------------------------*
**&      Form  FRM_PRO_DO_C
**&---------------------------------------------------------------------*
**       text
**----------------------------------------------------------------------*
**      <--P_ET_TABLE  text
**----------------------------------------------------------------------*
*FORM frm_pro_do_c  TABLES ct_table STRUCTURE ztrs0100_3.
*
*  LOOP AT  ct_table ASSIGNING FIELD-SYMBOL(<ls_data>) .
*
*    <ls_data>-prctrt = zcl_tr_getdesc=>get_prctr_desc( iv_prctr = <ls_data>-prctr ).
*    "利润中心描述
*
**    read table lt_bwtar_c into ls_bwtar with key vbeln = <ls_data>-vbeln.
**    if sy-subrc = 0.
**      <ls_data>-newbw  = ls_bwtar-newbw.   "现金流量代码
**      <ls_data>-newbwt = ls_bwtar-zfylxmc. "描述
**    endif.
**   现金流量代码描述
*    <ls_data>-newbwt = zcl_tr_getdesc=>get_rstgr_desc(
*                        iv_bukrs = <ls_data>-bukrs
*                        iv_rstgr = |{ <ls_data>-newbw }|
*                    ).
**   付款方式
*    <ls_data>-zfkfst = zcl_tr_getdesc=>get_fkfs_desc(
*                       iv_bukrs = <ls_data>-bukrs
*                       iv_zlsch = |{ <ls_data>-zlsch }|
*                   ).
*
**   成本中心
*    SELECT SINGLE  kostl ktext INTO ( <ls_data>-kostl,<ls_data>-ktext ) FROM ztrt0111
*      WHERE docno    = <ls_data>-djskdh
*        AND itemno   = <ls_data>-item_ywdj.
*
*    IF <ls_data>-zfmark = '10'.    "客户
**   客户描述
*      <ls_data>-kunnrt = zcl_tr_getdesc=>get_kunnr_desc( iv_kunnr = <ls_data>-kunnr ).
*    ELSEIF <ls_data>-zfmark = '20'."供应商.
**　　供应商描述
*      <ls_data>-kunnrt = zcl_tr_getdesc=>get_lifnr_desc( iv_lifnr = <ls_data>-kunnr ).
*    ELSEIF <ls_data>-zfmark = '99'."其他.
**    BP描述
*      <ls_data>-zsknam = zcl_tr_getdesc=>get_bp_name( iv_bp = |{ <ls_data>-zskno }| ).
*    ENDIF.
**    call function 'CONVERSION_EXIT_ALPHA_OUTPUT'
**      exporting
**        input  = <ls_data>-kunnr
**      importing
**        output = <ls_data>-kunnr.
*
*    CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
*      EXPORTING
*        input  = <ls_data>-kunnr
*      IMPORTING
*        output = <ls_data>-kunnr.
*
**   本次收款金额
*    <ls_data>-zbcskje = <ls_data>-wrbtr.
*
*    <ls_data>-read_only = 'X'.
*
*  ENDLOOP.
*ENDFORM.
**&---------------------------------------------------------------------*
**&      Form  FRM_PRO_DO_E_T
**&---------------------------------------------------------------------*
**       text
**----------------------------------------------------------------------*
**      -->P_ET_TABLE  text
**----------------------------------------------------------------------*
*FORM frm_pro_do_e_t  TABLES   ct_table STRUCTURE ztrs0100_4
*                               pt_bank STRUCTURE ztrs_bank_item.
*
*  DATA ls_table TYPE ztrs0100_4.
*  LOOP AT  pt_bank ASSIGNING FIELD-SYMBOL(<ls_data>) .
*
*    MOVE-CORRESPONDING <ls_data> TO ls_table.
*    ls_table-zbkfkhht = <ls_data>-zbkdkhht.
*    ls_table-zbkfkr = <ls_data>-zbkdkr.
*    ls_table-zbkfkt = <ls_data>-zbkdkt.
**    select single text1 bankl into ( ls_table-text1, ls_table-bankl )
**      from ztrt0013
**     where hbkid = <ls_data>-hbkid
**       and hktid = <ls_data>-hktid
**       and bukrs = <ls_data>-bukrs.
*
*    APPEND ls_table TO ct_table.
*    CLEAR ls_table.
*  ENDLOOP.
*
*ENDFORM.
**&---------------------------------------------------------------------*
**&      Form  FRM_PRO_DO_E
**&---------------------------------------------------------------------*
**       text
**----------------------------------------------------------------------*
**      -->P_LT_LIST  text
**      -->P_ET_TABLE  text
**----------------------------------------------------------------------*
*FORM frm_pro_do_e   TABLES  pt_list STRUCTURE ztrs_bzj_list
*                            ct_table STRUCTURE ztrs0100_3
*                     USING pv_type.
*  DATA ls_table TYPE ztrs0100_3.
*  LOOP AT pt_list INTO DATA(ls_list).
*    ls_table-bukrs   = ls_list-zzcol_company."公司代码
*
*    "履约保证金-让售 取客户(partner_no是SRM中的合作伙伴,vendor_no是ERP中的客户)
*    ls_table-kunnr   = ls_list-vendor_no.
*    ls_table-zsrm_bp = ls_list-partner_no.
*
**　　供应商描述
**    ls_table-kunnrt  = zcl_tr_getdesc=>get_lifnr_desc( iv_lifnr = ls_table-kunnr ).
*    ls_table-kunnrt  = ls_list-name_org1.
*    ls_table-wrbtr   = ls_list-ps_emd_amnt.  "金额
*    ls_table-zbcskje = ls_list-ps_emd_amnt.  "本次收款金额
*    ls_table-waerk   = ls_list-currency.     "货币
*    ls_table-djskdh  = ls_list-object_id.    "投标号
*    ls_table-prctr   = ls_list-zzprofit_ctr ."利润中心
*    ls_table-newbw   = ls_list-xjllxm.       "现金流量代码
*    ls_table-zlsch   = ls_list-fkfs.         "付款方式
*    ls_table-zterm   = ls_list-fktj.         "付款条件代码
*    ls_table-zzfwhtbh = ls_list-zzfwhtbh.    "法务合同编号
**   现金流量代码描述
*    ls_table-newbwt = zcl_tr_getdesc=>get_rstgr_desc(
*                        iv_bukrs = ls_table-bukrs
*                        iv_rstgr = |{ ls_table-newbw }|
*                    ).
**   付款方式
*    ls_table-zfkfst = zcl_tr_getdesc=>get_fkfs_desc(
*                       iv_bukrs = ls_table-bukrs
*                       iv_zlsch = |{ ls_table-zlsch }|
*                   ).
**   付款条件
*    ls_table-zfktkt = zcl_tr_getdesc=>get_fktk_desc( iv_zterm = ls_table-zterm ).
*
*    ls_table-prctrt = zcl_tr_getdesc=>get_prctr_desc( iv_prctr = ls_table-prctr ).
*    ls_table-read_only = 'X'.
*    APPEND ls_table TO ct_table.
*    CLEAR ls_table.
*  ENDLOOP.
*
*ENDFORM.
**&---------------------------------------------------------------------*
**&      Form  FRM_ICON_CREATE
**&---------------------------------------------------------------------*
**       text
**----------------------------------------------------------------------*
**      -->P_0385   text
**      -->P_TEXT_008  text
**      -->P_GD_ICON_BEFORE  text
**----------------------------------------------------------------------*
*FORM frm_icon_create  USING    p_icon TYPE ico_augp
*                           p_text
*                           p_result.
*
*  CALL FUNCTION 'ICON_CREATE'
*    EXPORTING
*      name                  = p_icon
*      info                  = p_text
*    IMPORTING
*      result                = p_result
*    EXCEPTIONS
*      icon_not_found        = 1
*      outputfield_too_short = 2
*      OTHERS                = 3.
*
*ENDFORM.
*.
**&---------------------------------------------------------------------*
**&      Form  FRM_PRO_DO_G
**&---------------------------------------------------------------------*
**       text
**----------------------------------------------------------------------*
**      -->P_IS_HEAD  text
**      <--P_ET_TABLE  text
**----------------------------------------------------------------------*
*FORM frm_pro_do_g  USING    ps_head
*                   CHANGING ct_table.
*
**  data ls_table type ztrs0100_3.
**  loop at pt_list into data(ls_list).
**    ls_table-bukrs   = ls_list-zzcol_company."公司代码
**    ls_table-kunnr   = ls_list-vendor_no.    "供应商
***　　供应商描述
**    ls_table-kunnrt  = zcl_tr_getdesc=>get_lifnr_desc( iv_lifnr = ls_table-kunnr ).
**    ls_table-wrbtr   = ls_list-ps_emd_amnt.  "金额
**    ls_table-zbcskje = ls_list-ps_emd_amnt.  "本次收款金额
**    ls_table-waerk   = ls_list-currency.     "货币
**    ls_table-djskdh  = ls_list-object_id.    "投标号
**    ls_table-prctr   = ls_list-zzprofit_ctr ."利润中心
**    ls_table-newbw   = ls_list-xjllxm.       "现金流量代码
**    ls_table-zlsch   = ls_list-fkfs.         "付款方式
**    ls_table-zterm   = ls_list-fktj.         "付款条件代码
***   现金流量代码描述
**    ls_table-newbwt = zcl_tr_getdesc=>get_rstgr_desc(
**                        iv_bukrs = ls_table-bukrs
**                        iv_rstgr = ls_table-newbw
**                    ).
***   付款方式
**    ls_table-zfkfst = zcl_tr_getdesc=>get_fkfs_desc(
**                       iv_bukrs = ls_table-bukrs
**                       iv_zlsch = |{ ls_table-zlsch }|
**                   ).
***   付款条件
**    ls_table-zfktkt = zcl_tr_getdesc=>get_fktk_desc( iv_zterm = ls_table-zterm ).
**    ls_table-read_only = 'X'.
**    append ls_table to ct_table.
**    clear ls_table.
**  endloop.
*
*
*
*ENDFORM.
**&---------------------------------------------------------------------*
**&      Form  FRM_PRO_DO_E1
**&---------------------------------------------------------------------*
**       text
**----------------------------------------------------------------------*
**      -->P_LT_LIST  text
**      -->P_ET_TABLE  text
**----------------------------------------------------------------------*
**&---------------------------------------------------------------------*
**&      Form  FRM_PRO_DO_E
**&---------------------------------------------------------------------*
**       text
**----------------------------------------------------------------------*
**      -->P_LT_LIST  text
**      -->P_ET_TABLE  text
**----------------------------------------------------------------------*
*FORM frm_pro_do_e1   TABLES  pt_list STRUCTURE ztrs_bzj_list
*                            ct_table STRUCTURE ztrs0100_3.
*  DATA ls_table TYPE ztrs0100_3.
*  LOOP AT pt_list INTO DATA(ls_list).
*    ls_table-bukrs   = ls_list-zzcol_company."公司代码
*    ls_table-kunnr   = ls_list-partner_no.    "供应商
**　　供应商描述
*    ls_table-kunnrt  = ls_list-description && ls_list-name_org1.
*    ls_table-wrbtr   = ls_list-ps_emd_amnt.  "金额
*    ls_table-zbcskje = ls_list-ps_emd_amnt.  "本次收款金额
*    ls_table-waerk   = ls_list-currency.     "货币
*    ls_table-djskdh  = ls_list-object_id.    "投标号
*    ls_table-prctr   = ls_list-zzprofit_ctr ."利润中心
*    ls_table-newbw   = ls_list-xjllxm.       "现金流量代码
*    ls_table-zlsch   = ls_list-fkfs.         "付款方式
*    ls_table-zterm   = ls_list-fktj.         "付款条件代码
*    ls_table-zzfwhtbh = ls_list-zzfwhtbh.    "法务合同号
**   现金流量代码描述
*    ls_table-newbwt = zcl_tr_getdesc=>get_rstgr_desc(
*                        iv_bukrs = ls_table-bukrs
*                        iv_rstgr = |{ ls_table-newbw }|
*                    ).
**   付款方式
*    ls_table-zfkfst = zcl_tr_getdesc=>get_fkfs_desc(
*                       iv_bukrs = ls_table-bukrs
*                       iv_zlsch = |{ ls_table-zlsch }|
*                   ).
**   付款条件
*    ls_table-zfktkt = zcl_tr_getdesc=>get_fktk_desc( iv_zterm = ls_table-zterm ).
*
*    ls_table-prctrt = zcl_tr_getdesc=>get_prctr_desc( iv_prctr = ls_table-prctr ).
*    ls_table-read_only = 'X'.
*    APPEND ls_table TO ct_table.
*    CLEAR ls_table.
*  ENDLOOP.
*ENDFORM.
**&---------------------------------------------------------------------*
**&      Form  FRM_PRO_DO_D
**&---------------------------------------------------------------------*
**       text
**----------------------------------------------------------------------*
**      -->P_LT_OUTPUT  text
**      -->P_ET_TABLE  text
**----------------------------------------------------------------------*
*FORM frm_pro_do_d  TABLES   pt_list STRUCTURE zcrms00163
*                            ct_table STRUCTURE ztrs0100_3.
*  DATA ls_table TYPE ztrs0100_3.
*  LOOP AT pt_list INTO DATA(ls_list).
*    ls_table-bukrs   = ls_list-zzclgc."公司代码
*    ls_table-kunnr   = ls_list-partner.    "供应商
**　　供应商描述
*    ls_table-kunnrt  = ls_list-name_org1.
*    ls_table-waerk   = ls_list-zzbizhong.     "货币
*    ls_table-djskdh  = ls_list-zzbxdh.    "投标号
*
*
*    ls_table-read_only = 'X'.
*    APPEND ls_table TO ct_table.
*    CLEAR ls_table.
*  ENDLOOP.
*ENDFORM.
**&---------------------------------------------------------------------*
**&      Form  FRM_PRO_DO_J_T
**&---------------------------------------------------------------------*
**       text
**----------------------------------------------------------------------*
**      -->P_ET_REF  text
**      -->P_LT_REF  text
**----------------------------------------------------------------------*
*FORM frm_pro_do_j_t  TABLES   ct_ref STRUCTURE ztrs0120_5
*                                "为 <...> 插入正确的名称
*                              pt_ref STRUCTURE ztrs3045_01_all.
*
*  DATA cs_ref TYPE ztrs0120_5.
*  LOOP AT pt_ref INTO DATA(ls_ref).
*    MOVE-CORRESPONDING ls_ref TO cs_ref.
*    cs_ref-name1    = zcl_tr_getdesc=>get_lifnr_desc( iv_lifnr = cs_ref-lifnr ).
*    cs_ref-kunnr_t  = zcl_tr_getdesc=>get_kunnr_desc( iv_kunnr = cs_ref-kunnr ).
*    APPEND cs_ref TO ct_ref.
*
*    CLEAR cs_ref.
*  ENDLOOP.
*
*
*ENDFORM.
**&---------------------------------------------------------------------*
**&      Form  FRM_PRO_DO_J
**&---------------------------------------------------------------------*
**       text
**----------------------------------------------------------------------*
**      -->P_ET_TABLE  text
**----------------------------------------------------------------------*
*FORM frm_pro_do_j  TABLES   ct_table STRUCTURE ztrs0100_3.
*  "为 <...> 插入正确的名称.
*  LOOP AT  ct_table ASSIGNING FIELD-SYMBOL(<ls_data>) .
*
**   现金流量代码
*    <ls_data>-newbw = 'ZZZ'.
**   现金流量代码描述
*    <ls_data>-newbwt = zcl_tr_getdesc=>get_rstgr_desc(
*                        iv_bukrs = <ls_data>-bukrs
*                        iv_rstgr = |{ <ls_data>-newbw }|
*                    ).
*
**   根据现金流量代码取科目
*
*    SELECT SINGLE hkont INTO <ls_data>-hkont
*      FROM ztrt0007
*     WHERE bukrs = <ls_data>-bukrs
*       AND ztr_account = <ls_data>-accot.
**   付款方式
*    zcl_tr_getdesc=>get_domain_dese(
*                       iv_domname = 'ZDM_TR_ZFFS'
*                       iv_langu   = sy-langu
*                       iv_value   = |{ <ls_data>-zfkfst }|
*                   ).
*
*    <ls_data>-zbcskje = <ls_data>-wrbtr.
*
*    <ls_data>-read_only = 'X'.
*
*    CALL FUNCTION 'ZFM_TR_DETERMINE_PRCTR'
*      EXPORTING
*        bukrs  = <ls_data>-bukrs
*      IMPORTING
*        prctr  = <ls_data>-prctr
*      EXCEPTIONS
*        error  = 1
*        OTHERS = 2.
*
*    <ls_data>-prctrt = zcl_tr_getdesc=>get_prctr_desc( iv_prctr = <ls_data>-prctr ).
*
*
*  ENDLOOP.
*
*ENDFORM.
**&---------------------------------------------------------------------*
**&      Form  FRM_REPOSTING_CHECK_SK
**&---------------------------------------------------------------------*
**       text
**----------------------------------------------------------------------*
**  -->  p1        text
**  <--  p2        text
**----------------------------------------------------------------------*
*FORM frm_reposting_check_sk  CHANGING ps_doc STRUCTURE ztrs_docrepcheck.
*
*  DATA: lv_belnr TYPE belnr_d,
*        lv_gjahr TYPE gjahr.
*
*  SELECT SINGLE *
*      FROM ztrt0120_post
*      INTO @DATA(ls_ztrt0120_post)
*      WHERE docno = @ps_doc-docno
*      AND bukrs = @ps_doc-bukrs
*      AND belnr_r = @space
*      AND xstov = @space.
*
*  IF sy-subrc = 0 .
*    ps_doc-belnr = ls_ztrt0120_post-belnr.
*    ps_doc-gjahr = ls_ztrt0120_post-gjahr.
*    ps_doc-reposting = 'X'.
*    MESSAGE ID 'ZTR02' TYPE 'E' NUMBER 346 INTO ps_doc-message WITH ps_doc-docno ps_doc-belnr.
*  ELSE.
*    "为防止过账凭证没有写入到POST中，再次检查BKPF表参照字段
*    SELECT SINGLE belnr gjahr FROM bkpf INTO ( lv_belnr,lv_gjahr )
*      WHERE bukrs = ps_doc-bukrs AND xblnr = ps_doc-docno AND stblg EQ space.
*    IF sy-subrc = 0.
*      ps_doc-belnr = lv_belnr.
*      ps_doc-gjahr = lv_gjahr.
*      ps_doc-reposting = 'X'.
*      MESSAGE ID 'ZTR02' TYPE 'E' NUMBER 346 INTO ps_doc-message WITH ps_doc-docno lv_belnr.
*    ENDIF.
*  ENDIF.
*
*ENDFORM.
**&---------------------------------------------------------------------*
**&      Form  FRM_REPOSTING_CHECK_ZF
**&---------------------------------------------------------------------*
**       text
**----------------------------------------------------------------------*
**  -->  p1        text
**  <--  p2        text
**----------------------------------------------------------------------*
*FORM frm_reposting_check_zf  CHANGING ps_doc STRUCTURE ztrs_docrepcheck.
*
**  DATA: LV_BELNR TYPE BELNR_D,
**        LV_GJAHR TYPE GJAHR.
**
**  SELECT SINGLE *
**      FROM ZTRT2000_POST
**      INTO @DATA(LS_ZTRT2000_POST)
**      WHERE DOCNO = @PS_DOC-DOCNO
**        AND ACTION NE 'R'
***      AND BUKRS = @PS_DOC-BUKRS
***      AND BELNR_R = @SPACE
***      AND XSTOV = @SPACE.
**       .
**
**  IF SY-SUBRC = 0 .
**    PS_DOC-BELNR = LS_ZTRT2000_POST-BELNR.
**    PS_DOC-GJAHR = LS_ZTRT2000_POST-GJAHR.
**    PS_DOC-REPOSTING = 'X'.
**    MESSAGE ID 'ZTR02' TYPE 'E' NUMBER 346 INTO PS_DOC-MESSAGE WITH PS_DOC-DOCNO PS_DOC-BELNR.
**  ELSE.
**    "为防止过账凭证没有写入到POST中，再次检查BKPF表参照字段
**    SELECT SINGLE BELNR GJAHR FROM BKPF INTO ( LV_BELNR,LV_GJAHR )
**      WHERE BUKRS = PS_DOC-BUKRS AND XBLNR = PS_DOC-DOCNO AND STBLG EQ SPACE.
**    IF SY-SUBRC = 0.
**      PS_DOC-BELNR = LV_BELNR.
**      PS_DOC-GJAHR = LV_GJAHR.
**      PS_DOC-REPOSTING = 'X'.
**      MESSAGE ID 'ZTR02' TYPE 'E' NUMBER 346 INTO PS_DOC-MESSAGE WITH PS_DOC-DOCNO LV_BELNR.
**    ENDIF.
**  ENDIF.
*
*
*ENDFORM.
**&---------------------------------------------------------------------*
**&      Form  FRM_REPOSTING_CHECK_CKHT
**&---------------------------------------------------------------------*
**       text
**----------------------------------------------------------------------*
**  -->  p1        text
**  <--  p2        text
**----------------------------------------------------------------------*
*FORM frm_reposting_check_ckht  CHANGING ps_doc STRUCTURE ztrs_docrepcheck.
*
*  DATA: lv_belnr TYPE belnr_d,
*        lv_gjahr TYPE gjahr.
*
*  SELECT SINGLE *
*      FROM ztrt6031_post
*      INTO @DATA(ls_ztrt6031_post)
*      WHERE docno = @ps_doc-docno
*      AND bukrs = @ps_doc-bukrs
*      AND belnr_r = @space
*      AND xstov = @space.
*
*  IF sy-subrc = 0 .
*    ps_doc-belnr = ls_ztrt6031_post-belnr.
*    ps_doc-gjahr = ls_ztrt6031_post-gjahr.
*    ps_doc-reposting = 'X'.
*    MESSAGE ID 'ZTR02' TYPE 'E' NUMBER 346 INTO ps_doc-message WITH ps_doc-docno ps_doc-belnr.
*  ELSE.
*    "为防止过账凭证没有写入到POST中，再次检查BKPF表参照字段
*    SELECT SINGLE belnr gjahr FROM bkpf INTO ( lv_belnr,lv_gjahr )
*      WHERE bukrs = ps_doc-bukrs AND xblnr = ps_doc-docno AND stblg EQ space.
*    IF sy-subrc = 0.
*      ps_doc-belnr = lv_belnr.
*      ps_doc-gjahr = lv_gjahr.
*      ps_doc-reposting = 'X'.
*      MESSAGE ID 'ZTR02' TYPE 'E' NUMBER 346 INTO ps_doc-message WITH ps_doc-docno lv_belnr.
*    ENDIF.
*  ENDIF.
*
*ENDFORM.
**&---------------------------------------------------------------------*
**&      Form  FRM_REPOSTING_CHECK_XYZDF
**&---------------------------------------------------------------------*
**       text
**----------------------------------------------------------------------*
**      <--P_<FS_DOC>  text
**----------------------------------------------------------------------*
*FORM frm_reposting_check_xyzdf  CHANGING ps_doc STRUCTURE ztrs_docrepcheck.
*
*
*
*
*
*ENDFORM.
**&---------------------------------------------------------------------*
**&      Form  FRM_AUTO_CLEARING
**&---------------------------------------------------------------------*
**       text
**----------------------------------------------------------------------*
**      -->P_MODE  text
**----------------------------------------------------------------------*
*FORM frm_auto_clearing  USING p_mode.
*
*  DATA:ls_head_p TYPE ztr_clear_h,
*       lt_belnr  TYPE ztr_t_belnr_c,
*       l_belnr   TYPE ztr_s_belnr_c,
*       lv_type   TYPE char1,
*       lv_msg    TYPE c LENGTH 100,
*       lv_belnr  TYPE belnr_d.
*
*  CASE p_mode.
*    WHEN 'A'. "全部清账
*      CALL FUNCTION 'ZFM_TR_BAPI_CLEAR'
*        EXPORTING
*          header   = ls_head_p
*          it_belnr = lt_belnr
*        IMPORTING
*          e_type   = lv_type
*          e_msg    = lv_msg
*          e_belnr  = lv_belnr.
*
*    WHEN 'P'. "部分清账
*      CALL FUNCTION 'ZFM_TR_BAPI_PART_CLEAR'
*        EXPORTING
*          header    = ls_head_p
*          it_belnr  = lt_belnr
*          iv_cshkzg = 'H'
*          i_belnr   = l_belnr
*        IMPORTING
*          e_type    = lv_type
*          e_msg     = lv_msg
*          e_belnr   = lv_belnr.
*
*    WHEN OTHERS.
*
*  ENDCASE.
*
*
*ENDFORM.
**&---------------------------------------------------------------------*
**&      Form  FRM_REPOSTING_CHECK_KHTZ
**&---------------------------------------------------------------------*
**       text
**----------------------------------------------------------------------*
**      <--P_<FS_DOC>  text
**----------------------------------------------------------------------*
*FORM frm_reposting_check_khtz CHANGING ps_doc STRUCTURE ztrs_docrepcheck.
*
*  DATA: lv_belnr TYPE belnr_d,
*        lv_gjahr TYPE gjahr.
*
*  SELECT SINGLE *
*      FROM ztrt2600_post
*      INTO @DATA(ls_ztrt2600_post)
*      WHERE docno = @ps_doc-docno
*      AND bukrs = @ps_doc-bukrs
*      AND belnr_r = @space
*      AND xstov = @space.
*
*  IF sy-subrc = 0 .
*    ps_doc-belnr = ls_ztrt2600_post-belnr.
*    ps_doc-gjahr = ls_ztrt2600_post-gjahr.
*    ps_doc-reposting = 'X'.
*    MESSAGE ID 'ZTR02' TYPE 'E' NUMBER 346 INTO ps_doc-message WITH ps_doc-docno ps_doc-belnr.
*  ELSE.
*    "为防止过账凭证没有写入到POST中，再次检查BKPF表参照字段
*    SELECT SINGLE belnr gjahr FROM bkpf INTO ( lv_belnr,lv_gjahr )
*      WHERE bukrs = ps_doc-bukrs AND xblnr = ps_doc-docno AND stblg EQ space.
*    IF sy-subrc = 0.
*      ps_doc-belnr = lv_belnr.
*      ps_doc-gjahr = lv_gjahr.
*      ps_doc-reposting = 'X'.
*      MESSAGE ID 'ZTR02' TYPE 'E' NUMBER 346 INTO ps_doc-message WITH ps_doc-docno lv_belnr.
*    ENDIF.
*  ENDIF.
*
*
*ENDFORM.
**&---------------------------------------------------------------------*
**&      Form  FRM_AMT_CHECK
**&---------------------------------------------------------------------*
**       text
**----------------------------------------------------------------------*
**      -->P_LT_AMT  text
**      -->P_LT_MSG  text
**----------------------------------------------------------------------*
*FORM frm_amt_conv  TABLES lt_amt STRUCTURE bapiaccr09 lt_msg STRUCTURE bapiret2 USING waers rate.
*
*  DATA lt_amt_c TYPE TABLE OF bapiaccr09.
*  DATA: lv_wrbtr     TYPE bapidoccur,
*        lv_amt_wrbtr TYPE bapidoccur.
*
*  READ TABLE lt_amt TRANSPORTING NO FIELDS WITH KEY currency = waers.
*  IF sy-subrc <> 0.
*    set_msg 'E' 'ZTR02' '454' '' waers '' '' ''.  "凭证货币&1在行项目中不存在
*    RETURN.
*  ENDIF.
*
*  SORT lt_amt BY itemno_acc curr_type currency.
*
*  APPEND LINES OF lt_amt TO lt_amt_c.
*  SORT lt_amt_c BY currency.
*  DELETE ADJACENT DUPLICATES FROM lt_amt_c COMPARING currency.
*  IF lines( lt_amt_c ) GT 2.
*    set_msg 'E' 'ZTR02' '455' '' '' '' '' ''.  "只能支持两种币种四舍五入转换
*    RETURN.
*  ENDIF.
*
*  CLEAR lt_amt_c.
*  LOOP AT lt_amt INTO DATA(ls_amt) WHERE currency = waers.
*    COLLECT ls_amt INTO lt_amt_c.
*    CLEAR ls_amt.
*  ENDLOOP.
*
*  READ TABLE lt_amt_c INTO ls_amt INDEX 1.
*  IF ls_amt-amt_doccur <> 0.
*    set_msg 'E' 'ZTR02' '456' '' '' '' '' ''.  "凭证总金额不平，无法转换
*    RETURN.
*  ENDIF.
*
**  CLEAR lt_amt_c.
**  LOOP AT lt_amt INTO DATA(ls_amt) WHERE currency <> waers.
**    COLLECT ls_amt INTO lt_amt_c.
**    CLEAR ls_amt.
**  ENDLOOP.
**
**  READ TABLE lt_amt_c INTO ls_amt INDEX 1.
**  IF ls_amt-amt_duccur <> '0.01' .
**    set_msg 'E' 'ZTR02' '457' '' '' '' '' ''.  "四舍五入金额差异不等于0.01，请检查！
**    RETURN.
**  ENDIF.
*
*  CLEAR: lv_wrbtr,lv_amt_wrbtr.
*  LOOP AT lt_amt ASSIGNING FIELD-SYMBOL(<fs_amt>) WHERE currency <> waers.
*    READ TABLE lt_amt INTO DATA(ls_amt_c) WITH KEY itemno_acc = <fs_amt>-itemno_acc.
*    IF sy-subrc = 0.
*      lv_amt_wrbtr = ls_amt_c-amt_doccur * rate.
*      lv_wrbtr = abs( <fs_amt>-amt_doccur ) - abs( lv_amt_wrbtr ).
*      IF abs( lv_wrbtr ) LE '0.01' AND lv_wrbtr <> 0.
*        <fs_amt>-amt_doccur = lv_amt_wrbtr.
*      ENDIF.
*    ENDIF.
*    CLEAR ls_amt_c.
*  ENDLOOP.
*
*ENDFORM.
**&---------------------------------------------------------------------*
**&      Form  FRM_GET_BANK_DATA
**&---------------------------------------------------------------------*
**       text
**----------------------------------------------------------------------*
**      -->P_LT_BANK_DOC  text
**      -->P_<FS_TRXNO_V>  text
**      -->P_<FS_DBKEY_V>  text
**      -->P_<FS_BUKRS_V>  text
**      -->P_<FS_KUNNR_V>  text
**      -->P_<FS_LIFNR_V>  text
**      -->P_<FS_HBKID_V>  text
**      -->P_<FS_HKTID_V>  text
**      -->P_<FS_YHZH_V>  text
**      -->P_<FS_ZBKITEM_V>  text
**----------------------------------------------------------------------*
*FORM frm_get_bank_data  TABLES lt_bank_doc STRUCTURE ztrs_bank_doc
*                         USING  lv_t lv_v trxno_v dbkey_v bukrs_v kunnr_v lifnr_v hbkid_v hktid_v yhzh_v zbkitem_v.
*
*  DATA: lr_bukrs   TYPE RANGE OF bukrs,
*        lr_kunnr   TYPE RANGE OF kunnr,
*        lr_lifnr   TYPE RANGE OF lifnr,
*        lr_hbkid   TYPE RANGE OF hbkid,
*        lr_hktid   TYPE RANGE OF hktid,
*        lr_trxno   TYPE RANGE OF ztr_bank_trxno,
*        lr_zbkitem TYPE RANGE OF ztr_bkitem,
*        lr_dbkey   TYPE RANGE OF /bobf/conf_key,
*        lr_yhzh    TYPE RANGE OF ztr_yhzh.
*
*  DATA: ls_bank_doc TYPE ztrs_bank_doc.
*
*  DEFINE set_mac.
*    IF &1 IS NOT INITIAL.
*      APPEND VALUE #( sign = 'I' option = 'EQ' low = &1 ) TO &2.
*    ELSE.
*      APPEND VALUE #( sign = 'I' option = 'CP' low = '*' ) TO &2.
*    ENDIF.
*  END-OF-DEFINITION.
*
*  set_mac:bukrs_v    lr_bukrs,
*          kunnr_v    lr_kunnr,
*          lifnr_v    lr_lifnr,
*          hbkid_v    lr_hbkid,
*          hktid_v    lr_hktid,
*          yhzh_v     lr_yhzh,
*          zbkitem_v  lr_zbkitem.
*
*  "从Bank Trans表中取流水
*  SELECT * FROM ztrt_bank_trans
*    INTO TABLE @DATA(lt_trans)
*    WHERE bukrs IN @lr_bukrs
*      AND hbkid IN @lr_hbkid
*      AND hktid IN @lr_hbkid
*      AND yhzh  IN @lr_yhzh
*      AND kunnr IN @lr_kunnr
*      AND lifnr IN @lr_lifnr
*      AND trxno = @trxno_v
*      AND zgroup_ac <> ''
*      AND split_flag = ''.
*
*  "从3023_02表中取流水
*  SELECT * FROM ztrt3023_02
*    INTO TABLE @DATA(lt_3023_02)
*    WHERE db_key = @dbkey_v
*      AND zbkitem IN @lr_zbkitem
*      AND zgroup_ac <> ''
*      AND dflag <> 'X'
*      AND split_flag = ''.
*
*  "从3023_02_cf表中取流水
*  SELECT * FROM ztrt3023_02_cf
*    INTO TABLE @DATA(lt_3023_02_cf)
*    WHERE db_key = @dbkey_v
*      AND zbkitem IN @lr_zbkitem
*      AND zgroup_ac <> ''.
*
*  LOOP AT lt_trans INTO DATA(ls_trans).
*    MOVE-CORRESPONDING ls_trans TO ls_bank_doc.
*    ls_bank_doc-tabname = lv_t.
*    ls_bank_doc-fieldvalue1 = lv_v.
*    APPEND ls_bank_doc TO lt_bank_doc.
*  ENDLOOP.
*
*  LOOP AT lt_3023_02 INTO DATA(ls_3023_02).
*    MOVE-CORRESPONDING ls_3023_02 TO ls_bank_doc.
*    ls_bank_doc-tabname = lv_t.
*    ls_bank_doc-fieldvalue1 = lv_v.
*    APPEND ls_bank_doc TO lt_bank_doc.
*  ENDLOOP.
*
*  LOOP AT lt_3023_02_cf INTO DATA(ls_3023_02_cf).
*    MOVE-CORRESPONDING ls_3023_02_cf TO ls_bank_doc.
*    ls_bank_doc-tabname = lv_t.
*    ls_bank_doc-fieldvalue1 = lv_v.
*    APPEND ls_bank_doc TO lt_bank_doc.
*  ENDLOOP.
*
*
*ENDFORM.
**&---------------------------------------------------------------------*
**&      Form  FRM_GET_BANK_REFDOC_BLANK
**&---------------------------------------------------------------------*
**       text
**----------------------------------------------------------------------*
**  -->  p1        text
**  <--  p2        text
**----------------------------------------------------------------------*
*FORM frm_get_bank_refdoc_blank TABLES lt_bank_dc_blank STRUCTURE ztrs_bank_doc.
*
*  DATA ls_bank_dc_blank TYPE ztrs_bank_doc.
*
*  "从Bank Trans表中取流水
*  SELECT * FROM ztrt_bank_trans
*    INTO TABLE @DATA(lt_trans)
*    WHERE zref_doc = ''
*      AND zgroup_ac <> ''
*      AND zgroup_ac <> '10'
*      AND zgroup_ac <> '99'
*      AND split_flag = ''.
*
*  LOOP AT lt_trans INTO DATA(ls_trans).
*    MOVE-CORRESPONDING ls_trans TO ls_bank_dc_blank.
*    ls_bank_dc_blank-zbkitem =  ls_trans-trxno.
*    APPEND ls_bank_dc_blank TO lt_bank_dc_blank.
*  ENDLOOP.
*
*  "从3023_02表中取流水
*  SELECT * FROM ztrt3023_02
*    INTO TABLE @DATA(lt_3023_02)
*    WHERE zref_doc = ''
*      AND zgroup_ac <> ''
*      AND zgroup_ac <> '10'
*      AND zgroup_ac <> '99'
*      AND dflag <> 'X'
*      AND split_flag = ''.
*
*  LOOP AT lt_3023_02 INTO DATA(ls_3023_02).
*    MOVE-CORRESPONDING ls_3023_02 TO ls_bank_dc_blank.
*    APPEND ls_bank_dc_blank TO lt_bank_dc_blank.
*  ENDLOOP.
*
*  "从3023_02_cf表中取流水
*  SELECT * FROM ztrt3023_02_cf
*    INTO TABLE @DATA(lt_3023_02_cf)
*    WHERE zref_doc = ''
*      AND zgroup_ac <> ''
*      AND zgroup_ac <> '10'
*      AND zgroup_ac <> '99'.
*
*  LOOP AT lt_3023_02_cf INTO DATA(ls_3023_02_cf).
*    MOVE-CORRESPONDING ls_3023_02_cf TO ls_bank_dc_blank.
*    APPEND ls_bank_dc_blank TO lt_bank_dc_blank.
*  ENDLOOP.
*
*ENDFORM.
**&---------------------------------------------------------------------*
**&      Form  FRM_GET_DOC_REFDOC_BLANK
**&---------------------------------------------------------------------*
**       text
**----------------------------------------------------------------------*
**      -->P_LT_BANK_DOCS  text
**      -->P_LT_BANK_DC_BLANK  text
**----------------------------------------------------------------------*
*FORM frm_get_doc_refdoc_blank  TABLES lt_bank_docs STRUCTURE ztr_update_bkdoc
*                                       lt_bank_dc_blank STRUCTURE ztrs_bank_doc
*                                       lt_bank_dc STRUCTURE ztrs_bank_doc
*                                       lt_msg STRUCTURE bapiret2
*                                USING fieldvalue1 mode.
*
*  DATA: lr_data TYPE REF TO data.
*  DATA: lv_dbkey   TYPE /bobf/conf_key,
*        lv_trxno   TYPE ztr_bank_trxno,
*        lv_zbkitem TYPE ztr_bkitem,
*        lv_bukrs   TYPE bukrs,
*        lv_kunnr   TYPE kunnr,
*        lv_lifnr   TYPE lifnr,
*        lv_hbkid   TYPE hbkid,
*        lv_hktid   TYPE hktid,
*        lv_yhzh    TYPE ztr_yhzh.
*  DATA: ls_bank_dc TYPE ztrs_bank_doc.
*  DATA: error_text TYPE string.
*  DATA: cond TYPE string.
*
*  FIELD-SYMBOLS: <lt_data> TYPE ANY TABLE.
*
*  LOOP AT lt_bank_dc_blank INTO DATA(ls_bank_dc_blank).
*    LOOP AT lt_bank_docs INTO DATA(ls_bank_docs).
*      ASSIGN COMPONENT 'TABNAME' OF STRUCTURE ls_bank_docs TO FIELD-SYMBOL(<fs_t>).          "获取表名
*      ASSIGN COMPONENT 'VIEWNAME' OF STRUCTURE ls_bank_docs TO FIELD-SYMBOL(<fs_v>).         "获取视图名
*      ASSIGN COMPONENT 'FIELDNAME' OF STRUCTURE ls_bank_docs TO FIELD-SYMBOL(<fs_fn>).       "获取单据号对应字段名
*      ASSIGN COMPONENT 'FIELDNAME1' OF STRUCTURE ls_bank_docs TO FIELD-SYMBOL(<fs_bukrs>).   "获取公司代码对应字段名
*      ASSIGN COMPONENT 'FIELDNAME2' OF STRUCTURE ls_bank_docs TO FIELD-SYMBOL(<fs_kunnr>).   "获取客户编码对应字段名
*      ASSIGN COMPONENT 'FIELDNAME3' OF STRUCTURE ls_bank_docs TO FIELD-SYMBOL(<fs_lifnr>).   "获取供应商编码对应字段名
*      ASSIGN COMPONENT 'FIELDNAME4' OF STRUCTURE ls_bank_docs TO FIELD-SYMBOL(<fs_hbkid>).   "获取开户银行简要键对应字段名
*      ASSIGN COMPONENT 'FIELDNAME5' OF STRUCTURE ls_bank_docs TO FIELD-SYMBOL(<fs_hktid>).   "获取账户细目代码对应字段名
*      ASSIGN COMPONENT 'FIELDNAME6' OF STRUCTURE ls_bank_docs TO FIELD-SYMBOL(<fs_trxno>).   "获取银行交易流水号对应字段名
*      ASSIGN COMPONENT 'FIELDNAME7' OF STRUCTURE ls_bank_docs TO FIELD-SYMBOL(<fs_zbkitem>). "获取交易流水号对应字段名
*      ASSIGN COMPONENT 'FIELDNAME8' OF STRUCTURE ls_bank_docs TO FIELD-SYMBOL(<fs_dbkey>).   "获取DBKEY对应字段名
*      ASSIGN COMPONENT 'FIELDNAME9' OF STRUCTURE ls_bank_docs TO FIELD-SYMBOL(<fs_yhzh>).    "获取银行账户对应字段名
**    ASSIGN COMPONENT 'ZUPDATE' OF STRUCTURE ls_bank_docs TO FIELD-SYMBOL(<fs_update>).     "获取更新条件
*      ASSIGN COMPONENT 'ZWHERE' OF STRUCTURE ls_bank_docs TO FIELD-SYMBOL(<fs_where>).       "获取取数条件
**    ASSIGN COMPONENT 'ZMODE' OF STRUCTURE ls_bank_docs TO FIELD-SYMBOL(<fs_mode>).         "获取处理模式
*
*      IF <fs_fn> IS ASSIGNED AND <fs_fn> IS INITIAL.
*        set_msg 'E' 'ZTR02' '496' <fs_t> '' '' '' ''.
*        RETURN.
*      ENDIF.
*
*      CREATE DATA lr_data TYPE TABLE OF (<fs_t>).
*      ASSIGN lr_data->* TO <lt_data>.               "动态创建内表
*
*      IF fieldvalue1 = '*'.
*
*        IF <fs_dbkey> IS NOT ASSIGNED AND <fs_trxno> IS NOT ASSIGNED AND <fs_zbkitem> IS NOT ASSIGNED.
*          CONTINUE.
*        ENDIF.
*
*        IF <fs_dbkey> IS ASSIGNED AND <fs_dbkey> IS INITIAL.
*          IF <fs_trxno> IS ASSIGNED AND <fs_trxno> IS INITIAL.
*            IF <fs_zbkitem> IS ASSIGNED AND <fs_zbkitem> IS INITIAL.
*              CONTINUE.
*            ENDIF.
*          ENDIF.
*        ENDIF.
*
*        IF <fs_dbkey> IS ASSIGNED AND <fs_dbkey> IS NOT INITIAL AND ls_bank_dc_blank-db_key <> '00000000000000000000000000000000'.
*          cond = |{ <fs_dbkey> } = '{ ls_bank_dc_blank-db_key }' | .       "取数条件
*        ELSEIF <fs_zbkitem> IS ASSIGNED AND <fs_zbkitem> IS NOT INITIAL AND ls_bank_dc_blank-zbkitem IS NOT INITIAL.
*          cond = |{ <fs_zbkitem> } = '{ ls_bank_dc_blank-zbkitem }' | .    "取数条件
*        ELSEIF <fs_trxno> IS ASSIGNED AND <fs_trxno> IS NOT INITIAL AND ls_bank_dc_blank-zbkitem IS NOT INITIAL.
*          cond = |{ <fs_trxno> } = '{ ls_bank_dc_blank-zbkitem }' | .      "取数条件
*        ENDIF.
*      ENDIF.
*
*      TRY.
*          SELECT COUNT(*) FROM (<fs_t>) WHERE (cond).
*        CATCH cx_sy_dynamic_osql_syntax INTO DATA(lcx_error).
*          CLEAR error_text.
*          error_text = lcx_error->get_text( ).
*          set_msg 'E' 'ZTR02' '000' error_text '' '' '' ''.
*          RETURN.
*      ENDTRY.
*
*      TRY.
*          SELECT * FROM (<fs_t>) WHERE (cond) INTO CORRESPONDING FIELDS OF TABLE @<lt_data>.
*        CATCH cx_sy_arithmetic_error INTO DATA(lcl_error).
*
*      ENDTRY.
*      IF sy-subrc = 0.
*        IF fieldvalue1 = '*'.
*          LOOP AT <lt_data> ASSIGNING FIELD-SYMBOL(<fs_data>).
*            MOVE-CORRESPONDING ls_bank_dc_blank TO ls_bank_dc.
*            ASSIGN COMPONENT <fs_fn> OF STRUCTURE <fs_data> TO FIELD-SYMBOL(<fs_docno>).
*            ls_bank_dc-fieldvalue1 = <fs_docno>.
*            ls_bank_dc-tabname = ls_bank_docs-tabname.
*            APPEND ls_bank_dc TO lt_bank_dc.
*            CLEAR ls_bank_dc.
*          ENDLOOP.
*
*        ELSE.
*
*          LOOP AT <lt_data> ASSIGNING <fs_data>.
*            ASSIGN COMPONENT <fs_bukrs> OF STRUCTURE <fs_data> TO FIELD-SYMBOL(<fs_bukrs_v>).
*            ASSIGN COMPONENT <fs_kunnr> OF STRUCTURE <fs_data> TO FIELD-SYMBOL(<fs_kunnr_v>).
*            ASSIGN COMPONENT <fs_lifnr> OF STRUCTURE <fs_data> TO FIELD-SYMBOL(<fs_lifnr_v>).
*            ASSIGN COMPONENT <fs_hbkid> OF STRUCTURE <fs_data> TO FIELD-SYMBOL(<fs_hbkid_v>).
*            ASSIGN COMPONENT <fs_hktid> OF STRUCTURE <fs_data> TO FIELD-SYMBOL(<fs_hktid_v>).
*            ASSIGN COMPONENT <fs_trxno> OF STRUCTURE <fs_data> TO FIELD-SYMBOL(<fs_trxno_v>).
*            ASSIGN COMPONENT <fs_zbkitem> OF STRUCTURE <fs_data> TO FIELD-SYMBOL(<fs_zbkitem_v>).
*            ASSIGN COMPONENT <fs_dbkey> OF STRUCTURE <fs_data> TO FIELD-SYMBOL(<fs_dbkey_v>).
*            ASSIGN COMPONENT <fs_yhzh> OF STRUCTURE <fs_data> TO FIELD-SYMBOL(<fs_yhzh_v>).
*
*            IF <fs_dbkey_v> IS NOT ASSIGNED AND <fs_trxno_v> IS NOT ASSIGNED AND <fs_zbkitem> IS NOT ASSIGNED.
*              CONTINUE.
*            ENDIF.
*
*            IF <fs_dbkey_v> IS ASSIGNED AND <fs_dbkey_v> IS INITIAL.
*              IF <fs_trxno_v> IS ASSIGNED AND <fs_trxno_v> IS INITIAL.
*                IF <fs_zbkitem> IS ASSIGNED AND <fs_zbkitem> IS INITIAL.
*                  CONTINUE.
*                ENDIF.
*              ENDIF.
*            ENDIF.
*
*            IF <fs_dbkey_v> IS ASSIGNED.   lv_dbkey = <fs_dbkey_v>.     ENDIF.
*            IF <fs_trxno_v> IS ASSIGNED.   lv_trxno = <fs_trxno_v>.     ENDIF.
*            IF <fs_zbkitem_v> IS ASSIGNED. lv_zbkitem = <fs_zbkitem_v>. ENDIF.
*            IF <fs_bukrs_v> IS ASSIGNED.   lv_bukrs = <fs_bukrs_v>.     ENDIF.
*            IF <fs_kunnr_v> IS ASSIGNED.   lv_kunnr = <fs_kunnr_v>.     ENDIF.
*            IF <fs_lifnr_v> IS ASSIGNED.   lv_lifnr = <fs_lifnr_v>.     ENDIF.
*            IF <fs_hbkid_v> IS ASSIGNED.   lv_hbkid = <fs_hbkid_v>.     ENDIF.
*            IF <fs_hktid_v> IS ASSIGNED.   lv_hktid = <fs_hktid_v>.     ENDIF.
*            IF <fs_yhzh_v> IS ASSIGNED.    lv_yhzh = <fs_yhzh_v>.       ENDIF.
*
*            PERFORM frm_get_bank_data TABLES lt_bank_dc
*               USING <fs_t> fieldvalue1 lv_trxno lv_dbkey lv_bukrs lv_kunnr lv_lifnr lv_hbkid lv_hktid lv_yhzh lv_zbkitem .
*
*          ENDLOOP.
*        ENDIF.
*
*        SORT lt_bank_dc.
*        DELETE ADJACENT DUPLICATES FROM lt_bank_dc.
*
*        PERFORM frm_execute_refdoc_mode TABLES lt_bank_dc lt_msg USING fieldvalue1 mode.
*
*      ENDIF.
*      CLEAR ls_bank_docs.
*    ENDLOOP.
*  ENDLOOP.
*
*ENDFORM.
**&---------------------------------------------------------------------*
**&      Form  FRM_EXECUTE_REFDOC_MODE
**&---------------------------------------------------------------------*
**       text
**----------------------------------------------------------------------*
**      -->P_LT_BANK_DC  text
**----------------------------------------------------------------------*
*FORM frm_execute_refdoc_mode  TABLES lt_bank_dc STRUCTURE ztrs_bank_doc
*                                      lt_msg STRUCTURE bapiret2
*                               USING fieldvalue1 mode.
*
*  CASE mode.
*    WHEN 'S'.
*
*    WHEN 'U'.
*
*      DATA lt_ref       TYPE ztrt_3028_agnref.
*      DATA ls_ref       LIKE LINE OF lt_ref.
*      DATA lv_group     TYPE zbk_grpac.
*      DATA ls_bank_dc_c TYPE ztrs_bank_doc.
*      DATA lt_bank_dc_c TYPE TABLE OF ztrs_bank_doc.
*
*      CLEAR lv_group.
*
*      DELETE lt_bank_dc WHERE zgroup_ac = ''.
*      APPEND LINES OF lt_bank_dc TO lt_bank_dc_c.
*
*      SORT lt_bank_dc_c BY zgroup_ac.
*      DELETE ADJACENT DUPLICATES FROM lt_bank_dc_c COMPARING zgroup_ac.
*      IF lines( lt_bank_dc_c ) <> 1.
*        set_msg 'E' 'ZTR02' '497' fieldvalue1 '' '' '' ''.
*        RETURN.
*      ELSE.
*        READ TABLE lt_bank_dc_c INTO ls_bank_dc_c INDEX 1.
*        IF sy-subrc = 0.
*          lv_group = ls_bank_dc_c-zgroup_ac.
*        ENDIF.
*      ENDIF.
*
*      LOOP AT lt_bank_dc INTO DATA(ls_bank_dc).
*        MOVE-CORRESPONDING ls_bank_dc TO ls_ref.
**            ls_ref-trxno    = ls_bank_dc-zbkitem.
*        ls_ref-zref_doc = ls_bank_dc-fieldvalue1.
*        ls_ref-bukrs    = ls_bank_dc-bukrs.
*        APPEND ls_ref TO lt_ref.
*        CLEAR ls_ref.
*      ENDLOOP.
*
*      zcl_tr_3024_gui=>agn_ref(
*      EXPORTING
*        it_ref    =  lt_ref      " ZTRS_3028_REFAGN
*        iv_commit = abap_true    " 布尔变量（X= 真，-= 假，空格 = 未知）
*        iv_group  = lv_group     " 实际对账路径
*      EXCEPTIONS
*        err       = 1
*        OTHERS    = 2  ).
*      IF sy-subrc = 0.
*        set_msg 'S' 'ZTR02' '951' fieldvalue1 '' '' '' ''.
*      ELSE.
*        set_msg 'E' 'ZTR02' '952' fieldvalue1 '' '' '' ''.
*      ENDIF.
*
*    WHEN OTHERS.
*  ENDCASE.
*
*ENDFORM.
**&---------------------------------------------------------------------*
**&      Form  FRM_GET_BANK_DOCS
**&---------------------------------------------------------------------*
**       text
**----------------------------------------------------------------------*
**      -->P_LT_BANK_DOCS  text
**----------------------------------------------------------------------*
*FORM frm_get_bank_docs  TABLES lt_bank_docs STRUCTURE ztr_update_bkdoc
*                                lt_bank_dc STRUCTURE ztrs_bank_doc
*                                lt_msg STRUCTURE bapiret2
*                        USING fieldvalue1 mode.
*
*  DATA: lr_data TYPE REF TO data.
*  DATA: lv_dbkey   TYPE /bobf/conf_key,
*        lv_trxno   TYPE ztr_bank_trxno,
*        lv_zbkitem TYPE ztr_bkitem,
*        lv_bukrs   TYPE bukrs,
*        lv_kunnr   TYPE kunnr,
*        lv_lifnr   TYPE lifnr,
*        lv_hbkid   TYPE hbkid,
*        lv_hktid   TYPE hktid,
*        lv_yhzh    TYPE ztr_yhzh.
*
*  DATA: error_text TYPE string.
*  DATA: cond TYPE string.
*
*  FIELD-SYMBOLS: <lt_data> TYPE ANY TABLE.
*
*  LOOP AT lt_bank_docs INTO DATA(ls_bank_docs).
*
*    ASSIGN COMPONENT 'TABNAME' OF STRUCTURE ls_bank_docs TO FIELD-SYMBOL(<fs_t>).          "获取表名
*    ASSIGN COMPONENT 'VIEWNAME' OF STRUCTURE ls_bank_docs TO FIELD-SYMBOL(<fs_v>).         "获取视图名
*    ASSIGN COMPONENT 'FIELDNAME' OF STRUCTURE ls_bank_docs TO FIELD-SYMBOL(<fs_fn>).       "获取单据号对应字段名
*    ASSIGN COMPONENT 'FIELDNAME1' OF STRUCTURE ls_bank_docs TO FIELD-SYMBOL(<fs_bukrs>).   "获取公司代码对应字段名
*    ASSIGN COMPONENT 'FIELDNAME2' OF STRUCTURE ls_bank_docs TO FIELD-SYMBOL(<fs_kunnr>).   "获取客户编码对应字段名
*    ASSIGN COMPONENT 'FIELDNAME3' OF STRUCTURE ls_bank_docs TO FIELD-SYMBOL(<fs_lifnr>).   "获取供应商编码对应字段名
*    ASSIGN COMPONENT 'FIELDNAME4' OF STRUCTURE ls_bank_docs TO FIELD-SYMBOL(<fs_hbkid>).   "获取开户银行简要键对应字段名
*    ASSIGN COMPONENT 'FIELDNAME5' OF STRUCTURE ls_bank_docs TO FIELD-SYMBOL(<fs_hktid>).   "获取账户细目代码对应字段名
*    ASSIGN COMPONENT 'FIELDNAME6' OF STRUCTURE ls_bank_docs TO FIELD-SYMBOL(<fs_trxno>).   "获取银行交易流水号对应字段名
*    ASSIGN COMPONENT 'FIELDNAME7' OF STRUCTURE ls_bank_docs TO FIELD-SYMBOL(<fs_zbkitem>). "获取交易流水号对应字段名
*    ASSIGN COMPONENT 'FIELDNAME8' OF STRUCTURE ls_bank_docs TO FIELD-SYMBOL(<fs_dbkey>).   "获取DBKEY对应字段名
*    ASSIGN COMPONENT 'FIELDNAME9' OF STRUCTURE ls_bank_docs TO FIELD-SYMBOL(<fs_yhzh>).    "获取银行账户对应字段名
**    ASSIGN COMPONENT 'ZUPDATE' OF STRUCTURE ls_bank_docs TO FIELD-SYMBOL(<fs_update>).     "获取更新条件
*    ASSIGN COMPONENT 'ZWHERE' OF STRUCTURE ls_bank_docs TO FIELD-SYMBOL(<fs_where>).       "获取取数条件
**    ASSIGN COMPONENT 'ZMODE' OF STRUCTURE ls_bank_docs TO FIELD-SYMBOL(<fs_mode>).         "获取处理模式
*
*    IF <fs_fn> IS ASSIGNED AND <fs_fn> IS INITIAL.
*      set_msg 'E' 'ZTR02' '496' <fs_t> '' '' '' ''.
*      RETURN.
*    ENDIF.
*
*    CREATE DATA lr_data TYPE TABLE OF (<fs_t>).
*    ASSIGN lr_data->* TO <lt_data>.               "动态创建内表
*
*    IF <fs_where> IS ASSIGNED AND <fs_where> IS NOT INITIAL.
*      cond =  |{ <fs_fn> } = '{ fieldvalue1 }' AND { <fs_where> } |.    "取数条件1
*    ELSE.
*      cond = |{ <fs_fn> } = '{ fieldvalue1 }' |.    "取数条件1
*    ENDIF.
*
*    TRY.
*        SELECT COUNT(*) FROM (<fs_t>) WHERE (cond).
*      CATCH cx_sy_dynamic_osql_syntax INTO DATA(lcx_error).
*        CLEAR error_text.
*        error_text = lcx_error->get_text( ).
*        set_msg 'E' 'ZTR02' '000' error_text '' '' '' ''.
*        RETURN.
*    ENDTRY.
*
*    TRY.
*        SELECT * FROM (<fs_t>) WHERE (cond) INTO CORRESPONDING FIELDS OF TABLE @<lt_data>.
*      CATCH cx_sy_arithmetic_error INTO DATA(lcl_error).
*
*    ENDTRY.
*    IF sy-subrc = 0.
*      LOOP AT <lt_data> ASSIGNING FIELD-SYMBOL(<fs_data>).
*        ASSIGN COMPONENT <fs_bukrs> OF STRUCTURE <fs_data> TO FIELD-SYMBOL(<fs_bukrs_v>).
*        ASSIGN COMPONENT <fs_kunnr> OF STRUCTURE <fs_data> TO FIELD-SYMBOL(<fs_kunnr_v>).
*        ASSIGN COMPONENT <fs_lifnr> OF STRUCTURE <fs_data> TO FIELD-SYMBOL(<fs_lifnr_v>).
*        ASSIGN COMPONENT <fs_hbkid> OF STRUCTURE <fs_data> TO FIELD-SYMBOL(<fs_hbkid_v>).
*        ASSIGN COMPONENT <fs_hktid> OF STRUCTURE <fs_data> TO FIELD-SYMBOL(<fs_hktid_v>).
*        ASSIGN COMPONENT <fs_trxno> OF STRUCTURE <fs_data> TO FIELD-SYMBOL(<fs_trxno_v>).
*        ASSIGN COMPONENT <fs_zbkitem> OF STRUCTURE <fs_data> TO FIELD-SYMBOL(<fs_zbkitem_v>).
*        ASSIGN COMPONENT <fs_dbkey> OF STRUCTURE <fs_data> TO FIELD-SYMBOL(<fs_dbkey_v>).
*        ASSIGN COMPONENT <fs_yhzh> OF STRUCTURE <fs_data> TO FIELD-SYMBOL(<fs_yhzh_v>).
*
*        IF <fs_dbkey_v> IS NOT ASSIGNED AND <fs_trxno_v> IS NOT ASSIGNED AND <fs_zbkitem> IS NOT ASSIGNED.
*          CONTINUE.
*        ENDIF.
*
*        IF <fs_dbkey_v> IS ASSIGNED AND <fs_dbkey_v> IS INITIAL.
*          IF <fs_trxno_v> IS ASSIGNED AND <fs_trxno_v> IS INITIAL.
*            IF <fs_zbkitem> IS ASSIGNED AND <fs_zbkitem> IS INITIAL.
*              CONTINUE.
*            ENDIF.
*          ENDIF.
*        ENDIF.
*
*        IF <fs_dbkey_v> IS ASSIGNED.   lv_dbkey = <fs_dbkey_v>.     ENDIF.
*        IF <fs_trxno_v> IS ASSIGNED.   lv_trxno = <fs_trxno_v>.     ENDIF.
*        IF <fs_zbkitem_v> IS ASSIGNED. lv_zbkitem = <fs_zbkitem_v>. ENDIF.
*        IF <fs_bukrs_v> IS ASSIGNED.   lv_bukrs = <fs_bukrs_v>.     ENDIF.
*        IF <fs_kunnr_v> IS ASSIGNED.   lv_kunnr = <fs_kunnr_v>.     ENDIF.
*        IF <fs_lifnr_v> IS ASSIGNED.   lv_lifnr = <fs_lifnr_v>.     ENDIF.
*        IF <fs_hbkid_v> IS ASSIGNED.   lv_hbkid = <fs_hbkid_v>.     ENDIF.
*        IF <fs_hktid_v> IS ASSIGNED.   lv_hktid = <fs_hktid_v>.     ENDIF.
*        IF <fs_yhzh_v> IS ASSIGNED.    lv_yhzh = <fs_yhzh_v>.       ENDIF.
*
*        PERFORM frm_get_bank_data TABLES lt_bank_dc
*           USING <fs_t> fieldvalue1 lv_trxno lv_dbkey lv_bukrs lv_kunnr lv_lifnr lv_hbkid lv_hktid lv_yhzh lv_zbkitem .
*
*      ENDLOOP.
*
*      PERFORM frm_execute_refdoc_mode TABLES lt_bank_dc lt_msg USING fieldvalue1 mode.
*
*    ENDIF.
*    CLEAR ls_bank_docs.
*  ENDLOOP.
*
*
*ENDFORM.
**&---------------------------------------------------------------------*
**&      Form  FRM_CHECK_450_QYRQ
**&---------------------------------------------------------------------*
**       text
**----------------------------------------------------------------------*
**      -->P_ET_TABLE  text
**----------------------------------------------------------------------*
*FORM frm_check_450_qyrq TABLES i_table STRUCTURE ztrs0100_3.
*
*  "取外销订单定金比例
*  SELECT * FROM zotct00450 INTO TABLE @DATA(lt_450).
**    FOR ALL ENTRIES IN @i_table
**    WHERE werks = @i_table-werks
**      AND zterm = @i_table-zterm.
*
*  "取460表收款指示单销售订单创建日期 >= 450表外销订单定金比例启用日期数据
*  LOOP AT i_table INTO DATA(ls_table).
*    READ TABLE lt_450 INTO DATA(ls_450) WITH KEY werks = ls_table-werks zterm = ls_table-zterm.
*    IF sy-subrc = 0.
*      IF ls_450-qyrq IS INITIAL. DELETE i_table. CONTINUE. ENDIF.
*      IF ls_table-erdat < ls_450-qyrq.
*        DELETE i_table.
*      ENDIF.
*    ELSE.
*      DELETE i_table.
*    ENDIF.
*  ENDLOOP.
*
*
*ENDFORM.
