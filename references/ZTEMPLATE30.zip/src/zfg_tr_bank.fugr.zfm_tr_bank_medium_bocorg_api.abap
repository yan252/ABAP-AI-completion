FUNCTION ZFM_TR_BANK_MEDIUM_BOCORG_API.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     VALUE(IM_T_TASKTYPE) TYPE  ZTRT_BOC_B2E0043_REQUEST_FIELD
*"--------------------------------------------------------------------
******  log
  IF im_t_tasktype IS INITIAL.
    RETURN.
  ENDIF.
  zcl_bank_logger_protocal=>set_api_starting_log( zif_bank_action=>action_is_get_cnaps_boc_org ).
******  log end
  DATA(lo_action) = zcl_bank_abstract_action=>create( zif_bank_action=>action_is_get_cnaps_boc_org ).
*  CHECK lo_action IS BOUND.
  IF lo_action IS BOUND.
    lo_action->set_entries( im_t_tasktype ).
    lo_action->run( ).
  ENDIF.
*  zcl_bank_logger_protocal=>end_logs( 'X' ).
  zcl_bank_logger_protocal=>end_logs( zif_bank_action=>action_is_get_cnaps_boc_org ).





ENDFUNCTION.
