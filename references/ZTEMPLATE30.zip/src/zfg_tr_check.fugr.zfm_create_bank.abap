FUNCTION ZFM_CREATE_BANK.
**"--------------------------------------------------------------------
**"*"局部接口：
**"  IMPORTING
**"     REFERENCE(DOCNO) TYPE  ZTR_DOCNO
**"     REFERENCE(TEST) TYPE  CHAR1 OPTIONAL
**"  EXPORTING
**"     REFERENCE(MSG) TYPE  STRING
**"     REFERENCE(BANKL) TYPE  BANKK
**"--------------------------------------------------------------------
*DATA ls_tr0014 TYPE ztrt0014.
*  DATA lv_numc TYPE numc10.
*  DATA lv_bankl TYPE bankk.
*  DATA lr_bankl TYPE RANGE OF bnka-bankl.
*  DATA ls_bankl LIKE LINE OF lr_bankl.
*  DATA msgtype  TYPE  bapi_mtype.
*
*  CLEAR msg.
*  SELECT SINGLE * INTO ls_tr0014
*    FROM ztrt0014
*    WHERE docno = docno.
*  IF sy-subrc <> 0.
*    msg = TEXT-e01.
*    RETURN.
*  ENDIF.
*
*
*  IF ls_tr0014-banks <> 'CN' AND ls_tr0014-bankl IS INITIAL.
*    ls_bankl-sign = 'I'.
*    ls_bankl-option = 'CP'.
*    ls_bankl-low = '1*'.
*    APPEND ls_bankl TO lr_bankl.
*    CLEAR lv_bankl.
*    SELECT MAX( bankl ) INTO lv_bankl FROM bnka
*      WHERE banks = ls_tr0014-banks AND bankl IN lr_bankl.
*    IF sy-subrc <> 0 OR lv_bankl IS INITIAL.
*      ls_tr0014-bankl = '1000000000'.
*    ELSE.
*      lv_numc =  lv_bankl.
*      lv_numc = lv_numc + 1.
*      ls_tr0014-bankl = lv_numc.
*    ENDIF.
*  ENDIF.
******************************"------------------------------ 发现接口创建的银行代码在前台修改时校验不通过，增加前台校验代码2020.4.8
*
*  INCLUDE ztr_fi01_input_check.
*
******************************" ------------------------------发现接口创建的银行代码在前台修改时校验不通过，增加前台校验代码2020.4.8
**创建
*  DATA: ls_address TYPE bapi1011_address,
*        ls_return  TYPE bapiret2,
*        lv_city    TYPE banks,
*        lv_bank    TYPE bankk.
*
*  ls_address-bank_name    = ls_tr0014-banka.
*  ls_address-street       = ls_tr0014-stras.
*  ls_address-city         = ls_tr0014-ort01.
*  ls_address-swift_code   = ls_tr0014-swift.
*  ls_address-bank_no      = ls_tr0014-bnklz.
*  ls_address-bank_branch  = ls_tr0014-brnch.
*  ls_address-region       = ls_tr0014-provz.
*
*  SET PARAMETER ID 'BDOCU' FIELD docno.
*
*  CALL FUNCTION 'BAPI_BANK_CREATE'
*    EXPORTING
*      bank_ctry           = ls_tr0014-banks
*      bank_key            = ls_tr0014-bankl
*      bank_address        = ls_address
*      i_xupdate           = ''
*      i_check_before_save = test
*    IMPORTING
*      return              = ls_return
*      bankcountry         = lv_city
*      bankkey             = lv_bank.
*  IF ls_return-type <> 'E' AND  ls_return-type <> 'A'.
*    IF test IS INITIAL.
*      bankl = ls_tr0014-bankl.
*      UPDATE ztrt0014 SET bankl = ls_tr0014-bankl WHERE docno = docno.
*      COMMIT WORK.
*      PERFORM update_bank_ind USING ls_tr0014-banks
*                                    ls_tr0014-bankl
*                                    ls_tr0014-bank_ind.
**发布银行代码
*      RANGES:
*        lr_banks FOR bnka-banks,
*        lr_rec   FOR t000-logsys.
*      DATA: lv_jobname    TYPE tbtcjob-jobname,
*            lv_jobcount   TYPE tbtcjob-jobcount,
*            lv_parameters TYPE pri_params.
*      lv_jobname = 'TR银行代码发布-' && ls_tr0014-banks && ls_tr0014-bankl.
*      APPEND VALUE #( sign = 'I' option = 'EQ' low = ls_tr0014-banks ) TO lr_banks.
*      CLEAR lr_bankl.
*      APPEND VALUE #(  sign = 'I' option = 'EQ' low = ls_tr0014-bankl ) TO lr_bankl.
*      lr_rec-sign = 'I'.
*      lr_rec-option = 'EQ'.
*      IF sy-mandt = '130'.
*        lr_rec-low = 'SRD_130_HQ'.
*      ELSEIF sy-mandt = '310'.
*        lr_rec-low = 'SRQCLNT310'.
*      ELSE.
*        lr_rec-low = 'SRPCLNT681'.
*      ENDIF.
*      APPEND lr_rec.
** V20210308    增加触发 同步CRM   -------------------------------
*      IF sy-mandt = '130'.
*        lr_rec-low = 'CRDCLNT130'.
*      ELSEIF sy-mandt = '310'.
*        lr_rec-low = 'CRQCLNT310'.
*      ELSE.
*        lr_rec-low = 'CRPCLNT685'.
*      ENDIF.
*      APPEND lr_rec.
** V20210308    增加触发 同步CRM ---------------------------------
*      CALL FUNCTION 'JOB_OPEN'
*        EXPORTING
*          jobname          = lv_jobname
*        IMPORTING
*          jobcount         = lv_jobcount
*        EXCEPTIONS
*          cant_create_job  = 1
*          invalid_job_data = 2
*          jobname_missing  = 3
*          OTHERS           = 4.
*      IF sy-subrc = 0.
*
*        SUBMIT rfbank_ale
*                           WITH banks IN lr_banks
*                           WITH bankl IN lr_bankl
*                           WITH testrun = abap_false
*                           WITH t_rec IN lr_rec
*                           VIA JOB lv_jobname NUMBER lv_jobcount
*                           AND RETURN.
*        IF sy-subrc = 0.
*          CALL FUNCTION 'JOB_CLOSE'
*            EXPORTING
*              jobcount             = lv_jobcount
*              jobname              = lv_jobname
*              strtimmed            = 'X'
*            EXCEPTIONS
*              cant_start_immediate = 1
*              invalid_startdate    = 2
*              jobname_missing      = 3
*              job_close_failed     = 4
*              job_nosteps          = 5
*              job_notex            = 6
*              lock_failed          = 7
*              OTHERS               = 8.
**      IF sy-subrc <> 0.
**        ...
**      ENDIF.
*        ENDIF.
*      ENDIF.
*    ENDIF.
*  ELSE.
*    msg = ls_return-message.
*  ENDIF.





ENDFUNCTION.
