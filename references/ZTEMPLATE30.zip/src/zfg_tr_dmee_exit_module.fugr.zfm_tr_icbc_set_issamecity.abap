FUNCTION ZFM_TR_ICBC_SET_ISSAMECITY.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     VALUE(I_TREE_TYPE) TYPE  DMEE_TREETYPE_ABA
*"     VALUE(I_TREE_ID) TYPE  DMEE_TREEID_ABA
*"     VALUE(I_ITEM)
*"     VALUE(I_PARAM)
*"     VALUE(I_UPARAM)
*"  EXPORTING
*"     REFERENCE(O_VALUE)
*"     REFERENCE(C_VALUE)
*"     REFERENCE(N_VALUE)
*"     REFERENCE(P_VALUE)
*"  TABLES
*"      I_TAB
*"--------------------------------------------------------------------
ASSIGN COMPONENT 'FPAYH' OF STRUCTURE i_item TO FIELD-SYMBOL(<fs_fpayh>).
  c_value = CONV #( zcl_icbc_enhancement=>set_issamecity( <fs_fpayh> ) ).





ENDFUNCTION.
