*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE lztrcapital_platformtop.           " Global Declarations
  INCLUDE lztrcapital_platformuxx.           " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZTRCAPITAL_PLATFORMF...           " Subroutines
* INCLUDE LZTRCAPITAL_PLATFORMO...           " PBO-Modules
* INCLUDE LZTRCAPITAL_PLATFORMI...           " PAI-Modules
* INCLUDE LZTRCAPITAL_PLATFORME...           " Events
* INCLUDE LZTRCAPITAL_PLATFORMP...           " Local class implement.
* INCLUDE LZTRCAPITAL_PLATFORMT99.           " ABAP Unit tests

  INCLUDE lztrcapital_platformo01.

  INCLUDE lztrcapital_platformi01.

  INCLUDE lztrcapital_platformf01.

  INCLUDE lztrcapital_platformpov.
