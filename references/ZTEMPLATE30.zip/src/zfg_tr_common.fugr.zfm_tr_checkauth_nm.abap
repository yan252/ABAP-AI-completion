FUNCTION ZFM_TR_CHECKAUTH_NM.
**"----------------------------------------------------------------------
**"*"本地接口：
**"  TABLES
**"      IT_BUKRS
**"      ET_AUTH_NM
**"----------------------------------------------------------------------
*DATA: BEGIN OF ls_auth_nm,
*          bukrs TYPE bukrs,
*          vkorg TYPE vkorg,
*        END OF ls_auth_nm,
*        lt_auth_nm LIKE TABLE OF ls_auth_nm.
*
*  SELECT * FROM ztr_sales_head INTO TABLE @DATA(lt_sales_head).
*
*  LOOP AT it_bukrs ASSIGNING FIELD-SYMBOL(<fs_bukrs>).
*    "检查公司代码是否配置为内贸公司
*    READ TABLE lt_sales_head INTO DATA(ls_sales_head) WITH KEY bukrs = <fs_bukrs>.
*    IF sy-subrc = 0.
*      IF ls_sales_head-vkorg IS NOT INITIAL.
*        "检查销售组织是否分配给公司代码
*        SELECT COUNT(*) FROM tvko WHERE bukrs = ls_sales_head-bukrs AND vkorg = ls_sales_head-vkorg.
*        IF sy-subrc = 0.
*          lt_auth_nm = VALUE #( BASE lt_auth_nm ( bukrs = ls_sales_head-bukrs vkorg = ls_sales_head-vkorg )  ).
*        ENDIF.
*      ENDIF.
*
*      IF ls_sales_head-vkorg_dim IS NOT INITIAL.
*        "如果配置了模糊查询的销售组织，将其转换为对应的销售组织和公司代码
*        SPLIT ls_sales_head-vkorg_dim AT ',' INTO TABLE DATA(lt_vkorg).
*        IF sy-subrc = 0.
*          LOOP AT lt_vkorg INTO DATA(ls_vkorg).
*            REPLACE '*' IN ls_vkorg WITH '%'.
*            SELECT bukrs vkorg FROM tvko
*              APPENDING CORRESPONDING FIELDS OF TABLE lt_auth_nm
*              WHERE vkorg LIKE ls_vkorg
*                AND bukrs = ls_sales_head-bukrs.
*          ENDLOOP.
*        ENDIF.
*
*      ENDIF.
*    ENDIF.
*  ENDLOOP.
*
*  sort lt_auth_nm.
*  delete ADJACENT DUPLICATES FROM lt_auth_nm.
*
*  et_auth_nm[] = lt_auth_nm.
*
*



ENDFUNCTION.
