FUNCTION ZFM_GET_CHECK_NO.
**"--------------------------------------------------------------------
**"*"局部接口：
**"  IMPORTING
**"     REFERENCE(NO_RULE) TYPE  ZE_NORULE
**"     REFERENCE(CKPAGES) TYPE  ZE_PAGES
**"     REFERENCE(BEGNO) TYPE  ZE_PAGES
**"  EXPORTING
**"     REFERENCE(ERROR) TYPE  STRING
**"  TABLES
**"      ALL_NO OPTIONAL
**"--------------------------------------------------------------------
*TYPES: BEGIN OF lty_s_ckno,
*           ckno TYPE zel_ckno,
*         END OF lty_s_ckno.
*
*  DATA: lv_first    TYPE i,
*        lv_len      TYPE i,
*        lv_end      TYPE i,
*        lv_set      TYPE i,
*        lv_len_p2   TYPE i,
*        lv_len_rule TYPE i,
*        lv_add      TYPE i,
*        lv_times    TYPE i,
*        lv_error    TYPE char1,
*        lv_less     TYPE i,
*        lv_all      TYPE i,
*        lv_low      TYPE zel_ckno,
*        lv_high     TYPE zel_ckno,
*        lv_part1    TYPE ze_norule,
*        lv_part2    TYPE ze_norule,
*        lv_part3    TYPE ze_norule,
*        lv_full     TYPE c LENGTH 60,
*        lt_ckno     TYPE STANDARD TABLE OF lty_s_ckno,
*        ls_ckno     TYPE lty_s_ckno,
*        lt_result   TYPE match_result_tab,
*        ls_result   TYPE match_result.
*
*
*
*  FIND ALL OCCURRENCES OF 'X'  IN
*     no_rule
*     RESULTS lt_result.
**校验规则---替换部分的‘X’是否连续
*  IF lt_result IS INITIAL.
*    MESSAGE e002(ztr01) INTO error.
*    RETURN.
*  ENDIF.
*  LOOP AT lt_result INTO ls_result.
*    IF lv_set = 0.
*      lv_first = ls_result-offset."初始位置
*      lv_set = ls_result-offset.
*    ELSE.
*      lv_set = lv_set + 1.
*      IF lv_set <> ls_result-offset.
*        MESSAGE e001(ztr01) INTO error.
*        RETURN.
*      ENDIF.
*    ENDIF.
*  ENDLOOP.
*
*  lv_len = strlen( no_rule )."支票编码长度
*
*  lv_end = ls_result-offset + 1."替换长度结束位置+1
*
*  lv_part1 = no_rule+0(lv_first)."替换部门的前面
*
*  lv_len = lv_len - lv_end .
*
*  IF lv_len <> 0.
*    lv_part3 = no_rule+lv_end(lv_len).
*  ENDIF.
*
*  lv_len_rule = lv_end - lv_first.
*
*  DO ckpages TIMES.
*    CLEAR lv_less.
*    lv_part2 = begno + lv_times .
*    lv_times = lv_times + 1.
*    CONDENSE lv_part2 NO-GAPS.
*    lv_len_p2 = strlen( lv_part2 ).
**    if lv_len < lv_len_rule.
**      lv_error = 'X'.
**      MESSAGE e003(ztr01) INTO error.
**        RETURN.
**    endif.
*    lv_less = lv_len_rule - lv_len_p2.
*    IF lv_less > 0.
*      DO lv_less TIMES.
*        CONCATENATE '0' lv_part2 INTO lv_part2.
*      ENDDO.
*    ENDIF.
*    CONCATENATE lv_part1 lv_part2 lv_part3 INTO lv_full.
*    CONDENSE lv_full NO-GAPS .
*    ls_ckno-ckno = lv_full.
*    APPEND ls_ckno TO lt_ckno.
*    lv_all = strlen( lv_full ).
*    IF lv_all > 20.
*      MESSAGE e003(ztr01) INTO error.
*      RETURN.
*    ENDIF.
*    IF lv_times = 1.
*      lv_low = lv_full.
*    ENDIF.
*  ENDDO.
*
*  lv_high = lv_full.
*
**校验是否已存在
*  DATA: lr_range TYPE RANGE OF zel_ckno WITH HEADER LINE,
*        lv_ckno  TYPE zel_ckno.
*
*  lr_range-sign = 'I'.
*  lr_range-low = lv_low.
*  IF lv_high IS NOT INITIAL .
*    lr_range-high = lv_high.
*    lr_range-option = 'BT'.
*  ELSE.
*    lr_range-option = 'EQ'.
*  ENDIF.
*  APPEND lr_range.
*
*  SELECT SINGLE ckno INTO lv_ckno FROM ztrt0008
*    INNER JOIN ztrt0004
*    ON ztrt0004~ck_group = ztrt0008~ck_group
*    WHERE ckno IN lr_range AND zdel <> abap_true.
*  IF sy-subrc = 0.
*    MESSAGE e004(ztr01) INTO error.
*    RETURN.
*  ENDIF.
*
*  all_no[] = lt_ckno.





ENDFUNCTION.
