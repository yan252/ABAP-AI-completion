class ZCL_BANK_ABC_FUNCTION_TRANX definition
  public
  inheriting from ZCL_BANK_FUNCTION_TRANSACTIONS
  final
  create public .

public section.
protected section.

  methods PROCESSING_RESPONSE_INTL_CORE
    redefinition .
private section.
ENDCLASS.



CLASS ZCL_BANK_ABC_FUNCTION_TRANX IMPLEMENTATION.


  METHOD PROCESSING_RESPONSE_INTL_CORE.
*    processing_response_by_dbtable(
*                im_data_db_table = 'ZTRT_abc_TRNS'
*                im_detail_response_component = 'TRANS'
*                im_statuscode_componnet = 'H_STATUS-RSPCOD'
*                im_statustext_component = 'H_STATUS-RSPMSG'
*                im_db_account_number_field = 'ACTACN'
*                IM_BANK_ENTRY_ACCNUMBER_FIELD = space  ).

************************************************************


    FIELD-SYMBOLS: <FT_FORMATTED_DATA>  TYPE ZTRS_ACC_DATA_FROM_BANK_TAB.
    FIELD-SYMBOLS: <FT_BANK_ENTRIES>  TYPE ZTRT_ABC_TRNS_TAB."STANDARD TABLE.
    FIELD-SYMBOLS: <FS_RESPONSE>           TYPE ZTRS_ABC_CQRA10_RESPONSE.
    FIELD-SYMBOLS: <FT_DETAILS> TYPE STANDARD TABLE.
    FIELD-SYMBOLS: <FT_SENDING_DATA>    TYPE ZTRS_GENERAL_BANK_ACC_MEDIUM_T.
    DATA LO_RESPONSE_STRUCTRE_DESC TYPE REF TO CL_ABAP_STRUCTDESCR.
    DATA: L_STATUS_CODE TYPE STRING,
          L_STATUS_TEXT TYPE STRING.

    CREATE_ACTION_FORMATTED_DATA( ).
    ASSIGN ACTION_FORMATTED_RESPONSE_DATA->* TO <FT_FORMATTED_DATA>.

    DATA(LS_RESPONSE_DATA) = GET_CURRENT_RESPONSE_DATA( ).
    ASSIGN LS_RESPONSE_DATA-RESPONSE_REF->* TO <FS_RESPONSE>.
    " DATA(ls_sending_file) = get_current_sending_file( ).

    READ TABLE <FT_FORMATTED_DATA> ASSIGNING FIELD-SYMBOL(<FS_FORMATTED_DATA>)
    WITH KEY BANK_IND = 'ABC'"bank_indicator'
    DATA_TABLE = 'ZTRT_ABC_TRNS'."im_data_db_table.
    IF SY-SUBRC <> 0.
      APPEND INITIAL LINE TO <FT_FORMATTED_DATA> ASSIGNING <FS_FORMATTED_DATA>.
      <FS_FORMATTED_DATA>-DATA_TABLE = 'ZTRT_ABC_TRNS'."im_data_db_table.
      <FS_FORMATTED_DATA>-BANK_IND   = 'ABC'."bank_indicator.
      CREATE DATA <FS_FORMATTED_DATA>-DATA_VALUE_LIST TYPE TABLE OF (<FS_FORMATTED_DATA>-DATA_TABLE).
    ENDIF.
    ASSIGN <FS_FORMATTED_DATA>-DATA_VALUE_LIST->* TO <FT_BANK_ENTRIES>.

    DATA(FILE) = <FS_RESPONSE>-CMP-BATCHFILENAME.
*****从农行前置机获取明细交易数据

    TYPES: BEGIN OF T_TEXT,
             TEXT(2000) TYPE C,
           END OF T_TEXT.
    DATA: I_TEXT  TYPE TABLE OF T_TEXT,
          I_TEXT2 TYPE TABLE OF T_TEXT,
          MX      TYPE TABLE OF T_TEXT,
          MX1     TYPE TABLE OF T_TEXT,
          MXS     LIKE LINE OF MX,
          WA_TEXT TYPE T_TEXT,
          i_bintab TYPE w3mimetabtype .
    DATA:LV_HDL      TYPE I,
         LV_KEY      TYPE I VALUE 26101957,
         LV_SLEN     TYPE I,
         LV_CMD(120),
         LV_PWD      TYPE TEXT30,
         LI_RESULT   TYPE TABLE OF TEXT256 , "WITH HEADER LINE,
         LS_RESULT   TYPE TEXT256,
         RESULT      TYPE TABLE OF TEXT256,
         LV_DEST     TYPE RFCDES-RFCDEST,
         LV_FTPNAME  TYPE TEXT150,
         LN          TYPE I,
         bLEN         TYPE I.

    SELECT SINGLE *
      INTO @DATA(FTP)
      FROM ZTRT_BANK_CN_FTP
      WHERE BANK_IND = 'ABC'.

    LV_DEST = FTP-DEST.

*    IF sy-batch IS INITIAL.
*      lv_dest = 'SAPFTP'.
*    ELSE.
*      lv_dest = 'SAPFTPA'.
*    ENDIF.

    SET EXTENDED CHECK OFF.

* Connect to server

    LV_SLEN = STRLEN( FTP-PASSWD ).

    CALL FUNCTION 'HTTP_SCRAMBLE' "获取加密密码
      EXPORTING
        SOURCE      = FTP-PASSWD  "'abc@123!'
        SOURCELEN   = LV_SLEN
        KEY         = LV_KEY
      IMPORTING
        DESTINATION = LV_PWD.
*lv_pwd = ftp-passwd .
    DO 3 TIMES.
      CALL FUNCTION 'FTP_CONNECT' "连接ftp服务器
        EXPORTING
          USER            = FTP-UESR   "'abc' "p_user
          PASSWORD        = LV_PWD
          HOST            = FTP-HOST  "'172.18.4.127' "p_host
          RFC_DESTINATION = FTP-DEST
        IMPORTING
          HANDLE          = LV_HDL "连接的句柄
        EXCEPTIONS
          NOT_CONNECTED   = 1
          OTHERS          = 2.
      IF SY-SUBRC = 0.
        EXIT.
      ENDIF.
    ENDDO.

    " DATA(wrkdir) = ftp-wrkdir."   ''\PROGRAM Files (x86)\中国农业银行\中国农业银行银企通平台\detail'.
    CONCATENATE 'cd' FTP-WRKDIR INTO LV_CMD
    SEPARATED BY SPACE.

    CALL FUNCTION 'FTP_COMMAND' "打开目标文件夹
      EXPORTING
        HANDLE        = LV_HDL
        COMMAND       = LV_CMD
      TABLES
        DATA          = LI_RESULT
      EXCEPTIONS
        TCPIP_ERROR   = 1
        COMMAND_ERROR = 2
        DATA_ERROR    = 3.

    CLEAR: LI_RESULT.
    REFRESH LI_RESULT.

    LV_CMD = 'ls'.
    CALL FUNCTION 'FTP_COMMAND' "获取文件夹文件目录
      EXPORTING
        HANDLE        = LV_HDL
        COMMAND       = LV_CMD
      TABLES
        DATA          = LI_RESULT
      EXCEPTIONS
        TCPIP_ERROR   = 1
        COMMAND_ERROR = 2
        DATA_ERROR    = 3.


    LOOP AT LI_RESULT INTO LS_RESULT.
      SEARCH LS_RESULT FOR FILE .
      IF SY-SUBRC = 0.
        "  PERFORM ftp_reconnect.

*        CALL FUNCTION 'FTP_COMMAND'
*          EXPORTING
*            HANDLE        = LV_HDL
*            COMMAND       = 'BIN' "'ASCII'
*          TABLES
*            DATA          = RESULT
*          EXCEPTIONS
*            TCPIP_ERROR   = 1
*            COMMAND_ERROR = 2
*            DATA_ERROR    = 3.
*        CLEAR: RESULT.
*        REFRESH RESULT.


        LV_FTPNAME = FILE.
        REFRESH I_TEXT.
        CALL FUNCTION 'FTP_SERVER_TO_R3'
          EXPORTING
            HANDLE         = LV_HDL
            FNAME          = LV_FTPNAME
*            CHARACTER_MODE = 'X'
          IMPORTING
            BLOB_LENGTH    = bLEN
          TABLES
*            TEXT           = I_TEXT
            BLOB           = i_bintab
            .

        CALL FUNCTION 'SCMS_BINARY_TO_TEXT'
          EXPORTING
            INPUT_LENGTH  = BLEN
            ENCODING      = '8400' "4110:UTF8,8400：GB2312
          IMPORTING
            OUTPUT_LENGTH = BLEN
          TABLES
            BINARY_TAB    = i_bintab
            TEXT_TAB      = I_TEXT
          EXCEPTIONS
            FAILED        = 1
            OTHERS        = 2.

        IF I_TEXT[] IS NOT INITIAL.
          CLEAR:LN.
          REFRESH MX1.
          LOOP AT I_TEXT INTO WA_TEXT ."FROM 1.
            REFRESH MX.
            SPLIT WA_TEXT AT '|' INTO TABLE MX.
            IF LN IS INITIAL.
              LN = LINES( MX ) ."明细交易的字段数量
            ENDIF.
            APPEND LINES OF MX[] TO MX1[].

          ENDLOOP.

        ENDIF.
      ENDIF.

    ENDLOOP.
    CALL FUNCTION 'FTP_DISCONNECT'
      EXPORTING
        HANDLE = LV_HDL.


    CALL FUNCTION 'RFC_CONNECTION_CLOSE'
      EXPORTING
        DESTINATION = LV_DEST
      EXCEPTIONS
        OTHERS      = 1.


**********从农行前置机获取明细交易数据

    DATA(LS_SENDING_FILE) = GET_CURRENT_SENDING_FILE( ).

    ASSIGN SENDING_DATA_REFERENCE->* TO <FT_SENDING_DATA>.

    READ TABLE <FT_SENDING_DATA> INTO DATA(LS_SENDING_DATA)
             WITH KEY SEQNUMBER = CURRENT_SENDING_SEQUENCE.


    DATA: TB_FT_BANK_ENTRIES TYPE TABLE OF  ZTRT_ABC_TRNS.
    DATA: TS_FT_BANK_ENTRIES TYPE ZTRT_ABC_TRNS.
    DATA: IK TYPE I.
    IK = 0.

    LOOP AT MX1 INTO MXS.
      IK = IK + 1.
*
      CASE IK.
        WHEN 1.
          TS_FT_BANK_ENTRIES-DBPROV  = MXS-TEXT.
        WHEN 2.
          TS_FT_BANK_ENTRIES-ACCNO = MXS-TEXT.
        WHEN 3.
          TS_FT_BANK_ENTRIES-DBCUR = MXS-TEXT.
        WHEN 4.
          TS_FT_BANK_ENTRIES-TRDATE = MXS-TEXT.
        WHEN 5.
          TS_FT_BANK_ENTRIES-TIMESTAB = MXS-TEXT.
        WHEN 6.
          TS_FT_BANK_ENTRIES-JRNNO = MXS-TEXT.
        WHEN 7.
          TS_FT_BANK_ENTRIES-TRTYPE = MXS-TEXT.
        WHEN 8.
          TS_FT_BANK_ENTRIES-BANKNO = MXS-TEXT.
        WHEN 9.
          TS_FT_BANK_ENTRIES-ACCNAME = MXS-TEXT.
        WHEN 10.
          TS_FT_BANK_ENTRIES-AMTINDEX = MXS-TEXT.
        WHEN 11.
          TS_FT_BANK_ENTRIES-OPPPROV = MXS-TEXT.
        WHEN 12.
          TS_FT_BANK_ENTRIES-OPPACCNO = MXS-TEXT.
        WHEN 13.
          TS_FT_BANK_ENTRIES-OPPCUR = MXS-TEXT.
        WHEN 14.
          TS_FT_BANK_ENTRIES-OPPNAME = MXS-TEXT.
        WHEN 15.
          TS_FT_BANK_ENTRIES-OPPBKNAME = MXS-TEXT.
        WHEN 16.
          TS_FT_BANK_ENTRIES-CSHINDEX = MXS-TEXT.
        WHEN 17.
          TS_FT_BANK_ENTRIES-ERRDATE = MXS-TEXT.
        WHEN 18.
          TS_FT_BANK_ENTRIES-ERRVCHNO = MXS-TEXT.
        WHEN 19.
          TS_FT_BANK_ENTRIES-AMT = MXS-TEXT.
        WHEN 20.
          TS_FT_BANK_ENTRIES-BAL = MXS-TEXT.
        WHEN 21.
          TS_FT_BANK_ENTRIES-PREAMT = MXS-TEXT.
        WHEN 22.
          TS_FT_BANK_ENTRIES-TOTCHG = MXS-TEXT.
        WHEN 23.
          TS_FT_BANK_ENTRIES-VOUCHERTYPE = MXS-TEXT.
        WHEN 24.
          TS_FT_BANK_ENTRIES-VOUCHERPROV = MXS-TEXT.
        WHEN 25.
          TS_FT_BANK_ENTRIES-VOUCHERBAT = MXS-TEXT.
        WHEN 26.
          TS_FT_BANK_ENTRIES-VOUCHERNO = MXS-TEXT.
        WHEN 27.
          TS_FT_BANK_ENTRIES-CUSTREF = MXS-TEXT.
        WHEN 28.
          TS_FT_BANK_ENTRIES-TELLER = MXS-TEXT.
        WHEN 29.
          TS_FT_BANK_ENTRIES-TRANSCODE = MXS-TEXT.
        WHEN 30.
          TS_FT_BANK_ENTRIES-VCHNO = MXS-TEXT.
        WHEN 31.
          TS_FT_BANK_ENTRIES-ABS = MXS-TEXT.
        WHEN 32.
          TS_FT_BANK_ENTRIES-POSTSCRIPT = MXS-TEXT.
        WHEN 33.
          TS_FT_BANK_ENTRIES-TRFROM = MXS-TEXT.

*******预留三个明细字段，防止农行增加字段
        WHEN 34.
          TS_FT_BANK_ENTRIES-YL1 = MXS-TEXT.
        WHEN 35.
          TS_FT_BANK_ENTRIES-YL2 = MXS-TEXT.
        WHEN 36.
          TS_FT_BANK_ENTRIES-YL3 = MXS-TEXT.

      ENDCASE.

      IF IK = LN."33.
        MOVE-CORRESPONDING LS_SENDING_DATA-SAP_FIELDS TO TS_FT_BANK_ENTRIES-SAP_FIELDS.

        TS_FT_BANK_ENTRIES-DBACCNO = TS_FT_BANK_ENTRIES-DBPROV && TS_FT_BANK_ENTRIES-ACCNO.
        APPEND TS_FT_BANK_ENTRIES  TO TB_FT_BANK_ENTRIES .
        IK = 0.
      ENDIF.
    ENDLOOP.

    " APPEND ts_ft_bank_entries  TO tb_ft_bank_entries .
    CLEAR:LS_SENDING_DATA.

    CREATE_ACTION_FORMATTED_DATA( ).

    <FT_BANK_ENTRIES> = TB_FT_BANK_ENTRIES[].

    MESSAGE I224(ZTR_BANK_APPLICATION)
    WITH BANK_INDICATOR
    FUNCTION_CONFIG-BANK_FUNC
    L_STATUS_CODE
    L_STATUS_TEXT
    INTO DUMMY_MESSAGE.
    ZCL_BANK_LOGGER_PROTOCAL=>ADD_LOG(
    VALUE #( UUID         = INSTANCE_UUID
    MSGID        = SY-MSGID
    MSGNO        = SY-MSGNO
    MSGTY        = SY-MSGTY
    MSGV1        = SY-MSGV1
    MSGV2        = SY-MSGV2
    MSGV3        = SY-MSGV3
    MSGV4        = SY-MSGV4
    MESSAGE      = DUMMY_MESSAGE
    BANK_ACTION  = ACTION
    BANK_IND     = BANK_INDICATOR
    BANK_FUNC    = FUNCTION_CONFIG-BANK_FUNC
    STEP         = STEP
    LOG_OBJ      = LS_SENDING_DATA-BANKN
    LOG_OBJ_TYPE  = ZCL_BANK_APPLICATION_LOGGER=>LOG_OBJECT_TYPE_BANK_ACCOUNT
    FILE_UUID     = LS_RESPONSE_DATA-FILE_UUID
    COUNTER_FILE_UUID = LS_SENDING_FILE-FILE_UUID ) ).

    CHECK_RESPONSE_IF_FINISHED( ).


  ENDMETHOD.
ENDCLASS.
