class ZCL_BANK_FILE_ADJUSTER_BOC definition
  public
  inheriting from ZCL_BANK_FILE_ADJUSTER
  final
  create public .

public section.

  methods ZIF_SENDING_FILE_ADJUSTER~ADJUST
    redefinition .
protected section.
private section.

  methods GET_TOCKEN_RESPONSE
    returning
      value(RS_TOKEN_RESPONSE) type ZTRT_BOC_TOKEN .
  methods RESET_FILE_BY_TOKEN_RESPONSE
    importing
      !IM_TOKEN_RESPONSE type ZTRT_BOC_TOKEN
    exporting
      !ET_RETURN_ERRORS type BAPIRET2_TAB
    changing
      !CH_CFILE_REF type ref to DATA
      !CH_XFILE_REF type ref to DATA .
ENDCLASS.



CLASS ZCL_BANK_FILE_ADJUSTER_BOC IMPLEMENTATION.


METHOD get_tocken_response.
    CONSTANTS: c_token_step              TYPE ztrt_action_step-step VALUE '001', "签到步骤
               c_token_sending_sequence  TYPE i VALUE 1,
               c_token_response_sequence TYPE i VALUE 1.
    DATA:lo_function TYPE REF TO zcl_bank_boc_b2e0001.

*    DATA(ls_tocken_response_ref) =
*           zcl_bank_abstract_action=>get_action(                    "get current running action
*                             )->get_bank( 'BOC'         "get current running bank
*                                        )->get_bank_function( c_token_step "get run function by step number
*                                               )->get_response_data_by_sequence(     " get response data of a function
*                                                     im_sending_sequence  = c_token_sending_sequence
*                                                     im_response_sequence = c_token_response_sequence ).

    lo_function ?=
           zcl_bank_abstract_action=>get_action(                    "get current running action
                             )->get_bank( 'BOC'         "get current running bank
                                        )->get_bank_function( c_token_step )."get run function by step number

    rs_token_response = lo_function->get_current_token( ).
*    ASSIGN ls_tocken_response_ref-RESPONSE_REF->* TO FIELD-SYMBOL(<fs_tocken_response>).
*    rs_token_response = <fs_tocken_response>.
  ENDMETHOD.


METHOD reset_file_by_token_response.
    DATA: l_xml_string  TYPE string,
          l_xml_xstring TYPE xstring.

    IF ch_cfile_ref IS BOUND.
      ASSIGN ch_cfile_ref->* TO FIELD-SYMBOL(<f_xml_string>).
      l_xml_string = <f_xml_string> .
    ENDIF.

    IF ch_xfile_ref IS BOUND.
      ASSIGN ch_xfile_ref->* TO FIELD-SYMBOL(<f_xml_xstring>).
      l_xml_xstring = <f_xml_xstring>.
    ENDIF.

    zcl_bank_data_mapping_engine=>reset_element_value(
                EXPORTING
                  im_t_element_values = VALUE ztrs_xml_element_value_tab(
                                                   ( name = zif_boc_constants=>file_field_termid
                                                     data = im_token_response-termid )
                                                   ( name = zif_boc_constants=>file_field_trnid
                                                     data = im_token_response-trnid )
                                                   ( name = zif_boc_constants=>file_field_custid
                                                     data = im_token_response-custid )
                                                   ( name = zif_boc_constants=>file_field_cusopr
                                                     data = im_token_response-cusopr )
                                                   ( name = zif_boc_constants=>file_field_token
                                                     data = im_token_response-token ) )
               IMPORTING
                 et_return_errors  = et_return_errors
               CHANGING
                 ch_xml_string     = l_xml_string
                 ch_xml_xstring    = l_xml_xstring ).

    IF et_return_errors IS INITIAL.
      IF <f_xml_string> IS ASSIGNED .
        <f_xml_string> = l_xml_string.
      ENDIF.

      IF <f_xml_xstring> IS ASSIGNED .
        <f_xml_xstring> = l_xml_xstring.
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD zif_sending_file_adjuster~adjust.
    IF im_step < '002'.
*    这个情况是签到，不需要调整
      RETURN.
    ENDIF.

    DATA(ls_token_response) = get_tocken_response( ).
    LOOP AT ch_data ASSIGNING FIELD-SYMBOL(<fs_sending_file>).
      reset_file_by_token_response(
               EXPORTING
                 im_token_response  = ls_token_response
               IMPORTING
                 et_return_errors   = ex_t_return
               CHANGING
                 ch_cfile_ref       = <fs_sending_file>-cfile
                 ch_xfile_ref       = <fs_sending_file>-xfile ).

      IF ex_t_return IS NOT INITIAL.
        EXIT.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.
ENDCLASS.
