*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_TR2_BANK_DBLBCXTOP.           " Global Declarations
  INCLUDE LZFG_TR2_BANK_DBLBCXUXX.           " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_TR2_BANK_DBLBCXF...           " Subroutines
* INCLUDE LZFG_TR2_BANK_DBLBCXO...           " PBO-Modules
* INCLUDE LZFG_TR2_BANK_DBLBCXI...           " PAI-Modules
* INCLUDE LZFG_TR2_BANK_DBLBCXE...           " Events
* INCLUDE LZFG_TR2_BANK_DBLBCXP...           " Local class implement.
* INCLUDE LZFG_TR2_BANK_DBLBCXT99.           " ABAP Unit tests
