FUNCTION ZFM_TR_GET_BANKID.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     REFERENCE(ZBNKN) TYPE  ZTR_YHZH
*"     REFERENCE(BUKRS) TYPE  BUKRS
*"     REFERENCE(ZZFWAERS) TYPE  ZTR_ZFWAERS
*"     REFERENCE(BANKL) TYPE  BANKL OPTIONAL
*"  EXPORTING
*"     REFERENCE(HBKID) TYPE  HBKID
*"     REFERENCE(HKTID) TYPE  HKTID
*"--------------------------------------------------------------------
SELECT SINGLE hbkid hktid INTO ( hbkid,hktid )
    FROM ztrt0013
    WHERE bukrs = bukrs AND waers = zzfwaers
      AND yhzh = zbnkn AND bankl = bankl.





ENDFUNCTION.
