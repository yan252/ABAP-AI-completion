FUNCTION ZFM_TR_BANK_MEDIUM_PAYMENT_API.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     VALUE(IM_T_ORDER_LIST) TYPE  ZTRS_PAYMENTORDER_LIST_TAB
*"--------------------------------------------------------------------
DATA l_task TYPE char20.

  LOOP AT zcl_bank_api_dispatcher=>dispatch_payments( im_t_order_list )
              INTO DATA(ls_orders_by_action).
    l_task = ls_orders_by_action-bank_ind &&
             ls_orders_by_action-action &&
             sy-uname &&
             sy-uzeit.
    CALL FUNCTION 'ZFM_TR_BANK_PAYMNT_CORE' DESTINATION 'NONE'
      STARTING NEW TASK l_task
      EXPORTING
        im_t_order_list       = ls_orders_by_action-orders
        im_action             = ls_orders_by_action-action
      EXCEPTIONS
        communication_failure = 1
        system_failure        = 2.
    IF sy-subrc <> 0.
*  let it be
      CONTINUE.
    ENDIF.
  ENDLOOP.





ENDFUNCTION.
