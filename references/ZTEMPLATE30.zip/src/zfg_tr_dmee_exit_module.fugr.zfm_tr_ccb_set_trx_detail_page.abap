FUNCTION ZFM_TR_CCB_SET_TRX_DETAIL_PAGE.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     VALUE(I_TREE_TYPE) TYPE  DMEE_TREETYPE_ABA
*"     VALUE(I_TREE_ID) TYPE  DMEE_TREEID_ABA
*"     VALUE(I_ITEM)
*"     VALUE(I_PARAM)
*"     VALUE(I_UPARAM)
*"  EXPORTING
*"     REFERENCE(O_VALUE)
*"     REFERENCE(C_VALUE)
*"     REFERENCE(N_VALUE)
*"     REFERENCE(P_VALUE)
*"  TABLES
*"      I_TAB
*"--------------------------------------------------------------------
DATA: l_string TYPE string.

  l_string = zcl_ccb_enhancement=>set_transaction_detail_page( i_item ).

  CONDENSE l_string.

  c_value = l_string.





ENDFUNCTION.
