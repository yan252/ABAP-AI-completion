FUNCTION ZFM_TR_PAYMORD_WD_ENCRY_IN_GUI.
*"--------------------------------------------------------------------
*"*"局部接口：
*"--------------------------------------------------------------------
DATA:ls_2001     TYPE ztrt2001,
       ls_2002     TYPE ztrt2002,
       ls_2003     TYPE ztrt2003,
       ls_2101     TYPE ztrt2101,
       ls_ssf_paym TYPE ztrt_paym_ssf,
       ls_syst     TYPE syst,
       l_read      TYPE flag,
       l_docno     TYPE ztrt2001-docno.

  DO 1000 TIMES.
    CALL FUNCTION 'ZFM_TR_PAYMORDER_SSF_READ_ORD'
      IMPORTING
        ex_s_paym_ssf = ls_ssf_paym
        ex_s_2101     = ls_2101
        ex_s_2001     = ls_2001
        ex_s_2002     = ls_2002
        ex_s_2003     = ls_2003
      EXCEPTIONS
        error         = 1
        OTHERS        = 2.
    IF sy-subrc <> 0.
      WAIT UP TO 1 SECONDS.
      CONTINUE.
    ELSE.
      l_read = 'X'.
      EXIT.
    ENDIF.
  ENDDO.

  IF l_read = space.
*    不应该出现这个情况，缓存表的更新不可能会在1000秒都不成功
*    如果出现这个情况，SSF没完成，webdynpro报错，不更新支付单
    RETURN.
  ENDIF.
  IF ls_ssf_paym-ssfuuid IS NOT INITIAL.
    IF ls_ssf_paym-zzftype = 'P004'.
      l_docno = ls_2101-docno.
    ELSE.
      l_docno = ls_2001-docno.
    ENDIF.

    PERFORM ssf_compare_paymord_single
                USING
                   l_docno
                   ls_ssf_paym-zzftype
                CHANGING
                   ls_syst.

  ENDIF.

  IF ls_syst-msgty <> 'E' AND
     ls_syst-msgty <> 'A' AND
     ls_syst-msgty <> 'X'.
    PERFORM ssf_encrypt_paymord_single
                USING
                   ls_2101
                   ls_2001
                   ls_2002
                   ls_2003
                   'X'
                   ls_ssf_paym-zzftype
                CHANGING
                   ls_ssf_paym-ssfuuid
                   ls_syst.
  ENDIF.

  ls_ssf_paym-completion = 'X'.
  MOVE: ls_syst-msgid TO ls_ssf_paym-msgid,
        ls_syst-msgty TO ls_ssf_paym-msgty,
        ls_syst-msgno TO ls_ssf_paym-msgno,
        ls_syst-msgv1 TO ls_ssf_paym-msgv1,
        ls_syst-msgv2 TO ls_ssf_paym-msgv2,
        ls_syst-msgv3 TO ls_ssf_paym-msgv3,
        ls_syst-msgv4 TO ls_ssf_paym-msgv4.

  CALL FUNCTION 'ZFM_TR_PAYMORDER_SSF_BUFF_SAVE'
    EXPORTING
      im_s_paym_ssf = ls_ssf_paym.





ENDFUNCTION.
