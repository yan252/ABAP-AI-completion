class ZCL_BANK_CITIC_FUNCTION_TRANX definition
  public
  inheriting from ZCL_BANK_FUNCTION_TRANSACTIONS
  final
  create public .

public section.

  methods ZIF_BANK_FUNCTION~SET_SENDING_DATA_REFERENCE
    redefinition .
protected section.

  methods CHECK_RESPONSE_IF_FINISHED
    redefinition .
  methods PROCESSING_RESPONSE_INTL_CORE
    redefinition .
private section.
ENDCLASS.



CLASS ZCL_BANK_CITIC_FUNCTION_TRANX IMPLEMENTATION.


METHOD check_response_if_finished.
    FIELD-SYMBOLS: <fs_response>        TYPE ztrs_citic_dltrnall_response.
    CONSTANTS: c_startrecord TYPE string VALUE 'startRecord',
               c_pagenumber  TYPE string VALUE 'pageNumber'.

    DATA(ls_sending_xml_ref) = get_sending_file_by_sequence( current_sending_sequence ).
    ASSIGN ls_sending_xml_ref-cfile->* TO FIELD-SYMBOL(<f_xml_string>).
*    DATA(l_sending_xml_ref_x) = get_sending_file_by_sequence(
*                                     im_x_reference = yes
*                                     im_sequence = current_sending_sequence ).
    ASSIGN ls_sending_xml_ref-xfile->* TO FIELD-SYMBOL(<f_xml_xstring>).

    zcl_bank_data_mapping_engine=>get_element_value(
                                     EXPORTING
                                       im_xml_string = <f_xml_string>
                                       im_t_fieldname = VALUE ztrs_fieldname_tab( ( name = c_startrecord )
                                                                                  ( name = c_pagenumber ) )
                                     IMPORTING
                                       ex_t_return_errors = DATA(lt_return_errors)
                                       ex_t_element_values = DATA(lt_element_values) ).

    IF lt_return_errors IS NOT INITIAL.
      messages->add_message_set( lt_return_errors ).
      current_response_is_finished = yes.
      RETURN.
    ENDIF.

    READ TABLE lt_element_values ASSIGNING FIELD-SYMBOL(<fs_startrecord>)
         WITH KEY name = c_startrecord.

    READ TABLE lt_element_values ASSIGNING FIELD-SYMBOL(<fs_pagenumber>)
         WITH KEY name = c_pagenumber.

    DATA(ls_response_data) = get_current_response_data( ).
    ASSIGN ls_response_data-response_ref->* TO <fs_response>.

    IF ( <fs_response>-stream-returnrecords < <fs_pagenumber>-data ) OR
        ( <fs_response>-stream-row IS INITIAL ).
*      当前没有返回明细记录，或返回明细记录小于请求的条目数，视为完成
      current_response_is_finished = yes.
      RETURN.
    ELSE.
*  not finished
      <fs_startrecord>-data = <fs_startrecord>-data + function_config-max_resp_item.
      SHIFT <fs_startrecord>-data LEFT DELETING LEADING '0'.
      CONDENSE <fs_startrecord>-data.
      <fs_pagenumber>-data = function_config-max_resp_item.
      SHIFT <fs_pagenumber>-data LEFT DELETING LEADING '0'.
      CONDENSE <fs_pagenumber>-data.

      zcl_bank_data_mapping_engine=>reset_element_value(
                                       EXPORTING
                                         im_t_element_values = lt_element_values
                                       IMPORTING
                                         et_return_errors = lt_return_errors
                                       CHANGING
                                         ch_xml_xstring = <f_xml_xstring>
                                         ch_xml_string = <f_xml_string> ).
      IF lt_return_errors IS NOT INITIAL.
        messages->add_message_set( lt_return_errors ).
        current_response_is_finished = yes.
        RETURN.
      ELSE.
        current_response_is_finished = no.
      ENDIF.
    ENDIF.


  ENDMETHOD.


METHOD processing_response_intl_core.
    processing_response_by_dbtable(
                im_data_db_table = 'ZTRT_CITIC_TRNS'
                im_detail_response_component = 'STREAM-ROW'
                im_statuscode_componnet = 'STREAM-STATUS'
                im_statustext_component = 'STREAM-STATUSTEXT'
*                im_account_number_field = 'ACCOUNTNO'   ).
                im_db_account_number_field = 'ACCOUNTNO'
                IM_BANK_ENTRY_ACCNUMBER_FIELD = space   ).
  ENDMETHOD.


METHOD zif_bank_function~set_sending_data_reference.
    FIELD-SYMBOLS: <ft_data> TYPE ZTRS_GENERAL_BANK_ACC_MEDIUM_T.
    DATA: lt_data TYPE ZTRS_GENERAL_BANK_ACC_MEDIUM_T.
    DATA: l_date_temp TYPE datum,
          l_high_date TYPE datum.
    CONSTANTS: c_date_range TYPE i VALUE 89. "中信银行交易明细查询最大能查90天

    super->set_sending_data_reference( im_data_reference ).

    ASSIGN sending_data_reference->* TO <ft_data>.

    LOOP AT <ft_data> INTO DATA(ls_data).
      l_high_date = ls_data-end_date.

      DO.
        l_date_temp = ls_data-start_date + c_date_range.

        IF l_high_date > l_date_temp.
          ls_data-end_date = l_date_temp.
          APPEND ls_data TO lt_data.
          ls_data-start_date = l_date_temp + 1.
        ELSE.
          ls_data-end_date = l_high_date.
          APPEND ls_data TO lt_data.
          EXIT.
        ENDIF.
      ENDDO.
    ENDLOOP.

    <ft_data> = lt_data.
  ENDMETHOD.
ENDCLASS.
