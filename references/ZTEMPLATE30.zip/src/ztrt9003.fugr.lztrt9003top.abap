FUNCTION-POOL ZTRT9003                   MESSAGE-ID SV.

* INCLUDE LZTRT9003D...                      " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZTRT9003T00                            . "view rel. data dcl.
