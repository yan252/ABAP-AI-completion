*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_TR_RFCTOP.                    " Global Declarations
  INCLUDE LZFG_TR_RFCUXX.                    " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_TR_RFCF...                    " Subroutines
* INCLUDE LZFG_TR_RFCO...                    " PBO-Modules
* INCLUDE LZFG_TR_RFCI...                    " PAI-Modules
* INCLUDE LZFG_TR_RFCE...                    " Events
* INCLUDE LZFG_TR_RFCP...                    " Local class implement.
* INCLUDE LZFG_TR_RFCT99.                    " ABAP Unit tests
