FUNCTION ZFM_TR2_BANK_DQCX_CITIC.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     REFERENCE(LT_IN) TYPE  ZLTTR2_BANK_QUERY_DEPOSIT_IN
*"  EXPORTING
*"     REFERENCE(LT_OUT) TYPE  ZLTTR2_BANK_QUERY_DEPOSIT_OUT
*"--------------------------------------------------------------------
DATA:BEGIN OF ls_data,
         action    TYPE string,
         username  TYPE string,
         accountno TYPE string,
         qryflg    TYPE string,
         openchanl TYPE string,
         qrytype   TYPE string,
         startdate TYPE string,
         enddate   TYPE string,
       END OF ls_data.

  TYPES:BEGIN OF ly_row,
          accountno TYPE string,
          accountnm TYPE string,
          fixaccno  TYPE string,
          perd      TYPE string,
          ratedate  TYPE string,
          orbl      TYPE string,
          balance   TYPE string,
          rate      TYPE string,
          wdtp      TYPE string,
          opendate  TYPE string,
          duedate   TYPE string,
          crytype   TYPE string,
        END OF ly_row.


  DATA:BEGIN OF ls_response,
         status     TYPE string,
         statustext TYPE string,
         row        TYPE ly_row OCCURS 0,
       END OF ls_response.

  DATA:response TYPE string.

  DATA:temp_in TYPE zlttr2_bank_query_deposit_in.


  DATA(lo_xml) = NEW zcl_tr2_xml( ).

  temp_in = CORRESPONDING #( lt_in[] ).

  SORT temp_in BY accountno .
  DELETE ADJACENT DUPLICATES FROM temp_in COMPARING accountno.

  LOOP AT temp_in INTO DATA(ls_in).
*    APPEND INITIAL LINE TO ls_data-stream ASSIGNING FIELD-SYMBOL(<fs_data>).
    ls_data-action = 'DLFNDQRY'.
    ls_data-username = CONV #( zcl_citic_enhancement=>get_user_name( ) ).
    ls_data-accountno = ls_in-accountno.
    ls_data-qryflg = ls_in-cxbs.
    ls_data-openchanl = ls_in-khqd.
    ls_data-qrytype   = ls_in-cxlx.
    ls_data-startdate = ls_in-qsrq.
    ls_data-enddate   = ls_in-jzrq.

    CALL FUNCTION 'ZFM_TR2_BANK_SEND'
      EXPORTING
        bank_ind    = 'CBI' "中国银行
        bank_action = '001' "票据查询
        data_in     = ls_data
        method      = 'POST'
      IMPORTING
        response    = response.

    lo_xml->convert_xml_to_abap( EXPORTING response = response bank_ind = 'CBI' bank_action = '001' IMPORTING data = ls_response ).
    IF ls_data IS NOT INITIAL.
      LOOP AT ls_response-row INTO DATA(ls_row).
        APPEND INITIAL LINE TO lt_out ASSIGNING FIELD-SYMBOL(<fs_out>).
        <fs_out>-jyzt   = ls_response-status.
        <fs_out>-jyztxx = ls_response-statustext.
        <fs_out>-hqzh   = ls_row-accountno.
        <fs_out>-hqzhmc = ls_row-accountnm.
        <fs_out>-dqzh   = ls_row-fixaccno .
        <fs_out>-cq     = ls_row-perd     .
        <fs_out>-qxrq   = ls_row-ratedate .
        <fs_out>-ysbj   = ls_row-orbl     .
        <fs_out>-zhye   = ls_row-balance  .
        <fs_out>-ll     = ls_row-rate     .
        <fs_out>-zjfs   = ls_row-wdtp     .
        <fs_out>-kkrq   = ls_row-opendate .
        <fs_out>-dqr    = ls_row-duedate  .
        <fs_out>-waers  = ls_row-crytype  .
        <fs_out>-erdat  = sy-datum.
        <fs_out>-erzet  = sy-uzeit.
      ENDLOOP.
      IF sy-subrc NE 0.
        IF ls_response-status IS NOT INITIAL.
          lt_out = CORRESPONDING #( temp_in ).
          LOOP AT lt_out ASSIGNING <fs_out>.
            <fs_out>-jyzt = ls_response-status.
            <fs_out>-jyztxx = ls_response-statustext.
          ENDLOOP.
        ELSE.
          lt_out = CORRESPONDING #( temp_in ).
          LOOP AT lt_out ASSIGNING <fs_out>.
*            <fs_out>-rspcod = ls_response-rspcod.
            <fs_out>-jyztxx = '调用银行接口失败'.
          ENDLOOP.
        ENDIF.
      ENDIF.
    ENDIF.

    CLEAR:ls_data,ls_response,response.
  ENDLOOP.





ENDFUNCTION.
