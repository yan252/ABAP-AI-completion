"Name: \PR:SAPMF02B\FO:PUBLISH_SWU_OBJECT\SE:END\EI
ENHANCEMENT 0 ZTR_MF02B00.
  DATA: l_bank_ind TYPE bnka-bank_ind.

  CALL FUNCTION 'ZFM_TR_SET_BANK_IND_TO_BNKA'
    EXPORTING
      im_banks       = bnka-banks
      im_bankl       = bnka-bankl
      im_banka       = conv CHAR255( bnka-banka )
      im_swift       = bnka-swift
      IM_SHOW_PROGRESS = space
      im_persistence = '1'
    IMPORTING
      ex_bank_ind    = l_bank_ind.

  IF bnka-bank_ind IS INITIAL.
    CLEAR ztrt_bankt.
  ELSE.
    SELECT SINGLE * FROM ztrt_bankt
           WHERE bank_ind = bnka-bank_ind
           AND   spras = sy-langu.
  ENDIF.
  LOOP AT SCREEN.
    IF screen-name = 'BNKA-BANK_IND'.
      IF screen-input = '1'.
*      可输入的情况下
        IF bnka-bank_ind IS NOT INITIAL AND
            l_bank_ind IS NOT INITIAL AND
          bnka-bank_ind = l_bank_ind.
*        银行代码带有银行行别和程序决定处理的行别一致，就不允许继续修改了
          screen-input = '0'.
        ENDIF.
      ENDIF.
    ENDIF.
    MODIFY SCREEN.
  ENDLOOP.
ENDENHANCEMENT.
