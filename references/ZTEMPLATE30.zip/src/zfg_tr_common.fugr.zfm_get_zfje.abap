FUNCTION ZFM_GET_ZFJE.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  TABLES
*"      ITEMS STRUCTURE  ZTR_S_BGUI
*"      RESULT STRUCTURE  ZTR_S_ZFJE
*"--------------------------------------------------------------------
CHECK items[] IS NOT INITIAL.

*挂账明细
  SELECT bguid zwe_flowd AS itemn  wrbtr_zf
         ztrt2001~docno zzfstatus
    INTO TABLE result
    FROM ztrt2004 INNER JOIN ztrt2001
    ON ztrt2004~docno = ztrt2001~docno
    FOR ALL ENTRIES IN items
    WHERE del_flg <> 'X'
      AND  zzfstatus <> '21' AND zzfstatus <> '29'
      AND zzfstatus <> '23' AND  zzfstatus <> '31' AND zzfstatus <> '57' AND zzfstatus <> '65'
      AND bguid = items-bguid AND zwe_flowd = items-itemn AND zzfstatus <> '64'.

*预付款
  SELECT bguid zwe_flowd AS itemn  wrbtr_zf
         ztrt2001~docno  zzfstatus
    APPENDING TABLE result
    FROM ztrt2005 INNER JOIN ztrt2001
    ON ztrt2005~docno = ztrt2001~docno
    FOR ALL ENTRIES IN items
    WHERE del_flg <> 'X'
      AND  zzfstatus <> '21' AND zzfstatus <> '29' AND zzfstatus <> '57'
      AND zzfstatus <> '23' AND  zzfstatus <> '31' AND zzfstatus <> '64' AND zzfstatus <> '62'
      AND bguid = items-bguid AND zwe_flowd = items-itemn AND zzfstatus <> '65'.

  SORT  result .
  DELETE ADJACENT DUPLICATES FROM result .





ENDFUNCTION.
