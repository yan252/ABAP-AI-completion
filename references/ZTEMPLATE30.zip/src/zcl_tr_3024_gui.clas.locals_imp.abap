*"* use this source file for the definition and implementation of
*"* local helper classes, interface definitions and type
*"* declarations

TYPES : BEGIN OF ty_grp ,
          sign   TYPE  char01,
          option TYPE char02,
          low    TYPE zbk_grp,
          high   TYPE zbk_grp,
        END OF ty_grp.

types ty_grpt type table of TY_GRP .

*DATA : mt_grp TYPE TABLE OF ty_grp .ZTRS_BANK_INFO
"types ty_BANK_DRAFT TYPE TABLE OF ZTRS_BANK_INFO.
