FUNCTION ZFM_TR2_BANK_DQZH_CITIC.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     REFERENCE(LT_IN) TYPE  ZLTTR2_BANK_REGULAR2CURRENT_IN
*"  EXPORTING
*"     REFERENCE(LT_OUT) TYPE  ZLTTR2_BANK_REGULAR2CURR_OUT
*"--------------------------------------------------------------------
DATA:BEGIN OF ls_data,
         action    TYPE string,
         username  TYPE string,
         clientid  TYPE string,
         accountno TYPE string,
         fixaccno  TYPE string,
         tranamt   TYPE string,
         drawtype  TYPE string,
         memo      TYPE string,
         abstract  TYPE string,
         eftdate   TYPE string,
       END OF ls_data.

  DATA:BEGIN OF ls_response,
         status     TYPE string,
         statustext TYPE string,
       END OF ls_response.

  DATA:response TYPE string.

  DATA:temp_in TYPE zlttr2_bank_regular2current_in.
  DATA:lv_log_uuid TYPE ztrt9504-log_uuid.


  DATA(lo_xml) = NEW zcl_tr2_xml( ).

  temp_in = CORRESPONDING #( lt_in[] ).

  SORT temp_in BY shdocno .
*  DELETE ADJACENT DUPLICATES FROM temp_in COMPARING accountno.

  LOOP AT temp_in INTO DATA(ls_in).
*    APPEND INITIAL LINE TO ls_data-stream ASSIGNING FIELD-SYMBOL(<fs_data>).
    ls_data-action = 'DLADVSUB'.
    ls_data-username = zcl_citic_enhancement=>get_user_name( ).
    ls_data-clientid = ls_in-shdocno && ls_in-zeile.
    ls_data-accountno = ls_in-zhqbnkn.
    ls_data-fixaccno = ls_in-zdqbnkn.
    ls_data-tranamt = ls_in-zjyje.
    ls_data-drawtype   = ls_in-zzqfs.
    ls_data-memo = ls_in-tzshbz.
    ls_data-eftdate   = ls_in-jqrq.

    CALL FUNCTION 'ZFM_TR2_BANK_SEND'
      EXPORTING
        bank_ind    = 'CBI' "中信国际
        bank_action = '002' "定期转活期
        data_in     = ls_data
        method      = 'POST'
      IMPORTING
        response    = response
        loguuid     = lv_log_uuid.

    lo_xml->convert_xml_to_abap( EXPORTING response = response bank_ind = 'CBI' bank_action = '002' IMPORTING data = ls_response ).
    IF ls_data IS NOT INITIAL.
      APPEND INITIAL LINE TO lt_out ASSIGNING FIELD-SYMBOL(<fs_out>).
      <fs_out>-log_uuid = lv_log_uuid.
      <fs_out>-shdocno = ls_in-shdocno.
      <fs_out>-zeile = ls_in-zeile.
      <fs_out>-bank_ind = ls_in-bank_ind.
      <fs_out>-jyzt   = ls_response-status.
      <fs_out>-jyztxx = ls_response-statustext.
    ENDIF.

    CLEAR:ls_data,ls_response,response.
  ENDLOOP.





ENDFUNCTION.
