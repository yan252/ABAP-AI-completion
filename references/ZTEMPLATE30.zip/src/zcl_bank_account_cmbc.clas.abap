class ZCL_BANK_ACCOUNT_CMBC definition
  public
  inheriting from ZCL_ABSTRACT_BANK_ACCOUNT
  final
  create public .

public section.
protected section.

  methods CONVERT_DATE
    importing
      !IM_DATE type CLIKE
    returning
      value(RE_DATE) type DATUM .

  methods BANK_BALANCE_TO_SAP
    redefinition .
  methods BANK_TRANSACTIONS_TO_SAP
    redefinition .
  methods SET_ACCOUNT_BALANCE_CORE
    redefinition .
  methods SET_ACCOUNT_TABNAME
    redefinition .
  methods SET_TRANSACTIONS_CORE
    redefinition .
  methods DEQUEUE_TRANSACTION
    redefinition .
private section.
ENDCLASS.



CLASS ZCL_BANK_ACCOUNT_CMBC IMPLEMENTATION.


METHOD bank_balance_to_sap.
    FIELD-SYMBOLS: <ft_new_account_balance> TYPE STANDARD TABLE.
    DATA: ls_balance_ext TYPE ztrt_cmbc_acbal.

    ASSIGN new_account_balance->* TO <ft_new_account_balance>.
    IF <ft_new_account_balance> IS NOT ASSIGNED OR
       <ft_new_account_balance> IS INITIAL.
      RETURN.
    ENDIF.

    LOOP AT <ft_new_account_balance> INTO ls_balance_ext.
      APPEND VALUE #(
                       bukrs        = ls_balance_ext-sap_bukrs
                       hbkid        = ls_balance_ext-sap_hbkid
                       hktid        = ls_balance_ext-sap_hktid
                       yhzh         = ls_balance_ext-acntno
                       bank_ind     = bank_indicator
                       zyue_ttl     = ls_balance_ext-ACCTBAL
                       zyue_frz     = ls_balance_ext-FRZBAL
                       zyue         = ls_balance_ext-avlbal
                       waers        = GET_ACCOUNT_CURRENCY( ls_balance_ext-sap_fields )
                       ) TO rt_balance.

    ENDLOOP.
  ENDMETHOD.


METHOD bank_transactions_to_sap.
    FIELD-SYMBOLS: <ft_new_transactions> TYPE STANDARD TABLE.
    DATA: ls_transactions_ext TYPE ztrt_cmbc_trns.

    ASSIGN new_transactions->* TO <ft_new_transactions>.
    IF <ft_new_transactions> IS NOT ASSIGNED OR
       <ft_new_transactions> IS INITIAL.
      RETURN.
    ENDIF.

    LOOP AT <ft_new_transactions> INTO ls_transactions_ext.
      DATA(l_shkzg) = zcl_cmbc_enhancement=>convert_debit_and_credit_flag( ls_transactions_ext-type ).
      DATA(ls_paymentkey) = get_paymkey_from_transaction( ls_transactions_ext-zexplain ).
*-----Begin 对方名称中的全角和半角括号去除后存入字段BKOINH1中 金志强 Add by KLTDEV5 20190726
      "字符串转换
      DATA:lv_bkoinh TYPE string.
      lv_bkoinh = ls_transactions_ext-opacntname.
      lv_bkoinh = convert_string( EXPORTING string = lv_bkoinh char = '(' ).
      lv_bkoinh = convert_string( EXPORTING string = lv_bkoinh char = ')' ).
      lv_bkoinh = convert_string( EXPORTING string = lv_bkoinh char = '（' ).
      lv_bkoinh = convert_string( EXPORTING string = lv_bkoinh char = '）' ).
*-----End 对方名称中的全角和半角括号去除后存入字段BKOINH1中 金志强 Add by KLTDEV5 20190726
      APPEND VALUE ztrt_bank_trans(
                       bukrs        = ls_transactions_ext-sap_bukrs
                       hbkid        = ls_transactions_ext-sap_hbkid
                       hktid        = ls_transactions_ext-sap_hktid
                       yhzh         = ls_transactions_ext-acntno
                       trxno        = ls_transactions_ext-recseq
                       bank_ind     = bank_indicator
                       trxdate      = ls_transactions_ext-actdate+0(4) &&
                                      ls_transactions_ext-actdate+5(2) &&
                                      ls_transactions_ext-actdate+8(2)
                       trxtime      = ls_transactions_ext-timestamp
                       shkzg        = l_shkzg
                       bkfse       = ls_transactions_ext-amount
                       trxamt        = convert_transamt_by_shkzg( im_shkzg        = l_shkzg
                                                                  im_original_amt = ls_transactions_ext-amount )
                       balamt       = ls_transactions_ext-balance
                       waers        = ls_transactions_ext-sap_waers
                       bzbnka       = ls_transactions_ext-opbankname
                       bzbnkn       = ls_transactions_ext-opacntno
                       bkoinh       = ls_transactions_ext-opacntname
                       abstract_txt = ls_transactions_ext-zexplain
                       paymentkey   = ls_paymentkey
                       zref_doc = ls_paymentkey-paymorder
                       intfdate     = system_info-datum
                       intftime     = system_info-uzeit
*                       kunnr2       = set_customer_code_by_name( ls_transactions_ext-opacntname )
*                       lifnr        = set_vendor_code_by_name( ls_transactions_ext-opacntname )
                       partner      = set_partner_by_name( ls_transactions_ext-opacntname )
                       bkoinh1      = lv_bkoinh
                       ) TO rt_transactions.

    ENDLOOP.
    finished_sap_tranx_fields(
               CHANGING
                 ch_t_tranx = rt_transactions ).
  ENDMETHOD.


method CONVERT_DATE.
re_date = im_date+0(4) &&
          im_date+5(2) &&
          im_date+8(2) .
  endmethod.


method DEQUEUE_TRANSACTION.
    DATA:ls_transaction TYPE ztrt_cmbc_trns.

    LOOP AT im_t_transactions INTO ls_transaction.
      dequeue_transaction_core(
                     im_bukrs = ls_transaction-sap_bukrs
                     im_hbkid = ls_transaction-sap_hbkid
                     im_hktid = ls_transaction-sap_hktid
                     im_yhzh = ls_transaction-acntno
                     im_trxno = ls_transaction-recseq ).
    ENDLOOP.
  endmethod.


METHOD set_account_balance_core.
    FIELD-SYMBOLS: <ft_acc_balance> TYPE ztrt_cmbc_acbal_tab.
    FIELD-SYMBOLS:<ft_new_entries> TYPE ztrt_cmbc_acbal_tab.
    DATA: l_new     TYPE flag,
          l_changed TYPE flag.

    ASSIGN im_data->* TO <ft_acc_balance>.

    ASSIGN new_account_balance->* TO <ft_new_entries>.

    IF <ft_acc_balance> IS INITIAL.
      RETURN.
    ENDIF.

    SELECT * INTO TABLE @DATA(lt_old_data)
           FROM ztrt_cmbc_acbal
           FOR ALL ENTRIES IN @<ft_acc_balance>
           WHERE acntno = @<ft_acc_balance>-acntno.

    LOOP AT <ft_acc_balance> INTO DATA(ls_acc_balance).
      CHECK filter_accbal_by_shifton_date(
                  EXPORTING
                    im_s_sap_field = ls_acc_balance-sap_fields ) = 'X'.
      READ TABLE lt_old_data INTO DATA(ls_old_data)
           WITH KEY acntno = ls_acc_balance-acntno.
      IF sy-subrc <> 0.
*      new
        l_new = 'X'.
      ELSE.
        IF ls_acc_balance-acc_field <> ls_old_data-acc_field.
          l_changed = 'X'.
        ENDIF.
      ENDIF.

      IF l_new = 'X' OR
         l_changed = 'X'.
        ls_acc_balance-dbadmin = ls_old_data-dbadmin.
        set_admin_fields(
                  EXPORTING
                    im_new_entry = l_new
                  CHANGING
                    cs_admin = ls_acc_balance-dbadmin ).
        APPEND ls_acc_balance TO <ft_new_entries>.
      ENDIF.

      CLEAR: l_new,
             l_changed.
    ENDLOOP.

  ENDMETHOD.


METHOD set_account_tabname.
    transaction_db_tabname = 'ZTRT_CMBC_TRNS'.
    account_balance_db_tabname = 'ZTRT_CMBC_ACBAL'.
    super->set_account_tabname( ).
  ENDMETHOD.


METHOD SET_TRANSACTIONS_CORE.
    FIELD-SYMBOLS: <ft_transactions> TYPE ztrt_cmbc_trns_tab.
    FIELD-SYMBOLS: <ft_new_entries> TYPE ztrt_cmbc_trns_tab.
    DATA: l_new     TYPE flag,
          l_changed TYPE flag.

    ASSIGN im_data->* TO <ft_transactions>.

    ASSIGN new_transactions->* TO <ft_new_entries>.

    IF <ft_transactions> is not ASSIGNED or
       <ft_transactions> IS INITIAL.
      RETURN.
    ENDIF.

    SELECT * INTO TABLE @DATA(lt_old_data)
           FROM ztrt_cmbc_trns
           FOR ALL ENTRIES IN @<ft_transactions>
           WHERE SVRID = @<ft_transactions>-SVRID.

    LOOP AT <ft_transactions> INTO DATA(ls_transactions).
      CHECK filter_trans_by_shifton_date(
                  EXPORTING
                    im_s_sap_field = ls_transactions-sap_fields
                    im_transaction_date = ls_transactions-actdate+0(4) &&
                                          ls_transactions-actdate+5(2) &&
                                          ls_transactions-actdate+8(2) ) = 'X'.
      enqueue_transaction_core(
                   EXPORTING
                     im_bukrs = ls_transactions-sap_bukrs
                     im_hbkid = ls_transactions-sap_hbkid
                     im_hktid = ls_transactions-sap_hktid
                     im_yhzh = ls_transactions-acntno
                     im_trxno = ls_transactions-recseq
                   IMPORTING
                     ex_enqueue_failed = DATA(l_enqueue_failed) ).
      IF l_enqueue_failed = yes.
*        被锁定，不纳入本次处理
        CLEAR l_enqueue_failed.
        CONTINUE.
      ENDIF.

      READ TABLE lt_old_data INTO DATA(ls_old_data)
           WITH KEY SVRID = ls_transactions-SVRID.
      IF sy-subrc <> 0.
*      new
        l_new = 'X'.
      ELSE.
        IF ls_transactions-trns_field <> ls_old_data-trns_field.
          l_changed = 'X'.
        ENDIF.
      ENDIF.

      IF l_new = 'X' OR
         l_changed = 'X'.
        ls_transactions-dbadmin = ls_old_data-dbadmin.
        set_admin_fields(
                  EXPORTING
                    im_new_entry = l_new
                  CHANGING
                    cs_admin = ls_transactions-dbadmin ).
        APPEND ls_transactions TO <ft_new_entries>.
        else.
        dequeue_transaction_core(
                     EXPORTING
                       im_bukrs = ls_transactions-sap_bukrs
                       im_hbkid = ls_transactions-sap_hbkid
                       im_hktid = ls_transactions-sap_hktid
                       im_yhzh = ls_transactions-acntno
                       im_trxno = ls_transactions-recseq ).
      ENDIF.

      CLEAR: l_new,
             l_changed,
             ls_old_data.
    ENDLOOP.

  ENDMETHOD.
ENDCLASS.
