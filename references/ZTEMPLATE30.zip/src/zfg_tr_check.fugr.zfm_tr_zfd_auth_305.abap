FUNCTION ZFM_TR_ZFD_AUTH_305.
**"--------------------------------------------------------------------
**"*"局部接口：
**"  IMPORTING
**"     REFERENCE(BUKRS) TYPE  BUKRS
**"     REFERENCE(ZZFTYPE) TYPE  ZTR_ZFTYPE
**"     REFERENCE(ACTIVE) TYPE  ZTR_ZFD_ATYPE
**"  EXCEPTIONS
**"      ERR
**"--------------------------------------------------------------------
*DATA: lv_string  TYPE string.
*  IF NOT  ( zcl_tr_3024_gui=>auth = abap_true OR sy-sysid = 'ERP' ).
*    sy-subrc = 0.
*    RETURN.
*  ENDIF.
*  AUTHORITY-CHECK OBJECT 'Z_TR305'
*    ID 'BUKRS' FIELD bukrs
*    ID 'ZTR_ZFTYPE' FIELD zzftype
*    ID 'ZTR_ATYPE' FIELD active.
*  IF sy-subrc <> 0.
*    zcl_wd_common=>get_dom_value(
*      EXPORTING
*        im_domnam = 'ZDM_TR_ZFTYPE'
*        im_domval = zzftype
*      RECEIVING
*        ex_desc   = lv_string
*    ).
*    CASE active.
*      WHEN '01'."管理
*        MESSAGE e222(ztr05) WITH bukrs lv_string  RAISING err.
*      WHEN '02'."过账
*        MESSAGE e223(ztr05) WITH bukrs lv_string  RAISING err.
*      WHEN '03'."查看
*        MESSAGE e220(ztr05) WITH bukrs lv_string  RAISING err.
*      WHEN OTHERS.
*    ENDCASE.
*  ENDIF.
*
*



ENDFUNCTION.
