class ZCL_TR2_COMMON definition
  public
  final
  create public .

public section.

  types:
    BEGIN OF ty_zoaref_no,
            ref_no TYPE zoaref_no,
          END OF ty_zoaref_no .
  types:
    tyt_zoaref_no TYPE TABLE OF ty_zoaref_no .


  class-methods ZFDTH_ACCEPT
    importing
      !IM_DATA type ZLTTR2_ZFDTHJS_IN
      !ZZD type ZTR2_SFTS optional
    returning
      value(EX_DATA) type ZLTTR2_ZFDTHJS_OUT .
  class-methods GET_WORKDAYS_BETWEEN_2_DATES
    importing
      !I_FROMDATE type D
      !I_TODATE type D
    returning
      value(E_DAYS) type I .
  class-methods GET_SNRO_NUMBER
    importing
      !OBJECT type INRI-OBJECT
      !NR_RANGE_NR type INRI-NRRANGENR
    exporting
      !E_TYPE type BAPI_MTYPE
      !E_MSG type BAPI_MSG
      value(E_NUMBER) type ANY .
  class-methods CHECK_NOT_INITIAL
    importing
      !IV_VALUE type DATA
      !IV_TEXT type STRING
    exporting
      value(ES_MESSAGE) type STRING
      !ES_TYPE type BAPI_MTYPE .
  class-methods CHECK_NEED_HWBC
    importing
      !IV_BUKRS type BUKRS
      !IV_HKTID_FK type HKTID
      !IV_HBKID_FK type HBKID
    returning
      value(RV_NEED) type ABAP_BOOL .
  class-methods CHECK_NEED_HWBC_ONLY_BUKRS
    importing
      !IV_BUKRS type BUKRS
    returning
      value(RV_NEED) type WDY_BOOLEAN .
  class-methods CONVERT_DATE_FORMAT
    importing
      !IV_DATE type C
      !IV_SEP type C default '/'
    returning
      value(RV_DATE) type STRING .
  class-methods GET_KKJE_BY_VBELN
    importing
      !IV_VBELN type VBELN_VF
      !IV_ZTERM type ZTERM
      !IV_KUNNR type KUNNR
    returning
      value(EV_KKJE) type ZTR2_KKJE .
  class-methods BATCH_DOWNLOAD_FILE
    importing
      !IV_BUSTYPE type ZDEBUSTYPE
      !IV_BUKRS type BUKRS
      !IT_REF_NO type TYT_ZOAREF_NO .
  class-methods GET_DAYS_BETWEEN_2_DATE
    importing
      !IV_DATE_BEGIN type D
      !IV_DATE_END type D
    returning
      value(RV_DAYS) type I .
  class-methods GET_DJSKDH_BY_VBELN
    importing
      !IV_VBELN type VBELN_VF
    returning
      value(RV_DJSKDH) type ZDJSKDH .
  class-methods GET_HKONT_MITKZ
    importing
      !IV_BUKRS type BUKRS
      !IV_HKONT type SAKNR
    returning
      value(RV_MITKZ) type MITKZ .
protected section.
private section.
ENDCLASS.



CLASS ZCL_TR2_COMMON IMPLEMENTATION.


METHOD batch_download_file.
*    TYPES:BEGIN OF ty_file_tab,
*            bustype    TYPE zt00040-bustype,
*            att_no     TYPE zt00040-att_no,
*            att_name   TYPE zt00040-att_name,
*            filetype   TYPE zt00040-filetype,
*            ref_no     TYPE zt00040-ref_no,
*            item       TYPE zt00040-item,
*            cuname     TYPE zt00040-cuname,
*            cdate      TYPE zt00040-cdate,
*            arc_doc_id TYPE zt00040-arc_doc_id,
*
*            filesave   TYPE icon_d,
*            filedele   TYPE icon_d,
*            text       TYPE zt00040-text,
*          END OF ty_file_tab.
*    DATA:gt_file_tab TYPE TABLE OF  ty_file_tab.
*    DATA:lt_ref_no TYPE tyt_zoaref_no.
*    DATA:lt_toadi TYPE TABLE OF toadi.
*    DATA: gs_zt00030 TYPE zt00030.
*    DATA: gv_path    TYPE string,
*          lv_picpath TYPE saepfad.
*
*
**校验业务类型
*    CLEAR:gs_zt00030.
*    SELECT SINGLE bustype
*                  bustypet
*                  objtype
*                  objtypet
*                  enfiletype
*            FROM zt00030
*            INTO CORRESPONDING FIELDS OF gs_zt00030
*            WHERE bustype =  iv_bustype.
*    IF sy-subrc NE 0.
*      MESSAGE e001(z01)  WITH  iv_bustype.
*    ELSE.
**业务对象类型与文档类型关系校验
*      SELECT SINGLE * FROM toaom INTO @DATA(ls_toaom)  WHERE sap_object = @gs_zt00030-objtype.
*      IF sy-subrc NE 0.
*        MESSAGE e002(z01)  WITH   gs_zt00030-objtype.
*      ENDIF.
*    ENDIF.
*
*    CHECK it_ref_no IS NOT INITIAL.
*
*    lt_ref_no = it_ref_no.
*    SORT lt_ref_no .
*    DELETE ADJACENT DUPLICATES FROM lt_ref_no COMPARING ALL FIELDS.
*
*    "OpenText附件文件信息存储表
*    SELECT bustype
*           att_no
*           att_name
*           filetype
*           ref_no
*           item
*           cuname
*           cdate
*           arc_doc_id
*           text
*           INTO CORRESPONDING FIELDS OF TABLE gt_file_tab
*           FROM zt00040
*           FOR ALL ENTRIES IN lt_ref_no
*           WHERE bustype EQ iv_bustype
*              AND ref_no EQ lt_ref_no-ref_no
*              AND delflag NE 'X'.
*    cl_gui_frontend_services=>directory_browse( EXPORTING window_title = CONV #( TEXT-t02 ) CHANGING selected_folder = gv_path ).
*
*    LOOP AT gt_file_tab INTO DATA(ls_file).
*      APPEND INITIAL LINE TO lt_toadi ASSIGNING FIELD-SYMBOL(<fs_toadi>).
*      SELECT SINGLE * INTO @DATA(ls_toa01) FROM toa01
*      WHERE sap_object = @gs_zt00030-objtype
*        AND object_id =  @ls_file-att_no
*        AND arc_doc_id = @ls_file-arc_doc_id.
*      <fs_toadi>-wid = ls_toa01-ar_object.
*      <fs_toadi>-wti = ls_file-att_name.
*      <fs_toadi>-adid = ls_file-arc_doc_id.
*      <fs_toadi>-aid  = ls_toa01-archiv_id.
*      <fs_toadi>-oid  = ls_file-att_no.
*      <fs_toadi>-oti  = gs_zt00030-objtype.
*      <fs_toadi>-dti  = ls_toa01-ar_object.
*      <fs_toadi>-dcl  = ls_file-filetype.
*
*      CONCATENATE gv_path '/' ls_file-att_name INTO lv_picpath.
*
*      CALL FUNCTION 'ARCHIVOBJECT_GET_CLIENT'
*        EXPORTING
*          archiv_doc_id            = ls_file-arc_doc_id
*          archiv_id                = ls_toa01-archiv_id
*          path                     = lv_picpath
*          doc_type                 = ls_file-filetype
*        EXCEPTIONS
*          error_archiv             = 1
*          error_communicationtable = 2
*          error_kernel             = 3
*          OTHERS                   = 4.
*
*
*      IF sy-subrc <> 0.
*        MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
*         WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
*      ENDIF.
*
*      CLEAR:lv_picpath.
*    ENDLOOP.
*
**    CALL FUNCTION 'ARCHIVOBJECT_DISPLAY'
**      EXPORTING
**        multiple                 = 'X'
**      TABLES
**        dispdocs                 = lt_toadi
**      EXCEPTIONS
**        error_archiv             = 1
**        error_communicationtable = 2
**        error_kernel             = 3
**        OTHERS                   = 4.
**    IF sy-subrc <> 0.
*** Implement suitable error handling here
**    ENDIF.
  ENDMETHOD.


METHOD check_need_hwbc.
    SELECT SINGLE bank_ind INTO @DATA(lv_bank_ind) FROM ztrt0013
    WHERE bukrs = @iv_bukrs
      AND hbkid = @iv_hbkid_fk
      AND hktid = @iv_hktid_fk.

    SELECT SINGLE @abap_true INTO @DATA(lv_exist) FROM ztrt9500 WHERE bukrs = @iv_bukrs AND bank_ind = @lv_bank_ind.
    IF sy-subrc = 0.
      rv_need = abap_true.
    ELSE.
      rv_need = abap_false.
    ENDIF.
  ENDMETHOD.


METHOD check_need_hwbc_only_bukrs.
    SELECT SINGLE @abap_true INTO @DATA(lv_exist) FROM ztrt9500 WHERE bukrs = @iv_bukrs .
    IF sy-subrc = 0.
      rv_need = abap_true.
    ELSE.
      rv_need = abap_false.
    ENDIF.
  ENDMETHOD.


METHOD CHECK_NOT_INITIAL.
    IF IV_VALUE IS INITIAL.
      IF ES_MESSAGE IS REQUESTED.
        MESSAGE S120 WITH IV_TEXT INTO ES_MESSAGE.
      ELSE.
        MESSAGE S120 WITH IV_TEXT DISPLAY LIKE 'E'.
      ENDIF.
      ES_TYPE = 'E'.
    ELSE.
      ES_TYPE = 'S'.
    ENDIF.
  ENDMETHOD.


METHOD convert_date_format.
    DATA:temp_date TYPE string.
    IF iv_date IS NOT INITIAL.
      temp_date = iv_date.
      REPLACE ALL OCCURRENCES OF '-' IN temp_date WITH ''.
      rv_date = temp_date+0(4) && iv_sep && temp_date+4(2) && iv_sep && temp_date+6(2).
    ENDIF.

  ENDMETHOD.


METHOD get_days_between_2_date.
    CALL FUNCTION 'HR_99S_INTERVAL_BETWEEN_DATES'
      EXPORTING
        begda = iv_date_begin
        endda = iv_date_end
*       TAB_MODE        = ' '
      IMPORTING
        days  = rv_days.
  rv_days = rv_days - 1.

  ENDMETHOD.


method GET_DJSKDH_BY_VBELN.
*      SELECT SINGLE djskdh
*        INTO @rv_djskdh
*        FROM zotct00460 AS z JOIN vbrp AS v
*          ON z~vbeln = v~vgbel
*        WHERE z~gdflg = ''
*          AND z~jqflg = ''
*          AND z~del_ind = ''
*          AND v~vbeln = @iv_vbeln.
  endmethod.


method GET_HKONT_MITKZ.
  endmethod.


METHOD get_kkje_by_vbeln.
*    SELECT SINGLE @abap_true INTO @DATA(lv_exist) FROM ztr2t1060 WHERE zterm = @iv_zterm.
*    IF sy-subrc = 0.
*      SELECT SINGLE ( zftdjje + zsjskje + ztzje + djje ) AS kkje
*        INTO @ev_kkje
*        FROM zotct00460 AS z JOIN vbrp AS v
*          ON z~vbeln = v~vgbel
*        WHERE z~gdflg = ''
*          AND z~jqflg = ''
*          AND z~del_ind = ''
*          AND v~vbeln = @iv_vbeln.
*    ELSE.
*      SELECT SINGLE vgbel INTO @DATA(vbeln_vl) FROM vbrp WHERE vbeln = @iv_vbeln.
*      IF sy-subrc = 0.
*        SELECT wrbtr  INTO TABLE @DATA(lt_wrbtr)
*          FROM bsid AS h
*         WHERE ( h~blart = 'SA' OR h~blart = 'Z8' )
*           AND h~kunnr = @iv_kunnr
*           AND ( h~bschl = '15' OR ( h~bschl = '19' AND h~umskz = 'A' ) )
*           AND h~zuonr = @vbeln_vl.
*      ENDIF.
*
*
*      ev_kkje = REDUCE #( INIT kkje = VALUE ztr2_kkje( ) FOR wa IN lt_wrbtr NEXT kkje = kkje + wa-wrbtr ).
*    ENDIF.

  ENDMETHOD.


METHOD get_snro_number.
    DATA temp_subrc TYPE c.

    DO 3 TIMES.
      CALL FUNCTION 'NUMBER_RANGE_ENQUEUE'
        EXPORTING
          object           = object
        EXCEPTIONS
          forgein_lock     = 1
          object_not_found = 2
          system_failure   = 3
          OTHERS           = 4.

      IF sy-subrc = 0.
        EXIT.
      ELSE.
        temp_subrc = sy-subrc.
        WAIT UP TO 1 SECONDS.
      ENDIF.
    ENDDO.

    IF temp_subrc = 0 .
      CALL FUNCTION 'NUMBER_GET_NEXT'
        EXPORTING
          nr_range_nr             = nr_range_nr
          object                  = object
        IMPORTING
          number                  = e_number
        EXCEPTIONS
          interval_not_found      = 1
          number_range_not_intern = 2
          object_not_found        = 3
          quantity_is_0           = 4
          quantity_is_not_1       = 5
          interval_overflow       = 6
          buffer_overflow         = 7
          OTHERS                  = 8.

      temp_subrc = sy-subrc.

      CALL FUNCTION 'NUMBER_RANGE_DEQUEUE'
        EXPORTING
          object           = object
        EXCEPTIONS
          object_not_found = 1
          OTHERS           = 2.

      IF temp_subrc <> 0.
        e_type = 'E'.
        e_msg = '生成编码失败'.
        RETURN.
      ENDIF.

    ELSE.
      e_type = 'E'.
      e_msg = '编码被锁定，请稍后再试'.
    ENDIF.
  ENDMETHOD.


METHOD get_workdays_between_2_dates.
    DATA:lv_date TYPE d.
      DATA:lv_date2 TYPE d.

    CALL FUNCTION 'BKK_ADD_WORKINGDAY'
          EXPORTING
            i_date      = I_TODATE
            i_days      = 1
            i_calendar1 = 'ZT'
          IMPORTING
            e_date      = lv_date2 .

       CALL FUNCTION 'BKK_ADD_WORKINGDAY'
          EXPORTING
            i_date      = lv_date2
            i_days      = '-1'
            i_calendar1 = 'ZT'
          IMPORTING
            e_date      = lv_date2 .


    IF i_fromdate > lv_date2 .
      e_days = 0.
    ELSE.
      lv_date = i_fromdate.
      WHILE lv_date NE lv_date2 .
        ADD 1 TO e_days.
        CALL FUNCTION 'BKK_ADD_WORKINGDAY'
          EXPORTING
            i_date      = i_fromdate
            i_days      = e_days
            i_calendar1 = 'ZT'
          IMPORTING
            e_date      = lv_date.

      ENDWHILE.
    ENDIF.


  ENDMETHOD.


METHOD ZFDTH_ACCEPT.
    TYPES:BEGIN OF TY_OUT.
        INCLUDE TYPE  ZTRS0076.
        INCLUDE TYPE  ZDBADMIN.
    TYPES END OF TY_OUT.
    TYPES: BEGIN OF TY_BANK_INFO,
             BUKRS TYPE ZTRT0013-BUKRS,
             HBKID TYPE ZTRT0013-HBKID,
             HKTID TYPE ZTRT0013-HKTID,
             BANKS TYPE ZTRT0013-BANKS,
             BANKL TYPE ZTRT0013-BANKL,
             YHZH  TYPE ZTRT0013-YHZH,
             BANKA TYPE BNKA-BANKA,
           END OF TY_BANK_INFO.

    DATA:GT_OUT TYPE TABLE OF TY_OUT,
         GS_OUT TYPE TY_OUT.

    DATA:GT_BANK_INFO TYPE STANDARD TABLE OF TY_BANK_INFO.

    DATA:LV_YHZH       TYPE ZTRT0013-YHZH,
         LV_LIFNR      TYPE LFA1-LIFNR,
         LV_VBUND      TYPE LFA1-VBUND,
         LV_DOCNO_KEY  TYPE ZTRT0070-DOCNO_KEY,
         LS_ZTRT0076   TYPE ZTRT0076,
         GV_LOCK_ERROR TYPE CHAR1,
         GV_LOCK_MSG   TYPE STRING.
    DATA: LV_INDEX TYPE SY-TABIX."ADD 20201118

    CHECK IM_DATA IS NOT INITIAL.




    IF ZZD IS INITIAL.
      SELECT
       A1~DOCNO                 ,"ZTRT2002 支付单申请-抬头信息
       A1~BUKRS                 ,
       A1~BUTXT                 ,
       A1~ZZFTYPE               ,
       A1~ZZFSTATUS             ,
       A1~ZFMARK                ,
       A1~ZSKNO                 ,
       A1~ZSKNAM                ,
       A1~ZZFWAERS              ,
       A1~ZZFWRBTR              ,
       A1~ZYWTYPE               ,
       A1~ZZFFS                 ,
       A1~ZBSKL                 ,

       A2~ZSKBANKL              ,      " ZTRT2002 支付单信息-收款银行信息
       A2~ZSKBANKA              ,
       A2~ZSKBNKN               ,

       A3~ZFKBANKL              ,       " ZTRT2003 支付单-付款银行信息
       A3~ZFKBANKA              ,
       A3~ZFKBNKN               ,

       A4~ZPJ_NO                ,
       A4~ZCP_DATE              ,
       A4~ZDQ_DATE              ,
       A4~ZPJ_TYPE              ,
       A4~ZHPJE                 ,
       A4~DOCNO_KEY             ,
       A4~ZJSNO                 ,
       A4~ZXH
   INTO CORRESPONDING FIELDS OF TABLE @GT_OUT
   FROM ZTRT2001 AS A1
   LEFT OUTER JOIN ZTRT2002 AS A2 ON A2~DOCNO = A1~DOCNO
   LEFT OUTER JOIN ZTRT2003 AS A3 ON A3~DOCNO = A1~DOCNO
   INNER JOIN ZTRT2009 AS A4 ON A4~DOCNO = A1~DOCNO
   FOR ALL ENTRIES IN @IM_DATA
   WHERE A1~BUKRS = @IM_DATA-BUKRS    "公司代码
   AND A1~DOCNO = @IM_DATA-DOCNO      "支付单
   AND A4~ZPJ_NO = @IM_DATA-DRAFT    "汇票号码
   AND A1~ZBSKL = 'A'            "背书
   AND A1~ZZFSTATUS = '16'.      "已过账
    ELSE.
      SELECT
      A1~DOCNO                 ,"ZTRT2002 支付单申请-抬头信息
      A1~BUKRS                 ,
      A1~BUTXT                 ,
      A1~ZZFTYPE               ,
      A1~ZZFSTATUS             ,
      A1~ZFMARK                ,
      A1~ZSKNO                 ,
      A1~ZSKNAM                ,
      A1~ZZFWAERS              ,
      A1~ZZFWRBTR              ,
      A1~ZYWTYPE               ,
      A1~ZZFFS                 ,
      A1~ZBSKL                 ,

      A2~ZSKBANKL              ,      " ZTRT2002 支付单信息-收款银行信息
      A2~ZSKBANKA              ,
      A2~ZSKBNKN               ,

      A3~ZFKBANKL              ,       " ZTRT2003 支付单-付款银行信息
      A3~ZFKBANKA              ,
      A3~ZFKBNKN               ,

      A4~ZPJ_NO                ,
      A4~ZCP_DATE              ,
      A4~ZDQ_DATE              ,
      A4~ZPJ_TYPE              ,
      A4~ZHPJE                 ,
      A4~DOCNO_KEY             ,
      A4~ZJSNO                 ,
      A4~ZXH
  INTO CORRESPONDING FIELDS OF TABLE @GT_OUT
  FROM ZTRT2001 AS A1
  LEFT OUTER JOIN ZTRT2002 AS A2 ON A2~DOCNO = A1~DOCNO
  LEFT OUTER JOIN ZTRT2003 AS A3 ON A3~DOCNO = A1~DOCNO
  INNER JOIN ZTRT2009 AS A4 ON A4~DOCNO = A1~DOCNO
  FOR ALL ENTRIES IN @IM_DATA
  WHERE A1~BUKRS = @IM_DATA-BUKRS    "公司代码
  AND A4~ZPJ_NO = @IM_DATA-DRAFT    "汇票号码
  AND a1~zskno = @IM_DATA-KUNNR      "客户编号
  AND A1~ZBSKL = 'A'            "背书
  AND A1~ZZFSTATUS = '16'.
    ENDIF.

    IF GT_OUT IS NOT INITIAL.

*      SELECT a~bukrs a~hbkid a~hktid a~banks a~bankl a~yhzh
*             b~banka
*        FROM ztrt0013 AS a
*        LEFT JOIN bnka AS b
*        ON a~bankl = b~bankl
*        AND a~banks = b~banks
*        INTO CORRESPONDING FIELDS OF TABLE gt_bank_info
*        FOR ALL ENTRIES IN gt_out
*        WHERE a~bukrs = gt_out-bukrs
*        AND a~hbkid = gt_out-hbkid
*        AND a~hktid = gt_out-hktid.
      SELECT A~BUKRS A~HBKID A~HKTID A~BANKS A~BANKL A~YHZH
        B~BANKA
        FROM ZTRT0013 AS A
        LEFT JOIN BNKA AS B
        ON A~BANKL = B~BANKL
        AND A~BANKS = B~BANKS
        INTO CORRESPONDING FIELDS OF TABLE GT_BANK_INFO
        FOR ALL ENTRIES IN IM_DATA
      WHERE A~BUKRS = IM_DATA-BUKRS
        AND A~YHZH = IM_DATA-BANKN_FK.
    ENDIF.

    LOOP AT IM_DATA INTO DATA(LS_DATA).
      CLEAR LV_INDEX.
      READ TABLE GT_OUT INTO GS_OUT WITH KEY
                                             ZPJ_NO = LS_DATA-DRAFT
                                             BUKRS = LS_DATA-BUKRS.
      CHECK SY-SUBRC = 0.
      LV_INDEX = SY-TABIX. "ADD 20201118
* 收票银行信息

      READ TABLE GT_BANK_INFO INTO DATA(GS_BANK_INFO) WITH KEY BUKRS = GS_OUT-BUKRS
*      hktid = gs_out-hktid hbkid = gs_out-hbkid.
      YHZH = LS_DATA-BANKN_FK.
      IF SY-SUBRC = 0.
        GS_OUT-YHZH  = GS_BANK_INFO-YHZH.
        GS_OUT-BANKL = GS_BANK_INFO-BANKL.
        GS_OUT-BANKS = GS_BANK_INFO-BANKS.
        GS_OUT-BANKA = GS_BANK_INFO-BANKA.
      ENDIF.
      CLEAR: GS_BANK_INFO.

      SELECT SINGLE ZITEM_STATUS
        FROM ZTRT0076
        INTO @DATA(GV_ITEM_STATUS)
        WHERE DOCNO_KEY = @GS_OUT-DOCNO_KEY
        AND BUKRS = @GS_OUT-BUKRS
        AND ZJSNO = @GS_OUT-ZJSNO
        AND DOCNO = @GS_OUT-DOCNO.

      IF SY-SUBRC = 0.
        APPEND INITIAL LINE TO EX_DATA ASSIGNING FIELD-SYMBOL(<LS_OUT>).
        MOVE-CORRESPONDING LS_DATA TO <LS_OUT>.
        MESSAGE S240(ZTR01) INTO <LS_OUT>-MESSAGE.
        <LS_OUT>-TYPE = 'E'.
        <LS_OUT>-ID = 'ZTR01'.
        <LS_OUT>-NUMBER = '240'.
        CONTINUE.
      ENDIF.

      IF GS_OUT-ZPJ_TYPE = '15' OR GS_OUT-ZPJ_TYPE = '25'.
        IF GS_OUT-YHZH IS INITIAL.
          MESSAGE S672(ZTR01) DISPLAY LIKE 'E'.
          CONTINUE.
        ENDIF.
      ENDIF.

      IF GS_OUT-YHZH IS NOT INITIAL.

        CLEAR: LV_YHZH.
        SELECT SINGLE YHZH
          FROM ZTRT0013
          INTO LV_YHZH
          WHERE YHZH = GS_OUT-YHZH
          AND BUKRS = GS_OUT-BUKRS.

        IF SY-SUBRC <> 0.
          APPEND INITIAL LINE TO EX_DATA ASSIGNING <LS_OUT>.
          MOVE-CORRESPONDING LS_DATA TO <LS_OUT>.
          MESSAGE S673(ZTR01) WITH GS_OUT-YHZH INTO <LS_OUT>-MESSAGE.
          <LS_OUT>-TYPE = 'E'.
          <LS_OUT>-ID = 'ZTR01'.
          <LS_OUT>-NUMBER = '673'.
          <LS_OUT>-MESSAGE_V1 = GS_OUT-YHZH.
          CONTINUE.
        ENDIF.

      ENDIF.

      "上线前放出 begin
* 若通过被退票接收，若收款方为关联方，则校验收款方通过被背书接收并且退票已过账
      CLEAR: LV_LIFNR,LV_VBUND.
      SELECT SINGLE LIFNR VBUND
        FROM LFA1
        INTO (LV_LIFNR,LV_VBUND)
        WHERE LIFNR = GS_OUT-ZSKNO
        AND KTOKK = 'S003'.

      IF SY-SUBRC = 0.

        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
          EXPORTING
            INPUT  = LV_VBUND
          IMPORTING
            OUTPUT = LV_VBUND.

        CLEAR: LV_DOCNO_KEY.
        SELECT SINGLE A~DOCNO_KEY
          FROM ZTRT0070 AS A
          INTO LV_DOCNO_KEY
          WHERE A~BUKRS = LV_VBUND
          AND A~DOCNO_KEY = GS_OUT-DOCNO_KEY
          AND A~ZJSNO = GS_OUT-ZJSNO
          AND A~ZTRAN_STATUS EQ '135'  "退票已过账
          AND A~ZNBLZ EQ '02'. "背书

        IF SY-SUBRC <> 0.
          APPEND INITIAL LINE TO EX_DATA ASSIGNING <LS_OUT>.
          MOVE-CORRESPONDING LS_DATA TO <LS_OUT>.
          MESSAGE S997(ZTR01) WITH GS_OUT-ZPJ_NO LV_VBUND INTO <LS_OUT>-MESSAGE.
          <LS_OUT>-TYPE = 'E'.
          <LS_OUT>-ID = 'ZTR01'.
          <LS_OUT>-NUMBER = '997'.
          <LS_OUT>-MESSAGE_V1 = GS_OUT-ZPJ_NO.
          <LS_OUT>-MESSAGE_V2 = LV_VBUND.
          CONTINUE.
        ENDIF.

      ENDIF.
      "上线前放出 end
      CLEAR :GV_ITEM_STATUS.

      CLEAR: GV_LOCK_ERROR,
       GV_LOCK_MSG.

      CALL FUNCTION 'ZFM_LOCK_ZTRT0070'
        EXPORTING
          DOCNO_KEY = GS_OUT-DOCNO_KEY
          BUKRS     = GS_OUT-BUKRS
          ZJSNO     = GS_OUT-ZJSNO
        IMPORTING
          EV_ERROR  = GV_LOCK_ERROR
          EV_MSG    = GV_LOCK_MSG.

      IF GV_LOCK_ERROR = 'X'.
        MESSAGE S000(ZTR01) WITH GV_LOCK_MSG DISPLAY LIKE 'E'.
        APPEND INITIAL LINE TO EX_DATA ASSIGNING <LS_OUT>.
        MOVE-CORRESPONDING LS_DATA TO <LS_OUT>.
        MESSAGE S000(ZTR01) WITH GV_LOCK_MSG INTO <LS_OUT>-MESSAGE.
        <LS_OUT>-TYPE = 'E'.
        <LS_OUT>-ID = 'ZTR01'.
        <LS_OUT>-NUMBER = '000'.
        <LS_OUT>-MESSAGE_V1 = GV_LOCK_MSG.
        CONTINUE.
      ENDIF.

      GS_OUT-ZITEM_STATUS = '15'.  "行项目状态 - 财务已确认

      GS_OUT-ZITEM_STATUS_T =  ZCL_WD_COMMON=>GET_DOM_VALUE( IM_DOMNAM = 'ZDM_TR_ZFTPJS_ST'  IM_DOMVAL = GS_OUT-ZITEM_STATUS ).

      GS_OUT-ZUSER = SY-UNAME. "操作人

* 申请单号
      CALL FUNCTION 'ZFM_GET_RANGE_NR'
        EXPORTING
          IV_DOCTYPE     = 'JSTH'
          IV_CONFIG_TYPE = '08'
        IMPORTING
          EV_DOCNO       = GS_OUT-DOCNO_TH.


      GS_OUT-ERDAT = SY-DATUM. "创建日期
      GS_OUT-ERZET = SY-UZEIT. "创建时间
      GS_OUT-ERNAM = SY-UNAME. "创建人
      GS_OUT-JSRI  = SY-DATUM. "接收单日期

      CLEAR: GS_OUT-BANKS,
             GS_OUT-BANKL,
             GS_OUT-BANKA,
             GS_OUT-HKTID,
             GS_OUT-HBKID.

      IF GS_OUT-YHZH IS NOT INITIAL.

        SELECT SINGLE A~HKTID A~HBKID A~BANKL A~BANKS B~BANKA
          FROM ZTRT0013 AS A
          LEFT JOIN BNKA AS B
          ON A~BANKL = B~BANKL
          AND A~BANKS = B~BANKS
          INTO (GS_OUT-HKTID,GS_OUT-HBKID,GS_OUT-BANKL,GS_OUT-BANKS,GS_OUT-BANKA)
          WHERE A~BUKRS = GS_OUT-BUKRS
          AND A~YHZH = GS_OUT-YHZH.

      ENDIF.

      MODIFY GT_OUT FROM GS_OUT INDEX LV_INDEX
      TRANSPORTING DOCNO_TH DOCNO_KEY BUKRS ZJSNO SJRQ ZITEM_STATUS ZUSER ZITEM_STATUS_T JSRI BANKL BANKS BANKA HKTID HBKID REMARK_FI.
*      WHERE SERNR = GS_OUT-SERNR.

      CLEAR :LS_ZTRT0076.
      MOVE-CORRESPONDING GS_OUT TO LS_ZTRT0076.
      MODIFY ZTRT0076 FROM LS_ZTRT0076.
      IF ZZD IS NOT INITIAL.
        APPEND INITIAL LINE TO EX_DATA ASSIGNING <LS_OUT>.
        MOVE-CORRESPONDING  LS_DATA TO <LS_OUT>.
        <LS_OUT>-DOCNO_KEY = LS_ZTRT0076-DOCNO_KEY.
        <LS_OUT>-ZJSNO     = LS_ZTRT0076-ZJSNO.
        <LS_OUT>-DOCNO_TH  = LS_ZTRT0076-DOCNO_TH.
        <LS_OUT>-ZITEM_STATUS = LS_ZTRT0076-ZITEM_STATUS.
      ENDIF.
      IF SY-SUBRC = 0 .
        COMMIT WORK .
      ELSE.
        ROLLBACK WORK.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.
ENDCLASS.
