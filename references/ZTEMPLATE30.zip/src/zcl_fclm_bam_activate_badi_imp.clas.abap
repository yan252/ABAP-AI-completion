class ZCL_FCLM_BAM_ACTIVATE_BADI_IMP definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_FCLM_BAM_AMD_ACTIVATION .
protected section.
private section.
ENDCLASS.



CLASS ZCL_FCLM_BAM_ACTIVATE_BADI_IMP IMPLEMENTATION.


  method IF_FCLM_BAM_AMD_ACTIVATION~ON_AFTER_ACTIVATE.
    break yangsen.

  endmethod.
ENDCLASS.
