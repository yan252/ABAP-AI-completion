FUNCTION ZFM_TR_ICBC_SET_PROP.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     VALUE(I_TREE_TYPE) TYPE  DMEE_TREETYPE_ABA
*"     VALUE(I_TREE_ID) TYPE  DMEE_TREEID_ABA
*"     VALUE(I_ITEM)
*"     VALUE(I_PARAM)
*"     VALUE(I_UPARAM)
*"  EXPORTING
*"     REFERENCE(O_VALUE)
*"     REFERENCE(C_VALUE)
*"     REFERENCE(N_VALUE)
*"     REFERENCE(P_VALUE)
*"  TABLES
*"      I_TAB
*"--------------------------------------------------------------------
FIELD-SYMBOLS <fs_fpayh> TYPE fpayh.

  ASSIGN COMPONENT 'FPAYH' OF STRUCTURE i_item TO <fs_fpayh>.
  DATA:tf(1) TYPE C.
  "跨行必输
  "0：对公账户
  "1：个人账户"

  SELECT SINGLE * INTO @DATA(ls_lfa1)
                FROM lfa1
                WHERE lifnr = @<fs_fpayh>-gpa1r."
  IF ls_lfa1-ktokk = 'S004' .  "员工

    tf = '1'.
  ELSE.

    tf = '0'.
  ENDIF.


  C_value = CONV #( tf ).





ENDFUNCTION.
