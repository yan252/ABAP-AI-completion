FUNCTION ZFM_DMEE_DOWNLOAD.
*"----------------------------------------------------------------------
*"*"本地接口：
*"  IMPORTING
*"     VALUE(IM_PATH) TYPE  BDCDATA-FVAL OPTIONAL
*"     REFERENCE(IM_TREE_TYPE) TYPE  DMEE_TREEID_ABA OPTIONAL
*"  TABLES
*"      IT_DMEE STRUCTURE  ZTRS_DMEE
*"----------------------------------------------------------------------
  DATA: L_PATH  TYPE BDCDATA-FVAL, "保存目录
        L_SUBRC TYPE SY-SUBRC,
        L_MODE  TYPE CHAR1 VALUE 'N'.
*  FIELD-SYMBOLS:  <DMEE> STRUCTURE ZTRS_DMEE DEFAULT ZTRS_DMEE.
  DATA: LT_MESSTAB LIKE  TABLE OF BDCMSGCOLL,
        LS_MESSTAB LIKE  BDCMSGCOLL.
  DATA: LS_MSGTX TYPE MSGTX.

  IF IM_PATH IS INITIAL.
    IM_PATH = 'D:\DMEE\'."此路径地址最好不要太长，因为DMEE下载路径长度有限制
  ENDIF.
  IF IM_TREE_TYPE IS NOT INITIAL"树类型，如有值且表为空，则取所有
    AND IT_DMEE[] IS INITIAL.
    SELECT TREE_TYPE TREE_ID
      INTO CORRESPONDING FIELDS OF TABLE IT_DMEE
      FROM DMEE_TREE
      WHERE TREE_TYPE = IM_TREE_TYPE
*        AND TREE_ID LIKE 'Z%'
      .
  ENDIF.
  LOOP AT IT_DMEE ASSIGNING FIELD-SYMBOL(<DMEE>).

    L_SUBRC = 0.
    LS_MSGTX = ''.
    L_PATH = IM_PATH && <DMEE>-TREE_TYPE && '\' && <DMEE>-TREE_ID.
    CALL FUNCTION 'ZFM_DMEE_DOWNLOAD1'
      EXPORTING
*       CTU            = 'X'
        MODE           = L_MODE "'N'
*       UPDATE         = 'L'
*       GROUP          =
*       USER           =
*       KEEP           =
*       HOLDDATE       =
*       NODATA         = '/'
        IM_XMLFILENAME = L_PATH   "'下载文件保存路径
        IM_TREE_TYPE   = <DMEE>-TREE_TYPE     "'PAYM'
        IM_TREE_ID     = <DMEE>-TREE_ID        "ZBANK_CN_BOCOM_310204_REQ
      IMPORTING
        SUBRC          = L_SUBRC
      TABLES
        MESSTAB        = LT_MESSTAB.
    IF L_SUBRC = 0.
      <DMEE>-SUCC = 'X'.
    ELSE.
      <DMEE>-SUCC = ''.
      LOOP AT LT_MESSTAB INTO LS_MESSTAB.
        MESSAGE ID LS_MESSTAB-MSGID TYPE 'S'  NUMBER LS_MESSTAB-MSGNR
          INTO LS_MSGTX
         WITH LS_MESSTAB-MSGV1 LS_MESSTAB-MSGV2
              LS_MESSTAB-MSGV3 LS_MESSTAB-MSGV4.

        <DMEE>-MSGTX = <DMEE>-MSGTX && '|' && LS_MSGTX.
      ENDLOOP.
      <DMEE>-MSGTX(1) = ''.

    ENDIF.

  ENDLOOP.


ENDFUNCTION.
