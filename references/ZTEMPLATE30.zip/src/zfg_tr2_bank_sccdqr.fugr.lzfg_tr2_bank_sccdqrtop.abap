FUNCTION-POOL ZFG_TR2_BANK_SCCDQR.          "MESSAGE-ID ..

* INCLUDE LZFG_TR2_BANK_SCCDQRD...           " Local class definition
