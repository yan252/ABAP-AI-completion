class ZCL_TR_COMMON definition
  public
  create public .

public section.

  types:
    gt_t042z TYPE TABLE OF t042z WITH DEFAULT KEY .
  types:
    gt_items TYPE TABLE OF ztrt9002 WITH DEFAULT KEY .
  types:
    gt_9036  TYPE TABLE OF ztrt9036  WITH DEFAULT KEY .

  class-methods GET_BANK_INFO
    importing
      value(BUKRS) type BUKRS
      value(YHZH) type ZTR_YHZH
    exporting
      !TEXT1 type FIBL_TXT50
      !BANKA type BANKA
      !WAERS type WAERS .
  class-methods GET_BILL_TYPE
    importing
      value(IV_CATES) type ZTR_CONFIG_TYPE
    returning
      value(ET_ITEMS) type GT_ITEMS .
  class-methods GET_BILL_STATUS
    importing
      value(IV_ZTYPE) type ZTR_DOCTYPE
    returning
      value(ET_ITEMS) type GT_9036 .
  class-methods CHECK_BP_GUARANTOR
    importing
      !IV_PARTNER type ZTR_PARTNER
      !IR_ELEMENT type ref to IF_WD_CONTEXT_ELEMENT optional
      !IV_ATTRIBUTE type STRING optional
      !IR_CONTROLLER type ref to IF_WD_CONTROLLER
    returning
      value(EV_FLAG) type FLAG .
  class-methods CHECK_BP_GTD_ORG
    importing
      !IV_PARTNER type ZTR_PARTNER
      !IR_ELEMENT type ref to IF_WD_CONTEXT_ELEMENT optional
      !IV_ATTRIBUTE type STRING optional
      !IR_CONTROLLER type ref to IF_WD_CONTROLLER
    returning
      value(EV_FLAG) type FLAG .
  class-methods CHECK_BP_FAC_ORG
    importing
      !IV_PARTNER type ZTR_PARTNER
      !IR_ELEMENT type ref to IF_WD_CONTEXT_ELEMENT optional
      !IV_ATTRIBUTE type STRING optional
      !IR_CONTROLLER type ref to IF_WD_CONTROLLER
    returning
      value(EV_FLAG) type FLAG .
  class-methods CHECK_BUKRS
    importing
      !IV_BUKRS type BUKRS
      !IR_ELEMENT type ref to IF_WD_CONTEXT_ELEMENT optional
      !IV_ATTRIBUTE type STRING optional
      !IR_CONTROLLER type ref to IF_WD_CONTROLLER
    returning
      value(EV_FLAG) type FLAG .
  class-methods CHECK_BANKS
    importing
      !IV_BANKS type BANKS
      !IR_ELEMENT type ref to IF_WD_CONTEXT_ELEMENT optional
      !IV_ATTRIBUTE type STRING optional
      !IR_CONTROLLER type ref to IF_WD_CONTROLLER
    returning
      value(EV_FLAG) type FLAG .
  class-methods CHECK_BANKL
    importing
      !IV_BANKL type BANKK
      !IR_CONTROLLER type ref to IF_WD_CONTROLLER
      !IR_ELEMENT type ref to IF_WD_CONTEXT_ELEMENT optional
      !IV_ATTRIBUTE type STRING optional
      !IV_BANKS type BANKS optional
    returning
      value(EV_FLAG) type FLAG .
  class-methods CHECK_BANKA
    importing
      !IV_BANKA type BANKA
      !IR_ELEMENT type ref to IF_WD_CONTEXT_ELEMENT optional
      value(IV_ATTRIBUTE) type STRING optional
      !IR_CONTROLLER type ref to IF_WD_CONTROLLER
      !IV_BANKL type BANKL optional
      !IV_BANKS type BANKS optional
    exporting
      value(EV_FLAG) type FLAG
      !EV_BANKS type BANKS
      !EV_BANKL type BANKL .
  class-methods CHECK_PARTNER
    importing
      !IV_PARTNER type ZTR_PARTNER
      !IR_ELEMENT type ref to IF_WD_CONTEXT_ELEMENT optional
      !IV_ATTRIBUTE type STRING optional
      !IR_CONTROLLER type ref to IF_WD_CONTROLLER
    returning
      value(EV_FLAG) type FLAG .
  class-methods CHECK_WAERS
    importing
      !IV_WAERS type WAERS
      !IR_ELEMENT type ref to IF_WD_CONTEXT_ELEMENT optional
      value(IV_ATTRIBUTE) type STRING optional
      !IR_CONTROLLER type ref to IF_WD_CONTROLLER
    returning
      value(EV_FLAG) type CHAR1 .
  class-methods CHECK_KUNNR
    importing
      !IV_KUNNR type KUNNR
      !IR_ELEMENT type ref to IF_WD_CONTEXT_ELEMENT optional
      !IV_ATTRIBUTE type STRING optional
      !IR_CONTROLLER type ref to IF_WD_CONTROLLER
    returning
      value(EV_FLAG) type CHAR1 .
  class-methods CHECK_ZXYZNO
    importing
      !IV_XYZNO type ZTR_XYZNO
      !IR_CONTROLLER type ref to IF_WD_CONTROLLER
    returning
      value(EV_FLAG) type CHAR1 .
  class-methods CHECK_YHZHBANKL
    importing
      !IV_BANKS type BANKS
      !IV_BANKL type BANKL
      !IV_HBKID type HBKID
      !IV_HKTID type HKTID
      !IR_CONTROLLER type ref to IF_WD_CONTROLLER
    exporting
      !EV_FLAG type FLAG .
  class-methods CHECK_YHZH
    importing
      !IV_BUKRS type BUKRS
      !IV_YHZH type ZTR_YHZH optional
      !IV_TEXT1 type FIBL_TXT50 optional
      !IV_HKTID type HKTID
      !IV_HBKID type HBKID
      !IR_ELEMENT type ref to IF_WD_CONTEXT_ELEMENT optional
      value(IV_ATTRIBUTE) type STRING optional
      !IR_CONTROLLER type ref to IF_WD_CONTROLLER
    exporting
      !EV_FLAG type FLAG
      !EV_HBKID type HBKID
      !EV_HKTID type HKTID .
  class-methods CHECK_FKTK
    importing
      !IV_FKTK type DZTERM
      !IR_ELEMENT type ref to IF_WD_CONTEXT_ELEMENT
      !IV_ATTRIBUTE type STRING
      !IR_CONTROLLER type ref to IF_WD_CONTROLLER
    returning
      value(EV_FLAG) type FLAG .
  class-methods GET_T042Z
    importing
      !IV_LAND1 type LAND1
    returning
      value(ET_ITEM) type GT_T042Z .
  class-methods SET_BUTTON_TEXT
    importing
      !IR_VIEW type ref to CL_WDR_VIEW
      !ID type STRING
      !VALUE type STRING
    changing
      !LR_BUTTON type ref to CL_WD_TOOLBAR_BUTTON .
  class-methods SET_BUTTON_VISIABLE
    importing
      !IR_VIEW type ref to CL_WDR_VIEW
      !ID type STRING
      !VALUE type WDUI_VISIBILITY
    changing
      !LR_BUTTON type ref to CL_WD_TOOLBAR_BUTTON .
  class-methods GET_BUKRS_TEXT
    importing
      !IV_BUKRS type BUKRS
    returning
      value(EV_BUTXT) type BUTXT .
  class-methods GET_BP_TEXT
    importing
      !IV_PARTNER type BU_PARTNER
    returning
      value(EV_NAME_ORG1) type BU_NAMEOR1 .
  class-methods GET_BANK_TEXT
    importing
      !IV_BANKS type BANKS
      !IV_BANKL type BANKK
    returning
      value(EV_BANKA) type BANKA .
  class-methods GET_BANK_IND_TEXT
    importing
      !IV_BANK_IND type ZTR_BANK_INDICATOR
    returning
      value(EV_BANK_IND_T) type ZTR_BANK_INDICATOR_TEXT .
  class-methods GET_USER_TEXT
    importing
      !IV_UNAME type XUBNAME
    returning
      value(EV_NAME_TEXT) type AD_NAMEFIR .
  class-methods GET_KOSTL_TEXT
    importing
      !IV_KOSTL type KOSTL
    returning
      value(EV_KOSTL_TEXT) type KTEXT .
  class-methods GET_ANLN1_TEXT
    importing
      !IV_ANLN1 type ANLN1
      !IV_BUKRS type BUKRS
    returning
      value(EV_ANLN1_T) type TXA50_ANLT .
  class-methods GET_USER_FULL_NAME
    importing
      !IV_UNAME type XUBNAME
    returning
      value(EV_NAME_TEXT) type NAME_TEXT .
  class-methods CHECK_ZHLX
    importing
      !IV_ZHLX type ZTR_ZHLX
      !IV_BUKRS type BUKRS
      !IV_BANKL type BANKL
      !IV_WAERS type WAERS
      !IV_HBKID type HBKID
      !IV_HKTID type HKTID
      !IR_CONTROLLER type ref to IF_WD_CONTROLLER
    returning
      value(EV_FLAG) type FLAG .
  class-methods CHECK_HKONT
    importing
      !IV_ZHLX type ZTRS0003-ZHLX
      !IV_HKONT type ZTRS0003-HKONT
      !IV_BUKRS type ZTRS0003-BUKRS
      value(IV_YHZH) type ZTRS0003-YHZH optional
      !IR_CONTROLLER type ref to IF_WD_CONTROLLER
    returning
      value(EV_FLAG) type FLAG .
  class-methods CALL_SPLS_URL
    importing
      !IV_TYPE type ZOALC_TYPE
      !IV_DOCNO type ZTR_DOCNO
      !IR_CONTR type ref to IF_WD_COMPONENT .
  class-methods CHECK_BANK_IND
    importing
      !IV_BANK_IND type ZTR_BANK_INDICATOR
      !IR_CONTROLLER type ref to IF_WD_CONTROLLER
    returning
      value(EV_FLAG) type FLAG .
  class-methods CHECK_XYZNO
    importing
      !IV_XYZNO type ZTR_XYZNO
      !IR_CONTROLLER type ref to IF_WD_CONTROLLER
    returning
      value(EV_FLAG) type CHAR1 .
  class-methods CHECK_KDGS
    importing
      !IV_KDGS type ZTR_ZKDGS optional
      !IV_ZKDGST type ZTR_ZKDGS optional
      !IR_ELEMENT type ref to IF_WD_CONTEXT_ELEMENT
      !IV_ATTRIBUTE type STRING
      !IR_CONTROLLER type ref to IF_WD_CONTROLLER
    exporting
      !EV_ERRO type FLAG .
  class-methods CHECK_IF_NO
    importing
      !IV_IF_NO type ZTR_IF_NO
      !IR_ELEMENT type ref to IF_WD_CONTEXT_ELEMENT optional
      !IV_ATTRIBUTE type STRING optional
      !IR_CONTROLLER type ref to IF_WD_CONTROLLER
    exporting
      !EV_ERRO type FLAG .
  class-methods CHECK_CEPC
    importing
      !IV_PRCTR type PRCTR
      !IR_ELEMENT type ref to IF_WD_CONTEXT_ELEMENT optional
      !IV_ATTRIBUTE type STRING optional
      !IR_CONTROLLER type ref to IF_WD_CONTROLLER
    exporting
      !EV_ERRO type FLAG .
  class-methods CHECK_WERKS
    importing
      !IV_WERKS type WERKS_D
      !IR_ELEMENT type ref to IF_WD_CONTEXT_ELEMENT optional
      !IV_ATTRIBUTE type STRING optional
      !IR_CONTROLLER type ref to IF_WD_CONTROLLER
    returning
      value(EV_FLAG) type FLAG .
  class-methods CHECK_LIFNR
    importing
      !IV_LIFNR type LIFNR
      !IR_ELEMENT type ref to IF_WD_CONTEXT_ELEMENT optional
      !IV_ATTRIBUTE type STRING optional
      !IR_CONTROLLER type ref to IF_WD_CONTROLLER
    returning
      value(EV_FLAG) type CHAR1 .
  class-methods CHECK_KOSTL
    importing
      !IV_KOSTL type KOSTL
      !IR_ELEMENT type ref to IF_WD_CONTEXT_ELEMENT optional
      !IV_ATTRIBUTE type STRING optional
      !IR_CONTROLLER type ref to IF_WD_CONTROLLER
    returning
      value(EV_FLAG) type CHAR1 .
  class-methods CHECK_DBHT
    importing
      !IV_DBHT type ZTR_CON_CODE
      !IR_ELEMENT type ref to IF_WD_CONTEXT_ELEMENT optional
      !IV_ATTRIBUTE type STRING optional
      !IR_CONTROLLER type ref to IF_WD_CONTROLLER
    returning
      value(EV_FLAG) type CHAR1 .
  class-methods CHECK_XYZYXD
    importing
      !IV_BANKS type BANKS
      !IR_ELEMENT type ref to IF_WD_CONTEXT_ELEMENT optional
      !IV_ATTRIBUTE type STRING optional
      !IR_CONTROLLER type ref to IF_WD_CONTROLLER
    returning
      value(EV_FLAG) type FLAG .
  class-methods CHECK_TINC
    importing
      !IV_INCO1 type INCO1
      !IR_ELEMENT type ref to IF_WD_CONTEXT_ELEMENT optional
      !IV_ATTRIBUTE type STRING optional
      !IR_CONTROLLER type ref to IF_WD_CONTROLLER
    returning
      value(EV_FLAG) type FLAG .
  class-methods CHECK_BANKL_XYZ
    importing
      !IV_BANKL type BANKK
      !IR_CONTROLLER type ref to IF_WD_CONTROLLER optional
      !IR_ELEMENT type ref to IF_WD_CONTEXT_ELEMENT optional
      !IV_ATTRIBUTE type STRING optional
      value(EV_FLAG) type FLAG .
  class-methods CHECK_VKORG_STATE
    importing
      !IV_BUKRS type BUKRS
    returning
      value(EV_STATE) type WDUI_VISIBILITY .
protected section.
private section.
ENDCLASS.



CLASS ZCL_TR_COMMON IMPLEMENTATION.


method call_spls_url.
*    data:lt_lcjl    type table of zoas00020.
*    data lv_lc_type type  zoalc_type.
    data lv_ref_no  type  zoaref_no   .
*    lv_lc_type =  iv_type.
*    lv_ref_no  = iv_docno.
**获取URL地址
*    call function 'ZFM_OA_GET_URL'
*      exporting
*        iv_lc_type  = lv_lc_type
*        iv_ref_no   = lv_ref_no
*      tables
*        et_oat00020 = lt_lcjl.
*
*    read table lt_lcjl into data(ls_lcjl) with key last_flag = 'X'.
**
**    data:lv_cl_zhsr type ref to zcl_hr_spjl_request.
**
**    create object lv_cl_zhsr.
**
**    call method lv_cl_zhsr->show_spjl
**      exporting
**        iv_url  = ls_lcjl-oa_url
**        iv_ctrl = ir_contr.
*
*    data: lo_window_manager type ref to if_wd_window_manager,
*          lo_api_comp       type ref to if_wd_component,
*          lo_view_ctrl      type ref to if_wd_view_controller,
*          lo_window         type ref to if_wd_window.
*    data lv_url type string.
*    lv_url = ls_lcjl-oa_url.
**获取COMPONENT
*    " lo_api_comp = iv_cpt.
**获取窗口管理器
*    lo_window_manager = ir_contr->get_window_manager( ).
**创建外部窗口
*    call method lo_window_manager->create_external_window
*      exporting
*        url         = lv_url
*        modal       = abap_false
*        has_menubar = abap_true
*      receiving
*        window      = lo_window.
**打开窗口
*    lo_window->open( ).
  endmethod.


METHOD check_banka.
    CHECK iv_banka IS NOT INITIAL.
    DATA lt_data TYPE TABLE OF bnka.
    SELECT * INTO CORRESPONDING FIELDS OF TABLE lt_data
      FROM bnka
     WHERE banka = iv_banka
      AND LOEVM = abap_false.

    IF iv_bankl IS NOT INITIAL.
      DELETE lt_data WHERE bankl NE iv_bankl.
    ENDIF.
    IF IV_BANKS IS NOT INITIAL.
      DELETE lt_data WHERE bankS NE IV_BANKS.
    ENDIF.
    IF lines( lt_data ) = 0.
      zcl_wd_message=>show_msg_detail(
       EXPORTING
         iv_type       = 'E'
         ir_element    = ir_element
         iv_attribute  = iv_attribute
         iv_msgid      = 'ZTR02'
         iv_msgno      = '096'
         iv_msgty      = 'E'
         ir_controller =  ir_controller" "你输入的银行不存在，请通过搜索帮助重新选择！
     ).

      ev_flag = 'X'.
      RETURN.
    ENDIF.

    IF  lines( lt_data ) > 1.
      zcl_wd_message=>show_msg_detail(
       EXPORTING
         iv_type       = 'E'
         ir_element    = ir_element
         iv_attribute  = iv_attribute
         iv_msgid      = 'ZTR02'
         iv_msgno      = '095'
         iv_msgty      = 'E'
         ir_controller =  ir_controller"你输入的银行有多条，请通过搜索帮助选择！ "
     ).

      ev_flag = 'X'.
      RETURN.
    ENDIF.

    IF  lines( lt_data ) = 1.
      ev_banks = lt_data[ 1 ]-banks.
      ev_bankl = lt_data[ 1 ]-bankl.
      RETURN.
    ENDIF.

  ENDMETHOD.


METHOD check_bankl.

    DATA lv_bankl TYPE bankk.
    CHECK iv_banks IS NOT INITIAL.
    CHECK iv_bankl IS NOT INITIAL.
    SELECT SINGLE bankl
      FROM bnka
      INTO lv_bankl
     WHERE banks = iv_banks
       AND bankl = iv_bankl.

    IF sy-subrc <> 0.
      zcl_wd_message=>show_msg_detail(
       EXPORTING
         iv_type       = 'E'
         iv_msgid      = 'ZTR01'
         iv_msgno      = '059'
         iv_msgty      = 'E'
         ir_controller =  ir_controller"银行代码与银行国家不匹配！ "
         ir_element    =  ir_element
         iv_attribute  =  iv_attribute
     ).

      ev_flag = 'X'.

    ENDIF.
  ENDMETHOD.


method CHECK_BANKL_XYZ.

    DATA lv_bankl TYPE bankk.

    CHECK iv_bankl is not INITIAL.

    SELECT SINGLE bankl
      FROM bnka
      INTO lv_bankl
     WHERE bankl = iv_bankl.

    IF sy-subrc <> 0.
      zcl_wd_message=>show_msg_detail(
       EXPORTING
         iv_type       = 'E'
         iv_msgid      = 'ZTR03'
         iv_msgno      = '230'
         iv_msgty      = 'E'
         ir_controller =  ir_controller"银行代码不合法！ "
         ir_element    =  ir_element
         iv_attribute  =  iv_attribute
     ).

      ev_flag = 'X'.

    ENDIF.
  endmethod.


method check_banks.
    data lv_land1 type land1.
    CHECK iv_banks is not INITIAL.
    select single land1 into lv_land1
      from t005
     where land1 = iv_banks.


    if sy-subrc <> 0.
      ev_flag = 'X'.


      zcl_wd_message=>show_msg_detail(
       exporting
         iv_type       = 'E'
         ir_element    = ir_element
         iv_attribute  = iv_attribute
         iv_msgid      = 'ZTR01'
         iv_msgno      = '052'
         iv_msgty      = 'E'
         ir_controller =  ir_controller"国家编码不存在 "
     ).
    endif.
  endmethod.


method check_bank_ind.
    data lv_bank_ind  type ztr_bank_indicator.

    select SINGLE bank_ind into  lv_bank_ind
      from ztrt_bankt
     where bank_ind = iv_bank_ind
       and spras    = sy-langu.


    if sy-subrc <> 0.
      ev_flag = 'X'.


      zcl_wd_message=>show_msg_detail(
       exporting
         iv_type       = 'E'
         iv_msgid      = 'ZTR02'
         iv_msgno      = '050'
         iv_msgty      = 'E'
         ir_controller =  ir_controller"公司代码输入错误 "
     ).
    endif.
  endmethod.


METHOD check_bp_fac_org.

    CHECK iv_partner IS NOT INITIAL.

    SELECT SINGLE partner INTO @DATA(lv_partner)
      FROM but000
     WHERE partner = @iv_partner
       AND bu_group IN ( 'A002', 'A003' )."APP银行的业务合作伙伴/集团外其它业务伙伴

    IF sy-subrc <> 0.
      zcl_wd_message=>show_msg_detail(
       EXPORTING
         iv_type       = 'E'
         ir_element    = ir_element
         iv_attribute  = iv_attribute
         iv_msgid      = 'ZTR06'
         iv_msgno      = '001'
         iv_msgty      = 'E'
         ir_controller =  ir_controller"请输入正确的融资机构！
     ).

      ev_flag = 'X'.

    ENDIF.

  ENDMETHOD.


METHOD CHECK_BP_GTD_ORG.

    CHECK iv_partner IS NOT INITIAL.

    SELECT SINGLE partner INTO @DATA(lv_partner)
      FROM but000
     WHERE partner = @iv_partner
       AND bu_group IN ('A001','A003')."APP集团内/集团外的业务合作伙伴

    IF sy-subrc <> 0.
      zcl_wd_message=>show_msg_detail(
       EXPORTING
         iv_type       = 'E'
         ir_element    = ir_element
         iv_attribute  = iv_attribute
         iv_msgid      = 'ZTR06'
         iv_msgno      = '014'
         iv_msgty      = 'E'
         ir_controller =  ir_controller"请输入正确的被担保企业！
     ).

      ev_flag = 'X'.

    ENDIF.

  ENDMETHOD.


METHOD check_bp_guarantor.

    CHECK iv_partner IS NOT INITIAL.

*    SELECT SINGLE partner INTO @DATA(lv_partner)
*      FROM ztrv_but000
*     WHERE partner = @iv_partner
*       AND rltyp = 'TR0200'"担保人
*       AND bu_group = 'A001'."APP集团内业务伙伴

    SELECT SINGLE partner INTO @DATA(lv_partner)
      FROM but000
     WHERE partner = @iv_partner
       AND bu_group = 'A001'."APP集团内业务伙伴

    IF sy-subrc <> 0.
      zcl_wd_message=>show_msg_detail(
       EXPORTING
         iv_type       = 'E'
         ir_element    = ir_element
         iv_attribute  = iv_attribute
         iv_msgid      = 'ZTR06'
         iv_msgno      = '002'
         iv_msgty      = 'E'
         ir_controller =  ir_controller"请输入正确的担保人！
     ).

      ev_flag = 'X'.

    ENDIF.

  ENDMETHOD.


method check_bukrs.
    data lv_bukrs type bukrs.
    CHECK iv_bukrs is not INITIAL.
    select single bukrs into lv_bukrs
      from t001
     where bukrs = iv_bukrs.


    if sy-subrc <> 0.
      ev_flag = 'X'.


      zcl_wd_message=>show_msg_detail(
       exporting
         iv_type       = 'E'
         ir_element    = ir_element
         iv_attribute  = iv_attribute
         iv_msgid      = 'ZTR01'
         iv_msgno      = '050'
         iv_msgty      = 'E'
         ir_controller =  IR_CONTROLLER"公司代码输入错误 "
     ).
    endif.
  endmethod.


method check_cepc.
    check iv_prctr is not initial.
    select single * into @data(ls_data)
      from cepc
     where prctr = @iv_prctr.
    if sy-subrc <> 0 .
      ev_erro = 'X'.
      zcl_wd_message=>show_msg_detail(
       exporting
         iv_type       = 'E'
         ir_element    = ir_element
         iv_attribute  = iv_attribute
         iv_msgid      = 'ZTR03'
         iv_msgno      = '032'
         iv_msgty      = 'E'
         ir_controller =  ir_controller"您输入的利润中心不存在！ "
     ).
      exit.

    endif.
  endmethod.


method check_dbht.
*    check  iv_dbht is not initial.
*
*
*    select single con_code into @data(lv_con_code)
*      from ztrt4009_01
*      where con_code = @iv_dbht.
*
*
*    if sy-subrc <> 0.
*      ev_flag = 'X'.
*
*      zcl_wd_message=>show_msg_detail(
*       exporting
*         iv_type       = 'E'
*         ir_element    = ir_element
*         iv_attribute  = iv_attribute
*         iv_msgid      = 'ZTR03'
*         iv_msgno      = '103'
*         iv_msgty      = 'E'
*         ir_controller =  ir_controller"缴款部门不正确！ "
*     ).
*    endif.

  endmethod.


method check_fktk.
    check iv_fktk is not initial.

    select single ZTERM into @data(lv_fktk)
    from T052U
    where zterm = @iv_fktk.

    if sy-subrc <> 0.
      ev_flag = 'X'.


      zcl_wd_message=>show_msg_detail(
       exporting
         iv_type       = 'E'
         ir_element    = ir_element
         iv_attribute  = iv_attribute
         iv_msgid      = 'ZTR03'
         iv_msgno      = '034'
         iv_msgty      = 'E'
         ir_controller =  ir_controller"您输入的付款条款不存在！ "
     ).
    endif.
  endmethod.


method check_hkont.

    data lt_data type table of ztrt0013.

    if  iv_zhlx <> '11' and iv_zhlx <> '12' and iv_zhlx <> '10'.
      select * into corresponding fields of table lt_data
        from ztrt0013
       where bukrs = iv_bukrs
         and hkont = iv_hkont.

      if lines( lt_data ) >= 1.
        ev_flag = 'X'.
        zcl_wd_message=>show_msg_detail(
         exporting
           iv_type       = 'E'
           iv_msgid      = 'ZTR01'
           iv_msgno      = '126'
           iv_msgty      = 'E'
*           iv_msgv1      = |{ ls_data-yhzh }|
           ir_controller =  ir_controller"会计科目已经被其他银行占用 "
       ).
      endif.
    endif.

  endmethod.


METHOD check_if_no.
*
*    CHECK iv_if_no IS NOT INITIAL AND iv_if_no <> space.
*
*    SELECT SINGLE * INTO @DATA(ls_data)
*      FROM ztrt4002_01
*     WHERE if_no   = @iv_if_no
*       AND del_ind = @space
*       AND if_status NE '10'
*       AND if_lock <> @abap_true.
*
*    IF sy-subrc <> 0.
*      ev_erro = 'X'.
*      zcl_wd_message=>show_msg_detail(
*       EXPORTING
*         iv_type       = 'E'
*         ir_element    = ir_element
*         iv_attribute  = iv_attribute
*         iv_msgid      = 'ZTR03'
*         iv_msgno      = '031'
*         iv_msgty      = 'E'
*         ir_controller =  ir_controller"您输入的融资台帐号不存在！ "
*     ).
*
*      EXIT.
*
*
*    ENDIF.

  ENDMETHOD.


method check_kdgs.
*    if iv_zkdgst is not initial.
*      select single * into  @data(ls_0002)
*        from ztrc0002
*       where zkdgst = @iv_zkdgst
*         and spras  = @sy-langu.
*
*      if sy-subrc <> 0.
*        ev_erro = 'X'.
*
*        zcl_wd_message=>show_msg_detail(
*         exporting
*           iv_type       = 'E'
*           ir_element    = ir_element
*           iv_attribute  = iv_attribute
*           iv_msgid      = 'ZTR03'
*           iv_msgno      = '030'
*           iv_msgty      = 'E'
*           ir_controller =  ir_controller"您输入的快递公司不存在！ "
*       ).
*        exit.
*      endif.
*    endif.
  endmethod.


method check_kostl.

    check  iv_kostl is not initial.


    select single ktext into @data(lv_kostl_text)
      from cskt
      where spras = @sy-langu
        and kostl = @iv_kostl
        and datbi >= @sy-datum.


    if sy-subrc <> 0.
      ev_flag = 'X'.

      zcl_wd_message=>show_msg_detail(
       exporting
         iv_type       = 'E'
         ir_element    = ir_element
         iv_attribute  = iv_attribute
         iv_msgid      = 'ZTR03'
         iv_msgno      = '064'
         iv_msgty      = 'E'
         ir_controller =  ir_controller"缴款部门不正确！ "
     ).
    endif.
  endmethod.


method check_kunnr.
    CHECK iv_kunnr is not INITIAL.

    data lv_kunnr type kunnr.

    call function 'CONVERSION_EXIT_ALPHA_INPUT'
      exporting
        input         = iv_kunnr
     IMPORTING
        OUTPUT        = lv_kunnr
              .
    select single * into @data(ls_data) from kna1 where kunnr = @lv_kunnr.

    if sy-subrc <> 0.
      ev_flag = 'X'.

      zcl_wd_message=>show_msg_detail(
       exporting
         iv_type       = 'E'
         ir_element    = ir_element
         iv_attribute  = iv_attribute
         iv_msgid      = 'ZTR02'
         iv_msgno      = '055'
         iv_msgty      = 'E'
         ir_controller =  ir_controller"客户编码不存在 "
     ).
    endif.
  endmethod.


method check_lifnr.
    check  iv_lifnr is not initial.

    SELECT SINGLE name1 INTO @data(lv_name1) FROM lfa1 WHERE lifnr = @iv_lifnr.

    if sy-subrc <> 0.
      ev_flag = 'X'.

      zcl_wd_message=>show_msg_detail(
       exporting
         iv_type       = 'E'
         ir_element    = ir_element
         iv_attribute  = iv_attribute
         iv_msgid      = 'ZTR03'
         iv_msgno      = '063'
         iv_msgty      = 'E'
         ir_controller =  ir_controller"供应商编码不存在！ "
     ).
    endif.
  endmethod.


method check_partner.
    check iv_partner is not initial.

    data lv_indata type but000-partner.

    call function 'CONVERSION_EXIT_ALPHA_INPUT'
      exporting
        input         = iv_partner
     IMPORTING
       OUTPUT        =  lv_indata.
              .

    select single partner into @data(lv_partner)
      from but000
     where partner = @lv_indata.

    if sy-subrc <> 0.
      zcl_wd_message=>show_msg_detail(
       exporting
         iv_type       = 'E'
         ir_element    = ir_element
         iv_attribute  = iv_attribute
         iv_msgid      = 'ZTR02'
         iv_msgno      = '043'
         iv_msgty      = 'E'
         ir_controller =  ir_controller"输入的合作伙伴代码不存在！ "
     ).

      ev_flag = 'X'.

    endif.
  endmethod.


method check_tinc.

    data lv_inco1 type inco1.
    check iv_inco1 is not initial.
    select single inco1 into lv_inco1
      from tinc
     where inco1 = iv_inco1.


    if sy-subrc <> 0.
      ev_flag = 'X'.


      zcl_wd_message=>show_msg_detail(
       exporting
         iv_type       = 'E'
         ir_element    = ir_element
         iv_attribute  = iv_attribute
         iv_msgid      = 'ZTR03'
         iv_msgno      = '111'
         iv_msgty      = 'E'
         ir_controller =  ir_controller"国家贸易条款不存在！ "
     ).
    endif.
  endmethod.


METHOD check_vkorg_state.

    SELECT * FROM ztrt9040_2 INTO TABLE @DATA(lt_bukrs) WHERE bukrs = @iv_bukrs.
    SELECT * FROM ztrt9040_3 APPENDING TABLE lt_bukrs WHERE bukrs = iv_bukrs.
    SELECT * FROM ztrt9040_4 APPENDING TABLE lt_bukrs WHERE bukrs = iv_bukrs.

    READ TABLE lt_bukrs ASSIGNING FIELD-SYMBOL(<fs_bukrs>) WITH KEY bukrs = iv_bukrs.
    IF sy-subrc = 0.
      IF <fs_bukrs>-burks_type = 10 OR <fs_bukrs>-burks_type = 20.
        ev_state = '00'. "如果是总部或工厂,销售组织非必填
      ELSE.
        ev_state = '01'. "如果是内贸,销售组织必填
      ENDIF.
    ENDIF.

  ENDMETHOD.


method check_waers.

    data lv_waers type waers.
    check iv_waers is not initial.
    select single waers into lv_waers
      from tcurc
     where waers = iv_waers.


    if sy-subrc <> 0.
      ev_flag = 'X'.


      zcl_wd_message=>show_msg_detail(
       exporting
         iv_type       = 'E'
         ir_element    = ir_element
         iv_attribute  = iv_attribute
         iv_msgid      = 'ZTR02'
         iv_msgno      = '053'
         iv_msgty      = 'E'
         ir_controller =  ir_controller"公司代码输入错误 "
     ).
    endif.
  endmethod.


method check_werks.

    data  lv_werks type WERKS_D.
    check iv_werks is not initial.
    select single WERKS into lv_werks
      from T001W
     where WERKS = iv_werks.


    if sy-subrc <> 0.
      ev_flag = 'X'.


      zcl_wd_message=>show_msg_detail(
       exporting
         iv_type       = 'E'
         ir_element    = ir_element
         iv_attribute  = iv_attribute
         iv_msgid      = 'ZTR03'
         iv_msgno      = '038'
         iv_msgty      = 'E'
         ir_controller =  ir_controller"公司代码输入错误 "
     ).
    endif.
  endmethod.


method CHECK_XYZNO.
*    select single * into @data(ls_data) from ztrt0022_tz
*      where zxyzno  = @iv_xyzno
*        and del_flg = ''.
*    if sy-subrc <> 0.
*      ev_flag = 'X'.
*
*
*      zcl_wd_message=>show_msg_detail(
*       exporting
*         iv_type       = 'E'
*         iv_msgid      = 'ZTR02'
*         iv_msgno      = '050'
*         iv_msgty      = 'E'
*         ir_controller =  ir_controller"公司代码输入错误 "
*     ).
*    endif.
  endmethod.


method CHECK_XYZYXD.
    data lv_land1 type land1.
    CHECK iv_banks is not INITIAL.
    select single land1 into lv_land1
      from t005
     where land1 = iv_banks.


    if sy-subrc <> 0.
      ev_flag = 'X'.


      zcl_wd_message=>show_msg_detail(
       exporting
         iv_type       = 'E'
         ir_element    = ir_element
         iv_attribute  = iv_attribute
         iv_msgid      = 'ZTR03'
         iv_msgno      = '105'
         iv_msgty      = 'E'
         ir_controller =  ir_controller"信用证有效地不合法！ "
     ).
    endif.
  endmethod.


method check_yhzh.
    data lt_0013 type table of ztrt0013.
    if iv_yhzh  is not initial.

      select * into corresponding fields of table lt_0013
        from ztrt0013
       where bukrs = iv_bukrs
         and yhzh = iv_yhzh
         and hbkid = iv_hbkid
         and hktid = iv_hktid
         and del_flg =  ''
         and is_nxh   <> '1'
         and is_zhbdj <> '1'.

      if sy-subrc <> 0 .
        zcl_wd_message=>show_msg_detail(
         exporting
           iv_type       = 'E'
           ir_element    = ir_element
           iv_attribute  = iv_attribute
           iv_msgid      = 'ZTR02'
           iv_msgno      = '099'
           iv_msgty      = 'E'
           ir_controller = ir_controller
           ).
        ev_flag = 'X'.
        return.
      else.
**--     如果根据根据账户找到多条台帐，提示让通过F4选择
*        if lines( lt_0013 ) > 1.
*          zcl_wd_message=>show_msg_detail(
*           exporting
*             iv_type       = 'E'
*             iv_msgid      = 'ZTR02'
*             iv_msgno      = '099'
*             iv_msgty      = 'E'
*             ir_controller = ir_controller
*             ).
*          ev_flag = 'X'.
*          return.
*        else.
        ev_hbkid = lt_0013[ 1 ]-hbkid.
        ev_hktid = lt_0013[ 1 ]-hktid.
        return.
*        endif.
      endif.
    elseif iv_text1 is not initial.
      select * into corresponding fields of table lt_0013
            from ztrt0013
           where bukrs = iv_bukrs
             and text1 = iv_text1
             and hbkid = iv_hbkid
             and hktid = iv_hktid
             and del_flg =  ''
             and is_nxh   <> '1'.

      if sy-subrc <> 0 .
        zcl_wd_message=>show_msg_detail(
         exporting
           iv_type       = 'E'
           iv_msgid      = 'ZTR02'
           iv_msgno      = '099'
           iv_msgty      = 'E'
           ir_controller = ir_controller
           ).
        ev_flag = 'X'.
        return.
      else.
*--     如果根据根据账户找到多条台帐，提示让通过F4选择
*        if lines( lt_0013 ) > 1.
*          zcl_wd_message=>show_msg_detail(
*           exporting
*             iv_type       = 'E'
*             iv_msgid      = 'ZTR02'
*             iv_msgno      = '099'
*             iv_msgty      = 'E'
*             ir_controller = ir_controller
*             ).
*          ev_flag = 'X'.
*          return.
*        else.
        ev_hbkid = lt_0013[ 1 ]-hbkid.
        ev_hktid = lt_0013[ 1 ]-hktid.
        return.
*        endif.
      endif.

    endif.


  endmethod.


method check_yhzhbankl.


    select single * into @data(ls_data)
      from ztrt0013
     where banks = @iv_banks
       and bankl = @iv_bankl
       and hbkid = @iv_hbkid
       and hktid = @iv_hktid
       and del_flg = ''
       and is_nxh   <> '1'
       AND IS_ZHBDJ <> '1'.


    if sy-subrc <> 0.
      zcl_wd_message=>show_msg_detail(
       exporting
         iv_type       = 'E'
         iv_msgid      = 'ZTR02'
         iv_msgno      = '097'
         iv_msgty      = 'E'
         ir_controller =  ir_controller"银行代码与银行国家不匹配！ "
     ).

      ev_flag = 'X'.

    endif.
  endmethod.


method check_zhlx.
    data ls_data type ztrt0013.
    check iv_zhlx = '11'.
    select single * into ls_data
      from ztrt0013
     where bukrs = iv_bukrs
       and bankl = iv_bankl
       and waers = iv_waers
       and zhlx  = iv_zhlx
       and ( hbkid <> iv_hbkid
       or hktid <> iv_hktid ).

    if sy-subrc = 0.
      ev_flag = 'X'.
      zcl_wd_message=>show_msg_detail(
       exporting
         iv_type       = 'E'
         iv_msgid      = 'ZTR01'
         iv_msgno      = '125'
         iv_msgty      = 'E'
         ir_controller =  ir_controller"公司代码输入错误 "
     ).
    endif.
  endmethod.


method check_zxyzno.

*    select single * into @data(ls_data) from ztrt0022_tz
*      where zxyzno  = @iv_xyzno
*        and del_flg = ''.
*    if sy-subrc <> 0.
*      ev_flag = 'X'.
*
*
*      zcl_wd_message=>show_msg_detail(
*       exporting
*         iv_type       = 'E'
*         iv_msgid      = 'ZTR02'
*         iv_msgno      = '093'
*         iv_msgty      = 'E'
*         ir_controller =  ir_controller"公司代码输入错误 "
*     ).
*    endif.
  endmethod.


METHOD get_anln1_text.

    SELECT SINGLE txt50 INTO ev_anln1_t FROM anlt
      WHERE spras = sy-langu
        AND bukrs = iv_bukrs
        AND anln1 = iv_anln1.

  ENDMETHOD.


METHOD get_bank_ind_text.

    SELECT SINGLE ltext INTO ev_bank_ind_t FROM ztrt_bankt
      WHERE bank_ind = iv_bank_ind.

  ENDMETHOD.


METHOD get_bank_info.
    DATA: lv_hbkid TYPE hbkid,
          lv_bankn TYPE bankn,
          lv_refzl TYPE refzl,
          lv_len   TYPE i,
          lv_bankl TYPE bankk,
          lv_banks TYPE banks,
          lv_hktid TYPE hktid.

*判断银行账户长短（标准18位）
    lv_len = strlen( yhzh ).
    IF lv_len <= 18.
      lv_bankn = yhzh.
    ELSE.
      lv_bankn = yhzh+0(18).
      lv_len = lv_len - 18.
      lv_refzl = yhzh+18(lv_len).
    ENDIF.
    SELECT SINGLE hbkid hktid waers INTO (lv_hbkid,lv_hktid,waers)
      FROM t012k
      WHERE bukrs = bukrs AND bankn = lv_bankn AND refzl =  lv_refzl.
    IF sy-subrc = 0.
*描述
      SELECT SINGLE text1 INTO text1 FROM t012t
        WHERE spras = sy-langu AND bukrs = bukrs
        AND hbkid = lv_hbkid AND hktid = lv_hktid.
*银行名称
      SELECT SINGLE bankl banks INTO (lv_bankl,lv_banks) FROM t012
        WHERE bukrs = bukrs AND hbkid = lv_hbkid.
      IF sy-subrc = 0.
        SELECT SINGLE banka INTO banka FROM bnka
          WHERE banks = lv_banks AND bankl = lv_bankl.
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD get_bank_text.

    SELECT SINGLE banka INTO ev_banka FROM bnka
      WHERE banks = iv_banks
        AND bankl = iv_bankl.

  ENDMETHOD.


METHOD get_bill_status.
    SELECT * INTO TABLE et_items FROM ztrt9036 WHERE doctype = iv_ztype.
  ENDMETHOD.


METHOD get_bill_type.
    SELECT * INTO TABLE et_items FROM ztrt9002 WHERE config_type = iv_cates.
  ENDMETHOD.


METHOD get_bp_text.

    SELECT SINGLE name_org1 INTO ev_name_org1
      FROM but000
     WHERE partner = iv_partner.

  ENDMETHOD.


METHOD get_bukrs_text.

    SELECT SINGLE butxt INTO ev_butxt
      FROM t001
     WHERE bukrs = iv_bukrs.

  ENDMETHOD.


METHOD get_kostl_text.

    SELECT SINGLE ktext INTO ev_kostl_text
      FROM cskt
      WHERE spras = sy-langu
        AND kostl = iv_kostl
        AND datbi >= sy-datum.

  ENDMETHOD.


METHOD get_t042z.
    SELECT * INTO TABLE et_item FROM t042z WHERE land1 = iv_land1.
  ENDMETHOD.


METHOD get_user_full_name.

    SELECT SINGLE b~name_text INTO ev_name_text
      FROM usr21 AS a INNER JOIN
           adrp AS b ON b~persnumber = a~persnumber
      WHERE a~bname = iv_uname.

  ENDMETHOD.


METHOD get_user_text.

    SELECT SINGLE b~NAME_LAST INTO ev_name_text
      FROM usr21 AS a INNER JOIN
           adrp AS b ON b~persnumber = a~persnumber
      WHERE a~bname = iv_uname.

  ENDMETHOD.


method SET_BUTTON_TEXT.
    data lr_ui_element type ref to if_wd_view_element.

    lr_ui_element ?= ir_view->get_element( id = id ).

    lr_button ?= lr_ui_element.

    lr_button->set_text( value = value ).
  endmethod.


method set_button_visiable.
    data lr_ui_element type ref to if_wd_view_element.

    lr_ui_element ?= ir_view->get_element( id = id ).

    lr_button ?= lr_ui_element.

    lr_button->set_visible( value = value ).
  endmethod.
ENDCLASS.
