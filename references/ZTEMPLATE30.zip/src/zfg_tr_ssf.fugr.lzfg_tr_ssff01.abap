*----------------------------------------------------------------------*
***INCLUDE LZFG_TR_SSFF01.
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  ENQUEUE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
INCLUDE ztri_ssf_plugin.

FORM enqueue .
  zcl_paymorder_memory_root=>enqueue(
                                 EXCEPTIONS
                                   error = 1 ).
  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid
            TYPE sy-msgty
            NUMBER sy-msgno
            WITH sy-msgv1
                 sy-msgv2
                 sy-msgv3
                 sy-msgv4
            RAISING enqueue_error.
  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  DEQUEUE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM dequeue .
zcl_paymorder_memory_root=>dequeue( ).
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  END
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM end .
  CALL FUNCTION 'ZFM_TR_PAYMORDER_SSF_BUFF_DEL'
    DESTINATION 'NONE' "避免影响主程序的更新
    EXPORTING
      im_datum = sy-datum
      im_uname = sy-uname.
  PERFORM dequeue.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  START
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM start CHANGING c_activate type flag.
  IF zcl_captical_encryptor=>check_act_of_client_and_user( )
              = zcl_captical_encryptor=>activation_result_not_active.
    RETURN.
  ENDIF.

c_activate = 'X'.

 PERFORM enqueue.

  CALL FUNCTION 'ZFM_TR_PAYMORDER_SSF_BUFF_DEL'
    DESTINATION 'NONE' "避免影响主程序的更新
    EXPORTING
      im_datum = sy-datum
      im_uname = sy-uname.
  DO 1000 TIMES.
    SELECT COUNT( * ) INTO @DATA(l_count)
           FROM ztrt_paym_ssf
           WHERE uname = @sy-uname
           AND   datum = @sy-datum.
    IF l_count > 0.
      WAIT UP TO 1 SECONDS.
      CLEAR l_count.
    ELSE.
      EXIT.
    ENDIF.
  ENDDO.
ENDFORM.
