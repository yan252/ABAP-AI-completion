FUNCTION ZFM_TR_UPD_BANK_IND_TO_BNKA.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     VALUE(IM_BANKS) TYPE  BNKA-BANKS
*"     VALUE(IM_BANKL) TYPE  BNKA-BANKL
*"     VALUE(IM_BANK_IND) TYPE  BNKA-BANK_IND
*"--------------------------------------------------------------------
DO 1000 TIMES.
    SELECT SINGLE * INTO @DATA(ls_bnka)
            FROM bnka
            WHERE banks = @im_banks
            AND   bankl = @im_bankl.
    IF sy-subrc = 0.
      DATA(l_exist) = 'X'.
      EXIT.
    ELSE.
      WAIT UP TO 1 SECONDS.
    ENDIF.
  ENDDO.

WAIT UP TO 5 SECONDS.

  UPDATE bnka SET bank_ind = im_bank_ind
              WHERE banks = im_banks
              AND   bankl = im_bankl.

  COMMIT WORK AND WAIT.





ENDFUNCTION.
