FUNCTION ZFM_TR_PAYMORD_BUFFER_TO_RANGE.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  EXPORTING
*"     REFERENCE(ET_RANGE) TYPE  ZTRT_PAYMORDER_RANGE
*"--------------------------------------------------------------------
LOOP AT gt_paymorder_buffer INTO DATA(ls_buffer).
    APPEND VALUE #( sign = 'I'
                    option = 'EQ'
                    low = ls_buffer-docno )
           TO et_range.
  ENDLOOP.





ENDFUNCTION.
