*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZTRT9010TOP.                      " Global Declarations
  INCLUDE LZTRT9010UXX.                      " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZTRT9010F...                      " Subroutines
* INCLUDE LZTRT9010O...                      " PBO-Modules
* INCLUDE LZTRT9010I...                      " PAI-Modules
* INCLUDE LZTRT9010E...                      " Events
* INCLUDE LZTRT9010P...                      " Local class implement.
* INCLUDE LZTRT9010T99.                      " ABAP Unit tests
  INCLUDE LZTRT9010F00                            . " subprograms
  INCLUDE LZTRT9010I00                            . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules

INCLUDE lztrt9010i01.
