FUNCTION ZTR_DECIMALS_ROUND.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     VALUE(DECIMALS) DEFAULT 0
*"     VALUE(INPUT)
*"  EXPORTING
*"     VALUE(OUTPUT)
*"  EXCEPTIONS
*"      INPUT_INVALID
*"--------------------------------------------------------------------
DATA n TYPE decfloat16.
  DATA m TYPE decfloat16.
  DATA: t,v,index.

  DESCRIBE FIELD input TYPE t.
  IF t NE 'F' AND t NE 'P' AND t NE 'I' AND t NE '8'
              AND t NE 'a' AND t NE 'e'.
    MESSAGE e460(ztr02) WITH 'INPUT' RAISING input_invalid.   "校验INPUT输入的值必须是数值类型
  ENDIF.

  index = decimals + 1.
  input = input * ( 10 ** index ).
  n = trunc( input ).   "取整数
  m = COND #( WHEN n > 0 THEN n MOD 10 WHEN n < 0 THEN n * ( -1 ) MOD 10 ).
  IF m GE 5.
    n = COND #( WHEN n > 0 THEN n + 10 - m WHEN n < 0 THEN n - 10 + m ). "四舍五入，考虑正数和负数不同情况
  ELSE.
    n = COND #( WHEN n > 0 THEN n - m WHEN n < 0 THEN n + m ).
  ENDIF.

  output = n / ( 10 ** index ).





ENDFUNCTION.
