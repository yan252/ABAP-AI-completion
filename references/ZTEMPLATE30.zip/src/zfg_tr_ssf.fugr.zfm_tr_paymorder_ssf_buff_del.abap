FUNCTION ZFM_TR_PAYMORDER_SSF_BUFF_DEL.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     VALUE(IM_DATUM) TYPE  SYDATUM
*"     VALUE(IM_UNAME) TYPE  SYUNAME
*"--------------------------------------------------------------------
DELETE FROM ztrt_paym_ssf WHERE uname = im_uname
                            AND   datum = im_datum.

  DELETE FROM ztrt2001_ssf WHERE uname = im_uname
                            AND   datum = im_datum.


  DELETE FROM ztrt2101_ssf WHERE uname = im_uname
                            AND   datum = im_datum.

  DELETE FROM ztrt2002_ssf WHERE uname = im_uname
                            AND   datum = im_datum.

  DELETE FROM ztrt2003_ssf WHERE uname = im_uname
                            AND   datum = im_datum.

  COMMIT WORK AND WAIT.





ENDFUNCTION.
