class ZCL_BANK_FILE_ADJUSTER_ICBC definition
  public
  inheriting from ZCL_BANK_FILE_ADJUSTER
  final
  create public .

public section.

  types:
    BEGIN OF type_s_exception_ind,
             sign_process type flag,
             value TYPE string,
             result_message_prefix type string,
             result_code type string,
           END OF type_s_exception_ind .
  types:
    type_t_exception_ind TYPE STANDARD TABLE OF type_s_exception_ind
                     WITH DEFAULT KEY .

  class-methods CLASS_CONSTRUCTOR .

  methods ZIF_RESPONSE_FILE_ADJUSTER~ADJUST
    redefinition .
  methods ZIF_SENDING_FILE_ADJUSTER~ADJUST
    redefinition .
protected section.
private section.

  class-data EXCEPTION_INDICATORS type TYPE_T_EXCEPTION_IND .

  methods ADJUST_SENDING_FILES_GENERAL
    importing
      !IM_ACTION type ZTR_APP_ACTION_FOR_BANK
      !IM_STEP type ZTR_APP_ACTION_STEP
    changing
      !CH_DATA type ZTRS_BANK_SENDING_FILE_TAB .
  methods ADJUST_PAYMENT_FILES
    importing
      !IM_ACTION type ZTR_APP_ACTION_FOR_BANK
      !IM_STEP type ZTR_APP_ACTION_STEP
    changing
      !CH_DATA type ZTRS_BANK_SENDING_FILE_TAB .
  methods ADJUST_SENDING_FILE_CORE
    importing
      !IM_STEP type ZTR_APP_ACTION_STEP
      !IM_PACKAGE_ID type CLIKE
      !IM_ACTION type ZTR_APP_ACTION_FOR_BANK
    changing
      !CH_STRING type STRING
      !CH_XSTRING type XSTRING .
  methods GET_CURRENT_PACKAGE_ID
    importing
      !IM_STEP type ZTR_APP_ACTION_STEP
    returning
      value(RE_PACKAGE_ID) type STRING .
  methods ADJUST_SIGN_OKAY_RESPONSE
    importing
      !IM_STEP type ZTR_APP_ACTION_STEP
      !IM_ORIGINAL_CDATA type ANY
    exporting
      !EX_CDATA type ANY
      !EX_XDATA type ANY
      !EX_T_RETURN type BAPIRET2_TAB .
  methods ADJUST_GENERAL_OKAY_RESPONSE
    importing
      !IM_STEP type ZTR_APP_ACTION_STEP
      !IM_ACTION type ZTR_APP_ACTION_FOR_BANK
      !IM_ORIGINAL_CDATA type ANY
      !IM_ORIGINAL_XDATA type ANY
    exporting
      !EX_CDATA type ANY
      !EX_XDATA type ANY
      !EX_T_RETURN type BAPIRET2_TAB .
  methods BUILD_EXCEPTION_XML
    importing
      !IM_ERRORSTRING_NODE_VALUE type CLIKE
      !IM_RESULT_MESSAGE type CLIKE
      !IM_RESULT_CODE type CLIKE
      !IM_STEP type ZTR_APP_ACTION_STEP
    exporting
      !EX_CDATA type STRING
      !EX_XDATA type XSTRING .
  methods FILTER_EXCEPTION_RESPONSE
    importing
      !IM_ACTION type ZTR_APP_ACTION_FOR_BANK
      !IM_STEP type ZTR_APP_ACTION_STEP
      !IM_ORIGINAL_CDATA type ANY
      !IM_ORIGINAL_XDATA type ANY
    exporting
      !EX_CDATA type ANY
      !EX_XDATA type ANY
      !EX_HAS_EXCEPTION_RESPONSE type FLAG .
  methods IF_SIGN_STEP
    importing
      !IM_ACTION type ZTR_APP_ACTION_FOR_BANK
      !IM_STEP type ZTR_APP_ACTION_STEP
    returning
      value(RE_SIGN_STEP) type FLAG .
ENDCLASS.



CLASS ZCL_BANK_FILE_ADJUSTER_ICBC IMPLEMENTATION.


METHOD adjust_general_okay_response.
    DATA: l_response_xml   TYPE string,
          l_pattern_data   TYPE string,
          l_response_xml_x TYPE xstring.

    SPLIT im_original_cdata
         AT zif_icbc_constant=>xml_okay_prefix_code
        INTO l_pattern_data
             l_response_xml.

    ex_cdata = l_response_xml.

    CALL FUNCTION 'SSFC_BASE64_DECODE'
      EXPORTING
        b64data                  = l_response_xml
      IMPORTING
        bindata                  = ex_xdata
      EXCEPTIONS
        ssf_krn_error            = 1
        ssf_krn_noop             = 2
        ssf_krn_nomemory         = 3
        ssf_krn_opinv            = 4
        ssf_krn_input_data_error = 5
        ssf_krn_invalid_par      = 6
        ssf_krn_invalid_parlen   = 7
        OTHERS                   = 8.
    IF sy-subrc <> 0.
*  这一步不应该有错误，继续执行
      return.
    ENDIF.


  ENDMETHOD.


METHOD adjust_payment_files.
    FIELD-SYMBOLS: <ft_payment_entries> TYPE ztrs_payment_entry_tab.


    DATA(l_signed_entries_ref) = get_current_sending_data_ref( im_step ).

    ASSIGN l_signed_entries_ref->* TO <ft_payment_entries>.

    LOOP AT ch_data ASSIGNING FIELD-SYMBOL(<fs_sending_file>).
      ASSIGN <fs_sending_file>-cfile->* TO FIELD-SYMBOL(<f_string>).
      ASSIGN <fs_sending_file>-xfile->* TO FIELD-SYMBOL(<f_xstring>).

      READ TABLE <ft_payment_entries> INTO DATA(ls_sending_data)
           WITH KEY seqnumber = <fs_sending_file>-sending_sequence.
      IF sy-subrc = 0.
        adjust_sending_file_core(
                  EXPORTING
                    im_action = im_action
                    im_step = im_step
                    im_package_id = ls_sending_data-doc1r
                 CHANGING
                   ch_string = <f_string>
                   ch_xstring = <f_xstring> ).
      ELSE.
*          不可能出现的错误，除非程序有BUG
*          这个错误应该在测试期间就被排除
*          否则不可能能投入生产
        MESSAGE x312(ztr_bank_application)
                WITH <fs_sending_file>-sending_sequence.
      ENDIF.

    ENDLOOP.

  ENDMETHOD.


METHOD adjust_sending_files_general.
    LOOP AT ch_data ASSIGNING FIELD-SYMBOL(<fs_sending_file>).
      ASSIGN <fs_sending_file>-cfile->* TO FIELD-SYMBOL(<f_string>).
      ASSIGN <fs_sending_file>-xfile->* TO FIELD-SYMBOL(<f_xstring>).
      adjust_sending_file_core(
                EXPORTING
                  im_action     = im_action
                  im_step       = im_step
                  im_package_id = zcl_icbc_enhancement=>get_packageid_from_sending_xml(
                                                           im_xml_string  = <f_string>
                                                           im_xml_xstring = <f_xstring> )
               CHANGING
                 ch_string      = <f_string>
                 ch_xstring     = <f_xstring> ).
    ENDLOOP.
  ENDMETHOD.


METHOD adjust_sending_file_core.
    DATA: l_real_xstring  TYPE xstring,
          l_encode_string TYPE string.

    CASE im_action.
      WHEN '001'.
*    支付
        ch_string = zcl_icbc_enhancement=>build_post_file_prefix(
                                        im_transactioncode = zcl_bank_enviroment=>create(
                                                                       im_bank_indicator = bank_indicator
                                                                       im_action = im_action
                                                                              )->get_single_step( im_step
                                                                                       )-bank_func
                                        im_package_id = im_package_id
                                        im_file_version = zif_icbc_constant=>file_version
                                        im_bank_code = zif_icbc_constant=>bank_code ) &&
                                        ch_string .
      WHEN OTHERS.
*        其他（一般是查询类）
        DATA(l_leading_string) = zcl_icbc_enhancement=>build_post_file_prefix(
                                        im_transactioncode = zcl_bank_enviroment=>create(
                                                                       im_bank_indicator = bank_indicator
                                                                       im_action = im_action
                                                                              )->get_single_step( im_step
                                                                                       )-bank_func
                                        im_package_id = im_package_id
                                        im_file_version = zif_icbc_constant=>file_version
                                        im_bank_code = zif_icbc_constant=>bank_code ).


        l_encode_string  = cl_http_utility=>escape_url( ch_string ).


        ch_string = l_leading_string && l_encode_string.

    ENDCASE.

    CALL FUNCTION 'SCMS_STRING_TO_XSTRING'
      EXPORTING
        text   = ch_string
      IMPORTING
        buffer = ch_xstring
      EXCEPTIONS
        failed = 1
        OTHERS = 2.
    IF sy-subrc <> 0.
*let it be
      return.
    ENDIF.

  ENDMETHOD.


METHOD adjust_sign_okay_response.
    DATA: l_first_xml_part TYPE string,
          l_last_xml_part  TYPE string,
          l_position       TYPE i.
    CONSTANTS: c_sign_step              TYPE ztrt_action_step-step VALUE '001'. "签名步骤

    ex_cdata = im_original_cdata.

    REPLACE ALL OCCURRENCES OF cl_abap_char_utilities=>cr_lf
            IN ex_cdata
            WITH space.

    CONDENSE ex_cdata NO-GAPS.

    FIND FIRST OCCURRENCE OF zif_icbc_constant=>result_element_suffix
                   IN ex_cdata
                   MATCH OFFSET l_position.
    IF sy-subrc = 0.
      l_position = l_position + strlen( zif_icbc_constant=>result_element_suffix ).
      l_first_xml_part = ex_cdata+0(l_position).
      l_last_xml_part = ex_cdata+l_position.
    ENDIF.

    ex_cdata =
                l_first_xml_part && "the first part of original xml

*                for example <fseqno>1500000000</fseqno>
                zif_icbc_constant=>fseqno_element_prefix &&
                get_current_package_id( im_step ) &&
                zif_icbc_constant=>fseqno_element_suffix &&

*                for example <resultCode>SSSSS</resultCode>
                zif_icbc_constant=>resultcode_element_prefix &&
                zif_icbc_constant=>resultcode_for_sign_ok &&
                zif_icbc_constant=>resultcode_element_suffix &&

*                for example <resultMsg>SIGN Process Okay</resultMsg>
                zif_icbc_constant=>resultmsg_element_prefix &&
                zif_icbc_constant=>resultmsg_for_sign_ok &&
                zif_icbc_constant=>resultmsg_element_suffix &&


                l_last_xml_part . "the last part of original xml
  ENDMETHOD.


METHOD build_exception_xml.
    DATA(ls_exception) = VALUE ztrs_icbc_exception_response(
                                  errorstring = im_errorstring_node_value
                                  fseqno = get_current_package_id( im_step )
                                  resultcode = im_result_code
                                  resultmsg = im_result_message
                                 ).

    CALL TRANSFORMATION zbank_cn_icbc_exception_error
              SOURCE input = ls_exception
              RESULT XML ex_cdata.
*    convert to xstring
    ex_xdata = cl_abap_codepage=>convert_to( ex_cdata ).

  ENDMETHOD.


METHOD class_constructor.
    exception_indicators =  VALUE #(
*                                报文签名的异常反馈标志
                                     ( sign_process = 'X'
                                       value = zif_icbc_constant=>xml_error_prefix_code
                                       result_message_prefix = zif_icbc_constant=>resultmsg_for_sign_error
                                       result_code = zif_icbc_constant=>sign_error_code )
                                     ( sign_process = 'X'
                                       value = zif_icbc_constant=>transform_failed_error_ind
                                       result_message_prefix = zif_icbc_constant=>resultmsg_for_sign_error
                                       result_code = zif_icbc_constant=>sign_error_code )

*                                       一般交易异常反馈标志
                                     ( sign_process = space
                                       value = zif_icbc_constant=>xml_error_prefix_code
                                       result_message_prefix = zif_icbc_constant=>resultmsg_for_tranx_error
                                       result_code = zif_icbc_constant=>tranx_error_code )
                                     ( sign_process = space
                                       value = zif_icbc_constant=>transform_failed_error_ind
                                       result_message_prefix = zif_icbc_constant=>resultmsg_for_tranx_error
                                       result_code = zif_icbc_constant=>tranx_error_code )
                                   ).

    SORT exception_indicators BY sign_process value.
    DELETE ADJACENT DUPLICATES FROM exception_indicators COMPARING sign_process
                                                                   value.

  ENDMETHOD.


METHOD filter_exception_response.
    LOOP AT exception_indicators INTO DATA(ls_exception_indicator)
             WHERE sign_process = if_sign_step( im_action = im_action
                                                im_step = im_step ).
      FIND FIRST OCCURRENCE OF ls_exception_indicator-value
                     IN im_original_cdata.
      IF sy-subrc = 0.
*        返回报文异常，
*        目前只发现errorCode或Transform Failed的情况
*        不可能同时返回这两个异常
*        如果后续发现有新的异常，请在 CLASS-CONTRUCTOR里添加
        ex_has_exception_response = 'X'.

        build_exception_xml(
                 EXPORTING
                    im_errorstring_node_value = ls_exception_indicator-value
                    im_result_message = ls_exception_indicator-result_message_prefix && im_original_cdata
                    im_result_code = ls_exception_indicator-result_code
                    im_step = im_step
                 IMPORTING
                    ex_cdata = ex_cdata
                    ex_xdata = ex_xdata ).

        EXIT."im_original_cdata只可能有一个值，因此退出
      ENDIF.
    ENDLOOP.
  ENDMETHOD.


METHOD get_current_package_id.
    DATA: lo_function TYPE REF TO zif_icbc_function.

    DATA(lo_general_function) =
               zcl_bank_abstract_action=>get_action(                    "get current running action
                                 )->get_bank( bank_indicator         "get current running bank
                                            )->get_bank_function( im_step ). "get run function by step number.
    lo_function ?= lo_general_function.

    re_package_id = lo_function->get_current_package_id( ).
  ENDMETHOD.


METHOD if_sign_step.
    IF im_action = '001' AND "支付操作
       im_step = '001'. "支付的签名步骤
*      只有支付的情况才有报文签名
      re_sign_step = 'X'.
    ELSE.
      re_sign_step = space.
    ENDIF.
  ENDMETHOD.


METHOD zif_response_file_adjuster~adjust.

    filter_exception_response(
              EXPORTING
                im_action = im_action
                im_step = im_step
                im_original_cdata = im_original_cdata
                im_original_xdata = im_original_xdata
              IMPORTING
                ex_cdata = ex_cdata
                ex_xdata = ex_xdata
                ex_has_exception_response = DATA(l_has_exception_response) ).

    IF l_has_exception_response = 'X'.
*      已经发现异常反馈，不可能有其他情况了，因此退出
      RETURN.
    ENDIF.

*    运行到此处起码签名反馈是正常的
    IF if_sign_step( im_action = im_action
                     im_step = im_step ) = 'X'.
*  签名步骤
      adjust_sign_okay_response(
                EXPORTING
*                  im_action = im_action
                  im_step = im_step
                  im_original_cdata = im_original_cdata
*                  im_original_xdata = im_original_xdata
                IMPORTING
                  ex_cdata = ex_cdata
                  ex_xdata = ex_xdata
                  ex_t_return = ex_t_return ).
    ELSE.
      adjust_general_okay_response(
                EXPORTING
                  im_action = im_action
                  im_step = im_step
                  im_original_cdata = im_original_cdata
                  im_original_xdata = im_original_xdata
                IMPORTING
                  ex_cdata = ex_cdata
                  ex_xdata = ex_xdata
                  ex_t_return = ex_t_return ).
    ENDIF.
  ENDMETHOD.


METHOD zif_sending_file_adjuster~adjust.
    CASE im_action.
      WHEN '001'.
*        支付业务
        IF im_step = '002'.
*          只有实际支付步骤002才需要调整，签名步骤001不需要调整
          adjust_payment_files(
                    EXPORTING
                      im_action = im_action
                      im_step = im_step
*                    IMPORTING
*                      ex_t_return = ex_t_return
                    CHANGING
                      ch_data = ch_data ).
        ENDIF.
      WHEN OTHERS.
*        其他业务，目前一般是查询类
          adjust_sending_files_general(
                    EXPORTING
                      im_action = im_action
                      im_step = im_step
*                    IMPORTING
*                      ex_t_return = ex_t_return
                    CHANGING
                      ch_data = ch_data ).
    ENDCASE.

  ENDMETHOD.
ENDCLASS.
