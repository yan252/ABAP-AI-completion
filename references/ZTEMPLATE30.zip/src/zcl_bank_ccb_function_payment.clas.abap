class ZCL_BANK_CCB_FUNCTION_PAYMENT definition
  public
  inheriting from ZCL_BANK_FUNCTION_PAYMENT
  final
  create public .

public section.
protected section.

  methods PROCESSING_RESPONSE_INTL_CORE
    redefinition .
private section.
ENDCLASS.



CLASS ZCL_BANK_CCB_FUNCTION_PAYMENT IMPLEMENTATION.


METHOD processing_response_intl_core.
    FIELD-SYMBOLS: <ft_sending_entries> TYPE ztrs_payment_entry_tab.
    FIELD-SYMBOLS: <fs_response>        TYPE ztrs_ccb_payment_response.
    DATA: ls_bank_payment_return TYPE ztrs_payment_bank_return.


    super->processing_response_intl_core( ).

    ASSIGN sending_data_reference->* TO <ft_sending_entries>.
    READ TABLE <ft_sending_entries> INTO DATA(ls_sending_entry)
         WITH KEY seqnumber = current_sending_sequence.
    IF sy-subrc <> 0.
*      unexpected error
      MESSAGE x091(ztr_bank_application)
              WITH function_config-bank_func
                   current_sending_sequence.
    ENDIF.

    DATA(ls_response_data) = get_current_response_data( ).
    ASSIGN ls_response_data-response_ref->* TO <fs_response>.

    MOVE: <fs_response>-header-return_code TO ls_bank_payment_return-header-bank_rtncode,
          <fs_response>-item-deal_type TO ls_bank_payment_return-header-bank_rtnflg,
          <fs_response>-header-return_msg TO ls_bank_payment_return-header-bank_rtnmsg.
    APPEND VALUE #( paymorder = ls_sending_entry-paymorder
                    doc1r = ls_sending_entry-paymorder
                    bank_rtncode = <fs_response>-header-return_code
                    bank_rtnmsg = <fs_response>-header-return_msg
                    bank_rtnflg = <fs_response>-item-deal_type
                    bank_tran_number = <fs_response>-item-credit_no )
                 TO ls_bank_payment_return-items.

    update_status_in_instance( ls_bank_payment_return ).

  ENDMETHOD.
ENDCLASS.
