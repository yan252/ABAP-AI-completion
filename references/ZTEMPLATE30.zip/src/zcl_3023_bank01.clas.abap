class ZCL_3023_BANK01 definition
  public
  inheriting from ZCL_3023_BANK
  final
  create public .

public section.
protected section.
private section.
ENDCLASS.



CLASS ZCL_3023_BANK01 IMPLEMENTATION.
ENDCLASS.
