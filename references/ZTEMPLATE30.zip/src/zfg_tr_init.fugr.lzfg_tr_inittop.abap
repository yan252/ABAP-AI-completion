FUNCTION-POOL ZFG_TR_INIT.                  "MESSAGE-ID ..

* INCLUDE LZFG_TR_INITD...                   " Local class definition
