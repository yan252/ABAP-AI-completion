FUNCTION ZFM_TR_BANK_MEDIUM_PAYMORD_STA.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     VALUE(IM_T_ORDER_LIST) TYPE  ZTRS_PAYMENTORDER_LIST_TAB
*"  EXPORTING
*"     REFERENCE(EX_T_ORDER_STATUS) TYPE  ZTRS_PAYMENTORDER_STATUS_TAB
*"--------------------------------------------------------------------
##TOO_MANY_ITAB_FIELDS
  SELECT * INTO CORRESPONDING FIELDS OF TABLE ex_t_order_status
           FROM ztrv_pymord_view
           FOR ALL ENTRIES IN im_t_order_list
           WHERE paymorder = im_t_order_list-paymorder
           AND   draft_zxh = im_t_order_list-draft_zxh.

  IF ex_t_order_status[] IS INITIAL."查询时刚好银企在进行支付，表里还没存数据，等一秒再查一次
    WAIT UP TO 1 SECONDS.
    SELECT * INTO CORRESPONDING FIELDS OF TABLE ex_t_order_status
             FROM ztrv_pymord_view
             FOR ALL ENTRIES IN im_t_order_list
             WHERE paymorder = im_t_order_list-paymorder
             AND   draft_zxh = im_t_order_list-draft_zxh.

  ENDIF.
*  IF im_t_order_list is NOT INITIAL and
*     lines( im_t_order_list ) <> lines( ex_t_order_status ).
*    MESSAGE e097(ztr_bank_application).
*  ENDIF.
  LOOP AT im_t_order_list  INTO DATA(ls_imp_list).
    READ TABLE ex_t_order_status INTO DATA(ls_exp_list)
          WITH KEY paymorder = ls_imp_list-paymorder
                   draft_zxh = ls_imp_list-draft_zxh.
    IF sy-subrc <> 0.
      CLEAR ls_exp_list.
      ls_exp_list-paymorder = ls_imp_list-paymorder.
      ls_exp_list-notfound = 'X'.
      APPEND ls_exp_list TO ex_t_order_status.
    ENDIF.
  ENDLOOP.





ENDFUNCTION.
