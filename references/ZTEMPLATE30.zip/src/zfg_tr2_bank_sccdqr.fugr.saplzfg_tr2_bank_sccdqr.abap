*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_TR2_BANK_SCCDQRTOP.           " Global Declarations
  INCLUDE LZFG_TR2_BANK_SCCDQRUXX.           " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_TR2_BANK_SCCDQRF...           " Subroutines
* INCLUDE LZFG_TR2_BANK_SCCDQRO...           " PBO-Modules
* INCLUDE LZFG_TR2_BANK_SCCDQRI...           " PAI-Modules
* INCLUDE LZFG_TR2_BANK_SCCDQRE...           " Events
* INCLUDE LZFG_TR2_BANK_SCCDQRP...           " Local class implement.
* INCLUDE LZFG_TR2_BANK_SCCDQRT99.           " ABAP Unit tests
