FUNCTION ZFM_TR2_BANK_DBLBCX_TX_BOC.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     REFERENCE(LT_IN) TYPE  ZLTTR2_BANK_DBLBCX_TX_IN
*"  EXPORTING
*"     REFERENCE(LT_OUT) TYPE  ZLTTR2_BANK_DBLBCX_TX_OUT1
*"--------------------------------------------------------------------
****单条数据查询-查贴现率

  TYPES:BEGIN OF ty_datescope,
          from TYPE string,
          to   TYPE string,
        END OF ty_datescope.
  TYPES:BEGIN OF ty_b2e0102,
          actacn    TYPE string,
          querytype TYPE string,
          begnum    TYPE string,
          draftno   TYPE string,
          acttyp    TYPE string,
          drafttype TYPE string,
          datescope TYPE ty_datescope,
          payeeactn TYPE string,
        END OF ty_b2e0102.
  DATA:ls_b2e0102-send TYPE ty_b2e0102.
  DATA:BEGIN OF ls_bocserch,
         b2e0102-rq TYPE ty_b2e0102 OCCURS 0,
       END OF ls_bocserch.
  DATA:response TYPE string.
  TYPES:BEGIN OF ly_sch1,
          rspcod       TYPE string,
          rspmsg       TYPE string,
          seqnum       TYPE string,
          msgseq       TYPE string,
          orinseq      TYPE string,
          cliorg       TYPE string,
          draftno      TYPE string,
          amount       TYPE string,
          date         TYPE string,
          status       TYPE string,
          duedate      TYPE string,
          draweename   TYPE string,
          acceptorname TYPE string,
          toname       TYPE string,
          applyname    TYPE string,
          drafttype    TYPE string,
          draweeacn    TYPE string,
          acceptoracn  TYPE string,
          toacn        TYPE string,
          tramt        TYPE string,
          rdsrat       TYPE string,
        END OF ly_sch1.

  DATA:ls_sch1 TYPE ly_sch1.
  DATA:BEGIN OF ls_response1,
         totalnum   TYPE string,
         rspcod     TYPE string,
         rspmsg     TYPE string,
         b2e0102-rs TYPE ly_sch1 OCCURS 0,
       END OF ls_response1.
  DATA: lv_calc_lins TYPE i.
  DATA:lv_exit  TYPE c,
       lv_begin TYPE i,
       lv_lines TYPE i.
  DATA:lv_flag TYPE c.
  DATA(lo_xml) = NEW zcl_tr2_xml( ).

  DATA: ls_out1 TYPE ztr2s_bank_dblbcx_tx_out.
  DATA: ls_out TYPE ztr2s_bank_dblbcx_tx_out1.

  LOOP AT lt_in INTO DATA(ls_in) WHERE bank_ind = 'BOC'."中行
    CLEAR :lv_exit ,
           lv_begin,
           lv_lines,
           lv_flag,
           ls_b2e0102-send,
           ls_bocserch.

    "一条数据最多返回50个查询结果，每次需要修改起止位置才行
    "A8和C3的都要查询
    WHILE lv_exit IS INITIAL.
      IF lv_begin IS INITIAL .
        lv_begin = 1.
      ENDIF.
      ls_b2e0102-send-actacn = ls_in-actacn.
      ls_b2e0102-send-querytype = ls_in-querytype.
      ls_b2e0102-send-draftno = ls_in-draftno.
      ls_b2e0102-send-payeeactn = ls_in-payeeactn.
      ls_b2e0102-send-acttyp = ls_in-acttyp.
      ls_b2e0102-send-drafttype = ls_in-drafttype.
      ls_b2e0102-send-begnum = lv_begin.
      APPEND ls_b2e0102-send TO ls_bocserch-b2e0102-rq.

      """""""这里的动作标识记得修改
      CALL FUNCTION 'ZFM_TR2_BANK_SEND'
        EXPORTING
          bank_ind    = 'BOC'
          bank_action = '011'
          data_in     = ls_bocserch
          method      = 'POST'
        IMPORTING
          response    = response.
      CLEAR ls_bocserch.
      lo_xml->convert_xml_to_abap( EXPORTING response = response bank_ind = 'BOC'
                                              bank_action = '011' IMPORTING data = ls_response1 ).

      LOOP AT ls_response1-b2e0102-rs  INTO ls_sch1.
        ls_out1-msgseq = ls_sch1-msgseq.
        ls_out1-draftno = ls_sch1-draftno.
        ls_out1-rspmsg = ls_sch1-rspmsg.
        ls_out1-rspcod = ls_sch1-rspcod.
        ls_out1-rdsrat = ls_sch1-rdsrat.
        ls_out1-STATUS = ls_sch1-STATUS.
        APPEND ls_out1 TO ls_out-b2e0102.
        ls_out-rspcod = ls_sch1-rspcod.
        ls_out-rspmsg = ls_sch1-rspmsg.
        CLEAR: ls_out1.
      ENDLOOP.

      if ls_out-rspcod is INITIAL.
      ls_out-rspcod = ls_response1-rspcod.
      ls_out-rspmsg = ls_response1-rspmsg.
      ENDIF.
      APPEND ls_out TO lt_out.
      IF sy-subrc <> 0.
        lv_flag = 'X'.
        EXIT.
      ELSE.
        REFRESH ls_response1-b2e0102-rs.
        CLEAR:response, ls_response1.
        lv_calc_lins = 50 + lv_calc_lins.
        IF ls_response1-totalnum - lv_calc_lins <= 0.
          lv_exit = 'X'.
        ELSE.
          lv_begin = lv_begin + 50.
        ENDIF.
      ENDIF.
    ENDWHILE.
  ENDLOOP.





ENDFUNCTION.
