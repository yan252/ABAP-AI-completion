*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_TR2_BANK_DQZHTOP.             " Global Declarations
  INCLUDE LZFG_TR2_BANK_DQZHUXX.             " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_TR2_BANK_DQZHF...             " Subroutines
* INCLUDE LZFG_TR2_BANK_DQZHO...             " PBO-Modules
* INCLUDE LZFG_TR2_BANK_DQZHI...             " PAI-Modules
* INCLUDE LZFG_TR2_BANK_DQZHE...             " Events
* INCLUDE LZFG_TR2_BANK_DQZHP...             " Local class implement.
* INCLUDE LZFG_TR2_BANK_DQZHT99.             " ABAP Unit tests
