class ZCL_PAYMENTENTRY_EDOC_CHECKER definition
  public
  final
  create public .

public section.

  methods CONSTRUCTOR
    importing
      !IM_ACTION type ZTR_APP_ACTION_FOR_BANK
      !IM_S_PAYMENT_ENTRY type ZTRT_PAYMENT .
  methods CHECK
    returning
      value(RT_MESSAGES) type ZTAB_BAPIRET2 .
protected section.
private section.

  data ACTION type ZTR_APP_ACTION_FOR_BANK .
  data PAYMENT_ENTRY type ZTRT_PAYMENT .
  data MESSAGES type ref to ZCL_MESSAGE_COLLECTOR .
  data DUMMY_MESSAGE type STRING .
  constants YES type FLAG value 'X' ##NO_TEXT.
  constants NO type FLAG value SPACE ##NO_TEXT.

  methods CHECK_BSKL .
  methods CHECK_DUEDATE .
  methods CHECK_DRAFTTYPE .
  methods CHECK_MASTER_FOR_ENDORSEMENT .
ENDCLASS.



CLASS ZCL_PAYMENTENTRY_EDOC_CHECKER IMPLEMENTATION.


METHOD CHECK.
    check_bskl( ).
    check_duedate( ).
    check_drafttype( ).
    IF payment_entry-draft_zbskl = 'A'.
      check_master_for_endorsement( ).
    ENDIF.

    messages->publish_messages(
                    EXPORTING
                      i_published_mode = messages->internal_mode
                    IMPORTING
                      et_messages = rt_messages ).

  ENDMETHOD.


METHOD check_bskl.
    DATA: l_error TYPE flag.

    IF payment_entry-draft_zbskl IS INITIAL.
      MESSAGE e271(ztr_bank_application)
              WITH payment_entry-entuuid
                   payment_entry-paymorder
              INTO dummy_message.
      messages->add_system_message( sy ).
      RETURN.
    ENDIF.

    CASE action.
      WHEN zif_bank_action=>action_is_create_edoc.
*        开立汇票
        IF payment_entry-draft_zbskl <> 'B'.
          l_error = yes.
        ENDIF.
      WHEN zif_bank_action=>action_is_edoc_endorsement.
*        背书
        IF payment_entry-draft_zbskl <> 'A'.
          l_error = yes.
        ENDIF.
      WHEN OTHERS.
        l_error = yes.
    ENDCASE.

    IF l_error = yes.
      MESSAGE e272(ztr_bank_application)
              WITH action
                   payment_entry-paymorder
                   payment_entry-draft_zbskl
              INTO dummy_message.
      messages->add_system_message( sy ).
      RETURN.
    ENDIF.
  ENDMETHOD.


METHOD check_drafttype.
    IF payment_entry-drafttype IS INITIAL.
      MESSAGE e274(ztr_bank_application)
              WITH payment_entry-entuuid
                   payment_entry-paymorder
                  payment_entry-draft_zxh
              INTO dummy_message.
      messages->add_system_message( sy ).
      RETURN.
    ENDIF.


    CASE payment_entry-drafttype.
      WHEN '15'.
*        电子银票
        IF payment_entry-zzffs <> '54'.
          MESSAGE e277(ztr_bank_application)
                  WITH payment_entry-paymorder
                       payment_entry-draft_zxh
                       payment_entry-drafttype
                       payment_entry-zzffs
                  INTO dummy_message.
          messages->add_system_message( sy ).
        ENDIF.
      WHEN '25'.
*        电子商票
        IF payment_entry-zzffs <> '53'.
          MESSAGE e277(ztr_bank_application)
                  WITH payment_entry-paymorder
                       payment_entry-draft_zxh
                       payment_entry-drafttype
                       payment_entry-zzffs
                  INTO dummy_message.
          messages->add_system_message( sy ).
        ENDIF.
      WHEN OTHERS.
        MESSAGE e275(ztr_bank_application)
                WITH payment_entry-entuuid
                     payment_entry-paymorder
                    payment_entry-draft_zxh
                    payment_entry-drafttype
                INTO dummy_message.
        messages->add_system_message( sy ).
    ENDCASE.
  ENDMETHOD.


METHOD check_duedate.
    IF payment_entry-draft_zbskl <> 'B'.
      RETURN.
    ENDIF.

    IF payment_entry-draft_duedate IS INITIAL.
      MESSAGE e273(ztr_bank_application)
              WITH payment_entry-entuuid
                   payment_entry-paymorder
                   payment_entry-draft_zxh
              INTO dummy_message.
      messages->add_system_message( sy ).
    ELSE.
      IF payment_entry-draft_duedate <= sy-datum.
        MESSAGE e276(ztr_bank_application)
                WITH payment_entry-entuuid
                     payment_entry-paymorder
                     payment_entry-draft_zxh
                INTO dummy_message.
        messages->add_system_message( sy ).
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD check_master_for_endorsement.
    IF payment_entry-draft_docno_key IS INITIAL OR
       payment_entry-draft_zjsno IS INITIAL OR
       payment_entry-draft_zpj_no IS INITIAL.
*          数据错误
*          背书的时候应该有汇票的主数据
      MESSAGE e278(ztr_bank_application)
              WITH payment_entry-entuuid
                  payment_entry-paymorder
                  payment_entry-draft_zxh
              INTO dummy_message.
      messages->add_system_message( sy ).
      RETURN.
    ENDIF.

    SELECT SINGLE * INTO @DATA(ls_0070)
           FROM ztrt0070
           WHERE docno_key = @payment_entry-draft_docno_key
           AND   bukrs = @payment_entry-zbukr
           AND   zjsno = @payment_entry-draft_zjsno.
    IF sy-subrc <> 0.
      MESSAGE e279(ztr_bank_application)
              WITH payment_entry-draft_docno_key
                   payment_entry-zbukr
                  payment_entry-draft_zjsno
              INTO dummy_message.
      messages->add_system_message( sy ).
      RETURN.
    ENDIF.

    IF ls_0070-del = yes.
      MESSAGE e280(ztr_bank_application)
              WITH payment_entry-draft_docno_key
                   payment_entry-zbukr
                  payment_entry-draft_zjsno
              INTO dummy_message.
      messages->add_system_message( sy ).
      RETURN.
    ENDIF.

    SELECT MAX( zjsno ) INTO @DATA(l_max_zjsno)
           FROM ztrt0070
           WHERE docno_key = @payment_entry-draft_docno_key
           AND   bukrs = @payment_entry-zbukr
           AND   del = @space.
    IF payment_entry-draft_zjsno <> l_max_zjsno.
      MESSAGE e281(ztr_bank_application)
              WITH payment_entry-draft_docno_key
                   payment_entry-zbukr
                  payment_entry-draft_zjsno
              INTO dummy_message.
      messages->add_system_message( sy ).
      RETURN.
    ENDIF.

    SELECT SINGLE * INTO @DATA(ls_0050)
          FROM ztrt0050
          WHERE docno_key = @payment_entry-draft_docno_key.
    IF sy-subrc <> 0.
      MESSAGE e282(ztr_bank_application)
                  WITH payment_entry-draft_docno_key
                  INTO dummy_message.
      messages->add_system_message( sy ).
      RETURN.
    ENDIF.

    IF ls_0050-draft <> payment_entry-draft_zpj_no.
      MESSAGE e283(ztr_bank_application)
                    WITH payment_entry-draft_docno_key
                         payment_entry-paymorder
                         payment_entry-draft_zxh
                         payment_entry-draft_zpj_no
                    INTO dummy_message.
      messages->add_system_message( sy ).
    ENDIF.

    IF ls_0050-zboety <> payment_entry-drafttype.
      MESSAGE e284(ztr_bank_application)
                    WITH payment_entry-draft_zpj_no
                         payment_entry-drafttype
                         ls_0050-zboety
                    INTO dummy_message.
      messages->add_system_message( sy ).
    ENDIF.

    IF ls_0050-draft_waers <> payment_entry-waers.
      MESSAGE e285(ztr_bank_application)
                    WITH payment_entry-draft_zpj_no
                         payment_entry-paymorder
                         payment_entry-waers
                         ls_0050-draft_waers
                    INTO dummy_message.
      messages->add_system_message( sy ).
    ENDIF.

    IF ls_0050-draft_wrbtr <> payment_entry-rwbtr.
      MESSAGE e286(ztr_bank_application)
                    WITH payment_entry-draft_zpj_no
                         payment_entry-paymorder
                    INTO dummy_message.
      messages->add_system_message( sy ).
    ENDIF.

    SELECT SINGLE * INTO @DATA(ls_0013)
           FROM ztrt0013
           WHERE bukrs = @ls_0070-bukrs
           AND   hbkid = @ls_0070-hbkid
           AND   hktid = @ls_0070-hktid.
    IF sy-subrc <> 0.
      MESSAGE e287(ztr_bank_application)
              WITH ls_0070-bukrs
                   ls_0070-hbkid
                   ls_0070-hktid
              INTO dummy_message.
      RETURN.
    ENDIF.

    IF ls_0013-waers <> payment_entry-waers.
      MESSAGE e288(ztr_bank_application)
              WITH ls_0070-bukrs
                   ls_0070-hbkid
                   ls_0070-hktid
                   payment_entry-waers
              INTO dummy_message.
    ENDIF.

    IF payment_entry-bnks1 IS INITIAL OR
       payment_entry-bnkl1 IS INITIAL OR
       payment_entry-bnkn1 IS INITIAL OR
       payment_entry-bank_ind IS INITIAL.
      MESSAGE e299(ztr_bank_application)
              WITH payment_entry-entuuid
              INTO dummy_message.
    ELSE.
      IF payment_entry-bnks1 <> ls_0013-banks OR
         payment_entry-bnkl1 <> ls_0013-bankl OR
        payment_entry-bnkn1 <> ls_0013-yhzh OR
        payment_entry-bank_ind <> ls_0013-bank_ind.
        MESSAGE e289(ztr_bank_application)
                WITH payment_entry-entuuid
                INTO dummy_message.
      ENDIF.
    ENDIF.

    IF ls_0013-is_yqzl = '0'.
      MESSAGE e290(ztr_bank_application)
              WITH payment_entry-entuuid
                   payment_entry-bnkn1
              INTO dummy_message.
    ENDIF.

  ENDMETHOD.


METHOD constructor.
    action = im_action.
    payment_entry = im_s_payment_entry.
    CREATE OBJECT messages
      EXPORTING
        i_message_key = im_action
        i_class       = 'ZTR_BANK_APPLICATION'.

  ENDMETHOD.
ENDCLASS.
