FUNCTION-POOL ZFG_TR_SSF MESSAGE-ID ztr_bank_application.

* INCLUDE LZFG_TR_SSFD...                    " Local class definition
