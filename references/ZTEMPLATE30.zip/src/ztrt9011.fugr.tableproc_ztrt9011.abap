*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZTRT9011
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZTRT9011            .

  PERFORM TABLEPROC.

ENDFUNCTION.
