FUNCTION ZFM_TR_PAYMORDER_COMPARION_S.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     REFERENCE(IM_DOCNO) TYPE  ZTRT2001-DOCNO
*"     REFERENCE(IM_ZZFTYPE) TYPE  ZTRT2001-ZZFTYPE OPTIONAL
*"  EXCEPTIONS
*"      ERROR
*"--------------------------------------------------------------------
SELECT SINGLE * INTO @DATA(ls_2002)
         FROM ztrt2002
         WHERE docno = @im_docno.

  SELECT SINGLE * INTO @DATA(ls_2003)
         FROM ztrt2003
         WHERE docno = @im_docno.

  IF im_zzftype = 'P004'.
*    保证金
    SELECT SINGLE * INTO @DATA(ls_2101)
           FROM ztrt2101
           WHERE docno = @im_docno.
    zcl_captical_encryptor=>do_paymorder_ssfcomparing_004(
                            EXPORTING
                              im_s_2101 = ls_2101
                              im_s_2002 = ls_2002
                              im_s_2003 = ls_2003
                            EXCEPTIONS
                              error = 1 ).
  ELSE.
    SELECT SINGLE * INTO @DATA(ls_2001)
           FROM ztrt2001
           WHERE docno = @im_docno.

    zcl_captical_encryptor=>do_paymorder_ssfcomparing(
                            EXPORTING
                              im_s_2001 = ls_2001
                              im_s_2002 = ls_2002
                              im_s_2003 = ls_2003
                            EXCEPTIONS
                              error = 1 ).
  ENDIF.

  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid
            TYPE 'E'
            NUMBER sy-msgno
            WITH sy-msgv1
                 sy-msgv2
                 sy-msgv3
                 sy-msgv4
                 RAISING error.
  ENDIF.





ENDFUNCTION.
