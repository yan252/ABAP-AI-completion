FUNCTION ZFM_TR_VIEW_ZFD.
**"--------------------------------------------------------------------
**"*"局部接口：
**"  IMPORTING
**"     REFERENCE(IV_DOCNO) TYPE  ZTR_ZFDOCNO
**"  EXPORTING
**"     REFERENCE(EV_MSG) TYPE  STRING
**"--------------------------------------------------------------------
*DATA: ls_param TYPE ihttpnvp,
*        lt_param TYPE tihttpnvp,
*        lv_app   TYPE wdy_application_name.
*
**非保证金
*  SELECT SINGLE zzftype,zywtype INTO @DATA(ls_zfd)
*    FROM ztrt2001
*    WHERE docno = @iv_docno.
*  IF sy-subrc = 0.
*    ls_param-name = 'ACTION'.
*    ls_param-value = 'D'.
*    APPEND ls_param TO lt_param.
*
*    CASE ls_zfd-zzftype.
*      WHEN  'P002' OR 'P003' OR 'P005'.
*        lv_app = 'ZWDC_TR_2206'.
*      WHEN 'T004'."同户名划转
*        lv_app = 'ZWDC_TR_2009'.
*      WHEN 'T005'."结汇
*        lv_app = 'ZWDC_TR_2010'.
*      WHEN  'T006'."购汇
*        lv_app = 'ZWDC_TR_2012'.
*      WHEN OTHERS.
*    ENDCASE.
*
*    IF ls_zfd-zywtype = '33'."资金调拨取现
*      lv_app = 'ZWDC_TR_2009'.
*    ENDIF.
*  ELSE.
*    "保证金
*    SELECT SINGLE docno INTO @DATA(lv_docno) FROM ztrt2101
*      WHERE docno = @iv_docno.
*    IF sy-subrc = 0.
*      lv_app = 'ZWDC_TR_2007'.
*    ENDIF.
*  ENDIF.
*
*  IF lv_app IS INITIAL.
*    MESSAGE s210(ztr05) INTO ev_msg.
*    RETURN.
*  ENDIF.
*
*  ls_param-name = 'DOCNO'.
*  ls_param-value = iv_docno.
*  APPEND ls_param TO lt_param.
*  CLEAR ls_param.
*
*
*
**调用
*  CALL FUNCTION 'ZWDY_EXECUTE_IN_PLACE'
*    EXPORTING
*      protocol            = 'HTTPS'
*      internalmode        = 'X'
*      smartclient         = ''
*      application         = lv_app
*      parameters          = lt_param
*      suppress_output     = ''
*    EXCEPTIONS
*      invalid_application = 1
*      browser_not_started = 2
*      action_cancelled    = 3
*      OTHERS              = 4.
*  IF sy-subrc <> 0.
** Implement suitable error handling here
*  ENDIF.
*
*



ENDFUNCTION.
