*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZTRT9002
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZTRT9002            .

  PERFORM TABLEPROC.

ENDFUNCTION.
