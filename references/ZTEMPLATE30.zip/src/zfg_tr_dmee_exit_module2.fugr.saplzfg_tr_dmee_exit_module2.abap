*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_TR_DMEE_EXIT_MODULE2TOP.      " Global Declarations
  INCLUDE LZFG_TR_DMEE_EXIT_MODULE2UXX.      " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_TR_DMEE_EXIT_MODULE2F...      " Subroutines
* INCLUDE LZFG_TR_DMEE_EXIT_MODULE2O...      " PBO-Modules
* INCLUDE LZFG_TR_DMEE_EXIT_MODULE2I...      " PAI-Modules
* INCLUDE LZFG_TR_DMEE_EXIT_MODULE2E...      " Events
* INCLUDE LZFG_TR_DMEE_EXIT_MODULE2P...      " Local class implement.
* INCLUDE LZFG_TR_DMEE_EXIT_MODULE2T99.      " ABAP Unit tests
