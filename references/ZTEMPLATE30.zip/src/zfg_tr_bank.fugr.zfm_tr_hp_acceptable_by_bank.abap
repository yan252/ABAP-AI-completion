FUNCTION ZFM_TR_HP_ACCEPTABLE_BY_BANK.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     REFERENCE(IM_BANKS) TYPE  BNKA-BANKS
*"     REFERENCE(IM_BANKL) TYPE  BNKA-BANKL
*"  EXCEPTIONS
*"      BANK_CODE_NOT_FOUND
*"      BANK_INDICATOR_ERROR
*"      HP_NOT_ACCEPTABLE
*"--------------------------------------------------------------------
SELECT SINGLE bank_ind INTO @DATA(l_bank_ind)
         FROM bnka
          WHERE banks = @im_banks
          AND   bankl = @im_bankl.

  IF sy-subrc <> 0.
    MESSAGE e341(ztr_bank_application)
            WITH im_banks
                 im_bankl
            RAISING bank_code_not_found.
  ENDIF.

  IF l_bank_ind IS INITIAL.
    MESSAGE e342(ztr_bank_application)
            WITH im_banks
                 im_bankl
            RAISING bank_indicator_error.
  ENDIF.

  SELECT COUNT( * ) INTO @DATA(l_count)
          FROM ztrt_bank
          WHERE bank_ind = @l_bank_ind.
  IF l_count < 1.
    MESSAGE e343(ztr_bank_application)
            WITH im_banks
                 im_bankl
                 l_bank_ind
            RAISING bank_indicator_error.
  ENDIF.

  SELECT SINGLE hp_exclude INTO @DATA(l_hp_exclude)
         FROM ztrt_bank_exclu
         WHERE bank_ind = @l_bank_ind.
  IF l_hp_exclude = 'X'.
    MESSAGE e344(ztr_bank_application)
            WITH im_banks
                 im_bankl
            RAISING bank_indicator_error.
  ENDIF.





ENDFUNCTION.
