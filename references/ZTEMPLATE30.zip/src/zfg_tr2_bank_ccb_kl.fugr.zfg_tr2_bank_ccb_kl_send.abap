FUNCTION ZFG_TR2_BANK_CCB_KL_SEND.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  TABLES
*"      T_DOCNO STRUCTURE  ZSR2T_2006
*"--------------------------------------------------------------------
DATA lt_docno TYPE TABLE OF zsr2t_2006 .
*&-------------------------------------------------------------------------*
*&                      类
*&-------------------------------------------------------------------------*

  SELECT *
    FROM ztr2t0200
    INTO CORRESPONDING FIELDS OF TABLE gt_klpj
    FOR ALL ENTRIES IN lt_docno
    WHERE  docno = lt_docno-docno.
  "bukrs IN s_bukrs
*      AND bankn_fk IN s_bankn
*      AND docno IN s_docno
*      AND draft IN s_draft
*      AND klpj_stat IN s_status
*      AND fkzl NE ''.

*
  SELECT *
    FROM ztr2t0150
    INTO CORRESPONDING FIELDS OF TABLE gt_bspj
    FOR ALL ENTRIES IN lt_docno
      WHERE  docno = lt_docno-docno.
*    WHERE "bukrs IN s_bukrs
*      AND bankn_fk IN s_bankn
*      AND docno IN s_docno
*      AND draft IN s_draft
*      AND bspj_stat IN s_status
*      AND sqtype = '20'.



*将数据放入GT_OUTPUT
  LOOP AT gt_klpj ASSIGNING FIELD-SYMBOL(<fs_klpj>).
    APPEND INITIAL LINE TO gt_output ASSIGNING FIELD-SYMBOL(<fs_output>).
    MOVE-CORRESPONDING <fs_klpj> TO <fs_output>.
    IF <fs_output>-kljs_stat NE 'B001'.
      <fs_output>-klcl_stat = <fs_output>-kljs_stat.
      <fs_output>-klcl_msg  = <fs_output>-kljs_msg.
    ENDIF.
    <fs_output>-klcl_statt = zcl_wd_common=>get_dom_value( im_domnam = 'ZTR2_BSJS_STAT' im_domval = <fs_output>-klcl_stat ).
    <fs_output>-klpj_statt = zcl_wd_common=>get_dom_value( im_domnam = 'ZTR2_KLPJ_STAT' im_domval = <fs_output>-klpj_stat ).
    <fs_output>-cdqr_statt = zcl_wd_common=>get_dom_value( im_domnam = 'ZTR2_KLPJ_STAT' im_domval = <fs_output>-cdqr_stat ).
    <fs_output>-cdqrjy_statt = zcl_wd_common=>get_dom_value( im_domnam = 'ZTR2_BSJS_STAT' im_domval = <fs_output>-cdqrjy_stat ).
    <fs_output>-lock = 'ZTR2T0200'.
  ENDLOOP.

  LOOP AT gt_bspj ASSIGNING FIELD-SYMBOL(<fs_bspj>).
    APPEND INITIAL LINE TO gt_output ASSIGNING <fs_output>.
    <fs_output> = CORRESPONDING #(  BASE ( <fs_output> ) <fs_bspj>  MAPPING date_kl   = date_bs
                                                                            klcl_stat = bscl_stat
                                                                            klcl_msg  = bscl_msg
                                                                            klsb_resa = bssb_reas
                                                                            klpj_stat = bspj_stat
                                                                            kljs_stat = bscl_stat
                                                                            kljs_msg = bsjs_msg
                                                                            kljy_seq = bsjy_seq ).
    IF <fs_output>-kljs_stat NE 'B001'.
      <fs_output>-klcl_stat = <fs_output>-kljs_stat.
      <fs_output>-klcl_msg  = <fs_output>-kljs_msg.
    ENDIF.

    <fs_output>-klcl_statt = zcl_wd_common=>get_dom_value( im_domnam = 'ZTR2_BSCL_STAT' im_domval = <fs_output>-klcl_stat ).
    <fs_output>-klpj_statt = zcl_wd_common=>get_dom_value( im_domnam = 'ZTR2_PJCL_STAT' im_domval = <fs_output>-klpj_stat ).
    <fs_output>-lock = 'ZTR2T0150'.
    CLEAR: <fs_output>-cdqrjy_stat,<fs_output>-cdqr_msg,<fs_output>-cdqr_rslt,<fs_output>-cdqr_stat,<fs_output>-cdqr_statt,<fs_output>-cdqrjy_statt.
  ENDLOOP.

  IF gt_output IS NOT INITIAL.
    SELECT zfmark
           zskno
           zsknam
           zbskl
           docno
           zzffs
      FROM ztrt2001
      INTO CORRESPONDING FIELDS OF TABLE gt_zfd
      FOR ALL ENTRIES IN gt_output
      WHERE docno = gt_output-docno.

    SELECT zskbanka
           docno
      FROM ztrt2002
      INTO CORRESPONDING FIELDS OF TABLE gt_zfdsk
      FOR ALL ENTRIES IN gt_output
      WHERE docno = gt_output-docno.

*    SELECT DOCNO
*           ZITEMNO
*           ZBSKL_FLG
*      FROM
*      INTO CORRESPONDING FIELDS OF TABLE GT_KLBS
*      FOR ALL ENTRIES IN GT_OUTPUT
*      WHERE DOCNO = GT_OUTPUT-DOCNO
*        AND ZITEMNO = GT_OUTPUT-ZXH.

    SELECT bukrs
           butxt
    FROM t001
    INTO CORRESPONDING FIELDS OF TABLE gt_t001
    FOR ALL ENTRIES IN gt_output
    WHERE bukrs = gt_output-bukrs.

    SELECT *
      FROM ztrt2003
      INTO CORRESPONDING FIELDS OF TABLE gt_ztrt2003
      FOR ALL ENTRIES IN gt_output
      WHERE docno = gt_output-docno.

    SELECT *
    FROM ztrt2008
    INTO CORRESPONDING FIELDS OF TABLE gt_ztrt2008
    FOR ALL ENTRIES IN gt_output
    WHERE docno = gt_output-docno.
  ENDIF.

  LOOP AT gt_output ASSIGNING <fs_output>.
*    IF LINE_EXISTS( GT_KLBS[ DOCNO = <FS_OUTPUT>-DOCNO ZITEMNO = <FS_OUTPUT>-ZXH ] ).
*      DATA(LS_KLBS) = GT_KLBS[ DOCNO = <FS_OUTPUT>-DOCNO ZITEMNO = <FS_OUTPUT>-ZXH ].
*      <FS_OUTPUT>-ZBSKL_FLG = LS_KLBS-ZBSKL_FLG.
*      <FS_OUTPUT>-ZBSKLT = ZCL_WD_COMMON=>GET_DOM_VALUE( IM_DOMNAM = 'ZTRDM_BSKL_FLG' IM_DOMVAL = <FS_OUTPUT>-ZBSKL_FLG ).
*    ENDIF.

    IF line_exists( gt_zfd[ docno = <fs_output>-docno ] ).
      DATA(ls_zfd) = gt_zfd[ docno = <fs_output>-docno ].
      <fs_output>-zfmark = ls_zfd-zfmark.
      <fs_output>-zskno = ls_zfd-zskno.
      <fs_output>-zsknam = ls_zfd-zsknam.
      <fs_output>-zzffs = ls_zfd-zzffs.
      <fs_output>-zbskl_flg = ls_zfd-zbskl.
      <fs_output>-zbsklt = zcl_wd_common=>get_dom_value( im_domnam = 'ZTRDM_BSKL_FLG' im_domval = <fs_output>-zbskl_flg )."??????????
    ENDIF.

    IF line_exists( gt_zfdsk[ docno = <fs_output>-docno ] ).
      DATA(ls_zfdsk) = gt_zfdsk[ docno = <fs_output>-docno ].
      <fs_output>-zskbanka = ls_zfdsk-zskbanka.
    ENDIF.

    IF line_exists( gt_t001[ bukrs = <fs_output>-bukrs ] ).
      DATA(ls_t001) = gt_t001[ bukrs = <fs_output>-bukrs ].
      <fs_output>-butxt_gs = ls_t001-butxt.
    ENDIF.

  ENDLOOP.

  IF gt_output IS NOT INITIAL.

    SELECT *
      FROM ztr2t0210
      INTO CORRESPONDING FIELDS OF TABLE gt_ztr2t0210
      FOR ALL ENTRIES IN gt_output
      WHERE bank_ind = gt_output-bank_ind_fk
        AND action IN ( '02', '10' ). "02开立 10背书支付

  ENDIF.

  PERFORM check_send.
  CHECK lv_err IS INITIAL.

  LOOP AT gt_output INTO gs_output WHERE ckbox IS NOT INITIAL.
*        IF GS_OUTPUT-KLPJ_STAT = '1'.
*          MESSAGE S054(ZTR201) DISPLAY LIKE 'E'.
*          RETURN.
*        ENDIF.

    "如果KLJY_SEQ网银交易流水号为空 OR KLJY_SEQ网银交易流水号不为空ANDKLCL_STAT处理状态≠（B001，B054，空)
*        IF gs_output-kljy_seq IS INITIAL OR ( gs_output-kljy_seq IS NOT INITIAL AND gs_output-klcl_stat NE 'B001'
*                                              AND gs_output-klcl_stat NE 'B054' AND gs_output-klcl_stat IS NOT INITIAL ).
*   1. 如果【内表-KLJS_STAT所对应的ZTR2T0210-RTNTYPE≠S】OR【内表-KLJS_STAT所对应的ZTR2T0210-RTNTYPE=S且内表-KLCL_STAT所对应的ZTR2T0210-RTNTYPE=X】
    READ TABLE gt_ztr2t0210 INTO gs_ztr2t0210 WITH KEY action = '10'  bank_ind = 'BOC' bank_rtncode = gs_output-kljs_stat BINARY SEARCH.
    READ TABLE gt_ztr2t0210 INTO DATA(gs_ztr2t02101) WITH KEY action = '10'  bank_ind = 'BOC' bank_rtncode = gs_output-klcl_stat BINARY SEARCH.
    IF gs_ztr2t0210-rtntype NE 'S' OR ( gs_ztr2t0210-rtntype = 'S' AND gs_ztr2t02101-rtntype = 'X').

    ELSE.
      MESSAGE s054(ztr201) DISPLAY LIKE 'E'.
      RETURN.
    ENDIF.

  ENDLOOP.


  "数据锁定
  LOOP AT gt_output INTO gs_output WHERE ckbox IS NOT INITIAL.
    IF gs_output-lock = 'ZTR2T0200'.
      CALL FUNCTION 'ENQUEUE_EZRTRT05550'
        EXPORTING
          mode_ztr2t0200 = 'E'
          mandt          = sy-mandt
          docno          = gs_output-docno
          zxh            = gs_output-zxh
        EXCEPTIONS
          foreign_lock   = 1
          system_failure = 2
          OTHERS         = 3.
      IF sy-subrc <> 0.
* IMPLEMENT SUITABLE ERROR HANDLING HERE
      ENDIF.
    ELSEIF gs_output-lock = 'ZTR2T0150'.

      CALL FUNCTION 'ENQUEUE_EZRTRT05460'
        EXPORTING
          mode_ztr2t0150 = 'E'
          mandt          = sy-mandt
          docno          = gs_output-docno
          zxh            = gs_output-zxh
        EXCEPTIONS
          foreign_lock   = 1
          system_failure = 2
          OTHERS         = 3.
      IF sy-subrc <> 0.
* IMPLEMENT SUITABLE ERROR HANDLING HERE
      ENDIF.
    ENDIF.
  ENDLOOP.


  PERFORM frm_send.


  "数据解锁
  LOOP AT gt_output INTO gs_output WHERE ckbox IS NOT INITIAL.
    IF gs_output-lock = 'ZTR2T0200'.

      CALL FUNCTION 'DEQUEUE_EZRTRT05550'
        EXPORTING
          mode_ztr2t0200 = 'E'
          mandt          = sy-mandt
          docno          = gs_output-docno
          zxh            = gs_output-zxh.

    ELSEIF gs_output-lock = 'ZTR2T0150'.

      CALL FUNCTION 'DEQUEUE_EZRTRT05460'
        EXPORTING
          mode_ztr2t0150 = 'E'
          mandt          = sy-mandt
          docno          = gs_output-docno
          zxh            = gs_output-zxh.
    ENDIF.
  ENDLOOP.
* gt_output





ENDFUNCTION.
