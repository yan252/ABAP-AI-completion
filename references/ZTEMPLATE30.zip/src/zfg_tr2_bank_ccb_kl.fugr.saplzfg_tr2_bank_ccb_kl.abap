*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_TR2_BANK_CCB_KLTOP.           " Global Declarations
  INCLUDE LZFG_TR2_BANK_CCB_KLUXX.           " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_TR2_BANK_CCB_KLF...           " Subroutines
* INCLUDE LZFG_TR2_BANK_CCB_KLO...           " PBO-Modules
* INCLUDE LZFG_TR2_BANK_CCB_KLI...           " PAI-Modules
* INCLUDE LZFG_TR2_BANK_CCB_KLE...           " Events
* INCLUDE LZFG_TR2_BANK_CCB_KLP...           " Local class implement.
* INCLUDE LZFG_TR2_BANK_CCB_KLT99.           " ABAP Unit tests

INCLUDE lzfg_tr2_bank_ccb_klf01.
