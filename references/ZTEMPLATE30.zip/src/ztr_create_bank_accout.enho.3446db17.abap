"Name: \FU:FCLM_BAM_REVISION_ACTIVATE\SE:END\EI
ENHANCEMENT 0 ZTR_CREATE_BANK_ACCOUT.
*FIORI 中创建银行账号激活时把账号信息保存到自定义表中
  BREAK yangsen.
CALL FUNCTION 'ZFM_SAVE_ZTRT0013_FIORI'
  EXPORTING
    IT_DB_AMD                 = lt_amd
    IT_DB_AMD_T               = lt_t
    IT_DB_AMD_CUR             = lt_cur
    IT_DB_AMD_SIG             = lt_sig
    IT_DB_AMD_LIM             = lt_lim
    IT_DB_ACLINK              = lt_aclink
    IT_DB_ACLINK2             = lt_aclink2
* IMPORTING
*   ET_MESSAGE                =
          .


ENDENHANCEMENT.
