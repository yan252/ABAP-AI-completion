FUNCTION ZFM_TR_BOCOM_GET_TIME_FLAG.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     VALUE(I_TREE_TYPE) TYPE  DMEE_TREETYPE_ABA
*"     VALUE(I_TREE_ID) TYPE  DMEE_TREEID_ABA
*"     VALUE(I_ITEM)
*"     VALUE(I_PARAM)
*"     VALUE(I_UPARAM)
*"  EXPORTING
*"     REFERENCE(O_VALUE)
*"     REFERENCE(C_VALUE)
*"     REFERENCE(N_VALUE)
*"     REFERENCE(P_VALUE)
*"  TABLES
*"      I_TAB
*"--------------------------------------------------------------------
DATA: LV_CUSTID   TYPE ZTRT_BANK_ASS-CUSTID,
        LV_BANK_IND TYPE ZTRT_BANK_ASS-BANK_IND,
        L_DATUM TYPE DATUM,
        l_yesda TYPE datum.

*0-当日及昨日交易明细查询
*1-昨日以前历史明细查询


  FIELD-SYMBOLS <ZTST> TYPE ZTRS_DMEE_ACCOUNT_LIST.

  ASSIGN COMPONENT 'ZTRS_DMEE_ACCOUNT_LIST' OF STRUCTURE I_ITEM TO <ZTST>.
  L_DATUM =  <ZTST>-START_DATE.

  l_yesda = sy-datum - 1.
IF L_DATUM < l_yesda."昨天以前
  C_VALUE = '1'.
ELSE.
  C_VALUE = '0'.
ENDIF.





ENDFUNCTION.
