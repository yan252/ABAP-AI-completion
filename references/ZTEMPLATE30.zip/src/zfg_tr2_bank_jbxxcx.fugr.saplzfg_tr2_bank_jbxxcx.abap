*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_TR2_BANK_JBXXCXTOP.           " Global Declarations
  INCLUDE LZFG_TR2_BANK_JBXXCXUXX.           " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_TR2_BANK_JBXXCXF...           " Subroutines
* INCLUDE LZFG_TR2_BANK_JBXXCXO...           " PBO-Modules
* INCLUDE LZFG_TR2_BANK_JBXXCXI...           " PAI-Modules
* INCLUDE LZFG_TR2_BANK_JBXXCXE...           " Events
* INCLUDE LZFG_TR2_BANK_JBXXCXP...           " Local class implement.
* INCLUDE LZFG_TR2_BANK_JBXXCXT99.           " ABAP Unit tests
