class ZCL_HTTP_BANK_ICBC definition
  public
  inheriting from ZCL_HTTP_BANK
  final
  create public .

public section.
protected section.

  methods CREATE_CLIENT_LINKAGE_ADDRESS
    redefinition .
private section.
ENDCLASS.



CLASS ZCL_HTTP_BANK_ICBC IMPLEMENTATION.


METHOD create_client_linkage_address.
    DATA: lo_function TYPE REF TO zif_icbc_function.
    DATA: l_exception TYPE string.
    DATA: BEGIN OF ls_destination,
            destination TYPE rfcdest,
            servicenr   TYPE rfcdisplay-rfcsysid,
            server      TYPE rfcdisplay-rfchost,
            path_prefix TYPE string,
          END OF ls_destination.
    DATA l_bank_date TYPE sydatum.

    ls_destination-destination = enviroment->get_single_step( current_processing_step )-destination.

    SELECT SINGLE dynaimc_link INTO @DATA(l_link)
           FROM ztrt_httprfcdest
           WHERE destination = @ls_destination-destination.

    IF l_link = no.
      RETURN.
    ENDIF.

    DATA(ls_function) = enviroment->get_function_by_step( current_processing_step ).



    CALL FUNCTION 'RFC_READ_HTTP_DESTINATION'
      EXPORTING
        destination             = ls_destination-destination
        authority_check         = space
      IMPORTING
        servicenr               = ls_destination-servicenr
        server                  = ls_destination-server
        path_prefix             = ls_destination-path_prefix
      EXCEPTIONS
        authority_not_available = 1
        destination_not_exist   = 2
        information_failure     = 3
        internal_failure        = 4
        no_http_destination     = 5
        OTHERS                  = 6.
    CASE sy-subrc.
      WHEN 1.
        l_exception = 'authority_not_available'.
      WHEN 2.
        l_exception = 'destination_not_exist'.
      WHEN 3.
        l_exception = 'information_failure'.
      WHEN 4.
        l_exception = 'internal_failure'.
      WHEN 5.
        l_exception = 'no_http_destination'.
      WHEN 6.
        l_exception = 'OTHERS'.
    ENDCASE.

    IF l_exception IS NOT INITIAL.
      MESSAGE e310(ztr_bank_application)
              WITH ls_destination-destination
                   l_exception
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = instance_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = current_action
                        bank_ind     = bank_indicator
                        bank_func    = ls_function-bank_func
                        step         = current_processing_step ) ).
      RETURN.
    ENDIF.

    lo_function ?= get_bank_function( current_processing_step ).
    DATA(l_id) = CONV string( zcl_icbc_enhancement=>set_id( ) ).
    DATA(l_package_id) = lo_function->get_current_package_id( ).
*    IF sy-mandt = '130' OR
*        sy-mandt = '150'.
*      l_bank_date = zcl_icbc_enhancement=>set_bank_date( ).
*    ELSE.
*      l_bank_date = sy-datum.
*    ENDIF.
*    DATA(l_sendtime) = l_bank_date &&
*                       sy-uzeit.
    DATA(l_sendtime) = sy-datum &&
                       sy-uzeit.

    re_url = 'http://' &&
             ls_destination-server &&
             ':' &&
             ls_destination-servicenr &&
             ls_destination-path_prefix.


*SM59中设置远程连接的路径前缀为：
*/servlet/ICBCCMPAPIReqServlet?userID=/zuserID/&PackageID=/zPackageID/&SendTime=/zSendTime/

*将前缀中的/zuserID/、/zPackageID/、/zSendTime/按照实际情况替换掉
    CONDENSE: l_sendtime,
              l_package_id,
              l_id.
    REPLACE '/zSendTime/' WITH l_sendtime INTO re_url.
    REPLACE '/zPackageID/' WITH l_package_id INTO re_url.
    REPLACE '/zuserID/' WITH l_id INTO re_url.

  ENDMETHOD.
ENDCLASS.
