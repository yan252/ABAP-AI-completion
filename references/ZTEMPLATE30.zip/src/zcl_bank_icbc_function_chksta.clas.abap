class ZCL_BANK_ICBC_FUNCTION_CHKSTA definition
  public
  inheriting from ZCL_BANK_FUNCTION_CHECKPAYM
  final
  create public .

public section.

  interfaces ZIF_ICBC_FUNCTION .

  aliases GET_CURRENT_PACKAGE_ID
    for ZIF_ICBC_FUNCTION~GET_CURRENT_PACKAGE_ID .
protected section.

  methods PROCESSING_RESPONSE_INTL_CORE
    redefinition .
private section.
ENDCLASS.



CLASS ZCL_BANK_ICBC_FUNCTION_CHKSTA IMPLEMENTATION.


  METHOD processing_response_intl_core.
    FIELD-SYMBOLS: <ft_sending_entries> TYPE ztrs_payment_check_status_tab.
    FIELD-SYMBOLS: <fs_response>        TYPE ztrs_icbc_qpayent_response.
    DATA: ls_bank_payment_return TYPE ztrs_payment_bank_return.
    DATA: l_same_bank TYPE flag.


    super->processing_response_intl_core( ).

    ASSIGN sending_data_reference->* TO <ft_sending_entries>.
    READ TABLE <ft_sending_entries> INTO DATA(ls_sending_entry)
         WITH KEY seqnumber = current_sending_sequence.
    IF sy-subrc <> 0.
*      unexpected error
      MESSAGE x091(ztr_bank_application)
              WITH function_config-bank_func
                   current_sending_sequence.
    ENDIF.

    DATA(ls_response_data) = get_current_response_data( ).
    ASSIGN ls_response_data-response_ref->* TO <fs_response>.

    MOVE: <fs_response>-pub-retcode TO ls_bank_payment_return-header-bank_rtncode,
          <fs_response>-pub-retmsg TO ls_bank_payment_return-header-bank_rtnmsg.

    READ TABLE <fs_response>-out-rd
              INTO DATA(ls_rd)
              INDEX 1.
*        工商银行设置为单笔交易
    IF sy-subrc = 0.
*      SELECT SINGLE zskbankl INTO @DATA(l_rec_bankl)
*             FROM ztrt2002
*             WHERE docno = @ls_sending_entry-doc1r.
*      SELECT SINGLE zfkbankl INTO @DATA(l_pay_bankl)
*             FROM ztrt2003
*             WHERE docno = @ls_sending_entry-doc1r.
*      IF zcl_bank_cnaps_code=>if_same_bank(
*                                   im_code1 = l_rec_bankl
*                                   im_code2 = l_pay_bankl ) = no.
**        跨行
*        IF ls_rd-result = zif_icbc_constant=>checkstatus_processing_code AND
*           ls_rd-instrretcode IS INITIAL.
**          跨行报文已发送，认为成功
*          ls_rd-instrretcode = zif_icbc_constant=>cross_success.
*        ENDIF.
*      ENDIF.
      APPEND VALUE #( paymorder = ls_sending_entry-paymorder
                      doc1r = ls_sending_entry-doc1r
                      bank_rtncode = ls_rd-result
                      bank_reqsts = ls_rd-instrretcode
                      bank_tran_number = <fs_response>-pub-serialno
                      bank_rtnmsg = ls_rd-instrretmsg )
                   TO ls_bank_payment_return-items.
    ELSE.
      IF <fs_response>-out-qryfseqno IS NOT INITIAL.
*        查到了当时发出的支付指令包，但没有返回明细项目(<fs_response>-out-rd)
*        交易失败
        <fs_response>-pub-retcode = zif_icbc_constant=>transaction_failed_302.
      ELSE.
*          没有查询到支付发出的指令包，有两个可能：
*          1）当时支付的时候的确是银行没有收到该支付交易（支付报文错误，或SAP银企直连错误导致报文没发出去等等）
*          2）查询报文本身报错了（D0089错误）
*          如果是第一个情况，设置支付交易为失败,如果返回D0089错误，根据配置表该错误代码的处理
        IF <fs_response>-pub-retcode <> zif_icbc_constant=>xml_error.
          <fs_response>-pub-retcode = zif_icbc_constant=>transaction_failed_302.
        ENDIF.
      ENDIF.

      APPEND VALUE #( paymorder = ls_sending_entry-paymorder
                      doc1r = ls_sending_entry-doc1r
                      bank_rtncode = <fs_response>-pub-retcode
                      bank_rtnmsg = <fs_response>-pub-retmsg )
                   TO ls_bank_payment_return-items.

    ENDIF.


    update_status_in_instance( ls_bank_payment_return ).


  ENDMETHOD.


  METHOD zif_icbc_function~get_current_package_id.
    INCLUDE ztri_bank_icbc_func_packageid.
  ENDMETHOD.
ENDCLASS.
