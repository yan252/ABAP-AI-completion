FUNCTION ZFM_TR_UPDATE_BZJTZ.
**"--------------------------------------------------------------------
**"*"局部接口：
**"  IMPORTING
**"     VALUE(DOCNO) TYPE  ZTR_ZFDOCNO OPTIONAL
**"     REFERENCE(ACTION) TYPE  CHAR1 DEFAULT 'U'
**"     VALUE(BZJ_TZ) TYPE  ZTR_BZJ_TZ OPTIONAL
**"  TABLES
**"      ITEM STRUCTURE  ZTR_BZJTZ_ITEM OPTIONAL
**"--------------------------------------------------------------------
***现有台帐
*  DATA: lt_tz      TYPE STANDARD TABLE OF ztrt2199,
*        lt_tzd     TYPE STANDARD TABLE OF ztrt2199,
*        lv_up      TYPE i,
*        ls_up      TYPE ztrt2199,
*        lv_index   TYPE i,
*        lv_pct     TYPE prctr,
*        lv_zzftype TYPE ztr_zbayype,
*        ls_tz      TYPE ztrt2199.
*  IF docno IS INITIAL AND bzj_tz IS INITIAL.
*    RETURN.
*  ENDIF.
*  IF bzj_tz IS INITIAL.
*    SELECT SINGLE bzj_tz INTO @DATA(lv_tz)
*      FROM ztrt2199
*      WHERE docno = @docno AND tztype IN ('B','P')
*       AND fitype = '1'.
*    IF sy-subrc = 0.
*      SELECT * INTO TABLE lt_tz
*        FROM ztrt2199
*        WHERE bzj_tz = lv_tz.
*    ENDIF.
*  ELSE.
*    SELECT * INTO TABLE lt_tz
*      FROM ztrt2199
*      WHERE bzj_tz = bzj_tz.
*    lv_tz = bzj_tz.
*  ENDIF.
*
*  LOOP AT item.
*    IF action = 'U'."更新
*      MOVE-CORRESPONDING item TO ls_tz.
*      ls_tz-bzj_tz = lv_tz.
*      ls_tz-zbzwrbtr = item-wrbtr."发生额
*      ls_tz-erdat = sy-datum.
*      ls_tz-erzet = sy-uzeit.
*      ls_tz-ernam = sy-uname.
*      ls_tz-aedat = sy-datum.
*      ls_tz-aezet = sy-uzeit.
*      ls_tz-aenam = sy-uname.
*      LOOP AT lt_tz INTO DATA(gs_cre) WHERE fitype = ls_tz-fitype
*                                         AND    docno = ls_tz-docno
*                                         AND    tztype = ls_tz-tztype
*                                         AND    bukrs = ls_tz-bukrs  .
*        IF gs_cre-aenam IS INITIAL.
*          ls_tz-aedat = gs_cre-erdat.
*          ls_tz-aezet = gs_cre-erzet.
*          ls_tz-aenam = gs_cre-ernam.
*        ELSE.
*          ls_tz-aedat = gs_cre-aedat.
*          ls_tz-aezet = gs_cre-aezet.
*          ls_tz-aenam = gs_cre-aenam.
*        ENDIF.
*        EXIT.
*      ENDLOOP.
*
*      APPEND ls_tz TO lt_tz.
*      CLEAR ls_tz.
*    ELSE."取消台帐
*      READ TABLE lt_tz INTO ls_tz WITH KEY bukrs = item-bukrs
*                                           docno = item-docno
*                                           tztype = item-tztype.
*      IF sy-subrc = 0.
*        lv_index = sy-tabix.
*        APPEND ls_tz TO lt_tzd.
*        DELETE lt_tz INDEX lv_index.
*      ENDIF.
*    ENDIF.
*  ENDLOOP.
*
*  SORT lt_tz BY zjydate erdat erzet.
*  LOOP AT lt_tz ASSIGNING FIELD-SYMBOL(<fs_tz>).
*    lv_up = sy-tabix - 1.
*    IF lv_up = 0.
**      <fs_tz>-zbzwrbtrb =   <fs_tz>-zbzwrbtr.
**      <fs_tz>-zlxwrbtrz =   <fs_tz>-zlxwrbtr.
**      <fs_tz>-zbzwrbtrz = <fs_tz>-zbzwrbtrb + <fs_tz>-zlxwrbtrz.
*      CONTINUE.
*    ENDIF.
**    "上一条
*    READ TABLE lt_tz INTO ls_up INDEX lv_up.
**本金发生-本金余额
*    <fs_tz>-zbzwrbtrb = ls_up-zbzwrbtrb + <fs_tz>-zbzwrbtr.
*
***利息余额
*    <fs_tz>-zlxwrbtrz = ls_up-zlxwrbtrz + <fs_tz>-zlxwrbtr.
*
***总余额
*    <fs_tz>-zbzwrbtrz = <fs_tz>-zbzwrbtrb + <fs_tz>-zlxwrbtrz.
*  ENDLOOP.
*  IF lt_tzd IS NOT INITIAL.
*    DELETE ztrt2199 FROM TABLE lt_tzd.
*  ENDIF.
*  MODIFY ztrt2199 FROM TABLE lt_tz.
*  COMMIT WORK.





ENDFUNCTION.
