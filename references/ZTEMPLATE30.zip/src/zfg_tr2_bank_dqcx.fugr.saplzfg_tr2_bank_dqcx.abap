*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_TR2_BANK_DQCXTOP.             " Global Declarations
  INCLUDE LZFG_TR2_BANK_DQCXUXX.             " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_TR2_BANK_DQCXF...             " Subroutines
* INCLUDE LZFG_TR2_BANK_DQCXO...             " PBO-Modules
* INCLUDE LZFG_TR2_BANK_DQCXI...             " PAI-Modules
* INCLUDE LZFG_TR2_BANK_DQCXE...             " Events
* INCLUDE LZFG_TR2_BANK_DQCXP...             " Local class implement.
* INCLUDE LZFG_TR2_BANK_DQCXT99.             " ABAP Unit tests
