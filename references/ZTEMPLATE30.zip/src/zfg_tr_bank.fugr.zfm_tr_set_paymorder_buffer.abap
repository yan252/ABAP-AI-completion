FUNCTION ZFM_TR_SET_PAYMORDER_BUFFER.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     REFERENCE(IM_T_PAYMORDER_BUFFER) TYPE
*"                             ZTRS_PAYMORDER_BUFFER_TAB
*"--------------------------------------------------------------------
PERFORM set_payment_order_buffer USING im_t_paymorder_buffer.





ENDFUNCTION.
