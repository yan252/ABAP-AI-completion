FUNCTION ZFM_TR_SET_BANK_IND_TO_BNKA.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     VALUE(IM_BANKS) TYPE  BANKS
*"     VALUE(IM_BANKL) TYPE  BANKL
*"     VALUE(IM_BANKA) TYPE  CHAR255
*"     VALUE(IM_SWIFT) TYPE  BNKA-SWIFT OPTIONAL
*"     VALUE(IM_PERSISTENCE) TYPE  CHAR01
*"     VALUE(IM_SHOW_PROGRESS) TYPE  CHAR01 DEFAULT 'X'
*"  EXPORTING
*"     VALUE(EX_BANK_IND) TYPE  ZTR_BANK_INDICATOR
*"     VALUE(EX_LTEXT) TYPE  ZTRT_BANKT-LTEXT
*"     VALUE(EX_OKAY) TYPE  FLAG
*"--------------------------------------------------------------------
*  IF im_banks <> 'CN'.
**    暂时只有中国境内的银行才能识别
*    ex_okay = 'X'.
*    RETURN.
*  ENDIF.

  CASE im_persistence.
    WHEN '1'.
      PERFORM external_not_persistence
              IN PROGRAM ztr_bankcode_and_bank_ind
              IF FOUND
              USING im_banks
                    im_bankl
                    im_banka
                    IM_SWIFT
                    IM_SHOW_PROGRESS
           CHANGING ex_bank_ind
                    ex_ltext.
    WHEN '2'.
      PERFORM external_persistence
              IN PROGRAM ztr_bankcode_and_bank_ind
              IF FOUND
              USING im_banks
                    im_bankl
                    IM_SWIFT
                    IM_SHOW_PROGRESS
           CHANGING ex_bank_ind
                    ex_ltext.
  ENDCASE.

  IF ex_bank_ind IS NOT INITIAL.
    ex_okay = 'X'.
  ENDIF.





ENDFUNCTION.
