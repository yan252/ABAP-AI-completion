class ZCL_HTTP_BANK definition
  public
  inheriting from ZCL_ABSTRACT_BANK
  create public .

public section.
protected section.

  data DESTINATION type ref to ZIF_BANK_HTTP_CLIENT .

  methods CREATE_CLIENT
    redefinition .
  methods DESTROY_CLIENT
    redefinition .
  methods INIT_CLIENT
    redefinition .
  methods RECEIVE_CORE
    redefinition .
  methods SEND_CORE
    redefinition .
private section.

  data DESTINATION_CLIENT type SEOCLSNAME value 'ZCL_BANK_HTTP_CLIENT' ##NO_TEXT.
ENDCLASS.



CLASS ZCL_HTTP_BANK IMPLEMENTATION.


METHOD create_client.
    DATA l_exception TYPE string.
    DATA: l_destination TYPE rfcdest.

*    start log
    MESSAGE i153(ztr_bank_application)
            WITH bank_indicator
                 im_destination
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = instance_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = current_action
                      bank_ind     = bank_indicator ) ).
*    end log
    SELECT SINGLE * INTO @DATA(ls_http_destination)
           FROM ztrt_httprfcdest
           WHERE destination = @im_destination.
    IF ls_http_destination-instance_class IS NOT INITIAL.
      l_destination = ls_http_destination-instance_class.
    ELSE.
      l_destination = destination_client.
    ENDIF.

    CREATE OBJECT destination TYPE (l_destination)
      EXPORTING
        im_destination           = im_destination
        im_bank_indicator        = bank_indicator
        im_create_by_url         = im_create_by_url
        im_url                   = im_linkage_address
      EXCEPTIONS
        argument_not_found       = 1
        destination_not_found    = 2
        destination_no_authority = 3
        plugin_not_active        = 4
        internal_error           = 5
        unknow_error             = 6.
    CASE sy-subrc.
      WHEN 0.
        CLEAR l_exception.
      WHEN 1.
        ##NO_TEXT
        l_exception = 'argument_not_found'.
      WHEN 2.
        ##NO_TEXT
        l_exception = 'destination_not_found'.
      WHEN 3.
        ##NO_TEXT
        l_exception = 'destination_no_authority'.
      WHEN 4.
        ##NO_TEXT
        l_exception = 'plugin_not_active'.
      WHEN 5.
        ##NO_TEXT
        l_exception = 'internal_error'.
      WHEN 6.
        ##NO_TEXT
        l_exception = 'unknow_error'.
    ENDCASE.

    IF l_exception IS NOT INITIAL.
*    start log
      MESSAGE e048(ztr_bank_application)
              WITH bank_indicator
                   im_destination
                   l_exception
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = instance_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = current_action
                        bank_ind     = bank_indicator ) ).
      set_error_step( rfc_init_error ).
*    end log

    ELSE.
      destination->init_for_posting( ).

*    start log
      MESSAGE i154(ztr_bank_application)
              WITH bank_indicator
                   im_destination
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = instance_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = current_action
                        bank_ind     = bank_indicator ) ).
*    end log
    ENDIF.
  ENDMETHOD.


METHOD destroy_client.
    IF destination IS BOUND.

*    start log
      MESSAGE i152(ztr_bank_application)
              WITH bank_indicator
                   destination->get_destination( )
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = INSTANCE_UUID
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = current_action
                        bank_ind     = bank_indicator ) ).
*end log

      destination->close( ).
      FREE destination.
    ENDIF.
  ENDMETHOD.


METHOD init_client.
*    IF ch_old_destination <> im_current_destination.
*
*      ch_old_destination = im_current_destination.
*      destroy_client( ).
*      SELECT SINGLE dynaimc_link INTO @DATA(l_url_flag)
*             FROM ztrt_httprfcdest
*             WHERE destination = @im_current_destination.
*      IF l_url_flag = yes.
*        IF im_url IS SUPPLIED.
*          create_client(
*                    im_destination   = im_current_destination
*                    im_url           = im_url
*                    im_create_by_url = yes ).
*        ELSE.
**      按地址连接，但没有提供地址
**       只执行摧毁旧连接后再退出去，等外边准备地址后再执行创建连接
*          return.
*        ENDIF.
*      ELSE.
**创建HTTP client
*        create_client( im_destination = im_current_destination ).
*      ENDIF.
*
*    ELSE.
*      destination->init_for_posting( ).
**      call METHOD destination->('INIT_FOR_POSTING').
*    ENDIF.

    IF if_error( ) = yes.
      RETURN.
    ENDIF.

    super->init_client( im_current_destination = im_current_destination
                        im_linkage_address = im_linkage_address ).

    IF if_error( ) = yes.
      RETURN.
    ENDIF.

    IF destination IS BOUND.
      destination->init_for_posting( ).
    ENDIF.


  ENDMETHOD.


METHOD receive_core.
    DATA(ls_bank_function) = enviroment->get_function_by_step( current_processing_step ).
    DATA(lo_function) = get_bank_function( current_processing_step ).
    DATA(ls_sending_file) = lo_function->get_current_sending_file( ).

    destination->receive(
           EXPORTING
             im_step                    = current_processing_step
             im_action                  = current_action
           EXCEPTIONS
             http_communication_failure = 1
             http_invalid_state         = 2
             http_processing_failed     = 3
             unknow_error               = 4 ).
    IF sy-subrc <> 0.
      CREATE DATA ex_response_xdata TYPE xstring.
      CREATE DATA ex_response_cdata TYPE string.
      MESSAGE ID sy-msgid
              TYPE sy-msgty
              NUMBER sy-msgno
              WITH sy-msgv1
                   sy-msgv2
                   sy-msgv3
                   sy-msgv4
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = instance_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = current_action
                        bank_ind     = bank_indicator
                        bank_func    = ls_bank_function-bank_func
                        step         = current_processing_step
                        counter_file_uuid    = ls_sending_file-file_uuid
                        file_direction = 'R' ) ).
      set_error_step( response_error ).
      RETURN.
*      set_error_step( response_error ).
*      add_system_msg_and_return response_error.
    ELSE.
      MESSAGE i176(ztr_bank_application)
              WITH bank_indicator
                   zcl_bank_enviroment=>s_get_bank_action_text( current_action )
                   current_processing_step
                   ls_bank_function-bank_func
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = instance_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = current_action
                        bank_ind     = bank_indicator
                        bank_func    = ls_bank_function-bank_func
                        step         = current_processing_step
                        counter_file_uuid    = ls_sending_file-file_uuid
                        file_direction = 'R' ) ).

      DATA(l_response_xml_xstring) = destination->get_response_data( ).
      CREATE DATA ex_response_xdata TYPE xstring.
      ASSIGN ex_response_xdata->* TO FIELD-SYMBOL(<f_xstring>).
      <f_xstring> = l_response_xml_xstring.

      DATA(l_response_xml_cstring) = destination->get_response_cdata( ).
      CREATE DATA ex_response_cdata TYPE string.
      ASSIGN ex_response_cdata->* TO FIELD-SYMBOL(<f_string>).
      <f_string> = l_response_xml_cstring.

    ENDIF.
  ENDMETHOD.


METHOD send_core.
    DATA(l_function) = enviroment->get_function_name_by_step( current_processing_step ).

    IF im_xfile_ref IS BOUND.
      ASSIGN im_xfile_ref->* TO FIELD-SYMBOL(<f_xfile>).
      IF <f_xfile> IS INITIAL.
        UNASSIGN <f_xfile>.
      ENDIF.
    ENDIF.

    IF im_cfile_ref IS BOUND.
      ASSIGN im_cfile_ref->* TO FIELD-SYMBOL(<f_cfile>).
      IF <f_cfile> IS INITIAL.
        UNASSIGN <f_cfile>.
      ENDIF.
    ENDIF.

    IF ( <f_xfile> IS NOT ASSIGNED    OR
       <f_xfile> IS INITIAL  )        AND
       ( <f_cfile> IS NOT ASSIGNED    OR
         <f_cfile> IS INITIAL ).
*      not possible
*      the file should be checked at start_running method
      MESSAGE i170(ztr_bank_application)
              WITH bank_indicator
                   zcl_bank_enviroment=>s_get_bank_action_text( current_action )
                   current_processing_step
                   l_function
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = instance_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = current_action
                        bank_ind     = bank_indicator
                        bank_func    = l_function
                        step         = current_processing_step
                        file_uuid    = im_file_uuid
                        file_direction = 'C' ) ).
*end log
      set_error_step( file_error ).
    ENDIF.


    init_client(
          EXPORTING
            im_current_destination = enviroment->get_single_step( current_processing_step )-destination
            im_linkage_address = create_client_linkage_address( ) ).
    IF if_error( ) = yes.
      EXIT.
    ENDIF.

    IF <f_xfile> IS NOT INITIAL.
      destination->set_request_data( <f_xfile> ).
    ELSE.
      destination->set_request_cdata( <f_cfile> ).
    ENDIF.

    destination->send(
                    EXPORTING
                      im_action                  = current_action
                      im_step                    = current_processing_step
                    EXCEPTIONS
                      http_communication_failure = 1
                      http_invalid_state         = 2
                      http_processing_failed     = 3
                      http_invalid_timeout       = 4
                      unknow_error               = 5 ).
    IF sy-subrc = 0.
      ex_send = yes.
    ELSE.
*      add_system_msg_and_return file_sending_error.
      MESSAGE ID sy-msgid
              TYPE sy-msgno
              NUMBER sy-msgno
              WITH sy-msgv1
                   sy-msgv2
                   sy-msgv3
                   sy-msgv4
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = instance_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = current_action
                        bank_ind     = bank_indicator
                        bank_func    = l_function
                        step         = current_processing_step
                        file_uuid    = im_file_uuid
                        file_direction = 'C' ) ).
      set_error_step( file_sending_error ).
    ENDIF.

  ENDMETHOD.
ENDCLASS.
