class ZCL_BANK_ACTION_M04 definition
  public
  inheriting from ZCL_BANK_ABSTRACT_ACTION
  final
  create public .

public section.
protected section.

  methods FEEDBACK_FROM_BANK_CORE
    redefinition .
  methods PREPARE_CORE
    redefinition .
  methods RUN_FOR_SPECIFIC_ACTION_CORE
    redefinition .
private section.

  data PAYMENT_ENTRIES type ZTRS_PAYMENTORDER_ENTRY_TAB .

  methods CREATE_PAYMENTRY_BY_ENTRY
    importing
      !IM_UUID type ZTR_PAYMENT_ENTRY_UUID
    returning
      value(RO_INSTANCE) type ref to ZCL_BANK_PAYMENT_ENTRY .
  methods UPDATE_PAYMENT_ENTRY
    importing
      !IM_BANK_INDICATOR type ZTR_BANK_INDICATOR
      !IM_FEEDBACK_FROM_BANK type ZTRT_PAYMENT_ENTRY_FROM_BANK
      !IM_S_BANK_ERROR_STEP type ZTRS_ERROR_STEP_EXT .
ENDCLASS.



CLASS ZCL_BANK_ACTION_M04 IMPLEMENTATION.


METHOD CREATE_PAYMENTRY_BY_ENTRY.
**    start log
*    MESSAGE i109(ztr_bank_application)
*            WITH action
*                 zcl_bank_enviroment=>s_get_bank_action_text( action )
*            INTO dummy_message.
*    zcl_bank_logger_protocal=>add_log(
*             VALUE #( msgid        = sy-msgid
*                      msgno        = sy-msgno
*                      msgty        = sy-msgty
*                      msgv1        = sy-msgv1
*                      msgv2        = sy-msgv2
*                      msgv3        = sy-msgv3
*                      msgv4        = sy-msgv4
*                      message      = dummy_message
*                      bank_action  = action ) ).
**    end log
    SELECT SINGLE entry_cls INTO @DATA(l_entry_class)
           FROM ztrt_act_entry
           WHERE action = @action.
    IF sy-subrc = 0.
      CREATE OBJECT ro_instance type (l_entry_class)
        EXPORTING
          im_creation_type    = zcl_bank_payment_entry=>create_from_payment_entry
          im_uuid             = im_uuid
        EXCEPTIONS
          creation_type_error = 1
          create_uuid_error   = 2
          uuid_error          = 3.
      IF sy-subrc <> 0.
*      unexpected technical error
*      the error should by solved by testing
        MESSAGE ID sy-msgid
                TYPE sy-msgty
                NUMBER sy-msgno
                WITH sy-msgv1
                     sy-msgv2
                     sy-msgv3
                     sy-msgv4.
      ENDIF.
    ELSE.
      MESSAGE e265
              WITH action.
    ENDIF.
  ENDMETHOD.


METHOD FEEDBACK_FROM_BANK_CORE.
    DATA: lt_response_entries TYPE ztrt_payment_entry_from_bank.

    LOOP AT banks_list INTO DATA(ls_bank_list)
          WHERE instance IS BOUND.
      ls_bank_list-instance->export_after_processed(
        IMPORTING
          et_entries = lt_response_entries
          ex_s_error_step = DATA(ls_error_step) ).

      update_payment_entry(
               EXPORTING
                  im_bank_indicator = ls_bank_list-bank_ind
                  im_feedback_from_bank = lt_response_entries
                  im_s_bank_error_step = ls_error_step ).
      CLEAR: lt_response_entries,
             ls_error_step.
    ENDLOOP.
  ENDMETHOD.


METHOD PREPARE_CORE.
    DATA: ls_payment_entry                 TYPE ztrs_paymentorder_entry.
    FIELD-SYMBOLS: <ft_payment_entry_list> TYPE ztrs_paymententry_list_tab.

    ASSIGN entries_reference->* TO <ft_payment_entry_list>.

    LOOP AT <ft_payment_entry_list> ASSIGNING FIELD-SYMBOL(<fs_entry>).
      ls_payment_entry-instance = create_paymentry_by_entry( <fs_entry>-entuuid ).
      ls_payment_entry-instance->set_entry( ).
      ls_payment_entry-entuuid  = <fs_entry>-entuuid.
      ls_payment_entry-doc1r    = ls_payment_entry-instance->get_reference_doc( ).
      ls_payment_entry-paymorder = ls_payment_entry-doc1r+0(10).
      ls_payment_entry-draft_zxh = ls_payment_entry-doc1r+10(4).
      ls_payment_entry-bank_ind = ls_payment_entry-instance->get_bank_indicator( ).
      APPEND ls_payment_entry TO payment_entries.
      CLEAR ls_payment_entry.
    ENDLOOP.
  ENDMETHOD.


method RUN_FOR_SPECIFIC_ACTION_CORE.
    LOOP AT payment_entries
          INTO DATA(ls_payment_entry)
          WHERE instance IS BOUND.
      IF ls_payment_entry-instance->if_error( ) = no.
        create_bank( ls_payment_entry-instance->get_bank_indicator( ) )->set_single_entry( ls_payment_entry-instance->export_entry( ) ).
      ELSE.
        ls_payment_entry-instance->destroy( ).
        FREE ls_payment_entry-instance.
        DELETE payment_entries WHERE entuuid = ls_payment_entry-entuuid.
**        "end with error on SAP applicaion level
      ENDIF.
    ENDLOOP.
  endmethod.


METHOD UPDATE_PAYMENT_ENTRY.
    LOOP AT payment_entries INTO DATA(ls_payment_entry)
          WHERE bank_ind = im_bank_indicator.
      READ TABLE im_feedback_from_bank INTO DATA(ls_feedback_from_bank)
            with key doc1r = ls_payment_entry-doc1r.
*           WITH KEY bank_ind = ls_payment_entry-bank_ind
*                    paymorder  = ls_payment_entry-paymorder.
      IF sy-subrc <> 0.
*        没有执行发送到银行的步骤或发送失败
        CLEAR ls_feedback_from_bank.
        IF im_s_bank_error_step-int IS INITIAL.
*          程序错误
          MESSAGE x997 WITH 'UPDATE_PAYMENT_ENTRY'.
        ENDIF.
      ENDIF.
      ls_payment_entry-instance->feedback_from_bank(
                     EXPORTING
                       im_s_bank_feedback = ls_feedback_from_bank
                       im_s_bank_error_step = im_s_bank_error_step ).
    ENDLOOP.
  ENDMETHOD.
ENDCLASS.
