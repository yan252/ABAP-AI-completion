*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_TR_INITTOP.                   " Global Declarations
  INCLUDE LZFG_TR_INITUXX.                   " Function Modules


*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_TR_INITF...                   " Subroutines
* INCLUDE LZFG_TR_INITO...                   " PBO-Modules
* INCLUDE LZFG_TR_INITI...                   " PAI-Modules
* INCLUDE LZFG_TR_INITE...                   " Events
* INCLUDE LZFG_TR_INITP...                   " Local class implement.
* INCLUDE LZFG_TR_INITT99.                   " ABAP Unit tests
