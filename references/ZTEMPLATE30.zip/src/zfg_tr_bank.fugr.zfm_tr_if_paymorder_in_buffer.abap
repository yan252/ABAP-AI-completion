FUNCTION ZFM_TR_IF_PAYMORDER_IN_BUFFER.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     REFERENCE(IM_PAYMORDER) TYPE  ZTRT_PAYMENT-PAYMORDER
*"  EXPORTING
*"     REFERENCE(EX_EXISTED) TYPE  FLAG
*"--------------------------------------------------------------------
READ TABLE gt_paymorder_buffer TRANSPORTING NO FIELDS
       WITH KEY docno = im_paymorder.
  IF sy-subrc = 0.
    ex_existed = 'X'.
  ENDIF.





ENDFUNCTION.
