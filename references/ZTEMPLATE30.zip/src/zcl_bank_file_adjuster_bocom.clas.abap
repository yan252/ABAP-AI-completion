class ZCL_BANK_FILE_ADJUSTER_BOCOM definition
  public
  inheriting from ZCL_BANK_FILE_ADJUSTER
  final
  create public .

public section.

  methods ZIF_SENDING_FILE_ADJUSTER~ADJUST
    redefinition .
protected section.
private section.
ENDCLASS.



CLASS ZCL_BANK_FILE_ADJUSTER_BOCOM IMPLEMENTATION.


METHOD ZIF_SENDING_FILE_ADJUSTER~ADJUST.
    DATA:L_STRING  TYPE STRING,
         L_XSTRING TYPE XSTRING.
    LOOP AT CH_DATA ASSIGNING FIELD-SYMBOL(<FS_DATA>).
      ASSIGN <FS_DATA>-CFILE->* TO FIELD-SYMBOL(<F_CFILE>).

      ASSIGN <FS_DATA>-XFILE->* TO FIELD-SYMBOL(<F_XFILE>).


      ZCL_BANK_DATA_MAPPING_ENGINE=>SET_XML_STANDALONE(
                       IMPORTING
                         ET_RETURN_ERRORS = EX_T_RETURN
                        CHANGING
                          CH_XML_CSTRING = <F_CFILE>
                          CH_XML_XSTRING = <F_XFILE> ).
      IF EX_T_RETURN IS NOT INITIAL.
        EXIT.
      ENDIF.
*发送文件去除：#<?xml version="1.0" encoding="utf-16"?>
*去除<ap>前的所有字符。

      L_STRING = <F_CFILE>.
      REPLACE REGEX '(^.*\?>)' IN L_STRING WITH SPACE.
**      L_STRING+1(1) = ''."发现替换后 一个字符为一个不可见字符，在这去除。
*      L_STRING = '<ap><head><tr_code>310101</tr_code><corp_no>0008146710</corp_no><user_no>00003</user_no><req_no>1</req_no>'.
*      L_STRING = L_STRING && '<tr_acdt>20210413</tr_acdt><tr_time>161736</tr_time><atom_tr_count>1</atom_tr_count>'.
*      L_STRING = L_STRING && '<channel>0</channel><reserved>1</reserved></head><body><acno>310899991010008776083</acno></body></ap>'.
*

    CALL FUNCTION 'SCMS_STRING_TO_XSTRING'
      EXPORTING
        text   = L_STRING
      IMPORTING
        buffer = L_XSTRING
      EXCEPTIONS
        failed = 1
        OTHERS = 2.
    IF sy-subrc <> 0.
*let it be
      return.
    ENDIF.
    <F_CFILE> = L_STRING.
    <F_XFILE> = L_XSTRING.

      UNASSIGN: <F_CFILE>,
                <F_XFILE>.
    ENDLOOP.
  ENDMETHOD.
ENDCLASS.
