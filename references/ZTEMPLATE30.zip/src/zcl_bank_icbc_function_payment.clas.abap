class ZCL_BANK_ICBC_FUNCTION_PAYMENT definition
  public
  inheriting from ZCL_BANK_FUNCTION_PAYMENT
  final
  create public .

public section.

  interfaces ZIF_ICBC_CONSTANT .
  interfaces ZIF_ICBC_FUNCTION .

  aliases BANK_CODE
    for ZIF_ICBC_CONSTANT~BANK_CODE .
  aliases ERROR_XML_HEADER_PREFIX
    for ZIF_ICBC_CONSTANT~ERROR_XML_HEADER_PREFIX .
  aliases ERROR_XML_HEADER_SUFFIX
    for ZIF_ICBC_CONSTANT~ERROR_XML_HEADER_SUFFIX .
  aliases FILE_VERSION
    for ZIF_ICBC_CONSTANT~FILE_VERSION .
  aliases FSEQNO_ELEMENT_NAME
    for ZIF_ICBC_CONSTANT~FSEQNO_ELEMENT_NAME .
  aliases FSEQNO_ELEMENT_PREFIX
    for ZIF_ICBC_CONSTANT~FSEQNO_ELEMENT_PREFIX .
  aliases FSEQNO_ELEMENT_SUFFIX
    for ZIF_ICBC_CONSTANT~FSEQNO_ELEMENT_SUFFIX .
  aliases RESULTCODE_ELEMENT_PREFIX
    for ZIF_ICBC_CONSTANT~RESULTCODE_ELEMENT_PREFIX .
  aliases RESULTCODE_ELEMENT_SUFFIX
    for ZIF_ICBC_CONSTANT~RESULTCODE_ELEMENT_SUFFIX .
  aliases RESULTCODE_FOR_SIGN_OK
    for ZIF_ICBC_CONSTANT~RESULTCODE_FOR_SIGN_OK .
  aliases RESULTMSG_ELEMENT_PREFIX
    for ZIF_ICBC_CONSTANT~RESULTMSG_ELEMENT_PREFIX .
  aliases RESULTMSG_ELEMENT_SUFFIX
    for ZIF_ICBC_CONSTANT~RESULTMSG_ELEMENT_SUFFIX .
  aliases RESULTMSG_FOR_SIGN_ERROR
    for ZIF_ICBC_CONSTANT~RESULTMSG_FOR_SIGN_ERROR .
  aliases RESULTMSG_FOR_SIGN_OK
    for ZIF_ICBC_CONSTANT~RESULTMSG_FOR_SIGN_OK .
  aliases RESULTMSG_FOR_TRANX_ERROR
    for ZIF_ICBC_CONSTANT~RESULTMSG_FOR_TRANX_ERROR .
  aliases SIGN_ERROR_CODE
    for ZIF_ICBC_CONSTANT~SIGN_ERROR_CODE .
  aliases TRANSACTIONCODE_PAYMENT
    for ZIF_ICBC_CONSTANT~TRANSACTIONCODE_PAYMENT .
  aliases TRANX_ERROR_CODE
    for ZIF_ICBC_CONSTANT~TRANX_ERROR_CODE .
  aliases GET_CURRENT_PACKAGE_ID
    for ZIF_ICBC_FUNCTION~GET_CURRENT_PACKAGE_ID .

  methods ZIF_BANK_FUNCTION~CREATE_FILES
    redefinition .
  methods ZIF_BANK_FUNCTION~EXPORT_AFTER_PROCESSED
    redefinition .
  methods ZIF_BANK_FUNCTION~GET_SENDING_FILE
    redefinition .
  methods ZIF_BANK_FUNCTION_PAYM_RELATE~UPDATE_PAYMENT_ENTRY
    redefinition .
protected section.

  methods ADJUST_FILE_AFTER_CREATION
    redefinition .
  methods APPEND_RESPONSE_DATA
    redefinition .
  methods PROCESSING_RESPONSE_INTL_CORE
    redefinition .
private section.

  constants SIGN_STEP type ZTR_APP_ACTION_STEP value '001' ##NO_TEXT.
  constants PAYMENT_STEP type ZTR_APP_ACTION_STEP value '002' ##NO_TEXT.

  methods CREATE_PAYMENT_FILE .
ENDCLASS.



CLASS ZCL_BANK_ICBC_FUNCTION_PAYMENT IMPLEMENTATION.


  METHOD adjust_file_after_creation.
    IF step = '001'.
*      001是签名步骤，不需要调整
      RETURN.
    ENDIF.

    super->adjust_file_after_creation( ).

  ENDMETHOD.


  METHOD append_response_data.
*    DATA: l_new_ref TYPE REF TO data.
*    FIELD-SYMBOLS:<fs_response>     TYPE ztrs_icbc_payent_response,
*                  <fs_response_new> TYPE ztrs_icbc_payent_response.
*
*    IF step = '002'.
*      ASSIGN im_response_data_ref->* TO <fs_response>.
*      CREATE DATA l_new_ref LIKE <fs_response>.
*      ASSIGN l_new_ref->* TO <fs_response_new>.
*      <fs_response_new> = <fs_response>.
*
*      IF <fs_response_new>-out-rd IS INITIAL.
**        没有返回明细支付项目数据，说明报错了
*        <fs_response_new>-pub-retmsg = <fs_response_new>-pub-retcode &&
*                                   '-' &&
*                                   <fs_response_new>-pub-retmsg.
**        清空返回代码，在配置中工商银行支付交易没有返回代码是代表错误
*        CLEAR <fs_response_new>-pub-retcode.
*      ELSE.
*        LOOP AT <fs_response_new>-out-rd ASSIGNING FIELD-SYMBOL(<fs_rd>).
*          <fs_rd>-iretmsg = <fs_rd>-iretcode &&
*                            '-' &&
*                            <fs_rd>-iretmsg.
*        ENDLOOP.
*      ENDIF.
*    ELSE.
*      l_new_ref = im_response_data_ref.
*    ENDIF.
*
*    super->append_response_data( l_new_ref ).

    super->append_response_data( IM_RESPONSE_DATA_REF ).
  ENDMETHOD.


  METHOD create_payment_file.
    CONSTANTS: "c_sign_step              TYPE ztrt_action_step-step VALUE '001', "签名步骤
               c_sign_response_sequence TYPE i VALUE 1.

    FIELD-SYMBOLS: <fs_response>        TYPE ztrs_icbc_payent_response.
    FIELD-SYMBOLS: <ft_payment_entries>   TYPE ztrs_payment_entry_tab.
    FIELD-SYMBOLS: <ft_signed_entries>   TYPE ztrs_payment_entry_tab.
    DATA: ls_sending_file                TYPE ztrs_bank_sending_file,
          l_sending_sequence             TYPE ztrs_payment_entry-seqnumber,
          lt_payment_entries_for_filelog TYPE ztrs_payment_entry_tab.

    MESSAGE i307(ztr_bank_application)
            WITH bank_indicator
                 function_config-bank_func
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = instance_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = action
                      bank_ind     = bank_indicator
                      bank_func    = function_config-bank_func
                      step         = step ) ).

    DATA(lo_sign_function) =
               zcl_bank_abstract_action=>get_action(                    "get current running action
                                 )->get_bank( bank_indicator         "get current running bank
                                            )->get_bank_function( sign_step ). "get run function by step number.
    DATA(l_signed_entries_ref) = lo_sign_function->get_sending_data_reference( ).
    ASSIGN l_signed_entries_ref->* TO <ft_signed_entries>.

    ASSIGN sending_data_reference->* TO <ft_payment_entries>.

    LOOP AT <ft_payment_entries> ASSIGNING FIELD-SYMBOL(<fs_sending_entry>).
      READ TABLE <ft_signed_entries> INTO DATA(ls_signed_entry)
           WITH KEY doc1r = <fs_sending_entry>-doc1r.
      IF sy-subrc = 0.
        DATA(ls_signed_response) =
               zcl_bank_abstract_action=>get_action(                    "get current running action
                                 )->get_bank( bank_indicator         "get current running bank
                                            )->get_bank_function( sign_step "get run function by step number
                                                   )->get_response_data_by_sequence(     " get response data of a function
                                                             im_sending_sequence  = ls_signed_entry-seqnumber
                                                             im_response_sequence = c_sign_response_sequence ).

        TRY.
            DATA(l_xml_uuid) = cl_system_uuid=>if_system_uuid_static~create_uuid_c22( ).
          CATCH cx_uuid_error.
*        start log
            MESSAGE e001(ztr_bank_application)
                    INTO dummy_message.
            zcl_bank_logger_protocal=>add_log(
                     VALUE #( uuid         = instance_uuid
                              msgid        = sy-msgid
                              msgno        = sy-msgno
                              msgty        = sy-msgty
                              msgv1        = sy-msgv1
                              msgv2        = sy-msgv2
                              msgv3        = sy-msgv3
                              msgv4        = sy-msgv4
                              message      = dummy_message
                              bank_action  = action
                              bank_ind     = bank_indicator
                              bank_func    = function_config-bank_func
                              step         = step ) ).
*        end log
            EXIT.
        ENDTRY.

        ADD 1 TO l_sending_sequence.

        ASSIGN ls_signed_response-response_ref->* TO <fs_response>.

        ls_sending_file-file_uuid = l_xml_uuid.

        CREATE DATA ls_sending_file-cfile TYPE string.
        ASSIGN ls_sending_file-cfile->* TO FIELD-SYMBOL(<f_string>).
        CREATE DATA ls_sending_file-xfile TYPE xstring.
        ASSIGN ls_sending_file-xfile->* TO FIELD-SYMBOL(<f_xstring>).
        <f_string>  = cl_http_utility=>escape_url( <fs_response>-pub-sign ).

        ls_sending_file-sending_sequence = l_sending_sequence.
        APPEND ls_sending_file TO sending_files.
        <fs_sending_entry>-seqnumber = l_sending_sequence.
        APPEND <fs_sending_entry> TO lt_payment_entries_for_filelog.

      ELSE.
*        not possible
        MESSAGE x309(ztr_bank_application)
                WITH <fs_sending_entry>-doc1r.
      ENDIF.

      CLEAR ls_signed_response.
    ENDLOOP.



    MESSAGE i308(ztr_bank_application)
            WITH bank_indicator
                 function_config-bank_func
            INTO dummy_message.


    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = instance_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = action
                      bank_ind     = bank_indicator
                      bank_func    = function_config-bank_func
                      step         = step ) ).
*        end log
  ENDMETHOD.


  METHOD processing_response_intl_core.
    FIELD-SYMBOLS: <ft_sending_entries> TYPE ztrs_payment_entry_tab.
    FIELD-SYMBOLS: <fs_response>        TYPE ztrs_icbc_payent_response.
    DATA: ls_bank_payment_return TYPE ztrs_payment_bank_return.


    super->processing_response_intl_core( ).

    ASSIGN sending_data_reference->* TO <ft_sending_entries>.
    READ TABLE <ft_sending_entries> INTO DATA(ls_sending_entry)
         WITH KEY seqnumber = current_sending_sequence.
    IF sy-subrc <> 0.
*      unexpected error
      MESSAGE x091(ztr_bank_application)
              WITH function_config-bank_func
                   current_sending_sequence.
    ENDIF.

    DATA(ls_response_data) = get_current_response_data( ).
    ASSIGN ls_response_data-response_ref->* TO <fs_response>.

    MOVE: <fs_response>-pub-retcode TO ls_bank_payment_return-header-bank_rtncode,
          <fs_response>-pub-retmsg TO ls_bank_payment_return-header-bank_rtnmsg.

    CASE step.
      WHEN sign_step.
        APPEND VALUE #( paymorder = ls_sending_entry-paymorder
                        doc1r = ls_sending_entry-doc1r
                        bank_rtncode = <fs_response>-pub-retcode
                        bank_rtnmsg = <fs_response>-pub-retmsg )
                     TO ls_bank_payment_return-items.
      WHEN payment_step.
        READ TABLE <fs_response>-out-rd
                  INTO DATA(ls_rd)
                  INDEX 1.
*        工商银行设置为单笔交易
        IF sy-subrc = 0.
          APPEND VALUE #( paymorder = ls_sending_entry-paymorder
                          doc1r = ls_sending_entry-doc1r
                          bank_rtncode = ls_rd-result
                          bank_reqsts = COND #( WHEN  ls_rd-result = '6' AND ls_rd-iretcode = 'B0012' THEN  ls_rd-iretcode ELSE '' )"可能是重复发送导致的报错，先设置处理中，防止重新支付
                          bank_tran_number = <fs_response>-pub-serialno
                          bank_rtnmsg = ls_rd-iretmsg )
                       TO ls_bank_payment_return-items.
        ELSE.
          APPEND VALUE #( paymorder = ls_sending_entry-paymorder
                          doc1r = ls_sending_entry-doc1r
*                          bank_rtncode = space
                          bank_rtncode = <fs_response>-pub-retcode
                          bank_tran_number = <fs_response>-pub-serialno
                          bank_rtnmsg = <fs_response>-pub-retmsg )
                       TO ls_bank_payment_return-items.
        ENDIF.

    ENDCASE.

    update_status_in_instance( ls_bank_payment_return ).

  ENDMETHOD.


  METHOD zif_bank_function_paym_relate~update_payment_entry.
    DATA: l_delete_entry_instance TYPE flag.

    DATA:lo_action_interface TYPE REF TO zif_bank_action_payment_relate.
    DATA(lo_action) = zcl_bank_abstract_action=>get_action( ).

    lo_action_interface ?= lo_action.

    IF lo_action_interface IS NOT BOUND.
      RETURN.
    ENDIF.

    IF step = sign_step.
      l_delete_entry_instance = space.
    ELSE.
      l_delete_entry_instance = yes.
    ENDIF.

    lo_action_interface->update_entry_from_external(
                          EXPORTING
                            im_bank_indicator = bank_indicator
                            im_feedback_from_bank = im_feedback_from_bank
                            im_delete_entry_instance = l_delete_entry_instance ).

  ENDMETHOD.


  METHOD zif_bank_function~create_files.
*    步骤001是签名步骤
*    步骤002是实际支付业务交易步骤
*    两个步骤使用的都是工商银行PAYENT功能的报文格式
*    001 - 组建PAYENT报文发送去签名,获取签名结果
*    002 - 签名成功获得签名结果后，将签名结果再发送到工商银行执行真正的交易
    IF step = sign_step.
*      签名步骤
      super->create_files( ).

    ELSE.
*      支付交易步骤
      create_payment_file( ).
      adjust_file_after_creation( ).
    ENDIF.

  ENDMETHOD.


  METHOD zif_bank_function~export_after_processed.
    DATA: lt_signed_result TYPE ztrt_payment_entry_from_bank.
    FIELD-SYMBOLS:<ft_payment_entries> TYPE ztrs_payment_entry_tab,
                  <ft_result_entry>    TYPE ztrt_payment_entry_from_bank.

    CALL METHOD super->zif_bank_function~export_after_processed
      IMPORTING
        et_entries = et_entries.

    IF step = sign_step.
*      报文签名步骤
      RETURN.
    ENDIF.

    CALL METHOD
               zcl_bank_abstract_action=>get_action(                    "get current running action
                                     )->get_bank( bank_indicator         "get current running bank
                                                )->get_bank_function( sign_step  "get run function by step number.
                                                   )->export_after_processed(
                                                               IMPORTING
                                                                 et_entries = lt_signed_result ).
    ASSIGN sending_data_reference->* TO <ft_payment_entries>.

    ASSIGN et_entries TO <ft_result_entry>.

    LOOP AT <ft_payment_entries> INTO DATA(ls_payment_entry).
      READ TABLE <ft_result_entry> INTO DATA(ls_export_entry)
            WITH KEY doc1r = ls_payment_entry-doc1r.
      CHECK sy-subrc <> 0.
*      找不到真是的支付反馈
      READ TABLE lt_signed_result INTO DATA(ls_sign_result)
           WITH KEY doc1r = ls_payment_entry-doc1r.
      IF sy-subrc = 0.
*        用签名步骤的反馈返回
        APPEND ls_sign_result TO <ft_result_entry>.
      ENDIF.
    ENDLOOP.

  ENDMETHOD.


  METHOD zif_bank_function~get_sending_file.
    FIELD-SYMBOLS:<ft_payment_entries> TYPE ztrs_payment_entry_tab.
    DATA: lt_signed_result TYPE ztrt_payment_entry_from_bank.

    CALL METHOD super->zif_bank_function~get_sending_file
      IMPORTING
        ex_file_uuid        = ex_file_uuid
        ex_sending_sequence = ex_sending_sequence
        ex_cfile_ref        = ex_cfile_ref
        ex_xfile_ref        = ex_xfile_ref
        ex_do_not_send      = ex_do_not_send.
    IF ex_do_not_send = yes.
      current_response_is_finished = yes.
      RETURN.
    ENDIF.

    IF step <> payment_step.
*  不是支付步骤
      RETURN.
    ENDIF.

    CALL METHOD
               zcl_bank_abstract_action=>get_action(                    "get current running action
                                     )->get_bank( bank_indicator         "get current running bank
                                                )->get_bank_function( sign_step  "get run function by step number.
                                                   )->export_after_processed(
                                                               IMPORTING
                                                                 et_entries = lt_signed_result ).

    ASSIGN sending_data_reference->* TO <ft_payment_entries>.

    READ TABLE <ft_payment_entries> INTO DATA(ls_payment_entry)
         WITH KEY seqnumber = ex_sending_sequence.
    IF sy-subrc <> 0.
*  不可能出现的错误
      MESSAGE x313(ztr_bank_application) WITH ex_sending_sequence.
    ENDIF.
    READ TABLE lt_signed_result INTO DATA(ls_sign_result)
         WITH KEY doc1r = ls_payment_entry-doc1r.
    IF sy-subrc <> 0.
*     都跑到支付发送步骤了，不应该出现找不到相应的签名记录
*      如果签名有错误，在签名步骤就应该报错了，不应该再跑到支付发送步骤
      ex_do_not_send = yes.
      current_response_is_finished = yes.
    ELSE.
      IF ls_sign_result-rtntype = 'F'.
*        签名失败
        ex_do_not_send = yes.
        current_response_is_finished = yes.
      ENDIF.
    ENDIF.

  ENDMETHOD.


  METHOD zif_icbc_function~get_current_package_id.
    FIELD-SYMBOLS:<ft_sending_entries> TYPE ztrs_payment_entry_tab.

    ASSIGN sending_data_reference->* TO <ft_sending_entries>.

    READ TABLE <ft_sending_entries> INTO DATA(ls_entry)
         WITH KEY seqnumber = current_sending_sequence.

    re_package_id = ls_entry-doc1r.
  ENDMETHOD.
ENDCLASS.
