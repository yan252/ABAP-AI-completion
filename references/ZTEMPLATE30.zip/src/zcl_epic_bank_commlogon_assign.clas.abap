class ZCL_EPIC_BANK_COMMLOGON_ASSIGN definition
  public
  final
  create public .

public section.

  methods CHANGE
    importing
      !IS_NEW_BANK_ASSIGN type ZTRT_BANK_ASS
    raising
      ZCX_EPIC_BANK_COMM_LOGON .
  methods CONSTRUCTOR
    importing
      !IS_BANK_ASSIGN type ZTRT_BANK_ASS .
  methods INSERT
    raising
      ZCX_EPIC_BANK_COMM_LOGON .
  methods DELETE
    raising
      ZCX_EPIC_BANK_COMM_LOGON .
  class-methods S_LOAD_ALL
    exporting
      !ET_ALL_ASSIGNMENTS type ZTRT_BANK_ASS_TAB .
PROTECTED SECTION.
private section.

  data MS_BANK_ASSIGN type ZTRT_BANK_ASS .

  methods CHANGE_USER_ASSIGN
    importing
      !IS_NEW_BANK_ASSIGN type ZTRT_BANK_ASS .
  methods DELETE_USER_ASSIGN .
  methods COMM_EXISTS_ASSIGN
    returning
      value(RF_EXISTS_ASSIGN) type FLAG .
  methods INSERT_USER_ASSIGN .
  methods LOCK
    raising
      ZCX_EPIC_BANK_COMM_LOGON .
  methods UNLOCK .
ENDCLASS.



CLASS ZCL_EPIC_BANK_COMMLOGON_ASSIGN IMPLEMENTATION.


METHOD change.
    DATA lf_exists_guid TYPE flag.
    DATA lr_cx_epic_bank_comm_logon TYPE REF TO zcx_epic_bank_comm_logon.
    DATA lo_user TYPE REF TO cl_epic_bank_comm_logon.
    DATA ls_new_bank_assign LIKE me->ms_bank_assign.
    DATA ls_old_bank_assign LIKE me->ms_bank_assign.


* check authority
    IF  cl_epic_bank_comm_logon=>s_has_authority( ) = abap_false.
      RAISE EXCEPTION TYPE zcx_epic_bank_comm_logon
        EXPORTING
          textid = zcx_epic_bank_comm_logon=>no_authorization.
    ENDIF.

    TRY .
        me->lock( ).
      CATCH zcx_epic_bank_comm_logon INTO lr_cx_epic_bank_comm_logon.
        RAISE EXCEPTION TYPE zcx_epic_bank_comm_logon
          EXPORTING
            previous = lr_cx_epic_bank_comm_logon.
    ENDTRY.

    CREATE OBJECT lo_user
      EXPORTING
        iv_guid = is_new_bank_assign-guid.

    lo_user->exists_guid(
      IMPORTING
        ef_exists = lf_exists_guid ).

    IF  lf_exists_guid = abap_false.
      RAISE EXCEPTION TYPE zcx_epic_bank_comm_logon
        EXPORTING
          textid = zcx_epic_bank_comm_logon=>user_not_exits.
    ENDIF.


    " in case of no changes
    ls_new_bank_assign = is_new_bank_assign.
    ls_old_bank_assign = me->ms_bank_assign.
    CLEAR ls_new_bank_assign-mandt.
    CLEAR ls_old_bank_assign-mandt.
    IF ls_new_bank_assign = ls_old_bank_assign.
      me->unlock( ).

      RAISE EXCEPTION TYPE zcx_epic_bank_comm_logon
        EXPORTING
          textid = zcx_epic_bank_comm_logon=>no_change.
    ENDIF.

    me->change_user_assign( is_new_bank_assign ).
    me->unlock( ).

    me->ms_bank_assign = is_new_bank_assign.

  ENDMETHOD.                    "CHANGE


METHOD change_user_assign.

    data: ls_new_bank_assign type ztrt_bank_ass.

    DATA(ls_system_info) = zcl_global_technical_service=>get_system_info( ).


    DELETE ztrt_bank_ass FROM me->ms_bank_assign.

    ls_new_bank_assign = is_new_bank_assign.

    ls_new_bank_assign-AEDAT = ls_system_info-datum.
    ls_new_bank_assign-AEZET = ls_system_info-uzeit.
    ls_new_bank_assign-AENAM = ls_system_info-uname.
    MODIFY ztrt_bank_ass FROM ls_new_bank_assign.
  ENDMETHOD.                    "CHANGE_USER_ASSIGN


METHOD comm_exists_assign.
    SELECT COUNT( * ) INTO @DATA(l_count)
            FROM ztrt_bank_ass
            WHERE bank_ind = @me->ms_bank_assign-bank_ind.
    IF l_count > 0.
      rf_exists_assign = abap_true.
    ENDIF.
  ENDMETHOD.                    "COMM_EXISTS_ASSIGN


METHOD CONSTRUCTOR.
    me->ms_bank_assign = IS_BANK_ASSIGN.
  ENDMETHOD.                    "CONSTRUCTOR


METHOD DELETE.


* check authority
    IF  cl_epic_bank_comm_logon=>s_has_authority( ) = abap_false.
      RAISE EXCEPTION TYPE zCX_EPIC_BANK_COMM_LOGON
        EXPORTING
          textid = zCX_EPIC_BANK_COMM_LOGON=>no_authorization.
    ENDIF.


    me->lock( ).

    me->delete_user_assign( ).

    me->unlock( ).


  ENDMETHOD.                    "DELETE


METHOD DELETE_USER_ASSIGN.
*    DELETE epic_bc_ua FROM me->ms_epic_bc_ua.
    delete ztrt_bank_ass FROM me->ms_bank_assign.
  ENDMETHOD.                    "DELETE_USER_ASSIGN


METHOD insert.
    DATA lf_exists_guid TYPE flag.
    DATA lo_user TYPE REF TO cl_epic_bank_comm_logon.

* check authority
    IF  cl_epic_bank_comm_logon=>s_has_authority( ) = abap_false.
      RAISE EXCEPTION TYPE zcx_epic_bank_comm_logon
        EXPORTING
          textid = zcx_epic_bank_comm_logon=>no_authorization.
    ENDIF.

    CREATE OBJECT lo_user
      EXPORTING
        iv_guid = ms_bank_assign-guid.

    lo_user->exists_guid(
      IMPORTING
        ef_exists = lf_exists_guid ).

    IF  lf_exists_guid = abap_false.
      RAISE EXCEPTION TYPE zcx_epic_bank_comm_logon
        EXPORTING
          textid = zcx_epic_bank_comm_logon=>user_not_exits.
    ENDIF.


    IF  me->comm_exists_assign( ) = abap_true.
      RAISE EXCEPTION TYPE zcx_epic_bank_comm_logon
        EXPORTING
          textid = zcx_epic_bank_comm_logon=>assignment_exits.
    ENDIF.

    me->insert_user_assign( ).


  ENDMETHOD.                    "CREATE


METHOD insert_user_assign.

    DATA(ls_system_info) = zcl_global_technical_service=>get_system_info( ).

    DATA: ls_new_bank_assign TYPE ztrt_bank_ass.

    ls_new_bank_assign = me->ms_bank_assign.
    ls_new_bank_assign-erdat = ls_system_info-datum.
    ls_new_bank_assign-erzet = ls_system_info-uzeit.
    ls_new_bank_assign-ernam = ls_system_info-uname.

    INSERT ztrt_bank_ass FROM ls_new_bank_assign.
  ENDMETHOD.                    "INSERT_USER_ASSIGN


METHOD lock.
    CALL FUNCTION 'ENQUEUE_EZTRT_BANK_ASS'
      EXPORTING
        mode_ztrt_bank_ass = 'E'
        mandt              = sy-mandt
        bank_ind           = me->ms_bank_assign-bank_ind
        x_bank_ind         = ' '
        _scope             = '2'
        _wait              = ' '
        _collect           = ' '
      EXCEPTIONS
        foreign_lock       = 1
        system_failure     = 2
        OTHERS             = 3.
    IF sy-subrc <> 0.
      RAISE EXCEPTION TYPE zcx_epic_bank_comm_logon
        EXPORTING
          textid = zcx_epic_bank_comm_logon=>enqueue_error.
    ENDIF.
  ENDMETHOD.                    "LOCK


METHOD S_LOAD_ALL.
    CLEAR et_all_assignments.
*    SELECT * FROM  epic_bc_ua INTO TABLE et_all_assignments. "#EC CI_NOWHERE
    select * into table ET_ALL_ASSIGNMENTS from ztrt_bank_ass. "#EC CI_NOWHERE
  ENDMETHOD.                    "S_LOAD_ALL


METHOD unlock.
    CALL FUNCTION 'DEQUEUE_EZTRT_BANK_ASS'
      EXPORTING
        mode_ztrt_bank_ass = 'E'
        mandt              = sy-mandt
        bank_ind           = me->ms_bank_assign-bank_ind
        x_bank_ind         = ' '
        _scope             = '3'
        _synchron          = ' '
        _collect           = ' '.

  ENDMETHOD.                    "UNLOCK
ENDCLASS.
