*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_TR2_BANK_DBYDTOP.             " Global Declarations
  INCLUDE LZFG_TR2_BANK_DBYDUXX.             " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_TR2_BANK_DBYDF...             " Subroutines
* INCLUDE LZFG_TR2_BANK_DBYDO...             " PBO-Modules
* INCLUDE LZFG_TR2_BANK_DBYDI...             " PAI-Modules
* INCLUDE LZFG_TR2_BANK_DBYDE...             " Events
* INCLUDE LZFG_TR2_BANK_DBYDP...             " Local class implement.
* INCLUDE LZFG_TR2_BANK_DBYDT99.             " ABAP Unit tests
