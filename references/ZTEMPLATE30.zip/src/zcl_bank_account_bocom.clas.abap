class ZCL_BANK_ACCOUNT_BOCOM definition
  public
  inheriting from ZCL_ABSTRACT_BANK_ACCOUNT
  final
  create public .

public section.
protected section.

  methods BANK_BALANCE_TO_SAP
    redefinition .
  methods BANK_TRANSACTIONS_TO_SAP
    redefinition .
  methods DEQUEUE_TRANSACTION
    redefinition .
  methods SET_ACCOUNT_BALANCE_CORE
    redefinition .
  methods SET_ACCOUNT_TABNAME
    redefinition .
  methods SET_TRANSACTIONS_CORE
    redefinition .
private section.
ENDCLASS.



CLASS ZCL_BANK_ACCOUNT_BOCOM IMPLEMENTATION.


METHOD BANK_BALANCE_TO_SAP.
    FIELD-SYMBOLS: <ft_new_account_balance> TYPE STANDARD TABLE.
    DATA: ls_balance_ext TYPE ztrt_BOCOM_acbal.
    DATA: L_ZYUE_FRZ  TYPE ZTR_ZYUE_FRZ."冻结余额

    ASSIGN new_account_balance->* TO <ft_new_account_balance>.
    IF <ft_new_account_balance> IS NOT ASSIGNED OR
       <ft_new_account_balance> IS INITIAL.
      RETURN.
    ENDIF.

    LOOP AT <ft_new_account_balance> INTO ls_balance_ext.
      L_ZYUE_FRZ = ls_balance_ext-BALANCE - ls_balance_ext-USABLEBALANCE.
      APPEND VALUE #(
                       bukrs        = ls_balance_ext-sap_bukrs
                       hbkid        = ls_balance_ext-sap_hbkid
                       hktid        = ls_balance_ext-sap_hktid
                       yhzh         = ls_balance_ext-ACCNO
                       bank_ind     = bank_indicator
                       zyue_ttl     = ls_balance_ext-BALANCE"当前余额
                       zyue_frz     = L_ZYUE_FRZ"冻结余额
                       zyue         = ls_balance_ext-USABLEBALANCE"可用余额
                       waers        = GET_ACCOUNT_CURRENCY( ls_balance_ext-sap_fields )
                       ) TO rt_balance.

    ENDLOOP.
  ENDMETHOD.


METHOD BANK_TRANSACTIONS_TO_SAP.
    FIELD-SYMBOLS: <FT_NEW_TRANSACTIONS> TYPE STANDARD TABLE.
    DATA: LS_TRANSACTIONS_EXT TYPE ZTRT_BOCOM_TRNS.
    DATA: BEGIN OF LS_ACCOUNT,
            BZBNKA TYPE ZTRT_BANK_TRANS-BZBNKA,
            BZBNKN TYPE ZTRT_BANK_TRANS-BZBNKN,
            BKOINH TYPE ZTRT_BANK_TRANS-BKOINH,
          END OF LS_ACCOUNT.
    DATA:  L_SHKZG TYPE SHKZG.
    DATA:LV_BKOINH TYPE STRING.

    ASSIGN NEW_TRANSACTIONS->* TO <FT_NEW_TRANSACTIONS>.
    IF <FT_NEW_TRANSACTIONS> IS NOT ASSIGNED OR
       <FT_NEW_TRANSACTIONS> IS INITIAL.
      RETURN.
    ENDIF.



    LOOP AT <FT_NEW_TRANSACTIONS> INTO LS_TRANSACTIONS_EXT.
      DATA(LS_PAYMENTKEY) = GET_PAYMKEY_FROM_TRANSACTION( LS_TRANSACTIONS_EXT-NOTES ).


**-----Begin 对方名称中的全角和半角括号去除后存入字段BKOINH1中 金志强 Add by KLTDEV5 20190726
*      "字符串转换
      LV_BKOINH = LS_TRANSACTIONS_EXT-KHHNA.
*      LV_BKOINH = CONVERT_STRING( EXPORTING STRING = LV_BKOINH CHAR = '(' ).
*      LV_BKOINH = CONVERT_STRING( EXPORTING STRING = LV_BKOINH CHAR = ')' ).
*      LV_BKOINH = CONVERT_STRING( EXPORTING STRING = LV_BKOINH CHAR = '（' ).
*      LV_BKOINH = CONVERT_STRING( EXPORTING STRING = LV_BKOINH CHAR = '）' ).
**-----End 对方名称中的全角和半角括号去除后存入字段BKOINH1中 金志强 Add by KLTDEV5 20190726
* ‘C’:贷
*‘D’:借

      IF LS_TRANSACTIONS_EXT-SZBJ = 'C'.
        L_SHKZG = 'H'.
      ELSEIF LS_TRANSACTIONS_EXT-SZBJ = 'D'.
        L_SHKZG = 'S'.
      ENDIF.
      APPEND VALUE #(
                       BUKRS        = LS_TRANSACTIONS_EXT-SAP_BUKRS
                       HBKID        = LS_TRANSACTIONS_EXT-SAP_HBKID
                       HKTID        = LS_TRANSACTIONS_EXT-SAP_HKTID
                       YHZH         = LS_TRANSACTIONS_EXT-ACCNO
                       TRXNO        = LS_TRANSACTIONS_EXT-TRANSID
                       BANK_IND     = BANK_INDICATOR
                       TRXDATE      = LS_TRANSACTIONS_EXT-JYRQ
                       TRXTIME      = LS_TRANSACTIONS_EXT-JYTM
                       SHKZG        = L_SHKZG
                       BKFSE       = CONV ZTR_BANK_TRXAMT( LS_TRANSACTIONS_EXT-JYJR )
                       TRXAMT        = CONVERT_TRANSAMT_BY_SHKZG( IM_SHKZG = L_SHKZG
                                                                 IM_ORIGINAL_AMT = LS_TRANSACTIONS_EXT-JYJR )

                       BALAMT       = CONV ZTR_BANK_BALAMT( LS_TRANSACTIONS_EXT-BALANCE )
                       WAERS        = LS_TRANSACTIONS_EXT-SAP_WAERS
*                           对方开户行名称
                       BZBNKA       = LS_TRANSACTIONS_EXT-KHHNA
*                           对方帐号
                       BZBNKN       = LS_TRANSACTIONS_EXT-ACCNO2
*                           对方账户名
                       BKOINH       = LS_TRANSACTIONS_EXT-ZHMC2
*                           附言
                       POSTSCRIPT_TXT = LS_TRANSACTIONS_EXT-NOTES
**                           用途
*                       USAGE_TXT      = ZCL_BOC_ENHANCEMENT=>GET_INTERINFO_PARTIALLY(
*                                                                    IM_INTERINFO_CODE = 'U'
*                                                                    IM_INTERINFO_TEXT = LS_TRANSACTIONS_EXT-INTERINFO )
**                           摘要
*                       ABSTRACT_TXT = ZCL_BOC_ENHANCEMENT=>GET_INTERINFO_PARTIALLY(
*                                                                    IM_INTERINFO_CODE = 'A'
*                                                                    IM_INTERINFO_TEXT = LS_TRANSACTIONS_EXT-INTERINFO )
*                           备注
                       COMMENT_TXT  = LS_TRANSACTIONS_EXT-REMA
*                       PAYMENTKEY  = LS_PAYMENTKEY
                       ZREF_DOC = LS_PAYMENTKEY-PAYMORDER
                       INTFDATE     = SYSTEM_INFO-DATUM
                       INTFTIME     = SYSTEM_INFO-UZEIT
*                       kunnr2       = set_customer_code_by_name( ls_account-bkoinh )
*                       lifnr        = set_vendor_code_by_name( ls_account-bkoinh )
                       PARTNER = SET_PARTNER_BY_NAME( LS_ACCOUNT-BKOINH )
                       BKOINH1 = LV_BKOINH
                       ) TO RT_TRANSACTIONS.

    ENDLOOP.

    FINISHED_SAP_TRANX_FIELDS(
               CHANGING
                 CH_T_TRANX = RT_TRANSACTIONS ).
  ENDMETHOD.


method DEQUEUE_TRANSACTION.
    DATA:ls_transaction TYPE ztrt_BOCOM_trns.

    LOOP AT im_t_transactions INTO ls_transaction.
      dequeue_transaction_core(
                     im_bukrs = ls_transaction-sap_bukrs
                     im_hbkid = ls_transaction-sap_hbkid
                     im_hktid = ls_transaction-sap_hktid
                     im_yhzh = ls_transaction-ACCNO
                     im_trxno = ls_transaction-transid ).
    ENDLOOP.
  endmethod.


METHOD SET_ACCOUNT_BALANCE_CORE.
    FIELD-SYMBOLS: <FT_BOCOM_BALANCE> TYPE ZTRT_BOCOM_ACBAL_TAB.
    FIELD-SYMBOLS:<FT_NEW_ENTRIES> TYPE ZTRT_BOCOM_ACBAL_TAB.
    DATA: L_NEW     TYPE FLAG,
          L_CHANGED TYPE FLAG.

    ASSIGN IM_DATA->* TO <FT_BOCOM_BALANCE>.

    ASSIGN NEW_ACCOUNT_BALANCE->* TO <FT_NEW_ENTRIES>.

    IF <FT_BOCOM_BALANCE> IS INITIAL.
      RETURN.
    ENDIF.

    SELECT * INTO TABLE @DATA(LT_OLD_DATA)
           FROM ZTRT_BOCOM_ACBAL
           FOR ALL ENTRIES IN @<FT_BOCOM_BALANCE>
           WHERE ACCNO = @<FT_BOCOM_BALANCE>-ACCNO.

    LOOP AT <FT_BOCOM_BALANCE> INTO DATA(LS_BOCOM_BALANCE).
*      CHECK FILTER_ACCBAL_BY_SHIFTON_DATE(
*                  EXPORTING
*                    IM_S_SAP_FIELD = LS_BOCOM_BALANCE-SAP_FIELDS  ) = 'X'.

      READ TABLE LT_OLD_DATA INTO DATA(LS_OLD_DATA)
           WITH KEY ACCNO = LS_BOCOM_BALANCE-ACCNO.
      IF SY-SUBRC <> 0.
*      new
        L_NEW = 'X'.
      ELSE.
        IF LS_BOCOM_BALANCE-ACC_FIELD <> LS_OLD_DATA-ACC_FIELD.
          L_CHANGED = 'X'.
        ENDIF.
      ENDIF.

      IF L_NEW = 'X' OR
         L_CHANGED = 'X'.
        LS_BOCOM_BALANCE-DBADMIN = LS_OLD_DATA-DBADMIN.
        SET_ADMIN_FIELDS(
                  EXPORTING
                    IM_NEW_ENTRY = L_NEW
                  CHANGING
                    CS_ADMIN = LS_BOCOM_BALANCE-DBADMIN ).
        APPEND LS_BOCOM_BALANCE TO <FT_NEW_ENTRIES>.
      ENDIF.

      CLEAR: L_NEW,
             L_CHANGED.
    ENDLOOP.

  ENDMETHOD.


METHOD SET_ACCOUNT_TABNAME.
    transaction_db_tabname = 'ZTRT_BOCOM_TRNS'."交易明细
    account_balance_db_tabname = 'ZTRT_BOCOM_ACBAL'."交通银行账户余额
*    history_acc_balance_db_name = 'ZTRT_BOCOM_HACBAL'."历史余额
    super->SET_ACCOUNT_TABNAME( ).
  ENDMETHOD.


METHOD SET_TRANSACTIONS_CORE.
*交易明细
    FIELD-SYMBOLS: <FT_TRANSACTIONS> TYPE ZTRT_BOCOM_TRNS_TAB.
    FIELD-SYMBOLS: <FT_NEW_ENTRIES> TYPE ZTRT_BOCOM_TRNS_TAB.
    DATA: L_NEW     TYPE FLAG,
          L_CHANGED TYPE FLAG.

    ASSIGN IM_DATA->* TO <FT_TRANSACTIONS>.

    ASSIGN NEW_TRANSACTIONS->* TO <FT_NEW_ENTRIES>.

    IF <FT_TRANSACTIONS> IS NOT ASSIGNED OR
       <FT_TRANSACTIONS> IS INITIAL.
      RETURN.
    ENDIF.

    SELECT * INTO TABLE @DATA(LT_OLD_DATA)
           FROM ZTRT_BOCOM_TRNS
           FOR ALL ENTRIES IN @<FT_TRANSACTIONS>
           WHERE ACCNO = @<FT_TRANSACTIONS>-ACCNO
           AND   TRANSID = @<FT_TRANSACTIONS>-TRANSID.

    LOOP AT <FT_TRANSACTIONS> INTO DATA(LS_TRANSACTIONS).
      CHECK FILTER_TRANS_BY_SHIFTON_DATE(
                  EXPORTING
                    IM_S_SAP_FIELD = LS_TRANSACTIONS-SAP_FIELDS
                    IM_TRANSACTION_DATE = CONV #( LS_TRANSACTIONS-JYRQ ) ) = 'X'.

      ENQUEUE_TRANSACTION_CORE(
                   EXPORTING
                     IM_BUKRS = LS_TRANSACTIONS-SAP_BUKRS
                     IM_HBKID = LS_TRANSACTIONS-SAP_HBKID
                     IM_HKTID = LS_TRANSACTIONS-SAP_HKTID
                     IM_YHZH = LS_TRANSACTIONS-ACCNO
                     IM_TRXNO = LS_TRANSACTIONS-TRANSID
                   IMPORTING
                     EX_ENQUEUE_FAILED = DATA(L_ENQUEUE_FAILED) ).
      IF L_ENQUEUE_FAILED = YES.
*        被锁定，不纳入本次处理
        CLEAR L_ENQUEUE_FAILED.
        CONTINUE.
      ENDIF.

      READ TABLE LT_OLD_DATA INTO DATA(LS_OLD_DATA)
           WITH KEY ACCNO = LS_TRANSACTIONS-ACCNO
                    TRANSID = LS_TRANSACTIONS-TRANSID.
      IF SY-SUBRC <> 0.
*      new
        L_NEW = 'X'.
      ELSE.
        IF LS_TRANSACTIONS-TRNS_FIELD <> LS_OLD_DATA-TRNS_FIELD.
          L_CHANGED = 'X'.
        ENDIF.
      ENDIF.

      IF L_NEW = 'X' OR
         L_CHANGED = 'X'.
        LS_TRANSACTIONS-DBADMIN = LS_OLD_DATA-DBADMIN.
        SET_ADMIN_FIELDS(
                  EXPORTING
                    IM_NEW_ENTRY = L_NEW
                  CHANGING
                    CS_ADMIN = LS_TRANSACTIONS-DBADMIN ).
        APPEND LS_TRANSACTIONS TO <FT_NEW_ENTRIES>.
      ELSE.
        DEQUEUE_TRANSACTION_CORE(
                     EXPORTING
                       IM_BUKRS = LS_TRANSACTIONS-SAP_BUKRS
                       IM_HBKID = LS_TRANSACTIONS-SAP_HBKID
                       IM_HKTID = LS_TRANSACTIONS-SAP_HKTID
                       IM_YHZH = LS_TRANSACTIONS-ACCNO
                       IM_TRXNO = LS_TRANSACTIONS-TRANSID ).
      ENDIF.

      CLEAR: L_NEW,
             L_CHANGED,
             LS_OLD_DATA.
    ENDLOOP.

  ENDMETHOD.
ENDCLASS.
