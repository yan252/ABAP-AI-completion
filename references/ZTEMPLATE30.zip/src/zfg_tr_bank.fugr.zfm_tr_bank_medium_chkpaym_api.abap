FUNCTION ZFM_TR_BANK_MEDIUM_CHKPAYM_API.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     VALUE(IM_T_ENTRY_LIST) TYPE  ZTRS_PAYMENTENTRY_LIST_TAB
*"     VALUE(IM_BANK_ACTION) TYPE  ZTR_APP_ACTION_FOR_BANK
*"         DEFAULT '004'
*"     VALUE(IM_TRIGGER_BY_ACC_TRANX) TYPE  CHAR01 OPTIONAL
*"--------------------------------------------------------------------
LOOP AT zcl_bank_api_dispatcher=>dispatch_payment_entries( im_t_entry_list )
           INTO DATA(ls_entries_by_action).
    CALL FUNCTION 'ZFM_TR_BANK_CHKPAYM_CORE'
      EXPORTING
        im_t_entry_list         = ls_entries_by_action-entries
        im_bank_action          = ls_entries_by_action-action
        im_trigger_by_acc_tranx = im_trigger_by_acc_tranx.
  ENDLOOP.





ENDFUNCTION.
