FUNCTION ZFM_TR_00192_DEQUEUE_EDOC.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     REFERENCE(IM_DOCNO_KEY) TYPE  ZTR_DOCNO_BASE
*"     REFERENCE(IM_BUKRS) TYPE  BUKRS
*"     REFERENCE(IM_ZJSNO) TYPE  ZTR_JSNO
*"--------------------------------------------------------------------
READ TABLE gt_070_key ASSIGNING FIELD-SYMBOL(<fs_070_key>)
        WITH KEY docno_key = im_docno_key
                 bukrs = im_bukrs
                 zjsno = im_zjsno.
  IF sy-subrc <> 0.
    RETURN.
  ENDIF.

  CALL FUNCTION 'DEQUEUE_EZTRT0070'
    EXPORTING
      mode_ztrt0070 = 'E'
      mandt         = sy-mandt
      docno_key     = <fs_070_key>-docno_key
      bukrs         = <fs_070_key>-bukrs
      zjsno         = <fs_070_key>-zjsno
      x_docno_key   = ' '
      x_bukrs       = ' '
      x_zjsno       = ' '
      _scope        = '3'
      _synchron     = ' '
      _collect      = ' '.
  CALL FUNCTION 'DEQUEUE_EZTRT0050'
    EXPORTING
      mode_ztrt0050 = 'E'
      mandt         = sy-mandt
      docno_key     = <fs_070_key>-docno_key
      x_docno_key   = ' '
      _scope        = '3'
      _synchron     = ' '
      _collect      = ' '.

delete gt_070_key WHERE docno_key = im_docno_key
                  and   bukrs = im_bukrs
                  and   zjsno = im_zjsno.





ENDFUNCTION.
