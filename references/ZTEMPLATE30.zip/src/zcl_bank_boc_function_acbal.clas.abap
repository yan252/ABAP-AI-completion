class ZCL_BANK_BOC_FUNCTION_ACBAL definition
  public
  inheriting from ZCL_BANK_FUNCTION_ACCBALANCE
  final
  create public .

public section.

  interfaces ZIF_BOC_FUNCTION .

  aliases RAISE_B2EERROR
    for ZIF_BOC_FUNCTION~RAISE_B2EERROR .
protected section.

  methods PROCESSING_RESPONSE_INTL_CORE
    redefinition .
private section.
ENDCLASS.



CLASS ZCL_BANK_BOC_FUNCTION_ACBAL IMPLEMENTATION.


  METHOD processing_response_intl_core.
    CASE action.
      WHEN zif_bank_action=>action_is_account_balance.
*        当前余额
        processing_response_by_dbtable(
                    im_data_db_table = 'ZTRT_BOC_ACBAL'
                    im_detail_response_component = 'TRANS'
                    im_statuscode_componnet = 'H_STATUS-RSPCOD'
                    im_statustext_component = 'H_STATUS-RSPMSG'
                    im_db_account_number_field = 'ACTACN'
                    im_bank_entry_accnumber_field = 'ACTACN'  ).
      WHEN zif_bank_action=>action_is_acc_history_balance.
*        历史余额
        processing_response_by_dbtable(
                    im_data_db_table = 'ZTRT_BOC_HACBAL'
                    im_detail_response_component = 'TRANS'
                    im_statuscode_componnet = 'H_STATUS-RSPCOD'
                    im_statustext_component = 'H_STATUS-RSPMSG'
                    im_db_account_number_field = 'ACTACN'
                    im_bank_entry_accnumber_field = 'ACTACN'  ).
    ENDCASE.

  ENDMETHOD.


  METHOD zif_boc_function~raise_b2eerror.
    raise_b2eerror.
    check_response_if_finished( ).
  ENDMETHOD.
ENDCLASS.
