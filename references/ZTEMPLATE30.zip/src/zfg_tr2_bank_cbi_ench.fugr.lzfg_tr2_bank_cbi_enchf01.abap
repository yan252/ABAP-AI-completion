*----------------------------------------------------------------------*
***INCLUDE LZFG_TR2_BANK_CBI_ENCHF01.
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  NEW_ACTION
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_I_ITEM  text
*----------------------------------------------------------------------*
FORM new_action  USING    i_item.
  ASSIGN COMPONENT 'FPAYH' OF STRUCTURE i_item TO FIELD-SYMBOL(<fs_fpayh>).
  ASSIGN COMPONENT 'DOC1R' OF STRUCTURE <fs_fpayh> TO FIELD-SYMBOL(<fs_doc1r>).
  IF go_action IS INITIAL OR gv_docno NE <fs_doc1r>.
    go_action = NEW zcl_cbi_dlcbitrn_enhancement( CONV #( <fs_doc1r> ) ).
  ENDIF.
ENDFORM.
