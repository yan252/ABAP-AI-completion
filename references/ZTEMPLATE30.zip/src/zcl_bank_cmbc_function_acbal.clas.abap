class ZCL_BANK_CMBC_FUNCTION_ACBAL definition
  public
  inheriting from ZCL_BANK_FUNCTION_ACCBALANCE
  final
  create public .

public section.

  interfaces ZIF_CMBC_FUNCTION .
protected section.

  aliases INTERACTION_COUNT
    for ZIF_CMBC_FUNCTION~INTERACTION_COUNT .
  aliases GET_CURRENT_PACKAGE_ID
    for ZIF_CMBC_FUNCTION~GET_CURRENT_PACKAGE_ID .
  aliases WAIT
    for ZIF_CMBC_FUNCTION~WAIT .

  methods APPEND_RESPONSE_DATA
    redefinition .
  methods PROCESSING_RESPONSE_INTL_CORE
    redefinition .
private section.
ENDCLASS.



CLASS ZCL_BANK_CMBC_FUNCTION_ACBAL IMPLEMENTATION.


  METHOD append_response_data.


    DATA: ls_data TYPE ztrs_cmbc_qrybalnew_response,
          lo_data TYPE REF TO data.

    ASSIGN im_response_data_ref->* TO FIELD-SYMBOL(<fs_imported_data>).

    ls_data = <fs_imported_data>.

    LOOP AT ls_data-xdatabody-balinfo INTO DATA(ls_balinfo).
      IF get_bank_return_code_info(
                                  im_return_code = ls_balinfo-errcode
                                  im_request_status = space
                                  im_request_result = space )-rtntype
             = zcl_bank_enviroment=>bank_return_code_is_failed.
        DELETE ls_data-xdatabody-balinfo WHERE errcode = ls_balinfo-errcode.
      ENDIF.
    ENDLOOP.

    GET REFERENCE OF ls_data INTO lo_data .

    super->append_response_data( lo_data ).

  ENDMETHOD.


  METHOD processing_response_intl_core.
    processing_response_by_dbtable(
                im_data_db_table              = 'ZTRT_CMBC_ACBAL'
                im_detail_response_component  = 'XDATABODY-BALINFO'
                im_statuscode_componnet       = 'RESPONSEHEADER-CODE'
                im_statustext_component       = 'RESPONSEHEADER-MESSAGE'
                im_db_account_number_field    = 'ACNTNO'        "20200720 民生批量查询，需要确定对应的账号
                im_bank_entry_accnumber_field = 'ACNTNO'  ).

    wait( ).
  ENDMETHOD.


  method ZIF_CMBC_FUNCTION~GET_CURRENT_PACKAGE_ID.

  endmethod.


  method ZIF_CMBC_FUNCTION~WAIT.
    zcl_cmbc_enhancement=>wait(
                    CHANGING
                      ch_interaction_count = interaction_count ).
  endmethod.
ENDCLASS.
