class ZCL_BANK_API_DISPATCHER definition
  public
  final
  create public .

public section.

  class-methods DISPATCH_PAYMENTS
    importing
      !IM_T_ORDERS type ZTRS_PAYMENTORDER_LIST_TAB
    returning
      value(RT_ORDERS_BY_ACTION) type ZTRS_PAYMORDERS_BY_ACTION_TAB .
  class-methods DISPATCH_PAYMENT_ENTRIES
    importing
      !IM_T_ENTRIES type ZTRS_PAYMENTENTRY_LIST_TAB
    returning
      value(RT_ENTRIES_BY_ACTION) type ZTRS_PAYMENTRY_BY_ACTION_TAB .
protected section.
private section.

  class-methods CHECK_ORDER_STATUS
    importing
      !IM_T_ORDERS type ZTRS_PAYMENTORDER_LIST_TAB .
ENDCLASS.



CLASS ZCL_BANK_API_DISPATCHER IMPLEMENTATION.


METHOD check_order_status.
    DATA: lt_order_list TYPE ztrs_paymentorder_list_tab.

    lt_order_list = im_t_orders.
    SORT lt_order_list BY paymorder.
    DELETE ADJACENT DUPLICATES FROM lt_order_list COMPARING paymorder.

******  支付平台在调用银企直连的时候支付单状态有可能没完成更新数据库
******  会导致银企直连报错
******  这个子程序检查支付单的状态是否真正更新了
******  循环1000次，如果10000次循环都还没更新完数据库，只能让银企直连报错了
    DO 1000 TIMES.
      LOOP AT lt_order_list INTO DATA(ls_order).
        SELECT SINGLE zzfstatus INTO @DATA(l_status)
                FROM ztrt2001
                WHERE docno = @ls_order-paymorder.
        IF sy-subrc <> 0.
*          保证金
          SELECT SINGLE zzfstatus INTO l_status
                  FROM ztrt2101
                  WHERE docno = ls_order-paymorder.
        ENDIF.
        IF l_status = '24'.
          DELETE lt_order_list WHERE paymorder = ls_order-paymorder.
        ENDIF.
        clear l_status.
      ENDLOOP.
      IF lt_order_list IS INITIAL.
        EXIT.
      ELSE.
        WAIT UP TO 1 SECONDS.
      ENDIF.
    ENDDO.
  ENDMETHOD.


METHOD dispatch_payments.
    FIELD-SYMBOLS:<f_docno> TYPE ztrt2001-docno,
                  <f_bukrs> TYPE ztrt2001-bukrs.
    DATA: l_bzj_paymentorder TYPE flag.

    FIELD-SYMBOLS:<fs_order_by_action> TYPE ztrs_paymorders_by_action.
    LOOP AT im_t_orders INTO DATA(ls_order).
      SELECT SINGLE * INTO @DATA(ls_2001)
             FROM ztrt2001
             WHERE docno = @ls_order-paymorder.
      IF sy-subrc <> 0.
*        不是一般支付单就是保证金支付单
        SELECT SINGLE * INTO @DATA(ls_2101)
               FROM ztrt2101
               WHERE docno = @ls_order-paymorder.
        ASSIGN ls_2101-docno TO <f_docno>.
        ASSIGN ls_2101-bukrs TO <f_bukrs>.
        l_bzj_paymentorder = 'X'.
      ELSE.
        ASSIGN ls_2001-docno TO <f_docno>.
        ASSIGN ls_2001-bukrs TO <f_bukrs>.
      ENDIF.

      SELECT SINGLE * INTO @DATA(ls_2002)
            FROM ztrt2002
            WHERE docno = @ls_order-paymorder.

      SELECT SINGLE * INTO @DATA(ls_2003)
             FROM ztrt2003
             WHERE docno = @ls_order-paymorder.
      SELECT SINGLE * INTO @DATA(ls_0013)
            FROM ztrt0013
            WHERE bukrs = @ls_2001-bukrs
            AND   hbkid = @ls_2003-hbkid
            AND   hktid = @ls_2003-hktid.
      SELECT SINGLE * INTO @DATA(ls_2010)
      FROM ztrt2010
      WHERE docno = @ls_2001-docno.
      IF ls_2001-zzftype = 'P005' AND
          l_bzj_paymentorder = space."
*        汇票支付单
        SELECT docno AS paymorder,
               zxh AS draft_zxh
               INTO TABLE @DATA(lt_2009)
               FROM ztrt2009
               WHERE docno = @ls_order-paymorder.
        IF sy-subrc = 0.
          READ TABLE rt_orders_by_action ASSIGNING <fs_order_by_action>
              WITH KEY bank_ind = ls_0013-bank_ind
                       action = zif_bank_action=>action_is_create_edoc.
          IF sy-subrc <> 0.
            APPEND INITIAL LINE TO rt_orders_by_action ASSIGNING <fs_order_by_action>.
            <fs_order_by_action>-action = zif_bank_action=>action_is_create_edoc.
            <fs_order_by_action>-bank_ind = ls_0013-bank_ind.
          ENDIF.
          APPEND LINES OF lt_2009 TO <fs_order_by_action>-orders.
        ENDIF.
      ELSE.
*        非汇票支付单
        IF l_bzj_paymentorder = space.
          SELECT SINGLE * INTO @DATA(ls_lfa1)
                 FROM lfa1
                 WHERE lifnr = @ls_2001-zskno."如果是非保证金支付单，ls_2001为空值，那么也不存在员工为收款人的状况
          IF ls_lfa1-ktokk = 'S004' AND  "员工
             ( ls_0013-bank_ind = 'BOC' OR "目前只有中国银行有对私专用报文，其他银行不区分报文
            "20191716增加农行对私：农行账户付给农行个人账户
               ( ls_0013-bank_ind = 'ABC' AND ls_2002-zskbankl+0(3) = ls_2003-zfkbankl+0(3)  ) ).

            READ TABLE rt_orders_by_action ASSIGNING <fs_order_by_action>
                 WITH KEY bank_ind = ls_0013-bank_ind
                          action = zif_bank_action=>action_is_payment_to_private.
            IF sy-subrc <> 0.
              APPEND INITIAL LINE TO rt_orders_by_action ASSIGNING <fs_order_by_action>.
              <fs_order_by_action>-action = zif_bank_action=>action_is_payment_to_private.
              <fs_order_by_action>-bank_ind = ls_0013-bank_ind.
            ENDIF.
            APPEND ls_order TO <fs_order_by_action>-orders.
          ELSE.

            IF ls_2010 IS NOT INITIAL.
              IF ls_2001-zzftype = 'T007'.
                READ TABLE rt_orders_by_action ASSIGNING <fs_order_by_action> WITH KEY bank_ind = ls_0013-bank_ind action = zif_bank_action=>action_is_current_to_deposit.
                IF sy-subrc <> 0.
                  APPEND INITIAL LINE TO rt_orders_by_action ASSIGNING <fs_order_by_action>.
                  <fs_order_by_action>-action = zif_bank_action=>action_is_current_to_deposit.
                  <fs_order_by_action>-bank_ind = ls_0013-bank_ind.
                ENDIF.
                APPEND ls_order TO <fs_order_by_action>-orders.
              ELSEIF ls_2001-zzftype = 'T008'.
                READ TABLE rt_orders_by_action ASSIGNING <fs_order_by_action> WITH KEY bank_ind = ls_0013-bank_ind action = zif_bank_action=>action_is_deposit_to_current.
                IF sy-subrc <> 0.
                  APPEND INITIAL LINE TO rt_orders_by_action ASSIGNING <fs_order_by_action>.
                  <fs_order_by_action>-action = zif_bank_action=>action_is_deposit_to_current.
                  <fs_order_by_action>-bank_ind = ls_0013-bank_ind.
                ENDIF.
                APPEND ls_order TO <fs_order_by_action>-orders.
              ELSE.
                READ TABLE rt_orders_by_action ASSIGNING <fs_order_by_action> WITH KEY bank_ind = ls_0013-bank_ind action = zif_bank_action=>action_is_payment.
                IF sy-subrc <> 0.
                  APPEND INITIAL LINE TO rt_orders_by_action ASSIGNING <fs_order_by_action>.
                  <fs_order_by_action>-action = zif_bank_action=>action_is_payment.
                  <fs_order_by_action>-bank_ind = ls_0013-bank_ind.
                ENDIF.
                APPEND ls_order TO <fs_order_by_action>-orders.
              ENDIF.
            ELSE.
              READ TABLE rt_orders_by_action ASSIGNING <fs_order_by_action> WITH KEY bank_ind = ls_0013-bank_ind action = zif_bank_action=>action_is_payment.
              IF sy-subrc <> 0.
                APPEND INITIAL LINE TO rt_orders_by_action ASSIGNING <fs_order_by_action>.
                <fs_order_by_action>-action = zif_bank_action=>action_is_payment.
                <fs_order_by_action>-bank_ind = ls_0013-bank_ind.
              ENDIF.
              APPEND ls_order TO <fs_order_by_action>-orders.

            ENDIF.
          ENDIF.
        ELSE.
          READ TABLE rt_orders_by_action ASSIGNING <fs_order_by_action>
               WITH KEY bank_ind = ls_0013-bank_ind
                        action = zif_bank_action=>action_is_payment_bzj.
          IF sy-subrc <> 0.
            APPEND INITIAL LINE TO rt_orders_by_action ASSIGNING <fs_order_by_action>.
            <fs_order_by_action>-action = zif_bank_action=>action_is_payment_bzj.
            <fs_order_by_action>-bank_ind = ls_0013-bank_ind.
          ENDIF.
          APPEND ls_order TO <fs_order_by_action>-orders.
        ENDIF.
      ENDIF.

      CLEAR: ls_2001,
             ls_2101,
             ls_2002,
             ls_2003,
             ls_0013,
             ls_lfa1,
             lt_2009,
             l_bzj_paymentorder.
      UNASSIGN: <f_docno>,
                <f_bukrs>.
    ENDLOOP.

    check_order_status( im_t_orders ).
  ENDMETHOD.


METHOD dispatch_payment_entries.
    DATA: l_action TYPE ztr_app_action_for_bank.
    SELECT entuuid,
           bank_ind,
           zzftype,
           bank_func,
           bank_rtncode,
           bank_reqsts
           INTO TABLE @DATA(lt_entries)
           FROM ztrt_payment
           FOR ALL ENTRIES IN @im_t_entries " initial table is possible
           WHERE entuuid = @im_t_entries-entuuid.

    LOOP AT lt_entries INTO DATA(ls_entry).
      CASE ls_entry-zzftype.
        WHEN 'P005'.
*          汇票支付单
          l_action = zif_bank_action=>action_is_check_m01_status.
        WHEN 'P004'.
*          保证金支付单
          l_action = zif_bank_action=>action_is_check_payments_bzj.
        WHEN OTHERS.
          IF ( ls_entry-bank_rtncode = '0000' OR ls_entry-bank_rtncode = '0001' ) AND
                ls_entry-bank_reqsts = '1' AND ls_entry-bank_ind = 'ABC'.
*          落地支付状态
            l_action = zif_bank_action=>action_is_check_loc_status.
          ELSE.
*          普通支付单(含对私和对公)
            l_action = zif_bank_action=>action_is_check_payments.
          ENDIF.
      ENDCASE.

      READ TABLE rt_entries_by_action ASSIGNING FIELD-SYMBOL(<fs_entries_by_action>)
               WITH KEY action = l_action
                        bank_ind = ls_entry-bank_ind.
      IF sy-subrc <> 0.
        APPEND INITIAL LINE TO rt_entries_by_action ASSIGNING <fs_entries_by_action>.
        <fs_entries_by_action>-action = l_action.
        <fs_entries_by_action>-bank_ind = ls_entry-bank_ind.
      ENDIF.

      READ TABLE im_t_entries INTO DATA(ls_imported_entry)
           WITH KEY entuuid = ls_entry-entuuid.
      IF sy-subrc = 0.
        APPEND ls_imported_entry TO <fs_entries_by_action>-entries.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.
ENDCLASS.
