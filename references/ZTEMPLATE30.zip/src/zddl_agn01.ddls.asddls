@AbapCatalog.sqlViewName: 'ZTRCDSAGN01'
@AbapCatalog.compiler.compareFilter: true
@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'ztrv_amt_agn-1'
define view ZDDL_AGN01 as select from ztrv_amt_agn{
  mandt  ,
  bguid  , 
  witemn , 
  wrbtr_agn , 
  waers 
} where dflag = ''  
  
 