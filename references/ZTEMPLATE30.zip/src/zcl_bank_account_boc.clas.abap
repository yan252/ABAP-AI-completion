class ZCL_BANK_ACCOUNT_BOC definition
  public
  inheriting from ZCL_ABSTRACT_BANK_ACCOUNT
  final
  create public .

public section.
protected section.

  methods BANK_BALANCE_TO_SAP
    redefinition .
  methods BANK_TRANSACTIONS_TO_SAP
    redefinition .
  methods DEQUEUE_TRANSACTION
    redefinition .
  methods SET_ACCOUNT_BALANCE_CORE
    redefinition .
  methods SET_ACCOUNT_TABNAME
    redefinition .
  methods SET_HISTORY_ACC_BAL_CORE
    redefinition .
  methods SET_TRANSACTIONS_CORE
    redefinition .
  methods BANK_HISTORY_BALANCE_TO_SAP
    redefinition .
private section.
ENDCLASS.



CLASS ZCL_BANK_ACCOUNT_BOC IMPLEMENTATION.


METHOD bank_balance_to_sap.
    FIELD-SYMBOLS: <ft_new_account_balance> TYPE STANDARD TABLE.
    DATA: ls_balance_ext TYPE ztrt_boc_acbal.

    ASSIGN new_account_balance->* TO <ft_new_account_balance>.
    IF <ft_new_account_balance> IS NOT ASSIGNED OR
       <ft_new_account_balance> IS INITIAL.
      RETURN.
    ENDIF.

    LOOP AT <ft_new_account_balance> INTO ls_balance_ext.
      APPEND VALUE #(
                       bukrs        = ls_balance_ext-sap_bukrs
                       hbkid        = ls_balance_ext-sap_hbkid
                       hktid        = ls_balance_ext-sap_hktid
                       yhzh         = ls_balance_ext-actacn
                       bank_ind     = bank_indicator
                       zyue_ttl     = ls_balance_ext-bokbal
                       zyue_frz     = ls_balance_ext-stpamt
                       zyue         = ls_balance_ext-avabal
                       waers        = GET_ACCOUNT_CURRENCY( ls_balance_ext-sap_fields )
                       ) TO rt_balance.

    ENDLOOP.
  ENDMETHOD.


method BANK_HISTORY_BALANCE_TO_SAP.
    FIELD-SYMBOLS: <ft_new_account_balance> TYPE STANDARD TABLE.
    DATA: ls_balance_ext TYPE ztrt_boc_hacbal.

    ASSIGN NEW_HISTORY_ACCOUNT_BALANCE->* TO <ft_new_account_balance>.
    IF <ft_new_account_balance> IS NOT ASSIGNED OR
       <ft_new_account_balance> IS INITIAL.
      RETURN.
    ENDIF.

    LOOP AT <ft_new_account_balance> INTO ls_balance_ext.
      APPEND VALUE #(
                       bukrs        = ls_balance_ext-sap_bukrs
                       hbkid        = ls_balance_ext-sap_hbkid
                       hktid        = ls_balance_ext-sap_hktid
*                    中国银行的接口文档提示历史余额的BALDAT长度为10
*                    但实际情况返回的日期是YYYYMMDD格式
                       zdate        = conv #( ls_balance_ext-baldat )
*                       zdate        = ls_balance_ext-baldat+0(4) &&
*                                      ls_balance_ext-baldat+5(2) &&
*                                      ls_balance_ext-baldat+8(2)
                       yhzh         = ls_balance_ext-actacn
                       bank_ind     = bank_indicator
                       zyue_ttl     = ls_balance_ext-bokbal
                       waers        = GET_ACCOUNT_CURRENCY( ls_balance_ext-sap_fields )
                       ) TO rt_balance.

    ENDLOOP.
  endmethod.


METHOD BANK_TRANSACTIONS_TO_SAP.
    FIELD-SYMBOLS: <FT_NEW_TRANSACTIONS> TYPE STANDARD TABLE.
    DATA: LS_TRANSACTIONS_EXT TYPE ZTRT_BOC_TRNS.
    DATA: BEGIN OF LS_ACCOUNT,
            BZBNKA TYPE ZTRT_BANK_TRANS-BZBNKA,
            BZBNKN TYPE ZTRT_BANK_TRANS-BZBNKN,
            BKOINH TYPE ZTRT_BANK_TRANS-BKOINH,
          END OF LS_ACCOUNT.


    ASSIGN NEW_TRANSACTIONS->* TO <FT_NEW_TRANSACTIONS>.
    IF <FT_NEW_TRANSACTIONS> IS NOT ASSIGNED OR
       <FT_NEW_TRANSACTIONS> IS INITIAL.
      RETURN.
    ENDIF.



    LOOP AT <FT_NEW_TRANSACTIONS> INTO LS_TRANSACTIONS_EXT.
*2019.04.18
*修改系统BUG，中行银企直联的银行交易流水读取时未考虑银行记账错误冲正的情况，从表ZTRT_BOC_TRNS向表ZTRT_BANK_TRANS转入数据时，
*增加判断逻辑：根据表ZTRT_BOC_TRNS中来往账标识DIRECTION及业务类型TRANSTYPE做判断，
*业务类型为11,转入表ZTRT_BANK_TRANS借方/贷方标识SHKZG作相反方向处理。
      IF LS_TRANSACTIONS_EXT-TRANSTYPE = '11'.

        IF  LS_TRANSACTIONS_EXT-DIRECTION = '1'.
          LS_TRANSACTIONS_EXT-DIRECTION = '2'.

        ELSEIF  LS_TRANSACTIONS_EXT-DIRECTION = '2'.
          LS_TRANSACTIONS_EXT-DIRECTION = '1'.

        ENDIF.

      ENDIF.

      DATA(L_SHKZG) = ZCL_BOC_ENHANCEMENT=>CONVERT_DEBIT_AND_CREDIT_FLAG( LS_TRANSACTIONS_EXT-DIRECTION ).
      DATA(LS_PAYMENTKEY) = GET_PAYMKEY_FROM_TRANSACTION(
                                         IM_RAW_TEXT = ZCL_BOC_ENHANCEMENT=>GET_INTERINFO_PARTIALLY(
                                                                           IM_INTERINFO_CODE = 'U'
                                                                           IM_INTERINFO_TEXT = LS_TRANSACTIONS_EXT-INTERINFO )
                                         IM_PATTERN = ZCL_BANK_PAYMENT_ENTRY=>TRANX_REFERENCE_PREFIX_BOC ).
      CASE L_SHKZG.
        WHEN 'H'.
*          往账
          LS_ACCOUNT-BZBNKA = LS_TRANSACTIONS_EXT-TOBANK.
          LS_ACCOUNT-BZBNKN = LS_TRANSACTIONS_EXT-ACTACN_R.
          LS_ACCOUNT-BKOINH = LS_TRANSACTIONS_EXT-TONAME.
        WHEN 'S'.
*          来账
          LS_ACCOUNT-BZBNKA = LS_TRANSACTIONS_EXT-IBKNAME_P.
          LS_ACCOUNT-BZBNKN = LS_TRANSACTIONS_EXT-ACTACN_P.
          LS_ACCOUNT-BKOINH = LS_TRANSACTIONS_EXT-ACNTNAME_P.
      ENDCASE.

*-----Begin 对方名称中的全角和半角括号去除后存入字段BKOINH1中 金志强 Add by KLTDEV5 20190726
      "字符串转换
      DATA:LV_BKOINH TYPE STRING.
      LV_BKOINH = LS_ACCOUNT-BKOINH.
      LV_BKOINH = CONVERT_STRING( EXPORTING STRING = LV_BKOINH CHAR = '(' ).
      LV_BKOINH = CONVERT_STRING( EXPORTING STRING = LV_BKOINH CHAR = ')' ).
      LV_BKOINH = CONVERT_STRING( EXPORTING STRING = LV_BKOINH CHAR = '（' ).
      LV_BKOINH = CONVERT_STRING( EXPORTING STRING = LV_BKOINH CHAR = '）' ).
*-----End 对方名称中的全角和半角括号去除后存入字段BKOINH1中 金志强 Add by KLTDEV5 20190726

      APPEND VALUE #(
                       BUKRS        = LS_TRANSACTIONS_EXT-SAP_BUKRS
                       HBKID        = LS_TRANSACTIONS_EXT-SAP_HBKID
                       HKTID        = LS_TRANSACTIONS_EXT-SAP_HKTID
                       YHZH         = LS_TRANSACTIONS_EXT-ACTACN
                       TRXNO        = LS_TRANSACTIONS_EXT-TRANSID
                       BANK_IND     = BANK_INDICATOR
                       TRXDATE      = LS_TRANSACTIONS_EXT-TXNDATE
                       TRXTIME      = LS_TRANSACTIONS_EXT-TXNTIME
                       SHKZG        = L_SHKZG
                       BKFSE       = CONV ZTR_BANK_TRXAMT( LS_TRANSACTIONS_EXT-TXNAMT )
                       TRXAMT        = CONVERT_TRANSAMT_BY_SHKZG( IM_SHKZG = L_SHKZG
                                                                 IM_ORIGINAL_AMT = LS_TRANSACTIONS_EXT-TXNAMT )

                       BALAMT       = CONV ZTR_BANK_BALAMT( LS_TRANSACTIONS_EXT-ACCTBAL )
                       WAERS        = LS_TRANSACTIONS_EXT-SAP_WAERS
*                           对方开户行名称
                       BZBNKA       = LS_ACCOUNT-BZBNKA
*                           对方帐号
                       BZBNKN       = LS_ACCOUNT-BZBNKN
*                           对方账户名
                       BKOINH       = LS_ACCOUNT-BKOINH
*                           附言
                       POSTSCRIPT_TXT = ZCL_BOC_ENHANCEMENT=>GET_INTERINFO_PARTIALLY(
                                                                    IM_INTERINFO_CODE = 'F'
                                                                    IM_INTERINFO_TEXT = LS_TRANSACTIONS_EXT-INTERINFO )
*                           用途
                       USAGE_TXT      = ZCL_BOC_ENHANCEMENT=>GET_INTERINFO_PARTIALLY(
                                                                    IM_INTERINFO_CODE = 'U'
                                                                    IM_INTERINFO_TEXT = LS_TRANSACTIONS_EXT-INTERINFO )
*                           摘要
                       ABSTRACT_TXT = ZCL_BOC_ENHANCEMENT=>GET_INTERINFO_PARTIALLY(
                                                                    IM_INTERINFO_CODE = 'A'
                                                                    IM_INTERINFO_TEXT = LS_TRANSACTIONS_EXT-INTERINFO )
*                           备注
                       COMMENT_TXT  = ZCL_BOC_ENHANCEMENT=>GET_INTERINFO_PARTIALLY(
                                                                    IM_INTERINFO_CODE = 'R'
                                                                    IM_INTERINFO_TEXT = LS_TRANSACTIONS_EXT-INTERINFO )
                       PAYMENTKEY  = LS_PAYMENTKEY
                       ZREF_DOC = LS_PAYMENTKEY-PAYMORDER
                       INTFDATE     = SYSTEM_INFO-DATUM
                       INTFTIME     = SYSTEM_INFO-UZEIT
*                       kunnr2       = set_customer_code_by_name( ls_account-bkoinh )
*                       lifnr        = set_vendor_code_by_name( ls_account-bkoinh )
                       PARTNER = SET_PARTNER_BY_NAME( LS_ACCOUNT-BKOINH )
                       BKOINH1 = LV_BKOINH
                       ) TO RT_TRANSACTIONS.

    ENDLOOP.

    FINISHED_SAP_TRANX_FIELDS(
               CHANGING
                 CH_T_TRANX = RT_TRANSACTIONS ).
  ENDMETHOD.


method DEQUEUE_TRANSACTION.
    DATA:ls_transaction TYPE ztrt_boc_trns.

    LOOP AT im_t_transactions INTO ls_transaction.
      dequeue_transaction_core(
                     im_bukrs = ls_transaction-sap_bukrs
                     im_hbkid = ls_transaction-sap_hbkid
                     im_hktid = ls_transaction-sap_hktid
                     im_yhzh = ls_transaction-actacn
                     im_trxno = ls_transaction-transid ).
    ENDLOOP.
  endmethod.


METHOD set_account_balance_core.
    FIELD-SYMBOLS: <ft_acc_balance> TYPE ztrt_boc_acbal_tab.
    FIELD-SYMBOLS:<ft_new_entries> TYPE ztrt_boc_acbal_tab.
    DATA: l_new     TYPE flag,
          l_changed TYPE flag.

    ASSIGN im_data->* TO <ft_acc_balance>.

    ASSIGN new_account_balance->* TO <ft_new_entries>.

    IF <ft_acc_balance> IS INITIAL.
      RETURN.
    ENDIF.

    SELECT * INTO TABLE @DATA(lt_old_data)
           FROM ztrt_boc_acbal
           FOR ALL ENTRIES IN @<ft_acc_balance>
           WHERE actacn = @<ft_acc_balance>-actacn.

    LOOP AT <ft_acc_balance> INTO DATA(ls_acc_balance).
      CHECK filter_accbal_by_shifton_date(
                  EXPORTING
                    im_s_sap_field = ls_acc_balance-sap_fields  ) = 'X'.

      READ TABLE lt_old_data INTO DATA(ls_old_data)
           WITH KEY actacn = ls_acc_balance-actacn.
      IF sy-subrc <> 0.
*      new
        l_new = 'X'.
      ELSE.
        IF ls_acc_balance-acc_field <> ls_old_data-acc_field.
          l_changed = 'X'.
        ENDIF.
      ENDIF.

      IF l_new = 'X' OR
         l_changed = 'X'.
        ls_acc_balance-dbadmin = ls_old_data-dbadmin.
        set_admin_fields(
                  EXPORTING
                    im_new_entry = l_new
                  CHANGING
                    cs_admin = ls_acc_balance-dbadmin ).
        APPEND ls_acc_balance TO <ft_new_entries>.
      ENDIF.

      CLEAR: l_new,
             l_changed.
    ENDLOOP.

  ENDMETHOD.


METHOD SET_ACCOUNT_TABNAME.
    transaction_db_tabname = 'ZTRT_BOC_TRNS'.
    account_balance_db_tabname = 'ZTRT_BOC_ACBAL'.
    history_acc_balance_db_name = 'ZTRT_BOC_HACBAL'.
    super->SET_ACCOUNT_TABNAME( ).
  ENDMETHOD.


method SET_HISTORY_ACC_BAL_CORE.
   FIELD-SYMBOLS: <ft_acc_balance> TYPE ztrt_boc_hacbal_tab.
    FIELD-SYMBOLS:<ft_new_entries> TYPE ztrt_boc_hacbal_tab.
    DATA: l_new     TYPE flag,
          l_changed TYPE flag.

    ASSIGN im_data->* TO <ft_acc_balance>.

    ASSIGN NEW_HISTORY_ACCOUNT_BALANCE->* TO <ft_new_entries>.

    IF <ft_acc_balance> IS INITIAL.
      RETURN.
    ENDIF.

    SELECT * INTO TABLE @DATA(lt_old_data)
           FROM ztrt_boc_hacbal
           FOR ALL ENTRIES IN @<ft_acc_balance>
           WHERE actacn = @<ft_acc_balance>-actacn
           and   baldat = @<ft_acc_balance>-baldat.

    LOOP AT <ft_acc_balance> INTO DATA(ls_acc_balance).
      CHECK filter_accbal_by_shifton_date(
                  EXPORTING
                    im_s_sap_field = ls_acc_balance-sap_fields
*                    中国银行的接口文档提示历史余额的BALDAT长度为10
*                    但实际情况返回的日期是YYYYMMDD格式
                    im_date =  conv #( ls_acc_balance-baldat ) ) = 'X'.
*                    im_date = ls_acc_balance-baldat+0(4) &&
*                              ls_acc_balance-baldat+5(2) &&
*                              ls_acc_balance-baldat+8(2)  ) = 'X'.

      READ TABLE lt_old_data INTO DATA(ls_old_data)
           WITH KEY actacn = ls_acc_balance-actacn
                    baldat = ls_acc_balance-baldat.
      IF sy-subrc <> 0.
*      new
        l_new = 'X'.
      ELSE.
        IF ls_acc_balance-acc_field <> ls_old_data-acc_field.
          l_changed = 'X'.
        ENDIF.
      ENDIF.

      IF l_new = 'X' OR
         l_changed = 'X'.
        ls_acc_balance-dbadmin = ls_old_data-dbadmin.
        set_admin_fields(
                  EXPORTING
                    im_new_entry = l_new
                  CHANGING
                    cs_admin = ls_acc_balance-dbadmin ).
        APPEND ls_acc_balance TO <ft_new_entries>.
      ENDIF.

      CLEAR: l_new,
             l_changed.
    ENDLOOP.
  endmethod.


METHOD set_transactions_core.
    FIELD-SYMBOLS: <ft_transactions> TYPE ztrt_boc_trns_tab.
    FIELD-SYMBOLS: <ft_new_entries> TYPE ztrt_boc_trns_tab.
    DATA: l_new     TYPE flag,
          l_changed TYPE flag.

    ASSIGN im_data->* TO <ft_transactions>.

    ASSIGN new_transactions->* TO <ft_new_entries>.

    IF <ft_transactions> IS NOT ASSIGNED OR
       <ft_transactions> IS INITIAL.
      RETURN.
    ENDIF.

    SELECT * INTO TABLE @DATA(lt_old_data)
           FROM ztrt_boc_trns
           FOR ALL ENTRIES IN @<ft_transactions>
           WHERE actacn = @<ft_transactions>-actacn
           AND   transid = @<ft_transactions>-transid.

    LOOP AT <ft_transactions> INTO DATA(ls_transactions).
      CHECK filter_trans_by_shifton_date(
                  EXPORTING
                    im_s_sap_field = ls_transactions-sap_fields
                    im_transaction_date = CONV #( ls_transactions-txndate ) ) = 'X'.

      enqueue_transaction_core(
                   EXPORTING
                     im_bukrs = ls_transactions-sap_bukrs
                     im_hbkid = ls_transactions-sap_hbkid
                     im_hktid = ls_transactions-sap_hktid
                     im_yhzh = ls_transactions-actacn
                     im_trxno = ls_transactions-transid
                   IMPORTING
                     ex_enqueue_failed = DATA(l_enqueue_failed) ).
      IF l_enqueue_failed = yes.
*        被锁定，不纳入本次处理
        CLEAR l_enqueue_failed.
        CONTINUE.
      ENDIF.

      READ TABLE lt_old_data INTO DATA(ls_old_data)
           WITH KEY actacn = ls_transactions-actacn
                    transid = ls_transactions-transid.
      IF sy-subrc <> 0.
*      new
        l_new = 'X'.
      ELSE.
        IF ls_transactions-trns_field <> ls_old_data-trns_field.
          l_changed = 'X'.
        ENDIF.
      ENDIF.

      IF l_new = 'X' OR
         l_changed = 'X'.
        ls_transactions-dbadmin = ls_old_data-dbadmin.
        set_admin_fields(
                  EXPORTING
                    im_new_entry = l_new
                  CHANGING
                    cs_admin = ls_transactions-dbadmin ).
        APPEND ls_transactions TO <ft_new_entries>.
      ELSE.
        dequeue_transaction_core(
                     EXPORTING
                       im_bukrs = ls_transactions-sap_bukrs
                       im_hbkid = ls_transactions-sap_hbkid
                       im_hktid = ls_transactions-sap_hktid
                       im_yhzh = ls_transactions-actacn
                       im_trxno = ls_transactions-transid ).
      ENDIF.

      CLEAR: l_new,
             l_changed,
             ls_old_data.
    ENDLOOP.

  ENDMETHOD.
ENDCLASS.
