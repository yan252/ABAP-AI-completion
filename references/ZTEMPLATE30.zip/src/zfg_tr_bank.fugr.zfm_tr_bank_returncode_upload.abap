FUNCTION ZFM_TR_BANK_RETURNCODE_UPLOAD.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     REFERENCE(IM_BY_BANK_FUNC) TYPE  FLAG OPTIONAL
*"--------------------------------------------------------------------
DATA: lv_file_path TYPE rlgrap-filename.
  DATA: lta_excel_table TYPE issr_alsmex_tabline.
  DATA: lst_excel_data TYPE alsmex_tabline.
  DATA: lt_header TYPE issr_alsmex_tabline.
  DATA: lt_bank_code   TYPE TABLE OF ztrt_bank_rtncod,
        ls_bank_code   TYPE  ztrt_bank_rtncod,
        lt_bank_code_t TYPE TABLE OF ztrt_bank_rtncot,
        ls_bank_code_t TYPE ztrt_bank_rtncot,
        lt_func_code   TYPE TABLE OF ztrt_bfun_rtncod,
        ls_func_code   TYPE ztrt_bfun_rtncod.
  DATA: BEGIN OF ls_code,
          bank_ind     TYPE ztr_bank_indicator,
          bank_func    TYPE ztr_bank_function,
          bank_rtncode TYPE ztr_bank_rtncode,
          bank_reqsts  TYPE ztr_bank_request_status,
          bank_rtnflg  TYPE ztr_bank_request_result,
          rtntype      TYPE ztr_bank_rtncode_type,
          entstatus    TYPE ztr_entstatus,
          bank_rtnmsg  TYPE ztr_bank_rtnmsg,
          frontend_rtn TYPE ztr_bank_frontend_return,
          ltext        TYPE ztr_bank_rtncode_ltext,
        END OF ls_code.
*  DATA lt_code LIKE TABLE OF ls_code.
  FIELD-SYMBOLS: <f_field> TYPE any.


  PERFORM frm_get_upload_file
              CHANGING
                 lv_file_path.

  CALL FUNCTION 'ALSM_EXCEL_TO_INTERNAL_TABLE'
    EXPORTING
      filename                = lv_file_path
      i_begin_col             = 1
      i_begin_row             = 1
      i_end_col               = 10
      i_end_row               = 65536
    TABLES
      intern                  = lta_excel_table
    EXCEPTIONS
      inconsistent_parameters = 1
      upload_ole              = 2.
  IF sy-subrc NE 0.
*  should not happen,
*  or excel application in user frontend is 2003 but the template is 2007 or above
    MESSAGE e096(ztr_bank_application).
  ENDIF.
  lt_header = lta_excel_table.
  DELETE lt_header WHERE row <> 1.
  SORT lt_header BY row col.

  DELETE lta_excel_table WHERE row = 1.
  SORT lta_excel_table BY row col.

  LOOP AT lta_excel_table INTO lst_excel_data.
    READ TABLE lt_header INTO DATA(ls_header)
         WITH KEY col = lst_excel_data-col.
    CHECK sy-subrc = 0.

    ASSIGN COMPONENT ls_header-value OF STRUCTURE ls_code TO <f_field>.
    IF sy-subrc = 0.
      <f_field> = lst_excel_data-value.
    ENDIF.

    AT END OF row.
      IF im_by_bank_func = 'X'.
        MOVE-CORRESPONDING ls_code TO ls_func_code.
        APPEND ls_func_code TO lt_func_code.
      ELSE.
        MOVE-CORRESPONDING ls_code TO ls_bank_code.
        APPEND ls_bank_code TO lt_bank_code.
        MOVE-CORRESPONDING ls_code TO ls_bank_code_t.
        APPEND ls_bank_code_t TO lt_bank_code_t.
      ENDIF.
      CLEAR: ls_code,
             ls_func_code,
             ls_bank_code,
             ls_bank_code_t.

    ENDAT.
  ENDLOOP.

  IF lt_func_code IS NOT INITIAL.
    MODIFY ztrt_bfun_rtncod FROM TABLE lt_func_code.
  ENDIF.

  IF lt_bank_code IS NOT INITIAL.
    MODIFY ztrt_bank_rtncod FROM TABLE lt_bank_code.
  ENDIF.

  IF lt_bank_code_t IS NOT INITIAL.
    MODIFY ztrt_bank_rtncot FROM TABLE lt_bank_code_t.
  ENDIF.





ENDFUNCTION.
