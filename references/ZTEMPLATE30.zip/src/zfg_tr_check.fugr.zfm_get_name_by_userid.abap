FUNCTION ZFM_GET_NAME_BY_USERID.
**"--------------------------------------------------------------------
**"*"局部接口：
**"  IMPORTING
**"     REFERENCE(UNAME) TYPE  SY-UNAME DEFAULT SY-UNAME
**"  EXPORTING
**"     REFERENCE(NAME) TYPE  ZE_USERNAME
**"--------------------------------------------------------------------
*name = uname.
*
*



ENDFUNCTION.
