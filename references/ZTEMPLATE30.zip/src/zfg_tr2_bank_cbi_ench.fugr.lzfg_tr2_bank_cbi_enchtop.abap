FUNCTION-POOL zfg_tr2_bank_cbi_ench.        "MESSAGE-ID ..

* INCLUDE LZFG_TR2_BANK_CBI_ENCHD...         " Local class definition


DATA:go_action TYPE REF TO zcl_cbi_dlcbitrn_enhancement.
DATA:gv_docno TYPE ztrt2001-docno.
