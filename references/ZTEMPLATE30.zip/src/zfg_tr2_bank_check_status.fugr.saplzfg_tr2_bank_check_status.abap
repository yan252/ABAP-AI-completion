*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_TR2_BANK_CHECK_STATUSTOP.     " Global Declarations
  INCLUDE LZFG_TR2_BANK_CHECK_STATUSUXX.     " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_TR2_BANK_CHECK_STATUSF...     " Subroutines
* INCLUDE LZFG_TR2_BANK_CHECK_STATUSO...     " PBO-Modules
* INCLUDE LZFG_TR2_BANK_CHECK_STATUSI...     " PAI-Modules
* INCLUDE LZFG_TR2_BANK_CHECK_STATUSE...     " Events
* INCLUDE LZFG_TR2_BANK_CHECK_STATUSP...     " Local class implement.
* INCLUDE LZFG_TR2_BANK_CHECK_STATUST99.     " ABAP Unit tests
