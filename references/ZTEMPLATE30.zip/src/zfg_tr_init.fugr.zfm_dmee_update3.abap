FUNCTION ZFM_DMEE_UPDATE3.
*"----------------------------------------------------------------------
*"*"本地接口：
*"  IMPORTING
*"     VALUE(CTU) LIKE  APQI-PUTACTIVE DEFAULT 'X'
*"     VALUE(MODE) LIKE  APQI-PUTACTIVE DEFAULT 'N'
*"     VALUE(UPDATE) LIKE  APQI-PUTACTIVE DEFAULT 'L'
*"     VALUE(GROUP) LIKE  APQI-GROUPID OPTIONAL
*"     VALUE(USER) LIKE  APQI-USERID OPTIONAL
*"     VALUE(KEEP) LIKE  APQI-QERASE OPTIONAL
*"     VALUE(HOLDDATE) LIKE  APQI-STARTDATE OPTIONAL
*"     VALUE(NODATA) LIKE  APQI-PUTACTIVE DEFAULT '/'
*"     VALUE(G_LOCATION_003) LIKE  BDCDATA-FVAL DEFAULT 'P'
*"     VALUE(G_XMLFILENAME_004) LIKE  BDCDATA-FVAL DEFAULT
*"       'D:\DMEE\PAYM\ZBANK_'
*"  EXPORTING
*"     VALUE(SUBRC) LIKE  SYST-SUBRC
*"  TABLES
*"      MESSTAB STRUCTURE  BDCMSGCOLL OPTIONAL
*"----------------------------------------------------------------------

subrc = 0.

perform bdc_nodata      using NODATA.

perform open_group      using GROUP USER KEEP HOLDDATE CTU.

perform bdc_dynpro      using 'SAPMDMEE_ABA' '0200'.
perform bdc_field       using 'BDC_CURSOR'
                              'DMEE_HEAD_ABA-TREE_TYPE'.
perform bdc_field       using 'BDC_OKCODE'
                              '=UPLOAD'.
perform bdc_dynpro      using 'SAPLDMEE1_ABA' '0240'.
perform bdc_field       using 'BDC_CURSOR'
                              'G_XMLFILENAME'.
perform bdc_field       using 'BDC_OKCODE'
                              '=ENTER'.
perform bdc_field       using 'G_LOCATION'
                              G_LOCATION_003.
perform bdc_field       using 'G_XMLFILENAME'
                              G_XMLFILENAME_004.
perform bdc_dynpro      using 'SAPLDMEE1_ABA' '0100'.
perform bdc_field       using 'BDC_OKCODE'
                              '=ACTIVATE'.
perform bdc_field       using 'BDC_CURSOR'
                              'DMEE_T_ABA-TEXT'.
perform bdc_dynpro      using 'SAPLSTRD' '0300'.
perform bdc_field       using 'BDC_CURSOR'
                              'KO008-TRKORR'.
perform bdc_field       using 'BDC_OKCODE'
                              '=LOCK'.
perform bdc_dynpro      using 'SAPMDMEE_ABA' '0200'.
perform bdc_field       using 'BDC_CURSOR'
                              'DMEE_HEAD_ABA-TREE_TYPE'.
perform bdc_field       using 'BDC_OKCODE'
                              '=BACK'.
perform bdc_transaction tables messtab
using                         'DMEE'
                              CTU
                              MODE
                              UPDATE.
if sy-subrc <> 0.
  subrc = sy-subrc.
  exit.
endif.

perform close_group using     CTU.





ENDFUNCTION.
