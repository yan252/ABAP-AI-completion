*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_TR_BANKTOP.                    " Global Declarations
  INCLUDE LZFG_TR_BANKUXX.                    " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_TR_ANKF...                    " Subroutines
* INCLUDE LZFG_TR_ANKO...                    " PBO-Modules
* INCLUDE LZFG_TR_ANKI...                    " PAI-Modules
* INCLUDE LZFG_TR_ANKE...                    " Events
* INCLUDE LZFG_TR_ANKP...                    " Local class implement.
* INCLUDE LZFG_TR_ANKT99.                    " ABAP Unit tests
INCLUDE lzfg_tr_bankf01.
