class ZCL_BANK_LOGGER_PROTOCAL definition
  public
  final
  create public .

public section.

  class-methods ADD_LOG
    importing
      !IM_S_FIELDS type ZTRS_BANK_LOG_PROTOCAL_FIELDS .
  class-methods ADD_MESSAGE_COLLECTOR
    importing
      !IM_UUID type SYSUUID_C22 optional
      !IM_MAINPROGRAM type SYREPID default SY-REPID
      !IM_DEFAULT_MESSAGE_CLASS type SYMSGID optional
    returning
      value(RO_INSTANCE) type ref to ZCL_MESSAGE_COLLECTOR .
  class-methods SET_API_STARTING_LOG
    importing
      !IM_ACTION type ZTR_APP_ACTION_FOR_BANK
      !IM_UUID type SYSUUID_C22 optional .
  class-methods SAVE_LOG .
  class-methods RECEIVE_PAYMENT_ENTRY_IN_API
    importing
      !IM_ACTION type ZTR_APP_ACTION_FOR_BANK
      !IM_T_ENTRY_LIST type ZTRS_PAYMENTENTRY_LIST_TAB
    returning
      value(RE_HAS_RECORD) type FLAG .
  class-methods RECEIVE_PAYMORDER_IN_API
    importing
      !IM_ACTION type ZTR_APP_ACTION_FOR_BANK
      !IM_T_ORDER_LIST type ZTRS_PAYMENTORDER_LIST_TAB
    returning
      value(RE_HAS_RECORD) type FLAG .
  class-methods RECEIVE_BANK_ACCOUNT_IN_API
    importing
      !IM_ACTION type ZTR_APP_ACTION_FOR_BANK
      !IM_T_ACCOUNT_LIST type ZTRS_BANK_ACCOUNT_TAB
    returning
      value(RE_HAS_RECORD) type FLAG .
  class-methods DESTROY .
  class-methods IMPORT_MESSAGES
    importing
      !IM_T_MESSAGES type ZTAB_BAPIRET2
      !IM_S_LOG_BUSINESSDATA_DATA type ZTRS_BANK_LOG_BUSINESSDATA
      !IM_UUID type SYSUUID_C22 optional .
  class-methods LOG_FILE
    importing
      !IM_FILE_UUID type ZTR_FILE_UUID
      !IM_BANK_INDICATOR type ZTR_BANK_INDICATOR
      !IM_ACTION type ZTR_APP_ACTION_FOR_BANK
      !IM_STEP type ZTR_APP_ACTION_STEP
      !IM_FUNCTION type ZTR_BANK_FUNCTION
      !IM_CFILE type ref to DATA
      !IM_XFILE type ref to DATA
      !IM_FILE_DIRECTION type ZTR_FILE_DIRECTION .
  class-methods GET_MESSAGE_COLLECTOR
    importing
      !IM_UUID type SYSUUID_C22
    returning
      value(RO_MESSAGE_COLLECTOR) type ref to ZCL_MESSAGE_COLLECTOR .
  class-methods END_LOGS
    importing
      !IM_ACTION type ZTR_APP_ACTION_FOR_BANK
      !IM_DESTROY type FLAG default 'X' .
  class-methods CREATE_LOGGER .
protected section.
private section.

  class-data LOGGER type ref to ZCL_BANK_APPLICATION_LOGGER .
  class-data DUMMY_MESSAGE type STRING .
  class-data DEFAULT_MESSAGE_CLASS type SYMSGID value 'ZTR_BANK_APPLICATION' ##NO_TEXT.
ENDCLASS.



CLASS ZCL_BANK_LOGGER_PROTOCAL IMPLEMENTATION.


METHOD add_log.
    IF logger IS BOUND.
      logger->add_log( im_s_fields ).
    ENDIF.
  ENDMETHOD.


METHOD add_message_collector.
    CHECK logger IS BOUND.
    ro_instance = logger->add_message_collector(
                    EXPORTING
                      im_uuid                  = im_uuid
                      im_mainprogram           = im_mainprogram
                      im_default_message_class = im_default_message_class ).
  ENDMETHOD.


METHOD create_logger.
*   CHECK logger IS NOT BOUND.
    logger = NEW #( ).
  ENDMETHOD.


METHOD destroy.
    FREE logger.
    CLEAR: dummy_message,
           default_message_class.
  ENDMETHOD.


METHOD end_logs.
    MESSAGE i202(ztr_bank_application)
            WITH im_action
                 zcl_bank_enviroment=>s_get_bank_action_text( im_action )
            INTO dummy_message.
    add_log( VALUE #( msgid = sy-msgid
                      msgno = sy-msgno
                      msgty = sy-msgty
                      msgv1 = sy-msgv1
                      msgv2 = sy-msgv2
                      msgv3 = sy-msgv3
                      msgv4 = sy-msgv4
                      message = dummy_message
                      bank_action = im_action )
                      ).
    save_log( ).

    IF im_destroy = 'X'.
      destroy( ).
    ENDIF.
  ENDMETHOD.


method GET_MESSAGE_COLLECTOR.
    ro_message_collector = logger->get_message_collector( im_uuid ).
  endmethod.


METHOD import_messages.
    CHECK logger IS BOUND.
    logger->import_messages(
                  im_t_messages              = im_t_messages
                  im_s_log_businessdata_data = im_s_log_businessdata_data
                  im_uuid                    = im_uuid ).
  ENDMETHOD.


METHOD log_file.
    logger->log_file(
                   im_file_uuid      = im_file_uuid
                   im_bank_indicator = im_bank_indicator
                   im_action         = im_action
                   im_step           = im_step
                   im_function       = im_function
                   im_cfile          = im_cfile
                   im_xfile          = im_xfile
                   im_file_direction = im_file_direction ).
  ENDMETHOD.


METHOD receive_bank_account_in_api.
    set_api_starting_log( im_action ).

    IF im_t_account_list IS NOT INITIAL.
      re_has_record = 'X'.
    ELSE.
      re_has_record = space.
      MESSAGE i102(ztr_bank_application)
              INTO dummy_message.
      add_log(
               VALUE #( msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        message      = dummy_message
                        bank_action  = im_action ) ).
*      end_logs( 'X' ).
      end_logs( im_action ).
    ENDIF.
  ENDMETHOD.


METHOD receive_payment_entry_in_api.
    set_api_starting_log( im_action ).

    IF IM_T_ENTRY_LIST IS NOT INITIAL.
      re_has_record = 'X'.

      LOOP AT im_t_entry_list INTO DATA(ls_entry_list).
        MESSAGE i101(ztr_bank_application)
                WITH ls_entry_list-paymorder
                INTO dummy_message.
        add_log(
                 VALUE #( msgid        = sy-msgid
                          msgno        = sy-msgno
                          msgty        = sy-msgty
                          msgv1        = sy-msgv1
                          msgv2        = sy-msgv2
                          msgv3        = sy-msgv3
                          msgv4        = sy-msgv4
                          message      = dummy_message
                          bank_action  = im_action
                          log_obj      = ls_entry_list-entuuid
                          log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                          paymorder    = ls_entry_list-paymorder ) ).
      ENDLOOP.
    ELSE.
      re_has_record = space.
      MESSAGE i102(ztr_bank_application)
              INTO dummy_message.
      add_log(
               VALUE #( msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        message      = dummy_message
                        bank_action  = im_action ) ).
*      end_logs( 'X' ).
      end_logs( im_action ).
    ENDIF.
  ENDMETHOD.


METHOD receive_paymorder_in_api.
    set_api_starting_log( im_action ).

    IF im_t_order_list IS NOT INITIAL.
      re_has_record = 'X'.

      LOOP AT im_t_order_list INTO DATA(ls_order_list).
        MESSAGE i101(ztr_bank_application)
                WITH ls_order_list-paymorder
                INTO dummy_message.
        add_log(
                 VALUE #( msgid        = sy-msgid
                          msgno        = sy-msgno
                          msgty        = sy-msgty
                          msgv1        = sy-msgv1
                          msgv2        = sy-msgv2
                          msgv3        = sy-msgv3
                          msgv4        = sy-msgv4
                          message      = dummy_message
                          bank_action  = im_action
                          log_obj      = ls_order_list-paymorder
                          log_obj_type = zcl_bank_application_logger=>log_object_type_payment_order
                          paymorder    = ls_order_list-paymorder ) ).
      ENDLOOP.
    ELSE.
      re_has_record = space.
      MESSAGE i102(ztr_bank_application)
              INTO dummy_message.
      add_log(
               VALUE #( msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        message      = dummy_message
                        bank_action  = im_action ) ).
*      end_logs( 'X' ).
      end_logs( im_action ).
    ENDIF.
  ENDMETHOD.


METHOD save_log.
    logger->save( ).
  ENDMETHOD.


METHOD set_api_starting_log.
    create_logger( ).

    add_message_collector(
                 EXPORTING
                   im_default_message_class = default_message_class
                   im_mainprogram           = sy-repid
                   im_uuid                  = im_uuid ).

    MESSAGE i100(ztr_bank_application)
            WITH im_action
                 zcl_bank_enviroment=>s_get_bank_action_text( im_action )
            INTO dummy_message.
    add_log( VALUE #( uuid = im_uuid
                      msgid = sy-msgid
                      msgno = sy-msgno
                      msgty = sy-msgty
                      msgv1 = sy-msgv1
                      msgv2 = sy-msgv2
                      msgv3 = sy-msgv3
                      msgv4 = sy-msgv4
                      message = dummy_message
                      bank_action = im_action )
                      ).

  ENDMETHOD.
ENDCLASS.
