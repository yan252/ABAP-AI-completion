class ZCX_SAPLINK definition
  public
  inheriting from CX_STATIC_CHECK
  create public .

*"* public components of class ZCX_SAPLINK
*"* do not include other source files here!!!
public section.

  constants ERROR_MESSAGE type SOTR_CONC value '0050568B43521EDCBCDA50C8EEDECFD9' ##NO_TEXT.
  constants EXISTING type SOTR_CONC value '0050568B43521EDCBCDA50C8EEDEEFD9' ##NO_TEXT.
  constants INCORRECT_FILE_FORMAT type SOTR_CONC value '0050568B43521EDCBCDA50C8EEDF0FD9' ##NO_TEXT.
  constants LOCKED type SOTR_CONC value '0050568B43521EDCBCDA50C8EEDF2FD9' ##NO_TEXT.
  data MSG type STRING value '44F7518323DB08BC02000000A7E42BB6' ##NO_TEXT.
  constants NOT_AUTHORIZED type SOTR_CONC value '0050568B43521EDCBCDA50C8EEDF4FD9' ##NO_TEXT.
  constants NOT_FOUND type SOTR_CONC value '0050568B43521EDCBCDA50C8EEDF6FD9' ##NO_TEXT.
  constants NO_PLUGIN type SOTR_CONC value '0050568B43521EDCBCDA50C8EEDF8FD9' ##NO_TEXT.
  constants SYSTEM_ERROR type SOTR_CONC value '0050568B43521EDCBCDA50C8EEDFAFD9' ##NO_TEXT.
  constants ZCX_SAPLINK type SOTR_CONC value '0050568B43521EDCBCDA50C8EEDFCFD9' ##NO_TEXT.
  data OBJECT type STRING .

  methods CONSTRUCTOR
    importing
      !TEXTID like TEXTID optional
      !PREVIOUS like PREVIOUS optional
      !MSG type STRING default '44F7518323DB08BC02000000A7E42BB6'
      !OBJECT type STRING optional .
protected section.
*"* protected components of class ZCX_SAPLINK
*"* do not include other source files here!!!
private section.
*"* private components of class ZCX_SAPLINK
*"* do not include other source files here!!!
ENDCLASS.



CLASS ZCX_SAPLINK IMPLEMENTATION.


  method CONSTRUCTOR.
CALL METHOD SUPER->CONSTRUCTOR
EXPORTING
TEXTID = TEXTID
PREVIOUS = PREVIOUS
.
 IF textid IS INITIAL.
   me->textid = ZCX_SAPLINK .
 ENDIF.
me->MSG = MSG .
me->OBJECT = OBJECT .
  endmethod.
ENDCLASS.
