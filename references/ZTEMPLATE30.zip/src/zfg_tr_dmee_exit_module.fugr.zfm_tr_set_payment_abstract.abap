FUNCTION ZFM_TR_SET_PAYMENT_ABSTRACT.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     VALUE(I_TREE_TYPE) TYPE  DMEE_TREETYPE_ABA
*"     VALUE(I_TREE_ID) TYPE  DMEE_TREEID_ABA
*"     VALUE(I_ITEM)
*"     VALUE(I_PARAM)
*"     VALUE(I_UPARAM)
*"  EXPORTING
*"     REFERENCE(O_VALUE)
*"     REFERENCE(C_VALUE)
*"     REFERENCE(N_VALUE)
*"     REFERENCE(P_VALUE)
*"  TABLES
*"      I_TAB
*"--------------------------------------------------------------------
FIELD-SYMBOLS:<fs_fpayh> TYPE fpayh.
  ASSIGN COMPONENT 'FPAYH' OF STRUCTURE i_item TO <fs_fpayh>.
  CONCATENATE zcl_bank_payment_entry=>transaction_reference_prefix "'APPTRATIONREFERENCE'
              <fs_fpayh>-doc1r
              INTO c_value.





ENDFUNCTION.
