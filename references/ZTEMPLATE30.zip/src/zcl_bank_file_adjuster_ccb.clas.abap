class ZCL_BANK_FILE_ADJUSTER_CCB definition
  public
  inheriting from ZCL_BANK_FILE_ADJUSTER
  final
  create public .

public section.

  methods ZIF_SENDING_FILE_ADJUSTER~ADJUST
    redefinition .
protected section.
private section.
ENDCLASS.



CLASS ZCL_BANK_FILE_ADJUSTER_CCB IMPLEMENTATION.


METHOD zif_sending_file_adjuster~adjust.
    DATA:l_string  TYPE string,
         l_xstring TYPE xstring.
    LOOP AT ch_data ASSIGNING FIELD-SYMBOL(<fs_data>).
      ASSIGN <fs_data>-cfile->* TO FIELD-SYMBOL(<f_cfile>).

      ASSIGN <fs_data>-xfile->* TO FIELD-SYMBOL(<f_xfile>).

      zcl_bank_data_mapping_engine=>set_xml_standalone(
                       IMPORTING
                         et_return_errors = ex_t_return
                        CHANGING
                          ch_xml_cstring = <f_cfile>
                          ch_xml_xstring = <f_xfile> ).
      IF ex_t_return IS NOT INITIAL.
        EXIT.
      ENDIF.
      <f_xfile> = cl_abap_codepage=>convert_to( zif_ccb_constants=>sending_message_prefix ) && <f_xfile>.
      <f_cfile> = zif_ccb_constants=>sending_message_prefix && <f_cfile>.
      UNASSIGN: <f_cfile>,
                <f_xfile>.
    ENDLOOP.
  ENDMETHOD.
ENDCLASS.
