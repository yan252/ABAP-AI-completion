class ZCL_BANK_CITIC_FUNCTION_PAYMNT definition
  public
  inheriting from ZCL_BANK_FUNCTION_PAYMENT
  final
  create public .

public section.
protected section.

  methods PROCESSING_RESPONSE_INTL_CORE
    redefinition .
private section.
ENDCLASS.



CLASS ZCL_BANK_CITIC_FUNCTION_PAYMNT IMPLEMENTATION.


METHOD processing_response_intl_core.
    FIELD-SYMBOLS: <fs_response>        TYPE ztrs_citic_dlinttrn_response.
    DATA: ls_bank_payment_return TYPE ztrs_payment_bank_return.


    super->processing_response_intl_core( ).

    DATA(ls_response_data) = get_current_response_data( ).
    ASSIGN ls_response_data-response_ref->* TO <fs_response>.
    MOVE: <fs_response>-stream-status TO ls_bank_payment_return-header-bank_rtncode,
          <fs_response>-stream-statustext TO ls_bank_payment_return-header-bank_rtnmsg.
    LOOP AT <fs_response>-stream-row INTO DATA(ls_row).
      APPEND VALUE #( paymorder = ls_row-clientid
                      doc1r = ls_row-clientid
                      bank_rtncode = ls_row-status
                      bank_rtnmsg = ls_row-statustext )
*                      bank_tran_number = ls_row-obssid )
                   TO ls_bank_payment_return-items.
    ENDLOOP.
    update_status_in_instance( ls_bank_payment_return ).

  ENDMETHOD.
ENDCLASS.
