*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_TR_SSFTOP.                    " Global Declarations
  INCLUDE LZFG_TR_SSFUXX.                    " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_TR_SSFF...                    " Subroutines
* INCLUDE LZFG_TR_SSFO...                    " PBO-Modules
* INCLUDE LZFG_TR_SSFI...                    " PAI-Modules
* INCLUDE LZFG_TR_SSFE...                    " Events
* INCLUDE LZFG_TR_SSFP...                    " Local class implement.
* INCLUDE LZFG_TR_SSFT99.                    " ABAP Unit tests

INCLUDE lzfg_tr_ssff01.
