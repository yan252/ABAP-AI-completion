FUNCTION ZFM_TR_BANK_LOGON_USER.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     REFERENCE(IM_BANK_INDICATOR) TYPE  ZTR_BANK_INDICATOR
*"  EXPORTING
*"     REFERENCE(EX_USER) TYPE  EPIC_BC_USER
*"     REFERENCE(EX_PASWORD) TYPE  STRING
*"--------------------------------------------------------------------
SELECT SINGLE guid
         INTO @DATA(l_guid)
         FROM ztrt_bank_ass
         WHERE bank_ind = @im_bank_indicator.
  IF sy-subrc <> 0.
    RETURN.
  ENDIF.

  DATA(lo_user) = NEW cl_epic_bank_comm_logon( l_guid ).

  TRY.
      ex_user = lo_user->get_commuser( ).
    CATCH cx_epic_bank_comm_logon.
  ENDTRY.

  TRY.
      ex_pasword = lo_user->get_user_secstore( ).
    CATCH cx_epic_bank_comm_logon.
  ENDTRY.





ENDFUNCTION.
