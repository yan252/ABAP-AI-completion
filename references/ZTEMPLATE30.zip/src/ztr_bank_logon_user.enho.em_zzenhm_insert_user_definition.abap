METHOD ZZENHM_INSERT_USER_DEFINITION .
    insert_user_definition(
          iv_new_name  = iv_new_name
          iv_new_descr = iv_new_descr ).
ENDMETHOD.
