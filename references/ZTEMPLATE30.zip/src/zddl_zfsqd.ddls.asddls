@AbapCatalog.sqlViewName: 'ZTRCDSZFSQD_AGN'
@AbapCatalog.compiler.compareFilter: true
@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: '支付申请单剩余支付金额'
define view ZDDL_ZFSQD 
as select from ztrt2500_1 as b 
inner  join ztrt2500_2 as c on b.mandt = c.mandt and b.docno = c.docno
left outer join ZDDL_AGN03 as a
   on  b.bukrs = a.bukrs   and c.docno = a.zbelnr1     and c.itemno = a.sqdxh
   and c.belnr = a.belnr  and c.gjahr = a.gjahr  and c.buzei = a.buzei
    {
   b.bukrs ,
   b.docno ,
   c.itemno ,
   b.betdt ,
   b.bcate ,
   case when c.rstgr <> '' then c.rstgr else
                         b.fund_flow end as fund_flow,
   b.ztr_bpt,
   b.ztr_bp ,
   c.name,
  case when c.zlsch  <> '' then c.zlsch else
                         b.zskfs  end as zskfs , 
   b.waers ,
   b.projk ,
   b.zcmt, 
   case when b.zterm = '' then 'ZZZZ'
                    else b.zterm  end as zterm,
   b.bvtyp ,
   c.banks,
c.bankl,
c.banka,
c.bankn,
   c.belnr,
    c.gjahr,
    c.buzei, 
   b.ref_docno ,
   case when b.bcate = '21' then  b.prctr  
                                    else  c.prctr end as prctr,
   //case when b.bcate = '22' then ref02  else '' end as REF02,
   ref02,
   //航行目的支付金额                                 
   case when  c.itemno = '0000' then  b.zzfje
        when b.bcate = '12'   then wrbtr     
        else  c.subzfje end as zfje_I,
   // 剩余可支付金额     
   case when  c.itemno = '0000'  and a.WRBTR_AGN >= 0  then   ( b.zzfje - a.WRBTR_AGN ) 
      // when  c.itemno = '0000'  and a.wrbtr_agn = 0  then    b.zzfje  
       when b.bcate = '12'   and a.WRBTR_AGN >= 0 then  ( wrbtr  - a.WRBTR_AGN )
      //when b.bcate = '12'   and a.wrbtr_agn = 0 then   wrbtr  
      when  a.WRBTR_AGN > 0 then ( c.subzfje - a.WRBTR_AGN ) 
      when b.bcate = '12'  then wrbtr   //退款通知单未进计划，
       else c.subzfje
            end  as syzfje,
  // agn 锁定金额
   a.WRBTR_AGN
   
}
where b.zzfstatus = '13' //or  b.zzfstatus  = 'T'

 
  
 