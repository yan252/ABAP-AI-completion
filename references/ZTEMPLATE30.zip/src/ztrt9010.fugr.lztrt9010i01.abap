*&---------------------------------------------------------------------*
*& 包含               LZTRT9010I01
*&---------------------------------------------------------------------*
MODULE in_zmplv INPUT.
CONCATENATE
ztrt9010-zversion
ztrt9010-gjahr
ztrt9010-monat
INTO
ztrt9010-zmplv .
ENDMODULE.
