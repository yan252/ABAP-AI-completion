FUNCTION ZFM_TR_SSFENCRYPTION_SAVE.
*"--------------------------------------------------------------------
*"*"更新函数模块：
*"
*"*"局部接口：
*"  IMPORTING
*"     VALUE(IM_S_HEADER) TYPE  ZTRT_ENCRH_H
*"     VALUE(IM_T_ITEMS) TYPE  ZTRT_ENCRH_I_TAB
*"     VALUE(IM_T_LENGTH) TYPE  ZTRT_ENCRH_LEN_TAB
*"--------------------------------------------------------------------
*把旧的加密数据删除
  SELECT SINGLE * INTO @DATA(ls_old_h)
         FROM ztrt_encrh_h
         WHERE uuid = @im_s_header-uuid.
  SELECT * INTO TABLE @DATA(lt_old_i)
         FROM ztrt_encrh_i
         WHERE uuid = @im_s_header-uuid.
  SELECT * INTO TABLE @DATA(lt_old_l)
        FROM ztrt_encrh_len
        WHERE uuid = @im_s_header-uuid.
  DELETE ztrt_encrh_h FROM ls_old_h.
  DELETE ztrt_encrh_i FROM TABLE lt_old_i.
  DELETE ztrt_encrh_len FROM TABLE lt_old_l.

  MODIFY ztrt_encrh_h FROM im_s_header.

  MODIFY ztrt_encrh_i FROM TABLE im_t_items.

  MODIFY ztrt_encrh_len FROM TABLE im_t_length.





ENDFUNCTION.
