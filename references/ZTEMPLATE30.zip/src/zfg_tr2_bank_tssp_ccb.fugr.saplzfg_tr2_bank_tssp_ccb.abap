*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_TR2_BANK_TSSP_CCBTOP.         " Global Declarations
  INCLUDE LZFG_TR2_BANK_TSSP_CCBUXX.         " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_TR2_BANK_TSSP_CCBF...         " Subroutines
* INCLUDE LZFG_TR2_BANK_TSSP_CCBO...         " PBO-Modules
* INCLUDE LZFG_TR2_BANK_TSSP_CCBI...         " PAI-Modules
* INCLUDE LZFG_TR2_BANK_TSSP_CCBE...         " Events
* INCLUDE LZFG_TR2_BANK_TSSP_CCBP...         " Local class implement.
* INCLUDE LZFG_TR2_BANK_TSSP_CCBT99.         " ABAP Unit tests
