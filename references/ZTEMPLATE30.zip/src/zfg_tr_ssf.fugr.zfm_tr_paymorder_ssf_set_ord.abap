FUNCTION ZFM_TR_PAYMORDER_SSF_SET_ORD.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     REFERENCE(IM_S_2101) TYPE  ZTRT2101 OPTIONAL
*"     REFERENCE(IM_S_2001) TYPE  ZTRT2001 OPTIONAL
*"     REFERENCE(IM_S_2002) TYPE  ZTRT2002 OPTIONAL
*"     REFERENCE(IM_S_2003) TYPE  ZTRT2003 OPTIONAL
*"     REFERENCE(IM_ZZFTYPE) TYPE  ZTRT2001-ZZFTYPE OPTIONAL
*"  EXCEPTIONS
*"      ERROR
*"--------------------------------------------------------------------
DATA: l_count  TYPE i,
        l_update TYPE flag.
  DATA:ls_ssf_2001 TYPE ztrt2001_ssf,
       lt_ssf_2001 TYPE STANDARD TABLE OF ztrt2001_ssf,
       ls_ssf_2002 TYPE ztrt2002_ssf,
       lt_ssf_2002 TYPE STANDARD TABLE OF ztrt2002_ssf,
       ls_ssf_2003 TYPE ztrt2003_ssf,
       lt_ssf_2003 TYPE STANDARD TABLE OF ztrt2003_ssf,
       ls_ssf_2101 TYPE ztrt2101_ssf,
       lt_ssf_2101 TYPE STANDARD TABLE OF ztrt2101_ssf,
       ls_ssf_paym TYPE ztrt_paym_ssf.

  SELECT COUNT( * ) INTO l_count
         FROM ztrt_paym_ssf
         WHERE uname = sy-uname
         AND   datum = sy-datum.
  IF l_count > 0.
*      程序错误，用户只能在webdynpro中处理一个支付单，处理结束后从数据库缓存清除掉
*      在处理一个支付单时，内存中不应该存在一个没处理结束的记录
    MESSAGE e328(ztr_bank_application)
            WITH sy-uname
                 sy-datum
            RAISING error.
  ENDIF.

  ls_ssf_paym-uname = sy-uname.
  ls_ssf_paym-datum = sy-datum.
  ls_ssf_paym-zzftype = im_zzftype.
  IF im_zzftype = 'P004'.
    ls_ssf_paym-ssfuuid = im_s_2101-ssfuuid.
  ELSE.
    ls_ssf_paym-ssfuuid = im_s_2001-ssfuuid.
  ENDIF.
  GET TIME STAMP FIELD ls_ssf_paym-ztimestamp.
  SELECT SINGLE tzonesys
         INTO ls_ssf_paym-ztimezone
         FROM ttzcu.

  ls_ssf_2001-uname = sy-uname.
  ls_ssf_2001-datum = sy-datum.
  MOVE-CORRESPONDING im_s_2001 TO ls_ssf_2001.
  APPEND ls_ssf_2001 TO lt_ssf_2001.

  ls_ssf_2002-uname = sy-uname.
  ls_ssf_2002-datum = sy-datum.
  MOVE-CORRESPONDING im_s_2002 TO ls_ssf_2002.
  APPEND ls_ssf_2002 TO lt_ssf_2002.

  ls_ssf_2003-uname = sy-uname.
  ls_ssf_2003-datum = sy-datum.
  MOVE-CORRESPONDING im_s_2003 TO ls_ssf_2003.
  APPEND ls_ssf_2003 TO lt_ssf_2003.

  ls_ssf_2101-uname = sy-uname.
  ls_ssf_2101-datum = sy-datum.
  MOVE-CORRESPONDING im_s_2101 TO ls_ssf_2101.
  APPEND ls_ssf_2101 TO lt_ssf_2101.

  CALL FUNCTION 'ZFM_TR_PAYMORDER_SSF_BUFF_SAVE'
    DESTINATION 'NONE' "避免影响主程序的更新
    EXPORTING
      im_s_paym_ssf = ls_ssf_paym
    TABLES
      im_t_2001     = lt_ssf_2001
      im_t_2002     = lt_ssf_2002
      im_t_2003     = lt_ssf_2003
      im_t_2101     = lt_ssf_2101.

  DO 1000 TIMES.
    SELECT SINGLE * INTO @DATA(ls_ssf_paym_db)
           FROM ztrt_paym_ssf
           WHERE uname = @ls_ssf_paym-uname
           AND   datum = @ls_ssf_paym-datum.
    IF ls_ssf_paym_db-ztimestamp = ls_ssf_paym-ztimestamp AND
       ls_ssf_paym_db-ztimezone = ls_ssf_paym-ztimezone.
      l_update = 'X'.
      EXIT.
    ELSE.
      WAIT UP TO 1 SECONDS.
    ENDIF.
  ENDDO.

  IF l_update = space.
*  对于很少的数据量，在1000秒内都没有更新成功，很难想象是什么导致的
    MESSAGE e333(ztr_bank_application)
            WITH ls_ssf_paym-uname
                 ls_ssf_paym-datum
            RAISING error.
  ENDIF.





ENDFUNCTION.
