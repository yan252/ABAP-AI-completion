@AbapCatalog.sqlViewName: 'ZTRCDS3020B'
@AbapCatalog.compiler.compareFilter: true
@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'BISK部分清账清账凭证'
define view ZDDL_RT3020_02 
as select from ztrcds3020a
{
  mandt,
  bukrs,
  gjahr,
  belnr,
  buzei,
  waers,
  sum( wrbtr ) as WRBTR ,
  sum( wrbtr_bsik ) as WRBTR_BSIK 
} group by  mandt , bukrs , gjahr ,belnr ,buzei ,waers 

  
 
 
  
 