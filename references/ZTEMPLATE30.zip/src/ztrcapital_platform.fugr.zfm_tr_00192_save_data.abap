FUNCTION ZFM_TR_00192_SAVE_DATA.
*"--------------------------------------------------------------------
*"*"更新函数模块：
*"
*"*"局部接口：
*"  IMPORTING
*"     VALUE(IM_S_HEADER) TYPE  ZTRT0192H
*"     VALUE(IM_T_ITEMS) TYPE  ZTRT0192I_TAB
*"     VALUE(IM_INSERT) TYPE  FLAG DEFAULT 'X'
*"     VALUE(IM_T_WP_MAPPING) TYPE  ZTRT0192H_WP_TAB OPTIONAL
*"     VALUE(IM_T_WP_AMOUNT) TYPE  ZTRT0192H_WP_AMT_TAB OPTIONAL
*"--------------------------------------------------------------------
IF im_insert = 'X'.
    INSERT ztrt0192h FROM im_s_header.
    IF sy-subrc = 0.
      INSERT ztrt0192i FROM TABLE im_t_items.

      INSERT ztrt0192h_wp FROM TABLE im_t_wp_mapping.

      INSERT ztrt0192h_wp_amt FROM TABLE im_t_wp_amount.

    ENDIF.
  ELSE.
    MODIFY ztrt0192h FROM im_s_header.
    IF sy-subrc = 0.
      MODIFY ztrt0192i FROM TABLE im_t_items.

      MODIFY ztrt0192h_wp FROM TABLE im_t_wp_mapping.

      MODIFY ztrt0192h_wp_amt FROM TABLE im_t_wp_amount.
    ENDIF.
  ENDIF.





ENDFUNCTION.
