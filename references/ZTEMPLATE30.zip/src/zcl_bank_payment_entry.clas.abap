class ZCL_BANK_PAYMENT_ENTRY definition
  public
  create public .

public section.

  constants YES type FLAG value 'X' ##NO_TEXT.
  constants NO type FLAG value SPACE ##NO_TEXT.
  constants CREATE_FROM_PAYMENT_ORDER type ZTR_PAYMENTRY_CREATION_TYPE value '1' ##NO_TEXT.
  constants CREATE_FROM_PAYMENT_ENTRY type ZTR_PAYMENTRY_CREATION_TYPE value '2' ##NO_TEXT.
  constants ENTRY_STATUS_APP_REJECT type ZTR_ENTSTATUS value '000' ##NO_TEXT.
  constants ENTRY_STATUS_APP_PROCESS type ZTR_ENTSTATUS value '100' ##NO_TEXT.
  constants ENTRY_STATUS_BANK_TRANX_OK type ZTR_ENTSTATUS value '300' ##NO_TEXT.
  constants ENTRY_STATUS_BANK_TRANX_FAILED type ZTR_ENTSTATUS value '301' ##NO_TEXT.
  constants ENTRY_STATUS_SEND_FAILED type ZTR_ENTSTATUS value '401' ##NO_TEXT.
  constants ENTRY_STATUS_RECEIVE_FAILED type ZTR_ENTSTATUS value '402' ##NO_TEXT.
  constants ENTRY_STATUS_APP_ERROR type ZTR_ENTSTATUS value '400' ##NO_TEXT.
  constants TRANSACTION_REFERENCE_PREFIX type STRING value 'APPTRANSACTIONREFERENCE' ##NO_TEXT.
  constants TRANX_REFERENCE_PREFIX_BOC type STRING value 'APPTRANXREF' ##NO_TEXT.
  class-data TRIGGER_BY_ACCOUNT_TRANX type FLAG .

  methods CONSTRUCTOR
    importing
      !IM_CREATION_TYPE type ZTR_PAYMENTRY_CREATION_TYPE
      !IM_UUID type SYSUUID_C22 optional
      !IM_S_PAYMENT_ORDER type ZTRS_PAYMENTORDER_LIST optional
    exceptions
      CREATION_TYPE_ERROR
      CREATE_UUID_ERROR
      UUID_ERROR .
  methods SET_ENTRY .
  methods IF_ERROR
    returning
      value(RE_ERROR) type FLAG .
  methods GET_BANK_INDICATOR
    returning
      value(RE_BANK_INDICATOR) type ZTR_BANK_INDICATOR .
  methods EXPORT_ENTRY
    returning
      value(RS_PAYMENT_ENTRY) type ZTRT_PAYMENT .
  methods GET_UUID
    returning
      value(RE_UUID) type ZTR_PAYMENT_ENTRY_UUID .
  methods GET_REFERENCE_DOC
    returning
      value(RE_REFERENCE_DOC) type DOC1R_FPM .
  methods SET_STATUS
    importing
      !IM_ENTRY_STATUS type ZTR_ENTSTATUS .
  methods DESTROY .
  methods IMPORT_STATUS_FROM_BANK
    importing
      !IM_S_STAUS_FROM_BANK type ZTRS_PAYMENT_ENTRY_FROM_BANK .
  methods FEEDBACK_FROM_BANK
    importing
      !IM_S_BANK_FEEDBACK type ZTRS_PAYMENT_ENTRY_FROM_BANK
      !IM_S_BANK_ERROR_STEP type ZTRS_ERROR_STEP_EXT .
  class-methods CREATE_INSTANCE_FROM_PAYMORDER
    importing
      !IM_ACTION type ZTR_APP_ACTION_FOR_BANK
      !IM_S_PAYMENT_ORDER type ZTRS_PAYMENTORDER_LIST
    exporting
      !EX_O_INSTANCE type ref to ZCL_BANK_PAYMENT_ENTRY
    exceptions
      ERROR .
  methods GET_PAYMENT_KEY
    returning
      value(RS_KEY) type ZTRS_PAYMENTORDER_LIST .
  methods SET_STATUS_FROM_TRANSACTION .
  methods IF_CHECK_STATUS
    returning
      value(RE_CHECK) type FLAG .
  class-methods SET_TRIGER_BY_ACCOUNT_TRANX .
  class-methods IF_TRIGER_BY_ACCOUNT_TRANX
    returning
      value(RE_TRIGER_BY_ACCOUNT_TRANX) type FLAG .
protected section.

  data MESSAGES type ref to ZCL_MESSAGE_COLLECTOR .
  data ENTRY_UUID type SYSUUID_C22 .
  data INSTANCE_CREATION_TYPE type ZTR_PAYMENTRY_CREATION_TYPE .
  data PAYMENT_ORDER type ZTRS_PAYMENTORDER_LIST .
  data PAYMENT_ENTRY type ZTRT_PAYMENT .
  class-data DUMMY_MESSAGE type STRING .
  data BANK_ACTION type ZTR_APP_ACTION_FOR_BANK .

  methods ENQUEUE_PAYMENT_ORDER .
  methods ENQUEUE_PAYMENT_ENTRY .
  methods DEQUEUE_PAYMENT_ORDER .
  methods DEQUEUE_PAYMENT_ENTRY .
  methods CHECK_FOR_NEW_ENTRY_CORE .
  methods LOG_STATUS .
  methods READ_PAYMENTORDER_PAYEE_DATA
    exporting
      !EX_S_S2002 type ZTRS_PAYMENT_ORDER_S2002 .
  methods READ_PAYMENTORDER_PAYER_DATA
    exporting
      !EX_S_S2003 type ZTRS_PAYMENT_ORDER_S2003 .
  methods READ_PAYMENTORDER_HEADER
    exporting
      !EX_S_S2001 type ZTRS_PAYMENT_ORDER_S2001
      !EX_NOT_EXITED type FLAG .
  methods READ_DATA_BY_PAYER_ACCOUNTKEY
    importing
      !IM_BUKRS type BUKRS
      !IM_HBKID type HBKID
      !IM_HKTID type HKTID
    exporting
      !EX_BANK_INDICATOR type ZTR_BANK_INDICATOR
      !EX_ZHMC type ZTR_ZHMC .
  methods READ_PAYMENT_ORDER_CORE
    returning
      value(RS_PAYMENT_ORDER) type ZTRS_PAYMENT_ORDER .
  methods CONVERT_PAYMORD_TO_ENTRY_CORE
    importing
      !IM_S_PAYMENT_ORDER type ZTRS_PAYMENT_ORDER .
  methods CHECK_ORDER_STATUS .
  methods SET_PAYER_ACCOUNT_NAME .
  methods SET_DATE_SEQUENCE .
  methods ADJUST_FIELD_FOR_INSERTING .
  methods SET_ZSBUKRS
    importing
      !IM_ZFMARK type ZTR_ZMARK
      !IM_ZSKNO type ZTR_SKNO
    returning
      value(RE_BUKRS) type BUKRS .
  methods SET_PARTNER_CODE_AND_TYPE
    importing
      !IM_ZFMARK type ZTR_ZMARK
      !IM_ZSKNO type ZTR_SKNO
    exporting
      !EX_GPA1T type GPA1T_FPM
      !EX_GPA1R type GPA1R_FPM .
  methods SET_STATUS_FROM_PAYMORD_BUFFER
    exporting
      !EX_DONE type FLAG .
  methods SET_STATUS_FROM_TRANX_DB
    exporting
      !EX_DONE type FLAG .
  methods CHECK_BANK_ACC_SHIFTON_DATE .
  methods CHECK_RECEIVE_ACCOUNT .
private section.

  methods SET_BY_PAYMENT_ORDER .
  methods SET_BY_PAYMENT_ENTRY .
  methods ENQUEUE .
  methods DEQUEUE .
  methods READ_PAYMENT_ORDER
    returning
      value(RS_PAYMENT_ORDER) type ZTRS_PAYMENT_ORDER .
  methods INSERT_ENTRY_FOR_STARTING .
  methods CONVERT_PAYMORDER_TO_PAYMENTRY .
  methods SAVE_ENTRY .
  methods BUILD_PAYMORDER_LINKAGE
    returning
      value(RS_PAYMENT_ORDER_LINKAGE) type ZTRT_PAYMLINK .
  methods CHECK_FOR_NEW_ENTRY .
  methods CHECK_ENTRY_AGAINST_OLD_ENTRY .
  methods CHECK_ENTRY_AGAINST_LINKAGE .
  methods CHECK_UUID .
  methods GET_ENTRY_STATUS_TEXT
    importing
      !IM_ENTRY_STATUS type ZTR_ENTSTATUS
    returning
      value(R_TEXT) type ZTR_ENTSTATUS_TEXT .
  methods CHECK_STATUS_FOLLOW_FIELD
    importing
      !IM_T_STATUS_FOLLOW type ZTRS_CHECK_STATUS_FOLLOW_TAB .
  methods SET_PROCESS_MSG_TO_ENTRY .
  methods FEEDBACK_FROM_BANK_RESPONSE
    importing
      !IM_S_BANK_FEEDBACK type ZTRS_PAYMENT_ENTRY_FROM_BANK .
  methods FEEDBACK_FROM_BANK_STEP_ERROR
    importing
      !IM_S_BANK_ERROR_STEP type ZTRS_ERROR_STEP_EXT .
  methods REFRESH_ENTRY
    importing
      !IM_ENTRY_UUID type ZTR_PAYMENT_ENTRY_UUID .
  methods GET_CURRENT_BANK_ACTION .
  methods CHECK_BANK .
  methods CHECK_ORDER_PAYMENT_METHOD .
ENDCLASS.



CLASS ZCL_BANK_PAYMENT_ENTRY IMPLEMENTATION.


METHOD adjust_field_for_inserting.
    DATA: l_bank_date TYPE sydatum.

    CASE payment_entry-bank_ind.
      WHEN 'ICBC'.
*        工商银行的支付参考是按照日期+当天的流水号码
*        工商银行的支付支持批量报文，但为了一对一对应支付单和支付报文
*        我们设置了工商银行的支付操作是单笔处理，也就是说一个支付参考对应一个支付单
        payment_entry-doc1r = payment_entry-seqdate && payment_entry-dateseq.
*        IF sy-mandt = '130' OR
*           sy-mandt = '150'.
**          工行测试系统不是按照自然日期
*          l_bank_date = zcl_icbc_enhancement=>set_bank_date( ).
*          payment_entry-doc1r = l_bank_date  && payment_entry-dateseq.
*        ELSE.
*
*          payment_entry-doc1r = payment_entry-seqdate && payment_entry-dateseq.
*        ENDIF.
    ENDCASE.
  ENDMETHOD.


METHOD build_paymorder_linkage.
*    start log
    MESSAGE i124(ztr_bank_application)
            WITH payment_order-paymorder
                 entry_uuid
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = entry_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = bank_action
                      bank_ind     = payment_entry-bank_ind
                      log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                      log_obj      = entry_uuid
                      paymorder    = payment_order-paymorder ) ).
*    end log

    SELECT SINGLE entstatus INTO @DATA(l_db_status)
            FROM ztrt_payment
            WHERE entuuid = @entry_uuid.
    IF sy-subrc <> 0.
*      get old status
*  technical error
*  it should not happend at this point
      MESSAGE e047(ztr_bank_application)
              WITH entry_uuid
                   'SET_STATUS'.
*      RETURN.
    ENDIF.

*检查当前设置的新状态是否允许更新数据库表
    SELECT COUNT( * ) INTO @DATA(l_count)
            FROM ztrt_entstamap
            WHERE insentstatus = @payment_entry-entstatus
            AND   dbentstatus = @l_db_status.
    IF l_count <= 0.
*      clear rs_payment_order_linkage.
      CLEAR l_count.
      SELECT COUNT( * ) INTO l_count
             FROM ztrt_paymlink
             WHERE paymorder = payment_entry-paymorder
             and   DRAFT_ZXH = payment_entry-draft_zxh.
      IF l_count > 0.
*  已经存在记录，当前设置的状态不允许更新数据库表
        CLEAR rs_payment_order_linkage.
        RETURN.
      ENDIF.
    ENDIF.

    SELECT SINGLE * INTO @DATA(ls_order_status_mapping)
         FROM ztrt_entordmap
         WHERE entstatus = @payment_entry-entstatus.
    IF sy-subrc <> 0.
*      配置错误
*    start log
      MESSAGE e010(ztr_bank_application)
              WITH payment_entry-entstatus
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = entry_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = bank_action
                        bank_ind     = payment_entry-bank_ind
                        log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                        log_obj      = entry_uuid
                        paymorder    = payment_order-paymorder ) ).
*    end log
      RETURN.
*      add_system_msg_and_return_01 010
*                                   payment_entry-entstatus.
    ENDIF.

*    IF ls_order_status_mapping = no.
**      该银企直连状态不需要更新连接表
*      RETURN.
*    ENDIF.

    IF ls_order_status_mapping-ordstatus IS NOT INITIAL.
      MOVE: payment_entry-paymorder            TO rs_payment_order_linkage-paymorder,
            payment_entry-draft_zxh            TO rs_payment_order_linkage-draft_zxh,
*            payment_entry-doc1r                TO rs_payment_order_linkage-doc1r,
*          payment_entry-paymorder_version    TO rs_payment_order_linkage-paymorder_version,
            ls_order_status_mapping-ordstatus  TO rs_payment_order_linkage-ordstatus,
            payment_entry-entuuid              TO rs_payment_order_linkage-entuuid.
    ENDIF.


*    start log
    MESSAGE i126(ztr_bank_application)
            WITH payment_order-paymorder
                 entry_uuid
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = entry_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = bank_action
                      bank_ind     = payment_entry-bank_ind
                      log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                      log_obj      = entry_uuid
                      paymorder    = payment_order-paymorder ) ).
*    end log
  ENDMETHOD.


METHOD check_bank.
    IF payment_entry-bank_ind IS INITIAL.
      MESSAGE e261(ztr_bank_application)
              WITH entry_uuid
                   payment_order-paymorder
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = entry_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = bank_action
                        bank_ind     = payment_entry-bank_ind
                        log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                        log_obj      = entry_uuid
                        paymorder    = payment_order-paymorder ) ).
      RETURN.
    ENDIF.

    SELECT SINGLE * INTO @DATA(ls_bank)
            FROM ztrt_bank
            WHERE bank_ind = @payment_entry-bank_ind.
    IF sy-subrc <> 0.
      MESSAGE e262 WITH entry_uuid
                        payment_order-paymorder
                        payment_entry-bank_ind
                   INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = entry_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = bank_action
                        bank_ind     = payment_entry-bank_ind
                        log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                        log_obj      = entry_uuid
                        paymorder    = payment_order-paymorder ) ).
      RETURN.
    ENDIF.

    IF ls_bank-active = no.
      MESSAGE e264 WITH entry_uuid
                        payment_order-paymorder
                        payment_entry-bank_ind
                   INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = entry_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = bank_action
                        bank_ind     = payment_entry-bank_ind
                        log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                        log_obj      = entry_uuid
                        paymorder    = payment_order-paymorder ) ).
      RETURN.
    ENDIF.

    IF ls_bank-comm_type IS INITIAL.
      MESSAGE e263 WITH entry_uuid
                        payment_order-paymorder
                        payment_entry-bank_ind
                   INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = entry_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = bank_action
                        bank_ind     = payment_entry-bank_ind
                        log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                        log_obj      = entry_uuid
                        paymorder    = payment_order-paymorder ) ).
      RETURN.
    ENDIF.


  ENDMETHOD.


METHOD check_bank_acc_shifton_date.
    SELECT SINGLE * INTO @DATA(ls_shifton_date)
            FROM ztrt_bank_shift
            WHERE bukrs = @payment_entry-zbukr
            AND   hbkid = @payment_entry-hbkid
            AND   hktid = @payment_entry-hktid.


    IF ( ls_shifton_date-datum )  IS INITIAL OR
       ( ls_shifton_date-datum IS NOT INITIAL AND
         sy-datum < ls_shifton_date-datum ).
      MESSAGE e358(ztr_bank_application)
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = entry_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = bank_action
                        log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                        log_obj      = entry_uuid
                        bank_ind     = payment_entry-bank_ind
                        paymorder    = payment_order-paymorder ) ).
    ENDIF.

  ENDMETHOD.


METHOD check_entry_against_linkage.
*    DATA: "ls_status_follow TYPE ztrs_check_status_follow,
*          lt_status_follow TYPE ztrs_check_status_follow_tab.

    SELECT SINGLE paymorder,
*                  paymorder_version,
                  ordstatus,
                  entuuid
                  INTO  @DATA(ls_linkage)
                  FROM ztrt_paymlink
                  WHERE paymorder = @payment_entry-paymorder
                  and     draft_zxh = @payment_entry-draft_zxh .
    IF sy-subrc <> 0.
      RETURN.
    ENDIF.

    IF ls_linkage-ordstatus IS INITIAL.
*    start log
      MESSAGE e018(ztr_bank_application)
              with payment_entry-paymorder
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = entry_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = bank_action
                        bank_ind     = payment_entry-bank_ind
                        log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                        log_obj      = entry_uuid
                        paymorder    = payment_order-paymorder ) ).
*    end log
    ENDIF.

  ENDMETHOD.


METHOD check_entry_against_old_entry.
    DATA: lt_old_entries TYPE ztrs_check_status_follow_tab.

    SELECT a~entuuid
           a~paymorder
           a~doc1r
           a~draft_zxh
           a~entstatus
           b~follow
           INTO CORRESPONDING FIELDS OF TABLE lt_old_entries
           FROM ztrt_payment AS a
           LEFT OUTER JOIN ztrt_entstatus AS b
           ON  a~entstatus = b~entstatus
           WHERE a~doc1r = payment_entry-doc1r
           OR    ( a~paymorder = payment_entry-paymorder
           AND     a~draft_zxh = payment_entry-draft_zxh ).

    SORT lt_old_entries BY entuuid.
    DELETE ADJACENT DUPLICATES FROM lt_old_entries  COMPARING entuuid.

    check_status_follow_field( lt_old_entries ).

  ENDMETHOD.


METHOD check_for_new_entry.
*    start log
    MESSAGE i129(ztr_bank_application)
            WITH payment_order-paymorder
                 entry_uuid
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = entry_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = bank_action
                      bank_ind     = payment_entry-bank_ind
                      log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                      log_obj      = entry_uuid
                      paymorder    = payment_order-paymorder ) ).
*    end log

*    检查支付单 -------支付单平台先发送数据再更新支付单状态
*    check_entry_against_paymorder( ).
*    return_if_error.
    check_for_new_entry_core( ).

*    start log
    MESSAGE i130(ztr_bank_application)
            WITH payment_order-paymorder
                 entry_uuid
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = entry_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = bank_action
                      bank_ind     = payment_entry-bank_ind
                      log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                      log_obj      = entry_uuid
                      paymorder    = payment_order-paymorder ) ).
*    end log
  ENDMETHOD.


METHOD check_for_new_entry_core.
    DATA l_finished TYPE flag.

*检查支付条目的UUID号码
    check_uuid( ).
    IF if_error( ) = yes.
      l_finished = yes.
    ENDIF.
*    return_if_error.
    check_bank_acc_shifton_date( ).
    IF if_error( ) = yes.
      l_finished = yes.
    ENDIF.

    check_receive_account( ).
    IF if_error( ) = yes.
      l_finished = yes.
    ENDIF.

*针对当前的支付单和旧的支付条目进行检查，
*避免出现重复支付的情况
    IF l_finished = no.

      check_order_payment_method( ).

      check_order_status( ).

      check_entry_against_old_entry( ).

*检查支付条目和支付单之间的连接状况
*    IF l_finished = no.
      check_entry_against_linkage( ).
    ENDIF.
  ENDMETHOD.


METHOD check_order_payment_method.
    SELECT COUNT( * ) INTO @DATA(l_count)
           FROM ztrt_pmordmethod
           WHERE config_type = 'P0'
           AND   zzftype = @payment_entry-zzftype
           AND   zzffs = @payment_entry-zzffs.
    IF l_count < 1.
      MESSAGE e269(ztr_bank_application)
              WITH entry_uuid
                   payment_order-paymorder
                  payment_entry-zzffs
              INTO dummy_message.
*    start log
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = entry_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = bank_action
                        log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                        log_obj      = entry_uuid
                        bank_ind     = payment_entry-bank_ind
                        paymorder    = payment_order-paymorder ) ).
    ENDIF.
  ENDMETHOD.


METHOD check_order_status.

    IF if_error( ) = yes.
      RETURN.
    ENDIF.

    SELECT SINGLE * INTO @DATA(ls_order)
           FROM ztrt2001
           WHERE docno = @payment_entry-paymorder.
    IF sy-subrc <> 0.
*  if_error的时候就已经应该退出了
*  不应该再来到这一步
      RETURN.
    ENDIF.

    SELECT COUNT( * ) INTO @DATA(l_count)
           FROM ztrt_pmordstatus
           WHERE config_type = 'P0'
           AND   zzftype = @payment_entry-zzftype
           AND   zzffs = @payment_entry-zzffs
           AND   zbskl = @payment_entry-draft_zbskl
           AND   zappro = @ls_order-zzfstatus.
    IF l_count < 1.
      MESSAGE e270(ztr_bank_application)
              WITH payment_entry-entuuid
                   payment_order-paymorder
                  ls_order-zzfstatus
              INTO dummy_message.
*    start log
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = entry_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = bank_action
                        log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                        log_obj      = entry_uuid
                        bank_ind     = payment_entry-bank_ind
                        paymorder    = payment_order-paymorder ) ).
    ENDIF.
  ENDMETHOD.


METHOD check_receive_account.
    DATA: l_string TYPE string.

    l_string = payment_entry-zbnkn.

    CONDENSE l_string.
   return ." 临时跳过校验 20210309
    IF l_string CN '0123456789'.
*      账户存在非数字的字符
      MESSAGE e373(ztr_bank_application)
            WITH payment_entry-zbnkn
            INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = entry_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = bank_action
                        bank_ind     = payment_entry-bank_ind
                        log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                        log_obj      = entry_uuid
                        paymorder    = payment_order-paymorder ) ).
    ENDIF.

  ENDMETHOD.


METHOD check_status_follow_field.
*    DATA l_dummy_message TYPE c.

    LOOP AT im_t_status_follow INTO DATA(ls_status_follow).
      CASE ls_status_follow-follow.
        WHEN '1' OR '2' OR 'X'.
*          '1' 处理中，同一支付单不能被重复发起支付
*          '2' 已完成，该支付单不能再发起支付
*           'X' 上一次出现发送或接收错误，上次的支付条目尚未更新为最终状态
*START LOG
          MESSAGE e009(ztr_bank_application)
                  WITH payment_entry-paymorder
                       get_entry_status_text( ls_status_follow-entstatus )
                  INTO dummy_message.
          zcl_bank_logger_protocal=>add_log(
                   VALUE #( uuid         = entry_uuid
                            msgid        = sy-msgid
                            msgno        = sy-msgno
                            msgty        = sy-msgty
                            msgv1        = sy-msgv1
                            msgv2        = sy-msgv2
                            msgv3        = sy-msgv3
                            msgv4        = sy-msgv4
                            message      = dummy_message
                            bank_action  = bank_action
                            bank_ind     = payment_entry-bank_ind
                            log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                            log_obj      = entry_uuid
                            paymorder    = payment_order-paymorder ) ).
*END LOG
          CONTINUE.
        WHEN '3'.
*目前没有这个情况
        WHEN '4'.
*          交易失败，该支付单可以使用相同的版本号码再发起支付
          CONTINUE.
        WHEN 'Z' OR 'P' or space.
          IF ls_status_follow-entuuid <> entry_uuid.
*          异常错误，不应该出现这个情况
*START LOG
            MESSAGE e013(ztr_bank_application)
                    WITH payment_entry-paymorder
                         get_entry_status_text( ls_status_follow-entstatus )
                    INTO dummy_message.
            zcl_bank_logger_protocal=>add_log(
                     VALUE #( uuid         = entry_uuid
                              msgid        = sy-msgid
                              msgno        = sy-msgno
                              msgty        = sy-msgty
                              msgv1        = sy-msgv1
                              msgv2        = sy-msgv2
                              msgv3        = sy-msgv3
                              msgv4        = sy-msgv4
                              message      = dummy_message
                              bank_action  = bank_action
                              bank_ind     = payment_entry-bank_ind
                              log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                              log_obj      = entry_uuid
                              paymorder    = payment_order-paymorder ) ).
*END LOG
            CONTINUE.
          ENDIF.
        WHEN OTHERS.
*          异常错误，不应该出现这个情况
*START LOG
          MESSAGE e012(ztr_bank_application)
                  WITH ls_status_follow-entuuid
                       ls_status_follow-entstatus
                       ls_status_follow-follow
                  INTO dummy_message.
          zcl_bank_logger_protocal=>add_log(
                   VALUE #( uuid         = entry_uuid
                            msgid        = sy-msgid
                            msgno        = sy-msgno
                            msgty        = sy-msgty
                            msgv1        = sy-msgv1
                            msgv2        = sy-msgv2
                            msgv3        = sy-msgv3
                            msgv4        = sy-msgv4
                            message      = dummy_message
                            bank_action  = bank_action
                            bank_ind     = payment_entry-bank_ind
                            log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                            log_obj      = entry_uuid
                            paymorder    = payment_order-paymorder ) ).
*END LOG
          CONTINUE.
      ENDCASE.
    ENDLOOP.
  ENDMETHOD.


METHOD check_uuid.
    SELECT COUNT( * ) INTO @DATA(l_count)
         FROM ztrt_payment
         WHERE entuuid = @payment_entry-entuuid.
    CASE instance_creation_type.
      WHEN create_from_payment_order.
        return.
*        IF l_count > 0.
**      exception
*          MESSAGE e008(ztr_bank_application)
*                WITH payment_entry-entuuid
*                INTO DATA(l_dummy_message).
*          messages->add_system_message( sy ).
*        ENDIF.
      WHEN create_from_payment_entry.
        IF l_count < 1.
*      exception
          MESSAGE e017(ztr_bank_application)
                WITH payment_entry-entuuid
                INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = entry_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = bank_action
                        bank_ind     = payment_entry-bank_ind
                        log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                        log_obj      = entry_uuid
                        paymorder    = payment_order-paymorder ) ).
*    end log

*          MESSAGE e017(ztr_bank_application)
*                WITH payment_entry-entuuid
*                INTO data(l_dummy_message).
*          messages->add_system_message( sy ).
        ENDIF.
    ENDCASE.
  ENDMETHOD.


METHOD constructor.
    ##NEEDED
*    DATA l_dummy_message TYPE c.
    CONSTANTS: lc_creation_type_domain TYPE dd07l-domname
                                       VALUE 'ZDM_TR_PAYMENTRY_CREATION_TYPE',
               lc_program              TYPE syrepid
                                       VALUE 'ZCL_BANK_PAYMENT_ENTRY',
               lc_message_id           TYPE symsgid
                                       VALUE 'ZTR_BANK_APPLICATION'.


*IM_CREATION_TYPE is a value of domain ZDM_TR_PAYMENTRY_CREATION_TYPE
    zcl_global_technical_service=>check_domain_value(
               EXPORTING
                 im_domain_name           = lc_creation_type_domain
                 im_domain_value          = im_creation_type
                 im_allow_initial_value   = no
               EXCEPTIONS
                 not_valid                = 1 ).
    IF sy-subrc <> 0.
*      technical error
*      the error should be avoided by testing
      MESSAGE ID sy-msgid
              TYPE 'E'
              NUMBER sy-msgno
              WITH sy-msgv1
                   sy-msgv2
                   sy-msgv3
                   sy-msgv4
               RAISING creation_type_error.
    ENDIF.

*set creation type
    instance_creation_type = im_creation_type.

*一般来说支付条目实例是通过传入的支付单IM_S_PAYMENT_ORDER创建的
*但为了应对异常情况（例如不是通过支付平台触发的），或为了以后扩展，因此也提供了支付条目UUID的参数
*但在APP后面的实施中，专门针对支付单创建实例进行
    CASE instance_creation_type.
      WHEN create_from_payment_order.
*        set payment order for current instance
        payment_order = im_s_payment_order.
*create the uuid for current instance
        CLEAR entry_uuid.
        TRY.
            entry_uuid = cl_system_uuid=>if_system_uuid_static~create_uuid_c22( ).
          CATCH cx_uuid_error.
            MESSAGE e001(ztr_bank_application)
             RAISING create_uuid_error.
        ENDTRY.

      WHEN create_from_payment_entry.
*        the uuid should by imported from outside
        entry_uuid = im_uuid.
        IF entry_uuid IS INITIAL.
          MESSAGE e004
                  RAISING uuid_error.
        ENDIF.

    ENDCASE.

    get_current_bank_action( ).

**create instance of message collector
*    CREATE OBJECT messages
*      EXPORTING
*        i_message_key  = entry_uuid
*        i_main_program = lc_program
*        i_class        = lc_message_id.

    messages = zcl_bank_logger_protocal=>add_message_collector(
                 EXPORTING
                   im_default_message_class = lc_message_id
                   im_mainprogram           = lc_program
                   im_uuid                  = entry_uuid ).
  ENDMETHOD.


METHOD convert_paymorder_to_paymentry.
*    start log
    MESSAGE i121(ztr_bank_application)
            WITH payment_order-paymorder
                 entry_uuid
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = entry_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = bank_action
                      log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                      log_obj      = entry_uuid
                      paymorder    = payment_order-paymorder ) ).
*    end log

    convert_paymord_to_entry_core( read_payment_order( ) ).

*    start log
    MESSAGE i122(ztr_bank_application)
            WITH payment_order-paymorder
                 entry_uuid
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = entry_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = bank_action
                      bank_ind     = payment_entry-bank_ind
                      log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                      log_obj      = entry_uuid
                      paymorder    = payment_order-paymorder ) ).
*    end log
  ENDMETHOD.


METHOD convert_paymord_to_entry_core.

    MOVE: im_s_payment_order-bank_ind   TO payment_entry-bank_ind,              "银行标志
          im_s_payment_order-docno      TO payment_entry-paymorder,             "支付单号码
          im_s_payment_order-zzffs      TO payment_entry-zzffs,                 "支付方式
          im_s_payment_order-zzftype    TO payment_entry-zzftype,                "支付单类型
*          im_s_payment_order-zversion   TO payment_entry-paymorder_version,     "支付单版本
          im_s_payment_order-bukrs      TO payment_entry-zbukr,                 "支付单的公司代码
          im_s_payment_order-zzfwaers   TO payment_entry-waers,                 "支付单的货币
          im_s_payment_order-zzfwrbtr   TO payment_entry-rwbtr,                 "支付单的金额
          im_s_payment_order-banks      TO payment_entry-bnks1,                 "支付单付款银行的国家代码
          im_s_payment_order-zfhbkid    TO payment_entry-hbkid,
          im_s_payment_order-zfhktid    TO payment_entry-hktid,
          im_s_payment_order-zfkbankl   TO payment_entry-bnkl1,                 "支付单付款银行
          im_s_payment_order-zfkbnkn    TO payment_entry-bnkn1,                 "支付单付款账户
          im_s_payment_order-pzhmc      TO payment_entry-pzhmc,
          im_s_payment_order-zskno      TO payment_entry-zskno,
          im_s_payment_order-zsbukrs    TO payment_entry-zsbukrs,
          im_s_payment_order-zszhmc     TO payment_entry-zszhmc,
          im_s_payment_order-zshbkid    TO payment_entry-zhbkid,
          im_s_payment_order-zshktid    TO payment_entry-zhktid,
          im_s_payment_order-zskbankl   TO payment_entry-zbnky,                 "支付单的收款银行
          im_s_payment_order-zskbanka   TO payment_entry-zbnka,                 "支付单的收款银行代码(联行号)
          im_s_payment_order-zskbnkn    TO payment_entry-zbnkn,                 "支付单的收款银行账户
          im_s_payment_order-zsknam     TO payment_entry-koinh.                 "支付单的收款人名称
*    目前有些供应商名称中带有空格，特别是员工供应商的名称，例如"李小名" 在LFA1中为"李 小名"
    CONDENSE payment_entry-koinh NO-GAPS.

    set_partner_code_and_type(
                EXPORTING
                  im_zfmark = im_s_payment_order-zfmark
                  im_zskno = im_s_payment_order-zskno
                IMPORTING
                  ex_gpa1t = payment_entry-gpa1t
                  ex_gpa1r = payment_entry-gpa1r ).

    IF payment_entry-zzftype = 'T004'.
      IF payment_entry-koinh IS INITIAL.
*  同户名转账的支付单，支付单抬头没有收款人名称
*  从账户台帐读取
        SELECT SINGLE zhmc
               INTO payment_entry-koinh
               FROM ztrt0013
               WHERE bukrs = payment_entry-zbukr
               AND   hbkid = payment_entry-zhbkid
               AND   hktid = payment_entry-zhktid.
      ENDIF.
    ENDIF.

    payment_entry-entuuid = entry_uuid.
    payment_entry-doc1r = payment_entry-paymorder.
  ENDMETHOD.


METHOD create_instance_from_paymorder.
    DATA: l_class TYPE string.

*    SELECT SINGLE zzftype INTO @DATA(l_zzftype)
*           FROM ztrt2001
*           WHERE docno = @im_s_payment_order-paymorder.
*    IF sy-subrc <> 0.
*      MESSAGE e005
*              WITH im_s_payment_order-paymorder
*              RAISING error.
*    ENDIF.

*    CASE im_action.
*      WHEN 'M01'.
*        CREATE OBJECT ex_o_instance TYPE zcl_bank_payment_entry_edoc
*          EXPORTING
*            im_creation_type    = zcl_bank_payment_entry=>create_from_payment_order
*            im_s_payment_order  = im_s_payment_order
*          EXCEPTIONS
*            creation_type_error = 1
*            create_uuid_error   = 2
*            uuid_error          = 3.
*      when '001' or '011'.
*        CREATE OBJECT ex_o_instance
*          EXPORTING
*            im_creation_type    = zcl_bank_payment_entry=>create_from_payment_order
*            im_s_payment_order  = im_s_payment_order
*          EXCEPTIONS
*            creation_type_error = 1
*            create_uuid_error   = 2
*            uuid_error          = 3.
*        when OTHERS.
*          MESSAGE e265
*                  with im_action
*                  RAISING error.
*    ENDCASE.
    SELECT SINGLE entry_cls INTO @DATA(l_entry_class)
           FROM ztrt_act_entry
           WHERE action = @im_action.
    IF sy-subrc = 0.
      CREATE OBJECT ex_o_instance TYPE (l_entry_class)
        EXPORTING
          im_creation_type    = zcl_bank_payment_entry=>create_from_payment_order
          im_s_payment_order  = im_s_payment_order
        EXCEPTIONS
          creation_type_error = 1
          create_uuid_error   = 2
          uuid_error          = 3.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid
                TYPE sy-msgty
                NUMBER sy-msgno
                WITH sy-msgv1
                     sy-msgv2
                     sy-msgv3
                     sy-msgv4
               RAISING error.
      ENDIF.
    ELSE.
      MESSAGE e265
              WITH im_action
              RAISING error.
    ENDIF.
  ENDMETHOD.


METHOD dequeue.
*    start log
    MESSAGE i146(ztr_bank_application)
            WITH payment_entry-paymorder
                 entry_uuid
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = entry_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = bank_action
                      log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                      log_obj      = entry_uuid
                      paymorder    = payment_order-paymorder ) ).
*    end log

**    dequeue payment order
*    IF instance_creation_type = create_from_payment_entry .
*      dequeue_payment_order( ).  "支付单在支付平台锁定
*    ENDIF.
*    dequeue payment entry

    dequeue_payment_order( ).
    dequeue_payment_entry( ).

*    start log
    MESSAGE i147(ztr_bank_application)
            WITH payment_entry-paymorder
                 entry_uuid
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = entry_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = bank_action
                      log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                      log_obj      = entry_uuid
                      paymorder    = payment_order-paymorder ) ).
*    end log
  ENDMETHOD.


METHOD dequeue_payment_entry.
    CALL FUNCTION 'DEQUEUE_EZPAYMENTRY'
      EXPORTING
        mode_ztrt_payment = 'E'
        mandt             = sy-mandt
        entuuid           = entry_uuid
        x_entuuid         = ' '
        _scope            = '3'
        _synchron         = ' '
        _collect          = ' '.
*    start log
    MESSAGE i145(ztr_bank_application)
            WITH entry_uuid
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = entry_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = bank_action
                      log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                      log_obj      = entry_uuid
                      paymorder    = payment_order-paymorder ) ).
*    end log
  ENDMETHOD.


METHOD dequeue_payment_order.
*    CALL FUNCTION 'DEQUEUE_EZTRT2001'
*      EXPORTING
*        mode_ztrt2001 = 'E'
*        mandt         = sy-mandt
*        docno         = payment_order-paymorder
*        x_docno       = ' '
*        _scope        = '3'
*        _synchron     = ' '
*        _collect      = ' '.
    CALL FUNCTION 'ZFM_TR_DELOCK_PAYMENTORDER'
      EXPORTING
        im_docno = payment_order-paymorder.

*    start log
    MESSAGE i144(ztr_bank_application)
            WITH entry_uuid
                 payment_order-paymorder
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = entry_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = bank_action
                      log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                      log_obj      = entry_uuid
                      paymorder    = payment_order-paymorder ) ).
*    end log

  ENDMETHOD.


METHOD destroy.
*    start log
    MESSAGE i142(ztr_bank_application)
            WITH payment_order-paymorder
                 entry_uuid
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = entry_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = bank_action
                      bank_ind     = payment_entry-bank_ind
                      log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                      log_obj      = entry_uuid
                      paymorder    = payment_order-paymorder ) ).
*    end log

    CLEAR: instance_creation_type,
           payment_order,
           payment_entry.
*           payment_order_status.

    dequeue( ).

*    start log
    MESSAGE i143(ztr_bank_application)
            WITH payment_order-paymorder
                 entry_uuid
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = entry_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = bank_action
                      bank_ind     = payment_entry-bank_ind
                      log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                      log_obj      = entry_uuid
                      paymorder    = payment_order-paymorder ) ).
*    end log
  ENDMETHOD.


METHOD enqueue.
*    enqueue the payment order
*    enqueue_payment_order( ). "---支付单在支付平台已经锁定
*    IF INSTANCE_CREATION_TYPE = create_from_payment_entry.
**    enqueue the payment order
*      enqueue_payment_order( ).
*    ENDIF.

    enqueue_payment_order( ).

*enqueue the payment entry
    enqueue_payment_entry( ).
  ENDMETHOD.


METHOD enqueue_payment_entry.
*    start log
    MESSAGE i115(ztr_bank_application)
            WITH entry_uuid
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = entry_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = bank_action
                      log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                      log_obj      = entry_uuid
                      paymorder    = payment_order-paymorder ) ).
*    end log

    CALL FUNCTION 'ENQUEUE_EZPAYMENTRY'
      EXPORTING
        mode_ztrt_payment = 'E'
        mandt             = sy-mandt
        entuuid           = entry_uuid
        x_entuuid         = ' '
        _scope            = '2'
        _wait             = ' '
        _collect          = ' '
      EXCEPTIONS
        foreign_lock      = 1
        system_failure    = 2
        OTHERS            = 3.
    IF sy-subrc <> 0.
*    start log
      MESSAGE ID sy-msgid
              TYPE sy-msgty
              NUMBER sy-msgno
              WITH sy-msgv1
                   sy-msgv2
                   sy-msgv3
                   sy-msgv4
              INTO dummy_message.

      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = entry_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = bank_action
                        log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                        log_obj      = entry_uuid
                        paymorder    = payment_order-paymorder ) ).
*    end log
    ELSE.
*    start log
      MESSAGE i116(ztr_bank_application)
              WITH entry_uuid
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = entry_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = bank_action
                        log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                        log_obj      = entry_uuid
                        paymorder    = payment_order-paymorder ) ).
*    end log
    ENDIF.

  ENDMETHOD.


METHOD enqueue_payment_order.
**    start log
*    MESSAGE i113(ztr_bank_application)
*            WITH entry_uuid
*                 payment_order-paymorder
*            INTO dummy_message.
*    zcl_bank_logger_protocal=>add_log(
*             VALUE #( uuid         = entry_uuid
*                      msgid        = sy-msgid
*                      msgno        = sy-msgno
*                      msgty        = sy-msgty
*                      msgv1        = sy-msgv1
*                      msgv2        = sy-msgv2
*                      msgv3        = sy-msgv3
*                      msgv4        = sy-msgv4
*                      message      = dummy_message
*                      bank_action  = bank_action
*                      log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
*                      log_obj      = entry_uuid
*                      paymorder    = payment_order-paymorder ) ).
**    end log
*
*    CALL FUNCTION 'ENQUEUE_EZTRT2001'
*      EXPORTING
*        mode_ztrt2001  = 'E'
*        docno          = payment_order-paymorder
*        x_docno        = ' '
*        _scope         = '2'
*        _wait          = ' '
*        _collect       = ' '
*      EXCEPTIONS
*        foreign_lock   = 1
*        system_failure = 2
*        OTHERS         = 3.
*    IF sy-subrc <> 0.
**    start log
*      MESSAGE ID sy-msgid
*              TYPE sy-msgty
*              NUMBER sy-msgno
*              WITH sy-msgv1
*                   sy-msgv2
*                   sy-msgv3
*                   sy-msgv4
*              INTO dummy_message.
*      zcl_bank_logger_protocal=>add_log(
*               VALUE #( uuid         = entry_uuid
*                        msgid        = sy-msgid
*                        msgno        = sy-msgno
*                        msgty        = sy-msgty
*                        msgv1        = sy-msgv1
*                        msgv2        = sy-msgv2
*                        msgv3        = sy-msgv3
*                        msgv4        = sy-msgv4
*                        message      = dummy_message
*                        bank_action  = bank_action
*                        log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
*                        log_obj      = entry_uuid
*                        paymorder    = payment_order-paymorder ) ).
**    end log
*    ELSE.
**    start log
*      MESSAGE i114(ztr_bank_application)
*              WITH entry_uuid
*                   payment_order-paymorder
*              INTO dummy_message.
*      zcl_bank_logger_protocal=>add_log(
*               VALUE #( uuid         = entry_uuid
*                        msgid        = sy-msgid
*                        msgno        = sy-msgno
*                        msgty        = sy-msgty
*                        msgv1        = sy-msgv1
*                        msgv2        = sy-msgv2
*                        msgv3        = sy-msgv3
*                        msgv4        = sy-msgv4
*                        message      = dummy_message
*                        bank_action  = bank_action
*                        log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
*                        log_obj      = entry_uuid
*                        paymorder    = payment_order-paymorder ) ).
**    end log
*    ENDIF.

    CALL FUNCTION 'ZFM_TR_LOCK_PAYMENTORDER'
      EXPORTING
        im_docno       = payment_order-paymorder
      EXCEPTIONS
        foreign_lock   = 1
        system_failure = 2
        OTHERS         = 3.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid
              TYPE sy-msgty
              NUMBER sy-msgno
              WITH sy-msgv1
                   sy-msgv2
                   sy-msgv3
                   sy-msgv4
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = entry_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = bank_action
                        log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                        log_obj      = entry_uuid
                        paymorder    = payment_order-paymorder ) ).
    ENDIF.
  ENDMETHOD.


method EXPORT_ENTRY.
    rs_payment_entry = payment_entry.
  endmethod.


METHOD feedback_from_bank.
*    start log
    MESSAGE i197(ztr_bank_application)
            WITH bank_action
                 zcl_bank_enviroment=>s_get_bank_action_text( bank_action )
                 payment_entry-entuuid
                 payment_entry-bank_ind
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = entry_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = bank_action
                      bank_ind = payment_entry-bank_ind
                      log_obj = payment_entry-entuuid
                      log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                      bank_func = im_s_bank_feedback-bank_func
                      paymorder = payment_entry-paymorder ) ).
*    end log

    IF im_s_bank_error_step-int IS NOT INITIAL.
      feedback_from_bank_step_error( im_s_bank_error_step ).
    ELSE.
      feedback_from_bank_response( im_s_bank_feedback ).
    ENDIF.

*    save_entry( ).
*    set_status( payment_entry-entstatus ).

*    start log
    MESSAGE i198(ztr_bank_application)
            WITH bank_action
                 zcl_bank_enviroment=>s_get_bank_action_text( bank_action )
                 payment_entry-entuuid
                 payment_entry-bank_ind
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = entry_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = bank_action
                      bank_ind = payment_entry-bank_ind
                      log_obj = payment_entry-entuuid
                      log_obj_type = ZCL_BANK_APPLICATION_LOGGER=>LOG_OBJECT_TYPE_PAYMENT_ENTRY
                      bank_func = im_s_bank_feedback-bank_func
                      paymorder = payment_entry-paymorder ) ).
*    end log
  ENDMETHOD.


METHOD feedback_from_bank_response.
    refresh_entry( im_s_bank_feedback-entuuid ).
    MOVE: im_s_bank_feedback-entstatus        TO payment_entry-entstatus,
          im_s_bank_feedback-rtntype          TO payment_entry-rtntype,
*          im_s_bank_feedback-bank_func        TO payment_entry-bank_func,
          im_s_bank_feedback-bank_rtncode     TO payment_entry-bank_rtncode,
          im_s_bank_feedback-bank_rtnmsg      TO payment_entry-bank_rtnmsg,
          im_s_bank_feedback-bank_reqsts      TO payment_entry-bank_reqsts,
          im_s_bank_feedback-bank_rtnflg      TO payment_entry-bank_rtnflg,
          im_s_bank_feedback-bank_msgseq      to payment_entry-bank_msgseq,
          im_s_bank_feedback-adjust_returncode to payment_entry-adjust_returncode,
          im_s_bank_feedback-draft_zpj_no     to payment_entry-draft_zpj_no.
*          im_s_bank_feedback-bank_tran_number TO payment_entry-bank_tran_number.
    IF instance_creation_type = create_from_payment_order.
      MOVE im_s_bank_feedback-bank_func        TO payment_entry-bank_func.
      MOVE im_s_bank_feedback-bank_tran_number TO payment_entry-bank_tran_number.
    ENDIF.

    set_status( payment_entry-entstatus ).
  ENDMETHOD.


METHOD feedback_from_bank_step_error.

*    SELECT SINGLE entstatus INTO @DATA(l_status)
*           FROM ztrt_entbk_map
*           WHERE instance_err = @im_s_bank_error_step-instance_error_code.
*    IF sy-subrc <> 0.
**      critical technical error
*      MESSAGE x092 WITH im_s_bank_error_step-instance_error_code.
*    ENDIF.
    refresh_entry( entry_uuid ).

    zcl_bank_enviroment=>s_get_status_by_error_step(
                       EXPORTING
                          im_bank_ind = payment_entry-bank_ind
                          im_action = bank_action
                          im_step = im_s_bank_error_step-step
                          im_instance_err = im_s_bank_error_step-instance_error_code
                       IMPORTING
                         e_status = DATA(l_status)
                       EXCEPTIONS
                         not_found = 1 ).
    IF sy-subrc <> 0.
*   critical error
      MESSAGE ID sy-msgid
              TYPE 'X'
              NUMBER sy-msgno
              WITH sy-msgv1
                   sy-msgv2
                   sy-msgv3
                   sy-msgv4.
    ENDIF.

*    add_system_msg_01 996
*                      im_s_bank_error_step-msg.
    MESSAGE e990(ztr_bank_application)
            WITH im_s_bank_error_step-msg
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = entry_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = bank_action
                      bank_ind     = payment_entry-bank_ind
                      log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                      log_obj      = entry_uuid
                      paymorder    = payment_order-paymorder ) ).



    set_status( l_status ).

  ENDMETHOD.


method GET_BANK_INDICATOR.
    re_bank_indicator = payment_entry-bank_ind.
  endmethod.


METHOD get_current_bank_action.
    DATA(lo_action) = zcl_bank_abstract_action=>get_action( ).
    IF lo_action IS BOUND.
      bank_action = zcl_bank_abstract_action=>get_action( )->get_action_code( ).
    ENDIF.
  ENDMETHOD.


METHOD get_entry_status_text.
    SELECT SINGLE ltext
           INTO r_text
           FROM ztrt_entstatust
           WHERE entstatus = im_entry_status
           AND   spras = sy-langu.
    IF sy-subrc <> 0.
      SELECT SINGLE ltext
             INTO r_text
             FROM ztrt_entstatust
             WHERE entstatus = im_entry_status
             and   spras = sy-langu.
    ENDIF.
  ENDMETHOD.


method GET_PAYMENT_KEY.
    rs_key-paymorder = payment_entry-paymorder.
    rs_key-draft_zxh = payment_entry-draft_zxh.
  endmethod.


METHOD GET_REFERENCE_DOC.
    re_reference_doc = payment_entry-doc1r.
  ENDMETHOD.


method GET_UUID.
    re_uuid = entry_uuid.
  endmethod.


METHOD if_check_status.
    SELECT SINGLE check_status INTO re_check
           FROM ztrt_entstatus
           WHERE entstatus = payment_entry-entstatus.
  ENDMETHOD.


method IF_ERROR.
    re_error = messages->if_error( ).
  endmethod.


method IF_TRIGER_BY_ACCOUNT_TRANX.
    RE_TRIGER_BY_ACCOUNT_TRANX = TRIGGER_BY_ACCOUNT_TRANX.
  endmethod.


METHOD import_status_from_bank.
    payment_entry-bank_rtncode = im_s_staus_from_bank-bank_rtncode.
    payment_entry-bank_rtnmsg = im_s_staus_from_bank-bank_rtnmsg.
    set_status( im_s_staus_from_bank-entstatus ).
  ENDMETHOD.


METHOD insert_entry_for_starting.

    convert_paymorder_to_paymentry( ).
*    return_if_error.
    set_date_sequence( ).

    adjust_field_for_inserting( ).
*    set_bank_reference( ).

*尽快把记录保存到支付条目的数据库表中
*此时的状态为空

    save_entry( ).

*支付单正式进入银企直连
*状态设置为 - 支付指令进入银企直连功能
    payment_entry-entstatus = entry_status_app_process.

    check_bank( ).
    IF if_error( ) = no.
*检查支付条目
      check_for_new_entry( ).
    ENDIF.

    IF if_error( ) = yes.
      payment_entry-entstatus = entry_status_app_reject.
    ENDIF.

**保存新的状态
*    save_entry( ).
    set_status( payment_entry-entstatus ).

  ENDMETHOD.


METHOD log_status.
    SELECT SINGLE entstatus INTO @DATA(l_entry_db_status)
           FROM ztrt_payment
           WHERE entuuid = @entry_uuid.
    SELECT SINGLE ltext INTO @DATA(l_entry_db_status_text)
           FROM ztrt_entstatust
           WHERE entstatus = @l_entry_db_status
           and   spras = @sy-langu.
    SELECT SINGLE zzfstatus INTO @DATA(l_paymorder_status)
            FROM ztrt2001
            WHERE docno = @payment_entry-paymorder.
    SELECT SINGLE zapprod INTO @DATA(l_paymorder_status_text)
           FROM ztrt9036
           WHERE doctype = 'P002'
           AND   zappro = @l_paymorder_status.
    SELECT SINGLE ordstatus INTO @DATA(l_linkage_status)
           FROM ztrt_paymlink
           WHERE paymorder = @payment_entry-paymorder
           and   draft_zxh = @payment_entry-draft_zxh.
    SELECT SINGLE zapprod INTO @DATA(l_linkage_status_text)
           FROM ztrt9036
           WHERE doctype = 'P002'
           AND   zappro = @l_linkage_status.
    CONCATENATE '当前状态:支付条目-'
                l_entry_db_status
                '('
                l_entry_db_status_text
                '),'
                '支付单-'
                l_paymorder_status
                '('
                l_paymorder_status_text
                '),'
                '状态连接-'
                l_linkage_status
                '('
                l_linkage_status_text
                ').'
                INTO dummy_message.
    CONDENSE dummy_message NO-GAPS.

*    start log
    MESSAGE i995(ztr_bank_application)
            WITH dummy_message
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = entry_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = bank_action
                      bank_ind     = payment_entry-bank_ind
                      log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                      log_obj      = entry_uuid
                      paymorder    = payment_order-paymorder ) ).
*    end log


  ENDMETHOD.


METHOD read_data_by_payer_accountkey.
    SELECT SINGLE * INTO @DATA(ls_0013)
               FROM ztrt0013
               WHERE bukrs = @im_bukrs
               AND   hbkid = @im_hbkid
               AND   hktid = @im_hktid.
    IF sy-subrc <> 0.
*    start log
      MESSAGE e090(ztr_bank_application)
              WITH im_bukrs
                   im_hbkid
                   im_hktid
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = entry_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = bank_action
                        log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                        log_obj      = entry_uuid
                        bank_ind     = payment_entry-bank_ind
                        paymorder    = payment_order-paymorder ) ).
*    end log
    ELSE.
      MOVE: ls_0013-bank_ind  TO ex_bank_indicator,
            ls_0013-zhmc      TO ex_zhmc.
    ENDIF.
  ENDMETHOD.


METHOD read_paymentorder_header.
    SELECT SINGLE docno
                     bukrs
                     butxt
                     zzfstatus
                     zfmark
                     zskno
                     zsknam
                     zzfwaers
                     zzfwrbtr
                     zzftype
                     zzffs
                     del_flg
                     remark
                     INTO CORRESPONDING FIELDS OF ex_s_s2001
                     FROM ztrt2001
                     WHERE docno = payment_order-paymorder.
    IF sy-subrc <> 0.
      ex_not_exited = yes.

      ex_s_s2001-docno = payment_order-paymorder.

      MESSAGE e118(ztr_bank_application)
              WITH entry_uuid
                   payment_order-paymorder
*                   '30'
              INTO dummy_message.
*    start log
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = entry_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = bank_action
                        log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                        log_obj      = entry_uuid
                        bank_ind     = payment_entry-bank_ind
                        paymorder    = payment_order-paymorder ) ).
      RETURN.
*    end log
    ELSE.

      ex_not_exited = no.

*      IF ex_s_s2001-zskno IS NOT INITIAL.
*        SELECT SINGLE vbund INTO @DATA(l_vbund)
*               FROM lfa1
*               WHERE lifnr = @ex_s_s2001-zskno.
*        IF l_vbund IS NOT INITIAL.
*          CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
*            EXPORTING
*              input  = l_vbund
*            IMPORTING
*              output = ex_s_s2001-zsbukrs.
*        ENDIF.
*      ENDIF.
      IF ex_s_s2001-zskno  IS NOT INITIAL AND
         ex_s_s2001-zfmark IS NOT INITIAL.
        ex_s_s2001-zsbukrs = set_zsbukrs(
                    im_zfmark = ex_s_s2001-zfmark
                    im_zskno = ex_s_s2001-zskno ).
      ENDIF.
      IF ex_s_s2001-del_flg = yes.
        MESSAGE e266(ztr_bank_application)
                WITH entry_uuid
                     payment_order-paymorder
                INTO dummy_message.
        zcl_bank_logger_protocal=>add_log(
                 VALUE #( uuid         = entry_uuid
                          msgid        = sy-msgid
                          msgno        = sy-msgno
                          msgty        = sy-msgty
                          msgv1        = sy-msgv1
                          msgv2        = sy-msgv2
                          msgv3        = sy-msgv3
                          msgv4        = sy-msgv4
                          message      = dummy_message
                          bank_action  = bank_action
                          log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                          log_obj      = entry_uuid
                          bank_ind     = payment_entry-bank_ind
                          paymorder    = payment_order-paymorder ) ).
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD read_paymentorder_payee_data.
    SELECT SINGLE hbkid AS zshbkid
                       hktid AS zshktid
                       zskbankl
                       zskbnkn
                       zskbanka
                       INTO ex_s_s2002
                       FROM ztrt2002
                       WHERE docno = payment_order-paymorder.
    IF sy-subrc <> 0.
*    start log
      MESSAGE e120(ztr_bank_application)
              WITH entry_uuid
                   payment_order-paymorder
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = entry_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = bank_action
                        log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                        log_obj      = entry_uuid
                        bank_ind     = payment_entry-bank_ind
                        paymorder    = payment_order-paymorder ) ).
*    end log
*      RETURN.
    ENDIF.
  ENDMETHOD.


METHOD read_paymentorder_payer_data.
    SELECT SINGLE hbkid AS zfhbkid
               hktid AS zfhktid
               zfkbankl
               zfkbnkn
               banks
               INTO ex_s_s2003
               FROM ztrt2003
               WHERE docno = payment_order-paymorder.
    IF sy-subrc <> 0.
*    start log
      MESSAGE e119(ztr_bank_application)
              WITH entry_uuid
                   payment_order-paymorder
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = entry_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = bank_action
                        log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                        log_obj      = entry_uuid
                        bank_ind     = payment_entry-bank_ind
                        paymorder    = payment_order-paymorder ) ).
*    end log
    ENDIF.
  ENDMETHOD.


METHOD read_payment_order.
*    DATA: l_order_existed TYPE flag.
*    start log
    MESSAGE i117(ztr_bank_application)
            WITH payment_order-paymorder
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = entry_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = bank_action
                      log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                      log_obj      = entry_uuid
                      paymorder    = payment_order-paymorder ) ).
*    end log

    rs_payment_order = read_payment_order_core( ).


*    start log
    MESSAGE i125(ztr_bank_application)
            WITH payment_order-paymorder
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = entry_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = bank_action
                      bank_ind     = rs_payment_order-bank_ind
                      log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                      log_obj      = entry_uuid
                      paymorder    = payment_order-paymorder ) ).
*    end log

  ENDMETHOD.


METHOD read_payment_order_core.
    read_paymentorder_header(
            IMPORTING
              ex_s_s2001    = rs_payment_order-s001
              ex_not_exited = DATA(l_not_exited) ).

    IF l_not_exited = no.
      read_paymentorder_payer_data(
                IMPORTING
                  ex_s_s2003 = rs_payment_order-s003 ).
      read_paymentorder_payee_data(
                IMPORTING
                  ex_s_s2002 = rs_payment_order-s002 ).
      read_data_by_payer_accountkey(
               EXPORTING
                 im_bukrs = rs_payment_order-bukrs
                 im_hbkid = rs_payment_order-zfhbkid
                 im_hktid = rs_payment_order-zfhktid
               IMPORTING
                 ex_bank_indicator = rs_payment_order-bank_ind
                 ex_zhmc           = rs_payment_order-pzhmc ).

      IF rs_payment_order-s001-zsbukrs IS NOT INITIAL AND
         rs_payment_order-s002-zshbkid IS NOT INITIAL AND
         rs_payment_order-s002-zshktid IS NOT INITIAL.
        SELECT SINGLE zhmc INTO rs_payment_order-s002-zszhmc
               FROM ztrt0013
               WHERE bukrs = rs_payment_order-s001-zsbukrs
               AND hbkid = rs_payment_order-s002-zshbkid
               AND  hktid = rs_payment_order-s002-zshktid.
      ELSE.
        rs_payment_order-s002-zszhmc = rs_payment_order-s001-zsknam.
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD refresh_entry.
*    refresh entry from db
    SELECT SINGLE * INTO payment_entry
           FROM ztrt_payment
           WHERE entuuid = im_entry_uuid.
    IF sy-subrc <> 0 .
*  不可能发生的错误
      MESSAGE x997 WITH 'REFRESH_ENTRY'.
    ENDIF.

    entry_uuid              = payment_entry-entuuid.
    payment_order-paymorder = payment_entry-paymorder.
  ENDMETHOD.


METHOD save_entry.
    DATA: l_entry_not_update   TYPE flag,
          l_linkage_not_update TYPE flag.

*    start log
    MESSAGE i123(ztr_bank_application)
            WITH payment_order-paymorder
                 entry_uuid
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = entry_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = bank_action
                      bank_ind     = payment_entry-bank_ind
                      log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                      log_obj      = entry_uuid
                      paymorder    = payment_order-paymorder ) ).
*    end log

    IF payment_entry-entstatus IS NOT INITIAL.
      DATA(ls_payment_order_linkage) = build_paymorder_linkage( ).
*      return_if_error.
    ENDIF.

    set_process_msg_to_entry( ).

    CALL FUNCTION 'ZFM_TR_SAVE_PAYMENT_ENTRY'
      EXPORTING
        im_s_payment_entry    = payment_entry
        im_s_payment_linkage  = ls_payment_order_linkage
        im_commit             = yes
      IMPORTING
        ex_entry_not_update   = l_entry_not_update
        ex_linkage_not_update = l_linkage_not_update.
    IF l_entry_not_update = yes.
*      不应该出现的错误，有这个错误程序无法处理
      MESSAGE e015(ztr_bank_application)
              WITH payment_entry-entuuid.
    ENDIF.

    IF ls_payment_order_linkage IS NOT INITIAL AND
        l_linkage_not_update = yes.
*      不应该出现的错误，有这个错误程序无法处理
      MESSAGE e016(ztr_bank_application)
              WITH payment_entry-entuuid
                   payment_entry-paymorder.
    ENDIF.

*    start log
    log_status( ).

    MESSAGE i127(ztr_bank_application)
            WITH payment_order-paymorder
                 entry_uuid
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = entry_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = bank_action
                      bank_ind     = payment_entry-bank_ind
                      log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                      log_obj      = entry_uuid
                      paymorder    = payment_order-paymorder ) ).

    MESSAGE i128(ztr_bank_application)
            WITH payment_order-paymorder
                 entry_uuid
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = entry_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = bank_action
                      bank_ind     = payment_entry-bank_ind
                      log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                      log_obj      = entry_uuid
                      paymorder    = payment_order-paymorder ) ).

*    end log
  ENDMETHOD.


METHOD set_by_payment_entry.
*enqueue the objects
    enqueue( ).

    refresh_entry( entry_uuid ).

  ENDMETHOD.


METHOD set_by_payment_order.
*    start log
    MESSAGE i112(ztr_bank_application)
            WITH payment_order-paymorder
                 entry_uuid
                 bank_action
                 zcl_bank_enviroment=>s_get_bank_action_text( bank_action )
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = entry_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = bank_action
                      log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                      log_obj      = entry_uuid
                      paymorder    = payment_order-paymorder ) ).
*    end log

*enqueue the objects
    enqueue( ).

*insert a new payment entry
    insert_entry_for_starting( ).

*    start log
    MESSAGE i131(ztr_bank_application)
            WITH payment_order-paymorder
                 entry_uuid
                 bank_action
                 zcl_bank_enviroment=>s_get_bank_action_text( bank_action )
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = entry_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = bank_action
                      bank_ind     = payment_entry-bank_ind
                      log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                      log_obj      = entry_uuid
                      paymorder    = payment_order-paymorder ) ).
*    end log
  ENDMETHOD.


METHOD set_date_sequence.
    SELECT SINGLE seqcontrol INTO @DATA(l_seqcontrol)
           FROM ztrt_bank
           WHERE bank_ind = @payment_entry-bank_ind.
    IF l_seqcontrol IS INITIAL.
      RETURN.
    ENDIF.

    DATA(lo_enviroment) = zcl_bank_enviroment=>create(
                                                 im_bank_indicator = payment_entry-bank_ind
                                                 im_action = bank_action ).
    lo_enviroment->check( ).
    IF if_error( ) = no.
      payment_entry-date_sequence = lo_enviroment->generate_date_sequence( ).
    ENDIF.

    lo_enviroment->publish_messages(
                  IMPORTING
                    et_messages = DATA(lt_messages) ).

    DELETE lt_messages WHERE type <> 'E'
                       AND   type <> 'A'
                         AND type <> 'X'.
    IF lt_messages IS NOT INITIAL.
*      messages->import_messages( lt_messages ).
      zcl_bank_logger_protocal=>import_messages(
                                   im_t_messages = lt_messages
                                   im_uuid = entry_uuid
                                   im_s_log_businessdata_data = VALUE #(
                                                                          bank_ind = payment_entry-bank_ind
                                                                          bank_action = bank_action
                                                                          log_obj = entry_uuid
                                                                          log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                                                                          paymorder = payment_entry-paymorder ) ).
    ENDIF.
  ENDMETHOD.


METHOD set_entry.
    CASE instance_creation_type.
      WHEN create_from_payment_order.
        set_by_payment_order( ).
      WHEN create_from_payment_entry.
        set_by_payment_entry( ).
    ENDCASE.
  ENDMETHOD.


METHOD set_partner_code_and_type.

    MOVE im_zskno TO ex_gpa1r.

    CASE im_zfmark.
      WHEN '10'.
*        供应商
        ex_gpa1t = '11'.
      WHEN '20'.
*        客户
        ex_gpa1t = '12'.
    ENDCASE.
  ENDMETHOD.


method SET_PAYER_ACCOUNT_NAME.
  endmethod.


METHOD set_process_msg_to_entry.
    SELECT SINGLE error_flag INTO @DATA(l_error_flag)
           FROM ztrt_entstatus
           WHERE entstatus = @payment_entry-entstatus.
    IF l_error_flag = space.
      payment_entry-process_msg = payment_entry-bank_rtnmsg.
      RETURN.
    ENDIF.

    CLEAR payment_entry-process_msg.
    LOOP AT messages->export_message_bapireturn( )
         INTO DATA(ls_message)
         WHERE type = 'E'.
      IF payment_entry-process_msg IS INITIAL.
        payment_entry-process_msg = ls_message-message.
      ELSE.
        payment_entry-process_msg = payment_entry-process_msg &&
                                     '/' &&
                                     ls_message-message.
      ENDIF.
      CONDENSE payment_entry-process_msg.
    ENDLOOP.

    IF payment_entry-process_msg IS INITIAL.
      payment_entry-process_msg = payment_entry-bank_rtnmsg.
    ENDIF.
  ENDMETHOD.


METHOD set_status.
*    SELECT SINGLE entstatus INTO @DATA(l_db_status)
*            FROM ztrt_payment
*            WHERE entuuid = @entry_uuid.
*    IF sy-subrc <> 0.
**      get old status
**  technical error
**  it should not happend at this point
*      MESSAGE e047(ztr_bank_application)
*              WITH entry_uuid
*                   'SET_STATUS'.
*      RETURN.
*    ENDIF.
*
**检查当前设置的新状态是否允许更新数据库表
*    SELECT COUNT( * ) INTO @DATA(l_count)
*            FROM ztrt_entstamap
*            WHERE insentstatus = @im_entry_status
*            AND   dbentstatus = @l_db_status.
*    IF l_count <= 0.
**  当前设置的状态不允许更新数据库表
*      RETURN.
*    ENDIF.

*设置新的状态
    payment_entry-entstatus = im_entry_status.

    save_entry( ).

  ENDMETHOD.


METHOD set_status_from_paymord_buffer.
    CONSTANTS: c_success_status      TYPE ztrt_payment-entstatus VALUE '300',
               c_success_status_type TYPE ztrt_payment-rtntype VALUE 'S'.

      MESSAGE i356(ztr_bank_application)
              WITH payment_entry-paymorder
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = entry_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = bank_action
                        log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                        log_obj      = entry_uuid
                        bank_ind     = payment_entry-bank_ind
                        paymorder    = payment_order-paymorder ) ).

    CALL FUNCTION 'ZFM_TR_IF_PAYMORDER_IN_BUFFER'
      EXPORTING
        im_paymorder = payment_entry-paymorder
      IMPORTING
        ex_existed   = ex_done.

    IF ex_done = no.
      RETURN.
    ENDIF.

    MOVE: c_success_status        TO payment_entry-entstatus,
          c_success_status_type   TO payment_entry-rtntype,
          TEXT-001                TO payment_entry-bank_rtnmsg.

      MESSAGE i357(ztr_bank_application)
              WITH payment_entry-paymorder
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = entry_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = bank_action
                        log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                        log_obj      = entry_uuid
                        bank_ind     = payment_entry-bank_ind
                        paymorder    = payment_order-paymorder ) ).

    set_status( payment_entry-entstatus ).

  ENDMETHOD.


METHOD set_status_from_transaction.
    DATA: l_done TYPE flag.

    set_status_from_paymord_buffer(
             IMPORTING
               ex_done = l_done ).

    IF l_done = yes.
      RETURN.
    ENDIF.

    set_status_from_tranx_db(
                 IMPORTING
                   ex_done = l_done ).

  ENDMETHOD.


METHOD set_status_from_tranx_db.
    CONSTANTS: c_success_status      TYPE ztrt_payment-entstatus VALUE '300',
               c_success_status_type TYPE ztrt_payment-rtntype VALUE 'S'.

    MESSAGE i359(ztr_bank_application)
            WITH payment_entry-paymorder
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = entry_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = bank_action
                      log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                      log_obj      = entry_uuid
                      bank_ind     = payment_entry-bank_ind
                      paymorder    = payment_order-paymorder ) ).

    SELECT COUNT( * ) INTO @DATA(l_count)
           FROM ztrt_bank_trans
           WHERE bukrs = @payment_entry-zbukr
           AND   hbkid = @payment_entry-hbkid
           AND   hktid = @payment_entry-hktid
           AND   yhzh = @payment_entry-bnkn1
           AND   paymorder = @payment_entry-paymorder.
    IF l_count < 1.
*      没有读取到数据
      ex_done = no.
      RETURN.
    ENDIF.

    MOVE: c_success_status        TO payment_entry-entstatus,
          c_success_status_type   TO payment_entry-rtntype,
          TEXT-001                TO payment_entry-bank_rtnmsg.

    MESSAGE i360(ztr_bank_application)
            WITH payment_entry-paymorder
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = entry_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = bank_action
                      log_obj_type = zcl_bank_application_logger=>log_object_type_payment_entry
                      log_obj      = entry_uuid
                      bank_ind     = payment_entry-bank_ind
                      paymorder    = payment_order-paymorder ) ).

    set_status( payment_entry-entstatus ).
  ENDMETHOD.


method SET_TRIGER_BY_ACCOUNT_TRANX.
    TRIGGER_BY_ACCOUNT_TRANX = yes.
  endmethod.


METHOD set_zsbukrs.
    DATA: l_vbund TYPE lfa1-vbund.
    CASE im_zfmark.
      WHEN '10'.
        SELECT SINGLE vbund INTO l_vbund
               FROM lfa1
               WHERE lifnr = im_zskno.
      WHEN '20'.
        SELECT SINGLE vbund INTO l_vbund
               FROM kna1
               WHERE kunnr = im_zskno.
      WHEN OTHERS.
        RETURN.
    ENDCASE.

    IF l_vbund IS NOT INITIAL.
      CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
        EXPORTING
          input  = l_vbund
        IMPORTING
          output = re_bukrs.
    ENDIF.

  ENDMETHOD.
ENDCLASS.
