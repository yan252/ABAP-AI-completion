class ZCL_TR2_BANK_INTERFACE_CBI definition
  public
  final
  create public .

public section.

  class-methods QUERY_FIXED_DEPOSIT
    importing
      !LT_IN type ZLTTR2_BANK_QUERY_DEPOSIT_IN
    returning
      value(LT_OUT) type ZLTTR2_BANK_QUERY_DEPOSIT_OUT .
  class-methods CONV_REGULAR_2_CURRENT
    importing
      !LT_IN type ZLTTR2_BANK_REGULAR2CURRENT_IN
    returning
      value(LT_OUT) type ZLTTR2_BANK_REGULAR2CURR_OUT .
  class-methods CHECK_STATUS
    importing
      !LT_IN type ZLTTR2_BANK_CHECK_STATUS_IN
    returning
      value(LT_OUT) type ZLTTR2_BANK_CHECK_STATUS_OUT .
protected section.
private section.
ENDCLASS.



CLASS ZCL_TR2_BANK_INTERFACE_CBI IMPLEMENTATION.


METHOD check_status.
    DATA:function_name TYPE rs38l-name.
    DATA:temp_in TYPE zlttr2_bank_check_status_in.
    DATA:temp_out TYPE zlttr2_bank_check_status_out.

    LOOP AT lt_in INTO DATA(ls_in) GROUP BY ls_in-bank_ind.
      function_name = 'ZFM_TR2_BANK_CHECK_STATUS_' && ls_in-bank_ind.
      LOOP AT lt_in INTO ls_in WHERE bank_ind = ls_in-bank_ind.
        APPEND ls_in TO temp_in.
      ENDLOOP.

      CALL FUNCTION 'FUNCTION_EXISTS'
        EXPORTING
          funcname           = function_name
        EXCEPTIONS
          function_not_exist = 1
          OTHERS             = 2.
      IF sy-subrc = 0 .
        CALL FUNCTION function_name
          EXPORTING
            lt_in  = temp_in
          IMPORTING
            lt_out = temp_out.
        APPEND LINES OF temp_out TO lt_out.
        CLEAR: temp_in,temp_out.
      ENDIF.

    ENDLOOP.
  ENDMETHOD.


METHOD conv_regular_2_current.
    DATA:function_name TYPE rs38l-name.
    DATA:temp_in TYPE zlttr2_bank_regular2current_in.
    DATA:temp_out TYPE zlttr2_bank_regular2curr_out.

    LOOP AT lt_in INTO DATA(ls_in) GROUP BY ls_in-bank_ind.
      function_name = 'ZFM_TR2_BANK_DQZH_' && ls_in-bank_ind.
      LOOP AT lt_in INTO ls_in WHERE bank_ind = ls_in-bank_ind.
        APPEND ls_in TO temp_in.
      ENDLOOP.

      CALL FUNCTION 'FUNCTION_EXISTS'
        EXPORTING
          funcname           = function_name
        EXCEPTIONS
          function_not_exist = 1
          OTHERS             = 2.
      IF sy-subrc = 0 .
        CALL FUNCTION function_name
          EXPORTING
            lt_in  = temp_in
          IMPORTING
            lt_out = temp_out.
        APPEND LINES OF temp_out TO lt_out.
        CLEAR: temp_in,temp_out.
      ENDIF.

    ENDLOOP.
  ENDMETHOD.


METHOD query_fixed_deposit.
    DATA:function_name TYPE rs38l-name.
    DATA:temp_in TYPE zlttr2_bank_query_deposit_in.
    DATA:temp_out TYPE zlttr2_bank_query_deposit_out.

    LOOP AT lt_in INTO DATA(ls_in) GROUP BY ls_in-bank_ind.
      function_name = 'ZFM_TR2_BANK_DQCX_' && ls_in-bank_ind.
      LOOP AT lt_in INTO ls_in WHERE bank_ind = ls_in-bank_ind.
        APPEND ls_in TO temp_in.
      ENDLOOP.

      CALL FUNCTION 'FUNCTION_EXISTS'
        EXPORTING
          funcname           = function_name
        EXCEPTIONS
          function_not_exist = 1
          OTHERS             = 2.
      IF sy-subrc = 0 .
        CALL FUNCTION function_name
          EXPORTING
            lt_in  = temp_in
          IMPORTING
            lt_out = temp_out.
        APPEND LINES OF temp_out TO lt_out.
        CLEAR: temp_in,temp_out.
      ENDIF.

    ENDLOOP.
  ENDMETHOD.
ENDCLASS.
