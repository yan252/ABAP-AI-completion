FUNCTION-POOL zfg_tr_common.                "MESSAGE-ID ..

*INCLUDE bdcrecxy_s .
*
*TYPES: BEGIN OF typ_0120_b,
*         docno   LIKE ztrt0120_1-docno,
*         item_no LIKE ztrt0120_1-item_no,
*         bukrs   LIKE ztrt0120-bukrs,
*         belnr   LIKE ztrt0120_1-belnr,
*         buzei   LIKE ztrt0120_1-buzei,
*         gjahr   LIKE ztrt0120_1-gjahr,
*         waerk   LIKE ztrt0120_1-waerk,
*         zbcskje LIKE ztrt0120_1-zbcskje,
*       END OF typ_0120_b.
*
*DEFINE set_msg.
*
*  APPEND VALUE #( type = &1 id = &2 number = &3 message = &4 message_v1 = &5 message_v2 = &6 message_v3 = &7 message_v4 = &8 ) TO lt_msg.
*
*END-OF-DEFINITION.
