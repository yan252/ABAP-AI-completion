*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZTRT9026
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZTRT9026            .

  PERFORM TABLEPROC.

ENDFUNCTION.
