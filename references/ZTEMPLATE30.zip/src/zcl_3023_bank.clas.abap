class ZCL_3023_BANK definition
  public
  create public .

public section.

  interfaces ZIF_3023_BANK .

  data MS_01 type ZTRT3022_01 .
  data MT_02 type ZTRTT_3022_02 .
  data MT_D02 type ZTRTT_3023_02 .
  data MS_D01 type ZTRT3023_01 .
  data MV_ZBKJYYE type ZTR_BKJYYE .
  data MV_HKTID type HKTID .

  methods CONSTRUCTOR
    importing
      !IV_BANKS type BANKS
      !IV_BANK_IND type ZTR_BANK_INDICATOR
      !IV_BUKRS type BUKRS optional
      !IV_HBKID type HBKID optional
      !IV_HKTID type HKTID optional
      !IV_VERSNO type VERSNO optional .
protected section.
private section.

  data MV_BANKS type BANKS .
  data MV_BANK_IND type ZTR_BANK_INDICATOR .
  data MV_BUKRS type BUKRS .
  data MV_HBKID type HBKID .
  data MS_13 type ZTRT0013 .
  data MV_VERSNO type VERSNO .
ENDCLASS.



CLASS ZCL_3023_BANK IMPLEMENTATION.


METHOD constructor.


    mv_banks    = iv_banks   .
    mv_bank_ind = iv_bank_ind .
    mv_bukrs    = iv_bukrs .
    mv_hbkid    = iv_hbkid .
    mv_hktid    = iv_hktid .
    mv_versno   = iv_versno .

    IF mv_hktid IS NOT INITIAL .

      SELECT MAX( zbkjyri ) FROM ztrv_3023 INTO @DATA(lv_date) WHERE  bukrs = @iv_bukrs  AND hbkid = @iv_hbkid  AND hktid = @iv_hktid  .
      IF  lv_date = '00000000' OR sy-subrc <> 0 .
        mv_zbkjyye = 0 .
      ELSE.

        SELECT SINGLE db_key FROM ztrt3023_01 INTO @DATA(lv_key)  WHERE bukrs = @iv_bukrs  AND hbkid = @iv_hbkid  AND hktid = @iv_hktid AND dflag = @space        AND  zbknum =
            ( SELECT MAX( zbknum ) FROM ztrv_3023 WHERE  bukrs = @iv_bukrs  AND hbkid = @iv_hbkid  AND hktid = @iv_hktid AND zbkjyri = @lv_date ) .
        IF sy-subrc = 0 .
          SELECT SINGLE zbkjyye FROM ztrt3023_02 INTO  mv_zbkjyye
                  WHERE parent_key = lv_key
                    AND dflag = space
                    AND zline =   ( SELECT MAX( zline ) FROM ztrt3023_02 WHERE parent_key = lv_key
                                                                           AND dflag = space
                                                                           AND ( zbkyt = text-f03 OR zbkyt = text-f04 ) ) .   "text-f03 / 04  is from ZTRE03027_FORM  314/326
          IF sy-subrc <> 0 .

            SELECT SINGLE zbkjyye FROM ztrt3023_02 INTO  mv_zbkjyye
             WHERE parent_key = lv_key
               AND dflag = space
               AND zline =   ( SELECT MAX( zline ) FROM ztrt3023_02 WHERE parent_key = lv_key
                                                                      AND dflag = space   ) .   "text-f03 / 04  is from ZTRE03027_FORM  314/326
            IF sy-subrc <> 0 .
              CLEAR mv_zbkjyye .
            ENDIF.
          ENDIF.
        ELSE.
          mv_zbkjyye = 0 .
        ENDIF.
      ENDIF.

      SELECT SINGLE * FROM ztrt0013 INTO ms_13 WHERE bukrs = mv_bukrs
                                                 AND hbkid = mv_hbkid
                                                 AND hktid = mv_hktid
                                                 AND del_flg = abap_false.
    ENDIF.
  ENDMETHOD.


METHOD zif_3023_bank~cal_file.

    DATA : ls_msg TYPE ztr_zjmsg .

*    SELECT * FROM ztrt3022_03 INTO TABLE @DATA(lt_03) ORDER BY text .

    et_tab = it_tab.

    LOOP AT et_tab ASSIGNING FIELD-SYMBOL(<fd_line>) .

      DATA(lv_line) = sy-tabix.

*      IF ms_01-shkzg_s = <fd_line>-zbkjsms AND ms_01-shkzg_s <> space.
*        <fd_line>-shkzg = 'S'.
*      ELSEIF  ms_01-shkzg_h = <fd_line>-zbkjsms  AND ms_01-shkzg_h <> space .
*        <fd_line>-shkzg  = 'H'.

* 2019.04.18
*  数据在载入表ZTRT3023_02时，根据借贷或收支描述（ZBKJSMS）和银行冲正字段识别导入金额的借方/贷方，
*  借方记入发生额（借），贷方记入发生额（贷）, 有银行冲正标识的，借/贷方调整为相反方向。
*  借贷或收支描述（ZBKJSMS）无内容的，根据银行冲正字段，将发生额（借）/发生额（贷）字段内的数据调整至相反方向。
      IF  ms_01-shkzg_h = <fd_line>-zbkjsms  AND ms_01-shkzg_h <> space AND
               ms_01-cz = <fd_line>-zbkcz AND  ms_01-cz <> space.
        <fd_line>-shkzg  = 'S'.

      ELSEIF  ms_01-shkzg_s = <fd_line>-zbkjsms  AND ms_01-shkzg_s <> space AND
               ms_01-cz = <fd_line>-zbkcz AND  ms_01-cz <> space.
        <fd_line>-shkzg  = 'H'.
      ELSEIF  <fd_line>-zbkjyes > 0 AND  ms_01-shkzg_s IS INITIAL AND ms_01-shkzg_h IS INITIAL AND
               ms_01-cz = <fd_line>-zbkcz AND  ms_01-cz <> space.
        <fd_line>-shkzg  = 'H'.
        <fd_line>-zbkjyeh = <fd_line>-zbkjyes .
        <fd_line>-zbkjyes = 0.
      ELSEIF  <fd_line>-zbkjyeh > 0 AND  ms_01-shkzg_s IS INITIAL AND ms_01-shkzg_h IS INITIAL AND
               ms_01-cz = <fd_line>-zbkcz AND  ms_01-cz <> space.
        <fd_line>-shkzg  = 'S'.
        <fd_line>-zbkjyes = <fd_line>-zbkjyeh .
        <fd_line>-zbkjyeh = 0.



      ELSEIF ms_01-shkzg_s = <fd_line>-zbkjsms AND ms_01-shkzg_s <> space.
        <fd_line>-shkzg = 'S'.
      ELSEIF  ms_01-shkzg_h = <fd_line>-zbkjsms  AND ms_01-shkzg_h <> space .
        <fd_line>-shkzg  = 'H'.
      ELSE.
        IF <fd_line>-zbkjye > 0 OR  ( <fd_line>-zbkjyes >  <fd_line>-zbkjyeh ) .
          <fd_line>-shkzg = 'S'.
        ELSEIF <fd_line>-zbkjye < 0  OR ( <fd_line>-zbkjyes <  <fd_line>-zbkjyeh ) .
          <fd_line>-shkzg = 'H'.
        ENDIF.
      ENDIF.

*      READ TABLE lt_03 INTO DATA(ls_03) WITH KEY text = <fd_line>-zbkjsms BINARY SEARCH .
*      IF sy-subrc = 0 .
*        <fd_line>-shkzg = ls_03-shkzg .
*      ELSE.
*
*      ENDIF.

      IF <fd_line>-zbkfse IS INITIAL AND  <fd_line>-zbkjye IS INITIAL.

        <fd_line>-zbkjye = <fd_line>-zbkjyes -  <fd_line>-zbkjyeh .
        <fd_line>-zbkfse = abs( <fd_line>-zbkjye ) .

      ELSEIF <fd_line>-zbkfse IS INITIAL AND  <fd_line>-zbkjye IS NOT INITIAL.

        <fd_line>-zbkfse = abs( <fd_line>-zbkjye ) .
**      20190821  只维护zbkjye 没有匹配发生额（借贷）
*        IF <fd_line>-shkzg  = 'S'.
*          <fd_line>-zbkjye = <fd_line>-zbkfse .
*        ELSEIF  <fd_line>-shkzg  = 'H'.
*          <fd_line>-zbkjye = <fd_line>-zbkfse * ( -1 ) .
*        ENDIF .
**      20190821  只维护zbkjye 没有匹配发生额（借贷）

      ELSEIF <fd_line>-zbkfse IS  NOT INITIAL AND  <fd_line>-zbkjye IS  INITIAL.

        IF <fd_line>-shkzg  = 'S'.
          <fd_line>-zbkjye = <fd_line>-zbkfse .
        ELSEIF  <fd_line>-shkzg  = 'H'.
          <fd_line>-zbkjye = <fd_line>-zbkfse * ( -1 ) .
        ENDIF .
      ENDIF.


      IF <fd_line>-zbkdkhht IS INITIAL AND <fd_line>-zbkdkr IS INITIAL AND <fd_line>-zbkdkt  IS INITIAL .
        IF <fd_line>-shkzg = 'S'.
          <fd_line>-zbkdkhht =  <fd_line>-zbkfkhht.
          <fd_line>-zbkdkr =  <fd_line>-zbkfkr.
          <fd_line>-zbkdkt =  <fd_line>-zbkfkt.
        ELSEIF <fd_line>-shkzg = 'H'.
          <fd_line>-zbkdkhht =  <fd_line>-zbkskhht.
          <fd_line>-zbkdkr =  <fd_line>-zbkskr.
          <fd_line>-zbkdkt =  <fd_line>-zbkskt.
        ENDIF.
      ENDIF.


      IF <fd_line>-zbkdkt IS NOT INITIAL.
        IF  <fd_line>-shkzg = 'S'.
          SELECT SINGLE kunnr FROM kna1 INTO <fd_line>-kunnr WHERE ( name1 = <fd_line>-zbkdkt  OR name2 = <fd_line>-zbkdkt )
                                                               AND ( ktokd = 'Z001'  OR  ktokd = 'Z003'  ) .
          IF sy-subrc  = 0 .
            <fd_line>-kunnr2 = <fd_line>-kunnr .
          ELSE.
            SELECT SINGLE lifnr FROM lfa1 INTO <fd_line>-lifnr WHERE ( name1 = <fd_line>-zbkdkt  OR name2 = <fd_line>-zbkdkt )
                                                                 AND ( ktokk = 'S001' OR ktokk = 'S004' OR  ktokk = 'S003' ) .
            IF sy-subrc  = 0 .
              <fd_line>-lifnr2 = <fd_line>-lifnr .
            ENDIF.
          ENDIF.
        ELSEIF <fd_line>-shkzg = 'H'.
          SELECT SINGLE lifnr FROM lfa1 INTO <fd_line>-lifnr WHERE ( name1 = <fd_line>-zbkdkt  OR name2 = <fd_line>-zbkdkt )
                                                                 AND ( ktokk = 'S001' OR ktokk = 'S004' OR ktokk = 'S003' ) .
          IF sy-subrc  = 0 .
            <fd_line>-lifnr2 = <fd_line>-lifnr .
          ELSE.
            SELECT SINGLE kunnr FROM kna1 INTO <fd_line>-kunnr WHERE ( name1 = <fd_line>-zbkdkt  OR name2 = <fd_line>-zbkdkt )
                                                               AND ( ktokd = 'Z001'  OR  ktokd = 'Z003'  ) .
            IF sy-subrc  = 0 .
              <fd_line>-kunnr2 = <fd_line>-kunnr .
            ENDIF.
          ENDIF.
        ENDIF.
      ENDIF.


      IF <fd_line>-zbkdk_bankl IS INITIAL .
        IF <fd_line>-zbkfk_bankl  IS NOT  INITIAL .
          <fd_line>-zbkdk_bankl = <fd_line>-zbkfk_bankl  .
        ELSEIF <fd_line>-zbksk_bankl IS NOT  INITIAL .
          <fd_line>-zbkdk_bankl = <fd_line>-zbksk_bankl  .
        ENDIF.
      ENDIF.

      IF <fd_line>-zbkfkhht IS INITIAL .
        IF <fd_line>-zbkfk_bankl IS NOT INITIAL .
          SELECT SINGLE banka FROM bnka INTO <fd_line>-zbkfkhht  WHERE bankl = <fd_line>-zbkfk_bankl .
        ELSE.
          IF <fd_line>-zbkfk_swift IS NOT INITIAL .
            SELECT SINGLE banka FROM bnka INTO <fd_line>-zbkfkhht  WHERE swift = <fd_line>-zbkfk_swift .
          ENDIF.
        ENDIF.
      ENDIF.

      IF <fd_line>-zbkskhht IS INITIAL .
        IF <fd_line>-zbksk_bankl IS NOT INITIAL .
          SELECT SINGLE banka FROM bnka INTO <fd_line>-zbkskhht  WHERE bankl = <fd_line>-zbksk_bankl .
        ELSE.
          IF <fd_line>-zbksk_swift IS NOT INITIAL .
            SELECT SINGLE banka FROM bnka INTO <fd_line>-zbkskhht  WHERE swift = <fd_line>-zbksk_swift .
          ENDIF.
        ENDIF.
      ENDIF.

      IF <fd_line>-zbkdkhht IS INITIAL .
        IF <fd_line>-zbkdk_bankl IS NOT INITIAL .
          SELECT SINGLE banka FROM bnka INTO <fd_line>-zbkdkhht  WHERE bankl = <fd_line>-zbkdk_bankl .
        ELSE.
          IF <fd_line>-zbkdk_swift IS NOT INITIAL .
            SELECT SINGLE banka FROM bnka INTO <fd_line>-zbkdkhht  WHERE swift = <fd_line>-zbkdk_swift .
          ENDIF.
        ENDIF.
      ENDIF.



*      mv_zbkjyye
      DATA : ls_09 TYPE  ztrt3023_09.
      IF lv_line = 1 .
        SELECT SINGLE zyetype FROM ztrt3023_09 INTO ls_09 WHERE bukrs  = ms_01-bukrs AND  hbkid = ms_01-hbkid AND hktid = ms_01-hbkid .
        IF  sy-subrc = 0 OR ls_09-zyetype = 'N'.
        ELSE.
*           IF <fd_line>-zbkjyye - <fd_line>-zbkjye <> mv_zbkjyye.
*            CLEAR ls_msg .
*            ls_msg-type = 'E'.
*            ls_msg-line = lv_line .
*            MESSAGE s293(ztr01) WITH | { condense( | { mv_zbkjyye } | ) } |  INTO ls_msg-msg.
*            APPEND ls_msg TO et_msg.
*        ENDIF.
        ENDIF.
      ENDIF.
*------------每一行都校验余额-----------------add by hjj 06.11.2020 15:15:47------------------------------------------
      IF <fd_line>-zbkjyye - <fd_line>-zbkjye <> mv_zbkjyye.
        CLEAR ls_msg .
        ls_msg-type = 'E'.
        ls_msg-line = lv_line .
        IF lv_line = 1.
          MESSAGE s293(ztr01) WITH | { condense( | { mv_zbkjyye } | ) } |  INTO ls_msg-msg.
        ELSE.
          MESSAGE s345(ztr05) WITH    | { condense( | {  <fd_line>-zbkjyye - <fd_line>-zbkjye } | ) } |  | { condense( | { mv_zbkjyye } | ) } |  INTO ls_msg-msg.
        ENDIF.
        APPEND ls_msg TO et_msg.
      ELSE.
        mv_zbkjyye = <fd_line>-zbkjyye  .
      ENDIF.
*-----------------------------add by hjj 06.11.2020 15:15:47------------------------------------------

      IF <fd_line>-zbkjye IS INITIAL.
        CLEAR ls_msg .
        ls_msg-type = 'E'.
        ls_msg-line = lv_line .
        MESSAGE s169(ztr01) WITH TEXT-e01 INTO ls_msg-msg.
        APPEND ls_msg TO et_msg.
      ENDIF.
      IF <fd_line>-zbkfse IS INITIAL .
        CLEAR ls_msg .
        ls_msg-type = 'E'.
        ls_msg-line = lv_line .
        MESSAGE s169(ztr01) WITH TEXT-e02 INTO ls_msg-msg.
        APPEND ls_msg TO et_msg.
      ENDIF.

      IF <fd_line>-shkzg IS INITIAL.
        CLEAR ls_msg .
        ls_msg-type = 'E'.
        ls_msg-line = lv_line .
        MESSAGE s170(ztr01) WITH TEXT-e03 INTO ls_msg-msg.
        APPEND ls_msg TO et_msg.
      ENDIF .

      CALL FUNCTION 'DATE_CHECK_PLAUSIBILITY'
        EXPORTING
          date                      = <fd_line>-zbkjyri
        EXCEPTIONS
          plausibility_check_failed = 1
          OTHERS                    = 2.
      IF sy-subrc <> 0.
        CLEAR ls_msg .
        ls_msg-type = 'E'.
        ls_msg-line = lv_line .
        MESSAGE s789(ztr01)  INTO ls_msg-msg.
        APPEND ls_msg TO et_msg.
      ENDIF.

      CALL FUNCTION 'TIME_CHECK_PLAUSIBILITY'
        EXPORTING
          time                      = <fd_line>-zbkjysj
        EXCEPTIONS
          plausibility_check_failed = 1
          OTHERS                    = 2.
      IF sy-subrc <> 0.
        CLEAR ls_msg .
        ls_msg-type = 'E'.
        ls_msg-line = lv_line .
        MESSAGE s790(ztr01)  INTO ls_msg-msg.
        APPEND ls_msg TO et_msg.
      ENDIF.

    ENDLOOP.
  ENDMETHOD.


METHOD zif_3023_bank~cvt_file.

    DATA(lt_data) = it_data.

    DATA : ls_msg TYPE ztr_zjmsg .

    SORT lt_data BY row col .

    SELECT SINGLE * FROM  ztrt3022_01 INTO ms_01
       WHERE banks       =  mv_banks
         AND bank_ind    =  mv_bank_ind
         AND bukrs       =  mv_bukrs
         AND hbkid       =  mv_hbkid
         AND versno       =  mv_versno
      .
    IF sy-subrc <> 0 ."20191210 如果没有则取行别配置，不分行别的版本
      SELECT SINGLE * FROM  ztrt3022_01 INTO ms_01
       WHERE banks       =  mv_banks
         AND bank_ind    =  mv_bank_ind
         AND bukrs       =  ''
         AND hbkid       =  ''.
    ENDIF.
    IF sy-subrc  = 0 .
      SELECT * FROM ztrt3022_02 INTO TABLE mt_02 WHERE bkguid = ms_01-bkguid .
    ENDIF.

    IF sy-subrc <> 0 .
      MESSAGE s150(ztr01) RAISING err.
    ENDIF.


    IF ms_01-cvt_method IS NOT INITIAL .    "  专家模式优先
      DATA et_cdata TYPE issr_alsmex_tabline.

      CALL METHOD zcl_tr_3023_gui=>(ms_01-cvt_method)
        EXPORTING
          iv_waers = iv_waers
          it_data  = it_data
        IMPORTING
          et_cdata = et_cdata
          et_data  = et_data
          et_msg   = et_msg
        EXCEPTIONS
          OTHERS   = 1.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
          WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.

        RETURN .

      ELSE.
        it_data = et_cdata.
      ENDIF.

    ENDIF .





    DATA(lv_line) = 1. "ms_01-sline .

    DATA ls_d02 TYPE ztrt3023_02 .

    DATA: lcx_error TYPE REF TO cx_root.

    IF ms_01-end_c IS NOT INITIAL .
      LOOP AT lt_data INTO DATA(ls_data) WHERE value CS ms_01-end_c.
        EXIT.
      ENDLOOP.
      IF sy-subrc = 0 .
        DATA(lv_end_line) = ls_data-row.
      ENDIF.
    ENDIF.


    CLEAR mt_d02 .

    DATA: lv_page TYPE cpcodepage.
    CALL FUNCTION 'NLS_GET_FRONTEND_CP'
      EXPORTING
        langu                 = sy-langu
        fetype                = 'MS'
      IMPORTING
        frontend_codepage     = lv_page
      EXCEPTIONS
        illegal_syst_codepage = 1
        no_frontend_cp_found  = 2
        internal_or_db_error  = 3
        OTHERS                = 4.


    WHILE ( lv_line <= ms_01-eline - ms_01-sline + 1  ) .

      IF lv_line >= lv_end_line AND lv_end_line <> 0  . EXIT. ENDIF.

      READ TABLE lt_data INTO ls_data WITH KEY row = lv_line BINARY SEARCH .
      IF sy-subrc <> 0 .EXIT. ENDIF.

      CLEAR ls_d02.
      ls_d02-zline =  lv_line.
      ls_d02-waers = ms_13-waers .
      LOOP AT mt_02 INTO DATA(ls_02) .


        ASSIGN COMPONENT ls_02-zbkfd OF STRUCTURE ls_d02 TO FIELD-SYMBOL(<fs_fd>).

        IF <fs_fd> IS ASSIGNED .

          READ TABLE lt_data INTO ls_data WITH KEY row = lv_line
                                                        col = ls_02-zbk_col BINARY SEARCH .
          IF sy-subrc = 0 .


            IF ms_01-space_c IS NOT INITIAL AND ls_data-value = ms_01-space_c .
              CLEAR ls_data-value .
            ENDIF.

            IF ms_01-del_1 IS NOT INITIAL  .
              DATA(lv_str) = strlen( ms_01-del_1  ) .
              IF ls_data-value(lv_str) =  ms_01-del_1 .
                SHIFT ls_data-value BY lv_str PLACES LEFT .
              ENDIF.
            ENDIF.


            IF ms_01-del_2 IS NOT INITIAL  .
              lv_str = strlen( ms_01-del_2  ) .
              IF ls_data-value(lv_str) =  ms_01-del_2 .
                SHIFT ls_data-value BY lv_str PLACES LEFT .
              ENDIF.
            ENDIF.

            IF ms_01-del_3 IS NOT INITIAL  .
              lv_str = strlen( ms_01-del_3  ) .
              IF ls_data-value(lv_str) =  ms_01-del_3 .
                SHIFT ls_data-value BY lv_str PLACES LEFT .
              ENDIF.
            ENDIF.

            IF ls_02-left_x = abap_true OR  ls_02-right_x = abap_true . .

              CALL FUNCTION 'SCP_REPLACE_STRANGE_CHARS'
                EXPORTING
                  intext            = ls_data-value
                  inter_cp          = lv_page
                  replacement       = 32     " 等于space, ASC
                IMPORTING
                  outtext           = ls_data-value
                EXCEPTIONS
                  invalid_codepage  = 1
                  codepage_mismatch = 2
                  internal_error    = 3
                  cannot_convert    = 4
                  fields_not_type_c = 5
                  OTHERS            = 6.
            ENDIF.

            IF ls_02-right_x = abap_true .
              SHIFT ls_data-value RIGHT DELETING TRAILING space.
            ENDIF.

            IF ls_02-left_x = abap_true .
              SHIFT ls_data-value LEFT DELETING LEADING space.
            ENDIF.



            IF  ls_02-cvt_method = space .
              TRY .
                  <fs_fd> = ls_data-value  .
                CATCH   cx_sy_conversion_error INTO lcx_error.
                  CLEAR <fs_fd> .
                  CLEAR ls_msg .
                  ls_msg-type = 'E'.
                  ls_msg-line = lv_line .
                  MESSAGE s156(ztr01) WITH lv_line ls_02-zbk_col INTO ls_msg-msg.
                  APPEND ls_msg TO et_msg.
              ENDTRY .

            ELSE.
              CALL METHOD zcl_tr_3022_gui=>(ls_02-cvt_method)
                EXPORTING
                  iv_in  = ls_data-value
                IMPORTING
                  ev_out = <fs_fd>
                EXCEPTIONS
                  err    = 1
                  OTHERS = 2.
              IF sy-subrc <> 0 .
                CLEAR ls_msg .
                ls_msg-type = 'E'.
                ls_msg-line = lv_line .
                MESSAGE s156(ztr01) WITH lv_line ls_02-zbk_col INTO ls_msg-msg.
                APPEND ls_msg TO et_msg.
              ENDIF.
            ENDIF.

            IF ( ls_02-zbkfd = 'ZBKFSE'
            OR ls_02-zbkfd = 'ZBKJYES'
            OR ls_02-zbkfd = 'ZBKJYEH'
            OR ls_02-zbkfd = 'ZBKJYE'
            OR ls_02-zbkfd = 'ZBKJYYE' ) AND iv_waers <> space.
              DATA: lv_f  TYPE isoc_factor .
              CALL FUNCTION 'CURRENCY_CONVERTING_FACTOR'
                EXPORTING
                  currency = iv_waers
                IMPORTING
                  factor   = lv_f.
              <fs_fd> = <fs_fd> / lv_f.
            ENDIF.
          ELSE.
            CLEAR : <fs_fd> .
          ENDIF.
        ENDIF.


      ENDLOOP.

      IF ls_d02 IS NOT INITIAL . APPEND ls_d02 TO mt_d02. ENDIF.
      lv_line = lv_line + 1.
    ENDWHILE .


    IF ms_01-desd = abap_true .
      SORT mt_d02 BY zline DESCENDING .
      LOOP AT mt_d02 ASSIGNING FIELD-SYMBOL(<fs_02>) .
        <fs_02>-zline = sy-tabix.
      ENDLOOP .
    ENDIF .

    et_data = mt_d02.

  ENDMETHOD.


METHOD zif_3023_bank~get_rng.

    SELECT SINGLE * FROM  ztrt3022_01 INTO ms_01
      WHERE banks       =  mv_banks
        AND bank_ind    =  mv_bank_ind
        AND bukrs       =  mv_bukrs
        AND hbkid       =  mv_hbkid
      AND versno = mv_versno.
    IF sy-subrc <> 0 .
      SELECT SINGLE * FROM  ztrt3022_01 INTO ms_01
        WHERE banks       =  mv_banks
          AND bank_ind    =  mv_bank_ind
          AND bukrs       =  ''
          AND hbkid       =  ''.
    ENDIF.

    IF sy-subrc = 0 .
      ev_srow = ms_01-sline.
      ev_erow = ms_01-eline.
      ev_scol  = 1.
      SELECT MAX( zbk_col ) FROM ztrt3022_02 INTO ev_ecol WHERE bkguid = ms_01-bkguid .
    ENDIF.
  ENDMETHOD.


METHOD zif_3023_bank~save.
    DATA : ls_alv TYPE ztrs_0023_alv,
           ls_232 TYPE ztrt3023_02,
           lt_232 TYPE TABLE OF ztrs_0023_alv.

    CLEAR : ms_d01 ,mt_d02 .

    lt_232 = it_data .

    SORT lt_232 BY zbkjyri zbkjysj .

    READ TABLE lt_232 INTO DATA(ls_line) INDEX 1 .

    IF sy-subrc = 0 .

      SELECT MAX( zline ) FROM ztrt3023_02 AS i INNER JOIN  ztrt3023_01 AS h ON i~parent_key = h~db_key
        INTO @DATA(lv_line)
       WHERE h~bukrs = @ls_line-bukrs
         AND h~hbkid = @ls_line-hbkid
         AND h~hktid = @ls_line-hktid
         AND h~dflag = @abap_false
         AND i~dflag = @abap_false
         AND i~zbkjyri  = @ls_line-zbkjyri.

      IF sy-subrc <> 0 .
        lv_line = 1 .
      ELSE.
        lv_line = lv_line  + 1 .
      ENDIF.

    ENDIF.


    LOOP AT it_data INTO ls_alv.
      IF sy-tabix = 1  .
        MOVE-CORRESPONDING ls_alv TO me->ms_d01.
        me->ms_d01-db_key = /bobf/cl_frw_factory=>get_new_key( ) .
      ENDIF.

*      DATA(lv_line) = sy-tabix.
      CLEAR ls_232 .
      MOVE-CORRESPONDING ls_alv TO ls_232.
      ls_232-db_key  = /bobf/cl_frw_factory=>get_new_key( ) .
      ls_232-parent_key = me->ms_d01-db_key .
      ls_232-zline = lv_line .
      lv_line  = lv_line + 1 .
      ls_232-iaedat  = sy-datum .
      ls_232-iaezet  = sy-uzeit.
      ls_232-iaenam = sy-uname.
      ls_232-itcode = sy-tcode .

      APPEND ls_232 TO me->mt_d02 .
    ENDLOOP.

    MODIFY ztrt3023_01 FROM me->ms_d01.
    IF sy-subrc = 0 .
      MODIFY ztrt3023_02 FROM TABLE me->mt_d02 .
    ENDIF.

    IF iv_commit = abap_true.
      COMMIT WORK AND WAIT .
    ENDIF.
  ENDMETHOD.
ENDCLASS.
