class ZCL_CAPTICAL_ENCRYPTOR definition
  public
  final
  create public .

public section.

  constants OBJECT_TYPE_IS_PAYMORD type ZTR_ENCRYPTED_OBJECT_TYPE value '1' ##NO_TEXT.
  constants OBJECT_TYPE_IS_PAYMORD_P004 type ZTR_ENCRYPTED_OBJECT_TYPE value '2' ##NO_TEXT.
  constants ALL_USER type ZTR_ENCRYUSER value '1' ##NO_TEXT.
  constants BY_USER type ZTR_ENCRYUSER value '2' ##NO_TEXT.
  constants ACTIVATION_RESULT_ERROR type CHAR01 value 'E' ##NO_TEXT.
  constants ACTIVATION_RESULT_NOT_ACTIVE type CHAR01 value 'N' ##NO_TEXT.
  constants ACTIVATION_RESULT_ACTIVE type CHAR01 value 'S' ##NO_TEXT.

  class-methods CLASS_CONSTRUCTOR .
  methods CONSTRUCTOR
    importing
      !IM_OBJECT_TYPE type ZTR_ENCRYPTED_OBJECT_TYPE
      !IM_OBJECT_CODE type ZTR_ENCRYPTED_OBJECT_CODE
      !IM_METHOD type ZTR_SSF_METHOD default 'ENCRYPT'
    raising
      ZCX_ENCRYPTOR_CREATE_ERROR .
  class-methods GET_BY_BUSINESS_OBJECT
    importing
      !IM_OBJECT_TYPE type ZTR_ENCRYPTED_OBJECT_TYPE
      !IM_OBJECT_CODE type ZTR_ENCRYPTED_OBJECT_CODE
      !IM_METHOD type ZTR_SSF_METHOD
    returning
      value(RO_ENCRYPTOR) type ref to ZCL_CAPTICAL_ENCRYPTOR
    raising
      ZCX_ENCRYPTOR_CREATE_ERROR .
  methods ENCRYPT
    importing
      !IM_O_ENCRYPTING_DATA type ref to DATA
      !IM_COMMIT_WORK type FLAG default SPACE
    exporting
      !EX_SSFUUID type ZTR_ENCRYPTION_UUID
    raising
      ZCX_ENCRYPTION_ERROR .
  methods COMPARE
    importing
      !IM_O_ENCRYPTING_DATA type ref to DATA
    raising
      ZCX_COMPARISION_ERROR .
  class-methods RAISE_SSF_ERROR
    importing
      !IM_SSF_RC type SSFPARMS-SSFCRC
      !IM_SUBRC type SYSUBRC
      !IM_FIELD type CLIKE optional
      !IM_STEP type CLIKE
    exceptions
      ERROR .
  class-methods CONVERT_UTF8_TO_STRING
    importing
      !IM_T_UTF8_DATA type RMPS_SSFBIN
      !IM_LENGTH type I
    returning
      value(RE_STRING) type STRING .
  class-methods CONVERT_STRING_TO_UTF8
    importing
      !IM_STRING type STRING
    returning
      value(RT_DATA) type RMPS_SSFBIN .
  class-methods DO_ENCRYPTION
    importing
      !IM_OBJECT_TYPE type ZTR_ENCRYPTED_OBJECT_TYPE
      !IM_OBJECT_CODE type ZTR_ENCRYPTED_OBJECT_CODE
      !IM_O_ENCRYPTING_DATA type ref to DATA
      !IM_COMMIT_WORK type FLAG default SPACE
    exporting
      !EX_SSFUUID type ZTR_ENCRYPTION_UUID
    raising
      ZCX_ENCRYPTOR_CREATE_ERROR
      ZCX_ENCRYPTION_ERROR .
  class-methods DO_COMPARISON
    importing
      !IM_OBJECT_TYPE type ZTR_ENCRYPTED_OBJECT_TYPE
      !IM_OBJECT_CODE type ZTR_ENCRYPTED_OBJECT_CODE
      !IM_O_ENCRYPTING_DATA type ref to DATA
    exporting
      !EX_SSFUUID type ZTR_ENCRYPTION_UUID
    raising
      ZCX_COMPARISION_ERROR
      ZCX_ENCRYPTOR_CREATE_ERROR .
  class-methods GET_ENCRYPTION_FIELDS_CONFIG
    importing
      !IM_OBJECT_TYPE type ZTR_ENCRYPTED_OBJECT_TYPE
    returning
      value(RT_FIELDS) type ZTRS_SSF_FIELD_TAB
    exceptions
      NOT_FOUND .
  class-methods BUILD_ENCRYPTION_FIELDVALUE
    importing
      !IM_OBJECT_TYPE type ZTR_ENCRYPTED_OBJECT_TYPE
      !IM_EXTERNAL_SOURCE type ANY
    returning
      value(RT_FIELDVALUES) type ZTRS_ENCRYPT_FIELDS_TAB .
  class-methods CHECK_ACT_OF_CLIENT_AND_USER
    returning
      value(RE_RESULT) type CHAR01 .
  class-methods CHECK_FOR_ACTIVATION
    importing
      !IM_OBJECT_TYPE type ZTR_ENCRYPTED_OBJECT_TYPE
    returning
      value(RE_RESULT) type CHAR01 .
  class-methods CHECK_ACTIVATION_OF_ENCRY
    importing
      !IM_OBJECT_TYPE type ZTR_ENCRYPTED_OBJECT_TYPE
    exporting
      !EX_RESULT type CHAR01
    exceptions
      ERROR .
  class-methods DO_PAYMORDER_SSFENCRYPTION_004
    importing
      !IM_S_2101 type ZTRT2101
      !IM_S_2002 type ZTRT2002
      !IM_S_2003 type ZTRT2003
      value(IM_COMMIT_WORK) type CHAR01
    exporting
      !EX_SSFUUID type ZTR_ENCRYPTION_UUID
    exceptions
      ERROR .
  class-methods DO_PAYMORDER_SSFENCRYPTION
    importing
      !IM_S_2001 type ZTRT2001
      !IM_S_2002 type ZTRT2002
      !IM_S_2003 type ZTRT2003
      value(IM_COMMIT_WORK) type CHAR01
    exporting
      !EX_SSFUUID type ZTR_ENCRYPTION_UUID
    exceptions
      ERROR .
  class-methods SET_SKIP .
  class-methods DO_PAYMORDER_SSFCOMPARING_004
    importing
      !IM_S_2101 type ZTRT2101
      !IM_S_2002 type ZTRT2002
      !IM_S_2003 type ZTRT2003
    exceptions
      ERROR .
  class-methods DO_PAYMORDER_SSFCOMPARING
    importing
      !IM_S_2001 type ZTRT2001
      !IM_S_2002 type ZTRT2002
      !IM_S_2003 type ZTRT2003
    exceptions
      ERROR .
  class-methods CHECK_UUID_IF_UPDATED
    importing
      !IM_UUID type ZTR_ENCRYPTION_UUID
    returning
      value(RE_UPDATED) type CHAR01 .
  class-methods IF_UKEY_IS_VALID
    exceptions
      NOT_VALID .
  class-methods SET_FROM_WEBDYNPRO .
  class-methods IF_FROM_WEBDYNPRO
    returning
      value(RE_WEBDYNPRO) type FLAG .
protected section.
private section.

  data ENCRYPTOR_UUID type ZTR_ENCRYPTION_UUID .
  data OBJECT_TYPE type ZTR_ENCRYPTED_OBJECT_TYPE .
  data OBJECT_CODE type ZTR_ENCRYPTED_OBJECT_CODE .
  class-data DUMMY_MESSAGE type STRING .
  class-data SSF_PARAMETERS type ZTRS_SSF_PARAMETERS .
  data ENCRIPTED_DATA type ZTRS_ENCRYPT_DATA_TAB .
  data ENCRIPTED_DATA_LENGTH type ZTRS_ENCRYPT_LENGTH_TAB .
  data CURRENT_SIGN_ITEM type ZTR_SSF_ITEM value '000' ##NO_TEXT.
  data CURRENT_ENVELOPE_ITEM type ZTR_SSF_ITEM value '000' ##NO_TEXT.
  data CURRENT_UTF8_ITEM type ZTR_SSF_ITEM value '000' ##NO_TEXT.
  data CURRENT_DEVELOPE_ITEM type ZTR_SSF_ITEM value '000' ##NO_TEXT.
  data CURRENT_VERIFY_4_SIGN_ITEM type ZTR_SSF_ITEM value '000' ##NO_TEXT.
  data CURRENT_VERIFY_4_ENVELOPE_ITEM type ZTR_SSF_ITEM value '000' ##NO_TEXT.
  constants SSF_TYPE_IS_SIGN type ZTR_SSF_TYPE value '1' ##NO_TEXT.
  constants SSF_TYPE_IS_KRN_SIGN type ZTR_SSF_TYPE value '3' ##NO_TEXT.
  constants SSF_TYPE_IS_ENVELOPE type ZTR_SSF_TYPE value '2' ##NO_TEXT.
  constants SSF_TYPE_IS_KRN_ENVELOPE type ZTR_SSF_TYPE value '4' ##NO_TEXT.
  constants SSF_TYPE_IS_UTF8 type ZTR_SSF_TYPE value 'U' ##NO_TEXT.
  constants SSF_TYPE_IS_DEVELOPE type ZTR_SSF_TYPE value 'Z' ##NO_TEXT.
  constants SSF_TYPE_IS_VERIFY_4_SIGN type ZTR_SSF_TYPE value 'X' ##NO_TEXT.
  constants SSF_TYPE_IS_KRN_VERIFY_4_SIGN type ZTR_SSF_TYPE value '6' ##NO_TEXT.
  constants SSF_TYPE_IS_VERIFY_4_ENVELOPE type ZTR_SSF_TYPE value 'Y' ##NO_TEXT.
  constants SSF_TYPE_IS_KRN_VERIFY_4_ENV type ZTR_SSF_TYPE value '5' ##NO_TEXT.
  constants METHOD_IS_ENCRYPTION type ZTR_SSF_METHOD value 'ENCRYPT' ##NO_TEXT.
  constants METHOD_IS_DECRYPTION type ZTR_SSF_METHOD value 'DECRYPT' ##NO_TEXT.
  constants METHOD_IS_COMPARISION type ZTR_SSF_METHOD value 'COMPARE' ##NO_TEXT.
  data METHOD type ZTR_SSF_METHOD .
  data EXTERNAL_SOURCE_DATA type ZTRS_ENCRYPT_FIELDS_TAB .
  data INTERNAL_DESCRYPTED_DATA type ZTRS_DECRYPTED_FIELDS_TAB .
  class-data SKIP type CHAR01 .
  constants PROFILE type STRING value 'tokcapi:*(*)' ##NO_TEXT.
  class-data FROM_WEBDYNPRO type FLAG .

  class-methods GET_SSF_PARAMETERS
    exceptions
      NOT_FOUND .
  methods SSF_KRN_SIGN
    exceptions
      SIGN_ERROR .
  methods SSF_KRN_VERIFY
    importing
      !IM_VERIFY_FOR_SSF_TYPE type ZTR_SSF_TYPE default 'X'
    exceptions
      VERIFY_ERROR .
  methods SSF_KRN_DEVELOPE
    exceptions
      DEVELOPE_ERROR .
  methods SSF_KRN_ENVELOPE
    exceptions
      ENVELOPE_ERROR .
  methods GET_ITEM_DATA_BY_FIELD
    importing
      !IM_FIELD type FIELDNAME optional
      !IM_SSF_TYPE type ZTR_SSF_TYPE
    exporting
      !EX_LENGTH type I
      value(ET_DATA) type RMPS_SSFBIN .
  methods SAVE
    importing
      !IM_COMMIT_WORK type FLAG default SPACE .
  methods BUILD_HEADER
    returning
      value(RS_HEADER) type ZTRT_ENCRH_H .
  methods FINISH_ITEM_BEFORE_SAVE
    returning
      value(RT_ITEMS) type ZTRT_ENCRH_I_TAB .
  methods FINISH_DATA_LENGTH_BEFORE_SAVE
    returning
      value(RT_DATA_LENGTH) type ZTRT_ENCRH_LEN_TAB .
  methods BUILD_UUID
    exceptions
      ERROR .
  methods GET_UUID_FROM_DB
    exporting
      value(EX_UUID) type ZTRT_ENCRH_I-UUID
    exceptions
      ERROR .
  methods READ_ENCRYPTED_ITEMS
    exceptions
      NOT_FOUND .
  methods READ_ENCRYPTED_DATA_LENGTH
    exceptions
      NOT_FOUND .
  methods CHECK_FOR_CONSTRUCTOR
    exceptions
      ERROR .
  methods INIT_FOR_CONSTRUCTOR
    exceptions
      ERROR .
  methods CONVERT_TO_UTF8
    importing
      !IM_STRING type STRING .
  methods CONVERT_TO_STRING .
  class-methods COLLECT_SOURCE_DATA
    importing
      !IM_TABNAME type TABNAME
      !IM_DATA type ANY
    changing
      !CH_T_SOURCE type ZTRS_ENCRYPTING_SOURCE_TAB .
  class-methods BUILD_ENCRYPTING_STRUCTURE
    importing
      !IM_T_SOURCE type ZTRS_ENCRYPTING_SOURCE_TAB
      !IM_OBJECT_TYPE type ZTR_ENCRYPTED_OBJECT_TYPE
    exporting
      value(EX_O_ENCRYPTING_DATA) type ref to DATA
    exceptions
      ERROR .
  methods BUILD_EXTERNAL_SOURCE_STRING
    importing
      !IM_O_ENCRYPTING_DATA type ref to DATA
    returning
      value(RE_STRING) type STRING .
ENDCLASS.



CLASS ZCL_CAPTICAL_ENCRYPTOR IMPLEMENTATION.


METHOD build_encrypting_structure.
    DATA: lo_structure TYPE REF TO cl_abap_structdescr.

    SELECT SINGLE encry_struc INTO @DATA(l_structure_name)
            FROM ztrt_encrh_act
            WHERE object_type = @im_object_type.
    IF l_structure_name IS INITIAL.
      MESSAGE e319(ztr_bank_application)
              RAISING error.
    ENDIF.

    zcl_global_technical_service=>check_table(
                    EXPORTING
                      im_tabname = l_structure_name
                    EXCEPTIONS
                      not_found = 1 ).
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid
              TYPE sy-msgty
              NUMBER sy-msgno
              WITH sy-msgv1
                   sy-msgv2
                   sy-msgv3
                   sy-msgv4
              RAISING error.
    ELSE.
      CREATE DATA ex_o_encrypting_data TYPE (l_structure_name).
      assign ex_o_encrypting_data->* to FIELD-SYMBOL(<fs_encrypting_data>).
    ENDIF.

    SELECT * INTO TABLE @DATA(lt_encrh_fld)
          FROM ztrt_encrh_fld
          WHERE object_type = @im_object_type.

    lo_structure ?= cl_abap_structdescr=>describe_by_name( l_structure_name ).
    DATA(lt_components) = lo_structure->get_components( ).

    IF lines( lt_components ) <> lines( lt_encrh_fld ).
      MESSAGE e320(ztr_bank_application)
              RAISING error.
    ENDIF.

    LOOP AT lo_structure->get_components( ) INTO DATA(ls_component).
      READ TABLE lt_encrh_fld INTO DATA(ls_encrh_fld)
            WITH KEY object_type = im_object_type
                     fieldname = ls_component-name.
      IF sy-subrc <> 0.
        MESSAGE e321(ztr_bank_application)
               WITH ls_component-name
                    l_structure_name
               RAISING error.
      ENDIF.

      ASSIGN COMPONENT ls_component-name
                      OF STRUCTURE <fs_encrypting_data>
                      TO FIELD-SYMBOL(<f_encrypting_field>).

      IF sy-subrc <> 0.
        MESSAGE e322(ztr_bank_application)
               WITH ls_component-name
               RAISING error.
      ENDIF.

      READ TABLE im_t_source INTO DATA(ls_source)
             WITH KEY tabname = ls_encrh_fld-reftabname.
      IF sy-subrc <> 0.
        MESSAGE e323(ztr_bank_application)
               WITH ls_encrh_fld-reftabname
               RAISING error.
      ENDIF.

      IF ls_source-data IS NOT BOUND.
        MESSAGE e324(ztr_bank_application)
               WITH ls_encrh_fld-reftabname
               RAISING error.
      ENDIF.

      ASSIGN ls_source-data->* TO FIELD-SYMBOL(<fs_source_data>).

      ASSIGN COMPONENT ls_encrh_fld-reffieldname
                       OF STRUCTURE <fs_source_data>
                       TO FIELD-SYMBOL(<f_source_field>).
      IF sy-subrc <> 0.
        MESSAGE e325(ztr_bank_application)
               WITH ls_encrh_fld-reftabname
                    ls_encrh_fld-reffieldname
               RAISING error.
      ENDIF.

      <f_encrypting_field> = <f_source_field>.

    ENDLOOP.
  ENDMETHOD.


METHOD build_encryption_fieldvalue.
    LOOP AT get_encryption_fields_config( im_object_type ) INTO DATA(ls_field).
      ASSIGN COMPONENT ls_field-fieldname OF STRUCTURE im_external_source TO FIELD-SYMBOL(<f_field>).
      IF sy-subrc <> 0.
        MESSAGE e251(ztr_bank_application)
                WITH im_object_type
                     ls_field-fieldname.
      ELSE.
        APPEND VALUE #( fieldname = ls_field-fieldname
                        value = CONV #( <f_field> ) )
                    TO rt_fieldvalues.
        UNASSIGN <f_field>.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.


METHOD build_external_source_string.
    ASSIGN im_o_encrypting_data->* TO FIELD-SYMBOL(<fs_external_source_data>).
    DO.
      ASSIGN COMPONENT sy-index OF STRUCTURE <fs_external_source_data> TO FIELD-SYMBOL(<f_field>).
      IF sy-subrc = 0.
        re_string = re_string && <f_field>.
      ELSE.
        EXIT.
      ENDIF.
    ENDDO.
  ENDMETHOD.


METHOD build_header.
    DATA(ls_system_info) = zcl_global_technical_service=>get_system_info( ).
    SELECT SINGLE * INTO rs_header
           FROM ztrt_encrh_h
           WHERE uuid = encryptor_uuid.
    IF sy-subrc <> 0.
      MOVE: encryptor_uuid TO rs_header-uuid,
            object_code TO rs_header-object_code,
            object_type TO rs_header-object_type.
      MOVE: ls_system_info-tcode TO rs_header-tcode,
            ls_system_info-timestamp TO rs_header-update_timestamp,
            ls_system_info-timezone  TO rs_header-update_timezone,
            ls_system_info-datum TO rs_header-erdat,
            ls_system_info-uzeit TO rs_header-erzet,
            ls_system_info-uname TO rs_header-ernam.
    ELSE.
      IF rs_header-object_code <> object_code OR
         rs_header-object_type   <> object_type.
*        program error
        MESSAGE x243(ztr_bank_application)
                with encryptor_uuid
                     rs_header-object_code
                     rs_header-object_type.
      ENDIF.
      MOVE: ls_system_info-tcode TO rs_header-tcode,
            ls_system_info-timestamp TO rs_header-update_timestamp,
            ls_system_info-timezone  TO rs_header-update_timezone,
            ls_system_info-datum TO rs_header-aedat,
            ls_system_info-uzeit TO rs_header-aezet,
            ls_system_info-uname TO rs_header-aenam.
    ENDIF.
    select single ENCRY_STRUC into rs_header-encry_struc
           from ZTRT_ENCRH_ACT
           where OBJECT_TYPE = rs_header-object_type.
  ENDMETHOD.


METHOD build_uuid.

    get_uuid_from_db(
         IMPORTING
           ex_uuid = encryptor_uuid
         EXCEPTIONS
           error = 1 ).
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid
              TYPE sy-msgty
              NUMBER sy-msgno
              WITH sy-msgv1
                   sy-msgv2
                   sy-msgv3
                   sy-msgv4
              RAISING error.
    ENDIF.

    IF encryptor_uuid IS INITIAL.
*  new encription
      TRY.
          encryptor_uuid = cl_system_uuid=>if_system_uuid_static~create_uuid_c22( ).
        CATCH cx_uuid_error.
          MESSAGE e001(ztr_bank_application)
                  RAISING error.
      ENDTRY.
    ENDIF.
  ENDMETHOD.


METHOD check_activation_of_encry.

      ex_result = check_for_activation( im_object_type ).

    CASE ex_result.
      WHEN activation_result_error.
        DATA(l_text) = zcl_global_technical_service=>get_domain_text(
                                     im_ingnore_error = 'X'
                                     im_domain_name = 'ZTRDM_ENCRYPTED_OBJECT_TYPE'
                                     im_domain_value = im_object_type ).

        MESSAGE e315(ztr_bank_application)
                WITH im_object_type
                     l_text
                     sy-mandt
                 RAISING error.
      WHEN activation_result_not_active OR
            activation_result_active.
        RETURN.
    ENDCASE.
  ENDMETHOD.


METHOD CHECK_ACT_OF_CLIENT_AND_USER.

    SELECT SINGLE * INTO @DATA(ls_encry_mandt)
           FROM ztrt_encry_mandt
           WHERE clientcode = @sy-mandt.
    IF sy-subrc <> 0.
*  配置错误
*  激活了加密，但没有对客户端的那些用户需要加密进行配置
      re_result = activation_result_error. "error
    ENDIF.

    IF ls_encry_mandt-encryuser = all_user.
*      所有用户都需要加密，这是生产环境的情况
      re_result = activation_result_active.
    ELSE.
*      这是测试系统或开发系统的情况，因为不是所有人都有证书
*      按用户
      SELECT SINGLE * INTO @DATA(ls_encry_user)
             FROM ztrt_encry_user
             WHERE clientcode = @ls_encry_mandt-clientcode
             AND   uname = @sy-uname.
      IF ls_encry_user-uname IS NOT INITIAL.
*      用户配置了，需要加密，
        re_result = activation_result_active.
      ELSE.
*        用户没有配置，不需要加密
        re_result = activation_result_not_active.
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD check_for_activation.

    IF skip = 'X'.
*      跳过加密过程
*      目前资金集中平台的销售公司到工厂的TT划款是后台运行，无法加密
*      销售公司到工厂的TT划款创建支付单前需要调用set_skip  method，让加密程序跳过加密过程
      re_result = activation_result_not_active.
      RETURN.
    ENDIF.

    SELECT SINGLE act INTO @DATA(l_act)
          FROM ztrt_encrh_act
          WHERE object_type = @im_object_type.
    IF sy-subrc <> 0.
*      没有激活
      re_result = activation_result_not_active.
      RETURN.
    ENDIF.

    re_result = check_act_of_client_and_user( ).


  ENDMETHOD.


METHOD check_for_constructor.
    IF object_code IS INITIAL.
      MESSAGE e246(ztr_bank_application)
              RAISING error.
    ENDIF.

*    zcl_global_technical_service=>check_domain_value(
*                       EXPORTING
*                          im_domain_name = 'ZTRDM_ENCRYPTED_OBJECT_TYPE'
*                          im_domain_value = object_type
*                          im_allow_initial_value = space
*                       EXCEPTIONS
*                         not_valid = 1 ).
*    IF sy-subrc <> 0.
*      MESSAGE ID sy-msgid
*              TYPE sy-msgty
*              NUMBER sy-msgno
*              WITH sy-msgv1
*                   sy-msgv2
*                   sy-msgv3
*                   sy-msgv4
*              RAISING error.
*    ENDIF.
    SELECT COUNT( * ) INTO @DATA(l_count)
           FROM ztrt_encrh_act
           WHERE object_type = @object_type.
    IF sy-subrc <> 0.
      MESSAGE e318(ztr_bank_application)
              WITH object_type
              RAISING error.
    ENDIF.
    zcl_global_technical_service=>check_domain_value(
                       EXPORTING
                          im_domain_name = 'ZTRDM_SSF_METHOD'
                          im_domain_value = method
                          im_allow_initial_value = space
                       EXCEPTIONS
                         not_valid = 1 ).
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid
              TYPE sy-msgty
              NUMBER sy-msgno
              WITH sy-msgv1
                   sy-msgv2
                   sy-msgv3
                   sy-msgv4
              RAISING error.
    ENDIF.
  ENDMETHOD.


METHOD check_uuid_if_updated.
    DO 1000 TIMES.
      SELECT COUNT( * ) INTO @DATA(l_count)
            FROM ztrt_encrh_h
            WHERE uuid = @im_uuid.
      IF l_count > 0.
        re_updated = 'X'.
        EXIT.
      ELSE.
        WAIT UP TO '0.1' SECONDS.
      ENDIF.
    ENDDO.
  ENDMETHOD.


method CLASS_CONSTRUCTOR.
    GET_SSF_PARAMETERS( ).
  endmethod.


METHOD collect_source_data.
    DATA: ls_source TYPE ztrs_encrypting_source.

    ls_source-tabname = im_tabname.

    CREATE DATA ls_source-data TYPE (im_tabname).

    ASSIGN ls_source-data->* TO FIELD-SYMBOL(<f_data>).

    <f_data> = im_data.

    APPEND ls_source TO ch_t_source.

  ENDMETHOD.


METHOD compare.

    convert_to_utf8( build_external_source_string( im_o_encrypting_data ) ).

    ssf_krn_verify(
            EXPORTING
              im_verify_for_ssf_type = ssf_type_is_krn_sign
            EXCEPTIONS
              verify_error = 1 ).
    IF sy-subrc <> 0.
      RAISE EXCEPTION TYPE zcx_comparision_error
        EXPORTING
          textid = VALUE #(
          msgid = sy-msgid
          msgno = sy-msgno
          attr1 = sy-msgv1
          attr2 = sy-msgv2
          attr3 = sy-msgv3
          attr4 = sy-msgv4 ).
    ENDIF.
  ENDMETHOD.


METHOD constructor.

    MOVE: im_object_type TO object_type,
          im_object_code TO object_code,
          im_method      TO method.

    check_for_constructor(
            EXCEPTIONS
              error = 1 ).
    IF sy-subrc = 0.
      init_for_constructor(
                 EXCEPTIONS
                   error = 1 ).
    ENDIF.

    IF sy-subrc = 0.
      if_ukey_is_valid(
              EXCEPTIONS
                not_valid = 1 ).
    ENDIF.

    IF sy-subrc <> 0.
      RAISE EXCEPTION TYPE zcx_encryptor_create_error
        EXPORTING
          textid = VALUE #(
          msgid = sy-msgid
          msgno = sy-msgno
          attr1 = sy-msgv1
          attr2 = sy-msgv2
          attr3 = sy-msgv3
          attr4 = sy-msgv4 ).
    ENDIF.

  ENDMETHOD.


METHOD convert_string_to_utf8.
    CONSTANTS: c_ssfbin_length TYPE i VALUE 255.

    DATA(lo_conv) = cl_abap_conv_out_ce=>create(
                           encoding    = 'UTF-8'
                           replacement = '#'
                           ignore_cerr = abap_true ).

    lo_conv->write( im_string ).

    DATA(l_buffer_string) = CONV string( lo_conv->get_buffer( ) ).

    DATA(l_buffer_string_length) =  strlen( l_buffer_string ) .
*    DESCRIBE FIELD l_buffer_string LENGTH DATA(l_buffer_string_length) IN BYTE MODE.
*    DATA(l_buffer_string_length) = cl_abap_list_utilities=>dynamic_output_length( l_buffer_string ).


    WHILE l_buffer_string_length > 0.
      IF l_buffer_string_length < c_ssfbin_length.
        APPEND VALUE #( bindata = l_buffer_string ) TO rt_data.
      ELSE.
        APPEND VALUE #( bindata = l_buffer_string(c_ssfbin_length) ) TO rt_data.
        l_buffer_string = l_buffer_string+c_ssfbin_length.
      ENDIF.
      l_buffer_string_length = l_buffer_string_length - c_ssfbin_length.
    ENDWHILE.
  ENDMETHOD.


METHOD convert_to_string.
*    LOOP AT external_source_data INTO DATA(ls_field).
    get_item_data_by_field(
                       EXPORTING
*                              im_field = ls_field-fieldname
                            im_ssf_type = ssf_type_is_utf8
                       IMPORTING
                         et_data = DATA(lt_utf8_data)
                         ex_length = DATA(l_length) ).

    APPEND VALUE #( ssf_type  = ssf_type_is_utf8
*                      fieldname = ls_field-fieldname
                    value     =   convert_utf8_to_string(
                                                   EXPORTING
                                                     im_t_utf8_data = lt_utf8_data
                                                     im_length = l_length ) )
                  TO internal_descrypted_data.
*    ENDLOOP.
  ENDMETHOD.


METHOD convert_to_utf8.
    DATA: l_item TYPE ztr_ssf_item.

    DATA(lt_utf8_data) = convert_string_to_utf8( im_string ).
    LOOP AT lt_utf8_data INTO DATA(ls_utf8_data).
      ADD 1 TO l_item.
      APPEND VALUE #(
                      uuid = encryptor_uuid
                      ssf_type = ssf_type_is_utf8
                      ssf_item = l_item
                      ssf_data = ls_utf8_data-bindata )
                  TO encripted_data.
    ENDLOOP.

    APPEND VALUE #(
                    uuid = encryptor_uuid
                    ssf_type = ssf_type_is_utf8
                    datalength = 255 )
                TO encripted_data_length.

  ENDMETHOD.


METHOD convert_utf8_to_string.
    DATA: l_string TYPE string.
    DATA: l_length TYPE i.
    DATA: l_original_length TYPE i.

    l_original_length = im_length.

    DATA(lo_conv) = cl_abap_conv_in_ce=>create(
                           encoding    = 'UTF-8'
                           replacement = '#'
                           input = value #( )
                           ignore_cerr = abap_true ).

    LOOP AT im_t_utf8_data INTO DATA(ls_utf8_data).
      IF l_original_length <= 0.
        EXIT.
      ENDIF.
      lo_conv->reset( ls_utf8_data-bindata ).
      lo_conv->read(
              IMPORTING
                data = l_string ).

      l_length = strlen( l_string ).
*      DESCRIBE FIELD l_string LENGTH l_length IN BYTE MODE.
      l_length = cl_abap_list_utilities=>dynamic_output_length( l_string ).
      IF l_length > l_original_length.
        l_length = l_original_length.
      ELSE.
        l_original_length = l_original_length - l_length.
      ENDIF.

      IF re_string IS INITIAL.
        re_string = l_string(l_length).
      ELSE.
        re_string = re_string && l_string(l_length).
      ENDIF.
      CLEAR l_string.
    ENDLOOP.

  ENDMETHOD.


METHOD do_comparison.
    DATA: lo_exception TYPE REF TO cx_static_check.

    TRY.
        get_by_business_object(
                    im_method      = method_is_comparision
                    im_object_type = im_object_type
                    im_object_code = im_object_code )->compare( im_o_encrypting_data ).
      CATCH zcx_comparision_error INTO lo_exception.
        dummy_message = lo_exception->get_text( ).
        MESSAGE e777(ztr_bank_application)
                WITH dummy_message
                INTO dummy_message.
        RAISE EXCEPTION TYPE zcx_comparision_error
          EXPORTING
            textid = VALUE #(
            msgid = sy-msgid
            msgno = sy-msgno
            attr1 = sy-msgv1
            attr2 = sy-msgv2
            attr3 = sy-msgv3
            attr4 = sy-msgv4 ).
      CATCH zcx_encryptor_create_error INTO lo_exception.
        dummy_message = lo_exception->get_text( ).
        MESSAGE e777(ztr_bank_application)
                WITH dummy_message
                INTO dummy_message.
        RAISE EXCEPTION TYPE zcx_encryptor_create_error
          EXPORTING
            textid = VALUE #(
            msgid = sy-msgid
            msgno = sy-msgno
            attr1 = sy-msgv1
            attr2 = sy-msgv2
            attr3 = sy-msgv3
            attr4 = sy-msgv4 ).
    ENDTRY.
  ENDMETHOD.


METHOD do_encryption.
    DATA: lo_exception TYPE REF TO cx_static_check.
    TRY.
        get_by_business_object(
                    im_method      = method_is_encryption
                    im_object_type = im_object_type
                    im_object_code = im_object_code )->encrypt(
                                                        EXPORTING
                                                          IM_O_ENCRYPTING_DATA = IM_O_ENCRYPTING_DATA
                                                          im_commit_work = im_commit_work
                                                        IMPORTING
                                                            ex_ssfuuid = ex_ssfuuid ).
      CATCH zcx_encryptor_create_error INTO lo_exception.
        dummy_message = lo_exception->get_text( ).
        MESSAGE e777(ztr_bank_application)
                WITH dummy_message
                INTO dummy_message.
        RAISE EXCEPTION TYPE zcx_encryptor_create_error
          EXPORTING
            textid = VALUE #(
            msgid = sy-msgid
            msgno = sy-msgno
            attr1 = sy-msgv1
            attr2 = sy-msgv2
            attr3 = sy-msgv3
            attr4 = sy-msgv4 ).
      CATCH zcx_encryption_error INTO lo_exception.
        dummy_message = lo_exception->get_text( ).
        MESSAGE e777(ztr_bank_application)
                WITH dummy_message
                INTO dummy_message.
        RAISE EXCEPTION TYPE zcx_encryption_error
          EXPORTING
            textid = VALUE #(
            msgid = sy-msgid
            msgno = sy-msgno
            attr1 = sy-msgv1
            attr2 = sy-msgv2
            attr3 = sy-msgv3
            attr4 = sy-msgv4 ).
    ENDTRY.



  ENDMETHOD.


METHOD do_paymorder_ssfcomparing.
    DATA: lo_exception TYPE REF TO cx_static_check.
    data: lo_encrypting_structure type ref to data.
DATA: lt_source TYPE ztrs_encrypting_source_tab.

    check_activation_of_encry(
                 EXPORTING
                   im_object_type = object_type_is_paymord
                 IMPORTING
                   ex_result = DATA(l_result)
                 EXCEPTIONS
                   error = 1 ).
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid
              TYPE sy-msgty
              NUMBER sy-msgno
              WITH sy-msgv1
                   sy-msgv2
                   sy-msgv3
              RAISING error.
    ENDIF.

    IF l_result = activation_result_not_active.
*    不需要加密
      RETURN.
    ENDIF.

    collect_source_data(
               EXPORTING
                 im_tabname = 'ZTRT2001'
                 im_data = im_s_2001
               CHANGING
                 ch_t_source = lt_source ).

    collect_source_data(
               EXPORTING
                 im_tabname = 'ZTRT2002'
                 im_data = im_s_2002
               CHANGING
                 ch_t_source = lt_source ).

    collect_source_data(
               EXPORTING
                 im_tabname = 'ZTRT2003'
                 im_data = im_s_2003
               CHANGING
                 ch_t_source = lt_source ).

    build_encrypting_structure(
                  EXPORTING
                    im_t_source = lt_source
                    im_object_type = object_type_is_paymord
                  IMPORTING
                    ex_o_encrypting_data = DATA(lo_encrypting_data)
                   EXCEPTIONS
                     error = 1 ).
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid
              TYPE sy-msgty
              NUMBER sy-msgno
              WITH sy-msgv1
                   sy-msgv2
                   sy-msgv3
                   sy-msgv4
              RAISING error.
    ENDIF.

    TRY.
        do_comparison(
               im_object_type = object_type_is_paymord
               im_object_code = CONV #( im_s_2001-docno )
               im_o_encrypting_data = lo_encrypting_data ).
      CATCH zcx_encryptor_create_error INTO lo_exception.
      MESSAGE e317(ztr_bank_application)
              WITH IM_S_2001-docno
                   lo_exception->get_text( )
              RAISING error.
      CATCH zcx_comparision_error INTO lo_exception.
      MESSAGE e317(ztr_bank_application)
              WITH IM_S_2001-docno
                   lo_exception->get_text( )
              RAISING error.
    ENDTRY.
*    IF lo_exception IS BOUND.
*      MESSAGE e317(ztr_bank_application)
*              WITH IM_S_2001-docno
*                   lo_exception->get_text( )
*              RAISING error.
*    ENDIF.
  ENDMETHOD.


METHOD DO_PAYMORDER_SSFCOMPARING_004.
    DATA: lo_exception TYPE REF TO cx_static_check.
    data: lo_encrypting_structure type ref to data.
DATA: lt_source TYPE ztrs_encrypting_source_tab.

    check_activation_of_encry(
                 EXPORTING
                   im_object_type = object_type_is_paymord_p004
                 IMPORTING
                   ex_result = DATA(l_result)
                 EXCEPTIONS
                   error = 1 ).
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid
              TYPE sy-msgty
              NUMBER sy-msgno
              WITH sy-msgv1
                   sy-msgv2
                   sy-msgv3
              RAISING error.
    ENDIF.

    IF l_result = activation_result_not_active.
*    不需要加密
      RETURN.
    ENDIF.

    collect_source_data(
               EXPORTING
                 im_tabname = 'ZTRT2101'
                 im_data = IM_S_2101
               CHANGING
                 ch_t_source = lt_source ).

    collect_source_data(
               EXPORTING
                 im_tabname = 'ZTRT2002'
                 im_data = im_s_2002
               CHANGING
                 ch_t_source = lt_source ).

    collect_source_data(
               EXPORTING
                 im_tabname = 'ZTRT2003'
                 im_data = im_s_2003
               CHANGING
                 ch_t_source = lt_source ).

    build_encrypting_structure(
                  EXPORTING
                    im_t_source = lt_source
                    im_object_type = object_type_is_paymord_p004
                  IMPORTING
                    ex_o_encrypting_data = DATA(lo_encrypting_data)
                   EXCEPTIONS
                     error = 1 ).
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid
              TYPE sy-msgty
              NUMBER sy-msgno
              WITH sy-msgv1
                   sy-msgv2
                   sy-msgv3
                   sy-msgv4
              RAISING error.
    ENDIF.

    TRY.
        do_comparison(
               im_object_type = object_type_is_paymord_p004
               im_object_code = CONV #( IM_S_2101-docno )
               im_o_encrypting_data = lo_encrypting_data ).
      CATCH zcx_encryptor_create_error INTO lo_exception.
      MESSAGE e317(ztr_bank_application)
              WITH IM_S_2101-docno
                   lo_exception->get_text( )
              RAISING error.
      CATCH zcx_comparision_error INTO lo_exception.
      MESSAGE e317(ztr_bank_application)
              WITH IM_S_2101-docno
                   lo_exception->get_text( )
              RAISING error.
    ENDTRY.
*    IF lo_exception IS BOUND.
*      MESSAGE e317(ztr_bank_application)
*              WITH IM_S_2101-docno
*                   lo_exception->get_text( )
*              RAISING error.
*    ENDIF.
  ENDMETHOD.


METHOD do_paymorder_ssfencryption.
    DATA: lo_exception TYPE REF TO cx_static_check.
    DATA: lt_source TYPE ztrs_encrypting_source_tab.

    check_activation_of_encry(
                 EXPORTING
                   im_object_type = object_type_is_paymord
                 IMPORTING
                   ex_result = DATA(l_result)
                 EXCEPTIONS
                   error = 1 ).
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid
              TYPE sy-msgty
              NUMBER sy-msgno
              WITH sy-msgv1
                   sy-msgv2
                   sy-msgv3
              RAISING error.
    ENDIF.

    IF l_result = activation_result_not_active.
*    不需要加密
      RETURN.
    ENDIF.

    collect_source_data(
               EXPORTING
                 im_tabname = 'ZTRT2001'
                 im_data = im_s_2001
               CHANGING
                 ch_t_source = lt_source ).

    collect_source_data(
               EXPORTING
                 im_tabname = 'ZTRT2002'
                 im_data = im_s_2002
               CHANGING
                 ch_t_source = lt_source ).

    collect_source_data(
               EXPORTING
                 im_tabname = 'ZTRT2003'
                 im_data = im_s_2003
               CHANGING
                 ch_t_source = lt_source ).

    build_encrypting_structure(
                  EXPORTING
                    im_t_source = lt_source
                    im_object_type = object_type_is_paymord
                  IMPORTING
                    ex_o_encrypting_data = DATA(lo_encrypting_data)
                   EXCEPTIONS
                     error = 1 ).
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid
              TYPE sy-msgty
              NUMBER sy-msgno
              WITH sy-msgv1
                   sy-msgv2
                   sy-msgv3
                   sy-msgv4
              RAISING error.
    ENDIF.

    TRY.
        do_encryption(
                     EXPORTING
                       im_object_type = object_type_is_paymord
                       im_object_code = CONV #( im_s_2001-docno )
*                       im_overwrite = im_overwrite
                       im_commit_work = im_commit_work
                       im_o_encrypting_data = lo_encrypting_data
                 IMPORTING
                   ex_ssfuuid = ex_ssfuuid
                                                 ).
      CATCH zcx_encryptor_create_error INTO lo_exception.
      MESSAGE e316(ztr_bank_application)
              WITH im_s_2001-docno
                   lo_exception->get_text( )
              RAISING error.
      CATCH zcx_encryption_error INTO lo_exception.
      MESSAGE e316(ztr_bank_application)
              WITH im_s_2001-docno
                   lo_exception->get_text( )
              RAISING error.
    ENDTRY.

*    IF lo_exception IS BOUND.
*      MESSAGE e316(ztr_bank_application)
*              WITH im_s_2001-docno
*                   lo_exception->get_text( )
*              RAISING error.
*    ENDIF.
  ENDMETHOD.


METHOD DO_PAYMORDER_SSFENCRYPTION_004.
    DATA: lo_exception TYPE REF TO cx_static_check.
    DATA: lt_source TYPE ztrs_encrypting_source_tab.

    check_activation_of_encry(
                 EXPORTING
                   im_object_type = object_type_is_paymord_p004
                 IMPORTING
                   ex_result = DATA(l_result)
                 EXCEPTIONS
                   error = 1 ).
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid
              TYPE sy-msgty
              NUMBER sy-msgno
              WITH sy-msgv1
                   sy-msgv2
                   sy-msgv3
              RAISING error.
    ENDIF.

    IF l_result = activation_result_not_active.
*    不需要加密
      RETURN.
    ENDIF.

    collect_source_data(
               EXPORTING
                 im_tabname = 'ZTRT2101'
                 im_data = im_s_2101
               CHANGING
                 ch_t_source = lt_source ).

    collect_source_data(
               EXPORTING
                 im_tabname = 'ZTRT2002'
                 im_data = im_s_2002
               CHANGING
                 ch_t_source = lt_source ).

    collect_source_data(
               EXPORTING
                 im_tabname = 'ZTRT2003'
                 im_data = im_s_2003
               CHANGING
                 ch_t_source = lt_source ).

    build_encrypting_structure(
                  EXPORTING
                    im_t_source = lt_source
                    im_object_type = object_type_is_paymord_p004
                  IMPORTING
                    ex_o_encrypting_data = DATA(lo_encrypting_data)
                   EXCEPTIONS
                     error = 1 ).
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid
              TYPE sy-msgty
              NUMBER sy-msgno
              WITH sy-msgv1
                   sy-msgv2
                   sy-msgv3
                   sy-msgv4
              RAISING error.
    ENDIF.

    TRY.
        do_encryption(
                     EXPORTING
                       im_object_type = object_type_is_paymord_p004
                       im_object_code = CONV #( im_s_2101-docno )
*                       im_overwrite = im_overwrite
                       im_commit_work = im_commit_work
                       im_o_encrypting_data = lo_encrypting_data
                 IMPORTING
                   ex_ssfuuid = ex_ssfuuid
                                                 ).
      CATCH zcx_encryptor_create_error INTO lo_exception.
      MESSAGE e316(ztr_bank_application)
              WITH im_s_2101-docno
                   lo_exception->get_text( )
              RAISING error.
      CATCH zcx_encryption_error INTO lo_exception.
      MESSAGE e316(ztr_bank_application)
              WITH im_s_2101-docno
                   lo_exception->get_text( )
              RAISING error.
    ENDTRY.

  ENDMETHOD.


METHOD encrypt.

    convert_to_utf8( build_external_source_string( im_o_encrypting_data ) ).
*
    if_ukey_is_valid(
        EXCEPTIONS
          not_valid = 1 ).
    IF sy-subrc = 0.
      ssf_krn_sign(
           EXCEPTIONS
             sign_error = 1 ).
      IF sy-subrc <> 0.
        RAISE EXCEPTION TYPE zcx_encryption_error
          EXPORTING
            textid = VALUE #(
            msgid = sy-msgid
            msgno = sy-msgno
            attr1 = sy-msgv1
            attr2 = sy-msgv2
            attr3 = sy-msgv3
            attr4 = sy-msgv4 ).
      ELSE.
        save( im_commit_work ).
        ex_ssfuuid = encryptor_uuid.
      ENDIF.
    ELSE.
      RAISE EXCEPTION TYPE zcx_encryption_error
        EXPORTING
          textid = VALUE #(
          msgid = sy-msgid
          msgno = sy-msgno
          attr1 = sy-msgv1
          attr2 = sy-msgv2
          attr3 = sy-msgv3
          attr4 = sy-msgv4 ).
    ENDIF.
  ENDMETHOD.


METHOD finish_data_length_before_save.
    DATA: ls_item TYPE ztrt_encrh_len.
    DATA(ls_system_info) = zcl_global_technical_service=>get_system_info( ).
    SELECT * INTO TABLE @DATA(lt_db_item)
            FROM ztrt_encrh_len
            FOR ALL ENTRIES IN @encripted_data_length
            WHERE uuid = @encripted_data_length-uuid
            AND   fieldname = @encripted_data_length-fieldname
            AND   ssf_type = @encripted_data_length-ssf_type.

    LOOP AT ENCRIPTED_DATA_LENGTH INTO DATA(ls_encripted_data_LENGTH)
          WHERE ssf_type = ssf_type_is_sign
          OR    ssf_type = ssf_type_is_krn_sign .
      MOVE-CORRESPONDING ls_encripted_data_LENGTH TO ls_item.

      READ TABLE lt_db_item INTO DATA(ls_db_item)
           WITH KEY uuid = ls_encripted_data_LENGTH-uuid
                    fieldname = ls_encripted_data_LENGTH-fieldname
                    ssf_type = ls_encripted_data_LENGTH-ssf_type.
      IF sy-subrc <> 0.
        MOVE: ls_system_info-tcode TO ls_item-tcode,
              ls_system_info-timestamp TO ls_item-update_timestamp,
              ls_system_info-timezone  TO ls_item-update_timezone,
              ls_system_info-datum TO ls_item-erdat,
              ls_system_info-uzeit TO ls_item-erzet,
              ls_system_info-uname TO ls_item-ernam.
      ELSE.
        ls_item-admin = ls_db_item-admin.
        MOVE: ls_system_info-tcode TO ls_item-tcode,
              ls_system_info-timestamp TO ls_item-update_timestamp,
              ls_system_info-timezone  TO ls_item-update_timezone,
              ls_system_info-datum TO ls_item-aedat,
              ls_system_info-uzeit TO ls_item-aezet,
              ls_system_info-uname TO ls_item-aenam.
      ENDIF.

      APPEND ls_item TO rt_data_length.
    ENDLOOP.
  ENDMETHOD.


METHOD finish_item_before_save.
    DATA: ls_item TYPE ztrt_encrh_i.
    DATA(ls_system_info) = zcl_global_technical_service=>get_system_info( ).
    SELECT * INTO TABLE @DATA(lt_db_item)
            FROM ztrt_encrh_i
            FOR ALL ENTRIES IN @encripted_data
            WHERE uuid = @encripted_data-uuid
            AND   fieldname = @encripted_data-fieldname
            AND   ssf_type = @encripted_data-ssf_type
            AND   ssf_item = @encripted_data-ssf_item.

    LOOP AT encripted_data INTO DATA(ls_encripted_data)
          WHERE ssf_type = ssf_type_is_sign
          or    ssf_type = ssf_type_is_krn_sign.
      MOVE-CORRESPONDING ls_encripted_data TO ls_item.

      READ TABLE lt_db_item INTO DATA(ls_db_item)
           WITH KEY uuid = ls_encripted_data-uuid
                    fieldname = ls_encripted_data-fieldname
                    ssf_type = ls_encripted_data-ssf_type
                    ssf_item = ls_encripted_data-ssf_item.
      IF sy-subrc <> 0.
        MOVE: ls_system_info-tcode TO ls_item-tcode,
              ls_system_info-timestamp TO ls_item-update_timestamp,
              ls_system_info-timezone  TO ls_item-update_timezone,
              ls_system_info-datum TO ls_item-erdat,
              ls_system_info-uzeit TO ls_item-erzet,
              ls_system_info-uname TO ls_item-ernam.
      ELSE.
        ls_item-admin = ls_db_item-admin.
        MOVE: ls_system_info-tcode TO ls_item-tcode,
              ls_system_info-timestamp TO ls_item-update_timestamp,
              ls_system_info-timezone  TO ls_item-update_timezone,
              ls_system_info-datum TO ls_item-aedat,
              ls_system_info-uzeit TO ls_item-aezet,
              ls_system_info-uname TO ls_item-aenam.
      ENDIF.

      APPEND ls_item TO rt_items.
    ENDLOOP.
  ENDMETHOD.


METHOD get_by_business_object.
    TRY.
        ro_encryptor = NEW #( im_object_type = im_object_type
                              im_object_code = im_object_code
                              im_method      = im_method  ).
      CATCH zcx_encryptor_create_error INTO DATA(lo_exception).
*        MESSAGE lo_exception TYPE 'E' .
        dummy_message = lo_exception->get_text( ).
        MESSAGE e777(ztr_bank_application)
                with dummy_message
                into dummy_message.
        RAISE EXCEPTION TYPE zcx_encryptor_create_error
          EXPORTING
            textid = VALUE #(
            msgid = sy-msgid
            msgno = sy-msgno
            attr1 = sy-msgv1
            attr2 = sy-msgv2
            attr3 = sy-msgv3
            attr4 = sy-msgv4 ).

    ENDTRY.
  ENDMETHOD.


METHOD get_encryption_fields_config.
    SELECT fieldname INTO TABLE rt_fields
           FROM ztrt_encrh_fld
           WHERE object_type = im_object_type.
    IF sy-subrc <> 0.
      MESSAGE e250(ztr_bank_application)
              WITH im_object_type
              RAISING not_found.
    ENDIF.
  ENDMETHOD.


METHOD get_item_data_by_field.
    IF et_data IS REQUESTED.
      LOOP AT encripted_data INTO DATA(ls_data)
            WHERE uuid = encryptor_uuid
            AND   ssf_type = im_ssf_type.
        APPEND VALUE #( bindata = ls_data-ssf_data ) TO et_data.
      ENDLOOP.
    ENDIF.

    IF ex_length IS REQUESTED.
      READ TABLE encripted_data_length INTO DATA(ls_encripted_data_length)
           WITH KEY uuid = encryptor_uuid
                    ssf_type = im_ssf_type.
      IF sy-subrc = 0.
        ex_length = ls_encripted_data_length-datalength.
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD get_ssf_parameters.
    CALL FUNCTION 'SSF_GET_PARAMETER'
      EXPORTING
        mandt                   = sy-mandt
        application             = 'DFAULT'
      IMPORTING
        appfound                = ssf_parameters-applic
        ssftoolkit              = ssf_parameters-ssftoolkit
        str_format              = ssf_parameters-ssfformat
        str_pab                 = ssf_parameters-pab
        str_pab_password        = ssf_parameters-pabpw
        str_profileid           = ssf_parameters-profileid
        str_profile             = ssf_parameters-profile
        str_profilepw           = ssf_parameters-profilepw
        str_hashalg             = ssf_parameters-hashalg
        str_encralg             = ssf_parameters-encralg
        b_inccerts              = ssf_parameters-inccerts
        b_detached              = ssf_parameters-detached
        b_distrib               = ssf_parameters-distrib
      EXCEPTIONS
        ssf_parameter_not_found = 1
        OTHERS                  = 2.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid
              TYPE sy-msgty
              NUMBER sy-msgno
              WITH sy-msgv1
                   sy-msgv2
                   sy-msgv3
                   sy-msgv4
              RAISING not_found.
    ELSE.
*        set default
      ssf_parameters-in_enc = 'X'.
      ssf_parameters-io_spec = 'T'.
*      ssf_parameters-indatalen = 255.
      ssf_parameters-b_outdec = 'X'.
    ENDIF.

  ENDMETHOD.


METHOD get_uuid_from_db.
    SELECT uuid INTO TABLE @DATA(lt_uuid) "encryptor_uuid
           FROM ztrt_encrh_h
           WHERE object_code = @object_code
           AND   object_type = @object_type.
    IF lines( lt_uuid ) > 1.
*      PROGRAM ERROR
      MESSAGE e244(ztr_bank_application)
              WITH object_type
                   object_code
              RAISING error.
    ELSE.
      READ TABLE lt_uuid INTO DATA(ls_uuid) INDEX 1.
      IF sy-subrc = 0 AND
         ls_uuid-uuid IS INITIAL.
*      PROGRAM ERROR
        MESSAGE e245(ztr_bank_application)
                WITH object_type
                     object_code
                RAISING error.
      ELSE.
        ex_uuid = ls_uuid-uuid.
      ENDIF.
    ENDIF.
  ENDMETHOD.


method IF_FROM_WEBDYNPRO.
    re_webdynpro = from_webdynpro.
  endmethod.


METHOD if_ukey_is_valid.
    DATA: l_string TYPE string VALUE 'X'.
    DATA: l_crc                TYPE ssfparms-ssfcrc.
    DATA: lt_ssfbin_out TYPE rmps_ssfbin.
    DATA: lt_signer TYPE ztr_ssfinfo_tab.

    IF check_act_of_client_and_user( ) = activation_result_not_active.
      RETURN.
    ENDIF.

    DATA(lt_sign_data_in) = convert_string_to_utf8( l_string ).

    SELECT SINGLE pname INTO @DATA(l_pname)
           FROM usracl
           WHERE bname = @sy-uname.

    APPEND VALUE ssfinfo( id = l_pname+2(253)
                          profile = profile )
                 TO lt_signer.

    CALL FUNCTION 'SSF_SIGN'
      EXPORTING
        ssf_dest                     = 'SAP_SSFATGUI'
        str_format                   = ssf_parameters-ssfformat
        b_inc_certs                  = ssf_parameters-inccerts
        b_detached                   = ssf_parameters-detached
        b_inenc                      = ssf_parameters-in_enc
        io_spec                      = ssf_parameters-io_spec
        ostr_input_data_l            = 255
        str_hashalg                  = ssf_parameters-hashalg
      IMPORTING
        crc                          = l_crc
      TABLES
        ostr_input_data              = lt_sign_data_in
        signer                       = lt_signer
        ostr_signed_data             = lt_ssfbin_out
      EXCEPTIONS
        ssf_rfc_error                = 399
        ssf_rfc_no_memory            = 201
        ssf_rfc_get_data_error       = 202
        ssf_rfc_send_data_error      = 203
        ssf_rfc_signer_list_error    = 205
        ssf_rfc_input_data_error     = 208
        ssf_fb_input_parameter_error = 209
        ssf_rfc_destination_error    = 210
        OTHERS                       = 212.
    raise_ssf_error(
              EXPORTING
                im_ssf_rc = l_crc
                im_subrc = sy-subrc
                im_step = 'SSF_SIGN'
              EXCEPTIONS
                error = 1  ).
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid
              TYPE sy-msgty
              NUMBER sy-msgno
              WITH sy-msgv1
                   sy-msgv2
                   sy-msgv3
                   sy-msgv4
              RAISING not_valid.
    ENDIF.
  ENDMETHOD.


METHOD init_for_constructor.
    CASE method.
      WHEN method_is_encryption.
        build_uuid(
                  EXCEPTIONS
                    error = 1 ).
      WHEN method_is_decryption OR
           method_is_comparision.
        get_uuid_from_db(
             IMPORTING
               ex_uuid = encryptor_uuid
             EXCEPTIONS
               error = 1 ).
        IF sy-subrc = 0.
          read_encrypted_items(
                      EXCEPTIONS
                        not_found = 1 ).
          IF sy-subrc = 0.
            read_encrypted_data_length(
                          EXCEPTIONS
                            not_found = 1 ).
          ENDIF.
        ENDIF.
    ENDCASE.

    IF sy-subrc = 0.
      get_ssf_parameters(
              EXCEPTIONS
                not_found = 1 ).
    ENDIF.

    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid
              TYPE sy-msgty
              NUMBER sy-msgno
              WITH sy-msgv1
                   sy-msgv2
                   sy-msgv3
                   sy-msgv4
              RAISING error.
    ENDIF.
  ENDMETHOD.


METHOD raise_ssf_error.
    DATA: l_exception TYPE string.
    IF im_subrc = 0.
      CASE im_ssf_rc.
        WHEN 1.
          MESSAGE e229(ztr_bank_application)
                  RAISING error.
        WHEN 2.
          MESSAGE e230(ztr_bank_application)
                  RAISING error.
        WHEN 3.
*          IF im_step <> 'VERIFY_CODE'.
*            MESSAGE e231(ztr_bank_application)
*                    RAISING error.
*          ENDIF.
        WHEN 4.
          MESSAGE e232(ztr_bank_application)
                  RAISING error.
        WHEN 5.
          MESSAGE e233(ztr_bank_application)
                  RAISING error.
        WHEN 6.
          MESSAGE e232(ztr_bank_application)
                  RAISING error.
        WHEN 7.
          MESSAGE e235(ztr_bank_application)
                  RAISING error.
        WHEN 8.
          MESSAGE e236(ztr_bank_application)
                  RAISING error.
        WHEN 9.
          MESSAGE e237(ztr_bank_application)
                  RAISING error.
        WHEN 10.
          MESSAGE e238(ztr_bank_application)
                  RAISING error.
        WHEN 11.
          MESSAGE e239(ztr_bank_application)
                  RAISING error.
        WHEN 12.
          IF im_step <> 'VERIFY_CORE'.
            MESSAGE e240(ztr_bank_application)
                    RAISING error.
          ENDIF.
        WHEN 13.
          MESSAGE e241(ztr_bank_application)
                  RAISING error.
      ENDCASE.
    ELSE.
      CASE sy-subrc.
        WHEN 101.
          MOVE 'SSF_RFC_ERROR' TO l_exception.              "#EC NOTEXT
        WHEN 102.
          MOVE 'SSF_RFC_NOMEMORY' TO l_exception.           "#EC NOTEXT
        WHEN 103.
          MOVE 'SSF_RFC_GET_DATA_ERROR' TO l_exception.     "#EC NOTEXT
        WHEN 104.
          MOVE 'SSF_RFC_SEND_DATA_ERROR' TO l_exception.    "#EC NOTEXT
        WHEN 105.
          MOVE 'SSF_RFC_SIGNER_LIST_ERROR' TO l_exception.  "#EC NOTEXT
        WHEN 106.
          MOVE 'SSF_RFC_RECIPIENT_ERROR' TO l_exception.    "#EC NOTEXT
        WHEN 107.
          MOVE 'SSF_RFC_RECIPIENT_LIST_ERROR' TO l_exception. "#EC NOTEXT
        WHEN 108.
          MOVE 'SSF_RFC_INPUT_DATA_ERROR' TO l_exception.   "#EC NOTEXT
        WHEN 109.
          MOVE 'SSF_FB_INPUT_PARAMETER_ERROR' TO l_exception. "#EC NOTEXT
        WHEN 110.
          MOVE 'SSF_RFC_DESTINATION_ERROR' TO l_exception.  "#EC NOTEXT
        WHEN 201.
          MOVE 'SSF_NOOP' TO l_exception.                   "#EC NOTEXT
        WHEN 202.
          MOVE 'SSF_KRN_NOMEMORY' TO l_exception.           "#EC NOTEXT
        WHEN 203.
          MOVE 'SSF_KRN_OPINV' TO l_exception.              "#EC NOTEXT
        WHEN 204.
          MOVE 'SSF_KRN_NOSSFLIB' TO l_exception.           "#EC NOTEXT
        WHEN 205.
          MOVE 'SSF_KRN_SIGNER_LIST_ERROR' TO l_exception.  "#EC NOTEXT
        WHEN 206.
          MOVE 'SSF_KRN_RECIPIENT_ERROR' TO l_exception.    "#EC NOTEXT
        WHEN 207.
          MOVE 'SSF_KRN_RECIPIENT_LIST_ERROR' TO l_exception. "#EC NOTEXT
        WHEN 208.
          MOVE 'SSF_KRN_INPUT_DATA_ERROR' TO l_exception.   "#EC NOTEXT
        WHEN 209.
          MOVE 'SSF_KRN_INVALID_PAR' TO l_exception.        "#EC NOTEXT
        WHEN 210.
          MOVE 'SSF_KRN_INVALID_PARLEN' TO l_exception.     "#EC NOTEXT
        WHEN 399.
          MOVE 'SSF_KRN_UNKNOWN_ERROR' TO l_exception.      "#EC NOTEXT
      ENDCASE.
      IF l_exception IS NOT INITIAL.
        MESSAGE e242(ztr_bank_application)
                WITH l_exception
*                     IM_FIELD
                     im_step
                RAISING error.
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD read_encrypted_data_length.
    SELECT * INTO CORRESPONDING FIELDS OF TABLE encripted_data_length
            FROM ztrt_encrh_len
            WHERE uuid = encryptor_uuid.
    IF sy-subrc <> 0.
      MESSAGE e249(ztr_bank_application)
              WITH object_type
                   object_code
                   encryptor_uuid
              RAISING not_found.
    ENDIF.
  ENDMETHOD.


METHOD read_encrypted_items.
    SELECT * INTO CORRESPONDING FIELDS OF TABLE encripted_data
            FROM ztrt_encrh_i
            WHERE uuid = encryptor_uuid.
    IF sy-subrc <> 0.
      MESSAGE e247(ztr_bank_application)
              WITH object_type
                   object_code
                   encryptor_uuid
              RAISING not_found.
    ENDIF.
  ENDMETHOD.


METHOD save.
    DATA(ls_header) = build_header( ).

    DATA(lt_item_for_save) = finish_item_before_save( ).

    DATA(lt_data_length_for_save) = finish_data_length_before_save( ).

*    MODIFY ztrt_encrh_h FROM ls_header.
*
*    MODIFY ztrt_encrh_i FROM TABLE lt_item_for_save.
*
*    MODIFY ztrt_encrh_len FROM TABLE lt_data_length_for_save.

    CALL FUNCTION 'ZFM_TR_SSFENCRYPTION_SAVE' IN UPDATE TASK
      EXPORTING
        im_s_header = ls_header
        im_t_items  = lt_item_for_save
        im_t_length = lt_data_length_for_save.

    IF im_commit_work = 'X'.
      COMMIT WORK AND WAIT .
    ENDIF.

  ENDMETHOD.


method SET_FROM_WEBDYNPRO.
   from_webdynpro = 'X'.
  endmethod.


method SET_SKIP.
    skip = 'X'.
  endmethod.


METHOD SSF_KRN_DEVELOPE.


  ENDMETHOD.


METHOD SSF_KRN_ENVELOPE.

  ENDMETHOD.


METHOD ssf_krn_sign.
    DATA: l_ostr_signed_data_l TYPE ssfparms-outdatalen,
          l_crc                TYPE ssfparms-ssfcrc.
    DATA: lt_ssfbin_out TYPE rmps_ssfbin.
    DATA: lt_signer TYPE ztr_ssfinfo_tab.
    DATA: l_item TYPE ztr_ssf_item.

    get_item_data_by_field(
                       EXPORTING
                            im_ssf_type = ssf_type_is_utf8
                       IMPORTING
                         et_data = DATA(lt_sign_data_in)
                         ex_length = DATA(l_length) ).

    APPEND VALUE ssfinfo( id = ssf_parameters-profileid
                          profile = ssf_parameters-profile )
                 TO lt_signer.

    CALL FUNCTION 'SSF_KRN_SIGN'
      EXPORTING
        str_format                   = ssf_parameters-ssfformat
        b_inc_certs                  = ssf_parameters-inccerts
        b_detached                   = ssf_parameters-detached
        b_inenc                      = ssf_parameters-in_enc
        io_spec                      = ssf_parameters-io_spec
        ostr_input_data_l            = l_length
        str_hashalg                  = ssf_parameters-hashalg
      IMPORTING
        ostr_signed_data_l           = l_ostr_signed_data_l
        crc                          = l_crc
      TABLES
        ostr_input_data              = lt_sign_data_in
        signer                       = lt_signer
        ostr_signed_data             = lt_ssfbin_out
      EXCEPTIONS
        ssf_krn_error                = 399
        ssf_krn_noop                 = 201
        ssf_krn_nomemory             = 202
        ssf_krn_opinv                = 203
        ssf_krn_signer_list_error    = 205
        ssf_krn_input_data_error     = 208
        ssf_krn_invalid_par          = 209
        ssf_krn_invalid_parlen       = 210
        ssf_fb_input_parameter_error = 211
        OTHERS                       = 212.
    raise_ssf_error(
              EXPORTING
                im_ssf_rc = l_crc
                im_subrc = sy-subrc
                im_step = 'SSF_SIGN'
              EXCEPTIONS
                error = 1  ).

    IF sy-subrc = 0.
      LOOP AT lt_ssfbin_out INTO DATA(ls_ssfbin_out).
        ADD 1 TO l_item.
        APPEND VALUE #(
                        uuid = encryptor_uuid
                        ssf_type = ssf_type_is_krn_sign
                        ssf_item = l_item
                        ssf_data = ls_ssfbin_out-bindata )
                    TO encripted_data.
      ENDLOOP.
      APPEND VALUE #(
                      uuid = encryptor_uuid
                      ssf_type = ssf_type_is_krn_sign
                      datalength = l_ostr_signed_data_l )
                  TO encripted_data_length.
    ELSE.
      MESSAGE ID sy-msgid
              TYPE sy-msgty
              NUMBER sy-msgno
              WITH sy-msgv1
                   sy-msgv2
                   sy-msgv3
                   sy-msgv4
              INTO dummy_message.
      MESSAGE e252(ztr_bank_application)
              WITH object_type
                   object_code
                   dummy_message
              RAISING sign_error.
    ENDIF.
  ENDMETHOD.


METHOD ssf_krn_verify.
    DATA: l_ostr_verify_data_l TYPE ssfparms-outdatalen,
          l_crc                TYPE ssfparms-ssfcrc.
    DATA: lt_recipient_list TYPE ztr_ssfinfo_tab.
    DATA: lt_ssfbin_out TYPE rmps_ssfbin.
    DATA: l_current_ssf_type TYPE ztr_ssf_type.
    DATA: lt_signer_result_list TYPE ztr_ssfinfo_tab.
    FIELD-SYMBOLS: <f_item> TYPE ztr_ssf_item.
    DATA: l_password TYPE ssfparms-pabpw.
    DATA: l_pab TYPE ssfparms-pab VALUE profile.
    DATA: l_verify_4_sign_item     TYPE ztr_ssf_item,
          l_verify_4_envelope_item TYPE ztr_ssf_item.


    sy-subrc = 0.

    get_item_data_by_field(
                       EXPORTING
*                            im_field = im_field
                            im_ssf_type = ssf_type_is_krn_sign
                       IMPORTING
                         ex_length = DATA(l_signed_length) ).

    get_item_data_by_field(
                       EXPORTING
*                            im_field = im_field
                            im_ssf_type = im_verify_for_ssf_type
                       IMPORTING
                         et_data = DATA(lt_ssfbin_data)
                         ex_length = DATA(l_length) ).

    get_item_data_by_field(
                       EXPORTING
*                            im_field = im_field
                            im_ssf_type = ssf_type_is_utf8
                       IMPORTING
                         et_data = DATA(lt_input_data_utf8)  ).
    CALL FUNCTION 'SSF_KRN_VERIFY'
      EXPORTING
        str_format                   = ssf_parameters-ssfformat
        b_inc_certs                  = ssf_parameters-inccerts
        b_inenc                      = ssf_parameters-in_enc
        b_outdec                     = ssf_parameters-b_outdec
        io_spec                      = ssf_parameters-io_spec
        ostr_signed_data_l           = l_signed_length
        ostr_input_data_l            = 255
        str_pab                      = ssf_parameters-pab
        str_pab_password             = l_password
      IMPORTING
        ostr_output_data_l           = l_ostr_verify_data_l
        crc                          = l_crc
      TABLES
        ostr_signed_data             = lt_ssfbin_data
        ostr_input_data              = lt_input_data_utf8
        signer_result_list           = lt_signer_result_list
        ostr_output_data             = lt_ssfbin_out
      EXCEPTIONS
        ssf_krn_error                = 399
        ssf_krn_noop                 = 201
        ssf_krn_nomemory             = 202
        ssf_krn_opinv                = 203
        ssf_krn_input_data_error     = 208
        ssf_krn_invalid_par          = 209
        ssf_krn_invalid_parlen       = 210
        ssf_fb_input_parameter_error = 109
        OTHERS                       = 212.

    raise_ssf_error(
              EXPORTING
                im_ssf_rc = l_crc
                im_subrc = sy-subrc
                im_step = 'VERIFY_CORE'
*                im_field = im_field
              EXCEPTIONS
                error = 1  ).
    IF sy-subrc = 0.
      CASE im_verify_for_ssf_type.
        WHEN ssf_type_is_develope.
          l_current_ssf_type = ssf_type_is_krn_verify_4_env.
        WHEN ssf_type_is_krn_sign.
          l_current_ssf_type = ssf_type_is_krn_verify_4_sign.
      ENDCASE.

      CASE l_current_ssf_type.
        WHEN ssf_type_is_krn_verify_4_sign.
          ASSIGN l_verify_4_sign_item TO <f_item>.
        WHEN ssf_type_is_krn_verify_4_env.
          ASSIGN l_verify_4_envelope_item TO <f_item>.
      ENDCASE.
      LOOP AT lt_ssfbin_out INTO DATA(ls_ssfbin_out).
        ADD 1 TO <f_item>.
        APPEND VALUE #(
                        uuid = encryptor_uuid
                        ssf_type = l_current_ssf_type
                        ssf_item = <f_item>
*                        fieldname = im_field
                        ssf_data = ls_ssfbin_out-bindata )
                    TO encripted_data.
      ENDLOOP.
      APPEND VALUE #(
                      uuid = encryptor_uuid
                      ssf_type = l_current_ssf_type
*                      fieldname = im_field
                      datalength = l_ostr_verify_data_l )
                  TO encripted_data_length.

      APPEND VALUE #( ssf_type  = l_current_ssf_type
*                      fieldname = im_field
                      value     = convert_utf8_to_string(
                                          EXPORTING
                                            im_t_utf8_data = lt_ssfbin_out
                                            im_length = l_ostr_verify_data_l ) )
                    TO internal_descrypted_data.
    ELSE.
      MESSAGE ID sy-msgid
              TYPE sy-msgty
              NUMBER sy-msgno
              WITH sy-msgv1
                   sy-msgv2
                   sy-msgv3
                   sy-msgv4
             INTO dummy_message.

      MESSAGE e255(ztr_bank_application)
              WITH object_type
                   object_code
*                   im_field
                   dummy_message
              RAISING verify_error.

    ENDIF.
  ENDMETHOD.
ENDCLASS.
