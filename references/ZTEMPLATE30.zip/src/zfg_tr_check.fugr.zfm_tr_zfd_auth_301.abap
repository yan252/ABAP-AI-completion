FUNCTION ZFM_TR_ZFD_AUTH_301.
**"--------------------------------------------------------------------
**"*"局部接口：
**"  IMPORTING
**"     REFERENCE(BUKRS) TYPE  BUKRS
**"     REFERENCE(CKACT) TYPE  ZTR_CKACT
**"  EXCEPTIONS
**"      ERR
**"--------------------------------------------------------------------
*DATA: lv_string  TYPE string.
*  IF NOT  ( zcl_tr_3024_gui=>auth = abap_true OR sy-sysid = 'ERP' ).
*    sy-subrc = 0.
*    RETURN.
*  ENDIF.
*  AUTHORITY-CHECK OBJECT 'Z_TR301'
*    ID 'BUKRS' FIELD bukrs
*    ID 'ZTR_CKACT' FIELD ckact.
*  IF sy-subrc <> 0.
*    zcl_wd_common=>get_dom_value(
*      EXPORTING
*        im_domnam = 'ZDMTR_CKACT'
*        im_domval = ckact
*      RECEIVING
*        ex_desc   = lv_string
*    ).
*    MESSAGE e249(ztr05) WITH bukrs lv_string  RAISING err.
*  ENDIF.
*




ENDFUNCTION.
