"Name: \TY:CL_EPIC_BANK_COMM_LOGON\ME:INSERT\SE:BEGIN\EI
ENHANCEMENT 0 ZTR_BANK_LOGON_INSERT_USER.

TRY.
  ZCL_BANK_ENHANCEMENT_SERVICE=>insert_logon_user(
          EXPORTING
            IM_NAME = IV_NAME
            IM_DESCR = IV_DESCR
            IM_NEW_PWD = IV_NEW_PWD
            IM_REPEAT_PWD = IV_REPEAT_PWD
            IM_O_LOGON_USER = ME
          IMPORTING
            EX_ENHANCEMENT_DONE = DATA(L_DONE) ).
      CATCH cx_epic_bank_comm_logon INTO DATA(LO_ENHM_epic_bank_comm_logon).
        RAISE EXCEPTION TYPE cx_epic_bank_comm_logon
          EXPORTING
            previous = LO_ENHM_epic_bank_comm_logon.
ENDTRY.
IF L_DONE = 'X'.
  EXIT.
ENDIF.
ENDENHANCEMENT.
