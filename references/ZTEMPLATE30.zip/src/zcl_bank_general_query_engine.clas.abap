class ZCL_BANK_GENERAL_QUERY_ENGINE definition
  public
  final
  create public .

public section.

  constants YES type FLAG value 'X' ##NO_TEXT.
  constants NO type FLAG value SPACE ##NO_TEXT.
  constants DEFAULT_MESSAGE_CLASS type SYMSGID value 'ZTR_BANK_APPLICATION' ##NO_TEXT.
  class-data DUMMY_MESSAGE type STRING .

  class-methods QUERY_PAYMENT_STATUS
    importing
      !IM_T_PAYMORDER_RANGE type ZTRT_PAYMORDER_RANGE
      !IM_T_BANK_IND_RANGE type ZTRT_BANK_IND_RANGE
      !IM_TRIGGER_BY_ACC_TRANX type CHAR01 default SPACE .
  class-methods QUEREY_ACCOUNT_BALANCE
    importing
      !IM_T_BANK_IND_RANGE type ZTRT_BANK_IND_RANGE
      !IM_T_BANK_ACC_RANGE type ZTRT_BANK_ACC_RANGE
      !IM_START_DATE type SYDATUM optional
      !IM_END_DATE type SYDATUM optional
      !IM_HISTORY_BALANCE type FLAG optional .
  class-methods QUEREY_TRANSACTIONS
    importing
      !IM_T_BANK_IND_RANGE type ZTRT_BANK_IND_RANGE
      !IM_T_BANK_ACC_RANGE type ZTRT_BANK_ACC_RANGE
      !IM_START_DATE type SYDATUM optional
      !IM_END_DATE type SYDATUM optional .
  class-methods QUERY_EDOC_LIST
    importing
      !IM_T_BANK_IND_RANGE type ZTRT_BANK_IND_RANGE
      !IM_T_BANK_ACC_RANGE type ZTRT_BANK_ACC_RANGE .
  class-methods QUERY_SHDOCNO_STATUS
    importing
      !IM_T_REDEEMORDER_RANGE type ZLTTR2_SHDOCNO_RANGE
      !IM_T_BANK_IND_RANGE type ZTRT_BANK_IND_RANGE .
protected section.
private section.

  class-methods GET_OPEN_PAYMENT_ORDER
    importing
      !IM_T_PAYMORDER_RANGE type ZTRT_PAYMORDER_RANGE
      !IM_T_BANK_IND_RANGE type ZTRT_BANK_IND_RANGE
      !IM_TRIGGER_BY_ACC_TRANX type CHAR01 default SPACE
    returning
      value(RT_PAYMENT_ENTRY_LIST) type ZTRS_PAYMENTENTRY_LIST_TAB .
  class-methods GET_ACCOUNTS
    importing
      !IM_T_BANK_IND_RANGE type ZTRT_BANK_IND_RANGE
      !IM_T_BANK_ACC_RANGE type ZTRT_BANK_ACC_RANGE
      !IM_START_DATE type SYDATUM optional
      !IM_END_DATE type SYDATUM optional
    returning
      value(RT_ACCOUNTS) type ZTRS_BANK_ACCOUNT_TAB .
  class-methods GET_OPEN_SHDOCNO
    importing
      !IM_SHDOCNO_RANGE type ZLTTR2_SHDOCNO_RANGE
      !IM_BANK_IND_RANGE type ZTRT_BANK_IND_RANGE
    returning
      value(ET_DATA) type ZLTTR2_BANK_CHECK_STATUS_IN .
ENDCLASS.



CLASS ZCL_BANK_GENERAL_QUERY_ENGINE IMPLEMENTATION.


METHOD get_accounts.

    MESSAGE i093(ztr_bank_application)
            WITH sy-uname
                 sy-datum
                 sy-uzeit
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log( VALUE #( msgid = sy-msgid
                      msgno = sy-msgno
                      msgty = sy-msgty
                      msgv1 = sy-msgv1
                      msgv2 = sy-msgv2
                      msgv3 = sy-msgv3
                      msgv4 = sy-msgv4
                      message = dummy_message )
                      ).

    SELECT ztrt0013~bukrs AS sap_bukrs
           ztrt0013~hbkid AS sap_hbkid
           ztrt0013~hktid AS sap_hktid
           ztrt0013~waers AS sap_waers
           ztrt0013~bank_ind
           ztrt0013~yhzh AS bankn
           INTO CORRESPONDING FIELDS OF TABLE rt_accounts
           FROM ztrt0013
           INNER JOIN ztrt_bank
           on ztrt0013~bank_ind = ztrt_bank~bank_ind
           WHERE ztrt0013~bank_ind IN im_t_bank_ind_range
           AND   ztrt0013~yhzh IN im_t_bank_acc_range
           AND   ztrt0013~is_yqzl = '1'
           AND   ( ztrt0013~is_nxh = '0'
           OR      ztrt0013~is_nxh = space )
           AND   ztrt0013~del_flg = space
           and   ztrt_bank~active = 'X'.

    SORT rt_accounts BY sap_bukrs
                        sap_hbkid
                        sap_hktid
                        bank_ind
                        bankn.
    DELETE ADJACENT DUPLICATES FROM rt_accounts
              COMPARING sap_bukrs
                        sap_hbkid
                        sap_hktid
                        bank_ind
                        bankn.
    LOOP AT rt_accounts ASSIGNING FIELD-SYMBOL(<fs_account>).
      <fs_account>-start_date = im_start_date.
      <fs_account>-end_date = im_end_date.
    ENDLOOP.
  ENDMETHOD.


METHOD get_open_payment_order.
    DATA: lt_entry_status TYPE RANGE OF ztr_entstatus.
    DATA: lt_source_keeped      TYPE ztrs_paymententry_list_tab,
          lt_payment_entry_list TYPE ztrs_paymententry_list_tab.
    DATA: l_timestamp TYPE timestampl.

    MESSAGE i093(ztr_bank_application)
            WITH sy-uname
                 sy-datum
                 sy-uzeit
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log( VALUE #( msgid = sy-msgid
                      msgno = sy-msgno
                      msgty = sy-msgty
                      msgv1 = sy-msgv1
                      msgv2 = sy-msgv2
                      msgv3 = sy-msgv3
                      msgv4 = sy-msgv4
                      message = dummy_message )
                      ).

    SELECT entuuid,
           paymorder,
           draft_zxh
           INTO TABLE @DATA(lt_entry_source)
           FROM ztrt_paymlink
           WHERE paymorder IN @im_t_paymorder_range
           AND   ordstatus = '24'.

    SELECT entstatus AS low
           INTO CORRESPONDING FIELDS OF TABLE lt_entry_status
           FROM ztrt_entstatus
           WHERE check_status = 'X'.
    LOOP AT lt_entry_status INTO DATA(ls_entry_status).
      ls_entry_status-sign = 'I'.
      ls_entry_status-option = 'EQ'.
      MODIFY lt_entry_status FROM ls_entry_status INDEX sy-tabix.
    ENDLOOP.

*Ö§¸¶¶©µ¥¸Õ½øÈëÒøÆóÖ±Á¬²úÉúÒøÆóÖ±Á¬Ê±£¬ÕâÊ±ÌõÄ¿×´Ì¬Îª¿Õ
*Òò´ËÖ§¸¶ÌõÄ¿¼ÇÂ¼ÀïÀíÂÛÉÏÓÐ¿ÉÄÜ´æÔÚ¿Õ°××´Ì¬µÄ¼ÇÂ¼
*µ«Õâ¸ö×´Ì¬ºÜ¿ì¾Í»á±»¸üÐÂ£¬³ý·Ç³ÌÐò´íÎó¡¢»ò²âÊÔÏµÍ³µÄÊý¾ÝÎÊÌâµÈµÈ
    CLEAR ls_entry_status.
    ls_entry_status-sign = 'I'.
    ls_entry_status-option = 'EQ'.
    APPEND ls_entry_status TO lt_entry_status.

    IF lt_entry_status IS NOT INITIAL.
      SELECT entuuid
             paymorder
             draft_zxh
             APPENDING TABLE lt_entry_source
             FROM ztrt_payment
             WHERE paymorder IN im_t_paymorder_range
             AND   entstatus IN lt_entry_status
             AND   bank_ind IN im_t_bank_ind_range.
    ENDIF.

    SORT lt_entry_source BY entuuid
                            paymorder
                            draft_zxh.
    DELETE ADJACENT DUPLICATES FROM lt_entry_source COMPARING ALL FIELDS.

    LOOP AT lt_entry_source INTO DATA(ls_entry_source).
      LOOP AT lt_source_keeped TRANSPORTING NO FIELDS
           WHERE entuuid <> ls_entry_source-entuuid
           AND   paymorder = ls_entry_source-paymorder
           AND   draft_zxh = ls_entry_source-draft_zxh.
*        ÑÏÖØ´íÎó
*        ÎªÊ²Ã´Ò»¸öÖ§¸¶¶©µ¥»á¶ÔÓ¦Á½¸ö»òÒÔÉÏÓÐÐ§µÄÖ§¸¶ÌõÄ¿£¿£¿
*        Í¶ÈëÉú²úºó²»Ó¦¸Ã³öÏÖÕâ¸öÇé¿ö
        MESSAGE s094
                WITH ls_entry_source-paymorder
                DISPLAY LIKE 'E'.
*        ³öÏÖÕâ¸ö´íÎóµÄÖ§¸¶¶©µ¥²»»á·¢ËÍµ½ÒøÐÐ¼ì²é×´Ì¬
        DELETE rt_payment_entry_list
               WHERE paymorder = ls_entry_source-paymorder
               AND   draft_zxh = ls_entry_source-draft_zxh.
        EXIT.
      ENDLOOP.
      IF sy-subrc <> 0.
        APPEND ls_entry_source TO lt_payment_entry_list.
      ENDIF.
      APPEND ls_entry_source TO lt_source_keeped.
    ENDLOOP.

    IF lt_payment_entry_list IS NOT INITIAL.
      GET TIME STAMP FIELD l_timestamp.
*
*      l_timestamp = cl_abap_timestamp_util=>get_instance( )->tstmpl_add_seconds(
*                                                                iv_timestamp = l_timestamp
*                                                                iv_seconds = CONV #( 3 * 60 * -1 ) ).
      SELECT entuuid,
             paymorder,
             draft_zxh,
             update_timestamp
             INTO TABLE @DATA(lt_raw_entries) "rt_payment_entry_list
             FROM ztrt_payment AS a
             INNER JOIN ztrt_bank AS b
             ON a~bank_ind = b~bank_ind
             FOR ALL ENTRIES IN @lt_payment_entry_list
             WHERE a~entuuid = @lt_payment_entry_list-entuuid
             AND   a~bank_ind <> @space
             AND   b~bank_ind IN @im_t_bank_ind_range
             AND   b~active = 'X'.
      LOOP AT lt_raw_entries INTO DATA(ls_raw_entry).
        IF im_trigger_by_acc_tranx = space.
          IF cl_abap_timestamp_util=>get_instance( )->tstmpl_seconds_between(
                                               iv_timestamp0 = ls_raw_entry-update_timestamp
                                               iv_timestamp1 = l_timestamp ) >= 300.
*          5·ÖÖÓÇ°´¦ÀíµÄÖ§¸¶ÌõÄ¿²»¼ì²éÖ§¸¶×´Ì¬
            APPEND VALUE #( entuuid = ls_raw_entry-entuuid
                            paymorder = ls_raw_entry-paymorder
                            draft_zxh = ls_raw_entry-draft_zxh )
                   TO rt_payment_entry_list.
          ENDIF.
        ELSE.
          APPEND VALUE #( entuuid = ls_raw_entry-entuuid
                          paymorder = ls_raw_entry-paymorder
                          draft_zxh = ls_raw_entry-draft_zxh )
                 TO rt_payment_entry_list.
        ENDIF.
      ENDLOOP.
    ENDIF.

    DATA(l_lines) = lines( rt_payment_entry_list ).

    MESSAGE i201(ztr_bank_application)
            WITH l_lines
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log( VALUE #( msgid = sy-msgid
                      msgno = sy-msgno
                      msgty = sy-msgty
                      msgv1 = sy-msgv1
                      msgv2 = sy-msgv2
                      msgv3 = sy-msgv3
                      msgv4 = sy-msgv4
                      message = dummy_message )
                      ).

  ENDMETHOD.


METHOD get_open_shdocno.

    SELECT shdocno
           zeile
           bank_ind
    INTO CORRESPONDING FIELDS OF TABLE et_data
    FROM ztrt9504
    WHERE shdocno IN im_shdocno_range
      AND bank_ind IN im_bank_ind_range.


  ENDMETHOD.


METHOD querey_account_balance.
    DATA: l_start_date TYPE sydatum,
          l_end_date   TYPE sydatum.
    DATA: l_action TYPE ztr_app_action_for_bank.

    zcl_bank_logger_protocal=>add_message_collector(
                 EXPORTING
                   im_default_message_class = default_message_class
                   im_mainprogram           = sy-repid  ).

    MESSAGE i203(ztr_bank_application)
            INTO dummy_message.

    zcl_bank_logger_protocal=>add_log(
             VALUE #( msgid = sy-msgid
                      msgno = sy-msgno
                      msgty = sy-msgty
                      msgv1 = sy-msgv1
                      msgv2 = sy-msgv2
                      msgv3 = sy-msgv3
                      msgv4 = sy-msgv4
                      message = dummy_message )
                      ).

    IF im_history_balance = 'X'.
      IF im_start_date IS INITIAL.
        l_start_date = sy-datum - 1.
      ELSE.
        l_start_date = im_start_date.
      ENDIF.

      IF im_end_date IS INITIAL.
        l_end_date = sy-datum - 1.
      ELSE.
        l_end_date = im_end_date.
      ENDIF.

      l_action = zif_bank_action=>action_is_acc_history_balance.
    ELSE.
      l_action = zif_bank_action=>action_is_account_balance.
    ENDIF.

    CALL FUNCTION 'ZFM_TR_BANK_MEDIUM_ACQUERY_API'
      EXPORTING
        im_action    = l_action
        im_t_account = get_accounts(
                           EXPORTING
                              im_t_bank_ind_range = im_t_bank_ind_range
                              im_t_bank_acc_range = im_t_bank_acc_range
                              im_start_date       = l_start_date
                              im_end_date         = l_end_date ).

  ENDMETHOD.


METHOD querey_transactions.
    DATA: l_start_date TYPE sydatum,
          l_end_date   TYPE sydatum.

    zcl_bank_logger_protocal=>add_message_collector(
                 EXPORTING
                   im_default_message_class = default_message_class
                   im_mainprogram           = sy-repid  ).

    MESSAGE i205(ztr_bank_application)
            INTO dummy_message.

    zcl_bank_logger_protocal=>add_log(
             VALUE #( msgid = sy-msgid
                      msgno = sy-msgno
                      msgty = sy-msgty
                      msgv1 = sy-msgv1
                      msgv2 = sy-msgv2
                      msgv3 = sy-msgv3
                      msgv4 = sy-msgv4
                      message = dummy_message )
                      ).

    IF im_start_date IS INITIAL.
      l_start_date = sy-datum - 1.
    ELSE.
      l_start_date = im_start_date.
    ENDIF.

    IF im_end_date IS INITIAL.
      l_end_date = sy-datum - 1.
    ELSE.
      l_end_date = im_end_date.
    ENDIF.

    CALL FUNCTION 'ZFM_TR_BANK_MEDIUM_ACQUERY_API'
      EXPORTING
        im_action    = zif_bank_action=>action_is_get_transactions
        im_t_account = get_accounts(
                           EXPORTING
                              im_t_bank_ind_range = im_t_bank_ind_range
                              im_t_bank_acc_range = im_t_bank_acc_range
                              im_start_date       = l_start_date
                              im_end_date         = l_end_date ).

  ENDMETHOD.


METHOD query_edoc_list.
    zcl_bank_logger_protocal=>add_message_collector(
                 EXPORTING
                   im_default_message_class = default_message_class
                   im_mainprogram           = sy-repid  ).

    MESSAGE i203(ztr_bank_application)
            INTO dummy_message.

    zcl_bank_logger_protocal=>add_log(
             VALUE #( msgid = sy-msgid
                      msgno = sy-msgno
                      msgty = sy-msgty
                      msgv1 = sy-msgv1
                      msgv2 = sy-msgv2
                      msgv3 = sy-msgv3
                      msgv4 = sy-msgv4
                      message = dummy_message )
                      ).

    CALL FUNCTION 'ZFM_TR_BANK_MEDIUM_ACQUERY_API'
      EXPORTING
        im_action    = zif_bank_action=>action_is_get_edoc_list
        im_t_account = get_accounts(
                           EXPORTING
                              im_t_bank_ind_range = im_t_bank_ind_range
                              im_t_bank_acc_range = im_t_bank_acc_range ).
  ENDMETHOD.


METHOD query_payment_status.

    zcl_bank_logger_protocal=>add_message_collector(
                 EXPORTING
                   im_default_message_class = default_message_class
                   im_mainprogram           = sy-repid  ).

    IF im_trigger_by_acc_tranx = space.
      MESSAGE i199(ztr_bank_application)
              INTO dummy_message.
    ELSE.
      MESSAGE i355(ztr_bank_application)
              INTO dummy_message.
    ENDIF.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( msgid = sy-msgid
                      msgno = sy-msgno
                      msgty = sy-msgty
                      msgv1 = sy-msgv1
                      msgv2 = sy-msgv2
                      msgv3 = sy-msgv3
                      msgv4 = sy-msgv4
                      message = dummy_message )
                      ).

    CALL FUNCTION 'ZFM_TR_BANK_MEDIUM_CHKPAYM_API'
      EXPORTING
        IM_TRIGGER_BY_ACC_TRANX = IM_TRIGGER_BY_ACC_TRANX
        im_t_entry_list = get_open_payment_order(
                                               EXPORTING
                                                  im_t_paymorder_range = im_t_paymorder_range
                                                  im_t_bank_ind_range = im_t_bank_ind_range
                                                  im_trigger_by_acc_tranx = im_trigger_by_acc_tranx ).

*    SUBMIT ztre02006_job
*           AND RETURN.
    SUBMIT ZTRE1012_JOB
            WITH p_nodis = im_trigger_by_acc_tranx.
  ENDMETHOD.


METHOD query_shdocno_status.
    DATA:lt_9503    TYPE TABLE OF ztrt9503,
         lt_9504    TYPE TABLE OF ztrt9504,
         lt_9504_db TYPE TABLE OF ztrt9504.
    DATA(lt_out) = zcl_tr2_bank_interface_cbi=>check_status( get_open_shdocno( im_shdocno_range = im_t_redeemorder_range
                                                                im_bank_ind_range = im_t_bank_ind_range  ) ).

    SELECT * INTO CORRESPONDING FIELDS OF TABLE @lt_9504
     FROM ztrt9504 FOR ALL ENTRIES IN @lt_out
      WHERE shdocno = @lt_out-shdocno.

    LOOP AT lt_out INTO DATA(temp_out).
      SELECT SINGLE bank_rtncode, rtntype,entstatus, bank_rtnmsg
      INTO  @DATA(ls_rtncod)
      FROM ztrt_bank_rtncod
      WHERE bank_rtncode = @temp_out-bank_rtncode AND bank_ind = @temp_out-bank_ind.

      READ TABLE lt_9504 INTO DATA(ls_9504) WITH KEY shdocno = temp_out-shdocno zeile = temp_out-zeile.
      IF sy-subrc = 0.
        ls_9504-log_uuid = temp_out-log_uuid.
        ls_9504-entstatus = ls_rtncod-entstatus.
        ls_9504-bank_rtnmsg = ls_rtncod-bank_rtnmsg.
        ls_9504-bank_rtncode = ls_rtncod-bank_rtncode.
        ls_9504-rtn_type = ls_rtncod-rtntype.
        ls_9504-aedat = sy-datum.
        ls_9504-aezet = sy-uzeit.
        ls_9504-aenam = sy-uname.

        APPEND ls_9504 TO lt_9504_db.

        APPEND INITIAL LINE TO lt_9503 ASSIGNING FIELD-SYMBOL(<fs_9503>).
        <fs_9503>-uuid = cl_system_uuid=>if_system_uuid_static~create_uuid_c22( ).
        <fs_9503>-loguuid = temp_out-log_uuid.
        <fs_9503>-shdocno = temp_out-shdocno.
        <fs_9503>-zeile = temp_out-zeile.
        <fs_9503>-bank_func = 'DLCIDSTT'.
        <fs_9503>-entstatus   = ls_rtncod-entstatus.
        <fs_9503>-bank_rtncode = ls_rtncod-bank_rtncode.
        <fs_9503>-bank_rtnmsg  = ls_rtncod-bank_rtnmsg.
        <fs_9503>-erdat = sy-datum.
        <fs_9503>-erzet = sy-uzeit.
        <fs_9503>-ernam = sy-uname.
      ENDIF.
    ENDLOOP.

    IF lt_9504_db IS NOT INITIAL.
      MODIFY ztrt9504 FROM TABLE lt_9504_db.
      MODIFY ztrt9503 FROM TABLE lt_9503.
      COMMIT WORK AND WAIT.
    ENDIF.
  ENDMETHOD.
ENDCLASS.
