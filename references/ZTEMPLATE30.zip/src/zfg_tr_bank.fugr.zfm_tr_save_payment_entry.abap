FUNCTION ZFM_TR_SAVE_PAYMENT_ENTRY.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     VALUE(IM_S_PAYMENT_ENTRY) TYPE  ZTRT_PAYMENT
*"     VALUE(IM_S_PAYMENT_LINKAGE) TYPE  ZTRT_PAYMLINK OPTIONAL
*"     VALUE(IM_COMMIT) TYPE  FLAG DEFAULT 'X'
*"  EXPORTING
*"     REFERENCE(EX_ENTRY_NOT_UPDATE) TYPE  FLAG
*"     REFERENCE(EX_LINKAGE_NOT_UPDATE) TYPE  FLAG
*"--------------------------------------------------------------------
DATA: l_dbcnt TYPE sydbcnt.
  DATA ls_seq TYPE ztrt_dseq.

  DATA ls_old_dbmin TYPE ztrs_dbadmin.
  DATA(ls_new_entry) = im_s_payment_entry.
  DATA(ls_new_linkage) = im_s_payment_linkage.
  DATA(ls_system_info) = zcl_global_technical_service=>get_system_info( ).

  SELECT SINGLE * INTO CORRESPONDING FIELDS OF ls_old_dbmin
          FROM ztrt_payment
          WHERE entuuid = im_s_payment_entry-entuuid.
  l_dbcnt = sy-dbcnt.

  PERFORM set_dbadmin
             USING ls_system_info
                   ls_old_dbmin
                   l_dbcnt
           CHANGING ls_new_entry-dbadmin.
  IF l_dbcnt IS INITIAL.
*    new inserting entry
    MOVE-CORRESPONDING ls_new_entry TO ls_seq.
  ENDIF.

  CLEAR ls_old_dbmin.

  IF im_s_payment_linkage IS NOT INITIAL.
*    SELECT SINGLE * INTO CORRESPONDING FIELDS OF ls_old_dbmin
*            FROM ztrt_paymlink
**          WHERE paymorder = im_s_payment_linkage-paymorder.
*            WHERE doc1r = im_s_payment_linkage-doc1r.
    SELECT SINGLE * INTO CORRESPONDING FIELDS OF ls_old_dbmin
            FROM ztrt_paymlink
          WHERE paymorder = im_s_payment_linkage-paymorder
          and   DRAFT_ZXH = im_s_payment_linkage-draft_zxh.
    l_dbcnt = sy-dbcnt.

    PERFORM set_dbadmin
               USING ls_system_info
                     ls_old_dbmin
                     l_dbcnt
             CHANGING ls_new_linkage-dbadmin.
    CLEAR ls_old_dbmin.
  ENDIF.

  CALL FUNCTION 'ZFM_TR_SAVE_PAYMENT_ENTRY_UPD' "IN UPDATE TASK
    EXPORTING
      im_s_payment_entry   = ls_new_entry
      im_s_payment_linkage = ls_new_linkage
      im_s_sequence_entry  = ls_seq.

  IF im_commit = 'X'.
    COMMIT WORK AND WAIT.

    CLEAR: ls_new_entry,
           ls_new_linkage.

    DO 300 TIMES.
      SELECT SINGLE * INTO ls_new_entry
            FROM ztrt_payment
            WHERE entuuid = im_s_payment_entry-entuuid.
      IF sy-subrc = 0 AND
          ls_new_entry-update_timestamp = ls_system_info-timestamp AND
          ls_new_entry-update_timezone = ls_system_info-timezone.
*      update finished
        ex_entry_not_update = space.
        EXIT.
      ELSE.
        ex_entry_not_update = 'X'.
        WAIT UP TO '0.01' SECONDS.
      ENDIF.
    ENDDO.

    IF im_s_payment_linkage IS NOT INITIAL.
      DO 300 TIMES.
*        SELECT SINGLE * INTO ls_new_linkage
*              FROM ztrt_paymlink
**              WHERE paymorder = im_s_payment_linkage-paymorder.
*              WHERE doc1r = im_s_payment_linkage-doc1r.
        SELECT SINGLE * INTO ls_new_linkage
              FROM ztrt_paymlink
              WHERE paymorder = im_s_payment_linkage-paymorder
              and   DRAFT_ZXH = im_s_payment_linkage-DRAFT_ZXH.
        IF sy-subrc = 0 AND
            ls_new_linkage-update_timestamp = ls_system_info-timestamp AND
            ls_new_linkage-update_timezone = ls_system_info-timezone.
*      update finished
          ex_linkage_not_update = space.
          EXIT.
        ELSE.
          ex_linkage_not_update = 'X'.
          WAIT UP TO '0.01' SECONDS.
        ENDIF.
      ENDDO.
    ELSE.
      ex_linkage_not_update = 'X'.
    ENDIF.
  ELSE.
    ex_entry_not_update = 'X'.
    ex_linkage_not_update = 'X'.
  ENDIF.





ENDFUNCTION.
