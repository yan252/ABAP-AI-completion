FUNCTION ZFM_TR_UPDATE_HPSTATUS.
**"--------------------------------------------------------------------
**"*"局部接口：
**"  IMPORTING
**"     REFERENCE(DOCNO) TYPE  ZTR_ZFDOCNO
**"--------------------------------------------------------------------
*DATA: lv_zzfstatus TYPE ztr_zfstatus,
*        lv_bukrs     TYPE bukrs,
*        lv_hpstatus  TYPE ztr_ztran_status,
*        lv_zbskl     TYPE ztr_bsklflg.
*
**支付单状态
*  SELECT SINGLE bukrs zzfstatus zbskl INTO (lv_bukrs,lv_zzfstatus,lv_zbskl) FROM ztrt2001
*    WHERE docno = docno AND zbskl = 'A'.
*  CHECK sy-subrc = 0.
*  SELECT * INTO TABLE @DATA(lt_2009) FROM ztrt2009
*    WHERE docno = @docno.
*  CHECK sy-subrc = 0.
*  LOOP AT lt_2009 INTO DATA(ls_2009).
**背书
*    CASE lv_zzfstatus.
*      WHEN '10'."生成
*        lv_hpstatus = '140'.
*      WHEN '11'."提交审批
*        lv_hpstatus = '141'.
*      WHEN  '13'."审批通过
*        lv_hpstatus = '142'.
*      WHEN '23' OR '29' OR '21 ' OR '57'."撤销确认/审批拒绝/删除/已作废/支付失败
*        lv_hpstatus = '144'.
*      WHEN '16'."已过账
*        lv_hpstatus = '145'.
*      WHEN '25'."付款确认
*        lv_hpstatus = '143'.
*      WHEN '56'. "撤销申请.
*        lv_hpstatus = '145'.
*      WHEN '28'."冲销
*        lv_hpstatus = '143'.
*    ENDCASE.
*    IF lv_hpstatus IS NOT INITIAL.
*      UPDATE ztrt0070 SET ztran_status = lv_hpstatus  aedat = sy-datum
*                          aezet = sy-uzeit aenam = sy-uname
*      WHERE docno_key = ls_2009-docno_key AND zjsno = ls_2009-zjsno
*        AND bukrs = lv_bukrs.
*      COMMIT WORK.
*    ENDIF.
*  ENDLOOP.
*




ENDFUNCTION.
