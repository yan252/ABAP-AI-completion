@AbapCatalog.sqlViewName: 'ZTRCDS3020A'
@AbapCatalog.compiler.compareFilter: true
@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'BISK閮ㄥ垎娓呰处鍘熷鍑瘉'
define view ZDDL_RT3020_01 
as select from bsik 
{
  mandt,
  bukrs,
  gjahr,
  belnr,
  buzei,
  wrbtr,
  wrbtr as WRBTR_BSIK,
  waers  ,
  rebzj  ,
  rebzg ,
  rebzz  
} 
 where zlspr = ''  
   and ( ( blart <> 'Z8' and blart <> 'Z7' )  or  ( ( blart = 'Z8' or blart = 'Z7' ) and ( xref3 = '' or umskz <> '' or xref3 like '%/%' ) ) )
   and shkzg = 'H' 
   and ( rebzg =  '' or  rebzj = '0000'  or   rebzz = '000'   )

union all

select from bsik 
{
  mandt,
  bukrs,
  rebzj as gjahr,
  rebzg as belnr,
  rebzz as buzei,
  case  
   when shkzg = 'H' then wrbtr 
   when shkzg = 'S' then wrbtr * ( -1 )
  else 0 end 
  as wrbtr ,
  0 as WRBTR_BSIK , 
  waers ,   
  gjahr as  rebzj ,
  belnr as  rebzg ,
  buzei as  rebzz 
} 
 where zlspr = ''  
   and ( ( blart <> 'Z8' and blart <> 'Z7' )  or  ( ( blart = 'Z8' or blart = 'Z7' ) and ( xref3 = '' or umskz <> '' or xref3 like '%/%' ) ) )
   and rebzg <>  '' 
   and rebzj <> '0000' 
   and rebzz <> '000'  
   


   
 
  
 