FUNCTION ZFM_TR_CBI_ABSTRACT_GET.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     VALUE(I_TREE_TYPE) TYPE  DMEE_TREETYPE_ABA
*"     VALUE(I_TREE_ID) TYPE  DMEE_TREEID_ABA
*"     VALUE(I_ITEM)
*"     VALUE(I_PARAM)
*"     VALUE(I_UPARAM)
*"  EXPORTING
*"     REFERENCE(O_VALUE)
*"     REFERENCE(C_VALUE)
*"     REFERENCE(N_VALUE)
*"     REFERENCE(P_VALUE)
*"  TABLES
*"      I_TAB
*"--------------------------------------------------------------------
ASSIGN COMPONENT 'FPAYH' OF STRUCTURE i_item TO FIELD-SYMBOL(<fs_fpayh>).
  ASSIGN COMPONENT 'DOC1R' OF STRUCTURE <fs_fpayh> TO FIELD-SYMBOL(<fs_doc1r>).
  SELECT SINGLE * INTO @DATA(ls_2010) FROM ztrt2010 WHERE docno = @<fs_doc1r>.
  IF sy-subrc = 0.
    IF ls_2010-jyfs = '4'.
      CALL FUNCTION 'ZFM_TR_SET_PAYMENT_ABSTRACT'
        EXPORTING
          i_tree_type = i_tree_type
          i_tree_id   = i_tree_id
          i_item      = i_item
          i_param     = i_param
          i_uparam    = i_uparam
        IMPORTING
          o_value     = o_value
          c_value     = c_value
          n_value     = n_value
          p_value     = p_value
        TABLES
          i_tab       = i_tab.
    ENDIF.
  ENDIF.





ENDFUNCTION.
