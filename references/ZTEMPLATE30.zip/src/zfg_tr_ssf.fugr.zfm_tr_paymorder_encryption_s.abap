FUNCTION ZFM_TR_PAYMORDER_ENCRYPTION_S.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     REFERENCE(IM_S_2101) TYPE  ZTRT2101 OPTIONAL
*"     REFERENCE(IM_S_2001) TYPE  ZTRT2001 OPTIONAL
*"     REFERENCE(IM_S_2002) TYPE  ZTRT2002
*"     REFERENCE(IM_S_2003) TYPE  ZTRT2003
*"     REFERENCE(IM_COMMIT_WORK) TYPE  FLAG OPTIONAL
*"     REFERENCE(IM_ZZFTYPE) TYPE  ZTRT2001-ZZFTYPE OPTIONAL
*"  EXPORTING
*"     REFERENCE(EX_SSFUUID) TYPE  ZTRT2001-SSFUUID
*"  EXCEPTIONS
*"      ERROR
*"--------------------------------------------------------------------
DATA: l_ssfuuid TYPE ztrt2001-ssfuuid.
  IF im_zzftype = 'P004'.
    zcl_captical_encryptor=>do_paymorder_ssfencryption_004(
                                 EXPORTING
                                  im_s_2101 = im_s_2101
                                  im_s_2002 = im_s_2002
                                  im_s_2003 = im_s_2003
                                  im_commit_work = im_commit_work
                                 IMPORTING
                                   ex_ssfuuid = l_ssfuuid
                                  EXCEPTIONS
                                    error = 1 ).
  ELSE.
*&BEGIN-------------------------------------------------------------
*&内贸划转单-创建支付单时跳过加密
*&CHANGE DATE: 11.20.2020
*&AUTHOR    : HANDXXJ
*&------------------------------------------------------------------
    DATA : lv_skip TYPE char01.
    GET PARAMETER ID 'ZTR2_NMHZ' FIELD lv_skip.
    IF lv_skip = abap_true.
      zcl_captical_encryptor=>set_skip( ).
    ENDIF.
    SET PARAMETER ID 'ZTR2_NMHZ' FIELD space.
*&END---------------------------------------------------------------
    zcl_captical_encryptor=>do_paymorder_ssfencryption(
                                 EXPORTING
                                  im_s_2001 = im_s_2001
                                  im_s_2002 = im_s_2002
                                  im_s_2003 = im_s_2003
                                  im_commit_work = im_commit_work
                                 IMPORTING
                                   ex_ssfuuid = l_ssfuuid
                                  EXCEPTIONS
                                    error = 1 ).
  ENDIF.

  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid
            TYPE sy-msgty
            NUMBER sy-msgno
            WITH sy-msgv1
                 sy-msgv2
                 sy-msgv3
                 sy-msgv4
            RAISING error.
  ELSE.
    ex_ssfuuid = l_ssfuuid.
  ENDIF.





ENDFUNCTION.
