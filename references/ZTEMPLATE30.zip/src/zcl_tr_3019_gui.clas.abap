class ZCL_TR_3019_GUI definition
  public
  final
  create public .

public section.

  class-data MV_WSTS_10 type NUMC2 value '10' ##NO_TEXT.
  class-data MV_WSTS_11 type NUMC2 value '11' ##NO_TEXT.
  class-data MV_WSTS_19 type NUMC2 value '19' ##NO_TEXT.
  class-data MV_WSTS_22 type NUMC2 value '22' ##NO_TEXT.
  class-data MV_WSTS_29 type NUMC2 value '29' ##NO_TEXT.
  class-data MV_MSTS_10 type NUMC2 value '10' ##NO_TEXT.
  class-data MV_MSTS_11 type NUMC2 value '11' ##NO_TEXT.
  class-data MV_MSTS_19 type NUMC2 value '19' ##NO_TEXT.
  class-data MV_MSTS_22 type NUMC2 value '22' ##NO_TEXT.
  class-data MV_MSTS_29 type NUMC2 value '29' ##NO_TEXT.
  class-data MV_WSTS_50 type NUMC2 value '50' ##NO_TEXT.
  class-data MV_MSTS_50 type NUMC2 value '50' ##NO_TEXT.
  class-data MV_MSTS_51 type NUMC2 value '51' ##NO_TEXT.
  class-data MV_MSTS_52 type NUMC2 value '52' ##NO_TEXT.
  class-data MV_MSTS_53 type NUMC2 value '53' ##NO_TEXT.
  class-data MV_MSTS_54 type NUMC2 value '54' ##NO_TEXT.
  class-data MV_MSTS_55 type NUMC2 value '55' ##NO_TEXT.
  class-data MV_WSTS_23 type NUMC2 value '23' ##NO_TEXT.
  class-data MV_FI_CHECK_EXIT_DISABLE type CHAR01 .
  class-data MV_BP_NO_CHECK type CHAR01 .
  class-data:
    BEGIN OF  gs_dm   ,
        domvalue_l TYPE dd07t-domvalue_l,
        ddtext     TYPE dd07t-ddtext,
      END OF gs_dm .
  class-data:
    gt_dm_bcate LIKE  TABLE OF gs_dm .
  class-data:
    gt_dm_znwx LIKE  TABLE OF gs_dm .
  class-data:
    gt_zlsch LIKE  TABLE OF gs_dm .
  class-data:
    gt_flowd LIKE  TABLE OF gs_dm .
  class-data:
    gt_stitel LIKE  TABLE OF gs_dm .
  class-data:
    gt_gsart LIKE  TABLE OF gs_dm .
  class-data:
    gt_sbewart LIKE  TABLE OF gs_dm .
  class-data:
    gt_buktyp LIKE  TABLE OF gs_dm .
  class-data:
    gt_glsx LIKE  TABLE OF gs_dm .
  class-data:
    gt_appro LIKE  TABLE OF gs_dm .
  class-data:
    gt_sqdtyrage TYPE RANGE OF ztrt2500_1-bcate .
  class-data:
    gt_hkrstgr TYPE RANGE OF bseg-rstgr .

  class-methods CHECK_TR_LOCK2
    importing
      !IV_ZBELNR1 type ZYFKSQNO
    exporting
      !ES_01 type ZTRT3018_01
      !ES_02 type ZTRT3017_01
      !E_TR_LOCK type CHAR01 .
  class-methods CHECK_TR_LOCK1
    importing
      !IV_BILLN type ZTR_BILLN_YGD
    exporting
      !ES_01 type ZTRT3018_01
      !ES_02 type ZTRT3017_01 .
  class-methods CHECK_TR_LOCK
    importing
      !IS_DATA type GB002_015
      !IS_TAB type ANY TABLE optional
    exporting
      !E_TR_LOCK type CHAR1 .
  class-methods GET_FUND_PLAN_STATE
    importing
      !IV_ZBELNR1 type BELNR_D
    exporting
      !E_BALANCE type ZBALANCE
      !ES_STATE type ZRTRS_FUND_PLAN_STATE
      !ES_MESSAGE type MSG .
  class-methods GET_3015_AMT
    importing
      !IV_BILLN type ZTR_BILLN_YGD
      !IV_ITEMN type ZTR_ITEMNO
    exporting
      !EV_JHZYE type ZTR_JHZYE
      !EV_DZFE type ZTR_DZFE
      !EV_SJSZE type ZTR_SJSZE .
  class-methods GET_SJLYT
    importing
      !I_ZSJLY type ZBK_SJLY
    exporting
      !E_TXT type ANY
    returning
      value(R_TXT) type ZBK_SJLYT .
  class-methods GET_ZGROUP_T
    importing
      !IV_GRP type ZBK_GRP
    exporting
      !EV_TEXT type VAL_TEXT
    returning
      value(RV_TEXT) type VAL_TEXT .
  class-methods GET_BUKRS_TYPE_TEXT
    importing
      !I_BURKS_TYPE type ZTR_BURKS_TYPE
    exporting
      !E_TYPE_D type ANY .
  class-methods GET_BUKRS_TYPE
    importing
      !I_BUKRS type BUKRS optional
      !I_RASSC type RASSC optional
    exporting
      !E_BURKS_TYPE type ZTR_BURKS_TYPE
      !E_TYPE_D type ANY .
  class-methods GET_STATUS_T
    importing
      !I_STS type ZAPPRO
    exporting
      !E_TXT type ANY
    returning
      value(R_TXT) type VAL_TEXT .
  class-methods GET_BUKRS_NAME
    importing
      !I_BUKRS type BUKRS
    exporting
      !E_TXT type BUTXT .
  class-methods GET_BP_NAME
    importing
      !I_BP type ZTR_BP
      !I_K type BOOLEAN optional
    exporting
      !E_BPNAME type NAME1_GP
      !E_BPT type ZTR_BPT
    returning
      value(R_BPNAME) type NAME1_GP .
  class-methods GET_FKFS_NAME
    importing
      !I_ZLSCH type ANY
    exporting
      !E_TEXT1 type TEXT1_042Z
    returning
      value(R_TEXT1) type TEXT1_042Z .
  class-methods GET_GL_T
    importing
      !I_ZGLSX type ZTR_GLSX
    exporting
      !E_TXT type ANY .
  class-methods GET_BCATE_T
    importing
      !I_BCATE type ZTR_BILL_CATE
    exporting
      !E_TXT type ANY
    returning
      value(R_TXT) type VAL_TEXT .
  class-methods GET_NWX_T
    importing
      !I_NWX type ZTR_ZNWX
    exporting
      !E_TXT type ANY .
  class-methods GET_BP_INFO
    importing
      !I_BP type LIFNR
    exporting
      !E_GBORT type GBORT
      !E_RASSC type RASSC
      !E_NWX type ZTR_ZNWX .
  class-methods GET_DETAIL
    importing
      !IT_ITEMN type ZTR_T_BGUI
    exporting
      !ET_ITEM type ZTRT_3018_02 .
  class-methods CVT_BUKRS
    importing
      !I_RASSC type RASSC
    exporting
      !E_BUKRS type BUKRS .
  class-methods LOCK_BUKRS
    importing
      !IV_BUKRS type BUKRS
    exceptions
      ERR .
  class-methods LOCK_WEEK_MONTH
    importing
      !IS_9010 type ZTRV9010
    exceptions
      ERR .
  class-methods LOCK_MHEAD
    importing
      !IV_BGUID type GUID_32
    exceptions
      ERR .
  class-methods LOCK_WHEAD
    importing
      !IV_BGUID type GUID_32
      !IV_AGN type CHAR01 optional
    exceptions
      ERR .
  class-methods LOCK_MITEM
    importing
      !IV_BGUID type GUID_32
      !IV_ITEMN type ZTR_ITEMN optional
    exceptions
      ERR .
  class-methods LOCK_WITEM
    importing
      !IV_BGUID type GUID_32
      !IV_ITEMN type ZTR_ITEMN
      !IV_AGN type CHAR01 optional
    exceptions
      ERR .
  class-methods UNLOCK_BUKRS
    importing
      !IV_BUKRS type BUKRS
    exceptions
      ERR .
  class-methods UNLOCK_MHEAD
    importing
      !IV_BGUID type GUID_32
    exceptions
      ERR .
  class-methods UNLOCK_WHEAD
    importing
      !IV_BGUID type GUID_32
      !IV_AGN type CHAR01 optional
    exceptions
      ERR .
  class-methods UNLOCK_MITEM
    importing
      !IV_BGUID type GUID_32
      !IV_ITEMN type ZTR_ITEMN
    exceptions
      ERR .
  class-methods UNLOCK_WITEM
    importing
      !IV_BGUID type GUID_32
      !IV_ITEMN type ZTR_ITEMN
      !IV_AGN type CHAR01 optional
    exceptions
      ERR .
  class-methods UNLOCK_WEEK_MONTH
    importing
      !IS_9010 type ZTRV9010
    exceptions
      ERR .
  class-methods GET_PSPHI
    importing
      !IV_PSPNR type PS_POSNR
    exporting
      !EV_PSPID type PS_POSID
      !EV_POST1 type PS_POST1
      !EV_PROJT type ZTR_PROJT .
  class-methods GET_FLOW_T
    importing
      !IV_FLOW type ZTR_FUND_FLOW
    exporting
      !EV_FLOWT type ZTR_FUND_FLOWD .
  class-methods CVT_AMT
    importing
      !IV_AMT type ANY
      !IV_FROM_CUR type WAERS
      !IV_TO_CUR type WAERS
      value(IV_DATE) type DATUM optional
      !IV_BUKRS type BUKRS optional
    exporting
      value(EV_AMT) type ANY
    exceptions
      ERR .
  class-methods LOCK_JJ
    importing
      !IV_BILLN type ZTR_JBILLN
      !IV_PASS_AGN type BOOLEAN optional
    exceptions
      ERR .
  class-methods UNLOCK_JJ
    importing
      !IV_BILLN type ZTR_JBILLN
      !IV_PASS_AGN type BOOLEAN optional
    exceptions
      ERR .
  class-methods GET_ZZFFS
    importing
      !IT_TYPE type ZTRT_ZLSCH
    exporting
      !EV_ZZFFS type ZTR_ZFD_ZFS
    exceptions
      ERR .
  class-methods GET_PAYTERM
    importing
      !IV_ZTERM type DZTERM
    exporting
      !EV_TEXT1 type TEXT1_052 .
  class-methods GET_PRCTR_NAME
    importing
      !IV_PRCTR type PRCTR
      !IV_BUKRS type BUKRS
    exporting
      !EV_KTEXT type KTEXT
      !EV_KOKRS type KOKRS .
  class-methods GET_VDARL
    importing
      !IV_BUKRS type BUKRS
      !IV_RANL type RANL
    exporting
      !EV_GSART type VVSART
      !EV_STITEL type STITEL .
  class-methods GET_STITELT
    importing
      !IV_STITEL type STITEL
    exporting
      !EV_STITELT type ZTR_STITELT .
  class-methods GET_GSARTT
    importing
      !IV_GSART type VVSART
    exporting
      !EV_GSARTT type ZTR_GSARTT .
  class-methods GET_SBEWART
    importing
      !IV_SBEWART type SBEWART
    exporting
      !EV_SBEWARTT type ZTR_SLDWART_T .
  class-methods GET_KOSTLT
    importing
      !IV_KOSTL type KOSTL
      !IV_BUKRS type BUKRS
    exporting
      !KTEXT type ZTR_KOSTLT .
  class-methods GET_BP_ALL
    importing
      !IV_BUKRS type BUKRS
      !IT_BP type ZTRT_3019_BPALL
    exporting
      !ET_BP type ZTRT_3019_BPALL
      !ET_BUKRST type ZTRT_3019_BUKRSALL .
  class-methods GET_VDARL_ALL
    importing
      !IV_BUKRS type BUKRS
      !IT_RANL type ZTRT_3019_RANL
    exporting
      !ET_RANL type ZTRT_3019_RANL .
  class-methods GET_BB_TEXT
    importing
      !IV_ZJJHBB type ZTR_ZJJHBB
    returning
      value(RV_TEXT) type TEXT40 .
  class-methods GET_PRCTRT
    importing
      !IV_PRCTR type PRCTR
      !IV_BUKRS type BUKRS
    exporting
      !EV_PRCTRT type ZTR_PRCTRT .
  class-methods GET_JYLXT
    importing
      !IV_JYLX type ZTR_JYLX
    exporting
      !EV_JYLXT type ZTR_JYLXT .
  class-methods GET_SHKZGT
    importing
      !IV_SHKZG type SHKZG
    exporting
      !EV_SHZKGT type ZTR_SHKZGT .
  class-methods GET_BP_TYPET
    importing
      !IV_BP_TYPE type ZBP_TYPE
    exporting
      !EV_BP_TYPET type ZBP_TYPET .
  class-methods GET_W_STS
    importing
      !I_BGUID type GUID_32
    exporting
      !E_STS type ZTR_WPLAN_STATUS .
  class-methods GET_FI_LIFNR
    exporting
      !EV_LIFNR type LIFNR .
  class-methods GET_ZHLXT
    importing
      !IV_ZHLX type ZTR_ZHLX
    exporting
      !EV_ZHLXT type ZTR_ZHLXT .
  class-methods GET_GUA_TYPET
    importing
      !IV_TYPE type ZTR_GUA_TYPE
    exporting
      !EV_TYPET type ZTR_GUA_TYPET .
  class-methods GET_ZFSQD_RANGE
    returning
      value(ET_RANGE) like GT_SQDTYRAGE .
  class-methods GET_HK_EXP
    importing
      !I_BUKRS type BUKRS
    returning
      value(ET_RSTGR) like GT_HKRSTGR .
  class-methods CHECK_HK_BUKRS
    importing
      !I_BUKRS type BUKRS
    returning
      value(E_FLAG) type FLAG .
protected section.
private section.
ENDCLASS.



CLASS ZCL_TR_3019_GUI IMPLEMENTATION.


METHOD check_hk_bukrs.
    SELECT COUNT(*) FROM ztrt2501 WHERE bukrs = i_bukrs.
    IF sy-subrc = 0.
      e_flag = abap_true.
    ELSE.
      CLEAR e_flag.
    ENDIF.


  ENDMETHOD.


METHOD check_tr_lock.

*  资金组创建资金计划后，锁定财务凭证
*  如对您有影响，联系资金组




    e_tr_lock = 'T'.

*  封标准冲销
    IF is_data-bkpf-stblg IS NOT INITIAL .
      SELECT COUNT(*)  FROM ztrv_amt_agn
       WHERE bukrs  = is_data-bkpf-bukrs
         AND gjahr  = is_data-bkpf-gjahr
         AND belnr  = is_data-bkpf-stblg
         AND wrbtr_agn <> 0
         AND dflag  = space .
      IF sy-subrc = 0 .
        e_tr_lock  = 'F'.  EXIT .
      ENDIF.

    ELSE.
      SELECT COUNT(*)  FROM ztrv_amt_agn
      WHERE bukrs  = is_data-bkpf-bukrs
        AND gjahr  = is_data-bkpf-gjahr
        AND belnr  = is_data-bkpf-belnr
        AND wrbtr_agn <> 0
        AND dflag  = space .
      IF sy-subrc = 0 .
        e_tr_lock  = 'F'.  EXIT .
      ENDIF.
    ENDIF.

    CHECK e_tr_lock = 'T'.

*  完全清账，部分清账最后一笔
    IF is_tab IS NOT INITIAL .
      ASSIGN is_tab TO FIELD-SYMBOL(<fs_tab>).
      LOOP AT <fs_tab> ASSIGNING FIELD-SYMBOL(<fs_line>).
        ASSIGN COMPONENT 'GJAHR'  OF STRUCTURE <fs_line> TO FIELD-SYMBOL(<fs_gjahr>).
        ASSIGN COMPONENT 'BELNR'  OF STRUCTURE <fs_line> TO FIELD-SYMBOL(<fs_belnr>).
        ASSIGN COMPONENT 'BUZEI'  OF STRUCTURE <fs_line> TO FIELD-SYMBOL(<fs_buzei>).
        SELECT COUNT(*)  FROM ztrv_amt_agn
         WHERE bukrs  = is_data-bkpf-bukrs
           AND gjahr  = <fs_gjahr>
           AND belnr  = <fs_belnr>
           AND buzei  = <fs_buzei>
         AND wrbtr_agn <> 0
           AND dflag  = space .
        IF sy-subrc = 0 .
          e_tr_lock  = 'F'.   EXIT .
        ENDIF.
      ENDLOOP.
    ENDIF.


    CHECK e_tr_lock = 'T'.


*   MR8M  , 部分清账不是最后一笔，剩余清账
    LOOP AT is_data-bseg INTO DATA(ls_bseg) .
      IF ls_bseg-rebzg IS NOT INITIAL .
        SELECT COUNT(*)  FROM ztrv_amt_agn
         WHERE bukrs  = ls_bseg-bukrs
           AND gjahr  = ls_bseg-rebzj
           AND belnr  = ls_bseg-rebzg
           AND buzei  = ls_bseg-rebzz
         AND wrbtr_agn <> 0
           AND dflag  = space .
        IF sy-subrc = 0 .
          e_tr_lock  = 'F'.   EXIT .
        ENDIF.
      ENDIF.
    ENDLOOP.

  ENDMETHOD.


METHOD check_tr_lock1.

*  资金组创建资金计划后，锁定财务凭证
*  如对您有影响，联系资金组
    SELECT SINGLE z1~zwkplv z1~zjjhbb FROM ztrt3018_01 AS z1
      INNER JOIN ztrt3018_02 AS z2
      ON z1~bguid = z2~bguid
      INTO CORRESPONDING FIELDS OF es_01
    WHERE z1~dflag = space
*      AND z1~status_w <> '10'
      AND z2~dflag = space
*      AND z2~zinactive = space
      AND ( z1~zjjhbb = '01' OR  ( z1~zjjhbb >= 20 AND z1~zjjhbb <= 99 )  )
      AND z2~billn = iv_billn .


    SELECT SINGLE z1~zmplv z1~zjjhbb FROM ztrt3017_01 AS z1
      INNER JOIN ztrt3017_02 AS z2
      ON z1~bguid = z2~bguid
      INTO CORRESPONDING FIELDS OF es_02
    WHERE z1~dflag = space
*      AND z1~status_w <> '10'
      AND z2~dflag = space
*      AND z2~zinactive = space
      AND ( z1~zjjhbb = '01' OR  ( z1~zjjhbb >= 20 AND z1~zjjhbb <=  99 )  )
      AND z2~billn = iv_billn .

  ENDMETHOD.


METHOD check_tr_lock2.

*  IV_ZBELNR1 是预付款单号
*  es_01 es_02可以不用管
*  e_tr_lock 打X 就是被锁定了


    CLEAR  e_tr_lock .

*  资金组创建资金计划后，锁定财务凭证
*  如对您有影响，联系资金组
    SELECT SINGLE z1~zwkplv z1~zjjhbb FROM ztrt3018_01 AS z1
      INNER JOIN ztrt3018_02 AS z2 ON z1~bguid = z2~bguid
      INNER JOIN ztrv_amt_agn AS z3 ON z3~bguid = z2~bguid AND z3~witemn = z2~itemn
      INTO CORRESPONDING FIELDS OF es_01
    WHERE z1~dflag = space
*      AND z1~status_w <> '10'
      AND z2~dflag = space
*      AND z2~zinactive = space
      AND z3~wrbtr_agn <> 0
      AND z3~dflag = space
      AND ( z1~zjjhbb = '01' OR  ( z1~zjjhbb >= 20 AND z1~zjjhbb <= 99 )  )
      AND z2~zbelnr1 = iv_zbelnr1 .
    IF sy-subrc = 0 .
      e_tr_lock = abap_true.
    ENDIF.


*    SELECT SINGLE z1~zmplv z1~zjjhbb FROM ztrt3017_01 AS z1
*      INNER JOIN ztrt3017_02 AS z2
*      ON z1~bguid = z2~bguid
*      INTO CORRESPONDING FIELDS OF es_02
*    WHERE z1~dflag = space
**      AND z1~status_w <> '10'
*      AND z2~dflag = space
**      AND z2~zinactive = space
*      AND ( z1~zjjhbb = '01' OR  ( z1~zjjhbb >= 20 AND z1~zjjhbb <=  99 )  )
*      AND z2~zbelnr1 =  iv_zbelnr1 .
*
*    IF sy-subrc = 0 .
*      e_tr_lock = 'F'.
*    ENDIF.



  ENDMETHOD.


METHOD cvt_amt.

*  同币种不需要转换
    IF iv_from_cur = iv_to_cur.
      ev_amt = iv_amt .
      RETURN.
    ENDIF.
*    金额为0 也无需转换
    IF iv_amt = 0.
      RETURN.
    ENDIF.

    IF iv_date IS INITIAL.
      iv_date = sy-datum.
    ENDIF.
*---------------预估计划 本位币 支付货币币种均不同是的处理--------------add by hjj 25.11.2020 15:02:45------------------------------------------
    IF iv_bukrs IS NOT INITIAL.
      SELECT SINGLE waers FROM t001 INTO @DATA(lv_loc_waers) WHERE bukrs = @iv_bukrs.
      IF lv_loc_waers NE iv_to_cur.
        CALL FUNCTION 'CONVERT_TO_LOCAL_CURRENCY'
          EXPORTING
            date             = iv_date
            foreign_amount   = iv_amt
            foreign_currency = iv_from_cur
            local_currency   = lv_loc_waers
          IMPORTING
            local_amount     = ev_amt
          EXCEPTIONS
            no_rate_found    = 1
            overflow         = 2
            no_factors_found = 3
            no_spread_found  = 4
            derived_2_times  = 5
            OTHERS           = 6.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
          WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
        ELSE.
          CALL FUNCTION 'CONVERT_TO_LOCAL_CURRENCY'
            EXPORTING
              date             = iv_date
              foreign_amount   = ev_amt
              foreign_currency = lv_loc_waers
              local_currency   = iv_to_cur
            IMPORTING
              local_amount     = ev_amt
            EXCEPTIONS
              no_rate_found    = 1
              overflow         = 2
              no_factors_found = 3
              no_spread_found  = 4
              derived_2_times  = 5
              OTHERS           = 6.
        ENDIF.
      ELSE.
        CALL FUNCTION 'CONVERT_TO_LOCAL_CURRENCY'
          EXPORTING
            date             = iv_date
            foreign_amount   = iv_amt
            foreign_currency = iv_from_cur
            local_currency   = iv_to_cur
          IMPORTING
            local_amount     = ev_amt
          EXCEPTIONS
            no_rate_found    = 1
            overflow         = 2
            no_factors_found = 3
            no_spread_found  = 4
            derived_2_times  = 5
            OTHERS           = 6.
      ENDIF.
    ELSE.

      CALL FUNCTION 'CONVERT_TO_LOCAL_CURRENCY'
        EXPORTING
          date             = iv_date
          foreign_amount   = iv_amt
          foreign_currency = iv_from_cur
          local_currency   = iv_to_cur
        IMPORTING
          local_amount     = ev_amt
        EXCEPTIONS
          no_rate_found    = 1
          overflow         = 2
          no_factors_found = 3
          no_spread_found  = 4
          derived_2_times  = 5
          OTHERS           = 6.

    ENDIF.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
        WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
    ENDIF.

  ENDMETHOD.


METHOD cvt_bukrs.

    DATA lv_rassc LIKE i_rassc .
    CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
      EXPORTING
        input  = i_rassc
      IMPORTING
        output = lv_rassc.

    SHIFT lv_rassc LEFT DELETING LEADING space .

    e_bukrs = lv_rassc(4) .

  ENDMETHOD.


METHOD get_3015_amt.

*   货币不考虑的  从前到后都是一个货币

    SELECT SINGLE waers FROM ztrt3019_01 INTO @DATA(lv_waers) WHERE billn_yg = @iv_billn  AND bilitmn = @iv_itemn .

    SELECT i~bguid , i~itemn , a~wrbtr_agn AS jhzfe  , a~waers  FROM ztrt3018_02 AS i
     INNER JOIN ztrt3019_01 AS h  ON h~billn = i~pbilln
     INNER JOIN ztrv_amt_agn AS a ON a~bguid = i~bguid AND a~witemn = i~itemn
      INTO TABLE @DATA(lt_item)
     WHERE i~billn      = @iv_billn
       AND i~bilitmn    = @iv_itemn
       AND i~dflag      = @abap_false
       AND h~dflag      = @abap_false
       AND h~status     > '10'
       AND a~dflag      = @abap_false .

    IF sy-subrc <> 0 .
      ev_jhzye = ev_dzfe = ev_sjsze = 0 .RETURN.
    ENDIF.

    DATA : lt_bgui TYPE TABLE OF ztr_s_bgui,
           lt_rlt  TYPE TABLE OF ztr_s_zfje.

    LOOP AT lt_item INTO DATA(ls_item) .

      CALL FUNCTION 'CONVERT_TO_LOCAL_CURRENCY'
        EXPORTING
          date             = sy-datum
          foreign_amount   = ls_item-jhzfe
          foreign_currency = ls_item-waers
          local_currency   = lv_waers
        IMPORTING
          local_amount     = ls_item-jhzfe
        EXCEPTIONS
          no_rate_found    = 1
          overflow         = 2
          no_factors_found = 3
          no_spread_found  = 4
          derived_2_times  = 5
          OTHERS           = 6.
      if sy-subrc <> 0 .
        ls_item-jhzfe = 0 .  " 不可能发生
      endif.

      ev_jhzye = ls_item-jhzfe + ev_jhzye .
      lt_bgui = VALUE #( BASE lt_bgui ( bguid = ls_item-bguid  itemn = ls_item-itemn ) ).
    ENDLOOP.

    CALL FUNCTION 'ZFM_GET_ZFJE'
      TABLES
        items  = lt_bgui
        result = lt_rlt.

    LOOP AT lt_rlt INTO DATA(ls_rlt) .
      IF ls_rlt-zzfstatus = '25' OR ls_rlt-zzfstatus = '16'.
        ev_sjsze  = ev_sjsze + ls_rlt-wrbtr_zf .
      ELSE.
        ev_dzfe =  ev_dzfe  + ls_rlt-wrbtr_zf .
      ENDIF.
    ENDLOOP.
  ENDMETHOD.


METHOD get_bb_text.
    IF   iv_zjjhbb =   '01' .
      rv_text = TEXT-d01.
      RETURN .
    ENDIF.

    IF iv_zjjhbb <= '04' .
      rv_text = TEXT-d02.
      RETURN .
    ENDIF.

    IF iv_zjjhbb >=  20 .
      rv_text = TEXT-d03.
      RETURN .
    ENDIF.

  ENDMETHOD.


METHOD get_bcate_t.
    IF gt_dm_bcate IS INITIAL.
      SELECT domvalue_l ddtext INTO TABLE gt_dm_bcate FROM dd07t
      WHERE domname = 'ZTRDM_BILL_CATE'
      AND ddlanguage = sy-langu .

*    SELECT SINGLE ddtext INTO r_txt FROM dd07t
*      WHERE domname = 'ZTRDM_BILL_CATE'
*        AND ddlanguage = sy-langu
*        AND domvalue_l = i_bcate.

    ENDIF.

    READ TABLE gt_dm_bcate INTO gs_dm  WITH  KEY domvalue_l = i_bcate.
    IF sy-subrc = 0 .
      e_txt = gs_dm-ddtext.
      r_txt = gs_dm-ddtext.
    ENDIF.
  ENDMETHOD.


METHOD get_bp_all.


    DATA : BEGIN OF ls_rassc  ,
             rassc TYPE rassc,
           END OF ls_rassc  ,
           lt_rassc LIKE TABLE OF ls_rassc.

    IF it_bp IS INITIAL . RETURN .ENDIF.

*    FIELD-SYMBOLS <fs_bp> TYPE zts_3019_bpall.

    DATA(lt_bp) = it_bp .
    SORT lt_bp BY bp .
    DELETE ADJACENT DUPLICATES FROM lt_bp COMPARING bp .

    SELECT lifnr , name1 ,vbund , land1 ,gbort , ktokk FROM lfa1 INTO TABLE @DATA(lt_lfa1)
      FOR ALL ENTRIES IN @lt_bp
       WHERE lifnr = @lt_bp-bp.
    IF sy-subrc = 0 .
      LOOP AT lt_lfa1 ASSIGNING FIELD-SYMBOL(<fs_lfa1>) WHERE ktokk <> 'S003' .
        CLEAR  <fs_lfa1>-vbund .
      ENDLOOP.
      SORT lt_lfa1 BY lifnr .
    ENDIF.

    SELECT kunnr , name1 ,vbund , land1  , ktokd FROM kna1 INTO TABLE @DATA(lt_kna1)
       FOR ALL ENTRIES IN @lt_bp
     WHERE kunnr = @lt_bp-bp.
    IF sy-subrc = 0 .
      LOOP AT lt_kna1 ASSIGNING FIELD-SYMBOL(<fs_kna1>) WHERE ktokd <> 'Z003' .
        CLEAR  <fs_kna1>-vbund .
      ENDLOOP.
      SORT lt_kna1 BY kunnr .
    ENDIF.


    SELECT partner AS bp ,name_org1  FROM but000 INTO TABLE @DATA(lt_bp00)  FOR ALL ENTRIES IN @lt_bp WHERE partner = @lt_bp-bp.
    IF sy-subrc = 0 .SORT lt_bp00 BY bp . ENDIF.

    SELECT partner AS bp , vbund AS rassc FROM bp001 INTO TABLE @DATA(lt_bp01) FOR ALL ENTRIES IN @lt_bp WHERE partner = @lt_bp-bp.
    IF sy-subrc = 0 .SORT lt_bp01 BY bp . ENDIF.

    SELECT b~partner AS bp ,a~country AS land1 FROM adrc AS a INNER JOIN but020 AS b ON a~addrnumber = b~addrnumber INTO TABLE @DATA(lt_bp02)
      FOR ALL ENTRIES IN  @lt_bp
      WHERE b~partner = @lt_bp-bp.
    IF sy-subrc = 0 .SORT lt_bp02 BY bp . ENDIF.



    LOOP AT lt_bp INTO DATA(ls_bp) WHERE bp IS NOT INITIAL .
      APPEND INITIAL LINE TO  et_bp ASSIGNING FIELD-SYMBOL(<fs_bp>).
      <fs_bp>-bp = ls_bp-bp .
      READ TABLE lt_lfa1 INTO DATA(ls_lfa1) WITH KEY lifnr = <fs_bp>-bp BINARY SEARCH .
      IF sy-subrc = 0.
        <fs_bp>-bpname = ls_lfa1-name1 .
        <fs_bp>-rassc  = ls_lfa1-vbund .
        IF <fs_bp>-rassc IS NOT INITIAL .
          lt_rassc = VALUE #( BASE lt_rassc ( rassc =  <fs_bp>-rassc )  ) .
        ENDIF .
        <fs_bp>-gbort  = ls_lfa1-gbort .
        <fs_bp>-bpt    = '10' .
        IF ls_lfa1-land1 = 'CN'.
          <fs_bp>-nwx = '01'.
        ELSE.
          <fs_bp>-nwx = '02'.
        ENDIF.
      ELSE.
        READ TABLE lt_kna1 INTO DATA(ls_kna1) WITH KEY kunnr  = <fs_bp>-bp BINARY SEARCH .
        IF sy-subrc = 0 .
          <fs_bp>-bpname = ls_kna1-name1 .
          <fs_bp>-rassc  = ls_kna1-vbund .
          IF <fs_bp>-rassc IS NOT INITIAL .
            lt_rassc = VALUE #( BASE lt_rassc ( rassc =  <fs_bp>-rassc )  ) .
          ENDIF .
          <fs_bp>-bpt    = '20' .
          IF ls_kna1-land1 = 'CN'.
            <fs_bp>-nwx = '01'.
          ELSE.
            <fs_bp>-nwx = '02'.
          ENDIF.

        ELSE.
          READ TABLE lt_bp00 INTO DATA(ls_bp00) WITH KEY bp = <fs_bp>-bp BINARY SEARCH .
          IF sy-subrc = 0 .
            <fs_bp>-bpname = ls_bp00-name_org1.
          ENDIF.

          READ TABLE lt_bp01 INTO DATA(ls_bp01) WITH KEY bp = <fs_bp>-bp BINARY SEARCH .
          IF sy-subrc = 0 .
            <fs_bp>-rassc  = ls_bp01-rassc  .
            IF <fs_bp>-rassc IS NOT INITIAL .
              lt_rassc = VALUE #( BASE lt_rassc ( rassc =  <fs_bp>-rassc )  ) .
            ENDIF .
          ENDIF.

          READ TABLE lt_bp02 INTO DATA(ls_bp02) WITH KEY bp = <fs_bp>-bp BINARY SEARCH .
          IF sy-subrc = 0 .
            IF ls_bp02-land1 = 'CN'.
              <fs_bp>-nwx = '01'.
            ELSE.
              <fs_bp>-nwx = '02'.
            ENDIF.
          ENDIF.
        ENDIF.
*        read table
      ENDIF.
    ENDLOOP.

    SORT et_bp BY bp .

    IF lt_rassc IS NOT INITIAL .
      SORT lt_rassc BY rassc .
      DELETE ADJACENT DUPLICATES FROM lt_rassc COMPARING rassc .
      LOOP AT lt_rassc ASSIGNING FIELD-SYMBOL(<fs_rassc>)  .
        IF <fs_rassc>-rassc(1) <> '0' .
        ELSE.
          <fs_rassc>-rassc(4) = <fs_rassc>-rassc+2(4).
        ENDIF.
      ENDLOOP.

      SELECT bukrs AS rassc  burks_type ddtext AS burks_typet FROM ztrcds9040 AS b INNER JOIN dd07t AS d
          ON b~burks_type = d~domvalue_l
        INTO CORRESPONDING FIELDS OF TABLE et_bukrst
        FOR ALL ENTRIES IN lt_rassc
       WHERE bukrs      = lt_rassc-rassc(4)
         AND domname    = 'ZTRDM_BUKRS_TYPE'
         AND ddlanguage = sy-langu .

      IF sy-subrc = 0 .
        LOOP AT et_bukrst ASSIGNING FIELD-SYMBOL(<fs_bukrst>) .
          CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
            EXPORTING
              input  = <fs_bukrst>-rassc
            IMPORTING
              output = <fs_bukrst>-rassc.
        ENDLOOP.
        SORT et_bukrst BY rassc .
      ENDIF.

    ENDIF.

  ENDMETHOD.


METHOD get_bp_info.

    SELECT SINGLE vbund , land1  , gbort , ktokk FROM lfa1 INTO (@e_rassc , @DATA(lv_land1),@e_gbort , @DATA(lv_ktokk) )  WHERE lifnr = @i_bp.
    IF sy-subrc <> 0 .
      SELECT SINGLE vbund , land1 , ktokd FROM kna1 INTO (@e_rassc , @lv_land1 , @DATA(lv_ktokd) )
       WHERE kunnr = @i_bp .

      IF sy-subrc <> 0 .
        SELECT SINGLE vbund FROM bp001 INTO e_rassc WHERE partner = i_bp.
        SELECT SINGLE a~country FROM adrc AS a INNER JOIN but020 AS b ON a~addrnumber = b~addrnumber INTO lv_land1
           WHERE b~partner = i_bp .

      ELSE.
        IF lv_ktokd <> 'Z003' .
          CLEAR e_rassc .
        ENDIF.
      ENDIF.

    ELSE.
      IF lv_ktokk <> 'S003' .
        CLEAR e_rassc .
      ENDIF.

    ENDIF.

    IF lv_land1 = 'CN'.
      e_nwx = '01'.
    ELSE.
      e_nwx = '02'.
    ENDIF.
  ENDMETHOD.


METHOD get_bp_name.


    IF i_k = abap_false .
      SELECT SINGLE name1 FROM lfa1 INTO e_bpname
        WHERE lifnr = i_bp.
      IF sy-subrc <> 0 .
        SELECT SINGLE name1 FROM kna1 INTO e_bpname
          WHERE kunnr = i_bp.
        IF sy-subrc = 0 .
          e_bpt = '10' .
        ELSE.
          SELECT SINGLE name_org1 FROM but000 INTO @DATA(lv_name)
        WHERE partner = @i_bp.
          IF sy-subrc = 0 .
            e_bpname = lv_name .
          ELSE.
            CLEAR : e_bpt , e_bpname.
          ENDIF.
        ENDIF.
      ELSE.
        e_bpt = '20' .
      ENDIF.

    ELSE.
      SELECT SINGLE name1 FROM kna1 INTO e_bpname
       WHERE kunnr = i_bp.
      IF sy-subrc = 0 .
        e_bpt = '10' .
      ELSE.
        CLEAR : e_bpt , e_bpname.
      ENDIF.
    ENDIF.

    r_bpname = e_bpname.

  ENDMETHOD.


METHOD get_bp_typet.
    SELECT SINGLE ddtext INTO ev_bp_typet FROM dd07t
WHERE domname = 'ZBP_TYPE'
 AND ddlanguage = sy-langu
 AND domvalue_l = iv_bp_type .
    IF sy-subrc <> 0 . CLEAR ev_bp_typet . ENDIF.
  ENDMETHOD.


METHOD get_bukrs_name.
    SELECT SINGLE butxt INTO e_txt
      FROM t001
      WHERE bukrs = i_bukrs.

  ENDMETHOD.


METHOD get_bukrs_type.

    IF i_bukrs IS NOT INITIAL .
      SELECT SINGLE burks_type ddtext FROM ztrcds9040 AS b INNER JOIN dd07t AS d
          ON b~burks_type = d~domvalue_l
         INTO ( e_burks_type , e_type_d )
       WHERE bukrs = i_bukrs
         AND DOMNAME = 'ZTRDM_BUKRS_TYPE'
         AND ddlanguage = sy-langu .
    ENDIF.

    IF i_rassc IS NOT INITIAL .

      CALL METHOD zcl_tr_3019_gui=>cvt_bukrs
        EXPORTING
          i_rassc = i_rassc
        IMPORTING
          e_bukrs = DATA(lv_bukrs).

      IF sy-subrc = 0 .
        SELECT SINGLE burks_type ddtext FROM ztrcds9040 AS b INNER JOIN dd07t AS d
            ON b~burks_type = d~domvalue_l
          INTO ( e_burks_type , e_type_d )
         WHERE bukrs = lv_bukrs
          AND DOMNAME = 'ZTRDM_BUKRS_TYPE'
           AND ddlanguage = sy-langu .
      ENDIF.



    ENDIF .


  ENDMETHOD.


METHOD get_bukrs_type_text.
*    SELECT SINGLE ddtext FROM  dd07t
*       INTO e_type_d
*     WHERE domvalue_l = i_burks_type
*       AND domname  = 'ZTRDM_BUKRS_TYPE'
*       AND ddlanguage = sy-langu .

    IF gt_buktyp IS INITIAL.
      SELECT
         domvalue_l
         ddtext
        FROM dd07t INTO TABLE gt_buktyp
    WHERE  domname  = 'ZTRDM_BUKRS_TYPE'
      AND ddlanguage = sy-langu .

    ENDIF.
    READ TABLE gt_buktyp INTO gs_dm WITH  KEY  domvalue_l = i_burks_type.
    IF sy-subrc = 0.
      e_type_d = gs_dm-ddtext.
    ENDIF.
  ENDMETHOD.


METHOD get_detail.

    DATA : lt_agn TYPE ztrt_amt_agn ..
    SELECT   * FROM  ztrt3018_02 INTO TABLE et_item
      FOR ALL ENTRIES IN it_itemn
      WHERE bguid = it_itemn-bguid
       AND itemn = it_itemn-itemn
       AND dflag = abap_false.
    IF sy-subrc = 0 .
      CALL METHOD zcl_tr_3020_gui=>get_agn
        EXPORTING
          it_w_item = et_item
        IMPORTING
          et_agn    = lt_agn.
      LOOP AT lt_agn INTO DATA(ls_agn) WHERE rflag = 'X'.
        READ TABLE et_item ASSIGNING FIELD-SYMBOL(<fs_item>) WITH KEY bguid  = ls_agn-bguid
                                                                      itemn  = ls_agn-witemn.
        IF sy-subrc = 0 .
          <fs_item>-jhzfe = ls_agn-wrbtr_agn.
        ENDIF.
      ENDLOOP.
    ENDIF.
  ENDMETHOD.


METHOD get_fi_lifnr.
    SELECT SINGLE ktonr FROM ztrt_fikd INTO ev_lifnr WHERE zpzlx = 'K' .
  ENDMETHOD.


METHOD get_fkfs_name .
*  SELECT SINGLE text1 FROM t042z INTO e_text1
*    WHERE zlsch = i_zlsch
*      AND land1   = 'CN'.
*  IF sy-subrc <> 0 .
*    CLEAR e_text1 .
*  ELSE .
*    r_text1 = e_text1.
*  ENDIF.

  IF gt_zlsch IS INITIAL.
    SELECT zlsch  AS  domvalue_l   text1  AS ddtext FROM t042z
      INTO TABLE gt_zlsch
    WHERE  land1   = 'CN'.
  ENDIF.
  READ TABLE gt_zlsch INTO gs_dm WITH  KEY domvalue_l = i_zlsch.
  IF sy-subrc = 0.
    e_text1 =   gs_dm-ddtext.
    r_text1 =   gs_dm-ddtext.
  ENDIF.
ENDMETHOD .


METHOD get_flow_t.
    IF gt_flowd IS INITIAL.
      SELECT
        fund_flow   AS domvalue_l
        fund_flowd  AS ddtext

        FROM ztrt9026 INTO TABLE gt_flowd  .

    ENDIF.
    READ TABLE gt_flowd INTO gs_dm WITH  KEY  domvalue_l = iv_flow.
    IF sy-subrc = 0.
      ev_flowt = gs_dm-ddtext.
    ENDIF.

*    SELECT SINGLE fund_flowd FROM ztrt9026 INTO ev_flowt WHERE fund_flow = iv_flow .
  ENDMETHOD.


METHOD GET_FUND_PLAN_STATE.

*       考虑预估支付单和紧急支出计划单的情况
*      1、无计划 - 允许清账
*      2、有计划 无支付单 - 不允许清账 释放计划，版本号XXX
*      3、有计划 有支付单未付款 - 不允许清账  作废支付单XXX并释放计划XXXXXX
*      4、有计划 有支付单部分付款 - 允许清账  TR在周计划中增加按钮让用户释放计划
*      5、有计划 有支付单全部付款 - 不允许清账，只能调用清账程序不能手工清账

*    DATA: LS_3018 TYPE ZTRT3018_01.
*    DATA: LS_2001 TYPE ZTRT2001.
*
*    CLEAR ES_MESSAGE.
*
**校验会计凭证号
*    SELECT COUNT(*)
*      FROM BSEG
*      WHERE BELNR = IV_ZBELNR1.
*    IF SY-SUBRC NE 0.
*      CLEAR ES_STATE.
*      E_BALANCE = ''.
*      CONCATENATE IV_ZBELNR1 ' 会计凭证号不存在，请检查' INTO ES_MESSAGE.
*      EXIT.
*    ENDIF.
*
**根据会计凭证获取周计划
*    SELECT SINGLE A~*
*      INTO @LS_3018
*      FROM ZTRT3018_01 AS A
*      INNER JOIN ZTRT3018_02 AS B ON A~BGUID = B~BGUID
*      WHERE B~BELNR = @IV_ZBELNR1
*        AND B~DFLAG NE 'X'.
*
**根据会计凭证获取支付单
*    SELECT SINGLE *
*      INTO LS_2001
*      FROM ZTRT2001
*      WHERE BUKRS  = LS_3018-BUKRS
*        AND ZWEPLV = LS_3018-ZWKPLV
*        AND BELNR  = IV_ZBELNR1
*        AND DEL_FLG NE 'X'.
*
*    IF LS_3018 IS INITIAL AND LS_2001 IS INITIAL.
*      CLEAR ES_STATE.
*      E_BALANCE = 'X'.
*      CONCATENATE IV_ZBELNR1 '凭证没有对应资金计划和支付单' INTO ES_MESSAGE.
*    ELSEIF LS_3018 IS NOT INITIAL AND LS_2001 IS INITIAL.
*      ES_STATE-BUKRS  = LS_3018-BUKRS.
*      ES_STATE-BELNR  = IV_ZBELNR1.
**      ES_STATE-DOCNO  = LS_3018-
*      ES_STATE-ZJJHBB = LS_3018-ZJJHBB.
*      ES_STATE-ZWKPLV = LS_3018-ZWKPLV.
*      E_BALANCE = ''.
*      CONCATENATE IV_ZBELNR1 '无法清账，请释放资金计划版本：' LS_3018-ZJJHBB INTO ES_MESSAGE.
*    ELSEIF LS_3018 IS NOT INITIAL AND LS_2001 IS NOT INITIAL.
*
*     "有支付单未付款
*
*
*
*     "有支付单部分付款
*
*
*
*     "有支付单全部付款
*
*
*
*    ENDIF.

  ENDMETHOD.


METHOD get_gl_t.
*    SELECT SINGLE ddtext INTO e_txt FROM dd07t
*      WHERE domname = 'ZTR_GLSX'
*        AND ddlanguage = sy-langu
*        AND domvalue_l = i_zglsx.
*    IF sy-subrc <> 0 .
*      CLEAR : e_txt.
*    ENDIF.

    IF gt_GLSX IS INITIAL.
      SELECT
        domvalue_l
        ddtext
        FROM dd07t INTO TABLE gt_GLSX
       WHERE domname = 'ZTR_GLSX'
        AND ddlanguage = sy-langu.
    ENDIF.
    READ TABLE gt_GLSX INTO gs_dm WITH  KEY  domvalue_l = i_zglsx.
    IF sy-subrc = 0.
      e_txt = gs_dm-ddtext.
    ENDIF.


  ENDMETHOD.


METHOD get_gsartt.
*    SELECT SINGLE ltx FROM tzpat INTO ev_gsartt WHERE spras = sy-langu AND gsart = iv_gsart.
    IF gt_GSART IS INITIAL.
      SELECT
        gsart   AS domvalue_l
        ltx  AS ddtext
        FROM tzpat INTO TABLE gt_GSART  WHERE spras = sy-langu.

    ENDIF.
    READ TABLE gt_GSART INTO gs_dm WITH  KEY  domvalue_l = iv_gsart.
    IF sy-subrc = 0.
      ev_gsartt = gs_dm-ddtext.
    ENDIF.

  ENDMETHOD.


METHOD GET_GUA_TYPET.
    SELECT SINGLE ddtext INTO ev_typet FROM dd07t
     WHERE domname = 'ZDM_TR_GUA_TYPE'
       AND ddlanguage = sy-langu
       AND domvalue_l = iv_type .
    IF sy-subrc <> 0 . CLEAR ev_typet . ENDIF.
  ENDMETHOD.


METHOD get_hk_exp.
    IF  check_hk_bukrs( i_bukrs = i_bukrs ) = abap_true.
      APPEND VALUE #( sign = 'I' option = 'EQ' low = 'B19'  ) TO et_rstgr.
    ELSE.
      APPEND VALUE #( sign = 'I' option = 'EQ' low = ''  ) TO et_rstgr.
    ENDIF.
  ENDMETHOD.


METHOD get_jylxt.
    SELECT SINGLE ddtext INTO ev_jylxt FROM dd07t
WHERE domname = 'ZTR_JYLX'
 AND ddlanguage = sy-langu
 AND domvalue_l = iv_jylx .
    IF sy-subrc <> 0 . CLEAR ev_jylxt . ENDIF.
  ENDMETHOD.


METHOD get_kostlt.

    SELECT SINGLE kokrs ,
                  kostl ,
                  datbi FROM csks INTO @DATA(ls_csks) WHERE kostl = @iv_kostl  AND bukrs = @iv_bukrs
                                                        AND datbi >= @sy-datum AND datab <= @sy-datum .
    IF sy-subrc = 0 .
      SELECT SINGLE ktext FROM cskt INTO  ktext WHERE spras = sy-langu
                                                  AND kokrs = ls_csks-kokrs
                                                  AND kostl = ls_csks-kostl
                                                  AND datbi = ls_csks-datbi .
    ENDIF.
  ENDMETHOD.


METHOD get_nwx_t.
*    SELECT SINGLE ddtext INTO e_txt FROM dd07t
*  WHERE domname = 'ZTR_ZNWX'
*    AND ddlanguage = sy-langu
*    AND domvalue_l = i_nwx.
*   if sy-subrc <> 0 . clear e_txt . endif.
*
  IF gt_dm_znwx IS INITIAL.
    SELECT domvalue_l ddtext INTO TABLE gt_dm_znwx FROM dd07t
    WHERE domname = 'ZTR_ZNWX'
    AND ddlanguage = sy-langu .

*    SELECT SINGLE ddtext INTO r_txt FROM dd07t
*      WHERE domname = 'ZTRDM_BILL_CATE'
*        AND ddlanguage = sy-langu
*        AND domvalue_l = i_bcate.

  ENDIF.

  READ TABLE gt_dm_znwx INTO gs_dm  WITH  KEY domvalue_l = i_nwx.
  IF sy-subrc = 0 .
    e_txt = gs_dm-ddtext.
  ENDIF.

  ENDMETHOD.


method GET_PAYTERM.
    select single text1 from t052u into ev_text1
      where spras = sy-langu
        and zterm = iv_zterm .
  endmethod.


METHOD get_prctrt.

    SELECT SINGLE kokrs FROM tka02 INTO @DATA(lv_kokrs) WHERE bukrs = @iv_bukrs .

    SELECT SINGLE ktext INTO ev_prctrt FROM cepct
      WHERE spras = sy-langu
        AND prctr = iv_prctr
        AND datbi >= sy-datum
        AND kokrs = lv_kokrs .
  ENDMETHOD.


METHOD get_prctr_name.

    SELECT SINGLE kokrs FROM tka02 INTO @DATA(lv_kokrs) WHERE bukrs = @iv_bukrs.
    IF sy-subrc = 0 .
      ev_kokrs = lv_kokrs .
      SELECT SINGLE ktext INTO ev_ktext FROM cepct
      WHERE spras = sy-langu
        AND prctr = iv_prctr
        AND datbi >= sy-datum
        AND kokrs = lv_kokrs .
    ENDIF.
  ENDMETHOD.


METHOD get_psphi.
    SELECT SINGLE pspid ,post1   " pspid && '|' && post1
      AS projt FROM proj
      WHERE pspnr = @iv_pspnr
     INTO ( @ev_pspid , @ev_post1 ) . ",@ev_projt


    IF sy-subrc = 0 .
      CALL FUNCTION 'CONVERSION_EXIT_ABPSN_OUTPUT'
        EXPORTING
          input  = ev_pspid
        IMPORTING
          output = ev_pspid.
      ev_projt = ev_pspid && '|' && ev_post1 .
    ENDIF.


  ENDMETHOD.


METHOD get_sbewart.

*    SELECT SINGLE sldwart_t FROM ztrc0001 INTO ev_sbewartt WHERE sbewart = iv_sbewart.
    IF gt_sbewart IS INITIAL.
      SELECT
        sbewart   AS domvalue_l
        sldwart_t  AS ddtext

        FROM ztrc0001 INTO TABLE gt_sbewart  .


    ENDIF.
    READ TABLE gt_sbewart INTO gs_dm WITH  KEY  domvalue_l = iv_sbewart.
    IF sy-subrc = 0.
      EV_SBEWARTT = gs_dm-ddtext.
    ENDIF.
  ENDMETHOD.


METHOD get_shkzgt.
    SELECT SINGLE ddtext INTO ev_shzkgt FROM dd07t
WHERE domname = 'SHKZG'
 AND ddlanguage = sy-langu
 AND domvalue_l = iv_shkzg .
    IF sy-subrc <> 0 . CLEAR ev_shzkgt . ENDIF.
  ENDMETHOD.


METHOD GET_SJLYT.

    SELECT SINGLE ddtext INTO e_txt FROM dd07t
     WHERE domname = 'ZBK_SJLY'
       AND ddlanguage = sy-langu
       AND domvalue_l = i_zsjly.
    IF sy-subrc = 0 .
      r_txt = e_txt.
    ENDIF.
  ENDMETHOD.


METHOD get_status_t.
*    SELECT SINGLE ddtext FROM  ztrv_appro1 INTO  r_txt
*      WHERE zappro = i_sts
*        AND ddlanguage = sy-langu .
*    IF sy-subrc = 0 .
*      e_txt = r_txt.
*    ENDIF.

    IF gt_appro IS INITIAL.
      SELECT
        zappro   AS domvalue_l
        ddtext
        FROM ztrv_appro1 INTO TABLE gt_appro
        WHERE ddlanguage = sy-langu.


    ENDIF.
    READ TABLE gt_appro INTO gs_dm WITH  KEY  domvalue_l = i_sts.
    IF sy-subrc = 0.
      r_txt = gs_dm-ddtext.
     e_txt = r_txt.
    ENDIF.

  ENDMETHOD.


METHOD get_stitelt.
*    SELECT SINGLE xkbez FROM td03t INTO ev_stitelt  WHERE spras = sy-langu  AND stitel = iv_stitel.
    IF gt_stitel IS INITIAL.
      SELECT
        stitel   AS domvalue_l
        xkbez  AS ddtext
        FROM td03t INTO TABLE gt_stitel  WHERE spras = sy-langu.
    ENDIF.
    READ TABLE gt_stitel INTO gs_dm WITH  KEY  domvalue_l = iv_stitel.
    IF sy-subrc = 0.
      ev_stitelt = gs_dm-ddtext.
    ENDIF.

  ENDMETHOD.


METHOD get_vdarl.
    SELECT SINGLE gsart stitel FROM vdarl
      INTO ( ev_gsart , ev_stitel )
      WHERE bukrs = iv_bukrs
       AND sarchiv = space
       AND ranl = iv_ranl .
  ENDMETHOD.


METHOD get_vdarl_all.
    IF it_ranl IS INITIAL .RETURN . ENDIF.

    DATA(lt_ranl) = it_ranl .
    SORT lt_ranl BY ranl .
    DELETE ADJACENT DUPLICATES FROM lt_ranl COMPARING ranl .

    SELECT  ranl gsart stitel FROM vdarl INTO CORRESPONDING FIELDS OF TABLE et_ranl
      FOR ALL ENTRIES IN lt_ranl
  WHERE bukrs = iv_bukrs
    AND sarchiv = space
    AND ranl = lt_ranl-ranl .

    IF sy-subrc = 0 .
      SORT et_ranl BY ranl.
    ENDIF.
  ENDMETHOD.


METHOD get_w_sts.
    SELECT SINGLE status_w FROM ztrt3018_01 INTO e_sts
      WHERE bguid = i_bguid.
    IF sy-subrc = 0 .
    ENDIF.
  ENDMETHOD.


METHOD get_zfsqd_range.
    IF gt_sqdtyrage IS INITIAL.
      SELECT
      'I' AS sign,
      'EQ' AS option,
      domvalue_l AS low
      FROM dd07t
      WHERE domname = 'ZTR_SQD_BCATE'  AND ddlanguage = @sy-langu
      INTO CORRESPONDING FIELDS OF TABLE @gt_sqdtyrage.
    ENDIF.

    et_range =  gt_sqdtyrage.
  ENDMETHOD.


METHOD get_zgroup_t.
    SELECT SINGLE ddtext FROM ztrt_bk_grp INTO ev_text
  WHERE zbk_grp = iv_grp.
    IF sy-subrc = 0 .
      rv_text = ev_text.
    ELSE."
      SELECT SINGLE ddtext FROM  dd07t INTO ev_text
      WHERE domname = 'ZBK_GRP'
      AND ddlanguage = sy-langu
      AND domvalue_l = iv_grp.
      rv_text = ev_text.
    ENDIF.
  ENDMETHOD.


METHOD get_zhlxt.
    SELECT SINGLE ddtext INTO ev_zhlxt FROM dd07t
     WHERE domname = 'ZDMTR_ZHLX'
       AND ddlanguage = sy-langu
       AND domvalue_l = iv_zhlx .
    IF sy-subrc <> 0 . CLEAR ev_zhlxt . ENDIF.
  ENDMETHOD.


METHOD get_zzffs.

    DATA : lv_num TYPE i .

    DATA(lt_type) = it_type .

    SORT lt_type . DELETE ADJACENT DUPLICATES FROM lt_type.

    LOOP AT lt_type INTO DATA(lv_type) .
      IF lv_type <> 'T'  AND lv_type <> 'D'.
        lv_num = lv_num + 1 .
        DATA(lv_cur_type) = lv_type.
      ENDIF.
    ENDLOOP.

    IF lv_num >= 2 .
      MESSAGE  e340(ztr01)  RAISING err.
    ENDIF.

    IF lv_num = 1 .
      SELECT SINGLE zzffs  FROM ztrt9042 INTO ev_zzffs WHERE zskfs = lv_cur_type .
      IF sy-subrc <> 0 .
        MESSAGE  e340(ztr01)  RAISING err.
      ELSE.
        RETURN .
      ENDIF.
    ENDIF.
  ENDMETHOD.


method lock_bukrs.
    call function 'ENQUEUE_EZTRV_T001'
      exporting
        mode_ztrv_t001 = 'E'
        bukrs          = iv_bukrs
        _scope           = '3'
      exceptions
        foreign_lock   = 1
        system_failure = 2
        others         = 3.
    if sy-subrc <> 0.
      message id sy-msgid  type sy-msgty number sy-msgno
        with  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 raising err.
    endif.
  endmethod.


METHOD lock_jj.

    CALL FUNCTION 'ENQUEUE_EZZTRT3020_01'
      EXPORTING
        mode_ztrt3020_01 = 'E'
        billn            = iv_billn
        _scope           = '3'
      EXCEPTIONS
        foreign_lock     = 1
        system_failure   = 2
        OTHERS           = 3.
    IF sy-subrc <> 0 .
      MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
        WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
    ENDIF.

    CALL FUNCTION 'ENQUEUE_EZZTRT3020_02'
      EXPORTING
        mode_ztrt3020_02 = 'E'
        billn            = iv_billn
        _scope           = '3'
      EXCEPTIONS
        foreign_lock     = 1
        system_failure   = 2
        OTHERS           = 3.
    IF sy-subrc <> 0 .
      MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
        WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
    ENDIF.

    IF iv_pass_agn = space.
      DATA(ls_02) = VALUE ztrt3020_02( billn = iv_billn ).

      CALL METHOD zcl_tr_3020_gui=>lock_jjagn
        EXPORTING
          is_w_item = ls_02
        EXCEPTIONS
          err       = 1
          OTHERS    = 2.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
        WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD lock_mhead.

    CALL FUNCTION 'ENQUEUE_EZZTRT3017_01'
      EXPORTING
        mode_ztrt3017_01 = 'E'
        bguid            = iv_bguid
        _scope           = '3'
      EXCEPTIONS
        foreign_lock     = 1
        system_failure   = 2
        OTHERS           = 3.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
      WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
    ENDIF.

*    SELECT * FROM ztrt3017_02
*     WHERE bguid =  @iv_bguid
*       AND dflag = @abap_false
*    INTO TABLE @DATA(lt_02) .
*
*
*    LOOP AT lt_02 INTO DATA(ls_02) .
*
*      CALL METHOD zcl_tr_3019_gui=>lock_mitem
*        EXPORTING
*          iv_bguid = ls_02-bguid
*          iv_itemn = ls_02-itemn
*        EXCEPTIONS
*          err      = 1
*          OTHERS   = 2.
*      IF sy-subrc <> 0.
*        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
*        WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
*      ENDIF.
*
*    ENDLOOP.

    CALL FUNCTION 'ENQUEUE_EZZTRT3017_02'
      EXPORTING
        mode_ztrt3017_02 = 'E'
        bguid            = iv_bguid
     "  itemn            = iv_itemn
        _scope           = '3'
      EXCEPTIONS
        foreign_lock     = 1
        system_failure   = 2
        OTHERS           = 3.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
      WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
    ENDIF.

  ENDMETHOD.


METHOD lock_mitem.

    CALL FUNCTION 'ENQUEUE_EZZTRT3017_02'
      EXPORTING
        mode_ztrt3017_02 = 'E'
        bguid            = iv_bguid
        itemn            = iv_itemn
        _scope           = '3'
      EXCEPTIONS
        foreign_lock     = 1
        system_failure   = 2
        OTHERS           = 3.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
        WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
    ENDIF.

  ENDMETHOD.


METHOD lock_week_month.
    DATA ls_sy TYPE syst.
    CALL FUNCTION 'ENQUEUE_EZZTRV9010'
      EXPORTING
        mode_ztrv9010  = 'E'
        mandt          = sy-mandt
        zversion       = is_9010-zversion
        gjahr          = is_9010-gjahr
        monat          = is_9010-monat
        zmplv          = is_9010-zmplv
        qmdate         = is_9010-qmdate
        bmdate         = is_9010-bmdate
        emdate         = is_9010-emdate
        zwmark         = is_9010-zwmark
        zwplv          = is_9010-zwplv
        qwdate         = is_9010-qwdate
        bwdate         = is_9010-bwdate
        ewdate         = is_9010-ewdate
        _scope         = '3'
      EXCEPTIONS
        foreign_lock   = 1
        system_failure = 2
        OTHERS         = 3.
    IF sy-subrc <> 0.
      ls_sy = sy.
*     判断一下 如果是运行计划，则不锁（实际很少见，但多个公司同时运行会出错 2020.4.28
      IF sy-subrc = 1.

        DATA garg     TYPE seqg3-garg.
        DATA enq      TYPE STANDARD TABLE OF seqg3.

        garg = is_9010.
        CALL FUNCTION 'ENQUEUE_READ'
          EXPORTING
*           GCLIENT               = SY-MANDT
            gname                 = 'ZTRV9010'
            garg                  = garg
            guname                = CONV eqeuname( sy-msgv1 )
*           LOCAL                 = ' '
*           FAST                  = ' '
*           GARGNOWC              = ' '
*        IMPORTING
*           NUMBER                = NUMBER
*           SUBRC                 = SUBRC
          TABLES
            enq                   = enq
          EXCEPTIONS
            communication_failure = 1
            system_failure        = 2
            OTHERS                = 3.
        IF sy-subrc = 0.
          LOOP AT enq INTO DATA(is_enq).
            IF is_enq-gtcode = sy-tcode .
              RETURN.
            ENDIF.
            EXIT.
          ENDLOOP.
        ENDIF.
      ENDIF.
*     判断一下 如果是运行计划，则不锁（实际很少见，但多个公司同时运行会出错 2020.4.28

      MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
      WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
    ENDIF.
  ENDMETHOD.


METHOD lock_whead.

    CALL FUNCTION 'ENQUEUE_EZZTRT3018_01'
      EXPORTING
        mode_ztrt3018_01 = 'E'
        bguid            = iv_bguid
        _scope           = '3'
      EXCEPTIONS
        foreign_lock     = 1
        system_failure   = 2
        OTHERS           = 3.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
      WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
    ENDIF.

    CALL FUNCTION 'ENQUEUE_EZZTRT3018_02'
      EXPORTING
        mode_ztrt3018_02 = 'E'
        bguid            = iv_bguid
        _scope           = '3'
      EXCEPTIONS
        foreign_lock     = 1
        system_failure   = 2
        OTHERS           = 3.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
      WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
    ENDIF.


    IF iv_agn = abap_true .
      SELECT * FROM ztrt3018_02
       WHERE bguid =  @iv_bguid
         AND dflag = @abap_false
        INTO TABLE @DATA(lt_02) .

      LOOP AT lt_02 INTO DATA(ls_02) WHERE sjzfje > 0.

*      CALL METHOD zcl_tr_3019_gui=>lock_witem
*        EXPORTING
*          iv_bguid = ls_02-bguid
*          iv_itemn = ls_02-itemn
*        EXCEPTIONS
*          err      = 1
*          OTHERS   = 2.
*      IF sy-subrc <> 0.
*        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
*        WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
*      ENDIF.

*      IF iv_agn = abap_true .
        CALL METHOD zcl_tr_3020_gui=>lock_agn
          EXPORTING
            is_w_item = ls_02
          EXCEPTIONS
            err       = 1
            OTHERS    = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
          WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
        ENDIF.
*      ENDIF.
      ENDLOOP.
    ENDIF.

  ENDMETHOD.


METHOD lock_witem.

    CALL FUNCTION 'ENQUEUE_EZZTRT3018_02'
      EXPORTING
        mode_ztrt3018_02 = 'E'
        bguid            = iv_bguid
        itemn            = iv_itemn
        _scope           = '3'
      EXCEPTIONS
        foreign_lock     = 1
        system_failure   = 2
        OTHERS           = 3.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
        WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
    ENDIF.

    IF iv_agn = abap_true   .
      DATA(ls_02) = VALUE ztrt3018_02( bguid = iv_bguid  itemn = iv_itemn ) .
      CALL METHOD zcl_tr_3020_gui=>lock_agn
        EXPORTING
          is_w_item = ls_02
        EXCEPTIONS
          err       = 1
          OTHERS    = 2.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
        WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD unlock_bukrs.
    CALL FUNCTION 'DEQUEUE_EZTRV_T001'
      EXPORTING
        mode_ztrv_t001 = 'E'
        bukrs          = iv_bukrs
        _scope         = '3'
      EXCEPTIONS
        foreign_lock   = 1
        system_failure = 2
        OTHERS         = 3.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
        WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
    ENDIF.
  ENDMETHOD.


METHOD unlock_jj.

    CALL FUNCTION 'DEQUEUE_EZZTRT3020_01'
      EXPORTING
        mode_ztrt3020_01 = 'E'
        billn            = iv_billn
        _scope           = '3'
      EXCEPTIONS
        foreign_lock     = 1
        system_failure   = 2
        OTHERS           = 3.
    IF sy-subrc <> 0 .
      MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
        WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
    ENDIF.

    CALL FUNCTION 'DEQUEUE_EZZTRT3020_02'
      EXPORTING
        mode_ztrt3020_02 = 'E'
        billn            = iv_billn
        _scope           = '3'
      EXCEPTIONS
        foreign_lock     = 1
        system_failure   = 2
        OTHERS           = 3.
    IF sy-subrc <> 0 .
      MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
        WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
    ENDIF.

    IF iv_pass_agn = space.
      DATA(ls_02) = VALUE ztrt3020_02( billn = iv_billn ).

      CALL METHOD zcl_tr_3020_gui=>unlock_jjagn
        EXPORTING
          is_w_item = ls_02
        EXCEPTIONS
          err       = 1
          OTHERS    = 2.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
        WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD UNLOCK_MHEAD.

    CALL FUNCTION 'DEQUEUE_EZZTRT3017_01'
      EXPORTING
        mode_ztrt3017_01 = 'E'
        bguid            = iv_bguid
        _scope           = '3'
      EXCEPTIONS
        foreign_lock     = 1
        system_failure   = 2
        OTHERS           = 3.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
      WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
    ENDIF.


    SELECT * FROM ztrt3017_02 INTO TABLE @DATA(lt_02)
     WHERE bguid = @iv_bguid
       AND dflag = @abap_false.


    LOOP AT lt_02 INTO DATA(ls_02) .

      CALL METHOD zcl_tr_3019_gui=>unlock_mitem
        EXPORTING
          iv_bguid = ls_02-bguid
          iv_itemn = ls_02-itemn
        EXCEPTIONS
          err      = 1
          OTHERS   = 2.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
        WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
      ENDIF.

    ENDLOOP.


  ENDMETHOD.


method UNLOCK_MITEM.
    call function 'DEQUEUE_EZZTRT3017_02'
      exporting
        mode_ztrt3017_02 = 'E'
        bguid            = iv_bguid
        itemn            = iv_itemn
        _scope           = '3'
      exceptions
        foreign_lock     = 1
        system_failure   = 2
        others           = 3.
    if sy-subrc <> 0.
      message id sy-msgid  type sy-msgty number sy-msgno
        with  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 raising err.
    endif.
  endmethod.


METHOD unlock_week_month.
    CALL FUNCTION 'DEQUEUE_EZZTRV9010'
      EXPORTING
        mode_ztrv9010  = 'E'
        mandt          = sy-mandt
        zversion       = is_9010-zversion
        gjahr          = is_9010-gjahr
        monat          = is_9010-monat
        zmplv          = is_9010-zmplv
        qmdate         = is_9010-qmdate
        zwmark         = is_9010-zwmark
        zwplv          = is_9010-zwplv
        qwdate         = is_9010-qwdate
        bwdate         = is_9010-bwdate
        ewdate         = is_9010-ewdate
        _scope         = '3'
      EXCEPTIONS
        foreign_lock   = 1
        system_failure = 2
        OTHERS         = 3.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
        WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
    ENDIF.
  ENDMETHOD.


METHOD unlock_whead.

    CALL FUNCTION 'DEQUEUE_EZZTRT3018_01'
      EXPORTING
        mode_ztrt3018_01 = 'E'
        bguid            = iv_bguid
        _scope           = '3'
      EXCEPTIONS
        foreign_lock     = 1
        system_failure   = 2
        OTHERS           = 3.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
      WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
    ENDIF.


    SELECT * FROM ztrt3018_02 INTO TABLE @DATA(lt_02)
     WHERE bguid = @iv_bguid
       AND dflag = @abap_false.


    LOOP AT lt_02 INTO DATA(ls_02) .

      CALL METHOD zcl_tr_3019_gui=>unlock_witem
        EXPORTING
          iv_bguid = ls_02-bguid
          iv_itemn = ls_02-itemn
        EXCEPTIONS
          err      = 1
          OTHERS   = 2.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
        WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
      ENDIF.

      IF iv_agn = abap_true.
        CALL METHOD zcl_tr_3020_gui=>unlock_agn
          EXPORTING
            is_w_item = ls_02
          EXCEPTIONS
            err       = 1
            OTHERS    = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
          WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
        ENDIF.
      ENDIF.
    ENDLOOP.


  ENDMETHOD.


METHOD unlock_witem.

    CALL FUNCTION 'DEQUEUE_EZZTRT3018_02'
      EXPORTING
        mode_ztrt3018_02 = 'E'
        bguid            = iv_bguid
        itemn            = iv_itemn
        _scope           = '3'
      EXCEPTIONS
        foreign_lock     = 1
        system_failure   = 2
        OTHERS           = 3.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
        WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
    ENDIF.

    IF iv_agn = abap_true .
      DATA(ls_02) = VALUE ztrt3018_02( bguid = iv_bguid  itemn = iv_itemn ) .

      CALL METHOD zcl_tr_3020_gui=>unlock_agn
        EXPORTING
          is_w_item = ls_02
        EXCEPTIONS
          err       = 1
          OTHERS    = 2.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
        WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
      ENDIF.
    ENDIF.
  ENDMETHOD.
ENDCLASS.
