FUNCTION ZFM_UPDATE_BANK_REFDOC.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     REFERENCE(FIELDVALUE1) TYPE  DDSHVALUE
*"     REFERENCE(MODE) TYPE  ZTR_MODE DEFAULT 'S'
*"  TABLES
*"      ET_BANK_DOC STRUCTURE  ZTRS_BANK_DOC
*"      ET_RETURN STRUCTURE  BAPIRET2
*"--------------------------------------------------------------------
*  DATA: lt_bank_dc TYPE TABLE OF ztrs_bank_doc.
*  DATA: lt_bank_dc_blank  TYPE TABLE OF ztrs_bank_doc.
*  DATA: lt_msg TYPE TABLE OF bapiret2.
*
*  SELECT * FROM ztr_update_bkdoc INTO TABLE @DATA(lt_bank_docs) WHERE del <> 'X'.
*  IF sy-subrc <> 0.
*    set_msg 'E' 'ZTR02' '495' '' '' '' '' ''.
*    et_return[] = lt_msg. EXIT.
*  ENDIF.
*
*  IF fieldvalue1 = '*'.
*    PERFORM frm_get_bank_refdoc_blank TABLES lt_bank_dc_blank.
*    PERFORM frm_get_doc_refdoc_blank  TABLES lt_bank_docs lt_bank_dc_blank lt_bank_dc lt_msg USING fieldvalue1 mode.
*  ELSE.
*    PERFORM frm_get_bank_docs TABLES lt_bank_docs lt_bank_dc lt_msg USING fieldvalue1 mode.
*  ENDIF.
*
*  et_bank_doc[] = lt_bank_dc.
*  et_return[] = lt_msg.
*  CLEAR lt_bank_dc.





ENDFUNCTION.
