FUNCTION ZFM_TR_LOCK_PAYMENTORDER.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     REFERENCE(IM_DOCNO) TYPE  ZTRT_PAYMENT-PAYMORDER
*"  EXCEPTIONS
*"      FOREIGN_LOCK
*"      SYSTEM_FAILURE
*"--------------------------------------------------------------------
READ TABLE gt_lock_payment_order INTO DATA(ls_payment_order)
       WITH KEY docno = im_docno.
  IF sy-subrc = 0.
*    被当前SESSION锁定,不再执行锁定
    RETURN.
  ENDIF.

  APPEND VALUE #( docno = im_docno ) TO gt_lock_payment_order.

  CALL FUNCTION 'ENQUEUE_EZPAYMORD_LOCK'
    EXPORTING
      mode_zpaymord_lock = 'E'
      mandt              = sy-mandt
      paymorder          = im_docno
      x_paymorder        = ' '
      _scope             = '2'
      _wait              = ' '
      _collect           = ' '
    EXCEPTIONS
      foreign_lock       = 1
      system_failure     = 2
      OTHERS             = 3.
  CASE sy-subrc.
    WHEN 0.
      RETURN.
    WHEN 1.
      DELETE gt_lock_payment_order
             WHERE docno = im_docno.
      MESSAGE id sy-msgid
              type sy-msgty
              number sy-msgno
              with sy-msgv1
                   sy-msgv2
                   sy-msgv3
                   sy-msgv4
              RAISING foreign_lock.
    WHEN 2.
      DELETE gt_lock_payment_order
             WHERE docno = im_docno.
      MESSAGE id sy-msgid
              type sy-msgty
              number sy-msgno
              with sy-msgv1
                   sy-msgv2
                   sy-msgv3
                   sy-msgv4
              RAISING system_failure.
  ENDCASE.





ENDFUNCTION.
