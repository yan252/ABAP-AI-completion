class ZCL_BANK_BOC_S definition
  public
  final
  create public .

public section.

  interfaces IF_HTTP_EXTENSION .

  types:
    BEGIN OF type_s_key_value.
    TYPES:fname  TYPE string.
    TYPES:fvalue TYPE string.
    TYPES:END OF type_s_key_value .
  types:
    type_t_key_value TYPE STANDARD TABLE OF type_s_key_value WITH DEFAULT KEY .

  constants DESTINATION type RFCDEST value 'RFC_BOC_S' ##NO_TEXT.


  methods REQUEST_POST
    importing
      !REQUEST type XSTRING
      !DEST type RFCDEST default DESTINATION
    exporting
      value(RESPONSE) type STRING
    returning
      value(ERROR) type STRING .
  methods CONVERT_XLM_TO_DOCUMENT
    importing
      !CONTENT type STRING
    exporting
      !PARSER type ref to IF_IXML_PARSER
      !DOCUMENT type ref to IF_IXML_DOCUMENT .
  methods TRANSFORMATION
    importing
      !ELEMENT type ref to IF_IXML_ELEMENT
    exporting
      !KEY_VALUE type TYPE_T_KEY_VALUE .
  methods DISPLAY_STRING_XML
    importing
      !CONTENT type STRING .
  methods DOWNLOAD_XML
    importing
      !CONTENT type STRING
      !PATH type LOCALFILE .
  methods CONVERT_XSTRING_TO_STRING
    importing
      !INPUT type XSTRING
    exporting
      !OUTPUT type STRING .
protected section.
private section.

  methods CONVERT_XLM_TO_DOCUMANT .
  methods DECODE_XTRSING_TO_STRING .
ENDCLASS.



CLASS ZCL_BANK_BOC_S IMPLEMENTATION.


method CONVERT_XLM_TO_DOCUMANT.
  endmethod.


method CONVERT_XLM_TO_DOCUMENT.
  endmethod.


method CONVERT_XSTRING_TO_STRING.
  endmethod.


method DECODE_XTRSING_TO_STRING.
  endmethod.


method DISPLAY_STRING_XML.
  endmethod.


method DOWNLOAD_XML.
  endmethod.


method IF_HTTP_EXTENSION~HANDLE_REQUEST.
  data request_str          type xstring.
  data response_str         type string.
  data:lv_err_text          type string.

  data:request_method   type string.



  "获取传递过来的参数 ~request_method
  request_method = server->request->get_header_field( '~request_method' ) .

  "POST http Method CO_REQUEST_METHOD_GET
  if request_method = if_http_request=>co_request_method_get.

    server->response->set_status( code = 200 reason = 'Ok' ).
    "server->response->set_content_type( 'application/json' ).
    server->response->set_cdata( data = response_str ).

  endif.

  "POST http method
  "IF request_method = 'POST'.

  if request_method = if_http_request=>co_request_method_post.

    request_str = server->request->get_data( ).

    lv_err_text = me->request_post( exporting request = request_str importing response = response_str ).

    if lv_err_text is initial.

      "Send the response back
      server->response->set_status( code = 200 reason = 'Ok' ).
      server->response->set_cdata( data = response_str ).

    else."500
      response_str = lv_err_text && response_str.
      server->response->set_status( code = 500 reason = 'Ok' ).
      server->response->set_cdata( data = response_str ).

    endif.

  endif.

  " PUT http method: modify
  if request_method = 'PUT'.

  endif.

  "DELETE http method: delete
  if request_method = 'DELETE'.

  endif.

  endmethod.


method REQUEST_POST.

    data:http_client          type ref to if_http_client.
    data:lv_system_fault      type ref to cx_ai_system_fault.
    data:lv_application_fault type ref to cx_ai_application_fault.
    data:lv_err_text          type string.
    data request_str          type string.

    data: request1  type string.

    "Create HTTP client object
    cl_http_client=>create_by_destination( exporting destination = dest importing client = http_client ).

    "SET request uri (/<path>[?<querystring>])
    cl_http_utility=>set_request_uri( request = http_client->request uri = '/BisOutPlatform/services/erpPlatform?wsdl' ).

    http_client->request->set_method( if_http_request=>co_request_method_post ).


*    me->DECODE_XSTRING_TO_STRING( exporting IV_ENCODING = 'UTF-8' IV_XML_XSTRING = request  importing EV_XML_STRING = request1  ).
    me->CONVERT_XSTRING_TO_STRING( exporting INPUT = request  importing OUTPUT = request1  ).



    "构造查询报文
    concatenate
    '<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:web="http://webservice.bedp.byttersoft.com">'
    '<soap:Header/>'
    '<soap:Body>'
    '<web:serverErpXml>'
    '<web:erpReqXml>'
    '<![CDATA['
*    request
    request1 "MODIFY BY CRH 20190723
    ']]>'
    '</web:erpReqXml>'
    '</web:serverErpXml>'
    '</soap:Body>'
    ' </soap:Envelope>'
    into request_str.

    http_client->request->set_header_field( name = 'server_protocol' value = 'HTTP/1.2' ).
    http_client->request->set_header_field( name = 'soapAction' value = 'http://172.20.0.40:8090/BisOutPlatform/services/erpPlatform/serverErpXml' ).
    http_client->request->set_cdata( data =  request_str ).
    http_client->send( exceptions http_communication_failure = 1 http_invalid_state = 2 ).
    try.
        http_client->receive( exceptions http_communication_failure = 1 http_invalid_state = 2 http_processing_failed = 3 ).
      catch cx_ai_system_fault into lv_system_fault.
        lv_err_text = lv_system_fault->get_text( ).
      catch cx_ai_application_fault into lv_application_fault.
        lv_err_text = lv_application_fault->get_text( ).
    endtry.
    response = http_client->response->get_cdata( ).
    http_client->close( ).

    "返回的SOAP 不是 最终要的报文 预处理
    data:lv_parser     type ref to if_ixml_parser.
    data:lv_document   type ref to if_ixml_document.
    data:element       type ref to if_ixml_element.
    data:lt_key_value  type type_t_key_value.
    data:ls_key_value  type type_s_key_value.

    me->convert_xlm_to_document( exporting content = response importing parser = lv_parser document = lv_document ).

    clear:element.
    call method lv_document->find_from_path
      exporting
        path = '/soapenv:Envelope/soapenv:Body/ns:serverErpXmlResponse/ns:return'
      receiving
        rval = element.

    me->transformation( exporting element = element importing key_value = lt_key_value ).

    read table lt_key_value into ls_key_value with key fname = 'return'.
    if sy-subrc eq 0.
      response = ls_key_value-fvalue.
    endif.

    error = lv_err_text.

  endmethod.


method TRANSFORMATION.
  endmethod.
ENDCLASS.
