FUNCTION ZFM_CHECK_BK.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     REFERENCE(BUKRS) TYPE  BUKRS
*"     REFERENCE(HBKID) TYPE  HBKID
*"     REFERENCE(HKTID) TYPE  HKTID
*"     REFERENCE(BANKL) TYPE  BANKL OPTIONAL
*"     REFERENCE(YHZH) TYPE  ZTR_YHZH OPTIONAL
*"  EXPORTING
*"     REFERENCE(ERROR) TYPE  CHAR1
*"--------------------------------------------------------------------
DATA lv_bank TYPE bankl.
  DATA lv_yhzh TYPE ztr_yhzh.
  SELECT SINGLE bankl yhzh INTO (lv_bank,lv_yhzh)
    FROM ztrt0013
    WHERE bukrs = bukrs AND hbkid = hbkid AND hktid = hktid.
  IF sy-subrc = 0.
    IF bankl IS NOT INITIAL.
      IF bankl <> lv_bank.
        error = abap_true.
      ENDIF.
    ENDIF.

    IF yhzh IS NOT INITIAL.
      IF yhzh <> lv_yhzh.
        error = abap_true.
      ENDIF.
    ENDIF.
  ENDIF.





ENDFUNCTION.
