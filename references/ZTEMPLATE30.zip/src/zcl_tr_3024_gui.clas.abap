class ZCL_TR_3024_GUI definition
  public
  final
  create public .

public section.

  class-data IV_POST_RSTGR type CHAR01 .
  class-data AUTH type CHAR01 value '' ##NO_TEXT.
  class-data GT_PP_02 type ZTRTT_3023_02 .
  class-data GT_BTRANS type ZTRT_BANK_TRANS_TAB .
  class-data GT_PP_02_CF type ZTRTT_3023_02_CF .

  class-methods CHECK_3023_04
    importing
      !IV_BUKRS type BUKRS
      !IV_QJ type ZBK_TJBQJ
      !IV_HKONT type HKONT
    exporting
      value(EV_SAVE) type CHAR01 .
  class-methods GET_GROUP
    importing
      !IV_ZGROUP type ZBK_GRP
    exporting
      !ET_RGROUP type ZTRT_3028_RANG .
  class-methods MAPPING_BY_REF
    importing
      !IV_GROUP type ZBK_GRPAC
      !IV_DOC type ZBK_REF_DOC
      !IV_LOCK type BOOLEAN default ABAP_TRUE
      !IV_COMMIT type BOOLEAN default ABAP_TRUE
      !IV_ZPPDATE type D optional
      !IT_FI_DOC type ZTRT_BELNR
    exceptions
      ERR .
  class-methods AGN_REF
    importing
      !IT_REF type ZTRT_3028_AGNREF
      !IV_LOCK type BOOLEAN default ABAP_TRUE
      !IV_COMMIT type BOOLEAN default ABAP_TRUE
      !IV_GROUP type ZBK_GRPAC
    exceptions
      ERR .
  class-methods AGN_REF_TR2
    importing
      !IT_REF type ZTRT_3028_AGNREF
      !IV_LOCK type BOOLEAN default ABAP_TRUE
      !IV_COMMIT type BOOLEAN default ABAP_TRUE
      !IV_GROUP type ZBK_GRPAC
      !IV_JXLXT type ZTR2_JXLXT optional
    exceptions
      ERR .
  class-methods UNLOCK_ALL
    importing
      !IT_TRANS type ZTRT_3028_AGNREF
    exceptions
      ERR .
  class-methods LOCK_ALL
    importing
      !IT_TRANS type ZTRT_3028_AGNREF
    exceptions
      ERR .
  class-methods LOCK_1
    importing
      !IV_TRANS type ZTRS_3028_AGNREF
    exceptions
      ERR .
  class-methods UNLOCK_1
    importing
      !IV_TRANS type ZTRS_3028_AGNREF
    exceptions
      ERR .
  class-methods LOCK_2
    importing
      !IV_TRANS type ZTRS_3028_AGNREF
    exceptions
      ERR .
  class-methods UNLOCK_2
    importing
      !IV_TRANS type ZTRS_3028_AGNREF
    exceptions
      ERR .
  class-methods LOCK_3
    importing
      !IV_TRANS type ZTRS_3028_AGNREF
    exceptions
      ERR .
  class-methods UNLOCK_3
    importing
      !IV_TRANS type ZTRS_3028_AGNREF
    exceptions
      ERR .
  class-methods GET_PPZT
    importing
      !IV_ZGROUP type ZBK_GRP
    exporting
      !EV_ZPPZT type ZBK_PPZT .
  class-methods UNMAPPING_BY_MANUAL
    importing
      !IT_REF type ZTRT_3028_AGNREF
      !IV_LOCK type BOOLEAN optional
      !IV_COMMIT type BOOLEAN optional
      !IT_BSIS type ZTRTT3023_03
    exceptions
      ERR .
  class-methods MAPPING_BY_MANUAL
    importing
      !IT_REF type ZTRT_3028_AGNREF
      !IV_LOCK type BOOLEAN optional
      !IV_COMMIT type BOOLEAN optional
      !IV_ZPPQJ type ZBK_PPQJ optional
      !IT_BSIS type ZTRTT3023_03
    exceptions
      ERR .
  class-methods MAPPING_BY_ATUO
    importing
      !IS_REF type ZTRS_3028_AGNREF
      !IV_LOCK type BOOLEAN optional
      !IV_COMMIT type BOOLEAN optional
      !IV_ZPPQJ type ZBK_PPQJ optional
      !IS_BSIS type ZTRT3023_03
    exceptions
      ERR .
  class-methods UNMAPPING_BY_ATUO
    importing
      !IS_REF type ZTRS_3028_AGNREF
      !IV_LOCK type BOOLEAN optional
      !IV_COMMIT type BOOLEAN optional
      !IS_BSIS type ZTRT3023_03
    exceptions
      ERR .
  class-methods MAPPING_UNMAPPING_LOG
    importing
      value(I_MODE) type PS_UPDMODE
      value(IT_LOG) type ZTRT3023_03_T
    exceptions
      ERROR .
  class-methods UNAGN_REF
    importing
      !IV_LOCK type BOOLEAN default ABAP_TRUE
      !IV_COMMIT type BOOLEAN default ABAP_TRUE
      !IV_GROUP type ZBK_GRPAC
      !IV_DOC type ZBK_REF_DOC
    exceptions
      ERR .
  class-methods UNAGN_REF_TR2
    importing
      !IV_LOCK type BOOLEAN default ABAP_TRUE
      !IV_COMMIT type BOOLEAN default ABAP_TRUE
      !IV_GROUP type ZBK_GRPAC
      !IV_DOC type ZBK_REF_DOC
      !IV_JXLXT type ZTR2_JXLXT optional
    exceptions
      ERR .
  class-methods UNAGN_REF_DRAFT
    importing
      !IV_LOCK type BOOLEAN default ABAP_TRUE
      !IV_COMMIT type BOOLEAN default ABAP_TRUE
      !IV_GROUP type ZBK_GRPAC
      !IV_DOC type ZBK_REF_DOC
      !IT_DRAFT type ZTRT0050_BKTRNS_T
    exceptions
      ERR .
  class-methods UNMAPPING_BY_REF
    importing
      !IV_GROUP type ZBK_GRPAC
      !IV_DOC type ZBK_REF_DOC
      !IV_LOCK type BOOLEAN default ABAP_TRUE
      !IV_COMMIT type BOOLEAN default ABAP_TRUE
    exceptions
      ERR .
  class-methods GET_BY_REF1
    importing
      !IV_DOC type ZBK_REF_DOC
      !IV_LOCK type BOOLEAN optional
    exporting
      !ET_BANK3 type ZTRTT_3023_02_CF
      !ET_FI_DOC type ZTRTT3023_03
      !ET_BANK1 type ZTRT_BANK_TRANS_TAB
      !ET_BANK2 type ZTRT_BANK_ITEM
      !ET_BANK type ZTRT_BANK_ITEM
    exceptions
      ERR .
  class-methods GET_BY_REF
    importing
      !IV_GROUP type ZBK_GRPAC
      !IV_DOC type ZBK_REF_DOC
      !IV_LOCK type BOOLEAN optional
    exporting
      !ET_FI_DOC type ZTRTT3023_03
      !ET_BANK1 type ZTRT_BANK_TRANS_TAB
      !ET_BANK2 type ZTRT_BANK_ITEM
      !ET_BANK type ZTRT_BANK_ITEM
      !ET_BANK3 type ZTRTT_3023_02_CF
    exceptions
      ERR .
  class-methods GET_BY_REF_TR2
    importing
      !IV_GROUP type ZBK_GRPAC
      !IV_DOC type ZBK_REF_DOC
      !IV_LOCK type BOOLEAN optional
      !IV_JXLXT type ZTR2_JXLXT optional
    exporting
      !ET_FI_DOC type ZTRTT3023_03
      !ET_BANK1 type ZTRT_BANK_TRANS_TAB
      !ET_BANK2 type ZTRT_BANK_ITEM
      !ET_BANK type ZTRT_BANK_ITEM
    exceptions
      ERR .
  class-methods QUREY_21
    importing
      !IV_GROUP type ZBK_GRPAC default '21'
      !IV_LOCK type BOOLEAN default ABAP_TRUE
      !IV_BUKRS type BUKRS
      !IV_HBKID type HBKID
      !IV_HKTID type HKTID
      !IV_SHKZG type SHKZG default 'S'
      !IV_ZPPZT type ZBK_PPZT default SPACE
      value(IV_ZZ) type BOOLEAN default SPACE
    exporting
      !ET_BANK1 type ZTRT_BANK_TRANS_TAB
      !ET_BANK2 type ZTRT_BANK_ITEM
      !ET_BANK type ZTRT_BANK_ITEM
      !ET_BANK3 type ZTRTT_3023_02_CF
    exceptions
      ERR .
  class-methods QUREY_22
    importing
      !IV_GROUP type ZBK_GRPAC default '22'
      !IV_LOCK type BOOLEAN optional
      !IV_BUKRS type BUKRS
      !IV_LIFNR type LIFNR optional
      !IV_KUNNR type KUNNR optional
      !IV_HBKID type HBKID optional
      !IV_HKTID type HKTID optional
      !IV_SHKZG type SHKZG optional
      !IV_ZPPZT type ZBK_PPZT default SPACE
      !IV_ZZ type BOOLEAN default SPACE
    exporting
      !ET_BANK1 type ZTRT_BANK_TRANS_TAB
      !ET_BANK2 type ZTRT_BANK_ITEM
      !ET_BANK type ZTRT_BANK_ITEM
      !ET_BANK3 type ZTRTT_3023_02_CF
    exceptions
      ERR .
  class-methods QUREY_23
    importing
      !IV_GROUP type ZBK_GRPAC default '23'
      !IV_LOCK type BOOLEAN optional
      !IV_BUKRS type BUKRS
      !IV_KUNNR type KUNNR optional
      !IV_HBKID type HBKID optional
      !IV_HKTID type HKTID optional
      !IV_SHKZG type SHKZG optional
      !IV_ZPPZT type ZBK_PPZT default SPACE
      !IV_ZZ type BOOLEAN default SPACE
    exporting
      !ET_BANK1 type ZTRT_BANK_TRANS_TAB
      !ET_BANK2 type ZTRT_BANK_ITEM
      !ET_BANK3 type ZTRTT_3023_02_CF
      !ET_BANK type ZTRT_BANK_ITEM
    exceptions
      ERR .
  class-methods QUREY_24
    importing
      !IV_GROUP type ZBK_GRPAC default '24'
      !IV_LOCK type BOOLEAN optional
      !IV_BUKRS type BUKRS
      !IV_KUNNR type KUNNR optional
      !IV_LIFNR type LIFNR optional
      !IV_ZPPZT type ZBK_PPZT default SPACE
      !IV_ZZ type BOOLEAN default SPACE
    exporting
      !ET_BANK1 type ZTRT_BANK_TRANS_TAB
      !ET_BANK2 type ZTRT_BANK_ITEM
      !ET_BANK3 type ZTRTT_3023_02_CF
      !ET_BANK type ZTRT_BANK_ITEM
    exceptions
      ERR .
  class-methods QUREY_25
    importing
      !IV_GROUP type ZBK_GRPAC default '25'
      !IV_LOCK type BOOLEAN optional
      !IV_BUKRS type BUKRS
      !IV_ZPPZT type ZBK_PPZT default SPACE
      !IV_ZZ type BOOLEAN default SPACE
    exporting
      !ET_BANK1 type ZTRT_BANK_TRANS_TAB
      !ET_BANK2 type ZTRT_BANK_ITEM
      !ET_BANK3 type ZTRTT_3023_02_CF
      !ET_BANK type ZTRT_BANK_ITEM
    exceptions
      ERR .
  class-methods QUERY_ZZ
    importing
      !IV_LOCK type BOOLEAN default ABAP_TRUE
      !IV_BUKRS type BUKRS
      !IV_ZPPZT type ZBK_PPZT default SPACE
    exporting
      !ET_BANK1 type ZTRT_BANK_TRANS_TAB
      !ET_BANK2 type ZTRT_BANK_ITEM
      !ET_BANK type ZTRT_BANK_ITEM
      !ET_BANK3 type ZTRTT_3023_02_CF
    exceptions
      ERR .
  class-methods QUREY_31
    importing
      !IV_GROUP type ZBK_GRPAC default '31'
      !IV_LOCK type BOOLEAN default ABAP_TRUE
      !IV_BUKRS type BUKRS
      !IV_HBKID type HBKID
      !IV_HKTID type HKTID
      !IV_SHKZG type SHKZG default 'S'
      !IV_ZPPZT type ZBK_PPZT default SPACE
      value(IV_ZZ) type BOOLEAN default SPACE
    exporting
      !ET_BANK1 type ZTRT_BANK_TRANS_TAB
      !ET_BANK2 type ZTRT_BANK_ITEM
      !ET_BANK3 type ZTRTT_3023_02_CF
      !ET_BANK type ZTRT_BANK_ITEM
    exceptions
      ERR .
  class-methods QUREY_32
    importing
      !IV_GROUP type ZBK_GRPAC default '32'
      !IV_LOCK type BOOLEAN default ABAP_TRUE
      !IV_BUKRS type BUKRS
      !IV_LIFNR type LIFNR optional
      !IV_HBKID type HBKID optional
      !IV_HKTID type HKTID optional
      !IV_SHKZG type SHKZG optional
      !IV_ZPPZT type ZBK_PPZT default SPACE
      !IV_ZZ type BOOLEAN default SPACE
    exporting
      !ET_BANK1 type ZTRT_BANK_TRANS_TAB
      !ET_BANK2 type ZTRT_BANK_ITEM
      !ET_BANK3 type ZTRTT_3023_02_CF
      !ET_BANK type ZTRT_BANK_ITEM
    exceptions
      ERR .
  class-methods QUREY_33
    importing
      !IV_GROUP type ZBK_GRPAC default '33'
      !IV_LOCK type BOOLEAN default ABAP_TRUE
      !IV_BUKRS type BUKRS
      !IV_KUNNR type KUNNR optional
      !IV_HBKID type HBKID optional
      !IV_HKTID type HKTID optional
      !IV_SHKZG type SHKZG optional
      !IV_ZPPZT type ZBK_PPZT default SPACE
      !IV_ZZ type BOOLEAN default SPACE
    exporting
      !ET_BANK1 type ZTRT_BANK_TRANS_TAB
      !ET_BANK2 type ZTRT_BANK_ITEM
      !ET_BANK3 type ZTRTT_3023_02_CF
      !ET_BANK type ZTRT_BANK_ITEM
    exceptions
      ERR .
  class-methods QUERY_34
    importing
      !IV_GROUP type ZBK_GRPAC default '34'
      !IV_LOCK type BOOLEAN default ABAP_TRUE
      !IV_BUKRS type BUKRS
      !IV_HBKID type HBKID optional
      !IV_HKTID type HKTID optional
      !IV_ZPPZT type ZBK_PPZT default SPACE
      !IV_SHKZG type SHKZG optional
    exporting
      !ET_BANK1 type ZTRT_BANK_TRANS_TAB
      !ET_BANK2 type ZTRT_BANK_ITEM
      !ET_BANK3 type ZTRTT_3023_02_CF
      !ET_BANK type ZTRT_BANK_ITEM
    exceptions
      ERR .
  class-methods QUREY_35
    importing
      !IV_GROUP type ZBK_GRPAC default '35'
      !IV_LOCK type BOOLEAN default ABAP_TRUE
      !IV_BUKRS type BUKRS
      !IV_LIFNR type LIFNR optional
      !IV_HBKID type HBKID optional
      !IV_HKTID type HKTID optional
      !IV_ZBKFSE type ZTR_BKFSE optional
      !IV_ZPPZT type ZBK_PPZT default SPACE
      !IV_ZZ type BOOLEAN default SPACE
    exporting
      !ET_BANK1 type ZTRT_BANK_TRANS_TAB
      !ET_BANK2 type ZTRT_BANK_ITEM
      !ET_BANK3 type ZTRTT_3023_02_CF
      !ET_BANK type ZTRT_BANK_ITEM
    exceptions
      ERR .
  class-methods CHANG_ITEM
    changing
      !IT_ITEM type ZTRT_BANK_TRANS_TAB .
  class-methods QUREY_26
    importing
      !IV_GROUP type ZBK_GRPAC default '26'
      !IV_LOCK type BOOLEAN default ABAP_TRUE
      !IV_BUKRS type BUKRS
      !IV_HBKID type HBKID
      !IV_HKTID type HKTID
      !IV_SHKZG type SHKZG default 'S'
      !IV_ZPPZT type ZBK_PPZT default SPACE
      value(IV_ZZ) type BOOLEAN default SPACE
    exporting
      !ET_BANK1 type ZTRT_BANK_TRANS_TAB
      !ET_BANK2 type ZTRT_BANK_ITEM
      !ET_BANK3 type ZTRTT_3023_02_CF
      !ET_BANK type ZTRT_BANK_ITEM
    exceptions
      ERR .
  class-methods QUREY_27
    importing
      !IV_GROUP type ZBK_GRPAC default '27'
      !IV_LOCK type BOOLEAN default ABAP_TRUE
      !IV_BUKRS type BUKRS
      !IV_HBKID type HBKID
      !IV_HKTID type HKTID
      !IV_SHKZG type SHKZG default 'S'
      !IV_ZPPZT type ZBK_PPZT default SPACE
      value(IV_ZZ) type BOOLEAN default SPACE
    exporting
      !ET_BANK1 type ZTRT_BANK_TRANS_TAB
      !ET_BANK2 type ZTRT_BANK_ITEM
      !ET_BANK3 type ZTRTT_3023_02_CF
      !ET_BANK type ZTRT_BANK_ITEM
    exceptions
      ERR .
  class-methods QUREY_40
    importing
      !IV_GROUP type ZBK_GRPAC default '40'
      !IV_LOCK type BOOLEAN default ABAP_TRUE
      !IV_BUKRS type BUKRS
      !IV_HBKID type HBKID
      !IV_HKTID type HKTID
      !IV_SHKZG type SHKZG optional
      !IV_ZPPZT type ZBK_PPZT default SPACE
      value(IV_ZZ) type BOOLEAN default SPACE
    exporting
      !ET_BANK1 type ZTRT_BANK_TRANS_TAB
      !ET_BANK2 type ZTRT_BANK_ITEM
      !ET_BANK3 type ZTRTT_3023_02_CF
      !ET_BANK type ZTRT_BANK_ITEM
    exceptions
      ERR .
  class-methods QUREY_41
    importing
      !IV_GROUP type ZBK_GRPAC default '41'
      !IV_LOCK type BOOLEAN default ABAP_TRUE
      !IV_BUKRS type BUKRS
      !IV_HBKID type HBKID
      !IV_HKTID type HKTID
      !IV_SHKZG type SHKZG optional
      !IV_ZPPZT type ZBK_PPZT default SPACE
      value(IV_ZZ) type BOOLEAN default SPACE
    exporting
      !ET_BANK1 type ZTRT_BANK_TRANS_TAB
      !ET_BANK2 type ZTRT_BANK_ITEM
      !ET_BANK3 type ZTRTT_3023_02_CF
      !ET_BANK type ZTRT_BANK_ITEM
    exceptions
      ERR .
  class-methods QUREY_42
    importing
      !IV_GROUP type ZBK_GRPAC default '42'
      !IV_LOCK type BOOLEAN default ABAP_TRUE
      !IV_BUKRS type BUKRS
      !IV_HBKID type HBKID
      !IV_HKTID type HKTID
      !IV_SHKZG type SHKZG optional
      !IV_ZPPZT type ZBK_PPZT default SPACE
      value(IV_ZZ) type BOOLEAN default SPACE
    exporting
      !ET_BANK1 type ZTRT_BANK_TRANS_TAB
      !ET_BANK2 type ZTRT_BANK_ITEM
      !ET_BANK3 type ZTRTT_3023_02_CF
      !ET_BANK type ZTRT_BANK_ITEM
    exceptions
      ERR .
  class-methods QUREY_28
    importing
      !IV_GROUP type ZBK_GRPAC default '28'
      !IV_LOCK type BOOLEAN optional
      !IV_BUKRS type BUKRS
      !IV_LIFNR type LIFNR optional
      !IV_KUNNR type KUNNR optional
      !IV_HBKID type HBKID optional
      !IV_HKTID type HKTID optional
      !IV_SHKZG type SHKZG optional
      !IV_ZPPZT type ZBK_PPZT default SPACE
      !IV_ZZ type BOOLEAN default SPACE
    exporting
      !ET_BANK1 type ZTRT_BANK_TRANS_TAB
      !ET_BANK2 type ZTRT_BANK_ITEM
      !ET_BANK3 type ZTRTT_3023_02_CF
      !ET_BANK type ZTRT_BANK_ITEM
    exceptions
      ERR .
  class-methods QUREY_36
    importing
      !IV_GROUP type ZBK_GRPAC default '36'
      !IV_LOCK type BOOLEAN default ABAP_TRUE
      !IV_BUKRS type BUKRS
      !IV_HBKID type HBKID
      !IV_HKTID type HKTID
      !IV_SHKZG type SHKZG default 'S'
      !IV_ZPPZT type ZBK_PPZT default SPACE
      value(IV_ZZ) type BOOLEAN default SPACE
    exporting
      !ET_BANK1 type ZTRT_BANK_TRANS_TAB
      !ET_BANK2 type ZTRT_BANK_ITEM
      !ET_BANK3 type ZTRTT_3023_02_CF
      !ET_BANK type ZTRT_BANK_ITEM
    exceptions
      ERR .
  class-methods GET_REF2_BY_REF
    importing
      !IV_GROUP type ZBK_GRPAC
      !IV_DOC type ZBK_REF_DOC
    changing
      !ET_BANK_DRAFT type ZTRS_BANK_INFO_TAB optional
    returning
      value(ET_SET_INPUT) type ZTRT0050_BKTRNS_T .
  class-methods SET_REF2_BY_REF
    importing
      !IV_GROUP type ZBK_GRPAC
      !IV_DOC type ZBK_REF_DOC
      !IV_COMMIT type BOOLEAN default 'X'
      !IV_DEL type BOOLEAN optional
    changing
      !ET_BANK_DRAFT type ZTRT0050_BKTRNS_T optional .
  class-methods QUREY_43
    importing
      !IV_GROUP type ZBK_GRPAC default '41'
      !IV_LOCK type BOOLEAN default ABAP_TRUE
      !IV_BUKRS type BUKRS
      !IV_HBKID type HBKID
      !IV_HKTID type HKTID
      !IV_SHKZG type SHKZG optional
      !IV_ZPPZT type ZBK_PPZT default SPACE
      value(IV_ZZ) type BOOLEAN default SPACE
    exporting
      !ET_BANK1 type ZTRT_BANK_TRANS_TAB
      !ET_BANK2 type ZTRT_BANK_ITEM
      !ET_BANK3 type ZTRTT_3023_02_CF
      !ET_BANK type ZTRT_BANK_ITEM
    exceptions
      ERR .
  class-methods QUREY_44
    importing
      !IV_GROUP type ZBK_GRPAC default '41'
      !IV_LOCK type BOOLEAN default ABAP_TRUE
      !IV_BUKRS type BUKRS
      !IV_HBKID type HBKID
      !IV_HKTID type HKTID
      !IV_SHKZG type SHKZG optional
      !IV_ZPPZT type ZBK_PPZT default SPACE
      value(IV_ZZ) type BOOLEAN default SPACE
    exporting
      !ET_BANK1 type ZTRT_BANK_TRANS_TAB
      !ET_BANK2 type ZTRT_BANK_ITEM
      !ET_BANK3 type ZTRTT_3023_02_CF
      !ET_BANK type ZTRT_BANK_ITEM
    exceptions
      ERR .
  class-methods QUREY_45
    importing
      !IV_GROUP type ZBK_GRPAC default '41'
      !IV_LOCK type BOOLEAN default ABAP_TRUE
      !IV_BUKRS type BUKRS
      !IV_HBKID type HBKID
      !IV_HKTID type HKTID
      !IV_SHKZG type SHKZG optional
      !IV_ZPPZT type ZBK_PPZT default SPACE
      value(IV_ZZ) type BOOLEAN default SPACE
    exporting
      !ET_BANK1 type ZTRT_BANK_TRANS_TAB
      !ET_BANK2 type ZTRT_BANK_ITEM
      !ET_BANK3 type ZTRTT_3023_02_CF
      !ET_BANK type ZTRT_BANK_ITEM
    exceptions
      ERR .
  class-methods GET_BANKFLOW_ZSJLY
    importing
      !IS_REF type ZTRS_3028_AGNREF
    exporting
      !ZSJLY type ZBK_SJLY_C
      !MSG type BAPIRET2 .
PROTECTED SECTION.
private section.
ENDCLASS.



CLASS ZCL_TR_3024_GUI IMPLEMENTATION.


METHOD agn_ref.

    DATA :
      lt_ref_3 TYPE ztrt_3028_agnref,
      lt_ref_2 TYPE ztrt_3028_agnref,
      lt_ref_1 TYPE ztrt_3028_agnref.
    DATA lt_03 TYPE TABLE OF ztrt3023_03 .
    DATA: zsjly TYPE zbk_sjly_c,
          msg   TYPE bapiret2.

*********step 1 : lock table*********************************************************************
    LOOP AT it_ref INTO DATA(ls_ref) .
      "判断银行流水来源
*      DATA: lo_zsjly_check TYPE REF TO zcl_tr_post_check.
*      CREATE OBJECT lo_zsjly_check.
      get_bankflow_zsjly( EXPORTING is_ref = ls_ref IMPORTING zsjly = zsjly msg = msg ).

*     拆分流水的
*      IF ls_ref-db_key IS NOT  INITIAL   AND    ls_ref-split_flag = 'Y'   .
      IF zsjly = '3'.
        APPEND ls_ref TO lt_ref_3.
        CALL METHOD zcl_tr_3024_gui=>lock_3
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
          WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
        CONTINUE.
      ENDIF.

*      "网银上载 的
*      IF     ls_ref-db_key IS NOT INITIAL    .
      IF zsjly = '1'.
        APPEND ls_ref TO lt_ref_2 .
*        IF iv_lock = abap_true .
        CALL METHOD zcl_tr_3024_gui=>lock_2
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
        CONTINUE.
      ENDIF.
*  银企直联的
*      IF    ls_ref-zbkitem IS NOT INITIAL OR ls_ref-trxno IS NOT INITIAL  .
      IF zsjly = '2'.
        IF ls_ref-trxno IS INITIAL .
          ls_ref-trxno = ls_ref-zbkitem .
        ENDIF.
        APPEND ls_ref TO lt_ref_1.

*        IF iv_lock = abap_true .
        CALL METHOD zcl_tr_3024_gui=>lock_1
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
        CONTINUE.
      ENDIF.

    ENDLOOP.


******* step 2:  check************************************************************************
    IF NOT lt_ref_1 IS INITIAL    .
      SELECT * FROM ztrt_bank_trans INTO TABLE @DATA(lt_01) FOR ALL ENTRIES IN @lt_ref_1
       WHERE bukrs = @lt_ref_1-bukrs
         AND hbkid = @lt_ref_1-hbkid
         AND hktid = @lt_ref_1-hktid
         AND yhzh  = @lt_ref_1-yhzh
         AND trxno = @lt_ref_1-trxno
****2020.4.28 更改判断关联了其他单据才保存，如果是本身则不校验
          AND  zgroup_ac <> @iv_group
          AND zref_doc NE @lt_ref_1-zref_doc .
****2020.4.28 更改判断关联了其他单据才保存，如果是本身则不校验 .

      LOOP AT lt_01 INTO DATA(ls_01) WHERE zgroup_ac <> iv_group OR zref_doc IS NOT INITIAL .
        MESSAGE e463(ztr01) WITH ls_01-trxno RAISING err.
      ENDLOOP.
    ENDIF .

    IF NOT lt_ref_2 IS INITIAL    .
      SELECT * FROM ztrt3023_02 INTO TABLE @DATA(lt_02) FOR ALL ENTRIES IN @lt_ref_2
            WHERE db_key = @lt_ref_2-db_key
            AND dflag  = @space
****2020.4.28 更改判断关联了其他单据才保存，如果是本身则不校验
            AND  zgroup_ac <> @iv_group
            AND zref_doc NE @lt_ref_2-zref_doc .
****2020.4.28 更改判断关联了其他单据才保存，如果是本身则不校验

      LOOP AT lt_02 INTO DATA(ls_02) WHERE zgroup_ac <> iv_group OR zref_doc IS NOT INITIAL .
        MESSAGE e463(ztr01) WITH ls_02-zbkitem RAISING err.
      ENDLOOP.
    ENDIF .

    IF NOT lt_ref_3 IS INITIAL    .
      SELECT * FROM ztrt3023_02_cf INTO TABLE @DATA(lt_cf) FOR ALL ENTRIES IN @lt_ref_3
            WHERE db_key = @lt_ref_3-db_key
            AND  zgroup_ac <> @iv_group
            AND zref_doc NE @lt_ref_3-zref_doc .
      LOOP AT lt_cf INTO DATA(ls_03) WHERE zgroup_ac <> iv_group OR zref_doc IS NOT INITIAL .
        MESSAGE e463(ztr01) WITH ls_03-zbkitem RAISING err.
      ENDLOOP.
    ENDIF .
*  step 3 modify table*********************************************************************
    IF NOT lt_ref_1 IS INITIAL  .
      LOOP AT lt_ref_1 INTO ls_ref .
                                                            "20200813
        READ TABLE gt_btrans INTO DATA(ls_bk) WITH   KEY  bukrs  = ls_ref-bukrs
                                                           hbkid  = ls_ref-hbkid
                                                            hktid  = ls_ref-hktid
                                                            yhzh   = ls_ref-yhzh
                                                           trxno  = ls_ref-trxno.
        IF sy-subrc <> 0.
          CLEAR ls_bk.
          UPDATE ztrt_bank_trans SET   zgroup_ac = iv_group
                                      zref_doc = ls_ref-zref_doc
                                      WHERE bukrs  = ls_ref-bukrs
                                      AND hbkid  = ls_ref-hbkid
                                      AND hktid  = ls_ref-hktid
                                      AND yhzh   = ls_ref-yhzh
                                      AND trxno  = ls_ref-trxno .
        ELSE.
          UPDATE ztrt_bank_trans SET
                                  zppzt = ls_bk-zppzt
                                  zppqj = ls_bk-zppqj
                                  zgroup_ac = iv_group
                                  zref_doc = ls_ref-zref_doc
                            WHERE bukrs  = ls_ref-bukrs
                              AND hbkid  = ls_ref-hbkid
                              AND hktid  = ls_ref-hktid
                              AND yhzh   = ls_ref-yhzh
                              AND trxno  = ls_ref-trxno .
        ENDIF.
        IF sy-subrc <> 0 .
          ROLLBACK WORK  .
          MESSAGE e340(ztr05)  RAISING err.
        ENDIF.
      ENDLOOP.
    ENDIF.
    IF NOT lt_ref_2 IS INITIAL  .
      LOOP AT lt_ref_2 INTO ls_ref .
        "可能前面已做取消匹配操作后的重新关联，匹配期间已被UpDATE 但尚未更新20200813
        READ TABLE gt_pp_02 INTO DATA(gs_pp) WITH  KEY db_key = ls_ref-db_key .
        IF sy-subrc <> 0.
          CLEAR gs_pp.
          UPDATE  ztrt3023_02 SET    zgroup_ac = iv_group
                                    zref_doc = ls_ref-zref_doc
                                    iaedat  = sy-datum
                                    iaezet  = sy-uzeit
                                    iaenam = sy-uname
                                    itcode = sy-tcode
                                    WHERE db_key = ls_ref-db_key .
        ELSE.
          UPDATE  ztrt3023_02 SET zppzt = gs_pp-zppzt
          zppqj = gs_pp-zppqj
          zgroup_ac = iv_group
          zref_doc = ls_ref-zref_doc
          iaedat  = sy-datum
          iaezet  = sy-uzeit
          iaenam = sy-uname
          itcode = sy-tcode
          WHERE db_key = ls_ref-db_key .
        ENDIF.
        IF sy-subrc <> 0 .
          ROLLBACK WORK  .
          MESSAGE e340(ztr05)  RAISING err.
        ENDIF.
      ENDLOOP.
    ENDIF.
    IF NOT lt_ref_3 IS INITIAL  .
      LOOP AT lt_ref_3 INTO ls_ref .
        "可能前面已做取消匹配操作后的重新关联，匹配期间已被UpDATE 但尚未更新20200813
        READ TABLE gt_pp_02_cf INTO  DATA(gs_pp_cf)  WITH  KEY db_key = ls_ref-db_key .
        IF sy-subrc <> 0.
          CLEAR gs_pp_cf.
          UPDATE  ztrt3023_02_cf SET   zgroup_ac = iv_group
                                       zref_doc = ls_ref-zref_doc
                                       iaedat  = sy-datum
                                       iaezet  = sy-uzeit
                                       iaenam = sy-uname
                                       itcode = sy-tcode
          WHERE db_key = ls_ref-db_key .
        ELSE.
          UPDATE  ztrt3023_02_cf SET zppzt = gs_pp_cf-zppzt
                                       zppqj = gs_pp_cf-zppqj
                                       zgroup_ac = iv_group
                                       zref_doc = ls_ref-zref_doc
                                       iaedat  = sy-datum
                                       iaezet  = sy-uzeit
                                       iaenam = sy-uname
                                       itcode = sy-tcode
            WHERE db_key = ls_ref-db_key .
        ENDIF.
        IF sy-subrc <> 0 .
          ROLLBACK WORK  .
          MESSAGE e340(ztr05)  RAISING err.
        ENDIF.
      ENDLOOP.
    ENDIF.
* 20200813 重新对账取消前的已对账的
    IF gt_btrans IS NOT INITIAL OR gt_pp_02 IS NOT INITIAL OR gt_pp_02_cf IS NOT INITIAL.
      SELECT * FROM ztrt3023_03_log INTO CORRESPONDING FIELDS OF TABLE lt_03
        FOR ALL ENTRIES IN it_ref
        WHERE   zgroup_ac = iv_group
         AND   zref_doc = it_ref-zref_doc
         AND dflag = ''
        ."AND action = 'P'.
      MODIFY ztrt3023_03 FROM TABLE lt_03.
    ENDIF.

    IF iv_commit = abap_true .
      COMMIT WORK AND WAIT .
    ENDIF.

    CLEAR gt_pp_02.
    CLEAR gt_btrans.
*    IF iv_lock = abap_true .
    LOOP AT it_ref INTO ls_ref .
      IF ls_ref-db_key IS NOT INITIAL.
        CALL METHOD zcl_tr_3024_gui=>unlock_2
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
        ENDIF.
      ELSE.

        CALL METHOD zcl_tr_3024_gui=>unlock_1
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
        ENDIF.

      ENDIF.

    ENDLOOP.
*    ENDIF.

  ENDMETHOD.


METHOD agn_ref_tr2.
*
*    DATA : lt_ref_2 TYPE ztrt_3028_agnref,
*           lt_ref_1 TYPE ztrt_3028_agnref.
*    DATA lt_03 TYPE TABLE OF ztrt3023_03.
*
*    LOOP AT it_ref INTO DATA(ls_ref) .
*      IF ls_ref-db_key IS NOT INITIAL.
*        APPEND ls_ref TO lt_ref_2 .
**        IF iv_lock = abap_true .
*        CALL METHOD zcl_tr_3024_gui=>lock_2
*          EXPORTING
*            iv_trans = ls_ref
*          EXCEPTIONS
*            err      = 1
*            OTHERS   = 2.
*        IF sy-subrc <> 0.
*          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
*            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
*        ENDIF.
**        ENDIF.
*      ELSE.
*        IF ls_ref-trxno IS INITIAL . ls_ref-trxno = ls_ref-zbkitem . ENDIF.
*        APPEND ls_ref TO lt_ref_1.
**        IF iv_lock = abap_true .
*        CALL METHOD zcl_tr_3024_gui=>lock_1
*          EXPORTING
*            iv_trans = ls_ref
*          EXCEPTIONS
*            err      = 1
*            OTHERS   = 2.
*        IF sy-subrc <> 0.
*          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
*            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
*        ENDIF.
**        ENDIF.
*      ENDIF.
*    ENDLOOP.
*
*
**   check
*    IF NOT lt_ref_2 IS INITIAL    .
*      SELECT * FROM ztrt3023_02 INTO TABLE @DATA(lt_02) FOR ALL ENTRIES IN @lt_ref_2
*       WHERE db_key = @lt_ref_2-db_key
*         AND dflag  = @space
*****2020.4.28 更改判断关联了其他单据才保存，如果是本身则不校验
*          AND  zgroup_ac <> @iv_group
*          AND zref_doc NE @lt_ref_2-zref_doc .
*****2020.4.28 更改判断关联了其他单据才保存，如果是本身则不校验
*
*      LOOP AT lt_02 INTO DATA(ls_02) WHERE zgroup_ac <> iv_group OR zref_doc IS NOT INITIAL .
*        MESSAGE e463(ztr01) WITH ls_02-zbkitem RAISING err.
*      ENDLOOP.
*
*    ENDIF .
*
*    IF NOT lt_ref_1 IS INITIAL    .
*      SELECT * FROM ztrt_bank_trans INTO TABLE @DATA(lt_01) FOR ALL ENTRIES IN @lt_ref_1
*       WHERE bukrs = @lt_ref_1-bukrs
*         AND hbkid = @lt_ref_1-hbkid
*         AND hktid = @lt_ref_1-hktid
*         AND yhzh  = @lt_ref_1-yhzh
*         AND trxno = @lt_ref_1-trxno
*****2020.4.28 更改判断关联了其他单据才保存，如果是本身则不校验
*          AND  zgroup_ac <> @iv_group
*          AND zref_doc NE @lt_ref_1-zref_doc .
*****2020.4.28 更改判断关联了其他单据才保存，如果是本身则不校验 .
*
*      LOOP AT lt_01 INTO DATA(ls_01) WHERE zgroup_ac <> iv_group OR zref_doc IS NOT INITIAL .
*        MESSAGE e463(ztr01) WITH ls_01-trxno RAISING err.
*      ENDLOOP.
*    ENDIF .
*
**   modify table
*    IF NOT lt_ref_2 IS INITIAL  .
*      LOOP AT lt_ref_2 INTO ls_ref .
*        "可能前面已做取消匹配操作后的重新关联，匹配期间已被UpDATE 但尚未更新20200813
*        READ TABLE gt_pp_02 INTO DATA(gs_pp) WITH  KEY db_key = ls_ref-db_key .
*        IF sy-subrc <> 0.
*          CLEAR gs_pp.
*        ENDIF.
*        UPDATE  ztrt3023_02 SET zppzt = gs_pp-zppzt
*                                zppqj = gs_pp-zppqj
*                                  zgroup_ac = iv_group
*                                  zref_doc = ls_ref-zref_doc
*                                  iaedat  = sy-datum
*                                  iaezet  = sy-uzeit
*                                  iaenam = sy-uname
*                                  itcode = sy-tcode
*                            WHERE db_key = ls_ref-db_key .
*
*        IF sy-subrc <> 0 .
*          ROLLBACK WORK  .
*          MESSAGE e109(ztr01)  RAISING err.
*        ENDIF.
*      ENDLOOP.
*    ENDIF.
*
*    IF NOT lt_ref_1 IS INITIAL  .
*      LOOP AT lt_ref_1 INTO ls_ref .
*                                                            "20200813
*        READ TABLE gt_btrans INTO DATA(ls_bk) WITH   KEY  bukrs  = ls_ref-bukrs
*                                                           hbkid  = ls_ref-hbkid
*                                                            hktid  = ls_ref-hktid
*                                                            yhzh   = ls_ref-yhzh
*                                                           trxno  = ls_ref-trxno.
*        IF sy-subrc <> 0.
*          CLEAR ls_bk.
*        ENDIF.
*        UPDATE ztrt_bank_trans SET
*                                zppzt = ls_bk-zppzt
*                                zppqj = ls_bk-zppqj
*                                zgroup_ac = iv_group
*                                zref_doc = ls_ref-zref_doc
*                          WHERE bukrs  = ls_ref-bukrs
*                            AND hbkid  = ls_ref-hbkid
*                            AND hktid  = ls_ref-hktid
*                            AND yhzh   = ls_ref-yhzh
*                            AND trxno  = ls_ref-trxno .
*        IF sy-subrc <> 0 .
*          ROLLBACK WORK  .
*          MESSAGE e109(ztr01)  RAISING err.
*        ENDIF.
*      ENDLOOP.
*    ENDIF.
** 20200813 重新对账取消前的已对账的
*    IF gt_btrans IS NOT INITIAL OR gt_pp_02 IS NOT INITIAL.
*      SELECT * FROM ztrt3023_03_log INTO CORRESPONDING FIELDS OF TABLE lt_03
*        FOR ALL ENTRIES IN it_ref
*        WHERE   zgroup_ac = iv_group
*         AND   zref_doc = it_ref-zref_doc
*         AND dflag = '' ."AND action = 'P'.
*      MODIFY ztrt3023_03 FROM TABLE lt_03.
*    ENDIF.
*
*    IF iv_commit = abap_true .
*      COMMIT WORK AND WAIT .
*    ENDIF.
*
*    CLEAR gt_pp_02.
*    CLEAR gt_btrans.
**    IF iv_lock = abap_true .
*    LOOP AT it_ref INTO ls_ref .
*      IF ls_ref-db_key IS NOT INITIAL.
*        CALL METHOD zcl_tr_3024_gui=>unlock_2
*          EXPORTING
*            iv_trans = ls_ref
*          EXCEPTIONS
*            err      = 1
*            OTHERS   = 2.
*        IF sy-subrc <> 0.
*        ENDIF.
*      ELSE.
*
*        CALL METHOD zcl_tr_3024_gui=>unlock_1
*          EXPORTING
*            iv_trans = ls_ref
*          EXCEPTIONS
*            err      = 1
*            OTHERS   = 2.
*        IF sy-subrc <> 0.
*        ENDIF.
*
*      ENDIF.
*
*    ENDLOOP.
**    ENDIF.
*
*    "自建表
*    CHECK iv_commit = abap_true.
*    DATA: lt_1058 TYPE STANDARD TABLE OF ztr2t1058,
*          ls_1058 TYPE ztr2t1058.
*
*    LOOP AT it_ref INTO ls_ref .
*      MOVE-CORRESPONDING ls_ref TO ls_1058.
*      ls_1058-zgroup_ac = iv_group.
*      ls_1058-jxlxt = iv_jxlxt.
*      APPEND ls_1058 TO lt_1058.
*      CLEAR: ls_1058.
*    ENDLOOP.
*
*    "更新自建表
*    IF lt_1058[] IS NOT INITIAL.
*      MODIFY ztr2t1058 FROM TABLE lt_1058.
*      COMMIT WORK.
*    ENDIF.
  ENDMETHOD.


METHOD chang_item.
    DATA lv_docno TYPE ztr_zfdocno.
    DATA lv_get  TYPE char1.
    DATA ls_2006 TYPE ztrt2006.
    DATA lt_2006 TYPE STANDARD TABLE OF ztrt2006.
    DATA lv_item TYPE i.
    LOOP AT it_item ASSIGNING FIELD-SYMBOL(<fs_item>) WHERE shkzg = 'H' AND zref_doc IS NOT INITIAL .
*       <FS_ITEM>-ZGROUP  = <FS_ITEM>-ZGROUP_AC  = ?
*=================支付单：判断银行流水分组==========
      CLEAR lv_get.
      "保证金
      SELECT SINGLE docno INTO lv_docno FROM ztrt2101
        WHERE docno = <fs_item>-zref_doc.
      IF sy-subrc = 0 .
        lv_get = abap_true.
        <fs_item>-zgroup  = <fs_item>-zgroup_ac = '31'.
      ENDIF.

      "其他支付单
      IF lv_get IS INITIAL.
        SELECT SINGLE zzftype,zywtype,zfmark INTO @DATA(ls_zfd) FROM ztrt2001
          WHERE docno = @<fs_item>-zref_doc.
        IF sy-subrc = 0.
          lv_get = abap_true.
          IF ls_zfd-zzftype = 'T005' OR ls_zfd-zzftype = 'T006'
             OR ls_zfd-zzftype = 'T004' OR ls_zfd-zywtype = '33'."同户名划转-购汇-结汇-现金取款
            <fs_item>-zgroup  = <fs_item>-zgroup_ac = '34'.
          ELSE.
            IF ls_zfd-zzftype = 'P002'."银行相关
              CASE ls_zfd-zfmark.
                WHEN '10'."客户
                  <fs_item>-zgroup  = <fs_item>-zgroup_ac = '33'.
                WHEN '20'."供应商
                  <fs_item>-zgroup  = <fs_item>-zgroup_ac = '32'.
                WHEN OTHERS.
              ENDCASE.
            ENDIF.
          ENDIF.
        ENDIF.
      ENDIF.

      IF lv_get IS NOT INITIAL.
        ls_2006-docno = <fs_item>-zref_doc.
*&BEGIN-------------------------------------------------------------
*&CHANGE TEXT
*&CHANGE DATE: 20.10.2020 14:38:24
*&AUTHOR    : HANDYXH
*&-------------------------------------------------------------
        lv_item = 1.
        LOOP AT lt_2006 TRANSPORTING NO FIELDS WHERE docno = <fs_item>-zref_doc.
          ADD 1 TO lv_item.
        ENDLOOP.
*&END-------------------------------------------------------------
        ls_2006-item = lv_item.
        ls_2006-zbtype = 'B'.
        ls_2006-bankno = <fs_item>-trxno.
        ls_2006-zqr = abap_true."确认付款的流水
        APPEND ls_2006 TO lt_2006.
        CLEAR ls_2006.
        CLEAR:lv_item.
      ENDIF.
*=================支付单：判断银行流水分组==========
    ENDLOOP.

    LOOP AT it_item ASSIGNING <fs_item> WHERE shkzg = 'S' .
      CLEAR : <fs_item>-zref_doc .
    ENDLOOP.


*=================支付单：存银行流水=========
    IF lt_2006 IS NOT INITIAL.
      MODIFY ztrt2006 FROM TABLE lt_2006.
    ENDIF.
*=================支付单：存银行流水=========
  ENDMETHOD.


METHOD check_3023_04.
    SELECT COUNT(*) FROM ztrt3023_04 WHERE bukrs   = iv_bukrs
                                       AND ztjbqj  = iv_qj
                                       AND hkont   = iv_hkont
                                       AND dflag   = abap_false .

    IF sy-subrc = 0 .
      ev_save = abap_true.
    ELSE.
      ev_save = abap_false.
    ENDIF.
  ENDMETHOD.


METHOD get_bankflow_zsjly.

  DEFINE set_msg.
    msg = VALUE #( TYPE = &1 ID = &2 NUMBER = &3 message_v1 = &4 message_v2 = &5 message_v3 = &6 message_v4 = &7 ).
  END-OF-DEFINITION.

  IF is_ref-zsjly IS NOT INITIAL. zsjly = is_ref-zsjly . EXIT. ENDIF.

  IF  is_ref-db_key IS NOT INITIAL.
    "拆分标识为空时
    IF is_ref-split_flag IS INITIAL.
      "拆分标识为空时，由于银企直连只有在拆分后才回写DB_KEY，所以只检查是否网银上传流水
      SELECT COUNT(*) FROM ztrt3023_02 WHERE db_key = is_ref-db_key AND dflag <> 'X'.
      IF sy-subrc = 0.
        zsjly = '1'.  "是网银上传
        RETURN.
      ELSE.
        set_msg 'E' 'ZTR02' '563' is_ref-db_key '' '' ''.   "银行流水&1在ZTRT3023_02中不存在，请检查！
        RETURN.
      ENDIF.
    ENDIF.

    "拆分标识不为空时
    IF is_ref-split_flag IS NOT INITIAL.
      "拆分标识不为空，首先检查是否拆分流水
      SELECT COUNT(*) FROM ztrt3023_02_cf WHERE db_key = is_ref-db_key.
      IF sy-subrc = 0.
        zsjly = '3'.   "是拆分流水
        RETURN.
      ELSE.
        "如果不是拆分流水，分别检查是否网银上传和银企直连

        "检查是否网银上传
        SELECT COUNT(*) FROM ztrt3023_02 WHERE db_key = is_ref-db_key AND dflag <> 'X'.
        IF sy-subrc = 0.
          zsjly = '1'.  "是网银上传
          RETURN.
        ENDIF.

        "检查是否银企直连
        SELECT COUNT(*) FROM ztrt_bank_trans WHERE db_key = is_ref-db_key.
        IF sy-subrc = 0.
          zsjly = '2'.  "是银企直连
          RETURN.
        ENDIF.

        IF zsjly IS INITIAL.
          set_msg 'E' 'ZTR02' '564' is_ref-db_key '' '' ''.   "拆分的银行流水&1不存在，请检查！
          RETURN.
        ENDIF.

      ENDIF.
    ENDIF.
  ENDIF.

  "如果DB_KEY为空
  IF is_ref-db_key IS INITIAL.
    "只有未拆分的银企直连流水的DB_KEY才可以为空，根据开户银行代码，银行账号和流水号检查是否银企直连流水
    IF is_ref-trxno IS NOT INITIAL.
      SELECT COUNT(*) FROM ztrt_bank_trans
      WHERE bukrs = is_ref-bukrs AND hbkid = is_ref-hbkid AND hktid = is_ref-hktid AND yhzh = is_ref-yhzh AND trxno = is_ref-trxno.
      IF sy-subrc = 0.
        zsjly = '2'.  "是银企直连
        RETURN.
      ELSE.
        set_msg 'E' 'ZTR02' '565' is_ref-trxno '' '' ''.   "银企直连的流水&1不存在，请检查！
        RETURN.
      ENDIF.
    ENDIF.

    IF is_ref-zbkitem IS NOT INITIAL.
      SELECT COUNT(*) FROM ztrt_bank_trans
      WHERE bukrs = is_ref-bukrs AND hbkid = is_ref-hbkid AND hktid = is_ref-hktid AND yhzh = is_ref-yhzh AND trxno = is_ref-zbkitem.
      IF sy-subrc = 0.
        zsjly = '2'.  "是银企直连
        RETURN.
      ELSE.
        set_msg 'E' 'ZTR02' '565' is_ref-trxno '' '' ''.   "银企直连的流水&1不存在，请检查！
        RETURN.
      ENDIF.
    ENDIF.

*      IF is_ref-trxno IS INITIAL AND is_ref-zbkitem IS INITIAL.
*        SELECT COUNT(*) FROM ztrt_bank_trans
*          WHERE bukrs = is_ref-bukrs AND hbkid = is_ref-hbkid AND hktid = is_ref-hktid AND yhzh = is_ref-yhzh.
*        IF sy-subrc = 0.
*          zsjly = '2'.  "是银企直连
*          RETURN.
*        ELSE.
*          set_msg 'E' 'ZTR02' '565' is_ref-trxno '' '' ''.   "银企直连的流水&1不存在，请检查！
*          RETURN.
*        ENDIF.
*      ENDIF.
  ENDIF.


ENDMETHOD.


METHOD get_by_ref.


    SELECT * FROM ztrt_bank_trans INTO CORRESPONDING FIELDS OF TABLE et_bank1
      WHERE zref_doc   = iv_doc
        AND zgroup_ac  = iv_group
        AND split_flag = ''
      .

    LOOP AT et_bank1 INTO DATA(ls_bank1) .
      DATA(ls_bank) = VALUE ztrs_bank_item( bukrs    =  ls_bank1-bukrs
                                            hbkid    =  ls_bank1-hbkid
                                            hktid    =  ls_bank1-hktid
                                            hkont    =  ls_bank1-hkont
                                            banks    =  ls_bank1-banks
                                            yhzh     =  ls_bank1-yhzh
                                            kunnr    =  ls_bank1-kunnr
                                            lifnr    =  ls_bank1-lifnr
                                            zppzt    =  ls_bank1-zppzt
                                            zppqj    =  ls_bank1-zppqj
                                            zbkitem  =  ls_bank1-trxno
                                            zbkjyri  =  ls_bank1-trxdate
                                            zbkjye   =  ls_bank1-trxamt
                                            zbkywt   =  ls_bank1-bustype_txt
                                            zbkyt    =  ls_bank1-usage_txt
                                            zbkzy    =  ls_bank1-abstract_txt
                                            zbkfy    =  ls_bank1-postscript_txt
                                            zbkbz    =  ls_bank1-comment_txt
                                            zbkdkhht =  ls_bank1-bzbnka
                                            zbkdkr   =  ls_bank1-bzbnkn
                                            zbkdkt   =  ls_bank1-bkoinh
                                            waers    =  ls_bank1-waers
                                            shkzg    =  ls_bank1-shkzg
                                            zsjly    =  '2'
                                             ) .
      APPEND ls_bank TO et_bank.
    ENDLOOP.

    SELECT i~db_key,
    h~bukrs,
    h~hbkid,
    h~hktid,
    h~banks,
    h~bankl,
    h~bank_ind,
    h~hkont,
    i~zbkitem,
    i~zbkjyri,
    i~zbkjysj,
    i~zbkjyrit,
    i~zbkbczbs,
    i~zbkjsms,
    i~zbkfse,
    i~zbkjye,
    i~zbkjyes,
    i~zbkjyeh,
    i~zbkjyye,
    i~zbkfkhht,
    i~zbkfkr,
    i~zbkfkt,
    i~zbkskhht,
    i~zbkskr,
    i~zbkskt,
    i~zbkdkhht,
    i~zbkdkr,
    i~zbkdkt,
    i~zbkywt,
    i~zbkzy1,
    i~zbkzy2,
    i~zbkzy,
    i~zbkyt,
    i~zbkfy,
    i~zbkbz,
    i~zbkad1,
    i~zbkad2,
    i~zbkad3,
    i~kunnr,
    i~lifnr,
    i~zppzt,
    i~zppqj,
    i~waers,
    i~shkzg,
    i~split_flag,
    '1' AS zsjly
    FROM ztrt3023_01 AS h  INNER JOIN ztrt3023_02 AS i ON h~db_key = i~parent_key
    INTO CORRESPONDING FIELDS OF TABLE @et_bank2
    WHERE i~zref_doc   = @iv_doc
*        AND i~zgroup_ac  = iv_group
    AND i~dflag = @space
    AND h~dflag = @space
    AND h~zly  = @space
    AND i~split_flag  = @space .
    IF sy-subrc = 0 .
      APPEND LINES OF et_bank2 TO et_bank.
    ENDIF.

    SELECT * FROM ztrt3023_02_cf INTO CORRESPONDING FIELDS OF TABLE et_bank3
    WHERE zref_doc   = iv_doc .

    LOOP AT et_bank3 INTO DATA(ls_bank3) .
      APPEND VALUE ztrs_bank_item( bukrs    =  ls_bank3-bukrs
      hbkid    =  ls_bank3-hbkid
      hktid    =  ls_bank3-hktid
      yhzh     =  ls_bank3-yhzh
      banks    =  ls_bank3-banks
      hkont    =  ls_bank3-hkont
      kunnr    =  ls_bank3-kunnr
      lifnr    =  ls_bank3-lifnr
      zppzt    =  ls_bank3-zppzt
      zppqj    =  ls_bank3-zppqj
      zbkitem  =  ls_bank3-zbkitem
      zbkjyri  =  ls_bank3-zbkjyri
      zbkjye   =  ls_bank3-zbkjye
      zbkywt   =  ls_bank3-zbkywt
      zbkyt    =  ls_bank3-zbkyt
      zbkzy    =  ls_bank3-zbkzy
      zbkfy    =  ls_bank3-zbkfy
      zbkbz    =  ls_bank3-zbkbz
      zbkdkhht =  ls_bank3-zbkdkhht
      zbkdkr   =  ls_bank3-zbkdkr
      zbkdkt   =  ls_bank3-zbkdkt
      waers    =  ls_bank3-waers
      shkzg    =  ls_bank3-shkzg
      split_flag    =  ls_bank3-split_flag
      zsjly    =  ls_bank3-zsjly
      )   TO et_bank.
    ENDLOOP.

    SELECT *   FROM ztrt3023_03 INTO CORRESPONDING FIELDS OF TABLE et_fi_doc
     WHERE  zref_doc   = iv_doc
      AND zgroup_ac  = iv_group .


* LOCK
    IF iv_lock IS NOT INITIAL .

      LOOP AT et_bank1 INTO ls_bank1 .
        DATA(ls_ref) =  VALUE ztrs_3028_agnref( bukrs = ls_bank1-bukrs
                                                hbkid = ls_bank1-hbkid
                                                hktid = ls_bank1-hktid
                                                yhzh  = ls_bank1-yhzh
                                                trxno  = ls_bank1-trxno ) .
        CALL METHOD zcl_tr_3024_gui=>lock_1
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.

      LOOP AT et_bank2  INTO DATA(ls_bank2)  .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank2-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_2
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.
      LOOP AT et_bank3  INTO  ls_bank3   .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank3-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_3
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.
    ENDIF.

  ENDMETHOD.


METHOD get_by_ref1.


    SELECT * FROM ztrt_bank_trans INTO CORRESPONDING FIELDS OF TABLE et_bank1
      WHERE zref_doc   = iv_doc
       AND split_flag = ''.

    LOOP AT et_bank1 INTO DATA(ls_bank1) .
      DATA(ls_bank) = VALUE ztrs_bank_item( bukrs    =  ls_bank1-bukrs
                                            hbkid    =  ls_bank1-hbkid
                                            hktid    =  ls_bank1-hktid
                                            yhzh     =  ls_bank1-yhzh
                                            banks    =  ls_bank1-banks
                                            hkont    =  ls_bank1-hkont
                                            kunnr    =  ls_bank1-kunnr
                                            lifnr    =  ls_bank1-lifnr
                                            zppzt    =  ls_bank1-zppzt
                                            zppqj    =  ls_bank1-zppqj
                                            zbkitem  =  ls_bank1-trxno
                                            zbkjyri  =  ls_bank1-trxdate
                                            zbkjye   =  ls_bank1-trxamt
                                            zbkywt   =  ls_bank1-bustype_txt
                                            zbkyt    =  ls_bank1-usage_txt
                                            zbkzy    =  ls_bank1-abstract_txt
                                            zbkfy    =  ls_bank1-postscript_txt
                                            zbkbz    =  ls_bank1-comment_txt
                                            zbkdkhht =  ls_bank1-bzbnka
                                            zbkdkr   =  ls_bank1-bzbnkn
                                            zbkdkt   =  ls_bank1-bkoinh
                                            waers    =  ls_bank1-waers
                                            shkzg    =  ls_bank1-shkzg
                                            split_flag    =  ls_bank1-split_flag
                                            zsjly    =  '2'
                                             ) .
      APPEND ls_bank TO et_bank.
    ENDLOOP.

    SELECT i~db_key,
           h~bukrs,
           h~hbkid,
           h~hktid,
           h~banks,
           h~bankl,
           h~bank_ind,
           h~hkont,
           i~zbkitem,
           i~zbkjyri,
           i~zbkjysj,
           i~zbkjyrit,
           i~zbkbczbs,
           i~zbkjsms,
           i~zbkfse,
           i~zbkjye,
           i~zbkjyes,
           i~zbkjyeh,
           i~zbkjyye,
           i~zbkfkhht,
           i~zbkfkr,
           i~zbkfkt,
           i~zbkskhht,
           i~zbkskr,
           i~zbkskt,
           i~zbkdkhht,
           i~zbkdkr,
           i~zbkdkt,
           i~zbkywt,
           i~zbkzy1,
           i~zbkzy2,
           i~zbkzy,
           i~zbkyt,
           i~zbkfy,
           i~zbkbz,
           i~zbkad1,
           i~zbkad2,
           i~zbkad3,
           i~kunnr,
           i~lifnr,
           i~zppzt,
           i~zppqj,
           i~waers,
           i~shkzg,
            i~split_flag,
            '1' AS zsjly
       FROM ztrt3023_01 AS h  INNER JOIN ztrt3023_02 AS i ON h~db_key = i~parent_key
       INTO CORRESPONDING FIELDS OF TABLE @et_bank2
      WHERE i~zref_doc   = @iv_doc
*        AND i~zgroup_ac  = iv_group
        AND i~dflag = @space
        AND h~dflag = @space
        AND h~zly  = @space
        AND i~split_flag  = @space .
    IF sy-subrc = 0 .
      APPEND LINES OF et_bank2 TO et_bank.
    ENDIF.

    SELECT * FROM ztrt3023_02_cf INTO CORRESPONDING FIELDS OF TABLE et_bank3
    WHERE zref_doc   = iv_doc .

    LOOP AT et_bank3 INTO DATA(ls_bank3) .
      APPEND VALUE ztrs_bank_item( bukrs    =  ls_bank3-bukrs
           hbkid    =  ls_bank3-hbkid
           hktid    =  ls_bank3-hktid
           yhzh     =  ls_bank3-yhzh
           banks    =  ls_bank3-banks
           hkont    =  ls_bank3-hkont
           kunnr    =  ls_bank3-kunnr
           lifnr    =  ls_bank3-lifnr
           zppzt    =  ls_bank3-zppzt
           zppqj    =  ls_bank3-zppqj
           zbkitem  =  ls_bank3-zbkitem
           zbkjyri  =  ls_bank3-zbkjyri
           zbkjye   =  ls_bank3-zbkjye
           zbkywt   =  ls_bank3-zbkywt
           zbkyt    =  ls_bank3-zbkyt
           zbkzy    =  ls_bank3-zbkzy
           zbkfy    =  ls_bank3-zbkfy
           zbkbz    =  ls_bank3-zbkbz
           zbkdkhht =  ls_bank3-zbkdkhht
           zbkdkr   =  ls_bank3-zbkdkr
           zbkdkt   =  ls_bank3-zbkdkt
           waers    =  ls_bank3-waers
           shkzg    =  ls_bank3-shkzg
           split_flag    =  ls_bank3-split_flag
           zsjly    =  ls_bank3-zsjly
           )   TO et_bank.
    ENDLOOP.

    SELECT *   FROM ztrt3023_03 INTO CORRESPONDING FIELDS OF TABLE et_fi_doc
     WHERE  zref_doc   = iv_doc
*      AND zgroup_ac  = iv_group
      .


* LOCK
    IF iv_lock IS NOT INITIAL .

      LOOP AT et_bank1 INTO ls_bank1 .
        DATA(ls_ref) =  VALUE ztrs_3028_agnref( bukrs = ls_bank1-bukrs
                                                hbkid = ls_bank1-hbkid
                                                hktid = ls_bank1-hktid
                                                yhzh  = ls_bank1-yhzh
                                                trxno  = ls_bank1-trxno ) .
        CALL METHOD zcl_tr_3024_gui=>lock_1
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.

      LOOP AT et_bank2  INTO DATA(ls_bank2)  .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank2-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_2
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.
      LOOP AT et_bank3  INTO  ls_bank3   .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank3-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_3
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.
    ENDIF.

  ENDMETHOD.


METHOD get_by_ref_tr2.
*
*
*    SELECT * FROM ztrt_bank_trans INTO CORRESPONDING FIELDS OF TABLE et_bank1
*      WHERE zref_doc   = iv_doc
*        AND zgroup_ac  = iv_group .
*
*    LOOP AT et_bank1 INTO DATA(ls_bank1) .
*      DATA(ls_bank) = VALUE ztrs_bank_item( bukrs    =  ls_bank1-bukrs
*                                            hbkid    =  ls_bank1-hbkid
*                                            hktid    =  ls_bank1-hktid
*                                            hkont    =  ls_bank1-hkont
*                                            banks    =  ls_bank1-banks
*                                            yhzh     =  ls_bank1-yhzh
*                                            kunnr    =  ls_bank1-kunnr
*                                            lifnr    =  ls_bank1-lifnr
*                                            zppzt    =  ls_bank1-zppzt
*                                            zppqj    =  ls_bank1-zppqj
*                                            zbkitem  =  ls_bank1-trxno
*                                            zbkjyri  =  ls_bank1-trxdate
*                                            zbkjye   =  ls_bank1-trxamt
*                                            zbkywt   =  ls_bank1-bustype_txt
*                                            zbkyt    =  ls_bank1-usage_txt
*                                            zbkzy    =  ls_bank1-abstract_txt
*                                            zbkfy    =  ls_bank1-postscript_txt
*                                            zbkbz    =  ls_bank1-comment_txt
*                                            zbkdkhht =  ls_bank1-bzbnka
*                                            zbkdkr   =  ls_bank1-bzbnkn
*                                            zbkdkt   =  ls_bank1-bkoinh
*                                            waers    =  ls_bank1-waers
*                                            shkzg    =  ls_bank1-shkzg ) .
*      APPEND ls_bank TO et_bank.
*    ENDLOOP.
*
*    SELECT i~db_key
*           h~bukrs
*           h~hbkid
*           h~hktid
*           h~banks
*           h~bankl
*           h~bank_ind
*           h~hkont
*           i~zbkitem
*           i~zbkjyri
*           i~zbkjysj
*           i~zbkjyrit
*           i~zbkbczbs
*           i~zbkjsms
*           i~zbkfse
*           i~zbkjye
*           i~zbkjyes
*           i~zbkjyeh
*           i~zbkjyye
*           i~zbkfkhht
*           i~zbkfkr
*           i~zbkfkt
*           i~zbkskhht
*           i~zbkskr
*           i~zbkskt
*           i~zbkdkhht
*           i~zbkdkr
*           i~zbkdkt
*           i~zbkywt
*           i~zbkzy1
*           i~zbkzy2
*           i~zbkzy
*           i~zbkyt
*           i~zbkfy
*           i~zbkbz
*           i~zbkad1
*           i~zbkad2
*           i~zbkad3
*           i~kunnr
*           i~lifnr
*           i~zppzt
*           i~zppqj
*           i~waers
*           i~shkzg
*       FROM ztrt3023_01 AS h  INNER JOIN ztrt3023_02 AS i ON h~db_key = i~parent_key
*       INTO CORRESPONDING FIELDS OF TABLE et_bank2
*      WHERE i~zref_doc   = iv_doc
*        AND i~zgroup_ac  = iv_group
*        AND i~dflag = space
*        AND h~dflag = space
*        AND h~zly  = space .
*    IF sy-subrc = 0 .
*      APPEND LINES OF et_bank2 TO et_bank.
*    ENDIF.
*
*    SELECT *   FROM ztrt3023_03 INTO CORRESPONDING FIELDS OF TABLE et_fi_doc
*     WHERE  zref_doc   = iv_doc
*      AND zgroup_ac  = iv_group .
*
*
** LOCK
*    IF iv_lock IS NOT INITIAL .
*
*      LOOP AT et_bank1 INTO ls_bank1 .
*        DATA(ls_ref) =  VALUE ztrs_3028_agnref( bukrs = ls_bank1-bukrs
*                                                hbkid = ls_bank1-hbkid
*                                                hktid = ls_bank1-hktid
*                                                yhzh  = ls_bank1-yhzh
*                                                trxno  = ls_bank1-trxno ) .
*        CALL METHOD zcl_tr_3024_gui=>lock_1
*          EXPORTING
*            iv_trans = ls_ref
*          EXCEPTIONS
*            err      = 1
*            OTHERS   = 2.
*        IF sy-subrc <> 0.
*          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
*            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
*        ENDIF.
*      ENDLOOP.
*
*      LOOP AT et_bank2  INTO DATA(ls_bank2)  .
*        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank2-db_key ) .
*        CALL METHOD zcl_tr_3024_gui=>lock_2
*          EXPORTING
*            iv_trans = ls_ref
*          EXCEPTIONS
*            err      = 1
*            OTHERS   = 2.
*        IF sy-subrc <> 0.
*          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
*            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
*        ENDIF.
*      ENDLOOP.
*    ENDIF.
*
**41 接受信用证融资 42 接受信用证兑付 43 DA/DP收款 44 Invoice discounting 45 DA/DP支付
*    SELECT *
*       FROM ztr2t1058
*       INTO TABLE @DATA(lt_exist)
*       WHERE zref_doc = @iv_doc
*         AND zgroup_ac = @iv_group
*         AND jxlxt <> @iv_jxlxt.
*
*    LOOP AT lt_exist INTO DATA(ls_exist) WHERE zref_doc = iv_doc
*                                           AND zgroup_ac = iv_group.
*      DELETE et_bank WHERE bukrs = ls_exist-bukrs AND hbkid = ls_exist-hbkid
*                        AND hktid = ls_exist-hktid AND zbkitem = ls_exist-trxno.
*    ENDLOOP.
  ENDMETHOD.


METHOD get_group.

    RETURN . " 暂废

    DATA : ls_grp TYPE ty_grp .
    CASE iv_zgroup .

      WHEN '11'.
        APPEND INITIAL LINE TO et_rgroup ASSIGNING FIELD-SYMBOL(<fs_grp>) .
        <fs_grp>-sign ='I'. <fs_grp>-sign = 'EQ'. <fs_grp>-low = '11' .

      WHEN '12'.
        APPEND INITIAL LINE TO  et_rgroup ASSIGNING <fs_grp> .
        <fs_grp>-sign ='I'. <fs_grp>-sign = 'EQ'. <fs_grp>-low = '12' .

      WHEN '21'.
        APPEND INITIAL LINE TO  et_rgroup ASSIGNING <fs_grp> .
        <fs_grp>-sign ='I'. <fs_grp>-sign = 'EQ'. <fs_grp>-low = '21' .

      WHEN '22'.
        APPEND INITIAL LINE TO  et_rgroup ASSIGNING <fs_grp> .
        <fs_grp>-sign ='I'. <fs_grp>-sign = 'EQ'. <fs_grp>-low = '22' .

      WHEN '23'.
        APPEND INITIAL LINE TO  et_rgroup ASSIGNING <fs_grp> .
        <fs_grp>-sign ='I'. <fs_grp>-sign = 'EQ'. <fs_grp>-low = '23' .

      WHEN '31'.
        APPEND INITIAL LINE TO  et_rgroup ASSIGNING <fs_grp> .
        <fs_grp>-sign ='I'. <fs_grp>-sign = 'EQ'. <fs_grp>-low = '31' .

      WHEN '32'.
*        INSERT INITIAL LINE INTO et_rgroup ASSIGNING <fs_grp> .
*        <fs_grp>-sign ='I'. <fs_grp>-sign = 'EQ'. <fs_grp>-low = 'ZZ' .
        APPEND INITIAL LINE TO  et_rgroup ASSIGNING <fs_grp> .
        <fs_grp>-sign ='I'. <fs_grp>-sign = 'EQ'. <fs_grp>-low = '32' .

      WHEN '33'.
        APPEND INITIAL LINE TO  et_rgroup ASSIGNING <fs_grp> .
        <fs_grp>-sign ='I'. <fs_grp>-sign = 'EQ'. <fs_grp>-low = '33' .
    ENDCASE .

    INSERT INITIAL LINE INTO et_rgroup ASSIGNING <fs_grp> .
    <fs_grp>-sign ='I'. <fs_grp>-sign = 'EQ'. <fs_grp>-low = 'ZZ' .

  ENDMETHOD.


METHOD get_ppzt.
    CASE iv_zgroup .
*      WHEN '10'.
      WHEN '11'.   " 银行对账平台手工对账
        ev_zppzt = '1'.
      WHEN '12'.   " 银行对账平台自动过账
        ev_zppzt = '2'.
      WHEN OTHERS .  " 其他模块匹配
        ev_zppzt = '3'.
    ENDCASE .
  ENDMETHOD.


METHOD get_ref2_by_ref.
    DATA lt_draft TYPE TABLE OF ztrt0072.
    DATA et_tmp  TYPE   ztrs_bank_info_tab .
    " CHECK it_bank[] IS NOT INITIAL.
    CHECK et_bank_draft[] IS NOT INITIAL.
    SELECT * FROM ztrt0050_bktrns INTO CORRESPONDING FIELDS OF TABLE et_set_input
      WHERE docno = iv_doc.
    CHECK sy-subrc = 0.

*    CASE  iv_group  .
*      WHEN '26'.  "贴现银行流水匹配
*      WHEN '27'.  "托收银行流水匹配
*        SELECT *
*        FROM ztrt0072 AS a
*        INNER JOIN ztrt0050 AS b
*        ON a~docno_key = b~docno_key
*        INTO CORRESPONDING FIELDS OF TABLE  et_set_input
*        WHERE a~docno = iv_doc
*        AND a~zitem_status IN ('15','20'). "只匹配财务已确认和会计已过账的行项目
*
*        SELECT *
*          INTO CORRESPONDING FIELDS OF TABLE  lt_draft
*          FROM ztrt0072
*          "FOR ALL ENTRIES IN et_bank_draft
*        WHERE  docno =  iv_doc
    "  AND draft =  et_bank_draft-draft..

    " IF sy-subrc = 0.  "已进行流水匹配到汇票
    DATA(row_cont) = 0.
    SORT et_bank_draft BY zbkitem.
    SORT et_set_input BY zbkitem.
    LOOP AT et_bank_draft ASSIGNING FIELD-SYMBOL(<fs>).
      row_cont = 0.
      LOOP AT et_set_input INTO DATA(ls_trns) WHERE zbkitem = <fs>-zbkitem ."AND draft = <fs>-draft.

        ADD 1 TO  row_cont .

        <fs>-draft = ls_trns-draft.
        <fs>-ckbox = 'X'.
        IF row_cont > 1.
          <fs>-zbkjye  = 0.
          APPEND <fs> TO et_tmp.
          CONTINUE.
        ELSE.
          <fs>-cell = VALUE lvc_t_styl( BASE   <fs>-cell  ( fieldname = 'CKBOX' style = cl_gui_alv_grid=>mc_style_disabled ) ).
          APPEND <fs> TO et_tmp.
        ENDIF.
      ENDLOOP.
      IF sy-subrc <> 0.
        APPEND <fs> TO et_tmp.
      ENDIF.
    ENDLOOP.
*        ELSE. "尚未进行流水匹配到汇票，需切换
*
*        ENDIF.
*      WHEN '36'.  "回购银行流水匹配
*      WHEN OTHERS.
*    ENDCASE.
    IF et_tmp[] IS NOT INITIAL.
      et_bank_draft[] = et_tmp[].
    ENDIF.
  ENDMETHOD.


METHOD lock_1.
    CALL FUNCTION 'ENQUEUE_EZTRT_BANK_TRANS'
      EXPORTING
        mode_ztrt_bank_trans = 'E'
        mandt                = sy-mandt
        bukrs                = iv_trans-bukrs
        hbkid                = iv_trans-hbkid
        hktid                = iv_trans-hktid
        yhzh                 = iv_trans-yhzh
        trxno                = iv_trans-trxno
        _scope               = '3'
      EXCEPTIONS
        foreign_lock         = 1
        system_failure       = 2
        OTHERS               = 3.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
        WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
    ENDIF.

  ENDMETHOD.


METHOD lock_2.
    CALL FUNCTION 'ENQUEUE_EZZTRT3023_02'
      EXPORTING
*       mode_ztrt3023_02 = 'X'
        mandt          = sy-mandt
        db_key         = iv_trans-db_key
        _scope         = '3'
      EXCEPTIONS
        foreign_lock   = 1
        system_failure = 2
        OTHERS         = 3.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
        WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
    ENDIF.

  ENDMETHOD.


METHOD lock_3.
    CALL FUNCTION 'ENQUEUE_EZTRT3023_CF'
      EXPORTING
        mandt          = sy-mandt
        db_key         = iv_trans-db_key
        _scope         = '3'
      EXCEPTIONS
        foreign_lock   = 1
        system_failure = 2
        OTHERS         = 3.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
        WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
    ENDIF.

  ENDMETHOD.


METHOD lock_all.
    LOOP AT it_trans INTO DATA(ls_ref) .
      IF ls_ref-split_flag = 'Y'.

        CALL METHOD zcl_tr_3024_gui=>lock_3
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
          WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
        CONTINUE.
      ENDIF.
      IF ls_ref-db_key IS NOT INITIAL.

        CALL METHOD zcl_tr_3024_gui=>lock_2
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
          WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ELSE.
        CALL METHOD zcl_tr_3024_gui=>lock_1
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
          WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDIF.
    ENDLOOP.


  ENDMETHOD.


METHOD mapping_by_atuo.

    DATA : lv_zppqj TYPE zbk_ppqj .
    IF iv_zppqj IS NOT INITIAL .
      lv_zppqj = iv_zppqj .
    ELSE.
      lv_zppqj = sy-datum(6) .
    ENDIF.

    IF is_ref-split_flag = 'Y'.
      IF iv_lock = abap_true .
        CALL METHOD zcl_tr_3024_gui=>lock_3
          EXPORTING
            iv_trans = is_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
          WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDIF.

      UPDATE ztrt3023_02_cf SET zppzt = '2'
                        zppqj = lv_zppqj
                        iaedat  = sy-datum
                        iaezet  = sy-uzeit
                        iaenam = sy-uname
                        itcode = sy-tcode
      WHERE db_key = is_ref-db_key .
      IF sy-subrc <> 0 .
        ROLLBACK WORK  .
        MESSAGE e109(ztr01)  RAISING err.
      ENDIF.

    ELSEIF is_ref-db_key IS NOT INITIAL.
      IF iv_lock = abap_true .
        CALL METHOD zcl_tr_3024_gui=>lock_2
          EXPORTING
            iv_trans = is_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDIF.

      UPDATE ztrt3023_02 SET zppzt = '2'
                 zppqj = lv_zppqj
                 iaedat  = sy-datum
iaezet  = sy-uzeit
iaenam = sy-uname
itcode = sy-tcode
                  WHERE db_key = is_ref-db_key .
      IF sy-subrc <> 0 .
        ROLLBACK WORK  .
        MESSAGE e109(ztr01)  RAISING err.
      ENDIF.

    ELSE.
      IF iv_lock = abap_true .
        CALL METHOD zcl_tr_3024_gui=>lock_1
          EXPORTING
            iv_trans = is_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDIF.

      UPDATE ztrt_bank_trans SET zppzt = '2'
                          zppqj = lv_zppqj WHERE bukrs = is_ref-bukrs
                                             AND hbkid = is_ref-hbkid
                                             AND hktid = is_ref-hktid
                                             AND yhzh  = is_ref-yhzh
                                             AND trxno = is_ref-trxno.
      IF sy-subrc <> 0 .
        ROLLBACK WORK  .
        MESSAGE e109(ztr01)  RAISING err.
      ENDIF.
    ENDIF.

    DATA(ls_bsis) = is_bsis.
    ls_bsis-zppzt = '2' .
    ls_bsis-zppqj = lv_zppqj  .

    MODIFY ztrt3023_03 FROM  ls_bsis.
    IF sy-subrc <> 0 .
      ROLLBACK WORK  .
      MESSAGE e109(ztr01)  RAISING err.
    ENDIF.
*20190927 费用过账优化
*    DATA I_MODE TYPE PS_UPDMODE.
*    DATA IT_LOG TYPE ZTRT3023_03_T.
    mapping_unmapping_log(
      EXPORTING
        i_mode = 'M'
        it_log = VALUE ztrt3023_03_t( ( ls_bsis ) )
      EXCEPTIONS
        error  = 1
        OTHERS = 2
           ).
    IF sy-subrc <> 0.
*     Implement suitable error handling here
    ENDIF.
*20190927 费用过账优化

    IF iv_commit = abap_true .
      COMMIT WORK AND WAIT .
    ENDIF.

    IF iv_lock = abap_true .
      IF is_ref-split_flag = 'Y'.
        CALL METHOD zcl_tr_3024_gui=>unlock_3
          EXPORTING
            iv_trans = is_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
      ELSEIF is_ref-db_key IS NOT INITIAL.
        CALL METHOD zcl_tr_3024_gui=>unlock_2
          EXPORTING
            iv_trans = is_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
        ENDIF.
      ELSE.

        CALL METHOD zcl_tr_3024_gui=>unlock_1
          EXPORTING
            iv_trans = is_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
        ENDIF.

      ENDIF.

    ENDIF.
  ENDMETHOD.


METHOD mapping_by_manual.

    DATA : lt_ref_2 TYPE ztrt_3028_agnref,
           lt_ref_1 TYPE ztrt_3028_agnref,
           lt_ref_3 TYPE ztrt_3028_agnref,
           lt_bsis  TYPE ztrtt3023_03.


    LOOP AT it_ref INTO DATA(ls_ref) .
      IF ls_ref-split_flag = 'Y'.
        APPEND ls_ref TO lt_ref_3 .
        IF iv_lock = abap_true .
          CALL METHOD zcl_tr_3024_gui=>lock_3
            EXPORTING
              iv_trans = ls_ref
            EXCEPTIONS
              err      = 1
              OTHERS   = 2.
          IF sy-subrc <> 0.
            MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
          ENDIF.
        ENDIF.
        CONTINUE.
      ENDIF.
      IF ls_ref-db_key IS NOT INITIAL.
        APPEND ls_ref TO lt_ref_2 .
        IF iv_lock = abap_true .
          CALL METHOD zcl_tr_3024_gui=>lock_2
            EXPORTING
              iv_trans = ls_ref
            EXCEPTIONS
              err      = 1
              OTHERS   = 2.
          IF sy-subrc <> 0.
            MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
              WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
          ENDIF.
        ENDIF.
      ELSE.
        APPEND ls_ref TO lt_ref_1.
        IF iv_lock = abap_true .
          CALL METHOD zcl_tr_3024_gui=>lock_1
            EXPORTING
              iv_trans = ls_ref
            EXCEPTIONS
              err      = 1
              OTHERS   = 2.
          IF sy-subrc <> 0.
            MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
              WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
          ENDIF.
        ENDIF.
      ENDIF.
    ENDLOOP.

    DATA : lv_zppqj TYPE zbk_ppqj .
    IF iv_zppqj IS NOT INITIAL .
      lv_zppqj = iv_zppqj .
    ELSE.
      lv_zppqj = sy-datum(6) .
    ENDIF.


    IF NOT lt_ref_1 IS INITIAL .
      LOOP AT lt_ref_1 INTO DATA(ls_ref_1) .
        UPDATE ztrt_bank_trans SET zppzt = '1'
                                   zppqj = lv_zppqj
                                zgroup_ac = '10'
                                zref_doc = ls_ref_1-zref_doc
                              WHERE bukrs = ls_ref_1-bukrs
                                               AND hbkid = ls_ref_1-hbkid
                                               AND hktid = ls_ref_1-hktid
                                               AND yhzh  = ls_ref-yhzh
                                               AND trxno = ls_ref_1-trxno .
*                                               AND zgroup_ac = '10' .

        IF sy-subrc <> 0 .
          ROLLBACK WORK  .
          MESSAGE e109(ztr01)  RAISING err.
        ENDIF.
      ENDLOOP.
    ENDIF.


    IF NOT lt_ref_2 IS INITIAL .
      LOOP AT lt_ref_2 INTO DATA(ls_ref_2) .
        UPDATE ztrt3023_02 SET zppzt = '1'
                               zppqj = lv_zppqj
                               iaedat  = sy-datum
                            zgroup_ac = '10'
                            zref_doc = ls_ref_2-zref_doc
                            iaezet  = sy-uzeit
                            iaenam = sy-uname
                            itcode = sy-tcode
                        WHERE db_key = ls_ref_2-db_key .
        IF sy-subrc <> 0 .
          ROLLBACK WORK  .
          MESSAGE e109(ztr01)  RAISING err.
        ENDIF.
      ENDLOOP.
    ENDIF.

    IF NOT lt_ref_3 IS INITIAL .
      LOOP AT lt_ref_3 INTO DATA(ls_ref_3) .
        UPDATE ztrt3023_02_cf SET zppzt = '1'
                               zppqj = lv_zppqj
                               iaedat  = sy-datum
                            zgroup_ac = '10'
                            zref_doc = ls_ref_3-zref_doc
                            iaezet  = sy-uzeit
                            iaenam = sy-uname
                            itcode = sy-tcode
                        WHERE db_key = ls_ref_3-db_key .
        IF sy-subrc <> 0 .
          ROLLBACK WORK  .
          MESSAGE e109(ztr01)  RAISING err.
        ENDIF.
      ENDLOOP.
    ENDIF.
    lt_bsis = it_bsis .
    LOOP AT lt_bsis ASSIGNING FIELD-SYMBOL(<fs_bsis>)  .
      <fs_bsis>-zppzt = '1' .
      <fs_bsis>-zppqj = lv_zppqj  .
    ENDLOOP.
    MODIFY ztrt3023_03 FROM TABLE lt_bsis .
    IF sy-subrc <> 0 .
      ROLLBACK WORK  .
      MESSAGE e109(ztr01)  RAISING err.
    ENDIF.
*20190927 费用过账优化
*    DATA I_MODE TYPE PS_UPDMODE.
*    DATA IT_LOG TYPE ZTRT3023_LOG_T.

    mapping_unmapping_log(
      EXPORTING
        i_mode = 'M'
        it_log = lt_bsis
      EXCEPTIONS
        error  = 1
        OTHERS = 2
           ).
    IF sy-subrc <> 0.
*     Implement suitable error handling here
    ENDIF.

*20190927 费用过账优化

    IF iv_commit = abap_true .
      COMMIT WORK AND WAIT .
    ENDIF.

    IF iv_lock = abap_true .
      LOOP AT it_ref INTO ls_ref .
        IF ls_ref-split_flag = 'Y'.
          CALL METHOD zcl_tr_3024_gui=>unlock_3
            EXPORTING
              iv_trans = ls_ref
            EXCEPTIONS
              err      = 1
              OTHERS   = 2.
          CONTINUE.
        ENDIF.

        IF ls_ref-db_key IS NOT INITIAL.
          CALL METHOD zcl_tr_3024_gui=>unlock_2
            EXPORTING
              iv_trans = ls_ref
            EXCEPTIONS
              err      = 1
              OTHERS   = 2.
          IF sy-subrc <> 0.
          ENDIF.
        ELSE.

          CALL METHOD zcl_tr_3024_gui=>unlock_1
            EXPORTING
              iv_trans = ls_ref
            EXCEPTIONS
              err      = 1
              OTHERS   = 2.
          IF sy-subrc <> 0.
          ENDIF.

        ENDIF.

      ENDLOOP.
    ENDIF.
  ENDMETHOD.


METHOD mapping_by_ref.

    DATA : lt_bank1 TYPE TABLE OF ztrt_bank_trans,
           lt_bank2 TYPE TABLE OF ztrt3023_02,
           lt_doc   TYPE TABLE OF ztrt3023_03,
*           ls_doc   TYPE ztrt3023_03,
           lt_ref_2 TYPE ztrt_3028_agnref,
           lt_ref_1 TYPE ztrt_3028_agnref.


    RETURN . "关闭单据匹配功能，因为此时可能没有银行流水对应。这就无法做货币，科目，金额等强校验。 匹配只有job自动和手工两种方式.

** LOCK
**    IF iv_lock IS NOT INITIAL .
*    SELECT * FROM ztrt_bank_trans INTO CORRESPONDING FIELDS OF TABLE lt_ref_1
*      WHERE zref_doc   = iv_doc
*        AND zgroup_ac  = iv_group .
*    IF sy-subrc = 0 .
*      LOOP AT lt_ref_1 INTO DATA(ls_ref) .
*        CALL METHOD zcl_tr_3024_gui=>lock_1
*          EXPORTING
*            iv_trans = ls_ref
*          EXCEPTIONS
*            err      = 1
*            OTHERS   = 2.
*        IF sy-subrc <> 0.
*          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
*            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
*        ENDIF.
*
*        CALL FUNCTION 'ENQUEUE_EZZTRV_3023_LOCK'
*          EXPORTING
*            mode_ztrv_3023_lock = 'E'
*            mandt               = sy-mandt
*            bukrs               = ls_ref-bukrs
*            hbkid               = ls_ref-hbkid
*            hktid               = ls_ref-hktid
*          EXCEPTIONS
*            foreign_lock        = 1
*            system_failure      = 2
*            OTHERS              = 3.
*        IF sy-subrc <> 0.
*          MESSAGE e609(ztr01)   WITH sy-msgv1  RAISING err.
*        ENDIF.
*
*
*        SELECT SINGLE hkont INTO @DATA(lv_hkont) FROM ztrt0013 WHERE bukrs = @ls_ref-bukrs
*                                            AND hbkid = @ls_ref-hbkid
*                                            AND hktid = @ls_ref-hktid .
*        IF sy-subrc = 0 .
*          CALL METHOD zcl_tr_3024_gui=>check_3023_04
*            EXPORTING
*              iv_bukrs = ls_ref-bukrs
*              iv_qj    = iv_zppdate(6)
*              iv_hkont = lv_hkont
*            IMPORTING
*              ev_save  = DATA(lv_save).
*
*          IF lv_save = abap_true .
*            MESSAGE e694(ztr01)   RAISING err.
*          ENDIF.
*        ENDIF.
*
*      ENDLOOP.
*    ENDIF.
*
*    SELECT * FROM ztrt3023_02 INTO CORRESPONDING FIELDS OF TABLE lt_ref_2
*     WHERE zref_doc   = iv_doc
*       AND zgroup_ac  = iv_group
*       AND dflag      = space .
*    IF sy-subrc = 0 .
*      LOOP AT lt_ref_2 INTO ls_ref .
*        CALL METHOD zcl_tr_3024_gui=>lock_2
*          EXPORTING
*            iv_trans = ls_ref
*          EXCEPTIONS
*            err      = 1
*            OTHERS   = 2.
*        IF sy-subrc <> 0.
*          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
*            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
*        ENDIF.
*        CALL FUNCTION 'ENQUEUE_EZZTRV_3023_LOCK'
*          EXPORTING
*            mode_ztrv_3023_lock = 'E'
*            mandt               = sy-mandt
*            bukrs               = ls_ref-bukrs
*            hbkid               = ls_ref-hbkid
*            hktid               = ls_ref-hktid
*          EXCEPTIONS
*            foreign_lock        = 1
*            system_failure      = 2
*            OTHERS              = 3.
*        IF sy-subrc <> 0.
*          MESSAGE e609(ztr01)   WITH sy-msgv1  RAISING err.
*        ENDIF.
*
*        SELECT SINGLE hkont INTO lv_hkont FROM ztrt0013 WHERE bukrs = ls_ref-bukrs
*                                            AND hbkid = ls_ref-hbkid
*                                            AND hktid = ls_ref-hktid .
*        IF sy-subrc = 0 .
*          CALL METHOD zcl_tr_3024_gui=>check_3023_04
*            EXPORTING
*              iv_bukrs = ls_ref-bukrs
*              iv_qj    = iv_zppdate(6)
*              iv_hkont = lv_hkont
*            IMPORTING
*              ev_save  = lv_save.
*
*          IF lv_save = abap_true .
*            MESSAGE e694(ztr01)   RAISING err.
*          ENDIF.
*        ENDIF.
*      ENDLOOP.
*    ENDIF.
**    ENDIF.
*
*
**check
*    SELECT * FROM ztrt_bank_trans INTO CORRESPONDING FIELDS OF TABLE lt_bank1
*      WHERE zref_doc   = iv_doc
*        AND zgroup_ac  = iv_group .
*    LOOP AT lt_bank1 INTO DATA(ls_bank1) WHERE zppzt <> space.
*      EXIT.
*    ENDLOOP.
*    IF sy-subrc = 0 .
*      MESSAGE e464(ztr01) WITH ls_bank1-trxno RAISING err.
*    ENDIF.
*
*    SELECT * FROM ztrt3023_02 INTO CORRESPONDING FIELDS OF TABLE lt_bank2
*      WHERE zref_doc   = iv_doc
*        AND zgroup_ac  = iv_group
*        AND dflag = space.
*    LOOP AT lt_bank2 INTO DATA(ls_bank2) WHERE zppzt <> space.
*      EXIT.
*    ENDLOOP.
*    IF sy-subrc = 0 .
*      MESSAGE e464(ztr01) WITH ls_bank2-zbkitem RAISING err.
*    ENDIF.
*
*    SELECT * FROM ztrt3023_03 INTO CORRESPONDING FIELDS OF TABLE lt_doc
*     WHERE  zref_doc   = iv_doc
*      AND zgroup_ac  = iv_group .
*    IF sy-subrc = 0 .
*      MESSAGE e465(ztr01) WITH  iv_doc RAISING err.
*    ENDIF.
*
*
*    IF iv_zppdate IS INITIAL .
*      DATA(lv_date) = sy-datum .
*    ELSE.
*      lv_date = iv_zppdate .
*    ENDIF.
*
*    DATA : lv_ppzt TYPE zbk_ppzt  .
*
*    CALL METHOD zcl_tr_3024_gui=>get_ppzt
*      EXPORTING
*        iv_zgroup = iv_group
*      IMPORTING
*        ev_zppzt  = lv_ppzt.
*
*    IF lt_bank1 IS NOT INITIAL .
*      UPDATE ztrt_bank_trans SET zppzt  =  lv_ppzt
*                                 zppqj  =  lv_date(6)
*                             WHERE zref_doc   = iv_doc
*                               AND zgroup_ac  = iv_group .
*      IF sy-subrc <> 0 .
*        ROLLBACK WORK  .
*        MESSAGE e109(ztr01)  RAISING err.
*      ENDIF.
*    ENDIF.
*
*    IF lt_bank2 IS NOT INITIAL .
*      UPDATE ztrt3023_02    SET  zppzt  =  lv_ppzt
*                                 zppqj  =  lv_date(6)
*                                 iaedat  = sy-datum
*                                 iaezet  = sy-uzeit
*                                 iaenam = sy-uname
*                                 itcode = sy-tcode
*                          WHERE  zref_doc   = iv_doc
*                            AND  zgroup_ac  = iv_group
*                            AND  dflag = space.
*      IF sy-subrc <> 0 .
*        ROLLBACK WORK  .
*        MESSAGE e109(ztr01)  RAISING err.
*      ENDIF.
*    ENDIF.
*
*    CLEAR lt_doc   .
*    LOOP AT  it_fi_doc INTO DATA(ls_fi_doc).
*      lt_doc = VALUE #( BASE lt_doc ( bukrs = ls_fi_doc-bukrs
*                                      gjahr = ls_fi_doc-gjahr
*                                      belnr = ls_fi_doc-belnr
*                                      buzei = ls_fi_doc-buzei
*                                      zppzt = lv_ppzt
*                                      zppqj = lv_date(6)
**                                      db_key
*                                      zref_doc = iv_doc
*                                      zgroup_ac = iv_group
*                                          ) ) .
*    ENDLOOP.
*
*    MODIFY ztrt3023_03 FROM TABLE lt_doc.
*
*    IF sy-subrc <> 0 .
*      ROLLBACK WORK  .
*      MESSAGE e109(ztr01)  RAISING err.
*    ENDIF.
*
*    IF iv_commit = abap_true .
*      COMMIT WORK AND WAIT .
*    ENDIF.
*
*
**    IF iv_lock IS NOT INITIAL .
*
*    LOOP AT lt_ref_1 INTO ls_ref .
*      CALL METHOD zcl_tr_3024_gui=>unlock_1
*        EXPORTING
*          iv_trans = ls_ref
*        EXCEPTIONS
*          err      = 1
*          OTHERS   = 2.
*      IF sy-subrc <> 0.
*        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
*          WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
*      ENDIF.
*    ENDLOOP.
*
*    LOOP AT lt_ref_2 INTO ls_ref .
*      CALL METHOD zcl_tr_3024_gui=>unlock_2
*        EXPORTING
*          iv_trans = ls_ref
*        EXCEPTIONS
*          err      = 1
*          OTHERS   = 2.
*      IF sy-subrc <> 0.
*        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
*          WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
*      ENDIF.
*    ENDLOOP.
*
**    ENDIF.

  ENDMETHOD.


METHOD mapping_unmapping_log.
*    将更新匹配表数据更新至日志表 ztrt3023_03_log
    DATA gt_log TYPE TABLE OF ztrt3023_03_log.
    DATA gs_log LIKE LINE OF gt_log.

    SORT it_log BY db_key.
    CASE i_mode.
      WHEN 'I' OR 'M'.
        LOOP AT   it_log INTO DATA(is_logm).
          gs_log       = CORRESPONDING #( is_logm ).
          gs_log-aedat = sy-datum.
          gs_log-aezet = sy-uzeit.
          gs_log-aenam = sy-uname.


          SELECT SINGLE  zxh erdat  erzet ernam action
                INTO (gs_log-zxh,gs_log-erdat,gs_log-erzet,gs_log-ernam, gs_log-action)
                FROM ztrt3023_03_log
                WHERE db_key = gs_log-db_key AND belnr = gs_log-belnr
                AND bukrs = gs_log-bukrs AND trxno = gs_log-trxno.
          IF sy-subrc <> 0.
*序号
            IF gs_log-db_key  IS NOT INITIAL.

              SELECT  MAX( zxh  )  INTO @DATA(zxh)
                           FROM ztrt3023_03_log
                           WHERE   db_key = @gs_log-db_key
                           AND bukrs = @gs_log-bukrs AND trxno = @gs_log-trxno.  .
              SELECT SINGLE    hbkid , hktid,  yhzh,  trxno ,zgroup, zref_doc, zgroup_ac
               INTO @DATA(group)
               FROM   ztrt3023_03_log
               WHERE db_key = @gs_log-db_key
                AND bukrs = @gs_log-bukrs AND trxno = @gs_log-trxno..
*其他
              IF sy-subrc = 0.
                MOVE-CORRESPONDING group TO gs_log.
              ENDIF.

            ELSE.
              SELECT  MAX( zxh  )  INTO  zxh
                      FROM ztrt3023_03_log
              WHERE   zgroup = gs_log-zgroup
                AND   zref_doc = gs_log-zref_doc
                AND   zgroup_ac = gs_log-zgroup_ac
                AND   bukrs = gs_log-bukrs AND trxno = gs_log-trxno.               .
            ENDIF.
            gs_log-zxh = zxh + 1.
*          操作类型
            IF sy-tcode = 'ZTR00088' OR  sy-tcode = 'ZTR00128'.
              gs_log-action = 'P'.
            ELSEIF  sy-tcode = 'ZTR00089' OR  sy-tcode = 'ZTR00120'.
              gs_log-action = 'R'.
            ENDIF.


          ENDIF.
          IF gs_log-erdat IS INITIAL.
            gs_log-erdat = sy-datum.
            gs_log-erzet = sy-uzeit.
            gs_log-ernam = sy-uname.
          ENDIF.
          APPEND gs_log TO gt_log.
          CLEAR gs_log.
          CLEAR is_logm.
        ENDLOOP.
      WHEN 'D'.
        LOOP AT it_log INTO DATA(is_logd).
          SELECT SINGLE * INTO gs_log FROM ztrt3023_03_log
            WHERE bukrs = is_logd-bukrs
              AND  gjahr = is_logd-gjahr
              AND  buzei = is_logd-buzei
              AND  belnr = is_logd-belnr.
          IF sy-subrc <> 0.
            gs_log       = CORRESPONDING #( is_logd ).
            IF sy-tcode = 'ZTR00088' OR  sy-tcode = 'ZTR00128'.
              gs_log-action = 'P'.
            ELSEIF  sy-tcode = 'ZTR00089' OR  sy-tcode = 'ZTR00120'.
              gs_log-action = 'R'.
            ENDIF.
          ENDIF.

          gs_log-dflag = 'X'.
          gs_log-aedat = sy-datum.
          gs_log-aezet = sy-uzeit.
          gs_log-aenam = sy-uname.

          APPEND gs_log TO gt_log.
          CLEAR gs_log.
          CLEAR is_logd.
        ENDLOOP.
      WHEN OTHERS.
    ENDCASE.

    MODIFY ztrt3023_03_log FROM TABLE gt_log.
    IF sy-subrc <> 0.
      RAISE error.
    ENDIF.


  ENDMETHOD.


METHOD query_34.

    DATA :  r_1 TYPE RANGE OF zbk_ppzt .
    CASE iv_zppzt .
      WHEN space.
        r_1 = VALUE #( BASE r_1 ( sign = 'I'  option  = 'EQ' low = iv_zppzt ) ) .
      WHEN abap_true .
        r_1 = VALUE #( BASE r_1 ( sign = 'I'  option  = 'NE' low = space ) ) .
      WHEN '*' .
        CLEAR r_1.
    ENDCASE .


    DATA :  r_3 TYPE RANGE OF hbkid.
    CASE iv_hbkid .
      WHEN space.
        CLEAR r_3.
      WHEN OTHERS .
        r_3 = VALUE #( BASE r_3 ( sign = 'I'  option  = 'EQ' low = iv_hbkid ) ) .
    ENDCASE .

    DATA :  r_4 TYPE RANGE OF hktid.
    CASE iv_hktid  .
      WHEN space.
        CLEAR r_4.
      WHEN OTHERS .
        r_4 = VALUE #( BASE r_4 ( sign = 'I'  option  = 'EQ' low = iv_hktid ) ) .
    ENDCASE .


    DATA :  r_5 TYPE RANGE OF shkzg  .
    CASE iv_shkzg   .
      WHEN space.
        CLEAR r_5.
      WHEN OTHERS .
        r_5 = VALUE #( BASE r_5 ( sign = 'I'  option  = 'EQ' low = iv_shkzg  ) ) .
    ENDCASE .

    SELECT * FROM ztrt_bank_trans INTO CORRESPONDING FIELDS OF TABLE et_bank1
     WHERE bukrs  = iv_bukrs
       AND zppzt  IN r_1
       AND hktid IN r_4
       AND hbkid IN r_3
       AND shkzg IN r_5
       AND zref_doc = space
       AND split_flag = space
       AND zgroup_ac  = iv_group .

    LOOP AT et_bank1 INTO DATA(ls_bank1) .
      DATA(ls_bank) = VALUE ztrs_bank_item( bukrs    =  ls_bank1-bukrs
                                            hbkid    =  ls_bank1-hbkid
                                            hktid    =  ls_bank1-hktid
                                            yhzh     =  ls_bank1-yhzh
                                            kunnr    =  ls_bank1-kunnr
                                            lifnr    =  ls_bank1-lifnr
                                            hkont    =  ls_bank1-hkont
                                            banks    =  ls_bank1-banks
                                            zppzt    =  ls_bank1-zppzt
                                            zppqj    =  ls_bank1-zppqj
                                            zbkitem  =  ls_bank1-trxno
                                            zbkjyri  =  ls_bank1-trxdate
                                            zbkjye   =  ls_bank1-trxamt
                                            zbkywt   =  ls_bank1-bustype_txt
                                            zbkyt    =  ls_bank1-usage_txt
                                            zbkzy    =  ls_bank1-abstract_txt
                                            zbkfy    =  ls_bank1-postscript_txt
                                            zbkbz    =  ls_bank1-comment_txt
                                            zbkdkhht =  ls_bank1-bzbnka
                                            zbkdkr   =  ls_bank1-bzbnkn
                                            zbkdkt   =  ls_bank1-bkoinh
                                            waers    =  ls_bank1-waers
                                            zsjly = '2'
                                            shkzg    =  ls_bank1-shkzg ) .
      APPEND ls_bank TO et_bank.
    ENDLOOP.

    SELECT
i~db_key,
           h~bukrs,
           h~hbkid,
           h~hktid,
           h~banks,
           h~bankl,
           h~bank_ind,
           h~hkont,
           z~yhzh,
           i~zbkitem,
           i~zbkjyri,
           i~zbkjysj,
           i~zbkjyrit,
           i~zbkbczbs,
           i~zbkjsms,
           i~zbkfse,
           i~zbkjye,
           i~zbkjyes,
           i~zbkjyeh,
           i~zbkjyye,
           i~zbkfkhht,
           i~zbkfkr,
           i~zbkfkt,
           i~zbkskhht,
           i~zbkskr,
           i~zbkskt,
           i~zbkdkhht,
           i~zbkdkr,
           i~zbkdkt,
           i~zbkywt,
           i~zbkzy1,
           i~zbkzy2,
           i~zbkzy,
           i~zbkyt,
           i~zbkfy,
           i~zbkbz,
           i~zbkad1,
           i~zbkad2,
           i~zbkad3,
           i~kunnr,
           i~lifnr,
           i~zppzt,
           i~zppqj,
           i~waers,
           i~shkzg,
          '1' AS zsjly
       FROM ztrt3023_01 AS h  INNER JOIN ztrt3023_02 AS i ON h~db_key = i~parent_key
             INNER JOIN ztrt0013    AS z ON z~bukrs  = h~bukrs
                                                         AND z~hbkid  = h~hbkid
                                                         AND z~hktid  = h~hktid
       INTO CORRESPONDING FIELDS OF TABLE @et_bank2
      WHERE  h~bukrs  = @iv_bukrs
         AND i~zppzt  IN @r_1
         AND i~zgroup_ac  = @iv_group
         AND h~hktid IN @r_4
         AND h~hbkid IN @r_3
         AND i~shkzg IN @r_5
         AND i~dflag = @space
         AND h~dflag = @space
         AND zref_doc = @space
         AND split_flag = @space
         AND h~zly  = @space .
    IF sy-subrc = 0 .
      APPEND LINES OF et_bank2 TO et_bank.
    ENDIF.

    SELECT * FROM ztrt3023_02_cf INTO CORRESPONDING FIELDS OF TABLE et_bank3
  WHERE bukrs  = iv_bukrs
  AND zppzt  IN r_1
  AND hktid IN r_4
  AND hbkid IN r_3
  AND shkzg IN r_5
  AND zref_doc = space
  AND zgroup_ac  = iv_group   .

    LOOP AT et_bank3 INTO DATA(ls_bank3) .
      ls_bank  =  CORRESPONDING #( ls_bank3 ).
      APPEND ls_bank TO et_bank.
      CLEAR ls_bank.
    ENDLOOP.
* LOCK
    IF iv_lock IS NOT INITIAL .
      LOOP AT et_bank1 INTO ls_bank1 .
        DATA(ls_ref) =  VALUE ztrs_3028_agnref( bukrs = ls_bank1-bukrs
                                                hbkid = ls_bank1-hbkid
                                                hktid = ls_bank1-hktid
                                                yhzh  = ls_bank1-yhzh
                                                trxno  = ls_bank1-trxno ) .
        CALL METHOD zcl_tr_3024_gui=>lock_1
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.

      LOOP AT et_bank2  INTO DATA(ls_bank2)  .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank2-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_2
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.

      LOOP AT et_bank3  INTO  ls_bank3  .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank3-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_3
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.
    ENDIF.
  ENDMETHOD.


METHOD query_zz.


    DATA :  r_1 TYPE RANGE OF zbk_ppzt .
    CASE iv_zppzt .
      WHEN space.
        r_1 = VALUE #( BASE r_1 ( sign = 'I'  option  = 'EQ' low = iv_zppzt ) ) .
      WHEN abap_true .
        r_1 = VALUE #( BASE r_1 ( sign = 'I'  option  = 'NE' low = space ) ) .
      WHEN '*' .
        CLEAR r_1.
    ENDCASE .


    DATA iv_group TYPE zbk_grpac VALUE 'ZZ'.
    SELECT * FROM ztrt_bank_trans INTO CORRESPONDING FIELDS OF TABLE et_bank1
     WHERE bukrs  = iv_bukrs
       AND zppzt  IN r_1
       AND zgroup_ac  = iv_group
       AND split_flag = space.

    LOOP AT et_bank1 INTO DATA(ls_bank1) .
      DATA(ls_bank) = VALUE ztrs_bank_item( bukrs    =  ls_bank1-bukrs
                                            hbkid    =  ls_bank1-hbkid
                                            hktid    =  ls_bank1-hktid
                                            yhzh     =  ls_bank1-yhzh
                                            hkont    =  ls_bank1-hkont
                                            banks    =  ls_bank1-banks
                                            kunnr    =  ls_bank1-kunnr
                                            lifnr    =  ls_bank1-lifnr
                                            zppzt    =  ls_bank1-zppzt
                                            zppqj    =  ls_bank1-zppqj
                                            zbkitem  =  ls_bank1-trxno
                                            zbkjyri  =  ls_bank1-trxdate
                                            zbkjye   =  ls_bank1-trxamt
                                            zbkywt   =  ls_bank1-bustype_txt
                                            zbkyt    =  ls_bank1-usage_txt
                                            zbkzy    =  ls_bank1-abstract_txt
                                            zbkfy    =  ls_bank1-postscript_txt
                                            zbkbz    =  ls_bank1-comment_txt
                                            zbkdkhht =  ls_bank1-bzbnka
                                            zbkdkr   =  ls_bank1-bzbnkn
                                            zbkdkt   =  ls_bank1-bkoinh
                                            waers    =  ls_bank1-waers
                                            zsjly    =  '2'
                                            shkzg    =  ls_bank1-shkzg
                                            ref_db_key = ls_bank1-ref_db_key ) .
      APPEND ls_bank TO et_bank.
    ENDLOOP.


    SELECT i~db_key,
           h~bukrs,
           h~hbkid,
           h~hktid,
           h~banks,
           h~bankl,
           h~bank_ind,
           h~hkont,
           z~yhzh,
           i~zbkitem,
           i~zbkjyri,
           i~zbkjysj,
           i~zbkjyrit,
           i~zbkbczbs,
           i~zbkjsms,
           i~zbkfse,
           i~zbkjye,
           i~zbkjyes,
           i~zbkjyeh,
           i~zbkjyye,
           i~zbkfkhht,
           i~zbkfkr,
           i~zbkfkt,
           i~zbkskhht,
           i~zbkskr,
           i~zbkskt,
           i~zbkdkhht,
           i~zbkdkr,
           i~zbkdkt,
           i~zbkywt,
           i~zbkzy1,
           i~zbkzy2,
           i~zbkzy,
           i~zbkyt,
           i~zbkfy,
           i~zbkbz,
           i~zbkad1,
           i~zbkad2,
           i~zbkad3,
           i~kunnr,
           i~lifnr,
           i~zppzt,
           i~zppqj,
           i~waers,
           i~shkzg,
          '1' AS zsjly
       FROM ztrt3023_01 AS h  INNER JOIN ztrt3023_02 AS i ON h~db_key = i~parent_key
                                                            INNER JOIN ztrt0013    AS z ON z~bukrs  = h~bukrs
                                                         AND z~hbkid  = h~hbkid
                                                         AND z~hktid  = h~hktid
       INTO CORRESPONDING FIELDS OF TABLE @et_bank2
      WHERE  h~bukrs  = @iv_bukrs
         AND i~zppzt  IN @r_1
         AND i~zgroup_ac  = @iv_group
         AND i~split_flag  = @space
         AND i~dflag = @space
         AND h~dflag = @space
         AND h~zly  = @space .
    IF sy-subrc = 0 .
      APPEND LINES OF et_bank2 TO et_bank.
    ENDIF.

    SELECT * FROM ztrt3023_02_cf INTO CORRESPONDING FIELDS OF TABLE et_bank3
  WHERE bukrs  = iv_bukrs
  AND zppzt  IN r_1
  AND zgroup_ac  = iv_group .

    LOOP AT et_bank3 INTO DATA(ls_bank3) .
      ls_bank  =  CORRESPONDING #( ls_bank3 ).
      APPEND ls_bank TO et_bank.
      CLEAR ls_bank.
    ENDLOOP.
* LOCK
    IF iv_lock IS NOT INITIAL .
      LOOP AT et_bank1 INTO ls_bank1 .
        DATA(ls_ref) =  VALUE ztrs_3028_agnref( bukrs = ls_bank1-bukrs
                                                hbkid = ls_bank1-hbkid
                                                hktid = ls_bank1-hktid
                                                yhzh  = ls_bank1-yhzh
                                                trxno  = ls_bank1-trxno ) .
        CALL METHOD zcl_tr_3024_gui=>lock_1
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.

      LOOP AT et_bank3  INTO  ls_bank3  .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank3-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_3
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.
    ENDIF.
  ENDMETHOD.


METHOD qurey_21.

    DATA :  r_1 TYPE RANGE OF zbk_ppzt .
    CASE iv_zppzt .
      WHEN space.
        r_1 = VALUE #( BASE r_1 ( sign = 'I'  option  = 'EQ' low = iv_zppzt ) ) .
      WHEN abap_true .
        r_1 = VALUE #( BASE r_1 ( sign = 'I'  option  = 'NE' low = space ) ) .
      WHEN '*' .
        CLEAR r_1.
    ENDCASE .


    SELECT * FROM ztrt_bank_trans INTO CORRESPONDING FIELDS OF TABLE et_bank1
       WHERE bukrs  = iv_bukrs
         AND hbkid  = iv_hbkid
         AND hktid  = iv_hktid
         AND shkzg  = iv_shkzg
         AND zppzt  IN r_1
         AND split_flag      = space
         AND zref_doc = space
         AND zgroup_ac  = iv_group .

    LOOP AT et_bank1 INTO DATA(ls_bank1) .
      DATA(ls_bank) = VALUE ztrs_bank_item( bukrs    =  ls_bank1-bukrs
                                            hbkid    =  ls_bank1-hbkid
                                            hktid    =  ls_bank1-hktid
                                            hkont    =  ls_bank1-hkont
                                            banks    =  ls_bank1-banks
                                            yhzh     =  ls_bank1-yhzh
                                            kunnr    =  ls_bank1-kunnr
                                            lifnr    =  ls_bank1-lifnr
                                            zppzt    =  ls_bank1-zppzt
                                            zppqj    =  ls_bank1-zppqj
                                            zbkitem  =  ls_bank1-trxno
                                            zbkjyri  =  ls_bank1-trxdate
                                            zbkjye   =  ls_bank1-trxamt
                                            zbkywt   =  ls_bank1-bustype_txt
                                            zbkyt    =  ls_bank1-usage_txt
                                            zbkzy    =  ls_bank1-abstract_txt
                                            zbkfy    =  ls_bank1-postscript_txt
                                            zbkbz    =  ls_bank1-comment_txt
                                            zbkdkhht =  ls_bank1-bzbnka
                                            zbkdkr   =  ls_bank1-bzbnkn
                                            zbkdkt   =  ls_bank1-bkoinh
                                            waers    =  ls_bank1-waers
                                            zsjly    =  '2'
                                            shkzg    =  ls_bank1-shkzg ) .
      APPEND ls_bank TO et_bank.
    ENDLOOP.

    SELECT i~db_key,
           h~bukrs,
           h~hbkid,
           h~hktid,
           h~banks,
           h~bankl,
           h~bank_ind,
           h~hkont,
           z~yhzh,
           i~zbkitem,
           i~zbkjyri,
           i~zbkjysj,
           i~zbkjyrit,
           i~zbkbczbs,
           i~zbkjsms,
           i~zbkfse,
           i~zbkjye,
           i~zbkjyes,
           i~zbkjyeh,
           i~zbkjyye,
           i~zbkfkhht,
           i~zbkfkr,
           i~zbkfkt,
           i~zbkskhht,
           i~zbkskr,
           i~zbkskt,
           i~zbkdkhht,
           i~zbkdkr,
           i~zbkdkt,
           i~zbkywt,
           i~zbkzy1,
           i~zbkzy2,
           i~zbkzy,
           i~zbkyt,
           i~zbkfy,
           i~zbkbz,
           i~zbkad1,
           i~zbkad2,
           i~zbkad3,
           i~kunnr,
           i~lifnr,
           i~zppzt,
           i~zppqj,
           i~waers,
           i~shkzg,
          '1' AS zsjly
       FROM ztrt3023_01 AS h  INNER JOIN ztrt3023_02 AS i ON h~db_key = i~parent_key
                              INNER JOIN ztrt0013    AS z ON z~bukrs  = h~bukrs
                                                         AND z~hbkid  = h~hbkid
                                                         AND z~hktid  = h~hktid
       INTO CORRESPONDING FIELDS OF TABLE @et_bank2
      WHERE  h~bukrs  = @iv_bukrs
         AND h~hbkid  = @iv_hbkid
         AND h~hktid  = @iv_hktid
         AND i~shkzg  = @iv_shkzg
         AND i~zppzt  IN @r_1
         AND i~zgroup_ac  = @iv_group
         AND i~dflag = @space
         AND h~dflag = @space
         AND zref_doc = @space
         AND split_flag      = @space
         AND h~zly  = @space .
    IF sy-subrc = 0 .
      APPEND LINES OF et_bank2 TO et_bank.
    ENDIF.

    SELECT * FROM ztrt3023_02_cf INTO CORRESPONDING FIELDS OF TABLE et_bank3
         WHERE bukrs  = iv_bukrs
           AND hbkid  = iv_hbkid
           AND hktid  = iv_hktid
           AND shkzg  = iv_shkzg
           AND zppzt  IN r_1
           AND zref_doc = space
           AND zgroup_ac  = iv_group .

    LOOP AT et_bank3 INTO DATA(ls_bank3) .
      ls_bank  =  CORRESPONDING #( ls_bank3 ).
      APPEND ls_bank TO et_bank.
      CLEAR ls_bank.
    ENDLOOP.

* LOCK
    IF iv_lock IS NOT INITIAL .

      LOOP AT et_bank1 INTO ls_bank1 .
        DATA(ls_ref) =  VALUE ztrs_3028_agnref( bukrs = ls_bank1-bukrs
                                                hbkid = ls_bank1-hbkid
                                                hktid = ls_bank1-hktid
                                                yhzh  = ls_bank1-yhzh
                                                trxno  = ls_bank1-trxno ) .
        CALL METHOD zcl_tr_3024_gui=>lock_1
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.

      LOOP AT et_bank2  INTO DATA(ls_bank2)  .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank2-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_2
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.
      LOOP AT et_bank3  INTO  ls_bank3  .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank3-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_3
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.
    ENDIF.


    IF iv_zz = abap_true.
      CALL METHOD zcl_tr_3024_gui=>query_zz
        EXPORTING
          iv_lock  = iv_lock
          iv_bukrs = iv_bukrs
          iv_zppzt = space
        IMPORTING
          et_bank1 = et_bank1
          et_bank2 = et_bank2
          et_bank  = et_bank
        EXCEPTIONS
          err      = 1
          OTHERS   = 2.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
      WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD qurey_22.

    DATA :  r_1 TYPE RANGE OF zbk_ppzt .
    CASE iv_zppzt .
      WHEN space.
        r_1 = VALUE #( BASE r_1 ( sign = 'I'  option  = 'EQ' low = iv_zppzt ) ) .
      WHEN abap_true .
        r_1 = VALUE #( BASE r_1 ( sign = 'I'  option  = 'NE' low = space ) ) .
      WHEN '*' .
        CLEAR r_1.
    ENDCASE .

    DATA :  r_2 TYPE RANGE OF lifnr .
    CASE iv_lifnr.
      WHEN space.
        CLEAR r_2.
      WHEN OTHERS .
        r_2 = VALUE #( BASE r_2 ( sign = 'I'  option  = 'EQ' low = iv_lifnr ) ) .
    ENDCASE .


    DATA :  r_3 TYPE RANGE OF hbkid.
    CASE iv_hbkid .
      WHEN space.
        CLEAR r_3.
      WHEN OTHERS .
        r_3 = VALUE #( BASE r_3 ( sign = 'I'  option  = 'EQ' low = iv_hbkid ) ) .
    ENDCASE .

    DATA :  r_4 TYPE RANGE OF hktid.
    CASE iv_hktid  .
      WHEN space.
        CLEAR r_4.
      WHEN OTHERS .
        r_4 = VALUE #( BASE r_4 ( sign = 'I'  option  = 'EQ' low = iv_hktid ) ) .
    ENDCASE .

    DATA :  r_5 TYPE RANGE OF shkzg  .
    CASE iv_shkzg   .
      WHEN space.
        CLEAR r_5.
      WHEN OTHERS .
        r_5 = VALUE #( BASE r_5 ( sign = 'I'  option  = 'EQ' low = iv_shkzg  ) ) .
    ENDCASE .

    DATA :  r_6 TYPE RANGE OF kunnr .
    CASE iv_kunnr.
      WHEN space.
        CLEAR r_6.
      WHEN OTHERS .
        r_6 = VALUE #( BASE r_6 ( sign = 'I'  option  = 'EQ' low = iv_kunnr ) ) .
    ENDCASE .

    SELECT * FROM ztrt_bank_trans INTO CORRESPONDING FIELDS OF TABLE et_bank1
     WHERE bukrs  = iv_bukrs
       AND lifnr IN r_2
       AND zppzt IN r_1
       AND hktid IN r_4
       AND hbkid IN r_3
       AND shkzg IN r_5
       AND kunnr IN r_6
       AND zref_doc = space
       AND split_flag = space
       AND zgroup_ac  = iv_group .


    LOOP AT et_bank1 INTO DATA(ls_bank1) .
      DATA(ls_bank) = VALUE ztrs_bank_item( bukrs    =  ls_bank1-bukrs
                                            hbkid    =  ls_bank1-hbkid
                                            hktid    =  ls_bank1-hktid
                                            hkont    =  ls_bank1-hkont
                                            banks    =  ls_bank1-banks
                                            yhzh     =  ls_bank1-yhzh
                                            kunnr    =  ls_bank1-kunnr
                                            lifnr    =  ls_bank1-lifnr
                                            zppzt    =  ls_bank1-zppzt
                                            zppqj    =  ls_bank1-zppqj
                                            zbkitem  =  ls_bank1-trxno
                                            zbkjyri  =  ls_bank1-trxdate
                                            zbkjye   =  ls_bank1-trxamt
                                            zbkywt   =  ls_bank1-bustype_txt
                                            zbkyt    =  ls_bank1-usage_txt
                                            zbkzy    =  ls_bank1-abstract_txt
                                            zbkfy    =  ls_bank1-postscript_txt
                                            zbkbz    =  ls_bank1-comment_txt
                                            zbkdkhht =  ls_bank1-bzbnka
                                            zbkdkr   =  ls_bank1-bzbnkn
                                            zbkdkt   =  ls_bank1-bkoinh
                                            waers    =  ls_bank1-waers
                                            zsjly = '2'
                                            shkzg    =  ls_bank1-shkzg ) .
      APPEND ls_bank TO et_bank.
    ENDLOOP.


    SELECT
i~db_key,
           h~bukrs,
           h~hbkid,
           h~hktid,
           h~banks,
           h~bankl,
           h~bank_ind,
           h~hkont,
           z~yhzh,
           i~zbkitem,
           i~zbkjyri,
           i~zbkjysj,
           i~zbkjyrit,
           i~zbkbczbs,
           i~zbkjsms,
           i~zbkfse,
           i~zbkjye,
           i~zbkjyes,
           i~zbkjyeh,
           i~zbkjyye,
           i~zbkfkhht,
           i~zbkfkr,
           i~zbkfkt,
           i~zbkskhht,
           i~zbkskr,
           i~zbkskt,
           i~zbkdkhht,
           i~zbkdkr,
           i~zbkdkt,
           i~zbkywt,
           i~zbkzy1,
           i~zbkzy2,
           i~zbkzy,
           i~zbkyt,
           i~zbkfy,
           i~zbkbz,
           i~zbkad1,
           i~zbkad2,
           i~zbkad3,
           i~kunnr,
           i~lifnr,
           i~zppzt,
           i~zppqj,
           i~waers,
           i~shkzg,
          '1' AS zsjly
     FROM ztrt3023_01 AS h  INNER JOIN ztrt3023_02 AS i ON h~db_key = i~parent_key
                                    INNER JOIN ztrt0013    AS z ON z~bukrs  = h~bukrs
                                                         AND z~hbkid  = h~hbkid
                                                         AND z~hktid  = h~hktid
     INTO CORRESPONDING FIELDS OF TABLE @et_bank2
    WHERE  h~bukrs  = @iv_bukrs
       AND i~zppzt  IN @r_1
       AND i~zgroup_ac  = @iv_group
       AND ( ( lifnr2 IN @r_2 AND lifnr = @space ) OR ( lifnr <> @space AND lifnr IN @r_2 ) )
       AND ( ( kunnr2 IN @r_6 AND kunnr = @space ) OR ( kunnr <> @space AND kunnr IN @r_6 ) )
       AND i~shkzg IN @r_5
       AND i~dflag = @space
       AND h~dflag = @space
       AND h~hktid IN @r_4
       AND h~hbkid IN @r_3
       AND zref_doc = @space
       AND split_flag = @space
       AND h~zly  = @space .

    IF sy-subrc = 0 .
      APPEND LINES OF et_bank2 TO et_bank.
    ENDIF.

    SELECT * FROM ztrt3023_02_cf INTO CORRESPONDING FIELDS OF TABLE et_bank3
  WHERE bukrs  = iv_bukrs
  AND lifnr IN r_2
  AND zppzt IN r_1
  AND hktid IN r_4
  AND hbkid IN r_3
  AND shkzg IN r_5
  AND kunnr IN r_6
  AND zref_doc = space
  AND zgroup_ac  = iv_group.

    LOOP AT et_bank3 INTO DATA(ls_bank3) .
      ls_bank  =  CORRESPONDING #( ls_bank3 ).
      APPEND ls_bank TO et_bank.
      CLEAR ls_bank.
    ENDLOOP.
* LOCK
    IF iv_lock IS NOT INITIAL .
      LOOP AT et_bank1 INTO ls_bank1 .
        DATA(ls_ref) =  VALUE ztrs_3028_agnref( bukrs = ls_bank1-bukrs
                                                hbkid = ls_bank1-hbkid
                                                hktid = ls_bank1-hktid
                                                yhzh  = ls_bank1-yhzh
                                                trxno  = ls_bank1-trxno ) .
        CALL METHOD zcl_tr_3024_gui=>lock_1
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.

      LOOP AT et_bank2  INTO DATA(ls_bank2)  .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank2-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_2
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.
      LOOP AT et_bank3  INTO  ls_bank3  .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank3-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_3
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.
    ENDIF.

    IF iv_zz = abap_true.
      CALL METHOD zcl_tr_3024_gui=>query_zz
        EXPORTING
          iv_lock  = iv_lock
          iv_bukrs = iv_bukrs
          iv_zppzt = space
        IMPORTING
          et_bank1 = et_bank1
          et_bank2 = et_bank2
          et_bank  = et_bank
        EXCEPTIONS
          err      = 1
          OTHERS   = 2.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
      WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD qurey_23.

    DATA :  r_1 TYPE RANGE OF zbk_ppzt .
    CASE iv_zppzt .
      WHEN space.
        r_1 = VALUE #( BASE r_1 ( sign = 'I'  option  = 'EQ' low = iv_zppzt ) ) .
      WHEN abap_true .
        r_1 = VALUE #( BASE r_1 ( sign = 'I'  option  = 'NE' low = space ) ) .
      WHEN '*' .
        CLEAR r_1.
    ENDCASE .

    DATA :  r_2 TYPE RANGE OF kunnr.
    CASE iv_kunnr.
      WHEN space.
        CLEAR r_2.
      WHEN OTHERS .
        r_2 = VALUE #( BASE r_2 ( sign = 'I'  option  = 'EQ' low = iv_kunnr ) ) .
    ENDCASE .

    DATA :  r_3 TYPE RANGE OF hbkid.
    CASE iv_hbkid .
      WHEN space.
        CLEAR r_3.
      WHEN OTHERS .
        r_3 = VALUE #( BASE r_3 ( sign = 'I'  option  = 'EQ' low = iv_hbkid ) ) .
    ENDCASE .

    DATA :  r_4 TYPE RANGE OF hktid.
    CASE iv_hktid  .
      WHEN space.
        CLEAR r_4.
      WHEN OTHERS .
        r_4 = VALUE #( BASE r_4 ( sign = 'I'  option  = 'EQ' low = iv_hktid ) ) .
    ENDCASE .

    DATA :  r_5 TYPE RANGE OF shkzg  .
    CASE iv_shkzg   .
      WHEN space.
        CLEAR r_5.
      WHEN OTHERS .
        r_5 = VALUE #( BASE r_5 ( sign = 'I'  option  = 'EQ' low = iv_shkzg  ) ) .
    ENDCASE .

    SELECT * FROM ztrt_bank_trans INTO CORRESPONDING FIELDS OF TABLE et_bank1
     WHERE bukrs  = iv_bukrs
       AND kunnr  IN r_2
       AND hbkid IN r_3
       AND hktid IN r_4
       AND zppzt  IN r_1
       AND shkzg  IN r_5
       AND zref_doc = space
       AND split_flag = space
       AND zgroup_ac  = iv_group .


    LOOP AT et_bank1 INTO DATA(ls_bank1) .
      DATA(ls_bank) = VALUE ztrs_bank_item( bukrs    =  ls_bank1-bukrs
                                            hbkid    =  ls_bank1-hbkid
                                            hktid    =  ls_bank1-hktid
                                            hkont    =  ls_bank1-hkont
                                            banks    =  ls_bank1-banks
                                            yhzh     =  ls_bank1-yhzh
                                            kunnr    =  ls_bank1-kunnr
                                            lifnr    =  ls_bank1-lifnr
                                            zppzt    =  ls_bank1-zppzt
                                            zppqj    =  ls_bank1-zppqj
                                            zbkitem  =  ls_bank1-trxno
                                            zbkjyri  =  ls_bank1-trxdate
                                            zbkjye   =  ls_bank1-trxamt
                                            zbkywt   =  ls_bank1-bustype_txt
                                            zbkyt    =  ls_bank1-usage_txt
                                            zbkzy    =  ls_bank1-abstract_txt
                                            zbkfy    =  ls_bank1-postscript_txt
                                            zbkbz    =  ls_bank1-comment_txt
                                            zbkdkhht =  ls_bank1-bzbnka
                                            zbkdkr   =  ls_bank1-bzbnkn
                                            zbkdkt   =  ls_bank1-bkoinh
                                            waers    =  ls_bank1-waers
                                            zsjly    =  '2'
                                            shkzg    =  ls_bank1-shkzg
                                            bankref  =  ls_bank1-bankref
                                            db_key   =  ls_bank1-db_key ) .
      APPEND ls_bank TO et_bank.
    ENDLOOP.
    SELECT   i~db_key,
             h~bukrs,
             h~hbkid,
             h~hktid,
             h~banks,
             h~bankl,
             h~bank_ind,
             h~hkont,
             z~yhzh,
             i~zbkitem,
             i~zbkjyri,
             i~zbkjysj,
             i~zbkjyrit,
             i~zbkbczbs,
             i~zbkjsms,
             i~zbkfse,
             i~zbkjye,
             i~zbkjyes,
             i~zbkjyeh,
             i~zbkjyye,
             i~zbkfkhht,
             i~zbkfkr,
             i~zbkfkt,
             i~zbkskhht,
             i~zbkskr,
             i~zbkskt,
             i~zbkdkhht,
             i~zbkdkr,
             i~zbkdkt,
             i~zbkywt,
             i~zbkzy1,
             i~zbkzy2,
             i~zbkzy,
             i~zbkyt,
             i~zbkfy,
             i~zbkbz,
             i~zbkad1,
             i~zbkad2,
             i~zbkad3,
             i~kunnr,
             i~lifnr,
             i~zppzt,
             i~zppqj,
             i~waers,
             i~shkzg,
            '1' AS zsjly,
             i~bankref
         FROM ztrt3023_01 AS h  INNER JOIN ztrt3023_02 AS i ON h~db_key = i~parent_key
                                            INNER JOIN ztrt0013    AS z ON z~bukrs  = h~bukrs
                                                           AND z~hbkid  = h~hbkid
                                                           AND z~hktid  = h~hktid
         INTO CORRESPONDING FIELDS OF TABLE @et_bank2
        WHERE  h~bukrs  = @iv_bukrs
           AND i~zppzt  IN @r_1
           AND ( ( kunnr2 IN @r_2 AND kunnr = @space ) OR ( kunnr <> @space AND kunnr IN @r_2 ) )
           AND h~hbkid IN @r_3
           AND h~hktid IN @r_4
           AND i~shkzg  IN @r_5
           AND i~zgroup_ac  = @iv_group
           AND i~dflag = @space
           AND h~dflag = @space
           AND zref_doc = @space
         AND split_flag = @space
           AND h~zly  = @space .

    IF sy-subrc = 0 .
      APPEND LINES OF et_bank2 TO et_bank.
    ENDIF.

    SELECT * FROM ztrt3023_02_cf INTO CORRESPONDING FIELDS OF TABLE et_bank3
     WHERE bukrs  = iv_bukrs
       AND kunnr  IN r_2
       AND hbkid IN r_3
       AND hktid IN r_4
       AND zppzt  IN r_1
       AND shkzg  IN r_5
       AND zref_doc = space
       AND zgroup_ac  = iv_group .

    LOOP AT et_bank3 INTO DATA(ls_bank3) .
      ls_bank  =  CORRESPONDING #( ls_bank3 ).
      APPEND ls_bank TO et_bank.
      CLEAR ls_bank.
    ENDLOOP.
* LOCK
    IF iv_lock IS NOT INITIAL .
      LOOP AT et_bank1 INTO ls_bank1 .
        DATA(ls_ref) =  VALUE ztrs_3028_agnref( bukrs = ls_bank1-bukrs
                                                hbkid = ls_bank1-hbkid
                                                hktid = ls_bank1-hktid
                                                yhzh  = ls_bank1-yhzh
                                                trxno  = ls_bank1-trxno ) .
        CALL METHOD zcl_tr_3024_gui=>lock_1
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.

      LOOP AT et_bank2  INTO DATA(ls_bank2)  .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank2-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_2
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.

      LOOP AT et_bank3  INTO ls_bank3  .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank3-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_3
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.

    ENDIF.

    IF iv_zz = abap_true.
      CALL METHOD zcl_tr_3024_gui=>query_zz
        EXPORTING
          iv_lock  = iv_lock
          iv_bukrs = iv_bukrs
          iv_zppzt = space
        IMPORTING
          et_bank1 = et_bank1
          et_bank2 = et_bank2
          et_bank  = et_bank
        EXCEPTIONS
          err      = 1
          OTHERS   = 2.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
      WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD qurey_24.

    DATA :  r_1 TYPE RANGE OF zbk_ppzt .
    CASE iv_zppzt .
      WHEN space.
        r_1 = VALUE #( BASE r_1 ( sign = 'I'  option  = 'EQ' low = iv_zppzt ) ) .
      WHEN abap_true .
        r_1 = VALUE #( BASE r_1 ( sign = 'I'  option  = 'NE' low = space ) ) .
      WHEN '*' .
        CLEAR r_1.
    ENDCASE .

    DATA :  r_2 TYPE RANGE OF lifnr .
    CASE iv_lifnr.
      WHEN space.
        CLEAR r_2.
      WHEN OTHERS .
        r_2 = VALUE #( BASE r_2 ( sign = 'I'  option  = 'EQ' low = iv_lifnr ) ) .
    ENDCASE .

    DATA :  r_6 TYPE RANGE OF kunnr .
    CASE iv_kunnr.
      WHEN space.
        CLEAR r_6.
      WHEN OTHERS .
        r_6 = VALUE #( BASE r_6 ( sign = 'I'  option  = 'EQ' low = iv_kunnr ) ) .
    ENDCASE .

    SELECT * FROM ztrt_bank_trans INTO CORRESPONDING FIELDS OF TABLE et_bank1
     WHERE bukrs  = iv_bukrs
       AND zppzt  IN r_1
       AND zref_doc = space
       AND split_flag = space
       AND ( ( kunnr2 IN r_6 AND kunnr = space ) OR ( kunnr <> space AND kunnr IN r_6 ) )
       AND ( ( lifnr2 IN r_2 AND lifnr = space ) OR ( lifnr <> space AND lifnr IN r_2 ) )
       AND zgroup_ac  = iv_group .

    LOOP AT et_bank1 INTO DATA(ls_bank1) .
      DATA(ls_bank) = VALUE ztrs_bank_item( bukrs    =  ls_bank1-bukrs
                                            hbkid    =  ls_bank1-hbkid
                                            hktid    =  ls_bank1-hktid
                                            hkont    =  ls_bank1-hkont
                                            banks    =  ls_bank1-banks
                                            yhzh     =  ls_bank1-yhzh
                                            kunnr    =  ls_bank1-kunnr
                                            lifnr    =  ls_bank1-lifnr
                                            zppzt    =  ls_bank1-zppzt
                                            zppqj    =  ls_bank1-zppqj
                                            zbkitem  =  ls_bank1-trxno
                                            zbkjyri  =  ls_bank1-trxdate
                                            zbkjye   =  ls_bank1-trxamt
                                            zbkywt   =  ls_bank1-bustype_txt
                                            zbkyt    =  ls_bank1-usage_txt
                                            zbkzy    =  ls_bank1-abstract_txt
                                            zbkfy    =  ls_bank1-postscript_txt
                                            zbkbz    =  ls_bank1-comment_txt
                                            zbkdkhht =  ls_bank1-bzbnka
                                            zbkdkr   =  ls_bank1-bzbnkn
                                            zbkdkt   =  ls_bank1-bkoinh
                                            waers    =  ls_bank1-waers
                                            zsjly = '2'
                                            shkzg    =  ls_bank1-shkzg
                                            bankref  =  ls_bank1-bankref
                                            ref_db_key = ls_bank1-ref_db_key ) .
      APPEND ls_bank TO et_bank.
    ENDLOOP.

    SELECT
i~db_key,
           h~bukrs,
           h~hbkid,
           h~hktid,
           h~banks,
           h~bankl,
           h~bank_ind,
           h~hkont,
           z~yhzh,
           i~zbkitem,
           i~zbkjyri,
           i~zbkjysj,
           i~zbkjyrit,
           i~zbkbczbs,
           i~zbkjsms,
           i~zbkfse,
           i~zbkjye,
           i~zbkjyes,
           i~zbkjyeh,
           i~zbkjyye,
           i~zbkfkhht,
           i~zbkfkr,
           i~zbkfkt,
           i~zbkskhht,
           i~zbkskr,
           i~zbkskt,
           i~zbkdkhht,
           i~zbkdkr,
           i~zbkdkt,
           i~zbkywt,
           i~zbkzy1,
           i~zbkzy2,
           i~zbkzy,
           i~zbkyt,
           i~zbkfy,
           i~zbkbz,
           i~zbkad1,
           i~zbkad2,
           i~zbkad3,
           i~kunnr,
           i~lifnr,
           i~zppzt,
           i~zppqj,
           i~waers,
           i~shkzg,
          '1' AS zsjly,
           i~bankref
       FROM ztrt3023_01 AS h  INNER JOIN ztrt3023_02 AS i ON h~db_key = i~parent_key
                                                INNER JOIN ztrt0013    AS z ON z~bukrs  = h~bukrs
                                                         AND z~hbkid  = h~hbkid
                                                         AND z~hktid  = h~hktid
       INTO CORRESPONDING FIELDS OF TABLE @et_bank2
      WHERE  h~bukrs  = @iv_bukrs
         AND i~zppzt IN @r_1
         AND i~zgroup_ac  = @iv_group
         AND ( ( i~kunnr2 IN @r_6 AND i~kunnr = @space ) OR ( i~kunnr <> @space AND i~kunnr IN @r_6 ) )
         AND ( ( lifnr2 IN @r_2 AND lifnr = @space ) OR ( lifnr <> @space AND lifnr IN @r_2 ) )
         AND i~dflag = @space
         AND h~dflag = @space
         AND i~zref_doc = @space
         AND split_flag = @space
         AND h~zly  = @space .
    IF sy-subrc = 0 .
      APPEND LINES OF et_bank2 TO et_bank.
    ENDIF.

    SELECT * FROM ztrt3023_02_cf INTO CORRESPONDING FIELDS OF TABLE et_bank3
  WHERE bukrs  = iv_bukrs
  AND zppzt  IN r_1
  AND zref_doc = space
  AND ( ( kunnr2 IN r_6 AND kunnr = space ) OR ( kunnr <> space AND kunnr IN r_6 ) )
  AND ( ( lifnr2 IN r_2 AND lifnr = space ) OR ( lifnr <> space AND lifnr IN r_2 ) )
  AND zgroup_ac  = iv_group .

    LOOP AT et_bank3 INTO DATA(ls_bank3) .
      ls_bank  =  CORRESPONDING #( ls_bank3 ).
      APPEND ls_bank TO et_bank.
      CLEAR ls_bank.
    ENDLOOP.
* LOCK
    IF iv_lock IS NOT INITIAL .
      LOOP AT et_bank1 INTO ls_bank1 .
        DATA(ls_ref) =  VALUE ztrs_3028_agnref( bukrs = ls_bank1-bukrs
                                                hbkid = ls_bank1-hbkid
                                                hktid = ls_bank1-hktid
                                                yhzh  = ls_bank1-yhzh
                                                trxno  = ls_bank1-trxno ) .
        CALL METHOD zcl_tr_3024_gui=>lock_1
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.

      LOOP AT et_bank2  INTO DATA(ls_bank2)  .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank2-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_2
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.

      LOOP AT et_bank3  INTO  ls_bank3  .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank3-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_3
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.
    ENDIF.

    IF iv_zz = abap_true.
      CALL METHOD zcl_tr_3024_gui=>query_zz
        EXPORTING
          iv_lock  = iv_lock
          iv_bukrs = iv_bukrs
          iv_zppzt = space
        IMPORTING
          et_bank1 = et_bank1
          et_bank2 = et_bank2
          et_bank  = et_bank
        EXCEPTIONS
          err      = 1
          OTHERS   = 2.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
      WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD qurey_25.

    DATA :  r_1 TYPE RANGE OF zbk_ppzt .
    CASE iv_zppzt .
      WHEN space.
        r_1 = VALUE #( BASE r_1 ( sign = 'I'  option  = 'EQ' low = iv_zppzt ) ) .
      WHEN abap_true .
        r_1 = VALUE #( BASE r_1 ( sign = 'I'  option  = 'NE' low = space ) ) .
      WHEN '*' .
        CLEAR r_1.
    ENDCASE .

    SELECT * FROM ztrt_bank_trans INTO CORRESPONDING FIELDS OF TABLE et_bank1
     WHERE bukrs  = iv_bukrs
       AND zppzt  IN r_1
       AND zref_doc = space
       AND split_flag = space
       AND zgroup_ac  = iv_group .

    LOOP AT et_bank1 INTO DATA(ls_bank1) .
      DATA(ls_bank) = VALUE ztrs_bank_item( bukrs    =  ls_bank1-bukrs
                                            hbkid    =  ls_bank1-hbkid
                                            hktid    =  ls_bank1-hktid
                                            yhzh     =  ls_bank1-yhzh
                                            kunnr    =  ls_bank1-kunnr
                                            hkont    =  ls_bank1-hkont
                                            banks    =  ls_bank1-banks
                                            lifnr    =  ls_bank1-lifnr
                                            zppzt    =  ls_bank1-zppzt
                                            zppqj    =  ls_bank1-zppqj
                                            zbkitem  =  ls_bank1-trxno
                                            zbkjyri  =  ls_bank1-trxdate
                                            zbkjye   =  ls_bank1-trxamt
                                            zbkywt   =  ls_bank1-bustype_txt
                                            zbkyt    =  ls_bank1-usage_txt
                                            zbkzy    =  ls_bank1-abstract_txt
                                            zbkfy    =  ls_bank1-postscript_txt
                                            zbkbz    =  ls_bank1-comment_txt
                                            zbkdkhht =  ls_bank1-bzbnka
                                            zbkdkr   =  ls_bank1-bzbnkn
                                            zbkdkt   =  ls_bank1-bkoinh
                                            waers    =  ls_bank1-waers
                                            zsjly = '2'
                                            shkzg    =  ls_bank1-shkzg ) .
      APPEND ls_bank TO et_bank.
    ENDLOOP.

    SELECT
i~db_key,
           h~bukrs,
           h~hbkid,
           h~hktid,
           h~banks,
           h~bankl,
           h~bank_ind,
           h~hkont,
           z~yhzh,
           i~zbkitem,
           i~zbkjyri,
           i~zbkjysj,
           i~zbkjyrit,
           i~zbkbczbs,
           i~zbkjsms,
           i~zbkfse,
           i~zbkjye,
           i~zbkjyes,
           i~zbkjyeh,
           i~zbkjyye,
           i~zbkfkhht,
           i~zbkfkr,
           i~zbkfkt,
           i~zbkskhht,
           i~zbkskr,
           i~zbkskt,
           i~zbkdkhht,
           i~zbkdkr,
           i~zbkdkt,
           i~zbkywt,
           i~zbkzy1,
           i~zbkzy2,
           i~zbkzy,
           i~zbkyt,
           i~zbkfy,
           i~zbkbz,
           i~zbkad1,
           i~zbkad2,
           i~zbkad3,
           i~kunnr,
           i~lifnr,
           i~zppzt,
           i~zppqj,
           i~waers,
           i~shkzg,
          '1' AS zsjly
       FROM ztrt3023_01 AS h  INNER JOIN ztrt3023_02 AS i ON h~db_key = i~parent_key
                                                      INNER JOIN ztrt0013    AS z ON z~bukrs  = h~bukrs
                                                         AND z~hbkid  = h~hbkid
                                                         AND z~hktid  = h~hktid
       INTO CORRESPONDING FIELDS OF TABLE @et_bank2
      WHERE  h~bukrs  = @iv_bukrs
         AND i~zppzt  IN @r_1
         AND i~zgroup_ac  = @iv_group
         AND i~zref_doc = @space
         AND i~split_flag = @space
         AND i~dflag = @space
         AND h~dflag = @space
         AND h~zly  = @space .
    IF sy-subrc = 0 .
      APPEND LINES OF et_bank2 TO et_bank.
    ENDIF.

    SELECT * FROM ztrt3023_02_cf INTO CORRESPONDING FIELDS OF TABLE et_bank3
      WHERE bukrs  = iv_bukrs
      AND zppzt  IN r_1
      AND zref_doc = space
      AND zgroup_ac  = iv_group .


    LOOP AT et_bank3 INTO DATA(ls_bank3) .
      ls_bank  =  CORRESPONDING #( ls_bank3 ).
      APPEND ls_bank TO et_bank.
      CLEAR ls_bank.
    ENDLOOP.
* LOCK
    IF iv_lock IS NOT INITIAL .
      LOOP AT et_bank1 INTO ls_bank1 .
        DATA(ls_ref) =  VALUE ztrs_3028_agnref( bukrs = ls_bank1-bukrs
                                                hbkid = ls_bank1-hbkid
                                                hktid = ls_bank1-hktid
                                                yhzh  = ls_bank1-yhzh
                                                trxno  = ls_bank1-trxno ) .
        CALL METHOD zcl_tr_3024_gui=>lock_1
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.

      LOOP AT et_bank2  INTO DATA(ls_bank2)  .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank2-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_2
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.
      LOOP AT et_bank3  INTO  ls_bank3  .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank3-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_3
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.
    ENDIF.

    IF iv_zz = abap_true.
      CALL METHOD zcl_tr_3024_gui=>query_zz
        EXPORTING
          iv_lock  = iv_lock
          iv_bukrs = iv_bukrs
          iv_zppzt = space
        IMPORTING
          et_bank1 = et_bank1
          et_bank2 = et_bank2
          et_bank  = et_bank
        EXCEPTIONS
          err      = 1
          OTHERS   = 2.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
      WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD qurey_26.

    DATA :  r_1 TYPE RANGE OF zbk_ppzt .
    CASE iv_zppzt .
      WHEN space.
        r_1 = VALUE #( BASE r_1 ( sign = 'I'  option  = 'EQ' low = iv_zppzt ) ) .
      WHEN abap_true .
        r_1 = VALUE #( BASE r_1 ( sign = 'I'  option  = 'NE' low = space ) ) .
      WHEN '*' .
        CLEAR r_1.
    ENDCASE .


    DATA :  r_5 TYPE RANGE OF shkzg  .
    CASE iv_shkzg   .
      WHEN space.
        CLEAR r_5.
      WHEN OTHERS .
        r_5 = VALUE #( BASE r_5 ( sign = 'I'  option  = 'EQ' low = iv_shkzg  ) ) .
    ENDCASE .

    SELECT * FROM ztrt_bank_trans INTO CORRESPONDING FIELDS OF TABLE et_bank1
       WHERE bukrs  = iv_bukrs
         AND hbkid  = iv_hbkid
         AND hktid  = iv_hktid
         AND shkzg  IN r_5
         AND zppzt  IN r_1
         AND zref_doc = space
      AND split_flag = space
         AND zgroup_ac  = iv_group .

    LOOP AT et_bank1 INTO DATA(ls_bank1) .
      DATA(ls_bank) = VALUE ztrs_bank_item( bukrs    =  ls_bank1-bukrs
                                            hbkid    =  ls_bank1-hbkid
                                            hktid    =  ls_bank1-hktid
                                            yhzh     =  ls_bank1-yhzh
                                            hkont    =  ls_bank1-hkont
                                            banks    =  ls_bank1-banks
                                            kunnr    =  ls_bank1-kunnr
                                            lifnr    =  ls_bank1-lifnr
                                            zppzt    =  ls_bank1-zppzt
                                            zppqj    =  ls_bank1-zppqj
                                            zbkitem  =  ls_bank1-trxno
                                            zbkjyri  =  ls_bank1-trxdate
                                            zbkjye   =  ls_bank1-trxamt
                                            zbkywt   =  ls_bank1-bustype_txt
                                            zbkyt    =  ls_bank1-usage_txt
                                            zbkzy    =  ls_bank1-abstract_txt
                                            zbkfy    =  ls_bank1-postscript_txt
                                            zbkbz    =  ls_bank1-comment_txt
                                            zbkdkhht =  ls_bank1-bzbnka
                                            zbkdkr   =  ls_bank1-bzbnkn
                                            zbkdkt   =  ls_bank1-bkoinh
                                            waers    =  ls_bank1-waers
                                            zsjly = '2'
                                            shkzg    =  ls_bank1-shkzg ) .
      APPEND ls_bank TO et_bank.
    ENDLOOP.

    SELECT
i~db_key,
           h~bukrs,
           h~hbkid,
           h~hktid,
           h~banks,
           h~bankl,
           h~bank_ind,
           h~hkont,
           z~yhzh,
           i~zbkitem,
           i~zbkjyri,
           i~zbkjysj,
           i~zbkjyrit,
           i~zbkbczbs,
           i~zbkjsms,
           i~zbkfse,
           i~zbkjye,
           i~zbkjyes,
           i~zbkjyeh,
           i~zbkjyye,
           i~zbkfkhht,
           i~zbkfkr,
           i~zbkfkt,
           i~zbkskhht,
           i~zbkskr,
           i~zbkskt,
           i~zbkdkhht,
           i~zbkdkr,
           i~zbkdkt,
           i~zbkywt,
           i~zbkzy1,
           i~zbkzy2,
           i~zbkzy,
           i~zbkyt,
           i~zbkfy,
           i~zbkbz,
           i~zbkad1,
           i~zbkad2,
           i~zbkad3,
           i~kunnr,
           i~lifnr,
           i~zppzt,
           i~zppqj,
           i~waers,
           i~shkzg,
          '1' AS zsjly
       FROM ztrt3023_01 AS h  INNER JOIN ztrt3023_02 AS i ON h~db_key = i~parent_key
                              INNER JOIN ztrt0013    AS z ON z~bukrs  = h~bukrs
                                                         AND z~hbkid  = h~hbkid
                                                         AND z~hktid  = h~hktid
       INTO CORRESPONDING FIELDS OF TABLE @et_bank2
      WHERE  h~bukrs  = @iv_bukrs
         AND h~hbkid  = @iv_hbkid
         AND h~hktid  = @iv_hktid
         AND i~shkzg  IN @r_5
         AND i~zppzt  IN @r_1
         AND i~zgroup_ac  = @iv_group
         AND i~dflag = @space
         AND h~dflag = @space
         AND zref_doc = @space
         AND split_flag = @space
         AND h~zly  = @space .
    IF sy-subrc = 0 .
      APPEND LINES OF et_bank2 TO et_bank.
    ENDIF.
    SELECT * FROM ztrt3023_02_cf INTO CORRESPONDING FIELDS OF TABLE et_bank3
         WHERE bukrs  = iv_bukrs
           AND hbkid  = iv_hbkid
           AND hktid  = iv_hktid
           AND shkzg  IN r_5
           AND zppzt  IN r_1
           AND zref_doc = space
           AND zgroup_ac  = iv_group .

    LOOP AT et_bank3 INTO DATA(ls_bank3) .
      ls_bank  =  CORRESPONDING #( ls_bank3 ).
      APPEND ls_bank TO et_bank.
      CLEAR ls_bank.
    ENDLOOP.
* LOCK
    IF iv_lock IS NOT INITIAL .

      LOOP AT et_bank1 INTO ls_bank1 .
        DATA(ls_ref) =  VALUE ztrs_3028_agnref( bukrs = ls_bank1-bukrs
                                                hbkid = ls_bank1-hbkid
                                                hktid = ls_bank1-hktid
                                                yhzh  = ls_bank1-yhzh
                                                trxno  = ls_bank1-trxno ) .
        CALL METHOD zcl_tr_3024_gui=>lock_1
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.

      LOOP AT et_bank2  INTO DATA(ls_bank2)  .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank2-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_2
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.

      LOOP AT et_bank3  INTO  ls_bank3  .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank3-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_3
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.
    ENDIF.


    IF iv_zz = abap_true.
      CALL METHOD zcl_tr_3024_gui=>query_zz
        EXPORTING
          iv_lock  = iv_lock
          iv_bukrs = iv_bukrs
          iv_zppzt = space
        IMPORTING
          et_bank1 = et_bank1
          et_bank2 = et_bank2
          et_bank  = et_bank
        EXCEPTIONS
          err      = 1
          OTHERS   = 2.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
      WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD qurey_27.

    DATA :  r_1 TYPE RANGE OF zbk_ppzt .
    CASE iv_zppzt .
      WHEN space.
        r_1 = VALUE #( BASE r_1 ( sign = 'I'  option  = 'EQ' low = iv_zppzt ) ) .
      WHEN abap_true .
        r_1 = VALUE #( BASE r_1 ( sign = 'I'  option  = 'NE' low = space ) ) .
      WHEN '*' .
        CLEAR r_1.
    ENDCASE .


    SELECT * FROM ztrt_bank_trans INTO CORRESPONDING FIELDS OF TABLE et_bank1
       WHERE bukrs  = iv_bukrs
         AND hbkid  = iv_hbkid
         AND hktid  = iv_hktid
         AND shkzg  = iv_shkzg
         AND zppzt  IN r_1
         AND zref_doc = space
         AND split_flag = space
         AND zgroup_ac  = iv_group .

    LOOP AT et_bank1 INTO DATA(ls_bank1) .
      DATA(ls_bank) = VALUE ztrs_bank_item( bukrs    =  ls_bank1-bukrs
                                            hbkid    =  ls_bank1-hbkid
                                            hktid    =  ls_bank1-hktid
                                            yhzh     =  ls_bank1-yhzh
                                            hkont    =  ls_bank1-hkont
                                            banks    =  ls_bank1-banks
                                            kunnr    =  ls_bank1-kunnr
                                            lifnr    =  ls_bank1-lifnr
                                            zppzt    =  ls_bank1-zppzt
                                            zppqj    =  ls_bank1-zppqj
                                            zbkitem  =  ls_bank1-trxno
                                            zbkjyri  =  ls_bank1-trxdate
                                            zbkjye   =  ls_bank1-trxamt
                                            zbkywt   =  ls_bank1-bustype_txt
                                            zbkyt    =  ls_bank1-usage_txt
                                            zbkzy    =  ls_bank1-abstract_txt
                                            zbkfy    =  ls_bank1-postscript_txt
                                            zbkbz    =  ls_bank1-comment_txt
                                            zbkdkhht =  ls_bank1-bzbnka
                                            zbkdkr   =  ls_bank1-bzbnkn
                                            zbkdkt   =  ls_bank1-bkoinh
                                            waers    =  ls_bank1-waers
                                            zsjly = '2'
                                            shkzg    =  ls_bank1-shkzg ) .
      APPEND ls_bank TO et_bank.
    ENDLOOP.

    SELECT
i~db_key,
           h~bukrs,
           h~hbkid,
           h~hktid,
           h~banks,
           h~bankl,
           h~bank_ind,
           h~hkont,
           z~yhzh,
           i~zbkitem,
           i~zbkjyri,
           i~zbkjysj,
           i~zbkjyrit,
           i~zbkbczbs,
           i~zbkjsms,
           i~zbkfse,
           i~zbkjye,
           i~zbkjyes,
           i~zbkjyeh,
           i~zbkjyye,
           i~zbkfkhht,
           i~zbkfkr,
           i~zbkfkt,
           i~zbkskhht,
           i~zbkskr,
           i~zbkskt,
           i~zbkdkhht,
           i~zbkdkr,
           i~zbkdkt,
           i~zbkywt,
           i~zbkzy1,
           i~zbkzy2,
           i~zbkzy,
           i~zbkyt,
           i~zbkfy,
           i~zbkbz,
           i~zbkad1,
           i~zbkad2,
           i~zbkad3,
           i~kunnr,
           i~lifnr,
           i~zppzt,
           i~zppqj,
           i~waers,
           i~shkzg,
          '1' AS zsjly
       FROM ztrt3023_01 AS h  INNER JOIN ztrt3023_02 AS i ON h~db_key = i~parent_key
                              INNER JOIN ztrt0013    AS z ON z~bukrs  = h~bukrs
                                                         AND z~hbkid  = h~hbkid
                                                         AND z~hktid  = h~hktid
       INTO CORRESPONDING FIELDS OF TABLE @et_bank2
      WHERE  h~bukrs  = @iv_bukrs
         AND h~hbkid  = @iv_hbkid
         AND h~hktid  = @iv_hktid
         AND i~shkzg  = @iv_shkzg
         AND i~zppzt  IN @r_1
         AND i~zgroup_ac  = @iv_group
         AND i~dflag = @space
         AND h~dflag = @space
         AND zref_doc = @space
         AND split_flag = @space
         AND h~zly  = @space .
    IF sy-subrc = 0 .
      APPEND LINES OF et_bank2 TO et_bank.
    ENDIF.
    SELECT * FROM ztrt3023_02_cf INTO CORRESPONDING FIELDS OF TABLE et_bank3
         WHERE bukrs  = iv_bukrs
           AND hbkid  = iv_hbkid
           AND hktid  = iv_hktid
           AND shkzg  = iv_shkzg
           AND zppzt  IN r_1
           AND zref_doc = space
           AND zgroup_ac  = iv_group .

    LOOP AT et_bank3 INTO DATA(ls_bank3) .
      ls_bank  =  CORRESPONDING #( ls_bank3 ).
      APPEND ls_bank TO et_bank.
      CLEAR ls_bank.
    ENDLOOP.

* LOCK
    IF iv_lock IS NOT INITIAL .

      LOOP AT et_bank1 INTO ls_bank1 .
        DATA(ls_ref) =  VALUE ztrs_3028_agnref( bukrs = ls_bank1-bukrs
                                                hbkid = ls_bank1-hbkid
                                                hktid = ls_bank1-hktid
                                                yhzh  = ls_bank1-yhzh
                                                trxno  = ls_bank1-trxno ) .
        CALL METHOD zcl_tr_3024_gui=>lock_1
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.

      LOOP AT et_bank2  INTO DATA(ls_bank2)  .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank2-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_2
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.

      LOOP AT et_bank3  INTO  ls_bank3  .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank3-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_3
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.

    ENDIF.


    IF iv_zz = abap_true.
      CALL METHOD zcl_tr_3024_gui=>query_zz
        EXPORTING
          iv_lock  = iv_lock
          iv_bukrs = iv_bukrs
          iv_zppzt = space
        IMPORTING
          et_bank1 = et_bank1
          et_bank2 = et_bank2
          et_bank  = et_bank
        EXCEPTIONS
          err      = 1
          OTHERS   = 2.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
      WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD qurey_28.

    DATA :  r_1 TYPE RANGE OF zbk_ppzt .
    CASE iv_zppzt .
      WHEN space.
        r_1 = VALUE #( BASE r_1 ( sign = 'I'  option  = 'EQ' low = iv_zppzt ) ) .
      WHEN abap_true .
        r_1 = VALUE #( BASE r_1 ( sign = 'I'  option  = 'NE' low = space ) ) .
      WHEN '*' .
        CLEAR r_1.
    ENDCASE .

    DATA :  r_2 TYPE RANGE OF lifnr .
    CASE iv_lifnr.
      WHEN space.
        CLEAR r_2.
      WHEN OTHERS .
        r_2 = VALUE #( BASE r_2 ( sign = 'I'  option  = 'EQ' low = iv_lifnr ) ) .
    ENDCASE .


    DATA :  r_3 TYPE RANGE OF hbkid.
    CASE iv_hbkid .
      WHEN space.
        CLEAR r_3.
      WHEN OTHERS .
        r_3 = VALUE #( BASE r_3 ( sign = 'I'  option  = 'EQ' low = iv_hbkid ) ) .
    ENDCASE .

    DATA :  r_4 TYPE RANGE OF hktid.
    CASE iv_hktid  .
      WHEN space.
        CLEAR r_4.
      WHEN OTHERS .
        r_4 = VALUE #( BASE r_4 ( sign = 'I'  option  = 'EQ' low = iv_hktid ) ) .
    ENDCASE .

    DATA :  r_5 TYPE RANGE OF shkzg  .
    CASE iv_shkzg   .
      WHEN space.
        CLEAR r_5.
      WHEN OTHERS .
        r_5 = VALUE #( BASE r_5 ( sign = 'I'  option  = 'EQ' low = iv_shkzg  ) ) .
    ENDCASE .

    DATA :  r_6 TYPE RANGE OF kunnr .
    CASE iv_kunnr.
      WHEN space.
        CLEAR r_6.
      WHEN OTHERS .
        r_6 = VALUE #( BASE r_6 ( sign = 'I'  option  = 'EQ' low = iv_kunnr ) ) .
    ENDCASE .

    SELECT * FROM ztrt_bank_trans INTO CORRESPONDING FIELDS OF TABLE et_bank1
     WHERE bukrs  = iv_bukrs
       AND lifnr IN r_2
       AND zppzt IN r_1
       AND hktid IN r_4
       AND hbkid IN r_3
       AND shkzg IN r_5
       AND kunnr IN r_6
       AND zref_doc = space
       AND split_flag = space
       AND zgroup_ac  = iv_group .


    LOOP AT et_bank1 INTO DATA(ls_bank1) .
      DATA(ls_bank) = VALUE ztrs_bank_item( bukrs    =  ls_bank1-bukrs
                                            hbkid    =  ls_bank1-hbkid
                                            hktid    =  ls_bank1-hktid
                                            yhzh     =  ls_bank1-yhzh
                                            hkont    =  ls_bank1-hkont
                                            banks    =  ls_bank1-banks
                                            kunnr    =  ls_bank1-kunnr
                                            lifnr    =  ls_bank1-lifnr
                                            zppzt    =  ls_bank1-zppzt
                                            zppqj    =  ls_bank1-zppqj
                                            zbkitem  =  ls_bank1-trxno
                                            zbkjyri  =  ls_bank1-trxdate
                                            zbkjye   =  ls_bank1-trxamt
                                            zbkywt   =  ls_bank1-bustype_txt
                                            zbkyt    =  ls_bank1-usage_txt
                                            zbkzy    =  ls_bank1-abstract_txt
                                            zbkfy    =  ls_bank1-postscript_txt
                                            zbkbz    =  ls_bank1-comment_txt
                                            zbkdkhht =  ls_bank1-bzbnka
                                            zbkdkr   =  ls_bank1-bzbnkn
                                            zbkdkt   =  ls_bank1-bkoinh
                                            waers    =  ls_bank1-waers
                                            zsjly = '2'
                                            shkzg    =  ls_bank1-shkzg ) .
      APPEND ls_bank TO et_bank.
    ENDLOOP.


    SELECT
i~db_key,
           h~bukrs,
           h~hbkid,
           h~hktid,
           h~banks,
           h~bankl,
           h~bank_ind,
           h~hkont,
           z~yhzh,
           i~zbkitem,
           i~zbkjyri,
           i~zbkjysj,
           i~zbkjyrit,
           i~zbkbczbs,
           i~zbkjsms,
           i~zbkfse,
           i~zbkjye,
           i~zbkjyes,
           i~zbkjyeh,
           i~zbkjyye,
           i~zbkfkhht,
           i~zbkfkr,
           i~zbkfkt,
           i~zbkskhht,
           i~zbkskr,
           i~zbkskt,
           i~zbkdkhht,
           i~zbkdkr,
           i~zbkdkt,
           i~zbkywt,
           i~zbkzy1,
           i~zbkzy2,
           i~zbkzy,
           i~zbkyt,
           i~zbkfy,
           i~zbkbz,
           i~zbkad1,
           i~zbkad2,
           i~zbkad3,
           i~kunnr,
           i~lifnr,
           i~zppzt,
           i~zppqj,
           i~waers,
           i~shkzg,
          '1' AS zsjly
     FROM ztrt3023_01 AS h  INNER JOIN ztrt3023_02 AS i ON h~db_key = i~parent_key
                                    INNER JOIN ztrt0013    AS z ON z~bukrs  = h~bukrs
                                                         AND z~hbkid  = h~hbkid
                                                         AND z~hktid  = h~hktid
     INTO CORRESPONDING FIELDS OF TABLE @et_bank2
    WHERE  h~bukrs  = @iv_bukrs
       AND i~zppzt  IN @r_1
       AND i~zgroup_ac  = @iv_group
       AND ( ( lifnr2 IN @r_2 AND lifnr = @space ) OR ( lifnr <> @space AND lifnr IN @r_2 ) )
       AND ( ( kunnr2 IN @r_6 AND kunnr = @space ) OR ( kunnr <> @space AND kunnr IN @r_6 ) )
       AND i~shkzg IN @r_5
       AND i~dflag = @space
       AND h~dflag = @space
       AND h~hktid IN @r_4
       AND h~hbkid IN @r_3
       AND split_flag = @space
       AND zref_doc = @space
       AND h~zly  = @space .

    IF sy-subrc = 0 .
      APPEND LINES OF et_bank2 TO et_bank.
    ENDIF.
    SELECT * FROM ztrt3023_02_cf INTO CORRESPONDING FIELDS OF TABLE et_bank3
  WHERE bukrs  = iv_bukrs
  AND lifnr IN r_2
  AND zppzt IN r_1
  AND hktid IN r_4
  AND hbkid IN r_3
  AND shkzg IN r_5
  AND kunnr IN r_6
  AND zref_doc = space
  AND zgroup_ac  = iv_group .

    LOOP AT et_bank3 INTO DATA(ls_bank3) .
      ls_bank  =  CORRESPONDING #( ls_bank3 ).
      APPEND ls_bank TO et_bank.
      CLEAR ls_bank.
    ENDLOOP.
* LOCK
    IF iv_lock IS NOT INITIAL .
      LOOP AT et_bank1 INTO ls_bank1 .
        DATA(ls_ref) =  VALUE ztrs_3028_agnref( bukrs = ls_bank1-bukrs
                                                hbkid = ls_bank1-hbkid
                                                hktid = ls_bank1-hktid
                                                yhzh  = ls_bank1-yhzh
                                                trxno  = ls_bank1-trxno ) .
        CALL METHOD zcl_tr_3024_gui=>lock_1
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.

      LOOP AT et_bank2  INTO DATA(ls_bank2)  .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank2-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_2
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.

      LOOP AT et_bank3  INTO  ls_bank3  .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank3-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_3
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.
    ENDIF.

    IF iv_zz = abap_true.
      CALL METHOD zcl_tr_3024_gui=>query_zz
        EXPORTING
          iv_lock  = iv_lock
          iv_bukrs = iv_bukrs
          iv_zppzt = space
        IMPORTING
          et_bank1 = et_bank1
          et_bank2 = et_bank2
          et_bank  = et_bank
        EXCEPTIONS
          err      = 1
          OTHERS   = 2.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
      WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD qurey_31.

    DATA :  r_1 TYPE RANGE OF zbk_ppzt .
    CASE iv_zppzt .
      WHEN space.
        r_1 = VALUE #( BASE r_1 ( sign = 'I'  option  = 'EQ' low = iv_zppzt ) ) .
      WHEN abap_true .
        r_1 = VALUE #( BASE r_1 ( sign = 'I'  option  = 'NE' low = space ) ) .
      WHEN '*' .
        CLEAR r_1.
    ENDCASE .


    SELECT * FROM ztrt_bank_trans INTO CORRESPONDING FIELDS OF TABLE et_bank1
       WHERE bukrs  = iv_bukrs
         AND hbkid  = iv_hbkid
         AND hktid  = iv_hktid
         AND shkzg  = iv_shkzg
         AND zppzt  IN r_1
         AND zref_doc = space
         AND split_flag = space
         AND zgroup_ac  = iv_group .

    LOOP AT et_bank1 INTO DATA(ls_bank1) .
      DATA(ls_bank) = VALUE ztrs_bank_item( bukrs    =  ls_bank1-bukrs
                                            hbkid    =  ls_bank1-hbkid
                                            hktid    =  ls_bank1-hktid
                                            yhzh     =  ls_bank1-yhzh
                                            kunnr    =  ls_bank1-kunnr
                                            lifnr    =  ls_bank1-lifnr
                                            hkont    =  ls_bank1-hkont
                                            banks    =  ls_bank1-banks
                                            zppzt    =  ls_bank1-zppzt
                                            zppqj    =  ls_bank1-zppqj
                                            zbkitem  =  ls_bank1-trxno
                                            zbkjyri  =  ls_bank1-trxdate
                                            zbkjye   =  ls_bank1-trxamt
                                            zbkywt   =  ls_bank1-bustype_txt
                                            zbkyt    =  ls_bank1-usage_txt
                                            zbkzy    =  ls_bank1-abstract_txt
                                            zbkfy    =  ls_bank1-postscript_txt
                                            zbkbz    =  ls_bank1-comment_txt
                                            zbkdkhht =  ls_bank1-bzbnka
                                            zbkdkr   =  ls_bank1-bzbnkn
                                            zbkdkt   =  ls_bank1-bkoinh
                                            waers    =  ls_bank1-waers
                                            zsjly = '2'
                                            shkzg    =  ls_bank1-shkzg ) .
      APPEND ls_bank TO et_bank.
    ENDLOOP.

    SELECT
           i~db_key,
           h~bukrs,
           h~hbkid,
           h~hktid,
           h~banks,
           h~bankl,
           h~bank_ind,
           h~hkont,
           z~yhzh,
           i~zbkitem,
           i~zbkjyri,
           i~zbkjysj,
           i~zbkjyrit,
           i~zbkbczbs,
           i~zbkjsms,
           i~zbkfse,
           i~zbkjye,
           i~zbkjyes,
           i~zbkjyeh,
           i~zbkjyye,
           i~zbkfkhht,
           i~zbkfkr,
           i~zbkfkt,
           i~zbkskhht,
           i~zbkskr,
           i~zbkskt,
           i~zbkdkhht,
           i~zbkdkr,
           i~zbkdkt,
           i~zbkywt,
           i~zbkzy1,
           i~zbkzy2,
           i~zbkzy,
           i~zbkyt,
           i~zbkfy,
           i~zbkbz,
           i~zbkad1,
           i~zbkad2,
           i~zbkad3,
           i~kunnr,
           i~lifnr,
           i~zppzt,
           i~zppqj,
           i~waers,
           i~shkzg,
          '1' AS zsjly
       FROM ztrt3023_01 AS h  INNER JOIN ztrt3023_02 AS i ON h~db_key = i~parent_key
                                                  INNER JOIN ztrt0013    AS z ON z~bukrs  = h~bukrs
                                                         AND z~hbkid  = h~hbkid
                                                         AND z~hktid  = h~hktid
       INTO CORRESPONDING FIELDS OF TABLE @et_bank2
      WHERE  h~bukrs  = @iv_bukrs
         AND h~hbkid  = @iv_hbkid
         AND h~hktid  = @iv_hktid
         AND i~shkzg  = @iv_shkzg
         AND i~zppzt  IN @r_1
         AND i~zgroup_ac  = @iv_group
         AND i~dflag = @space
         AND h~dflag = @space
         AND split_flag = @space
         AND zref_doc = @space
         AND h~zly  = @space .
    IF sy-subrc = 0 .
      APPEND LINES OF et_bank2 TO et_bank.
    ENDIF.

    SELECT * FROM ztrt3023_02_cf INTO CORRESPONDING FIELDS OF TABLE et_bank3
         WHERE bukrs  = iv_bukrs
           AND hbkid  = iv_hbkid
           AND hktid  = iv_hktid
           AND shkzg  = iv_shkzg
           AND zppzt  IN r_1
           AND zref_doc = space
           AND zgroup_ac  = iv_group .

    LOOP AT et_bank3 INTO DATA(ls_bank3) .
      ls_bank  =  CORRESPONDING #( ls_bank3 ).
      APPEND ls_bank TO et_bank.
      CLEAR ls_bank.
    ENDLOOP.
* LOCK
    IF iv_lock IS NOT INITIAL .

      LOOP AT et_bank1 INTO ls_bank1 .
        DATA(ls_ref) =  VALUE ztrs_3028_agnref( bukrs = ls_bank1-bukrs
                                                hbkid = ls_bank1-hbkid
                                                hktid = ls_bank1-hktid
                                                yhzh  = ls_bank1-yhzh
                                                trxno  = ls_bank1-trxno ) .
        CALL METHOD zcl_tr_3024_gui=>lock_1
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.

      LOOP AT et_bank2  INTO DATA(ls_bank2)  .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank2-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_2
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.


      LOOP AT et_bank3  INTO  ls_bank3  .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank3-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_3
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.
    ENDIF.


    IF iv_zz = abap_true.
      CALL METHOD zcl_tr_3024_gui=>query_zz
        EXPORTING
          iv_lock  = iv_lock
          iv_bukrs = iv_bukrs
          iv_zppzt = space
        IMPORTING
          et_bank1 = et_bank1
          et_bank2 = et_bank2
          et_bank  = et_bank
        EXCEPTIONS
          err      = 1
          OTHERS   = 2.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
      WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD qurey_32.

    DATA :  r_1 TYPE RANGE OF zbk_ppzt .
    CASE iv_zppzt .
      WHEN space.
        r_1 = VALUE #( BASE r_1 ( sign = 'I'  option  = 'EQ' low = iv_zppzt ) ) .
      WHEN abap_true .
        r_1 = VALUE #( BASE r_1 ( sign = 'I'  option  = 'NE' low = space ) ) .
      WHEN '*' .
        CLEAR r_1.
    ENDCASE .

    DATA :  r_2 TYPE RANGE OF lifnr .
    CASE iv_lifnr.
      WHEN space.
        CLEAR r_2.
      WHEN OTHERS .
        r_2 = VALUE #( BASE r_2 ( sign = 'I'  option  = 'EQ' low = iv_lifnr ) ) .
    ENDCASE .


    DATA :  r_3 TYPE RANGE OF hbkid.
    CASE iv_hbkid .
      WHEN space.
        CLEAR r_3.
      WHEN OTHERS .
        r_3 = VALUE #( BASE r_3 ( sign = 'I'  option  = 'EQ' low = iv_hbkid ) ) .
    ENDCASE .

    DATA :  r_4 TYPE RANGE OF hktid.
    CASE iv_hktid  .
      WHEN space.
        CLEAR r_4.
      WHEN OTHERS .
        r_4 = VALUE #( BASE r_4 ( sign = 'I'  option  = 'EQ' low = iv_hktid ) ) .
    ENDCASE .

    DATA :  r_5 TYPE RANGE OF shkzg  .
    CASE iv_shkzg   .
      WHEN space.
        CLEAR r_5.
      WHEN OTHERS .
        r_5 = VALUE #( BASE r_5 ( sign = 'I'  option  = 'EQ' low = iv_shkzg  ) ) .
    ENDCASE .

    SELECT * FROM ztrt_bank_trans INTO CORRESPONDING FIELDS OF TABLE et_bank1
     WHERE bukrs  = iv_bukrs
       AND lifnr IN r_2
       AND zppzt IN r_1
       AND hktid IN r_4
       AND hbkid IN r_3
       AND shkzg IN r_5
       AND zref_doc = space
       AND split_flag = space
       AND zgroup_ac  = iv_group .


    LOOP AT et_bank1 INTO DATA(ls_bank1) .
      DATA(ls_bank) = VALUE ztrs_bank_item( bukrs    =  ls_bank1-bukrs
                                            hbkid    =  ls_bank1-hbkid
                                            hktid    =  ls_bank1-hktid
                                            yhzh     =  ls_bank1-yhzh
                                            kunnr    =  ls_bank1-kunnr
                                            lifnr    =  ls_bank1-lifnr
                                            hkont    =  ls_bank1-hkont
                                            banks    =  ls_bank1-banks
                                            zppzt    =  ls_bank1-zppzt
                                            zppqj    =  ls_bank1-zppqj
                                            zbkitem  =  ls_bank1-trxno
                                            zbkjyri  =  ls_bank1-trxdate
                                            zbkjye   =  ls_bank1-trxamt
                                            zbkywt   =  ls_bank1-bustype_txt
                                            zbkyt    =  ls_bank1-usage_txt
                                            zbkzy    =  ls_bank1-abstract_txt
                                            zbkfy    =  ls_bank1-postscript_txt
                                            zbkbz    =  ls_bank1-comment_txt
                                            zbkdkhht =  ls_bank1-bzbnka
                                            zbkdkr   =  ls_bank1-bzbnkn
                                            zbkdkt   =  ls_bank1-bkoinh
                                            waers    =  ls_bank1-waers
                                            zsjly = '2'
                                            shkzg    =  ls_bank1-shkzg ) .
      APPEND ls_bank TO et_bank.
    ENDLOOP.


    SELECT
          i~db_key,
           h~bukrs,
           h~hbkid,
           h~hktid,
           h~banks,
           h~bankl,
           h~bank_ind,
           h~hkont,
           z~yhzh,
           i~zbkitem,
           i~zbkjyri,
           i~zbkjysj,
           i~zbkjyrit,
           i~zbkbczbs,
           i~zbkjsms,
           i~zbkfse,
           i~zbkjye,
           i~zbkjyes,
           i~zbkjyeh,
           i~zbkjyye,
           i~zbkfkhht,
           i~zbkfkr,
           i~zbkfkt,
           i~zbkskhht,
           i~zbkskr,
           i~zbkskt,
           i~zbkdkhht,
           i~zbkdkr,
           i~zbkdkt,
           i~zbkywt,
           i~zbkzy1,
           i~zbkzy2,
           i~zbkzy,
           i~zbkyt,
           i~zbkfy,
           i~zbkbz,
           i~zbkad1,
           i~zbkad2,
           i~zbkad3,
           i~kunnr,
           i~lifnr,
           i~zppzt,
           i~zppqj,
           i~waers,
           i~shkzg,
          '1' AS zsjly
     FROM ztrt3023_01 AS h  INNER JOIN ztrt3023_02 AS i ON h~db_key = i~parent_key
                                                        INNER JOIN ztrt0013    AS z ON z~bukrs  = h~bukrs
                                                         AND z~hbkid  = h~hbkid
                                                         AND z~hktid  = h~hktid
     INTO CORRESPONDING FIELDS OF TABLE @et_bank2
    WHERE  h~bukrs  = @iv_bukrs
       AND i~zppzt  IN @r_1
       AND i~zgroup_ac  = @iv_group
       AND ( ( lifnr2 IN @r_2 AND lifnr = @space ) OR ( lifnr <> @space  AND lifnr IN @r_2 ) )
       AND i~shkzg IN @r_5
       AND i~dflag = @space
       AND h~dflag = @space
       AND h~hktid IN @r_4
       AND h~hbkid IN @r_3
       AND zref_doc = @space
         AND split_flag = @space
      AND h~zly  = @space .

    IF sy-subrc = 0 .
      APPEND LINES OF et_bank2 TO et_bank.
    ENDIF.

    SELECT * FROM ztrt3023_02_cf INTO CORRESPONDING FIELDS OF TABLE et_bank3
  WHERE  bukrs  = iv_bukrs
        AND lifnr IN r_2
        AND zppzt IN r_1
        AND hktid IN r_4
        AND hbkid IN r_3
        AND shkzg IN r_5
        AND zref_doc = space
        AND zgroup_ac  = iv_group . .

    LOOP AT et_bank3 INTO DATA(ls_bank3) .
      ls_bank  =  CORRESPONDING #( ls_bank3 ).
      APPEND ls_bank TO et_bank.
      CLEAR ls_bank.
    ENDLOOP.
* LOCK
    IF iv_lock IS NOT INITIAL .
      LOOP AT et_bank1 INTO ls_bank1 .
        DATA(ls_ref) =  VALUE ztrs_3028_agnref( bukrs  = ls_bank1-bukrs
                                                hbkid  = ls_bank1-hbkid
                                                hktid  = ls_bank1-hktid
                                                yhzh   = ls_bank1-yhzh
                                                trxno  = ls_bank1-trxno ) .
        CALL METHOD zcl_tr_3024_gui=>lock_1
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.

      LOOP AT et_bank2  INTO DATA(ls_bank2)  .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank2-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_2
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.

      LOOP AT et_bank3  INTO  ls_bank3  .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank3-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_3
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.
    ENDIF.

    IF iv_zz = abap_true.
      CALL METHOD zcl_tr_3024_gui=>query_zz
        EXPORTING
          iv_lock  = iv_lock
          iv_bukrs = iv_bukrs
          iv_zppzt = space
        IMPORTING
          et_bank1 = et_bank1
          et_bank2 = et_bank2
          et_bank  = et_bank
        EXCEPTIONS
          err      = 1
          OTHERS   = 2.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
      WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD qurey_33.

    DATA :  r_1 TYPE RANGE OF zbk_ppzt .
    CASE iv_zppzt .
      WHEN space.
        r_1 = VALUE #( BASE r_1 ( sign = 'I'  option  = 'EQ' low = iv_zppzt ) ) .
      WHEN abap_true .
        r_1 = VALUE #( BASE r_1 ( sign = 'I'  option  = 'NE' low = space ) ) .
      WHEN '*' .
        CLEAR r_1.
    ENDCASE .

    DATA :  r_2 TYPE RANGE OF kunnr.
    CASE iv_kunnr.
      WHEN space.
        CLEAR r_2.
      WHEN OTHERS .
        r_2 = VALUE #( BASE r_2 ( sign = 'I'  option  = 'EQ' low = iv_kunnr ) ) .
    ENDCASE .

    DATA :  r_3 TYPE RANGE OF hbkid.
    CASE iv_hbkid .
      WHEN space.
        CLEAR r_3.
      WHEN OTHERS .
        r_3 = VALUE #( BASE r_3 ( sign = 'I'  option  = 'EQ' low = iv_hbkid ) ) .
    ENDCASE .

    DATA :  r_4 TYPE RANGE OF hktid.
    CASE iv_hktid  .
      WHEN space.
        CLEAR r_4.
      WHEN OTHERS .
        r_4 = VALUE #( BASE r_4 ( sign = 'I'  option  = 'EQ' low = iv_hktid ) ) .
    ENDCASE .

    DATA :  r_5 TYPE RANGE OF shkzg  .
    CASE iv_shkzg   .
      WHEN space.
        CLEAR r_5.
      WHEN OTHERS .
        r_5 = VALUE #( BASE r_5 ( sign = 'I'  option  = 'EQ' low = iv_shkzg  ) ) .
    ENDCASE .

    SELECT * FROM ztrt_bank_trans INTO CORRESPONDING FIELDS OF TABLE et_bank1
     WHERE bukrs  = iv_bukrs
       AND kunnr  IN r_2
       AND hbkid IN r_3
       AND hktid IN r_4
       AND zppzt  IN r_1
       AND shkzg  IN r_5
       AND zref_doc = space
       AND split_flag = space
       AND zgroup_ac  = iv_group .


    LOOP AT et_bank1 INTO DATA(ls_bank1) .
      DATA(ls_bank) = VALUE ztrs_bank_item( bukrs    =  ls_bank1-bukrs
                                            hbkid    =  ls_bank1-hbkid
                                            hktid    =  ls_bank1-hktid
                                            yhzh     =  ls_bank1-yhzh
                                            hkont    =  ls_bank1-hkont
                                            banks    =  ls_bank1-banks
                                            kunnr    =  ls_bank1-kunnr
                                            lifnr    =  ls_bank1-lifnr
                                            zppzt    =  ls_bank1-zppzt
                                            zppqj    =  ls_bank1-zppqj
                                            zbkitem  =  ls_bank1-trxno
                                            zbkjyri  =  ls_bank1-trxdate
                                            zbkjye   =  ls_bank1-trxamt
                                            zbkywt   =  ls_bank1-bustype_txt
                                            zbkyt    =  ls_bank1-usage_txt
                                            zbkzy    =  ls_bank1-abstract_txt
                                            zbkfy    =  ls_bank1-postscript_txt
                                            zbkbz    =  ls_bank1-comment_txt
                                            zbkdkhht =  ls_bank1-bzbnka
                                            zbkdkr   =  ls_bank1-bzbnkn
                                            zbkdkt   =  ls_bank1-bkoinh
                                            waers    =  ls_bank1-waers
                                            zsjly = '2'
                                            shkzg    =  ls_bank1-shkzg ) .
      APPEND ls_bank TO et_bank.
    ENDLOOP.

    SELECT
i~db_key,
           h~bukrs,
           h~hbkid,
           h~hktid,
           h~banks,
           h~bankl,
           h~bank_ind,
           h~hkont,
           z~yhzh,
           i~zbkitem,
           i~zbkjyri,
           i~zbkjysj,
           i~zbkjyrit,
           i~zbkbczbs,
           i~zbkjsms,
           i~zbkfse,
           i~zbkjye,
           i~zbkjyes,
           i~zbkjyeh,
           i~zbkjyye,
           i~zbkfkhht,
           i~zbkfkr,
           i~zbkfkt,
           i~zbkskhht,
           i~zbkskr,
           i~zbkskt,
           i~zbkdkhht,
           i~zbkdkr,
           i~zbkdkt,
           i~zbkywt,
           i~zbkzy1,
           i~zbkzy2,
           i~zbkzy,
           i~zbkyt,
           i~zbkfy,
           i~zbkbz,
           i~zbkad1,
           i~zbkad2,
           i~zbkad3,
           i~kunnr,
           i~lifnr,
           i~zppzt,
           i~zppqj,
           i~waers,
           i~shkzg,
          '1' AS zsjly
       FROM ztrt3023_01 AS h  INNER JOIN ztrt3023_02 AS i ON h~db_key = i~parent_key
                                                              INNER JOIN ztrt0013    AS z ON z~bukrs  = h~bukrs
                                                         AND z~hbkid  = h~hbkid
                                                         AND z~hktid  = h~hktid
       INTO CORRESPONDING FIELDS OF TABLE @et_bank2

      WHERE  h~bukrs  = @iv_bukrs
         AND i~zppzt  IN @r_1
         AND ( ( kunnr2 IN @r_2 AND kunnr = @space ) OR ( kunnr <> @space AND kunnr IN @r_2 ) )
         AND h~hbkid IN @r_3
         AND h~hktid IN @r_4
         AND i~shkzg  IN @r_5
         AND i~zgroup_ac  = @iv_group
         AND i~dflag = @space
         AND h~dflag = @space
         AND zref_doc = @space
         AND split_flag = @space
         AND h~zly  = @space .

    IF sy-subrc = 0 .
      APPEND LINES OF et_bank2 TO et_bank.
    ENDIF.

    SELECT * FROM ztrt3023_02_cf INTO CORRESPONDING FIELDS OF TABLE et_bank3
  WHERE  bukrs  = iv_bukrs
  AND kunnr  IN r_2
  AND hbkid IN r_3
  AND hktid IN r_4
  AND zppzt  IN r_1
  AND shkzg  IN r_5
  AND zref_doc = space
  AND zgroup_ac  = iv_group  .

    LOOP AT et_bank3 INTO DATA(ls_bank3) .
      ls_bank  =  CORRESPONDING #( ls_bank3 ).
      APPEND ls_bank TO et_bank.
      CLEAR ls_bank.
    ENDLOOP.

* LOCK
    IF iv_lock IS NOT INITIAL .
      LOOP AT et_bank1 INTO ls_bank1 .
        DATA(ls_ref) =  VALUE ztrs_3028_agnref( bukrs = ls_bank1-bukrs
                                                hbkid = ls_bank1-hbkid
                                                hktid = ls_bank1-hktid
                                                yhzh  = ls_bank1-yhzh
                                                trxno  = ls_bank1-trxno ) .
        CALL METHOD zcl_tr_3024_gui=>lock_1
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.

      LOOP AT et_bank2  INTO DATA(ls_bank2)  .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank2-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_2
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.


      LOOP AT et_bank3  INTO  ls_bank3  .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank3-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_3
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.
    ENDIF.

    IF iv_zz = abap_true.
      CALL METHOD zcl_tr_3024_gui=>query_zz
        EXPORTING
          iv_lock  = iv_lock
          iv_bukrs = iv_bukrs
          iv_zppzt = space
        IMPORTING
          et_bank1 = et_bank1
          et_bank2 = et_bank2
          et_bank  = et_bank
        EXCEPTIONS
          err      = 1
          OTHERS   = 2.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
      WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD qurey_35.

    DATA :  r_1 TYPE RANGE OF zbk_ppzt .
    CASE iv_zppzt .
      WHEN space.
        r_1 = VALUE #( BASE r_1 ( sign = 'I'  option  = 'EQ' low = iv_zppzt ) ) .
      WHEN abap_true .
        r_1 = VALUE #( BASE r_1 ( sign = 'I'  option  = 'NE' low = space ) ) .
      WHEN '*' .
        CLEAR r_1.
    ENDCASE .

    DATA :  r_2 TYPE RANGE OF lifnr .
    CASE iv_lifnr.
      WHEN space.
        CLEAR r_2.
      WHEN OTHERS .
        r_2 = VALUE #( BASE r_2 ( sign = 'I'  option  = 'EQ' low = iv_lifnr ) ) .
    ENDCASE .


    DATA :  r_3 TYPE RANGE OF hbkid.
    CASE iv_hbkid .
      WHEN space.
        CLEAR r_3.
      WHEN OTHERS .
        r_3 = VALUE #( BASE r_3 ( sign = 'I'  option  = 'EQ' low = iv_hbkid ) ) .
    ENDCASE .

    DATA :  r_4 TYPE RANGE OF hktid.
    CASE iv_hktid  .
      WHEN space.
        CLEAR r_4.
      WHEN OTHERS .
        r_4 = VALUE #( BASE r_4 ( sign = 'I'  option  = 'EQ' low = iv_hktid ) ) .
    ENDCASE .

    DATA :  r_5 TYPE RANGE OF ztr_bkfse  .
    CASE iv_zbkfse  .
      WHEN space.
        CLEAR r_5.
      WHEN OTHERS .
        r_5 = VALUE #( BASE r_5 ( sign = 'I'  option  = 'EQ' low = iv_zbkfse  ) ) .
    ENDCASE .

    SELECT * FROM ztrt_bank_trans INTO CORRESPONDING FIELDS OF TABLE et_bank1
     WHERE bukrs  = iv_bukrs
       AND lifnr IN r_2
       AND zppzt IN r_1
       AND hktid IN r_4
       AND hbkid IN r_3
       AND bkfse IN r_5
       AND zref_doc = space
       AND split_flag = space
       AND zgroup_ac  = iv_group .


    LOOP AT et_bank1 INTO DATA(ls_bank1) .
      DATA(ls_bank) = VALUE ztrs_bank_item( bukrs    =  ls_bank1-bukrs
                                            hbkid    =  ls_bank1-hbkid
                                            hktid    =  ls_bank1-hktid
                                            yhzh     =  ls_bank1-yhzh
                                            kunnr    =  ls_bank1-kunnr
                                            lifnr    =  ls_bank1-lifnr
                                            hkont    =  ls_bank1-hkont
                                            banks    =  ls_bank1-banks
                                            zppzt    =  ls_bank1-zppzt
                                            zppqj    =  ls_bank1-zppqj
                                            zbkitem  =  ls_bank1-trxno
                                            zbkjyri  =  ls_bank1-trxdate
                                            zbkjye   =  ls_bank1-trxamt
                                            zbkywt   =  ls_bank1-bustype_txt
                                            zbkyt    =  ls_bank1-usage_txt
                                            zbkzy    =  ls_bank1-abstract_txt
                                            zbkfy    =  ls_bank1-postscript_txt
                                            zbkbz    =  ls_bank1-comment_txt
                                            zbkdkhht =  ls_bank1-bzbnka
                                            zbkdkr   =  ls_bank1-bzbnkn
                                            zbkdkt   =  ls_bank1-bkoinh
                                            waers    =  ls_bank1-waers
                                            zsjly = '2'
                                            shkzg    =  ls_bank1-shkzg ) .
      APPEND ls_bank TO et_bank.
    ENDLOOP.


    SELECT
i~db_key,
           h~bukrs,
           h~hbkid,
           h~hktid,
           h~banks,
           h~bankl,
           h~bank_ind,
           h~hkont,
           z~yhzh,
           i~zbkitem,
           i~zbkjyri,
           i~zbkjysj,
           i~zbkjyrit,
           i~zbkbczbs,
           i~zbkjsms,
           i~zbkfse,
           i~zbkjye,
           i~zbkjyes,
           i~zbkjyeh,
           i~zbkjyye,
           i~zbkfkhht,
           i~zbkfkr,
           i~zbkfkt,
           i~zbkskhht,
           i~zbkskr,
           i~zbkskt,
           i~zbkdkhht,
           i~zbkdkr,
           i~zbkdkt,
           i~zbkywt,
           i~zbkzy1,
           i~zbkzy2,
           i~zbkzy,
           i~zbkyt,
           i~zbkfy,
           i~zbkbz,
           i~zbkad1,
           i~zbkad2,
           i~zbkad3,
           i~kunnr,
           i~lifnr,
           i~zppzt,
           i~zppqj,
           i~waers,
           i~shkzg,
          '1' AS zsjly
     FROM ztrt3023_01 AS h  INNER JOIN ztrt3023_02 AS i ON h~db_key = i~parent_key
                   INNER JOIN ztrt0013    AS z ON z~bukrs  = h~bukrs
                                                         AND z~hbkid  = h~hbkid
                                                         AND z~hktid  = h~hktid
     INTO CORRESPONDING FIELDS OF TABLE @et_bank2
    WHERE  h~bukrs  = @iv_bukrs
       AND i~zppzt  IN @r_1
       AND i~zgroup_ac  = @iv_group
       AND ( ( lifnr2 IN @r_2 AND lifnr = @space ) OR ( lifnr <> @space  AND lifnr IN @r_2 ) )
       AND i~zbkfse IN @r_5
       AND i~dflag = @space
       AND h~dflag = @space
       AND h~hktid IN @r_4
       AND h~hbkid IN @r_3
       AND i~zref_doc = @space
       AND i~split_flag = @space
       AND h~zly  = @space .

    IF sy-subrc = 0 .
      APPEND LINES OF et_bank2 TO et_bank.
    ENDIF.

    SELECT * FROM ztrt3023_02_cf INTO CORRESPONDING FIELDS OF TABLE et_bank3
  WHERE bukrs  = iv_bukrs
      AND lifnr IN r_2
      AND zppzt IN r_1
      AND hktid IN r_4
      AND hbkid IN r_3
      AND zbkfse IN r_5
      AND zref_doc = space
      AND zgroup_ac  = iv_group.

    LOOP AT et_bank3 INTO DATA(ls_bank3) .
      ls_bank  =  CORRESPONDING #( ls_bank3 ).
      APPEND ls_bank TO et_bank.
      CLEAR ls_bank.
    ENDLOOP.
* LOCK
    IF iv_lock IS NOT INITIAL .
      LOOP AT et_bank1 INTO ls_bank1 .
        DATA(ls_ref) =  VALUE ztrs_3028_agnref( bukrs  = ls_bank1-bukrs
                                                hbkid  = ls_bank1-hbkid
                                                hktid  = ls_bank1-hktid
                                                yhzh   = ls_bank1-yhzh
                                                trxno  = ls_bank1-trxno ) .
        CALL METHOD zcl_tr_3024_gui=>lock_1
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.

      LOOP AT et_bank2  INTO DATA(ls_bank2)  .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank2-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_2
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.

      LOOP AT et_bank3  INTO  ls_bank3  .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank3-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_3
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.
    ENDIF.

    IF iv_zz = abap_true.
      CALL METHOD zcl_tr_3024_gui=>query_zz
        EXPORTING
          iv_lock  = iv_lock
          iv_bukrs = iv_bukrs
          iv_zppzt = space
        IMPORTING
          et_bank1 = et_bank1
          et_bank2 = et_bank2
          et_bank  = et_bank
        EXCEPTIONS
          err      = 1
          OTHERS   = 2.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
      WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD qurey_36.

    DATA :  r_1 TYPE RANGE OF zbk_ppzt .
    CASE iv_zppzt .
      WHEN space.
        r_1 = VALUE #( BASE r_1 ( sign = 'I'  option  = 'EQ' low = iv_zppzt ) ) .
      WHEN abap_true .
        r_1 = VALUE #( BASE r_1 ( sign = 'I'  option  = 'NE' low = space ) ) .
      WHEN '*' .
        CLEAR r_1.
    ENDCASE .

    DATA :  r_5 TYPE RANGE OF shkzg  .
    CASE iv_shkzg   .
      WHEN space.
        CLEAR r_5.
      WHEN OTHERS .
        r_5 = VALUE #( BASE r_5 ( sign = 'I'  option  = 'EQ' low = iv_shkzg  ) ) .
    ENDCASE .

    SELECT * FROM ztrt_bank_trans INTO CORRESPONDING FIELDS OF TABLE et_bank1
       WHERE bukrs  = iv_bukrs
         AND hbkid  = iv_hbkid
         AND hktid  = iv_hktid
         AND shkzg  IN r_5
         AND zppzt  IN r_1
         AND zref_doc = space
         AND zgroup_ac  = iv_group .

    LOOP AT et_bank1 INTO DATA(ls_bank1) .
      DATA(ls_bank) = VALUE ztrs_bank_item( bukrs    =  ls_bank1-bukrs
                                            hbkid    =  ls_bank1-hbkid
                                            hktid    =  ls_bank1-hktid
                                            yhzh     =  ls_bank1-yhzh
                                            hkont    =  ls_bank1-hkont
                                            banks    =  ls_bank1-banks
                                            kunnr    =  ls_bank1-kunnr
                                            lifnr    =  ls_bank1-lifnr
                                            zppzt    =  ls_bank1-zppzt
                                            zppqj    =  ls_bank1-zppqj
                                            zbkitem  =  ls_bank1-trxno
                                            zbkjyri  =  ls_bank1-trxdate
                                            zbkjye   =  ls_bank1-trxamt
                                            zbkywt   =  ls_bank1-bustype_txt
                                            zbkyt    =  ls_bank1-usage_txt
                                            zbkzy    =  ls_bank1-abstract_txt
                                            zbkfy    =  ls_bank1-postscript_txt
                                            zbkbz    =  ls_bank1-comment_txt
                                            zbkdkhht =  ls_bank1-bzbnka
                                            zbkdkr   =  ls_bank1-bzbnkn
                                            zbkdkt   =  ls_bank1-bkoinh
                                            waers    =  ls_bank1-waers
                                            zsjly = '2'
                                            shkzg    =  ls_bank1-shkzg ) .
      APPEND ls_bank TO et_bank.
    ENDLOOP.

    SELECT
i~db_key,
           h~bukrs,
           h~hbkid,
           h~hktid,
           h~banks,
           h~bankl,
           h~bank_ind,
           h~hkont,
           z~yhzh,
           i~zbkitem,
           i~zbkjyri,
           i~zbkjysj,
           i~zbkjyrit,
           i~zbkbczbs,
           i~zbkjsms,
           i~zbkfse,
           i~zbkjye,
           i~zbkjyes,
           i~zbkjyeh,
           i~zbkjyye,
           i~zbkfkhht,
           i~zbkfkr,
           i~zbkfkt,
           i~zbkskhht,
           i~zbkskr,
           i~zbkskt,
           i~zbkdkhht,
           i~zbkdkr,
           i~zbkdkt,
           i~zbkywt,
           i~zbkzy1,
           i~zbkzy2,
           i~zbkzy,
           i~zbkyt,
           i~zbkfy,
           i~zbkbz,
           i~zbkad1,
           i~zbkad2,
           i~zbkad3,
           i~kunnr,
           i~lifnr,
           i~zppzt,
           i~zppqj,
           i~waers,
           i~shkzg,
          '1' AS zsjly
       FROM ztrt3023_01 AS h  INNER JOIN ztrt3023_02 AS i ON h~db_key = i~parent_key
                              INNER JOIN ztrt0013    AS z ON z~bukrs  = h~bukrs
                                                         AND z~hbkid  = h~hbkid
                                                         AND z~hktid  = h~hktid
       INTO CORRESPONDING FIELDS OF TABLE @et_bank2
      WHERE  h~bukrs  = @iv_bukrs
         AND h~hbkid  = @iv_hbkid
         AND h~hktid  = @iv_hktid
         AND i~shkzg  IN @r_5
               AND i~zppzt  IN @r_1
         AND i~zgroup_ac  = @iv_group
         AND i~dflag = @space
         AND h~dflag = @space
         AND zref_doc = @space
         AND split_flag = @space
         AND h~zly  = @space .
    IF sy-subrc = 0 .
      APPEND LINES OF et_bank2 TO et_bank.
    ENDIF.
    SELECT * FROM ztrt3023_02_cf INTO CORRESPONDING FIELDS OF TABLE et_bank3
         WHERE bukrs  = iv_bukrs
           AND hbkid  = iv_hbkid
           AND hktid  = iv_hktid
           AND shkzg  IN r_5
           AND zppzt  IN r_1
           AND zref_doc = space
           AND zgroup_ac  = iv_group .

    LOOP AT et_bank3 INTO DATA(ls_bank3) .
      ls_bank  =  CORRESPONDING #( ls_bank3 ).
      APPEND ls_bank TO et_bank.
      CLEAR ls_bank.
    ENDLOOP.
* LOCK
    IF iv_lock IS NOT INITIAL .

      LOOP AT et_bank1 INTO ls_bank1 .
        DATA(ls_ref) =  VALUE ztrs_3028_agnref( bukrs = ls_bank1-bukrs
                                                hbkid = ls_bank1-hbkid
                                                hktid = ls_bank1-hktid
                                                yhzh  = ls_bank1-yhzh
                                                trxno  = ls_bank1-trxno ) .
        CALL METHOD zcl_tr_3024_gui=>lock_1
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.

      LOOP AT et_bank2  INTO DATA(ls_bank2)  .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank2-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_2
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.


      LOOP AT et_bank3  INTO  ls_bank3  .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank3-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_3
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.
    ENDIF.


    IF iv_zz = abap_true.
      CALL METHOD zcl_tr_3024_gui=>query_zz
        EXPORTING
          iv_lock  = iv_lock
          iv_bukrs = iv_bukrs
          iv_zppzt = space
        IMPORTING
          et_bank1 = et_bank1
          et_bank2 = et_bank2
          et_bank  = et_bank
        EXCEPTIONS
          err      = 1
          OTHERS   = 2.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
      WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD qurey_40.

    DATA :  r_1 TYPE RANGE OF zbk_ppzt .
    CASE iv_zppzt .
      WHEN space.
        r_1 = VALUE #( BASE r_1 ( sign = 'I'  option  = 'EQ' low = iv_zppzt ) ) .
      WHEN abap_true .
        r_1 = VALUE #( BASE r_1 ( sign = 'I'  option  = 'NE' low = space ) ) .
      WHEN '*' .
        CLEAR r_1.
    ENDCASE .

    DATA :  r_5 TYPE RANGE OF shkzg  .
    CASE iv_shkzg   .
      WHEN space.
        CLEAR r_5.
      WHEN OTHERS .
        r_5 = VALUE #( BASE r_5 ( sign = 'I'  option  = 'EQ' low = iv_shkzg  ) ) .
    ENDCASE .

    SELECT * FROM ztrt_bank_trans INTO CORRESPONDING FIELDS OF TABLE et_bank1
       WHERE bukrs  = iv_bukrs
         AND hbkid  = iv_hbkid
         AND hktid  = iv_hktid
         AND shkzg  IN r_5
         AND zppzt  IN r_1
         AND zref_doc = space
         AND split_flag = space
         AND zgroup_ac  = iv_group .

    LOOP AT et_bank1 INTO DATA(ls_bank1) .
      DATA(ls_bank) = VALUE ztrs_bank_item( bukrs    =  ls_bank1-bukrs
                                            hbkid    =  ls_bank1-hbkid
                                            hktid    =  ls_bank1-hktid
                                            yhzh     =  ls_bank1-yhzh
                                            kunnr    =  ls_bank1-kunnr
                                            lifnr    =  ls_bank1-lifnr
                                            hkont    =  ls_bank1-hkont
                                            banks    =  ls_bank1-banks
                                            zppzt    =  ls_bank1-zppzt
                                            zppqj    =  ls_bank1-zppqj
                                            zbkitem  =  ls_bank1-trxno
                                            zbkjyri  =  ls_bank1-trxdate
                                            zbkjye   =  ls_bank1-trxamt
                                            zbkywt   =  ls_bank1-bustype_txt
                                            zbkyt    =  ls_bank1-usage_txt
                                            zbkzy    =  ls_bank1-abstract_txt
                                            zbkfy    =  ls_bank1-postscript_txt
                                            zbkbz    =  ls_bank1-comment_txt
                                            zbkdkhht =  ls_bank1-bzbnka
                                            zbkdkr   =  ls_bank1-bzbnkn
                                            zbkdkt   =  ls_bank1-bkoinh
                                            waers    =  ls_bank1-waers
                                            zsjly = '2'
                                            shkzg    =  ls_bank1-shkzg ) .
      APPEND ls_bank TO et_bank.
    ENDLOOP.

    SELECT
i~db_key,
           h~bukrs,
           h~hbkid,
           h~hktid,
           h~banks,
           h~bankl,
           h~bank_ind,
           h~hkont,
           z~yhzh,
           i~zbkitem,
           i~zbkjyri,
           i~zbkjysj,
           i~zbkjyrit,
           i~zbkbczbs,
           i~zbkjsms,
           i~zbkfse,
           i~zbkjye,
           i~zbkjyes,
           i~zbkjyeh,
           i~zbkjyye,
           i~zbkfkhht,
           i~zbkfkr,
           i~zbkfkt,
           i~zbkskhht,
           i~zbkskr,
           i~zbkskt,
           i~zbkdkhht,
           i~zbkdkr,
           i~zbkdkt,
           i~zbkywt,
           i~zbkzy1,
           i~zbkzy2,
           i~zbkzy,
           i~zbkyt,
           i~zbkfy,
           i~zbkbz,
           i~zbkad1,
           i~zbkad2,
           i~zbkad3,
           i~kunnr,
           i~lifnr,
           i~zppzt,
           i~zppqj,
           i~waers,
           i~shkzg,
          '1' AS zsjly
       FROM ztrt3023_01 AS h  INNER JOIN ztrt3023_02 AS i ON h~db_key = i~parent_key
                              INNER JOIN ztrt0013    AS z ON z~bukrs  = h~bukrs
                                                         AND z~hbkid  = h~hbkid
                                                         AND z~hktid  = h~hktid
       INTO CORRESPONDING FIELDS OF TABLE @et_bank2
      WHERE  h~bukrs  = @iv_bukrs
         AND h~hbkid  = @iv_hbkid
         AND h~hktid  = @iv_hktid
         AND i~shkzg  IN @r_5
         AND i~zppzt  IN @r_1
         AND i~zgroup_ac  = @iv_group
         AND i~dflag = @space
         AND h~dflag = @space
         AND zref_doc = @space
         AND split_flag = @space
         AND h~zly  = @space .
    IF sy-subrc = 0 .
      APPEND LINES OF et_bank2 TO et_bank.
    ENDIF.

    SELECT * FROM ztrt3023_02_cf INTO CORRESPONDING FIELDS OF TABLE et_bank3
         WHERE bukrs  = iv_bukrs
           AND hbkid  = iv_hbkid
           AND hktid  = iv_hktid
           AND shkzg  IN r_5
           AND zppzt  IN r_1
           AND zref_doc = space
           AND zgroup_ac  = iv_group .

    LOOP AT et_bank3 INTO DATA(ls_bank3) .
      ls_bank  =  CORRESPONDING #( ls_bank3 ).
      APPEND ls_bank TO et_bank.
      CLEAR ls_bank.
    ENDLOOP.
* LOCK
    IF iv_lock IS NOT INITIAL .

      LOOP AT et_bank1 INTO ls_bank1 .
        DATA(ls_ref) =  VALUE ztrs_3028_agnref( bukrs = ls_bank1-bukrs
                                                hbkid = ls_bank1-hbkid
                                                hktid = ls_bank1-hktid
                                                yhzh  = ls_bank1-yhzh
                                                trxno  = ls_bank1-trxno ) .
        CALL METHOD zcl_tr_3024_gui=>lock_1
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.

      LOOP AT et_bank2  INTO DATA(ls_bank2)  .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank2-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_2
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.

      LOOP AT et_bank3  INTO  ls_bank3  .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank3-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_3
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.
    ENDIF.


    IF iv_zz = abap_true.
      CALL METHOD zcl_tr_3024_gui=>query_zz
        EXPORTING
          iv_lock  = iv_lock
          iv_bukrs = iv_bukrs
          iv_zppzt = space
        IMPORTING
          et_bank1 = et_bank1
          et_bank2 = et_bank2
          et_bank  = et_bank
        EXCEPTIONS
          err      = 1
          OTHERS   = 2.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
      WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD qurey_41.

    DATA :  r_1 TYPE RANGE OF zbk_ppzt .
    CASE iv_zppzt .
      WHEN space.
        r_1 = VALUE #( BASE r_1 ( sign = 'I'  option  = 'EQ' low = iv_zppzt ) ) .
      WHEN abap_true .
        r_1 = VALUE #( BASE r_1 ( sign = 'I'  option  = 'NE' low = space ) ) .
      WHEN '*' .
        CLEAR r_1.
    ENDCASE .


    SELECT * FROM ztrt_bank_trans INTO CORRESPONDING FIELDS OF TABLE et_bank1
       WHERE bukrs  = iv_bukrs
         AND hbkid  = iv_hbkid
         AND hktid  = iv_hktid
*         AND shkzg  = iv_shkzg
         AND zppzt  IN r_1
         AND zref_doc = space
         AND zgroup_ac  = iv_group .

    LOOP AT et_bank1 INTO DATA(ls_bank1) .
      DATA(ls_bank) = VALUE ztrs_bank_item( bukrs    =  ls_bank1-bukrs
                                            hbkid    =  ls_bank1-hbkid
                                            hktid    =  ls_bank1-hktid
                                            yhzh     =  ls_bank1-yhzh
                                            hkont    =  ls_bank1-hkont
                                            banks    =  ls_bank1-banks
                                            kunnr    =  ls_bank1-kunnr
                                            lifnr    =  ls_bank1-lifnr
                                            zppzt    =  ls_bank1-zppzt
                                            zppqj    =  ls_bank1-zppqj
                                            zbkitem  =  ls_bank1-trxno
                                            zbkjyri  =  ls_bank1-trxdate
                                            zbkjye   =  ls_bank1-trxamt
                                            zbkfse   =  ls_bank1-bkfse
                                            zbkywt   =  ls_bank1-bustype_txt
                                            zbkyt    =  ls_bank1-usage_txt
                                            zbkzy    =  ls_bank1-abstract_txt
                                            zbkfy    =  ls_bank1-postscript_txt
                                            zbkbz    =  ls_bank1-comment_txt
                                            zbkdkhht =  ls_bank1-bzbnka
                                            zbkdkr   =  ls_bank1-bzbnkn
                                            zbkdkt   =  ls_bank1-bkoinh
                                            waers    =  ls_bank1-waers
                                            shkzg    =  ls_bank1-shkzg ) .
      APPEND ls_bank TO et_bank.
    ENDLOOP.

    SELECT i~db_key
           h~bukrs
           h~hbkid
           h~hktid
           h~banks
           h~bankl
           h~bank_ind
           h~hkont
           z~yhzh
           i~zbkitem
           i~zbkjyri
           i~zbkjysj
           i~zbkjyrit
           i~zbkbczbs
           i~zbkjsms
           i~zbkfse
           i~zbkjye
           i~zbkjyes
           i~zbkjyeh
           i~zbkjyye
           i~zbkfkhht
           i~zbkfkr
           i~zbkfkt
           i~zbkskhht
           i~zbkskr
           i~zbkskt
           i~zbkdkhht
           i~zbkdkr
           i~zbkdkt
           i~zbkywt
           i~zbkzy1
           i~zbkzy2
           i~zbkzy
           i~zbkyt
           i~zbkfy
           i~zbkbz
           i~zbkad1
           i~zbkad2
           i~zbkad3
           i~kunnr
           i~lifnr
           i~zppzt
           i~zppqj
           i~waers
           i~shkzg
       FROM ztrt3023_01 AS h  INNER JOIN ztrt3023_02 AS i ON h~db_key = i~parent_key
                              INNER JOIN ztrt0013    AS z ON z~bukrs  = h~bukrs
                                                         AND z~hbkid  = h~hbkid
                                                         AND z~hktid  = h~hktid
       INTO CORRESPONDING FIELDS OF TABLE et_bank2
      WHERE  h~bukrs  = iv_bukrs
         AND h~hbkid  = iv_hbkid
         AND h~hktid  = iv_hktid
*         AND i~shkzg  = iv_shkzg
         AND i~zppzt  IN r_1
         AND i~zgroup_ac  = iv_group
         AND i~dflag = space
         AND h~dflag = space
         AND zref_doc = space
         AND h~zly  = space .
    IF sy-subrc = 0 .
      APPEND LINES OF et_bank2 TO et_bank.
    ENDIF.

* LOCK
    IF iv_lock IS NOT INITIAL .

      LOOP AT et_bank1 INTO ls_bank1 .
        DATA(ls_ref) =  VALUE ztrs_3028_agnref( bukrs = ls_bank1-bukrs
                                                hbkid = ls_bank1-hbkid
                                                hktid = ls_bank1-hktid
                                                yhzh  = ls_bank1-yhzh
                                                trxno  = ls_bank1-trxno ) .
        CALL METHOD zcl_tr_3024_gui=>lock_1
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.

      LOOP AT et_bank2  INTO DATA(ls_bank2)  .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank2-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_2
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.
    ENDIF.


    IF iv_zz = abap_true.
      CALL METHOD zcl_tr_3024_gui=>query_zz
        EXPORTING
          iv_lock  = iv_lock
          iv_bukrs = iv_bukrs
          iv_zppzt = space
        IMPORTING
          et_bank1 = et_bank1
          et_bank2 = et_bank2
          et_bank  = et_bank
        EXCEPTIONS
          err      = 1
          OTHERS   = 2.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
      WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD qurey_42.

    DATA :  r_1 TYPE RANGE OF zbk_ppzt .
    CASE iv_zppzt .
      WHEN space.
        r_1 = VALUE #( BASE r_1 ( sign = 'I'  option  = 'EQ' low = iv_zppzt ) ) .
      WHEN abap_true .
        r_1 = VALUE #( BASE r_1 ( sign = 'I'  option  = 'NE' low = space ) ) .
      WHEN '*' .
        CLEAR r_1.
    ENDCASE .


    SELECT * FROM ztrt_bank_trans INTO CORRESPONDING FIELDS OF TABLE et_bank1
       WHERE bukrs  = iv_bukrs
         AND hbkid  = iv_hbkid
         AND hktid  = iv_hktid
*         AND shkzg  = iv_shkzg
         AND zppzt  IN r_1
         AND zref_doc = space
         AND split_flag = space
         AND zgroup_ac  = iv_group .

    LOOP AT et_bank1 INTO DATA(ls_bank1) .
      DATA(ls_bank) = VALUE ztrs_bank_item( bukrs    =  ls_bank1-bukrs
                                            hbkid    =  ls_bank1-hbkid
                                            hktid    =  ls_bank1-hktid
                                            hkont    =  ls_bank1-hkont
                                            banks    =  ls_bank1-banks
                                            yhzh     =  ls_bank1-yhzh
                                            kunnr    =  ls_bank1-kunnr
                                            lifnr    =  ls_bank1-lifnr
                                            zppzt    =  ls_bank1-zppzt
                                            zppqj    =  ls_bank1-zppqj
                                            zbkitem  =  ls_bank1-trxno
                                            zbkjyri  =  ls_bank1-trxdate
                                            zbkjye   =  ls_bank1-trxamt
                                            zbkywt   =  ls_bank1-bustype_txt
                                            zbkyt    =  ls_bank1-usage_txt
                                            zbkzy    =  ls_bank1-abstract_txt
                                            zbkfy    =  ls_bank1-postscript_txt
                                            zbkbz    =  ls_bank1-comment_txt
                                            zbkdkhht =  ls_bank1-bzbnka
                                            zbkdkr   =  ls_bank1-bzbnkn
                                            zbkdkt   =  ls_bank1-bkoinh
                                            waers    =  ls_bank1-waers
                                            zsjly = '2'
                                            shkzg    =  ls_bank1-shkzg ) .
      APPEND ls_bank TO et_bank.
    ENDLOOP.

    SELECT

i~db_key,
           h~bukrs,
           h~hbkid,
           h~hktid,
           h~banks,
           h~bankl,
           h~bank_ind,
           h~hkont,
           z~yhzh,
           i~zbkitem,
           i~zbkjyri,
           i~zbkjysj,
           i~zbkjyrit,
           i~zbkbczbs,
           i~zbkjsms,
           i~zbkfse,
           i~zbkjye,
           i~zbkjyes,
           i~zbkjyeh,
           i~zbkjyye,
           i~zbkfkhht,
           i~zbkfkr,
           i~zbkfkt,
           i~zbkskhht,
           i~zbkskr,
           i~zbkskt,
           i~zbkdkhht,
           i~zbkdkr,
           i~zbkdkt,
           i~zbkywt,
           i~zbkzy1,
           i~zbkzy2,
           i~zbkzy,
           i~zbkyt,
           i~zbkfy,
           i~zbkbz,
           i~zbkad1,
           i~zbkad2,
           i~zbkad3,
           i~kunnr,
           i~lifnr,
           i~zppzt,
           i~zppqj,
           i~waers,
           i~shkzg,
          '1' AS zsjly
       FROM ztrt3023_01 AS h  INNER JOIN ztrt3023_02 AS i ON h~db_key = i~parent_key
                              INNER JOIN ztrt0013    AS z ON z~bukrs  = h~bukrs
                                                         AND z~hbkid  = h~hbkid
                                                         AND z~hktid  = h~hktid
       INTO CORRESPONDING FIELDS OF TABLE @et_bank2
      WHERE  h~bukrs  = @iv_bukrs
         AND h~hbkid  = @iv_hbkid
         AND h~hktid  = @iv_hktid
*         AND i~shkzg  = @iv_shkzg
         AND i~zppzt  IN @r_1
         AND i~zgroup_ac  = @iv_group
         AND i~dflag = @space
         AND h~dflag = @space
         AND zref_doc = @space
         AND split_flag = @space
         AND h~zly  = @space .
    IF sy-subrc = 0 .
      APPEND LINES OF et_bank2 TO et_bank.
    ENDIF.
    SELECT * FROM ztrt3023_02_cf INTO CORRESPONDING FIELDS OF TABLE et_bank3
         WHERE bukrs  = iv_bukrs
           AND hbkid  = iv_hbkid
           AND hktid  = iv_hktid
*           AND shkzg  = iv_shkzg
           AND zppzt  IN r_1
           AND zref_doc = space
           AND zgroup_ac  = iv_group .

    LOOP AT et_bank3 INTO DATA(ls_bank3) .
      ls_bank  =  CORRESPONDING #( ls_bank3 ).
      APPEND ls_bank TO et_bank.
      CLEAR ls_bank.
    ENDLOOP.
* LOCK
    IF iv_lock IS NOT INITIAL .

      LOOP AT et_bank1 INTO ls_bank1 .
        DATA(ls_ref) =  VALUE ztrs_3028_agnref( bukrs = ls_bank1-bukrs
                                                hbkid = ls_bank1-hbkid
                                                hktid = ls_bank1-hktid
                                                yhzh  = ls_bank1-yhzh
                                                trxno  = ls_bank1-trxno ) .
        CALL METHOD zcl_tr_3024_gui=>lock_1
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.

      LOOP AT et_bank2  INTO DATA(ls_bank2)  .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank2-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_2
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.

      LOOP AT et_bank3  INTO  ls_bank3  .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank3-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_3
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.
    ENDIF.


    IF iv_zz = abap_true.
      CALL METHOD zcl_tr_3024_gui=>query_zz
        EXPORTING
          iv_lock  = iv_lock
          iv_bukrs = iv_bukrs
          iv_zppzt = space
        IMPORTING
          et_bank1 = et_bank1
          et_bank2 = et_bank2
          et_bank  = et_bank
        EXCEPTIONS
          err      = 1
          OTHERS   = 2.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
      WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD qurey_43.

    DATA :  r_1 TYPE RANGE OF zbk_ppzt .
    CASE iv_zppzt .
      WHEN space.
        r_1 = VALUE #( BASE r_1 ( sign = 'I'  option  = 'EQ' low = iv_zppzt ) ) .
      WHEN abap_true .
        r_1 = VALUE #( BASE r_1 ( sign = 'I'  option  = 'NE' low = space ) ) .
      WHEN '*' .
        CLEAR r_1.
    ENDCASE .


    SELECT * FROM ztrt_bank_trans INTO CORRESPONDING FIELDS OF TABLE et_bank1
       WHERE bukrs  = iv_bukrs
         AND hbkid  = iv_hbkid
         AND hktid  = iv_hktid
*         AND shkzg  = iv_shkzg
         AND zppzt  IN r_1
         AND zref_doc = space
      AND split_flag = space
         AND zgroup_ac  = iv_group .

    LOOP AT et_bank1 INTO DATA(ls_bank1) .
      DATA(ls_bank) = VALUE ztrs_bank_item( bukrs    =  ls_bank1-bukrs
                                            hbkid    =  ls_bank1-hbkid
                                            hktid    =  ls_bank1-hktid
                                            yhzh     =  ls_bank1-yhzh
                                            hkont    =  ls_bank1-hkont
                                            banks    =  ls_bank1-banks
                                            kunnr    =  ls_bank1-kunnr
                                            lifnr    =  ls_bank1-lifnr
                                            zppzt    =  ls_bank1-zppzt
                                            zppqj    =  ls_bank1-zppqj
                                            zbkitem  =  ls_bank1-trxno
                                            zbkjyri  =  ls_bank1-trxdate
                                            zbkjye   =  ls_bank1-trxamt
                                            zbkfse   =  ls_bank1-bkfse
                                            zbkywt   =  ls_bank1-bustype_txt
                                            zbkyt    =  ls_bank1-usage_txt
                                            zbkzy    =  ls_bank1-abstract_txt
                                            zbkfy    =  ls_bank1-postscript_txt
                                            zbkbz    =  ls_bank1-comment_txt
                                            zbkdkhht =  ls_bank1-bzbnka
                                            zbkdkr   =  ls_bank1-bzbnkn
                                            zbkdkt   =  ls_bank1-bkoinh
                                            waers    =  ls_bank1-waers
                                            zsjly = '2'
                                            shkzg    =  ls_bank1-shkzg ) .
      APPEND ls_bank TO et_bank.
    ENDLOOP.

    SELECT
i~db_key,
           h~bukrs,
           h~hbkid,
           h~hktid,
           h~banks,
           h~bankl,
           h~bank_ind,
           h~hkont,
           z~yhzh,
           i~zbkitem,
           i~zbkjyri,
           i~zbkjysj,
           i~zbkjyrit,
           i~zbkbczbs,
           i~zbkjsms,
           i~zbkfse,
           i~zbkjye,
           i~zbkjyes,
           i~zbkjyeh,
           i~zbkjyye,
           i~zbkfkhht,
           i~zbkfkr,
           i~zbkfkt,
           i~zbkskhht,
           i~zbkskr,
           i~zbkskt,
           i~zbkdkhht,
           i~zbkdkr,
           i~zbkdkt,
           i~zbkywt,
           i~zbkzy1,
           i~zbkzy2,
           i~zbkzy,
           i~zbkyt,
           i~zbkfy,
           i~zbkbz,
           i~zbkad1,
           i~zbkad2,
           i~zbkad3,
           i~kunnr,
           i~lifnr,
           i~zppzt,
           i~zppqj,
           i~waers,
           i~shkzg,
          '1' AS zsjly
       FROM ztrt3023_01 AS h  INNER JOIN ztrt3023_02 AS i ON h~db_key = i~parent_key
                              INNER JOIN ztrt0013    AS z ON z~bukrs  = h~bukrs
                                                         AND z~hbkid  = h~hbkid
                                                         AND z~hktid  = h~hktid
       INTO CORRESPONDING FIELDS OF TABLE @et_bank2
      WHERE  h~bukrs  = @iv_bukrs
         AND h~hbkid  = @iv_hbkid
         AND h~hktid  = @iv_hktid
*         AND i~shkzg  = iv_shkzg
         AND i~zppzt  IN @r_1
         AND i~zgroup_ac  = @iv_group
         AND i~dflag = @space
         AND h~dflag = @space
         AND split_flag = @space
         AND zref_doc = @space
         AND h~zly  = @space .
    IF sy-subrc = 0 .
      APPEND LINES OF et_bank2 TO et_bank.
    ENDIF.
    SELECT * FROM ztrt3023_02_cf INTO CORRESPONDING FIELDS OF TABLE et_bank3
         WHERE bukrs  = iv_bukrs
           AND hbkid  = iv_hbkid
           AND hktid  = iv_hktid

           AND zppzt  IN r_1
           AND zref_doc = space
           AND zgroup_ac  = iv_group .

    LOOP AT et_bank3 INTO DATA(ls_bank3) .
      ls_bank  =  CORRESPONDING #( ls_bank3 ).
      APPEND ls_bank TO et_bank.
      CLEAR ls_bank.
    ENDLOOP.
* LOCK
    IF iv_lock IS NOT INITIAL .

      LOOP AT et_bank1 INTO ls_bank1 .
        DATA(ls_ref) =  VALUE ztrs_3028_agnref( bukrs = ls_bank1-bukrs
                                                hbkid = ls_bank1-hbkid
                                                hktid = ls_bank1-hktid
                                                yhzh  = ls_bank1-yhzh
                                                trxno  = ls_bank1-trxno ) .
        CALL METHOD zcl_tr_3024_gui=>lock_1
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.

      LOOP AT et_bank2  INTO DATA(ls_bank2)  .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank2-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_2
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.


      LOOP AT et_bank3  INTO  ls_bank3  .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank3-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_3
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.
    ENDIF.


    IF iv_zz = abap_true.
      CALL METHOD zcl_tr_3024_gui=>query_zz
        EXPORTING
          iv_lock  = iv_lock
          iv_bukrs = iv_bukrs
          iv_zppzt = space
        IMPORTING
          et_bank1 = et_bank1
          et_bank2 = et_bank2
          et_bank  = et_bank
        EXCEPTIONS
          err      = 1
          OTHERS   = 2.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
      WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD qurey_44.

    DATA :  r_1 TYPE RANGE OF zbk_ppzt .
    CASE iv_zppzt .
      WHEN space.
        r_1 = VALUE #( BASE r_1 ( sign = 'I'  option  = 'EQ' low = iv_zppzt ) ) .
      WHEN abap_true .
        r_1 = VALUE #( BASE r_1 ( sign = 'I'  option  = 'NE' low = space ) ) .
      WHEN '*' .
        CLEAR r_1.
    ENDCASE .


    SELECT * FROM ztrt_bank_trans INTO CORRESPONDING FIELDS OF TABLE et_bank1
       WHERE bukrs  = iv_bukrs
         AND hbkid  = iv_hbkid
         AND hktid  = iv_hktid
*         AND shkzg  = iv_shkzg
         AND zppzt  IN r_1
         AND zref_doc = space
         AND zgroup_ac  = iv_group .

    LOOP AT et_bank1 INTO DATA(ls_bank1) .
      DATA(ls_bank) = VALUE ztrs_bank_item( bukrs    =  ls_bank1-bukrs
                                            hbkid    =  ls_bank1-hbkid
                                            hktid    =  ls_bank1-hktid
                                            yhzh     =  ls_bank1-yhzh
                                            hkont    =  ls_bank1-hkont
                                            banks    =  ls_bank1-banks
                                            kunnr    =  ls_bank1-kunnr
                                            lifnr    =  ls_bank1-lifnr
                                            zppzt    =  ls_bank1-zppzt
                                            zppqj    =  ls_bank1-zppqj
                                            zbkitem  =  ls_bank1-trxno
                                            zbkjyri  =  ls_bank1-trxdate
                                            zbkjye   =  ls_bank1-trxamt
                                            zbkfse   =  ls_bank1-bkfse
                                            zbkywt   =  ls_bank1-bustype_txt
                                            zbkyt    =  ls_bank1-usage_txt
                                            zbkzy    =  ls_bank1-abstract_txt
                                            zbkfy    =  ls_bank1-postscript_txt
                                            zbkbz    =  ls_bank1-comment_txt
                                            zbkdkhht =  ls_bank1-bzbnka
                                            zbkdkr   =  ls_bank1-bzbnkn
                                            zbkdkt   =  ls_bank1-bkoinh
                                            waers    =  ls_bank1-waers
                                            zsjly = '2'
                                            shkzg    =  ls_bank1-shkzg ) .
      APPEND ls_bank TO et_bank.
    ENDLOOP.

    SELECT
i~db_key,
           h~bukrs,
           h~hbkid,
           h~hktid,
           h~banks,
           h~bankl,
           h~bank_ind,
           h~hkont,
           z~yhzh,
           i~zbkitem,
           i~zbkjyri,
           i~zbkjysj,
           i~zbkjyrit,
           i~zbkbczbs,
           i~zbkjsms,
           i~zbkfse,
           i~zbkjye,
           i~zbkjyes,
           i~zbkjyeh,
           i~zbkjyye,
           i~zbkfkhht,
           i~zbkfkr,
           i~zbkfkt,
           i~zbkskhht,
           i~zbkskr,
           i~zbkskt,
           i~zbkdkhht,
           i~zbkdkr,
           i~zbkdkt,
           i~zbkywt,
           i~zbkzy1,
           i~zbkzy2,
           i~zbkzy,
           i~zbkyt,
           i~zbkfy,
           i~zbkbz,
           i~zbkad1,
           i~zbkad2,
           i~zbkad3,
           i~kunnr,
           i~lifnr,
           i~zppzt,
           i~zppqj,
           i~waers,
           i~shkzg,
          '1' AS zsjly
       FROM ztrt3023_01 AS h  INNER JOIN ztrt3023_02 AS i ON h~db_key = i~parent_key
                              INNER JOIN ztrt0013    AS z ON z~bukrs  = h~bukrs
                                                         AND z~hbkid  = h~hbkid
                                                         AND z~hktid  = h~hktid
       INTO CORRESPONDING FIELDS OF TABLE @et_bank2
      WHERE  h~bukrs  = @iv_bukrs
         AND h~hbkid  = @iv_hbkid
         AND h~hktid  = @iv_hktid
*         AND i~shkzg  = iv_shkzg
         AND i~zppzt  IN @r_1
         AND i~zgroup_ac  = @iv_group
         AND i~dflag = @space
         AND h~dflag = @space
         AND zref_doc = @space
         AND split_flag = @space
         AND h~zly  = @space .
    IF sy-subrc = 0 .
      APPEND LINES OF et_bank2 TO et_bank.
    ENDIF.
    SELECT * FROM ztrt3023_02_cf INTO CORRESPONDING FIELDS OF TABLE et_bank3
         WHERE bukrs  = iv_bukrs
           AND hbkid  = iv_hbkid
           AND hktid  = iv_hktid
*          AND shkzg  = iv_shkzg
           AND zppzt  IN r_1
           AND zref_doc = space
           AND zgroup_ac  = iv_group .

    LOOP AT et_bank3 INTO DATA(ls_bank3) .
      ls_bank  =  CORRESPONDING #( ls_bank3 ).
      APPEND ls_bank TO et_bank.
      CLEAR ls_bank.
    ENDLOOP.
* LOCK
    IF iv_lock IS NOT INITIAL .

      LOOP AT et_bank1 INTO ls_bank1 .
        DATA(ls_ref) =  VALUE ztrs_3028_agnref( bukrs = ls_bank1-bukrs
                                                hbkid = ls_bank1-hbkid
                                                hktid = ls_bank1-hktid
                                                yhzh  = ls_bank1-yhzh
                                                trxno  = ls_bank1-trxno ) .
        CALL METHOD zcl_tr_3024_gui=>lock_1
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.

      LOOP AT et_bank2  INTO DATA(ls_bank2)  .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank2-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_2
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.

      LOOP AT et_bank3  INTO  ls_bank3  .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank3-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_3
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.
    ENDIF.


    IF iv_zz = abap_true.
      CALL METHOD zcl_tr_3024_gui=>query_zz
        EXPORTING
          iv_lock  = iv_lock
          iv_bukrs = iv_bukrs
          iv_zppzt = space
        IMPORTING
          et_bank1 = et_bank1
          et_bank2 = et_bank2
          et_bank  = et_bank
        EXCEPTIONS
          err      = 1
          OTHERS   = 2.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
      WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD qurey_45.

    DATA :  r_1 TYPE RANGE OF zbk_ppzt .
    DATA :  r_5 TYPE RANGE OF shkzg .
    CASE iv_zppzt .
      WHEN space.
        r_1 = VALUE #( BASE r_1 ( sign = 'I'  option  = 'EQ' low = iv_zppzt ) ) .
      WHEN abap_true .
        r_1 = VALUE #( BASE r_1 ( sign = 'I'  option  = 'NE' low = space ) ) .
      WHEN '*' .
        CLEAR r_1.
    ENDCASE .
    CASE iv_shkzg .
      WHEN space.

      WHEN OTHERS .
        r_5 = VALUE #( BASE r_5 ( sign = 'I'  option  = 'EQ' low = iv_shkzg ) ) .

    ENDCASE .

    SELECT * FROM ztrt_bank_trans INTO CORRESPONDING FIELDS OF TABLE et_bank1
       WHERE bukrs  = iv_bukrs
         AND hbkid  = iv_hbkid
         AND hktid  = iv_hktid
*         AND shkzg  = iv_shkzg
         AND zppzt  IN r_1
         AND zref_doc = space
         AND zgroup_ac  = iv_group .

    LOOP AT et_bank1 INTO DATA(ls_bank1) .
      DATA(ls_bank) = VALUE ztrs_bank_item( bukrs    =  ls_bank1-bukrs
                                            hbkid    =  ls_bank1-hbkid
                                            hktid    =  ls_bank1-hktid
                                            yhzh     =  ls_bank1-yhzh
                                            hkont    =  ls_bank1-hkont
                                            banks    =  ls_bank1-banks
                                            kunnr    =  ls_bank1-kunnr
                                            lifnr    =  ls_bank1-lifnr
                                            zppzt    =  ls_bank1-zppzt
                                            zppqj    =  ls_bank1-zppqj
                                            zbkitem  =  ls_bank1-trxno
                                            zbkjyri  =  ls_bank1-trxdate
                                            zbkjye   =  ls_bank1-trxamt
                                            zbkfse   =  ls_bank1-bkfse
                                            zbkywt   =  ls_bank1-bustype_txt
                                            zbkyt    =  ls_bank1-usage_txt
                                            zbkzy    =  ls_bank1-abstract_txt
                                            zbkfy    =  ls_bank1-postscript_txt
                                            zbkbz    =  ls_bank1-comment_txt
                                            zbkdkhht =  ls_bank1-bzbnka
                                            zbkdkr   =  ls_bank1-bzbnkn
                                            zbkdkt   =  ls_bank1-bkoinh
                                            waers    =  ls_bank1-waers
                                            zsjly = '2'
                                            shkzg    =  ls_bank1-shkzg ) .
      APPEND ls_bank TO et_bank.
    ENDLOOP.

    SELECT
i~db_key,
           h~bukrs,
           h~hbkid,
           h~hktid,
           h~banks,
           h~bankl,
           h~bank_ind,
           h~hkont,
           z~yhzh,
           i~zbkitem,
           i~zbkjyri,
           i~zbkjysj,
           i~zbkjyrit,
           i~zbkbczbs,
           i~zbkjsms,
           i~zbkfse,
           i~zbkjye,
           i~zbkjyes,
           i~zbkjyeh,
           i~zbkjyye,
           i~zbkfkhht,
           i~zbkfkr,
           i~zbkfkt,
           i~zbkskhht,
           i~zbkskr,
           i~zbkskt,
           i~zbkdkhht,
           i~zbkdkr,
           i~zbkdkt,
           i~zbkywt,
           i~zbkzy1,
           i~zbkzy2,
           i~zbkzy,
           i~zbkyt,
           i~zbkfy,
           i~zbkbz,
           i~zbkad1,
           i~zbkad2,
           i~zbkad3,
           i~kunnr,
           i~lifnr,
           i~zppzt,
           i~zppqj,
           i~waers,
           i~shkzg,
          '1' AS zsjly
       FROM ztrt3023_01 AS h  INNER JOIN ztrt3023_02 AS i ON h~db_key = i~parent_key
                              INNER JOIN ztrt0013    AS z ON z~bukrs  = h~bukrs
                                                         AND z~hbkid  = h~hbkid
                                                         AND z~hktid  = h~hktid
       INTO CORRESPONDING FIELDS OF TABLE @et_bank2
      WHERE  h~bukrs  = @iv_bukrs
         AND h~hbkid  = @iv_hbkid
         AND h~hktid  = @iv_hktid
*         AND i~shkzg  = iv_shkzg
         AND i~zppzt  IN @r_1
         AND i~zgroup_ac  = @iv_group
         AND i~dflag = @space
         AND h~dflag = @space
         AND zref_doc = @space
         AND split_flag = @space
         AND h~zly  = @space .
    IF sy-subrc = 0 .
      APPEND LINES OF et_bank2 TO et_bank.
    ENDIF.
    SELECT * FROM ztrt3023_02_cf INTO CORRESPONDING FIELDS OF TABLE et_bank3
         WHERE bukrs  = iv_bukrs
           AND hbkid  = iv_hbkid
           AND hktid  = iv_hktid
           "AND shkzg  = iv_shkzg
           AND zppzt  IN r_1
           AND zref_doc = space
           AND zgroup_ac  = iv_group .

    LOOP AT et_bank3 INTO DATA(ls_bank3) .
      ls_bank  =  CORRESPONDING #( ls_bank3 ).
      APPEND ls_bank TO et_bank.
      CLEAR ls_bank.
    ENDLOOP.
* LOCK
    IF iv_lock IS NOT INITIAL .

      LOOP AT et_bank1 INTO ls_bank1 .
        DATA(ls_ref) =  VALUE ztrs_3028_agnref( bukrs = ls_bank1-bukrs
                                                hbkid = ls_bank1-hbkid
                                                hktid = ls_bank1-hktid
                                                yhzh  = ls_bank1-yhzh
                                                trxno  = ls_bank1-trxno ) .
        CALL METHOD zcl_tr_3024_gui=>lock_1
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.

      LOOP AT et_bank2  INTO DATA(ls_bank2)  .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank2-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_2
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.

      LOOP AT et_bank3  INTO  ls_bank3  .
        ls_ref  =  VALUE ztrs_3028_agnref( db_key = ls_bank3-db_key ) .
        CALL METHOD zcl_tr_3024_gui=>lock_3
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.
    ENDIF.


    IF iv_zz = abap_true.
      CALL METHOD zcl_tr_3024_gui=>query_zz
        EXPORTING
          iv_lock  = iv_lock
          iv_bukrs = iv_bukrs
          iv_zppzt = space
        IMPORTING
          et_bank1 = et_bank1
          et_bank2 = et_bank2
          et_bank  = et_bank
        EXCEPTIONS
          err      = 1
          OTHERS   = 2.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
      WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err.
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD set_ref2_by_ref.
    DATA lt_draft_d TYPE TABLE OF  ztrt0050_bktrns .
    DATA lt_draft_m TYPE TABLE OF  ztrt0050_bktrns .
    "  CHECK et_bank_draft[] IS NOT INITIAL.
    IF iv_del = abap_false.

      DELETE et_bank_draft WHERE draft IS  INITIAL OR zbkitem IS INITIAL .
      CHECK et_bank_draft[] IS NOT INITIAL.
      SELECT *
      INTO CORRESPONDING FIELDS OF TABLE  lt_draft_d
      FROM ztrt0050_bktrns
      FOR ALL ENTRIES IN et_bank_draft
      WHERE  docno =  iv_doc
      AND draft =  et_bank_draft-draft
       AND zxh = et_bank_draft-zxh  .

      CASE  iv_group  .
        WHEN '26'.  "贴现银行流水匹配
*          SELECT *
*          FROM ztrt0078_item AS a
*          INNER JOIN ztrt0050 AS b
*          ON a~docno_key = b~docno_key
*          INTO CORRESPONDING FIELDS OF TABLE lt_draft_m
*            FOR ALL ENTRIES IN et_bank_draft
*          WHERE a~docno = iv_doc
*          "  AND itmst IN ('15','20')
*          AND a~draft =  et_bank_draft-draft
*          AND a~zxh =  et_bank_draft-zxh.

        WHEN '27'.  "托收银行流水匹配

          SELECT *
          FROM ztrt0072 AS a
          INNER JOIN ztrt0050 AS b
          ON a~docno_key = b~docno_key
          INTO CORRESPONDING FIELDS OF TABLE lt_draft_m
            FOR ALL ENTRIES IN et_bank_draft
          WHERE a~docno = iv_doc
      "    AND a~zitem_status IN ('15','20')
         AND a~draft =  et_bank_draft-draft
         AND a~zxh =  et_bank_draft-zxh
            . "只匹配财务已确认和会计已过账的行项目

        WHEN '36'.  "回购银行流水匹配
*          SELECT *
*          FROM ztrt0078_item AS a
*          INNER JOIN ztrt0099_item AS b   ON b~txdoc = a~docno      AND a~zxh = b~zxh
*          INNER JOIN ztrt0050 AS c        ON a~docno_key = c~docno_key
*          INTO CORRESPONDING FIELDS OF TABLE lt_draft_m
*            FOR ALL ENTRIES IN et_bank_draft
*          WHERE b~docno = iv_doc
*        "  AND itmst IN ('15','20')
*          AND a~draft =  et_bank_draft-draft
*          AND b~sernr =  et_bank_draft-zxh.
*


        WHEN OTHERS.
      ENDCASE.

      IF lt_draft_m[] IS NOT INITIAL.  "已进行流水匹配到汇票"72表只保存一条流水，另建表ZTRT0050_BKTRNS保存
        LOOP AT et_bank_draft ASSIGNING FIELD-SYMBOL(<fs>) .

          READ TABLE lt_draft_m INTO DATA(ls_draft) WITH  KEY draft = <fs>-draft  zxh = <fs>-zxh.
          IF sy-subrc = 0 .
            ls_draft-zbkitem = <fs>-zbkitem.
            ls_draft-zbkjye = <fs>-zbkjye.
            MOVE-CORRESPONDING ls_draft TO <fs>.

            <fs>-aptype = COND #( WHEN iv_group = '26' THEN 'H004'
                                  WHEN iv_group = '27' THEN 'H003'
                                  WHEN iv_group = '36' THEN 'H006'
             ).
            <fs>-erdat = sy-datum.
            <fs>-erzet = sy-uzeit.
            <fs>-ernam = sy-uname.
          ENDIF.
        ENDLOOP.
*        ELSE. "尚未进行流水匹配到汇票，需切换
*
      ENDIF.
      DELETE ztrt0050_bktrns  FROM TABLE lt_draft_d.
      MODIFY ztrt0050_bktrns FROM  TABLE  et_bank_draft.
    ELSE.
      CLEAR lt_draft_d.
      DELETE et_bank_draft WHERE docno NE  iv_doc.
      CHECK et_bank_draft[] IS NOT INITIAL.
      SELECT *
      INTO CORRESPONDING FIELDS OF TABLE  lt_draft_d
      FROM ztrt0050_bktrns
        FOR ALL ENTRIES IN et_bank_draft
      WHERE  docno =  iv_doc
         AND docno = et_bank_draft-docno
         AND zxh = et_bank_draft-zxh
         AND draft = et_bank_draft-draft        .
      IF sy-subrc = 0.
        DELETE ztrt0050_bktrns  FROM TABLE lt_draft_d.
      ENDIF.
    ENDIF.

    IF iv_commit = 'X'.
      COMMIT WORK AND WAIT.

    ENDIF.

  ENDMETHOD.


METHOD unagn_ref.

    DATA : lt_ref_3 TYPE ztrt_3028_agnref,
           lt_ref_2 TYPE ztrt_3028_agnref,
           lt_ref_1 TYPE ztrt_3028_agnref.
    CLEAR: gt_pp_02,gt_btrans.
    "20200102 取消流水匹配时的关联验证（DYNPRO程序后面会全量重新匹配）
    "同户名划转需匹配两笔流水时可能存在自动匹配成功一笔流水，当手工在支付单上匹配第二笔流水时校验会卡住 T004
    SELECT SINGLE zzftype INTO @DATA(zfdtype)  FROM ztrt2001 WHERE docno = @iv_doc .
    IF sy-subrc = 0 AND zfdtype NE 'T004' AND zfdtype NE 'T005' AND  zfdtype NE 'T006'.
      "20200102 取消流水匹配时的关联验证（DYNPRO程序后面会全量重新匹配）
      SELECT COUNT(*) FROM ztrt3023_02
       WHERE zref_doc = iv_doc
         AND zgroup_ac = iv_group
         AND zppzt <> ''
         AND dflag      = space .
      IF sy-subrc = 0.
        MESSAGE e466(ztr01) RAISING err.
      ENDIF.


      SELECT COUNT(*) FROM ztrt_bank_trans
       WHERE zref_doc = iv_doc
         AND zgroup_ac = iv_group
         AND zppzt <> ''.
      IF sy-subrc = 0.
        MESSAGE e466(ztr01) RAISING err.
      ENDIF.
    ENDIF.
*    IF iv_lock = abap_true .

    SELECT db_key FROM ztrt3023_02 INTO CORRESPONDING FIELDS OF TABLE lt_ref_2
     WHERE zref_doc = iv_doc
       AND zgroup_ac = iv_group
       AND dflag      = space
         AND split_flag      = space .

    LOOP AT  lt_ref_2 INTO DATA(ls_ref) .
      CALL METHOD zcl_tr_3024_gui=>lock_2
        EXPORTING
          iv_trans = ls_ref
        EXCEPTIONS
          err      = 1
          OTHERS   = 2.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
          WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
      ENDIF.
    ENDLOOP.

    SELECT * FROM ztrt_bank_trans INTO CORRESPONDING FIELDS OF TABLE lt_ref_1
       WHERE zref_doc = iv_doc
         AND zgroup_ac = iv_group
         AND split_flag      = space.

    LOOP AT  lt_ref_1 INTO ls_ref.
      CALL METHOD zcl_tr_3024_gui=>lock_1
        EXPORTING
          iv_trans = ls_ref
        EXCEPTIONS
          err      = 1
          OTHERS   = 2.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
          WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
      ENDIF.
    ENDLOOP .
*    ENDIF.
    SELECT db_key FROM ztrt3023_02_cf INTO CORRESPONDING FIELDS OF TABLE lt_ref_3
    WHERE zref_doc = iv_doc
    AND zgroup_ac = iv_group  .

    LOOP AT  lt_ref_3 INTO  ls_ref  .
      CALL METHOD zcl_tr_3024_gui=>lock_3
        EXPORTING
          iv_trans = ls_ref
        EXCEPTIONS
          err      = 1
          OTHERS   = 2.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
        WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
      ENDIF.
    ENDLOOP.



*   modify table
    DATA lv_db1 TYPE ztrt3023_02 .
    SELECT * FROM ztrt3023_02 INTO lv_db1  WHERE zref_doc = iv_doc  AND zgroup_ac = iv_group   AND dflag      = space .
      UPDATE  ztrt3023_02 SET  zref_doc  = space
                               zgroup_ac = lv_db1-zgroup
                               zppzt = ''
                               zppqj = '000000'

                               iaedat  = sy-datum
                                iaezet  = sy-uzeit
                                iaenam = sy-uname
                                itcode = sy-tcode
                        WHERE  db_key    = lv_db1-db_key  .

      IF lv_db1-zppqj NE '000000'.
        APPEND lv_db1 TO gt_pp_02.
      ENDIF.

    ENDSELECT .
    DATA lv_db3 TYPE ztrt3023_02_cf .
    SELECT * FROM ztrt3023_02_cf INTO lv_db3  WHERE zref_doc = iv_doc  AND zgroup_ac = iv_group     .
      UPDATE  ztrt3023_02_cf SET  zref_doc  = space
      zgroup_ac = lv_db3-zgroup
      zppzt = ''
      zppqj = '000000'
      iaedat  = sy-datum
      iaezet  = sy-uzeit
      iaenam = sy-uname
      itcode = sy-tcode
      WHERE  db_key    = lv_db3-db_key  .

      IF lv_db3-zppqj NE '000000'.
        APPEND lv_db3 TO gt_pp_02_cf.
      ENDIF.

    ENDSELECT .

    DATA lv_db2 TYPE ztrt_bank_trans .
    SELECT  * FROM ztrt_bank_trans INTO lv_db2  WHERE zref_doc = iv_doc   AND zgroup_ac = iv_group .
      UPDATE ztrt_bank_trans SET  zref_doc  = space
                                  zgroup_ac = lv_db2-zgroup
                                  zppzt = ''
                                  zppqj = '000000'
                           WHERE  bukrs   = lv_db2-bukrs
                             AND  hbkid   = lv_db2-hbkid
                             AND  hktid   = lv_db2-hktid
                             AND  yhzh    = lv_db2-yhzh
                             AND  trxno   = lv_db2-trxno .
      IF lv_db2-zppqj NE '000000'.
        APPEND lv_db2 TO gt_btrans.
      ENDIF.
    ENDSELECT .
**********   同时有对账的数据也要取消掉 20200813 add by hjj
*    UPDATE ztrt3023_03_log SET aedat = sy-datum   aezet = sy-uzeit   aenam = sy-uname   action = 'X'
*                WHERE zgroup_ac = iv_group AND zref_doc = iv_doc. “暂时不更新，留着回写已对账的流水

    DELETE FROM ztrt3023_03 WHERE zgroup_ac = iv_group AND zref_doc = iv_doc.
**********   同时有对账的数据也要取消掉 20200813 add by hjj

    IF iv_commit = abap_true .
      COMMIT WORK AND WAIT .
    ENDIF.

*    IF iv_lock = abap_true .
    LOOP AT lt_ref_2 INTO ls_ref .

      CALL METHOD zcl_tr_3024_gui=>unlock_2
        EXPORTING
          iv_trans = ls_ref
        EXCEPTIONS
          err      = 1
          OTHERS   = 2.
      IF sy-subrc <> 0.
      ENDIF.
    ENDLOOP.
    LOOP AT lt_ref_1 INTO ls_ref .
      CALL METHOD zcl_tr_3024_gui=>unlock_1
        EXPORTING
          iv_trans = ls_ref
        EXCEPTIONS
          err      = 1
          OTHERS   = 2.
      IF sy-subrc <> 0.
      ENDIF.
    ENDLOOP.
*    ENDIF.
    LOOP AT lt_ref_3 INTO ls_ref .
      CALL METHOD zcl_tr_3024_gui=>unlock_3
        EXPORTING
          iv_trans = ls_ref
        EXCEPTIONS
          err      = 1
          OTHERS   = 2.
      IF sy-subrc <> 0.
      ENDIF.
    ENDLOOP.

  ENDMETHOD.


METHOD unagn_ref_draft.

    DATA : lt_ref_3 TYPE ztrt_3028_agnref,
           lt_ref_2 TYPE ztrt_3028_agnref,
           lt_ref_1 TYPE ztrt_3028_agnref.

    DATA:lt_del_draft TYPE TABLE OF ztrt0050_bktrns.

    SELECT COUNT(*) INTO @DATA(lv_ppsl)
          FROM ztrt0050_bktrns
          WHERE   docno = @iv_doc.

    IF lv_ppsl > 0.

      SELECT * FROM ztrt0050_bktrns
       INTO TABLE lt_del_draft
        FOR ALL ENTRIES IN it_draft
       WHERE  docno = iv_doc
      AND docno = it_draft-docno
      AND zxh = it_draft-zxh
      "AND zbkitem = it_draft-zbkitem
        .


      SELECT db_key FROM ztrt3023_02 INTO CORRESPONDING FIELDS OF TABLE lt_ref_2
       WHERE zref_doc = iv_doc
         AND zgroup_ac = iv_group
         AND dflag      = space
         AND split_flag      = space
         .

      LOOP AT  lt_ref_2 INTO DATA(ls_ref) .

        CALL METHOD zcl_tr_3024_gui=>lock_2
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.

      SELECT db_key FROM ztrt3023_02_cf INTO CORRESPONDING FIELDS OF TABLE lt_ref_3
      WHERE zref_doc = iv_doc
      AND zgroup_ac = iv_group .

      LOOP AT  lt_ref_3 INTO  ls_ref  .

        CALL METHOD zcl_tr_3024_gui=>lock_3
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
          WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.

      SELECT * FROM ztrt_bank_trans INTO CORRESPONDING FIELDS OF TABLE lt_ref_1
         WHERE zref_doc = iv_doc
           AND zgroup_ac = iv_group
         AND split_flag      = space.

      LOOP AT  lt_ref_1 INTO ls_ref.
        CALL METHOD zcl_tr_3024_gui=>lock_1
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP .
*    ENDIF.
      "解除银行与财务凭证匹配20201014
      zcl_tr_3024_gui=>unmapping_by_ref(
      EXPORTING
        iv_group  = iv_group   " 实际对账路径
        iv_doc    = iv_doc    " 关联业务单据
        iv_lock   = abap_false    " 锁
        iv_commit = abap_true    " COMMIT
      EXCEPTIONS
        err       = 1
        OTHERS    = 2
        ).
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
        WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4       RAISING err.
        ROLLBACK WORK.
        EXIT.
      ENDIF.




*   modify table
      DATA lv_db1 TYPE ztrt3023_02 .
      SELECT * FROM ztrt3023_02 INTO lv_db1  WHERE zref_doc = iv_doc  AND zgroup_ac = iv_group   AND dflag      = space .
        READ TABLE lt_del_draft INTO DATA(ls_del_draft) WITH  KEY zbkitem = lv_db1-zbkitem.
        IF sy-subrc <> 0 AND lv_ppsl > 0   ."已发生流水关联汇票
          CONTINUE.
        ENDIF.


        UPDATE  ztrt3023_02 SET  zref_doc  = space
                                 zgroup_ac = lv_db1-zgroup
                                 zppzt = ''
                                 zppqj = '000000'

                                 iaedat  = sy-datum
  iaezet  = sy-uzeit
  iaenam = sy-uname
  itcode = sy-tcode
                          WHERE  db_key    = lv_db1-db_key  .
      ENDSELECT .

      DATA lv_db3 TYPE ztrt3023_02_cf .
      SELECT * FROM ztrt3023_02_cf INTO lv_db3  WHERE zref_doc = iv_doc  AND zgroup_ac = iv_group  .
        READ TABLE lt_del_draft INTO  ls_del_draft  WITH  KEY zbkitem = lv_db1-zbkitem.
        IF sy-subrc <> 0 AND lv_ppsl > 0   ."已发生流水关联汇票
          CONTINUE.
        ENDIF.


        UPDATE  ztrt3023_02_cf SET  zref_doc  = space
        zgroup_ac = lv_db3-zgroup
        zppzt = ''
        zppqj = '000000'

        iaedat  = sy-datum
        iaezet  = sy-uzeit
        iaenam = sy-uname
        itcode = sy-tcode
        WHERE  db_key    = lv_db3-db_key  .
      ENDSELECT .


      DATA lv_db2 TYPE ztrt_bank_trans .
      SELECT  * FROM ztrt_bank_trans INTO lv_db2  WHERE zref_doc = iv_doc   AND zgroup_ac = iv_group .
        READ TABLE lt_del_draft INTO  ls_del_draft  WITH  KEY zbkitem = lv_db2-trxno.
        IF sy-subrc <> 0 AND lv_ppsl > 0."已发生流水关联汇票
          CONTINUE.
        ENDIF.
        UPDATE ztrt_bank_trans SET  zref_doc  = space
                                    zgroup_ac = lv_db2-zgroup
                                    zppzt = ''
                                    zppqj = '000000'
                             WHERE  bukrs   = lv_db2-bukrs
                               AND  hbkid   = lv_db2-hbkid
                               AND  hktid   = lv_db2-hktid
                               AND  yhzh    = lv_db2-yhzh
                               AND  trxno   = lv_db2-trxno .
      ENDSELECT .


      IF iv_commit = abap_true .
        COMMIT WORK AND WAIT .
      ENDIF.

*    IF iv_lock = abap_true .
      LOOP AT lt_ref_2 INTO ls_ref .

        CALL METHOD zcl_tr_3024_gui=>unlock_2
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
        ENDIF.
      ENDLOOP.
      LOOP AT lt_ref_1 INTO ls_ref .
        CALL METHOD zcl_tr_3024_gui=>unlock_1
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
        ENDIF.
      ENDLOOP.
*    ENDIF.
    ENDIF.

    "判断流水 是否全部取消，是则再次调用取消功能
    CLEAR lv_ppsl.
    SELECT COUNT(*) INTO  lv_ppsl
          FROM ztrt0050_bktrns
          WHERE   docno =  iv_doc .
    IF lv_ppsl = 0.
      unagn_ref(  EXPORTING
             iv_group = iv_group
             iv_doc   = iv_doc ).

    ENDIF.

  ENDMETHOD.


METHOD unagn_ref_tr2.
*
*    DATA : lt_ref_2 TYPE ztrt_3028_agnref,
*           lt_ref_1 TYPE ztrt_3028_agnref.
*    CLEAR: gt_pp_02,gt_btrans.
**    "20200102 取消流水匹配时的关联验证（DYNPRO程序后面会全量重新匹配）
**    "同户名划转需匹配两笔流水时可能存在自动匹配成功一笔流水，当手工在支付单上匹配第二笔流水时校验会卡住 T004
**    SELECT SINGLE zzftype INTO @DATA(zfdtype)  FROM ztrt2001 WHERE docno = @iv_doc .
**    IF sy-subrc = 0 AND zfdtype NE 'T004' AND zfdtype NE 'T005' AND  zfdtype NE 'T006'.
**      "20200102 取消流水匹配时的关联验证（DYNPRO程序后面会全量重新匹配）
**      SELECT COUNT(*) FROM ztrt3023_02
**       WHERE zref_doc = iv_doc
**         AND zgroup_ac = iv_group
**         AND zppzt <> ''
**         AND dflag      = space .
**      IF sy-subrc = 0.
**        MESSAGE e466(ztr01) RAISING err.
**      ENDIF.
**
**
**      SELECT COUNT(*) FROM ztrt_bank_trans
**       WHERE zref_doc = iv_doc
**         AND zgroup_ac = iv_group
**         AND zppzt <> ''.
**      IF sy-subrc = 0.
**        MESSAGE e466(ztr01) RAISING err.
**      ENDIF.
**    ENDIF.
***    IF iv_lock = abap_true .
*
*
**&BEGIN-------------------------------------------------------------
**&费用+兑付金额
**&CHANGE DATE: 09.03.2020
**&AUTHOR    : HANDXXJ
**&------------------------------------------------------------------
*    "获取银行流水与单据号关联关系记录表
*    SELECT *
*      FROM ztr2t1058
*      INTO TABLE @DATA(lt_exist)
*      WHERE zref_doc = @iv_doc
*        AND zgroup_ac = @iv_group
*        AND jxlxt = @iv_jxlxt.
**&END---------------------------------------------------------------
*
*    SELECT db_key FROM ztrt3023_02 INTO CORRESPONDING FIELDS OF TABLE lt_ref_2
*     WHERE zref_doc = iv_doc
*       AND zgroup_ac = iv_group
*       AND dflag      = space .
*
**&BEGIN-------------------------------------------------------------
**&排除非此种金额类型的行
**&CHANGE DATE: 09.03.2020
**&AUTHOR    : HANDXXJ
**&------------------------------------------------------------------
*    LOOP AT lt_ref_2 INTO DATA(ls_ref_2).
*      DATA(lv_tabix) = sy-tabix.
*      READ TABLE lt_exist INTO DATA(ls_exist) WITH KEY db_key = ls_ref_2-db_key.
*      IF sy-subrc NE 0.
*        DELETE lt_ref_2 INDEX lv_tabix.
*      ENDIF.
*    ENDLOOP.
**&END---------------------------------------------------------------
*
*    LOOP AT  lt_ref_2 INTO DATA(ls_ref) .
*      CALL METHOD zcl_tr_3024_gui=>lock_2
*        EXPORTING
*          iv_trans = ls_ref
*        EXCEPTIONS
*          err      = 1
*          OTHERS   = 2.
*      IF sy-subrc <> 0.
*        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
*          WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
*      ENDIF.
*    ENDLOOP.
*
*    SELECT * FROM ztrt_bank_trans INTO CORRESPONDING FIELDS OF TABLE lt_ref_1
*       WHERE zref_doc = iv_doc
*         AND zgroup_ac = iv_group .
*
**&BEGIN-------------------------------------------------------------
**&排除非此种金额类型的行
**&CHANGE DATE: 09.03.2020
**&AUTHOR    : HANDXXJ
**&------------------------------------------------------------------
*    LOOP AT lt_ref_1 INTO DATA(ls_ref_1).
*      lv_tabix = sy-tabix.
*      READ TABLE lt_exist INTO ls_exist WITH KEY bukrs   = ls_ref_1-bukrs
*                                                 hbkid   = ls_ref_1-hbkid
*                                                 hktid   = ls_ref_1-hktid
**                                                yhzh    = lv_db2-yhzh
*                                                 trxno   = ls_ref_1-trxno .
*      IF sy-subrc NE 0.
*        DELETE lt_ref_1 INDEX lv_tabix.
*      ENDIF.
*    ENDLOOP.
**&END---------------------------------------------------------------
*
*    LOOP AT  lt_ref_1 INTO ls_ref.
*      CALL METHOD zcl_tr_3024_gui=>lock_1
*        EXPORTING
*          iv_trans = ls_ref
*        EXCEPTIONS
*          err      = 1
*          OTHERS   = 2.
*      IF sy-subrc <> 0.
*        MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
*          WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
*      ENDIF.
*    ENDLOOP .
**    ENDIF.
*
*
*
*
**   modify table
**&BEGIN-------------------------------------------------------------
**&CHANGE DATE: 09.03.2020
**&AUTHOR    : HANDXXJ
**&------------------------------------------------------------------
**    DATA lv_db1 TYPE  ztrt3023_02 .
**    SELECT * FROM ztrt3023_02 INTO lv_db1  WHERE zref_doc = iv_doc  AND zgroup_ac = iv_group   AND dflag      = space .
**      UPDATE  ztrt3023_02 SET  zref_doc  = space
**                                  zgroup_ac = lv_db1-zgroup
**                                  zppzt = ''
**                                  zppqj = '000000'
**
**                                  iaedat  = sy-datum
**                                   iaezet  = sy-uzeit
**                                   iaenam = sy-uname
**                                   itcode = sy-tcode
**                           WHERE  db_key    = lv_db1-db_key  .
**
**      IF lv_db1-zppqj NE '000000'.
**        APPEND lv_db1 TO gt_pp_02.
**      ENDIF.
**    ENDSELECT .
*
**    DATA lv_db2 TYPE ztrt_bank_trans .
**    SELECT  * FROM ztrt_bank_trans INTO lv_db2  WHERE zref_doc = iv_doc   AND zgroup_ac = iv_group .
**      UPDATE ztrt_bank_trans SET  zref_doc  = space
**                                  zgroup_ac = lv_db2-zgroup
**                                  zppzt = ''
**                                  zppqj = '000000'
**                           WHERE  bukrs   = lv_db2-bukrs
**                             AND  hbkid   = lv_db2-hbkid
**                             AND  hktid   = lv_db2-hktid
**                             AND  yhzh    = lv_db2-yhzh
**                             AND  trxno   = lv_db2-trxno .
**      IF lv_db2-zppqj NE '000000'.
**        APPEND lv_db2 TO gt_btrans.
**      ENDIF.
**    ENDSELECT .
*    DATA: lt_db1 TYPE STANDARD TABLE OF ztrt3023_02,
*          lt_db2 TYPE STANDARD TABLE OF ztrt_bank_trans.
*
*    IF lt_ref_2[] IS NOT INITIAL.
*      SELECT *
*        FROM ztrt3023_02
*        INTO TABLE lt_db1
*        FOR ALL ENTRIES IN lt_ref_2
*        WHERE db_key = lt_ref_2-db_key .
*    ENDIF.
*
*    IF lt_ref_1[] IS NOT INITIAL.
*      SELECT  *
*        FROM ztrt_bank_trans
*        INTO TABLE lt_db2
*        FOR ALL ENTRIES IN lt_ref_1
*        WHERE  bukrs   = lt_ref_1-bukrs
*          AND  hbkid   = lt_ref_1-hbkid
*          AND  hktid   = lt_ref_1-hktid
*          AND  trxno   = lt_ref_1-trxno .
*    ENDIF.
*
*    LOOP AT lt_ref_2 INTO ls_ref_2.
*      READ TABLE lt_db1 INTO DATA(ls_db1) WITH KEY db_key = ls_ref_2-db_key.
*
*      UPDATE  ztrt3023_02 SET  zref_doc  = space
*                               zgroup_ac = ls_db1-zgroup
*                               zppzt = ''
*                               zppqj = '000000'
*
*                               iaedat  = sy-datum
*                                iaezet  = sy-uzeit
*                                iaenam = sy-uname
*                                itcode = sy-tcode
*                        WHERE  db_key    = ls_db1-db_key  .
*
*      IF ls_db1-zppqj NE '000000'.
*        APPEND ls_db1 TO gt_pp_02.
*      ENDIF.
*      CLEAR: ls_db1.
*    ENDLOOP.
*
*    LOOP AT lt_ref_1 INTO ls_ref_1.
*      READ TABLE lt_db2 INTO DATA(ls_db2) WITH KEY bukrs   = ls_ref_1-bukrs
*                                                   hbkid   = ls_ref_1-hbkid
*                                                   hktid   = ls_ref_1-hktid
*                                                   trxno   = ls_ref_1-trxno .
*
*
*      UPDATE ztrt_bank_trans SET  zref_doc  = space
*                              zgroup_ac = ls_db2-zgroup
*                              zppzt = ''
*                              zppqj = '000000'
*                       WHERE  bukrs   = ls_db2-bukrs
*                         AND  hbkid   = ls_db2-hbkid
*                         AND  hktid   = ls_db2-hktid
**                         AND  yhzh    = ls_db2-yhzh
*                         AND  trxno   = ls_db2-trxno .
*      IF ls_db2-zppqj NE '000000'.
*        APPEND ls_db2 TO gt_btrans.
*      ENDIF.
*      CLEAR: ls_db2.
*    ENDLOOP.
*
**&END---------------------------------------------------------------
*
*
*
***********   同时有对账的数据也要取消掉 20200813 add by hjj
**    UPDATE ztrt3023_03_log SET aedat = sy-datum   aezet = sy-uzeit   aenam = sy-uname   action = 'X'
**                WHERE zgroup_ac = iv_group AND zref_doc = iv_doc. “暂时不更新，留着回写已对账的流水
*
*
**&BEGIN-------------------------------------------------------------
**&费用+兑付金额
**&CHANGE DATE: 09.03.2020
**&AUTHOR    : HANDXXJ
**&------------------------------------------------------------------
**    DELETE FROM ztrt3023_03 WHERE zgroup_ac = iv_group AND zref_doc = iv_doc.
*
*    LOOP AT lt_ref_2 INTO ls_ref_2.
*      DELETE FROM ztrt3023_03 WHERE db_key = ls_ref_2-db_key.
*    ENDLOOP.
*
*    LOOP AT lt_ref_1 INTO ls_ref_1.
*      DELETE FROM ztrt3023_03 WHERE  bukrs   = ls_ref_1-bukrs
*                         AND  hbkid   = ls_ref_1-hbkid
*                         AND  hktid   = ls_ref_1-hktid
**                         AND  yhzh    = ls_ref_1-yhzh
*                         AND  trxno   = ls_ref_1-trxno .
*    ENDLOOP.
**&END---------------------------------------------------------------
*
***********   同时有对账的数据也要取消掉 20200813 add by hjj
*
*    IF iv_commit = abap_true .
*      COMMIT WORK AND WAIT .
*    ENDIF.
*
**    IF iv_lock = abap_true .
*    LOOP AT lt_ref_2 INTO ls_ref .
*
*      CALL METHOD zcl_tr_3024_gui=>unlock_2
*        EXPORTING
*          iv_trans = ls_ref
*        EXCEPTIONS
*          err      = 1
*          OTHERS   = 2.
*      IF sy-subrc <> 0.
*      ENDIF.
*    ENDLOOP.
*    LOOP AT lt_ref_1 INTO ls_ref .
*      CALL METHOD zcl_tr_3024_gui=>unlock_1
*        EXPORTING
*          iv_trans = ls_ref
*        EXCEPTIONS
*          err      = 1
*          OTHERS   = 2.
*      IF sy-subrc <> 0.
*      ENDIF.
*    ENDLOOP.
**    ENDIF.
*

  ENDMETHOD.


METHOD unlock_1.
    CALL FUNCTION 'DEQUEUE_EZTRT_BANK_TRANS'
      EXPORTING
        mode_ztrt_bank_trans = 'E'
        mandt                = sy-mandt
        bukrs                = iv_trans-bukrs
        hbkid                = iv_trans-hbkid
        hktid                = iv_trans-hktid
        yhzh                 = iv_trans-yhzh
        trxno                = iv_trans-trxno
        _scope               = '3'
      EXCEPTIONS
        foreign_lock         = 1
        system_failure       = 2
        OTHERS               = 3.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
        WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
    ENDIF.
  ENDMETHOD.


METHOD unlock_2.
    CALL FUNCTION 'DEQUEUE_EZZTRT3023_02'
      EXPORTING
*       mode_ztrt3023_02 = 'X'
        mandt          = sy-mandt
        db_key         = iv_trans-db_key
        _scope         = '3'
      EXCEPTIONS
        foreign_lock   = 1
        system_failure = 2
        OTHERS         = 3.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
        WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
    ENDIF.
  ENDMETHOD.


METHOD unlock_3.
    CALL FUNCTION 'DEQUEUE_EZTRT3023_CF'
      EXPORTING
*       MODE_ZTRT3023_02_CF = 'X'
        mandt          = sy-mandt
        db_key         = iv_trans-db_key
        _scope         = '3'
      EXCEPTIONS
        foreign_lock   = 1
        system_failure = 2
        OTHERS         = 3.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
        WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
    ENDIF.

  ENDMETHOD.


METHOD unlock_all.
    LOOP AT it_trans INTO DATA(ls_ref) .
      IF  ls_ref-split_flag = 'Y'.
        CALL METHOD zcl_tr_3024_gui=>unlock_3
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
        ENDIF.
        CONTINUE.

      ENDIF.


      IF ls_ref-db_key IS NOT INITIAL.
        CALL METHOD zcl_tr_3024_gui=>unlock_2
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
        ENDIF.
      ELSE.

        CALL METHOD zcl_tr_3024_gui=>unlock_1
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
        ENDIF.

      ENDIF.

    ENDLOOP.

  ENDMETHOD.


METHOD unmapping_by_atuo.
    IF is_ref-split_flag = 'Y'.
      IF iv_lock = abap_true .
        CALL METHOD zcl_tr_3024_gui=>lock_3
          EXPORTING
            iv_trans = is_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDIF.
      UPDATE ztrt3023_02_cf SET zppzt = ''
      iaedat  = sy-datum
      iaezet = sy-uzeit
      iaenam = sy-uname
      itcode = sy-tcode
      zppqj = '000000'   WHERE db_key = is_ref-db_key .
      IF sy-subrc <> 0 .
        ROLLBACK WORK  .
        MESSAGE e109(ztr01)  RAISING err.
      ENDIF.

      SELECT * FROM ztrt3023_03 INTO TABLE @DATA(lt_3023)
            WHERE db_key = @is_bsis-db_key .
      DELETE FROM  ztrt3023_03 WHERE   db_key = is_bsis-db_key .

    ELSEIF is_ref-db_key IS NOT INITIAL.
      IF iv_lock = abap_true .
        CALL METHOD zcl_tr_3024_gui=>lock_2
          EXPORTING
            iv_trans = is_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDIF.

      UPDATE ztrt3023_02 SET zppzt = ''
                            iaedat  = sy-datum
                             iaezet = sy-uzeit
                             iaenam = sy-uname
                             itcode = sy-tcode
                              zppqj = '000000'   WHERE db_key = is_ref-db_key .
      IF sy-subrc <> 0 .
        ROLLBACK WORK  .
        MESSAGE e109(ztr01)  RAISING err.
      ENDIF.
*20190927 费用过账优化
      SELECT * FROM ztrt3023_03 INTO TABLE @lt_3023
                       WHERE db_key = @is_bsis-db_key .
*20190927 费用过账优化
      DELETE FROM  ztrt3023_03 WHERE   db_key = is_bsis-db_key .

    ELSE.
      IF iv_lock = abap_true .
        CALL METHOD zcl_tr_3024_gui=>lock_1
          EXPORTING
            iv_trans = is_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDIF.

      UPDATE ztrt_bank_trans SET zppzt = ''
                                 zppqj = '000000'    WHERE bukrs = is_ref-bukrs
                                                       AND hbkid = is_ref-hbkid
                                                       AND hktid = is_ref-hktid
                                                       AND yhzh  = is_ref-yhzh
                                                       AND trxno = is_ref-trxno.
      IF sy-subrc <> 0 .
        ROLLBACK WORK  .
        MESSAGE e109(ztr01)  RAISING err.
      ENDIF.
*20190927 费用过账优化
      SELECT * FROM ztrt3023_03 INTO TABLE  lt_3023
                          WHERE    bukrs = is_bsis-bukrs
                              AND  hbkid = is_bsis-hbkid
                              AND  hktid = is_bsis-hktid
                              AND  yhzh  = is_ref-yhzh
                              AND  trxno = is_bsis-trxno.
*20190927 费用过账优化

      DELETE FROM  ztrt3023_03 WHERE  bukrs = is_bsis-bukrs
                           AND  hbkid = is_bsis-hbkid
                           AND  hktid = is_bsis-hktid
                           AND  yhzh  = is_ref-yhzh
                           AND  trxno = is_bsis-trxno .

    ENDIF.



    IF sy-subrc <> 0 .
      ROLLBACK WORK  .
      MESSAGE e109(ztr01)  RAISING err.
    ENDIF.
*20190927 费用过账优化
*    DATA I_MODE TYPE PS_UPDMODE.
    DATA lt_bsis TYPE ztrt3023_03_t.
    lt_bsis = lt_3023.
    mapping_unmapping_log(
      EXPORTING
        i_mode = 'D'
        it_log = lt_bsis
      EXCEPTIONS
        error  = 1
        OTHERS = 2
           ).
    IF sy-subrc <> 0.
*     Implement suitable error handling here
    ENDIF.
*20190927 费用过账优化

    IF iv_commit = abap_true .
      COMMIT WORK AND WAIT .
    ENDIF.

    IF iv_lock = abap_true .
      IF is_ref-split_flag      = 'Y'.
        CALL METHOD zcl_tr_3024_gui=>unlock_3
          EXPORTING
            iv_trans = is_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
        ENDIF.
      ELSEIF is_ref-db_key IS NOT INITIAL.
        CALL METHOD zcl_tr_3024_gui=>unlock_2
          EXPORTING
            iv_trans = is_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
        ENDIF.
      ELSE.

        CALL METHOD zcl_tr_3024_gui=>unlock_1
          EXPORTING
            iv_trans = is_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
        ENDIF.

      ENDIF.

    ENDIF.
  ENDMETHOD.


METHOD unmapping_by_manual.

    DATA : lt_ref_2 TYPE ztrt_3028_agnref,
           lt_ref_1 TYPE ztrt_3028_agnref,
           lt_ref_3 TYPE ztrt_3028_agnref,
           lt_bsis  TYPE ztrtt3023_03.

    LOOP AT it_ref INTO DATA(ls_ref) .
      IF ls_ref-split_flag = 'Y'.
        APPEND ls_ref TO lt_ref_3 .
        IF iv_lock = abap_true .
          CALL METHOD zcl_tr_3024_gui=>lock_3
            EXPORTING
              iv_trans = ls_ref
            EXCEPTIONS
              err      = 1
              OTHERS   = 2.
          IF sy-subrc <> 0.
            MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
          ENDIF.
        ENDIF.
        CONTINUE.
      ENDIF.


      IF ls_ref-db_key IS NOT INITIAL.
        APPEND ls_ref TO lt_ref_2 .
        IF iv_lock = abap_true .
          CALL METHOD zcl_tr_3024_gui=>lock_2
            EXPORTING
              iv_trans = ls_ref
            EXCEPTIONS
              err      = 1
              OTHERS   = 2.
          IF sy-subrc <> 0.
            MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
              WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
          ENDIF.
        ENDIF.
      ELSE.
        APPEND ls_ref TO lt_ref_1.
        IF iv_lock = abap_true .
          CALL METHOD zcl_tr_3024_gui=>lock_1
            EXPORTING
              iv_trans = ls_ref
            EXCEPTIONS
              err      = 1
              OTHERS   = 2.
          IF sy-subrc <> 0.
            MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
              WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
          ENDIF.
        ENDIF.
      ENDIF.
    ENDLOOP.

    IF NOT lt_ref_1 IS INITIAL .
      LOOP AT lt_ref_1 INTO DATA(ls_ref_1) .
        UPDATE ztrt_bank_trans SET zppzt = ''
                             zppqj = '000000'
                             zref_doc = ''
                             WHERE bukrs = ls_ref_1-bukrs
                                              AND hbkid = ls_ref_1-hbkid
                                              AND hktid = ls_ref_1-hktid
                                              AND yhzh  = ls_ref_1-yhzh
                                              AND trxno = ls_ref_1-trxno.

        IF sy-subrc <> 0 .
          ROLLBACK WORK  .
          MESSAGE e109(ztr01)  RAISING err.
        ENDIF.
      ENDLOOP.
    ENDIF.


    IF NOT lt_ref_2 IS INITIAL .
      LOOP AT lt_ref_2 INTO DATA(ls_ref_2) .
        UPDATE ztrt3023_02 SET  zppzt = ''
                             zppqj = '000000'
                             zref_doc = ''
                             iaedat  = sy-datum
                              iaezet  = sy-uzeit
                              iaenam = sy-uname
                              itcode = sy-tcode
                           WHERE db_key = ls_ref_2-db_key .
        IF sy-subrc <> 0 .
          ROLLBACK WORK  .
          MESSAGE e109(ztr01)  RAISING err.
        ENDIF.
      ENDLOOP.
    ENDIF.

    IF NOT lt_ref_3 IS INITIAL .
      LOOP AT lt_ref_3 INTO DATA(ls_ref_3) .
        UPDATE ztrt3023_02_cf SET  zppzt = ''
        zppqj = '000000'
        zref_doc = ''
        iaedat  = sy-datum
        iaezet  = sy-uzeit
        iaenam = sy-uname
        itcode = sy-tcode
        WHERE db_key = ls_ref_2-db_key .
        IF sy-subrc <> 0 .
          ROLLBACK WORK  .
          MESSAGE e109(ztr01)  RAISING err.
        ENDIF.
      ENDLOOP.
    ENDIF.



    lt_bsis = it_bsis .
    DELETE ztrt3023_03 FROM TABLE lt_bsis .
    IF sy-subrc <> 0 .
      ROLLBACK WORK  .
      MESSAGE e109(ztr01)  RAISING err.
    ENDIF.
*20190927 费用过账优化

    mapping_unmapping_log(
      EXPORTING
        i_mode = 'D'
        it_log = lt_bsis
      EXCEPTIONS
        error  = 1
        OTHERS = 2
           ).
    IF sy-subrc <> 0.
*     Implement suitable error handling here
    ENDIF.

*20190927 费用过账优化
    IF iv_commit = abap_true .
      COMMIT WORK AND WAIT .
    ENDIF.

    IF iv_lock = abap_true .
      LOOP AT it_ref INTO ls_ref .
        IF  ls_ref-split_flag = 'Y'.
          CALL METHOD zcl_tr_3024_gui=>unlock_3
            EXPORTING
              iv_trans = ls_ref
            EXCEPTIONS
              err      = 1
              OTHERS   = 2.
          IF sy-subrc <> 0.
          ENDIF.
          CONTINUE.

        ENDIF.


        IF ls_ref-db_key IS NOT INITIAL.
          CALL METHOD zcl_tr_3024_gui=>unlock_2
            EXPORTING
              iv_trans = ls_ref
            EXCEPTIONS
              err      = 1
              OTHERS   = 2.
          IF sy-subrc <> 0.
          ENDIF.
        ELSE.

          CALL METHOD zcl_tr_3024_gui=>unlock_1
            EXPORTING
              iv_trans = ls_ref
            EXCEPTIONS
              err      = 1
              OTHERS   = 2.
          IF sy-subrc <> 0.
          ENDIF.

        ENDIF.

      ENDLOOP.
    ENDIF.
  ENDMETHOD.


METHOD unmapping_by_ref.

    DATA : lt_bank1 TYPE TABLE OF ztrt_bank_trans,
           lt_bank2 TYPE TABLE OF ztrt3023_02,
           lt_bank3 TYPE TABLE OF ztrt3023_02_cf,
           lt_doc   TYPE TABLE OF ztrt3023_03,
           lv_bukrs TYPE bukrs,
*           ls_doc   TYPE ztrt3023_03,
           lt_ref_3 TYPE ztrt_3028_agnref,
           lt_ref_2 TYPE ztrt_3028_agnref,
           lt_ref_1 TYPE ztrt_3028_agnref.

    IF iv_group IS INITIAL OR iv_doc IS INITIAL .
      MESSAGE e173(ztr02) RAISING err .
    ENDIF.
*   没有匹配就不做了

    SELECT * FROM ztrt_bank_trans INTO CORRESPONDING FIELDS OF TABLE lt_bank1
      WHERE zref_doc   = iv_doc
        AND zgroup_ac  = iv_group
        AND zppzt <> space .

    IF sy-subrc <> 0 .

      SELECT * FROM ztrt3023_02 INTO CORRESPONDING FIELDS OF TABLE lt_bank2
        WHERE zref_doc   = iv_doc
          AND zgroup_ac  = iv_group
          AND dflag  = space
          AND zppzt <> space .

      IF sy-subrc <> 0 .
        SELECT * FROM ztrt3023_02_cf INTO CORRESPONDING FIELDS OF TABLE lt_bank3
        WHERE zref_doc   = iv_doc
        AND zgroup_ac  = iv_group
        AND zppzt <> space .

        IF sy-subrc <> 0 .

          SELECT * FROM ztrt3023_03 INTO CORRESPONDING FIELDS OF TABLE lt_doc
           WHERE  zref_doc   = iv_doc
             AND  zgroup_ac  = iv_group
             AND zppzt <> space.
          IF sy-subrc <> 0 .
            RETURN .   " 压根没匹配过
          ENDIF.
        ENDIF.
      ENDIF.
    ENDIF.



* LOCK

    SELECT * FROM ztrt_bank_trans INTO CORRESPONDING FIELDS OF TABLE lt_ref_1
      WHERE zref_doc   = iv_doc
        AND zgroup_ac  = iv_group .
    IF sy-subrc = 0 .
      IF iv_lock IS NOT INITIAL .
        LOOP AT lt_ref_1 INTO DATA(ls_ref) .
          CALL METHOD zcl_tr_3024_gui=>lock_1
            EXPORTING
              iv_trans = ls_ref
            EXCEPTIONS
              err      = 1
              OTHERS   = 2.
          IF sy-subrc <> 0.
            MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
              WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
          ENDIF.

          CALL FUNCTION 'ENQUEUE_EZZTRV_3023_LOCK'
            EXPORTING
              mode_ztrv_3023_lock = 'E'
              mandt               = sy-mandt
              bukrs               = ls_ref-bukrs
              hbkid               = ls_ref-hbkid
              hktid               = ls_ref-hktid
            EXCEPTIONS
              foreign_lock        = 1
              system_failure      = 2
              OTHERS              = 3.
          IF sy-subrc <> 0.
            MESSAGE e609(ztr01)   WITH sy-msgv1  RAISING err.
          ENDIF.
        ENDLOOP.
      ENDIF.
      LOOP AT lt_ref_1 INTO ls_ref .
        SELECT SINGLE hkont INTO @DATA(lv_hkont) FROM ztrt0013 WHERE bukrs = @ls_ref-bukrs
                                                           AND hbkid = @ls_ref-hbkid
                                                           AND hktid = @ls_ref-hktid .
        IF sy-subrc = 0 .

          SELECT SINGLE zppqj FROM  ztrt_bank_trans INTO @DATA(lv_zppqj)
                                                     WHERE bukrs  = @ls_ref-bukrs
                                                       AND hbkid  = @ls_ref-hbkid
                                                       AND hktid  = @ls_ref-hktid
                                                       AND yhzh   = @ls_ref-yhzh
                                                       AND trxno  = @ls_ref-trxno .
          IF sy-subrc = 0.
            CALL METHOD zcl_tr_3024_gui=>check_3023_04
              EXPORTING
                iv_bukrs = ls_ref-bukrs
                iv_qj    = lv_zppqj
                iv_hkont = lv_hkont
              IMPORTING
                ev_save  = DATA(lv_save).

            IF lv_save = abap_true .
              MESSAGE e694(ztr01)   RAISING err.
            ENDIF.
          ENDIF.
        ENDIF.
      ENDLOOP.
    ENDIF.

**

    SELECT z2~db_key
           z1~bukrs
           z1~hbkid
           z1~hktid
*             Z1~YHZH
*             Z1~TRXNO
           z2~zbkitem
           z2~zref_doc
       FROM ztrt3023_02 AS z2 INNER JOIN ztrt3023_01 AS z1 ON z2~parent_key = z1~db_key
       INTO CORRESPONDING FIELDS OF TABLE lt_ref_2
     WHERE z2~zref_doc   = iv_doc
       AND z2~zgroup_ac  = iv_group
       AND z2~dflag      = space
      AND  z1~dflag      = space  .
    IF sy-subrc = 0 .
      IF iv_lock IS NOT INITIAL .
        LOOP AT lt_ref_2 INTO ls_ref .
          CALL METHOD zcl_tr_3024_gui=>lock_2
            EXPORTING
              iv_trans = ls_ref
            EXCEPTIONS
              err      = 1
              OTHERS   = 2.
          IF sy-subrc <> 0.
            MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
              WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
          ENDIF.

          CALL FUNCTION 'ENQUEUE_EZZTRV_3023_LOCK'
            EXPORTING
              mode_ztrv_3023_lock = 'E'
              mandt               = sy-mandt
              bukrs               = ls_ref-bukrs
              hbkid               = ls_ref-hbkid
              hktid               = ls_ref-hktid
            EXCEPTIONS
              foreign_lock        = 1
              system_failure      = 2
              OTHERS              = 3.
          IF sy-subrc <> 0.
            MESSAGE e609(ztr01)   WITH sy-msgv1  RAISING err.
          ENDIF.
        ENDLOOP.
      ENDIF.
      LOOP AT lt_ref_2 INTO ls_ref .
        SELECT SINGLE hkont INTO lv_hkont FROM ztrt0013 WHERE bukrs = ls_ref-bukrs
                                                          AND hbkid = ls_ref-hbkid
                                                          AND hktid = ls_ref-hktid .
        IF sy-subrc = 0 .

          SELECT SINGLE zppqj FROM  ztrt3023_02  INTO lv_zppqj
                                                  WHERE db_key = ls_ref-db_key.
          IF sy-subrc = 0 .
            CALL METHOD zcl_tr_3024_gui=>check_3023_04
              EXPORTING
                iv_bukrs = ls_ref-bukrs
                iv_qj    = lv_zppqj
                iv_hkont = lv_hkont
              IMPORTING
                ev_save  = lv_save.

            IF lv_save = abap_true .
              MESSAGE e694(ztr01)   RAISING err.
            ENDIF.
          ENDIF.
        ENDIF.
      ENDLOOP .
    ENDIF.
*锁定拆分流水
    SELECT  db_key
    bukrs
     hbkid
     hktid
     zbkitem
     zref_doc
    FROM ztrt3023_02_cf
    INTO CORRESPONDING FIELDS OF TABLE lt_ref_3
    WHERE  zref_doc   = iv_doc
    AND  zgroup_ac  = iv_group  .
    IF sy-subrc = 0 .
      IF iv_lock IS NOT INITIAL .
        LOOP AT lt_ref_3 INTO ls_ref .
          CALL METHOD zcl_tr_3024_gui=>lock_3
            EXPORTING
              iv_trans = ls_ref
            EXCEPTIONS
              err      = 1
              OTHERS   = 2.
          IF sy-subrc <> 0.
            MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
          ENDIF.

          CALL FUNCTION 'ENQUEUE_EZZTRV_3023_LOCK'
            EXPORTING
              mode_ztrv_3023_lock = 'E'
              mandt               = sy-mandt
              bukrs               = ls_ref-bukrs
              hbkid               = ls_ref-hbkid
              hktid               = ls_ref-hktid
            EXCEPTIONS
              foreign_lock        = 1
              system_failure      = 2
              OTHERS              = 3.
          IF sy-subrc <> 0.
            MESSAGE e609(ztr01)   WITH sy-msgv1  RAISING err.
          ENDIF.
        ENDLOOP.
      ENDIF.
      LOOP AT lt_ref_3 INTO ls_ref .
        SELECT SINGLE hkont INTO lv_hkont FROM ztrt0013 WHERE bukrs = ls_ref-bukrs
        AND hbkid = ls_ref-hbkid
        AND hktid = ls_ref-hktid .
        IF sy-subrc = 0 .

          SELECT SINGLE zppqj FROM  ztrt3023_02_cf  INTO lv_zppqj
          WHERE db_key = ls_ref-db_key.
          IF sy-subrc = 0 .
            CALL METHOD zcl_tr_3024_gui=>check_3023_04
              EXPORTING
                iv_bukrs = ls_ref-bukrs
                iv_qj    = lv_zppqj
                iv_hkont = lv_hkont
              IMPORTING
                ev_save  = lv_save.

            IF lv_save = abap_true .
              MESSAGE e694(ztr01)   RAISING err.
            ENDIF.
          ENDIF.
        ENDIF.
      ENDLOOP .
    ENDIF.







*check
    SELECT * FROM ztrt_bank_trans INTO CORRESPONDING FIELDS OF TABLE lt_bank1
      WHERE zref_doc   = iv_doc
        AND zgroup_ac  = iv_group .
    LOOP AT lt_bank1 INTO DATA(ls_bank1) WHERE zppzt = space.
      EXIT.
    ENDLOOP.
    IF sy-subrc = 0 .
      MESSAGE e467(ztr01) WITH ls_bank1-trxno RAISING err.
    ENDIF.

    SELECT * FROM ztrt3023_02 INTO CORRESPONDING FIELDS OF TABLE lt_bank2
      WHERE zref_doc   = iv_doc
        AND zgroup_ac  = iv_group
        AND dflag = space.
    LOOP AT lt_bank2 INTO DATA(ls_bank2) WHERE zppzt = space.
      EXIT.
    ENDLOOP.
    IF sy-subrc = 0 .
      MESSAGE e467(ztr01) WITH ls_bank2-zbkitem RAISING err.
    ENDIF.

    SELECT * FROM ztrt3023_02_cf INTO CORRESPONDING FIELDS OF TABLE lt_bank3
    WHERE zref_doc   = iv_doc
    AND zgroup_ac  = iv_group .
    LOOP AT lt_bank3 INTO DATA(ls_bank3) WHERE zppzt = space.
      EXIT.
    ENDLOOP.
    IF sy-subrc = 0 .
      MESSAGE e467(ztr01) WITH ls_bank2-zbkitem RAISING err.
    ENDIF.

    SELECT * FROM ztrt3023_03 INTO CORRESPONDING FIELDS OF TABLE lt_doc
     WHERE  zref_doc   = iv_doc
      AND   zgroup_ac  = iv_group .
    IF sy-subrc <> 0 .
      MESSAGE e468(ztr01) WITH  iv_doc RAISING err.
    ENDIF.


    IF lt_bank1 IS NOT INITIAL .
      UPDATE ztrt_bank_trans SET zppzt  =  space
                                 zppqj  =  '000000'
                             WHERE zref_doc   = iv_doc
                               AND zgroup_ac  = iv_group .
      IF sy-subrc <> 0 .
        ROLLBACK WORK  .
        MESSAGE e109(ztr01)  RAISING err.
      ENDIF.
    ENDIF.

    IF lt_bank2 IS NOT INITIAL .
      UPDATE ztrt3023_02    SET zppzt  =  space
                                zppqj  =  '000000'
                                iaedat  = sy-datum
iaezet  = sy-uzeit
iaenam = sy-uname
itcode = sy-tcode
                          WHERE  zref_doc   = iv_doc
                            AND  zgroup_ac  = iv_group
                            AND  dflag = space.
      IF sy-subrc <> 0 .
        ROLLBACK WORK  .
        MESSAGE e109(ztr01)  RAISING err.
      ENDIF.
    ENDIF.
    IF lt_bank3 IS NOT INITIAL .
      UPDATE ztrt3023_02_cf    SET zppzt  =  space
      zppqj  =  '000000'
      iaedat  = sy-datum
      iaezet  = sy-uzeit
      iaenam = sy-uname
      itcode = sy-tcode
      WHERE  zref_doc   = iv_doc
      AND  zgroup_ac  = iv_group .
      IF sy-subrc <> 0 .
        ROLLBACK WORK  .
        MESSAGE e109(ztr01)  RAISING err.
      ENDIF.
    ENDIF.

*20190927 费用过账优化
    SELECT * INTO TABLE @DATA(lt_3023)
      FROM ztrt3023_03 WHERE    zref_doc = @iv_doc
                        AND   zgroup_ac = @iv_group.
*20190927 费用过账优化
    DELETE FROM  ztrt3023_03 WHERE    zref_doc = iv_doc
                               AND   zgroup_ac = iv_group.


    IF sy-subrc <> 0 .
      ROLLBACK WORK  .
      MESSAGE e109(ztr01)  RAISING err.
    ENDIF.
*20190927 费用过账优化
*    DATA I_MODE TYPE PS_UPDMODE.
    DATA it_log TYPE ztrt3023_03_t.
    it_log = lt_3023.
    mapping_unmapping_log(
      EXPORTING
        i_mode = 'D'
        it_log = it_log
      EXCEPTIONS
        error  = 1
        OTHERS = 2
           ).
    IF sy-subrc <> 0.
*     Implement suitable error handling here
    ENDIF.
*20190927 费用过账优化
    IF iv_commit = abap_true .
      COMMIT WORK AND WAIT .
    ENDIF.


    IF iv_lock IS NOT INITIAL .

      LOOP AT lt_ref_1 INTO ls_ref .
        CALL METHOD zcl_tr_3024_gui=>unlock_1
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.

      LOOP AT lt_ref_2 INTO ls_ref .
        CALL METHOD zcl_tr_3024_gui=>unlock_2
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.
      LOOP AT lt_ref_3 INTO ls_ref .
        CALL METHOD zcl_tr_3024_gui=>unlock_3
          EXPORTING
            iv_trans = ls_ref
          EXCEPTIONS
            err      = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid  TYPE sy-msgty NUMBER sy-msgno
            WITH  sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 RAISING err .
        ENDIF.
      ENDLOOP.
    ENDIF.

  ENDMETHOD.
ENDCLASS.
