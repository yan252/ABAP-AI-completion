FUNCTION ZFM_TR_DELOCK_BANK.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     REFERENCE(IM_BANK_IND) TYPE  ZTR_BANK_INDICATOR
*"--------------------------------------------------------------------
READ TABLE gt_lock_bank INTO DATA(ls_bank)
       WITH KEY bank_ind = im_bank_ind.
  IF sy-subrc = 0.
    CALL FUNCTION 'DEQUEUE_EZTRS_BANK_LOCK'
      EXPORTING
        mode_ztrs_bank_lock = 'E'
        mandt               = sy-mandt
        bank_ind            = im_bank_ind
        x_bank_ind          = ' '
        _scope              = '3'
        _synchron           = ' '
        _collect            = ' '.
    DELETE gt_lock_bank
           WHERE bank_ind = im_bank_ind.
  ENDIF.





ENDFUNCTION.
