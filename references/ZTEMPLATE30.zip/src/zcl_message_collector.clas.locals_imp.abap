*"* use this source file for the definition and implementation of
*"* local helper classes, interface definitions and type
*"* declarations
CLASS lcl_receiver IMPLEMENTATION.
  METHOD constructor.
  ENDMETHOD.                    "constructor

  METHOD on_close.
    container->free( ).
    CLEAR container.
    CLEAR grid.
  ENDMETHOD.                    "on_close

ENDCLASS.                    "lcl_receiver IMPLEMENTATION
