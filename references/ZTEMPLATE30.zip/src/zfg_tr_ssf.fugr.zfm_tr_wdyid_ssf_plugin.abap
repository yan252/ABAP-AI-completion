FUNCTION ZFM_TR_WDYID_SSF_PLUGIN.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     REFERENCE(IM_APPLICATION) TYPE  RSSTCD-PARA_VALUE
*"     REFERENCE(IM_START_MODE) TYPE  RSSTCD-PARA_VALUE
*"--------------------------------------------------------------------
IF ( im_application = 'ZWDA_TR_3012_QUERY' OR
     im_application = 'ZWDC_TR_2019' OR
     im_application = 'ZWDC_TR_2110' OR
     im_application = 'ZWDC_TR_2112' ) AND
     im_start_mode = 'BROWSER'.
    zcl_captical_encryptor=>if_ukey_is_valid(
                        EXCEPTIONS
                          not_valid = 1 ).
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid
                 TYPE 'S'
                 NUMBER sy-msgno
                 WITH sy-msgv1
                      sy-msgv2
                      sy-msgv3
                      sy-msgv4
                DISPLAY LIKE 'E'.
      LEAVE TO SCREEN 0.
    ENDIF.
  ENDIF.





ENDFUNCTION.
