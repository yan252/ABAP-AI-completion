@AbapCatalog.sqlViewName: 'ZTRCDS3020Z'
@AbapCatalog.compiler.compareFilter: true
@AbapCatalog.preserveKey: true
@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: '应付未清账龄表附加—虚拟账户的银行代扣凭证'
define view ZDDL_RT3020Z 
as select from bsik as a inner join
               bseg as b on b.mandt = a.mandt
                    and b.bukrs = a.bukrs
                    and b.belnr = a.belnr
                    and b.gjahr = a.gjahr
                    and b.buzei = a.buzei
                          inner join 
               lfa1 as c on a.lifnr = c.lifnr
                         and c.mandt = a.mandt
                         inner join 
               lfb1 as d on a.lifnr = d.lifnr
                         and a.bukrs = d.bukrs
                         and a.mandt = d.mandt
                         inner join 
               lfbk as K on  K.lifnr = a.lifnr
                         and K.bvtyp = a.bvtyp
                         and K.mandt = a.mandt
                         and K.bankl = 'ZZZZZZ'
                   
{
a.mandt,
a.bukrs,
a.belnr,
a.gjahr,
a.buzei,
a.lifnr,
a.zlsch,
a.waers,
a.zterm,
a.sgtxt,
a.bvtyp,
a.shkzg,
case   when a.shkzg = 'H' then a.wrbtr 
       when a.shkzg = 'S' then a.wrbtr * ( -1 )
        else 0 end 
 as wrbtr ,
( case
  when ( b.koart = 'D' and b.shkzg = 'H' ) or ( b.koart = 'K' and b.shkzg = 'S' ) and b.rebzg = '' and a.zfbdt <> '00000000' then a.zfbdt 
  when ( b.koart = 'D' and b.shkzg = 'H' ) or ( b.koart = 'K' and b.shkzg = 'S' ) and b.rebzg = '' and a.zfbdt = '00000000' then a.bldat
  when a.zfbdt <> '00000000' and a.zbd3t <> 0                  then dats_add_days(a.zfbdt,CEIL(a.zbd3t),'NULL') 
  when a.zfbdt <> '00000000' and a.zbd3t = 0 and a.zbd2t <> 0  then dats_add_days(a.zfbdt,CEIL(a.zbd2t),'NULL') 
  when a.zfbdt <> '00000000' and a.zbd3t = 0 and a.zbd2t = 0   then dats_add_days(a.zfbdt,CEIL(a.zbd1t),'NULL') 
  when a.zfbdt  = '00000000' and a.zbd3t <> 0                  then dats_add_days(a.bldat,CEIL(a.zbd3t),'NULL') 
  when a.zfbdt  = '00000000' and a.zbd3t = 0 and a.zbd2t <> 0  then dats_add_days(a.bldat,CEIL(a.zbd2t),'NULL') 
  when a.zfbdt  = '00000000' and a.zbd3t = 0 and a.zbd2t = 0   then dats_add_days(a.bldat,CEIL(a.zbd1t),'NULL') 
  else a.zfbdt
  end )
  as zfbdt,
a.hkont,
b.rstgr,
a.ebeln,
a.ebelp,
a.projk,
a.prctr,
a.kostl,
a.kidno,
a.xref1,
a.xref2,
a.xref3,
a.rebzj ,
a.rebzg ,
a.rebzz  
}
where a.zlspr = '' 
  and ( ( a.blart <> 'Z8' and a.blart <> 'Z7' )  or  ( ( a.blart = 'Z8' or a.blart = 'Z7' ) and ( a.xref3 = '' or a.umskz <> '' or a.xref3 like '%/%' ) ) )
  and c.sperr = ''
  and c.loevm = ''
  and c.nodel = '' 
  and d.sperr = ''
  and d.loevm = ''
  and d.nodel = '' 
  and ( a.hkont <> '0022010100'   and  a.hkont <> '0022010200'  and a.hkont <> '0022010300' )
  and a.zlsch = 'Z' // 银行代扣代缴
  
 
  
 