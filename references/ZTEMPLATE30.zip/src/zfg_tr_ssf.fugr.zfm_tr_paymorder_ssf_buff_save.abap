FUNCTION ZFM_TR_PAYMORDER_SSF_BUFF_SAVE.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     VALUE(IM_S_PAYM_SSF) TYPE  ZTRT_PAYM_SSF
*"  TABLES
*"      IM_T_2001 STRUCTURE  ZTRT2001_SSF OPTIONAL
*"      IM_T_2002 STRUCTURE  ZTRT2002_SSF OPTIONAL
*"      IM_T_2003 STRUCTURE  ZTRT2003_SSF OPTIONAL
*"      IM_T_2101 STRUCTURE  ZTRT2101_SSF OPTIONAL
*"--------------------------------------------------------------------
MODIFY ztrt_paym_ssf FROM im_s_paym_ssf.

  IF im_t_2001 IS SUPPLIED.
    DELETE FROM ztrt2001_ssf WHERE uname = im_s_paym_ssf-uname
                             AND   datum = im_s_paym_ssf-datum.
    MODIFY ztrt2001_ssf FROM TABLE im_t_2001.
  ENDIF.

  IF im_t_2002 IS SUPPLIED.
    DELETE FROM ztrt2002_ssf WHERE uname = im_s_paym_ssf-uname
                             AND   datum = im_s_paym_ssf-datum.
    MODIFY ztrt2002_ssf FROM TABLE im_t_2002.
  ENDIF.

  IF im_t_2003 IS SUPPLIED.
    DELETE FROM ztrt2003_ssf WHERE uname = im_s_paym_ssf-uname
                             AND   datum = im_s_paym_ssf-datum.
    MODIFY ztrt2003_ssf FROM TABLE im_t_2003.
  ENDIF.

  IF im_t_2101 IS SUPPLIED.
    DELETE FROM ztrt2101_ssf WHERE uname = im_s_paym_ssf-uname
                             AND   datum = im_s_paym_ssf-datum.
    MODIFY ztrt2101_ssf FROM TABLE im_t_2101.
  ENDIF.

  COMMIT WORK AND WAIT .





ENDFUNCTION.
