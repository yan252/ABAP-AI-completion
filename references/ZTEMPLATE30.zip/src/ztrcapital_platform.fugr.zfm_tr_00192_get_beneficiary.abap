FUNCTION ZFM_TR_00192_GET_BENEFICIARY.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     REFERENCE(IM_O_SELECTOR) TYPE
*"EF TO ZCL_0192_RAW_ITEM_SELECTER
*"--------------------------------------------------------------------
selector = im_o_selector.
  CLEAR ztrs_00192_beneficiary.
  CALL SCREEN '0101' STARTING AT 25 6
                     ENDING   AT 100   11.





ENDFUNCTION.
