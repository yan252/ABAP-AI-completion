FUNCTION ZFM_TR2_BANK_TSSP_CCB.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     VALUE(LS_IN) TYPE  ZLTTR2_BANK_TSSP_IN
*"     VALUE(BUKRS) TYPE  BUKRS
*"     VALUE(YHZH) TYPE  ZTR_YHZH
*"  EXPORTING
*"     REFERENCE(LS_OUT) TYPE  ZLTTR2_BANK_TSSP_OUT
*"--------------------------------------------------------------------
DATA(LO_XML) = NEW ZCL_TR2_XML( ).

 DATA:RESPONSE TYPE STRING.
    CALL FUNCTION 'ZFM_TR2_BANK_SEND'
      EXPORTING
        BANK_IND    = 'CCB'
        BANK_ACTION = 'AKR'
        DATA_IN     = LS_IN
        METHOD      = 'POST'
        BUKRS       = BUKRS
        YHZH        = YHZH
      IMPORTING
        RESPONSE    = RESPONSE.

    LO_XML->CONVERT_XML_TO_ABAP( EXPORTING RESPONSE = RESPONSE BANK_IND = 'CCB'
                                           BANK_ACTION = 'AKR' IMPORTING DATA = LS_OUT ).





ENDFUNCTION.
