FUNCTION ZFM_TR_DELOCK_PAYMENTORDER.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     REFERENCE(IM_DOCNO) TYPE  ZTRT_PAYMENT-PAYMORDER
*"--------------------------------------------------------------------
READ TABLE gt_lock_payment_order INTO DATA(ls_payment_order)
       WITH KEY docno = im_docno.
  IF sy-subrc = 0.
    CALL FUNCTION 'DEQUEUE_EZPAYMORD_LOCK'
      EXPORTING
        mode_zpaymord_lock = 'E'
        mandt              = sy-mandt
        paymorder          = im_docno
        x_paymorder        = ' '
        _scope             = '3'
        _synchron          = ' '
        _collect           = ' '.

    DELETE gt_lock_payment_order
           WHERE docno = im_docno.
  ENDIF.





ENDFUNCTION.
