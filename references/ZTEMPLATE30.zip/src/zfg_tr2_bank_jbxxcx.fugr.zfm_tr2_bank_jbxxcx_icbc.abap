FUNCTION ZFM_TR2_BANK_JBXXCX_ICBC.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     REFERENCE(LT_IN) TYPE  ZLTTR2_BANK_JBXXCX_IN
*"  EXPORTING
*"     REFERENCE(LT_OUT) TYPE  ZLTTR2_BANK_JBXXCX_OUT
*"--------------------------------------------------------------------
DATA:BEGIN OF LS_DATA,
         TRANSCODE  TYPE STRING, "交易代码
         TRANDATE   TYPE STRING, "ERP系统产生的交易日期，格式是YYYYMMDD
         TRANTIME   TYPE STRING, "ERP系统产生的交易时间，格式如HHMMSSSSS，精确到毫秒
         LANGUAGE   TYPE STRING, " 语言：ZH_CN简体中文，EN_US英文，默认ZH_CN
         ACCESSTYPE TYPE STRING, "1-终端接入2-平台接入送空或者不送默认为终端接入
         LOGINID    TYPE STRING, "证书ID，当ACCESS_TYPE=2时必输
         FSEQNO     TYPE STRING, "指令包序列
         ACCOUNTNO  TYPE STRING, " 本方账号：背书转让签收时为被背书人账号
         BILLNO     TYPE STRING, "电子票据号码
       END OF LS_DATA.

  TYPES: BEGIN OF TY_RD,
*           tran_type         TYPE string,
*           trans_num         TYPE string,
*           account_name      TYPE string,
*           account_no        TYPE string,
*           bank_code         TYPE string,
*           next_account_name TYPE string,
*           next_account_no   TYPE string,
*           next_bank_code    TYPE string,
*           sign_date         TYPE string,
*           recite_flag       TYPE string,
           TRANTYPE        TYPE STRING,
           TRANSNUM        TYPE STRING,
           ACCOUNTNAME     TYPE STRING,
           ACCOUNTNO       TYPE STRING,
           BANKCODE        TYPE STRING,
           NEXTACCOUNTNAME TYPE STRING,
           NEXTACCOUNTNO   TYPE STRING,
           NEXTBANKCODE    TYPE STRING,
           SIGNDATE        TYPE STRING,
           RECITEFLAG      TYPE STRING,
           GUARNTRADRESS   TYPE STRING,
         END OF TY_RD.

  DATA:BEGIN OF LS_RESPONSE,
         RETURNCODE               TYPE STRING,
         RETURNMSG                TYPE STRING,
         MSGID                    TYPE STRING,
         BILL_NO                  TYPE STRING,
         BILL_TYPE                TYPE STRING,
         BILL_AMOUNT              TYPE STRING,
         BILL_OPEN_DATE           TYPE STRING,
         BILL_DUE_DATE            TYPE STRING,
         BILL_STATUS              TYPE STRING,
         BILL_HOLD_NAME           TYPE STRING,
         BILL_HOLD_ACCOUNT        TYPE STRING,
         BILL_HOLD_BANK_CODE      TYPE STRING,
         RECITE_FLAG              TYPE STRING,
         BILL_OPEN_TYPE           TYPE STRING,
         BILL_OPEN_NAME           TYPE STRING,
         BILL_OPEN_ACCOUNT        TYPE STRING,
         BILL_OPEN_BANK_CODE      TYPE STRING,
         PAYEE_TYPE               TYPE STRING,
         PAYEE_ACCOUNT_NAME       TYPE STRING,
         PAYEE_ACCOUNT_NO         TYPE STRING,
         PAYEE_BANK_CODE          TYPE STRING,
         ACCEPT_TYPE              TYPE STRING,
         ACCEPTER_TYPE            TYPE STRING,
         ACCEPTER_ACCOUNT_NO      TYPE STRING,
         ACCEPTER_BANK_CODE       TYPE STRING,
         ACCEPTER_ADDRESS         TYPE STRING,
         ACCEPT_DATE              TYPE STRING,
         REMOTE_HOLDER_BANK_CODE  TYPE STRING,
         REMOTE_HOLDER_ACCOUNT_NO TYPE STRING,
         REMOTE_HOLDER_NAME       TYPE STRING,
         CONTRACT_NO              TYPE STRING,
         REF_NO                   TYPE STRING,


         BILL_OPEN_GUARANTOR_NAME TYPE STRING,
         BILL_OPEN_GUARANTOR_ADD  TYPE STRING,
         BILL_OPEN_GUARANT_DATE   TYPE STRING,
         ACCEPTER_NAME            TYPE STRING,
         BILL_OPEN_PROMISE        TYPE STRING,
         ACCEPTER_PROMISE         TYPE STRING,
         ACCEPT_GUARANTOR_NAME    TYPE STRING,
         ACCEPT_GUARANTOR_ADD     TYPE STRING,
         ACCEPT_GUARANT_DATE      TYPE STRING,
         BILL_OPEN_RATE_AGENCY    TYPE STRING,
         BILL_OPEN_LEVEL          TYPE STRING,
         BILL_OPEN_RATE_DUE       TYPE STRING,
         ACCEPTER_RATE_AGENCY     TYPE STRING,
         ACCEPTER_LEVEL           TYPE STRING,
         ACCEPTER_RATE_DUE        TYPE STRING,
         RD                       TYPE TY_RD OCCURS 0,
       END OF LS_RESPONSE.

  DATA:RESPONSE TYPE STRING,
       LV_YHZH  TYPE ZTR_YHZH.

  CONSTANTS: GC_BANK_IND TYPE ZTR_BANK_IND VALUE 'ICBC'.
  DATA(LO_XML) = NEW ZCL_TR2_XML( ).

  SELECT SINGLE *
    FROM ZTR2T0020
    INTO @DATA(LS_0020)
    WHERE BANK_IND = @GC_BANK_IND.
    REFRESH LT_OUT.
  "每次处理一条
  LOOP AT LT_IN INTO DATA(LS_IN) WHERE BANK_IND_FK = GC_BANK_IND.
    LS_DATA-TRANSCODE =  'QBILLBASIC'.
    LS_DATA-TRANDATE = SY-DATUM.
    LS_DATA-TRANTIME = SY-UZEIT && '001'.
    IF SY-LANGU = '1'.
      LS_DATA-LANGUAGE = 'zh_CN'.
    ELSE.
      LS_DATA-LANGUAGE = 'zh_US'.
    ENDIF.
    LS_DATA-ACCESSTYPE = '1'.    "1-终端接入2-平台接入送空或者不送默认为终端接入
    LS_DATA-FSEQNO = CL_SYSTEM_UUID=>IF_SYSTEM_UUID_STATIC~CREATE_UUID_C22( )..
    LS_DATA-LOGINID = LS_0020-CUSOPR.
    LS_DATA-BILLNO = LS_IN-DRAFT. "电子票据号码
    LS_DATA-ACCOUNTNO = LS_IN-BANKN_FK.   "持票人账号

**取号码段
*    CALL FUNCTION 'NUMBER_RANGE_ENQUEUE'
*      EXPORTING
*        object           = 'ZTR2_SEQNO'
*      EXCEPTIONS
*        foreign_lock     = 1
*        object_not_found = 2
*        system_failure   = 3
*        OTHERS           = 4.
**  **如果号码范围存在
*    IF sy-subrc EQ 0 .
*      CALL FUNCTION 'NUMBER_GET_NEXT'
*        EXPORTING
*          nr_range_nr             = '01'
*          object                  = 'ZTR2_SEQNO'
*        IMPORTING
*          number                  = ls_data-fseqno
*        EXCEPTIONS
*          interval_not_found      = 1
*          number_range_not_intern = 2
*          object_not_found        = 3
*          quantity_is_0           = 4
*          quantity_is_not_1       = 5
*          interval_overflow       = 6
*          buffer_overflow         = 7
*          OTHERS                  = 8.
*
*      CALL FUNCTION 'NUMBER_RANGE_DEQUEUE'
*        EXPORTING
*          object           = 'ZSDDNR'
*        EXCEPTIONS
*          object_not_found = 1
*          OTHERS           = 2.
*    ENDIF .

    LV_YHZH = LS_IN-BANKN_FK.
    CALL FUNCTION 'ZFM_TR2_BANK_SEND'
      EXPORTING
        BANK_IND    = GC_BANK_IND
        BANK_ACTION = 'A04' "基本信息查询接口
        DATA_IN     = LS_DATA
        METHOD      = 'POST'
        BUKRS       = LS_IN-BUKRS
        YHZH        = LV_YHZH
      IMPORTING
        RESPONSE    = RESPONSE.

    "银行返回json解析
    /UI2/CL_JSON=>DESERIALIZE( EXPORTING JSON = RESPONSE CHANGING DATA = LS_RESPONSE ).

    APPEND INITIAL LINE TO LT_OUT ASSIGNING FIELD-SYMBOL(<FS_OUT>).
    <FS_OUT>-DRAFT = LS_IN-DRAFT.

    IF LS_RESPONSE IS NOT INITIAL.
      <FS_OUT>-RSPCOD      = LS_RESPONSE-RETURNCODE.
      <FS_OUT>-RSPMSG      = LS_RESPONSE-RETURNMSG.
      <FS_OUT>-MSGID       = LS_RESPONSE-MSGID.
      IF LS_RESPONSE-BILL_NO IS NOT INITIAL.
      <FS_OUT>-DRAFT       = LS_RESPONSE-BILL_NO.
      ENDIF.
      <FS_OUT>-BILLTYPE    = LS_RESPONSE-BILL_TYPE.
      <FS_OUT>-BILLAMO     = LS_RESPONSE-BILL_AMOUNT.
      <FS_OUT>-OPENDATE    = LS_RESPONSE-BILL_OPEN_DATE.
      <FS_OUT>-DUEDATE     = LS_RESPONSE-BILL_DUE_DATE.
      <FS_OUT>-STATUS      = LS_RESPONSE-BILL_STATUS.
      <FS_OUT>-HNAME       = LS_RESPONSE-BILL_HOLD_NAME.
      <FS_OUT>-HACCOUNT    = LS_RESPONSE-BILL_HOLD_ACCOUNT.
      <FS_OUT>-HBANKCODE   = LS_RESPONSE-BILL_HOLD_BANK_CODE.
      <FS_OUT>-RECITE      = LS_RESPONSE-RECITE_FLAG.
      <FS_OUT>-OPENTYPE    = LS_RESPONSE-BILL_OPEN_TYPE.
      <FS_OUT>-OPENNAME    = LS_RESPONSE-BILL_OPEN_NAME.
      <FS_OUT>-OPENACCOUNT = LS_RESPONSE-BILL_OPEN_ACCOUNT.
      <FS_OUT>-OPENCODE    = LS_RESPONSE-BILL_OPEN_BANK_CODE.
      <FS_OUT>-PAYEETYPE   = LS_RESPONSE-PAYEE_TYPE .
      <FS_OUT>-PAYEENAME   = LS_RESPONSE-PAYEE_ACCOUNT_NAME.
      <FS_OUT>-PAYEENO     = LS_RESPONSE-PAYEE_ACCOUNT_NO.
      <FS_OUT>-PAYEECODE   = LS_RESPONSE-PAYEE_BANK_CODE.
      <FS_OUT>-ACCTYPE     = LS_RESPONSE-ACCEPT_TYPE.
      <FS_OUT>-ACCERTYPE   = LS_RESPONSE-ACCEPTER_TYPE.
      <FS_OUT>-ACCERNO     = LS_RESPONSE-ACCEPTER_ACCOUNT_NO.
      <FS_OUT>-ACCERCODE   = LS_RESPONSE-ACCEPTER_BANK_CODE.
      <FS_OUT>-ACCERDRESS  = LS_RESPONSE-ACCEPTER_ADDRESS.
      <FS_OUT>-ACCTDATE    = LS_RESPONSE-ACCEPT_DATE.
      <FS_OUT>-REBANKCODE  = LS_RESPONSE-REMOTE_HOLDER_BANK_CODE.
      <FS_OUT>-REACCOUNTNO = LS_RESPONSE-REMOTE_HOLDER_ACCOUNT_NO.
      <FS_OUT>-RENAME      = LS_RESPONSE-REMOTE_HOLDER_NAME.
      <FS_OUT>-CONTRACTNO  = LS_RESPONSE-CONTRACT_NO.
      <FS_OUT>-REFNO       = LS_RESPONSE-REF_NO.

      <FS_OUT>-BILL_OPEN_GUARANTOR_NAME       = LS_RESPONSE-BILL_OPEN_GUARANTOR_NAME.
      <FS_OUT>-BILL_OPEN_GUARANTOR_ADD       = LS_RESPONSE-BILL_OPEN_GUARANTOR_ADD .
      <FS_OUT>-BILL_OPEN_GUARANT_DATE       = LS_RESPONSE-BILL_OPEN_GUARANT_DATE  .
      <FS_OUT>-ACCEPTERNAME       = LS_RESPONSE-ACCEPTER_NAME           .
      <FS_OUT>-BILL_OPEN_PROMISE       = LS_RESPONSE-BILL_OPEN_PROMISE       .
      <FS_OUT>-ACCEPTER_PROMISE       = LS_RESPONSE-ACCEPTER_PROMISE        .
      <FS_OUT>-ACCEPT_GUARANTOR_NAME       = LS_RESPONSE-ACCEPT_GUARANTOR_NAME   .
      <FS_OUT>-ACCEPT_GUARANTOR_ADD       = LS_RESPONSE-ACCEPT_GUARANTOR_ADD    .
      <FS_OUT>-ACCEPT_GUARANT_DATE       = LS_RESPONSE-ACCEPT_GUARANT_DATE     .
      <FS_OUT>-BILL_OPEN_RATE_AGENCY       = LS_RESPONSE-BILL_OPEN_RATE_AGENCY   .
      <FS_OUT>-BILL_OPEN_LEVEL       = LS_RESPONSE-BILL_OPEN_LEVEL         .
      <FS_OUT>-BILL_OPEN_RATE_DUE       = LS_RESPONSE-BILL_OPEN_RATE_DUE      .
      <FS_OUT>-ACCEPTER_RATE_AGENCY       = LS_RESPONSE-ACCEPTER_RATE_AGENCY    .
      <FS_OUT>-ACCEPTER_LEVEL       = LS_RESPONSE-ACCEPTER_LEVEL          .
      <FS_OUT>-ACCEPTER_RATE_DUE       = LS_RESPONSE-ACCEPTER_RATE_DUE       .

      LOOP AT LS_RESPONSE-RD ASSIGNING FIELD-SYMBOL(<FS_RD>).
        APPEND INITIAL LINE TO <FS_OUT>-RD ASSIGNING FIELD-SYMBOL(<FS_OUTRD>).
*        <fs_outrd>-trantype    = <fs_rd>-tran_type.
*        <fs_outrd>-transnum    = <fs_rd>-trans_num.
*        <fs_outrd>-accname     = <fs_rd>-account_name.
*        <fs_outrd>-accno       = <fs_rd>-account_no.
*        <fs_outrd>-bankcode    = <fs_rd>-bank_code.
*        <fs_outrd>-nextname    = <fs_rd>-next_account_name.
*        <fs_outrd>-nextno      = <fs_rd>-next_account_no.
*        <fs_outrd>-nextcode    = <fs_rd>-next_bank_code.
*        <fs_outrd>-sign_date   = <fs_rd>-sign_date.
*        <fs_outrd>-flag        = <fs_rd>-recite_flag.
        <FS_OUTRD>-TRANTYPE    = <FS_RD>-TRANTYPE.
        <FS_OUTRD>-TRANSNUM    = <FS_RD>-TRANSNUM.
        <FS_OUTRD>-ACCNAME     = <FS_RD>-ACCOUNTNAME.
        <FS_OUTRD>-ACCNO       = <FS_RD>-ACCOUNTNO.
        <FS_OUTRD>-BANKCODE    = <FS_RD>-BANKCODE.
        <FS_OUTRD>-NEXTNAME    = <FS_RD>-NEXTACCOUNTNAME.
        <FS_OUTRD>-NEXTNO      = <FS_RD>-NEXTACCOUNTNO.
        <FS_OUTRD>-NEXTCODE    = <FS_RD>-NEXTBANKCODE.
        <FS_OUTRD>-SIGN_DATE   = <FS_RD>-SIGNDATE.
        <FS_OUTRD>-FLAG        = <FS_RD>-RECITEFLAG.
      ENDLOOP.
    ELSE.
      <FS_OUT>-RSPCOD = ''.
      <FS_OUT>-RSPMSG = ''.
    ENDIF.

  ENDLOOP.





ENDFUNCTION.
