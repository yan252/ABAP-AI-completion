class ZCL_BANK_ABC_FUNCTION_CHKSTA definition
  public
  inheriting from ZCL_BANK_FUNCTION_CHECKPAYM
  final
  create public .

public section.
protected section.

  methods PROCESSING_RESPONSE_INTL_CORE
    redefinition .
private section.
ENDCLASS.



CLASS ZCL_BANK_ABC_FUNCTION_CHKSTA IMPLEMENTATION.


METHOD processing_response_intl_core.
    FIELD-SYMBOLS: <ft_sending_entries> TYPE ztrs_payment_check_status_tab.
    FIELD-SYMBOLS: <fs_response>        TYPE ztrs_abc_cqrt04_res_status."ztrs_Abc_payment_response.
    DATA: ls_bank_payment_return TYPE ztrs_payment_bank_return.


    super->processing_response_intl_core( ).

    ASSIGN sending_data_reference->* TO <ft_sending_entries>.
    READ TABLE <ft_sending_entries> INTO DATA(ls_sending_entry)
          WITH KEY seqnumber = current_sending_sequence.
    IF sy-subrc <> 0.
*      unexpected error
      MESSAGE x091(ztr_bank_application)
      WITH function_config-bank_func
      current_sending_sequence.
    ENDIF.

    DATA(ls_response_data) = get_current_response_data( ).
    ASSIGN ls_response_data-response_ref->* TO <fs_response>.

    MOVE: <fs_response>-ap-respcode TO ls_bank_payment_return-header-bank_rtncode,
    "  <fs_response>-responseheader-adjustcode TO ls_bank_payment_return-header-adjust_returncode,
    <fs_response>-ap-respinfo TO ls_bank_payment_return-header-bank_rtnmsg.
*
*1.CFRT02交易的应答报文中<RespCode>值为0000且<WaitFlag>值为0，表示交易成功;
*    <RespCode>值为0000且<WaitFlag>值为1，表示交易落地，需要用CQRA61交易查落地交易处理结果;
*    <RespCode>值为0001且<WaitFlag>值为1，表示交易落地，需要用CQRA61交易查落地交易处理结果;
*    <RespCode>值为9999、CICS、0996、1001，表示交易结果未知、需要用CQRT04交易做查证;
*    <RespCode>的值非0000、0001、9999、CICS、0996、1001，表示交易失败。
*2.CFRT21、CFRT73交易的应答报文中<RespCode>值为0000，表示交易成功;
*    <RespCode>值为9999、CICS、0996、1001，表示交易结果未知、需要用CQRT04交易做查证;
*    <RespCode>的值非0000、9999、CICS、0996、1001，表示交易失败。

*  1）CQRT04一般情况下都会成功返回，这里的成功说明CQRT04查询交易本身成功，具体它所查的流水状态，见2）中判断
*  2）判断szRespCode其是否为“0000”，是则说明该流水成功了；否则需要再判断szAbisRespCode是否为空，如果szAbisRespCode不为空则真正的返回码采用szAbisRespCode中的值，如果szAbisRespCode为空则就直接采用szRespCode的值。
*  3）<Postscript>该流水的状态信息</Postscript>中，是反映该流水具体处理状态说明，如果成功，则显示“交易成功”，否则显示具体错误信息

    "  SPLIT <fs_response>-cmp-respprvdata AT ',' INTO DATA(p1) DATA(p2) DATA(p3) DATA(p4) DATA(p5).
    BREAK-POINT.
    DATA(p4) = <fs_response>-cmp-respprvdata+18(4).
    DATA(p5) = <fs_response>-cmp-respprvdata+22(4).
    IF p4 = '0000'.
      <fs_response>-ap-respcode = p4.
    ELSE.
      IF p5 IS NOT  INITIAL.
        <fs_response>-ap-respcode = p5.
      ELSE.
        <fs_response>-ap-respcode = p4.
      ENDIF.
    ENDIF.
    CLEAR:p4,p5.

*    IF     <fs_response>-ap-respcode <> '0000'
*       AND <fs_response>-ap-respcode <> '9999'
*       AND <fs_response>-ap-respcode <> 'CICS'
*       AND <fs_response>-ap-respcode <> '0996'
*       AND <fs_response>-ap-respcode <> '1001'
*       AND <fs_response>-ap-respcode <> '0001'. "通过银企通通讯平台软件（专线版）做的，落地交易查到的结果是0001
*
*
*      DATA(adre) = 'FFFFFF'."表示交易失败。
*    ENDIF.
*银行返回码是否已维护，没维护的报未知错误
    SELECT SINGLE bank_rtncode INTO  @data(rc)
          FROM ztrt_bank_rtncod
          WHERE bank_ind = 'ABC'
          AND   bank_rtncode = @<fs_response>-ap-respcode.
    "AND   bank_reqsts = @wf.
    IF rc IS INITIAL.

      DATA(adre)  = 'FFFFFF'."表示未知错误。

    ENDIF.
    CLEAR:rc.
    APPEND VALUE #( paymorder = ls_sending_entry-paymorder
                    doc1r = ls_sending_entry-paymorder
                    bank_rtncode = <fs_response>-ap-respcode
                   " bank_reqsts = <fs_response>-corp-waitflag
                    adjust_returncode = adre
                    bank_rtnmsg = <fs_response>-postscript
                    bank_tran_number = <fs_response>-ap-respseqno )
                    TO ls_bank_payment_return-items.

    update_status_in_instance( ls_bank_payment_return ).
    CLEAR:adre.
  ENDMETHOD.
ENDCLASS.
