class ZCL_BANK_CITIC_FUNCTION_ACBAL definition
  public
  inheriting from ZCL_BANK_FUNCTION_ACCBALANCE
  final
  create public .

public section.
protected section.

  methods PROCESSING_RESPONSE_INTL_CORE
    redefinition .
private section.
ENDCLASS.



CLASS ZCL_BANK_CITIC_FUNCTION_ACBAL IMPLEMENTATION.


METHOD processing_response_intl_core.
    processing_response_by_dbtable(
                im_data_db_table = 'ZTRT_CITIC_ACBAL'
                im_detail_response_component = 'STREAM-ROW'
                im_statuscode_componnet = 'STREAM-STATUS'
                im_statustext_component = 'STREAM-STATUSTEXT'
                im_db_account_number_field = 'ACCOUNTNO'
                IM_BANK_ENTRY_ACCNUMBER_FIELD = 'ACCOUNTNO'  ).
  ENDMETHOD.
ENDCLASS.
