*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_TR2_BANK_DBCX_BOCTOP.         " Global Declarations
  INCLUDE LZFG_TR2_BANK_DBCX_BOCUXX.         " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_TR2_BANK_DBCX_BOCF...         " Subroutines
* INCLUDE LZFG_TR2_BANK_DBCX_BOCO...         " PBO-Modules
* INCLUDE LZFG_TR2_BANK_DBCX_BOCI...         " PAI-Modules
* INCLUDE LZFG_TR2_BANK_DBCX_BOCE...         " Events
* INCLUDE LZFG_TR2_BANK_DBCX_BOCP...         " Local class implement.
* INCLUDE LZFG_TR2_BANK_DBCX_BOCT99.         " ABAP Unit tests
