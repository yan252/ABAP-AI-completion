class ZCL_BANK_ACCOUNT_CCB definition
  public
  inheriting from ZCL_ABSTRACT_BANK_ACCOUNT
  final
  create public .

public section.
protected section.

  methods BANK_BALANCE_TO_SAP
    redefinition .
  methods BANK_TRANSACTIONS_TO_SAP
    redefinition .
  methods DEQUEUE_TRANSACTION
    redefinition .
  methods SET_ACCOUNT_BALANCE_CORE
    redefinition .
  methods SET_ACCOUNT_TABNAME
    redefinition .
  methods SET_HISTORY_ACC_BAL_CORE
    redefinition .
  methods SET_TRANSACTIONS_CORE
    redefinition .
  methods BANK_HISTORY_BALANCE_TO_SAP
    redefinition .
private section.
ENDCLASS.



CLASS ZCL_BANK_ACCOUNT_CCB IMPLEMENTATION.


METHOD bank_balance_to_sap.
    FIELD-SYMBOLS: <ft_new_account_balance> TYPE STANDARD TABLE.
    DATA: ls_balance_ext TYPE ztrt_ccb_acbal.

    ASSIGN new_account_balance->* TO <ft_new_account_balance>.
    IF <ft_new_account_balance> IS NOT ASSIGNED OR
       <ft_new_account_balance> IS INITIAL.
      RETURN.
    ENDIF.

    LOOP AT <ft_new_account_balance> INTO ls_balance_ext.
      APPEND VALUE #(
                       bukrs        = ls_balance_ext-sap_bukrs
                       hbkid        = ls_balance_ext-sap_hbkid
                       hktid        = ls_balance_ext-sap_hktid
                       yhzh         = ls_balance_ext-acc_no
                       bank_ind     = bank_indicator
                       zyue_ttl     = ls_balance_ext-BALANCE
                       zyue_frz     = ( ls_balance_ext-BALANCE - ls_balance_ext-balance1 )
                       zyue         = ls_balance_ext-balance1
                       waers        = GET_ACCOUNT_CURRENCY( ls_balance_ext-sap_fields )
                       ) TO rt_balance.

    ENDLOOP.
  ENDMETHOD.


METHOD bank_history_balance_to_sap.
    FIELD-SYMBOLS: <ft_new_account_balance> TYPE STANDARD TABLE.
    DATA: ls_balance_ext TYPE ztrt_ccb_hacbal.

    ASSIGN new_history_account_balance->* TO <ft_new_account_balance>.
    IF <ft_new_account_balance> IS NOT ASSIGNED OR
       <ft_new_account_balance> IS INITIAL.
      RETURN.
    ENDIF.

    LOOP AT <ft_new_account_balance> INTO ls_balance_ext.
      APPEND VALUE #(
                       bukrs        = ls_balance_ext-sap_bukrs
                       hbkid        = ls_balance_ext-sap_hbkid
                       hktid        = ls_balance_ext-sap_hktid
                       yhzh         = ls_balance_ext-acc_no
                       zdate        = ls_balance_ext-zdate
                       bank_ind     = bank_indicator
                       zyue_ttl     = ls_balance_ext-balance
                       waers        = get_account_currency( ls_balance_ext-sap_fields )
                       ) TO rt_balance.

    ENDLOOP.
  ENDMETHOD.


METHOD bank_transactions_to_sap.
    FIELD-SYMBOLS: <ft_new_transactions> TYPE STANDARD TABLE.
    DATA: ls_transactions_ext TYPE ztrt_ccb_trns.

    ASSIGN new_transactions->* TO <ft_new_transactions>.
    IF <ft_new_transactions> IS NOT ASSIGNED OR
       <ft_new_transactions> IS INITIAL.
      RETURN.
    ENDIF.

    LOOP AT <ft_new_transactions> INTO ls_transactions_ext.
      DATA(l_shkzg) = zcl_ccb_enhancement=>convert_debit_and_credit_flag( ls_transactions_ext-flag1 ).
      DATA(ls_paymentkey) = get_paymkey_from_transaction( ls_transactions_ext-det ).

*-----Begin 对方名称中的全角和半角括号去除后存入字段BKOINH1中 金志强 Add by KLTDEV5 20190726
      "字符串转换
      DATA:lv_bkoinh TYPE string.
      lv_bkoinh = ls_transactions_ext-acc_name1.
      lv_bkoinh = convert_string( EXPORTING string = lv_bkoinh char = '(' ).
      lv_bkoinh = convert_string( EXPORTING string = lv_bkoinh char = ')' ).
      lv_bkoinh = convert_string( EXPORTING string = lv_bkoinh char = '（' ).
      lv_bkoinh = convert_string( EXPORTING string = lv_bkoinh char = '）' ).
*-----End 对方名称中的全角和半角括号去除后存入字段BKOINH1中 金志强 Add by KLTDEV5 20190726

      APPEND VALUE ztrt_bank_trans(
                       bukrs        = ls_transactions_ext-sap_bukrs
                       hbkid        = ls_transactions_ext-sap_hbkid
                       hktid        = ls_transactions_ext-sap_hktid
                       yhzh         = ls_transactions_ext-accno1
                       trxno        = ls_transactions_ext-tran_flow
                       bank_ind     = bank_indicator
                       trxdate      = ls_transactions_ext-trandate+0(4) &&
                                      ls_transactions_ext-trandate+5(2) &&
                                      ls_transactions_ext-trandate+8(2)
* begin 20190716 针对建行部分交易银行记账日期与交易发生日期不在同一天的流水进行调整  ERDK930996
*交易日期在记账日期前，交易时间设置到0点
*                       trxtime      = ls_transactions_ext-trantime+0(2) &&
*                                      ls_transactions_ext-trantime+3(2) &&
*                                      ls_transactions_ext-trantime+6(2)
                       trxtime      = COND uzeit( WHEN ls_transactions_ext-trandate = ls_transactions_ext-real_trandate
                                                  THEN ls_transactions_ext-trantime+0(2) &&
                                                       ls_transactions_ext-trantime+3(2) &&
                                                       ls_transactions_ext-trantime+6(2)   )
* end 20190716 针对建行部分交易银行记账日期与交易发生日期不在同一天的流水进行调整  ERDK930996
                       shkzg        = l_shkzg
                       bkfse       = ls_transactions_ext-amt
                       trxamt        = convert_transamt_by_shkzg( im_shkzg        = l_shkzg
                                                                  im_original_amt = ls_transactions_ext-amt )
                       balamt       = ls_transactions_ext-amt1
                       waers        = ls_transactions_ext-sap_waers
                       bzbnka       = ls_transactions_ext-cadbank_nm
                       bzbnkn       = ls_transactions_ext-accno2
                       bkoinh       = ls_transactions_ext-acc_name1
                       abstract_txt = ls_transactions_ext-message
                       paymentkey   = ls_paymentkey
                       zref_doc = ls_paymentkey-paymorder
                       intfdate     = system_info-datum
                       intftime     = system_info-uzeit
                       partner      = set_partner_by_name( ls_transactions_ext-acc_name1 )
                       bkoinh1      = lv_bkoinh
                       ) TO rt_transactions.

    ENDLOOP.
    finished_sap_tranx_fields(
               CHANGING
                 ch_t_tranx = rt_transactions ).
  ENDMETHOD.


method DEQUEUE_TRANSACTION.
    DATA:ls_transaction TYPE ztrt_ccb_trns.

    LOOP AT im_t_transactions INTO ls_transaction.
      dequeue_transaction_core(
                     im_bukrs = ls_transaction-sap_bukrs
                     im_hbkid = ls_transaction-sap_hbkid
                     im_hktid = ls_transaction-sap_hktid
                     im_yhzh = ls_transaction-accno1
                     im_trxno = ls_transaction-tran_flow ).
    ENDLOOP.
  endmethod.


METHOD set_account_balance_core.
    FIELD-SYMBOLS: <ft_acc_balance> TYPE ztrt_ccb_acbal_tab.
    FIELD-SYMBOLS:<ft_new_entries> TYPE ztrt_ccb_acbal_tab.
    DATA: l_new     TYPE flag,
          l_changed TYPE flag.

    ASSIGN im_data->* TO <ft_acc_balance>.

    ASSIGN new_account_balance->* TO <ft_new_entries>.

    IF <ft_acc_balance> IS INITIAL.
      RETURN.
    ENDIF.

    SELECT * INTO TABLE @DATA(lt_old_data)
           FROM ztrt_ccb_acbal
           FOR ALL ENTRIES IN @<ft_acc_balance>
           WHERE acc_no = @<ft_acc_balance>-acc_no.

    LOOP AT <ft_acc_balance> INTO DATA(ls_acc_balance).
      CHECK filter_accbal_by_shifton_date(
                  EXPORTING
                    im_s_sap_field = ls_acc_balance-sap_fields ) = 'X'.
      enqueue_balance_core(
                 EXPORTING
                   im_bukrs = ls_acc_balance-sap_bukrs
                   im_hbkid = ls_acc_balance-sap_hbkid
                   im_hktid = ls_acc_balance-sap_hktid
                 IMPORTING
                   ex_enqueue_failed = DATA(l_enqueue_failed) ).
      IF l_enqueue_failed = yes.
*        被锁定，不纳入本次处理
        CLEAR l_enqueue_failed.
        CONTINUE.
      ENDIF.

      READ TABLE lt_old_data INTO DATA(ls_old_data)
           WITH KEY acc_no = ls_acc_balance-acc_no.
      IF sy-subrc <> 0.
*      new
        l_new = 'X'.
      ELSE.
        IF ls_acc_balance-acc_field <> ls_old_data-acc_field.
          l_changed = 'X'.
        ENDIF.
      ENDIF.

      IF l_new = 'X' OR
         l_changed = 'X'.
        ls_acc_balance-dbadmin = ls_old_data-dbadmin.
        set_admin_fields(
                  EXPORTING
                    im_new_entry = l_new
                  CHANGING
                    cs_admin = ls_acc_balance-dbadmin ).
        APPEND ls_acc_balance TO <ft_new_entries>.
      ELSE.
        dequeue_balance_core(
                   EXPORTING
                     im_bukrs = ls_acc_balance-sap_bukrs
                     im_hbkid = ls_acc_balance-sap_hbkid
                     im_hktid = ls_acc_balance-sap_hktid ).
      ENDIF.

      CLEAR: l_new,
             l_changed.
    ENDLOOP.

  ENDMETHOD.


METHOD SET_ACCOUNT_TABNAME.
    transaction_db_tabname = 'ZTRT_CCB_TRNS'.
    account_balance_db_tabname = 'ZTRT_CCB_ACBAL'.
    HISTORY_ACC_BALANCE_DB_NAME = 'ZTRT_CCB_HACBAL'.
    super->set_account_tabname( ).
  ENDMETHOD.


method SET_HISTORY_ACC_BAL_CORE.
 FIELD-SYMBOLS: <ft_acc_balance> TYPE ztrt_ccb_hacbal_tab.
    FIELD-SYMBOLS:<ft_new_entries> TYPE ztrt_ccb_hacbal_tab.
    DATA: l_new     TYPE flag,
          l_changed TYPE flag.

    ASSIGN im_data->* TO <ft_acc_balance>.

    ASSIGN NEW_HISTORY_ACCOUNT_BALANCE->* TO <ft_new_entries>.

    IF <ft_acc_balance> IS INITIAL.
      RETURN.
    ENDIF.

    SELECT * INTO TABLE @DATA(lt_old_data)
           FROM ztrt_ccb_hacbal
           FOR ALL ENTRIES IN @<ft_acc_balance>
           WHERE acc_no = @<ft_acc_balance>-acc_no
           and   zdate = @<ft_acc_balance>-zdate.

    LOOP AT <ft_acc_balance> INTO DATA(ls_acc_balance).
      CHECK filter_accbal_by_shifton_date(
                  EXPORTING
                    im_s_sap_field = ls_acc_balance-sap_fields
*                    ZDATE是CHAR类型
*                    如果ZDATE不是CHAR类型，XML transformation会报错
                    im_date = ls_acc_balance-zdate+0(4) &&
                              ls_acc_balance-zdate+4(2) &&
                              ls_acc_balance-zdate+6(2) ) = 'X'.

      READ TABLE lt_old_data INTO DATA(ls_old_data)
           WITH KEY acc_no = ls_acc_balance-acc_no
                    zdate = ls_acc_balance-zdate.
      IF sy-subrc <> 0.
*      new
        l_new = 'X'.
      ELSE.
        IF ls_acc_balance-acc_field <> ls_old_data-acc_field.
          l_changed = 'X'.
        ENDIF.
      ENDIF.

      IF l_new = 'X' OR
         l_changed = 'X'.
        ls_acc_balance-dbadmin = ls_old_data-dbadmin.
        set_admin_fields(
                  EXPORTING
                    im_new_entry = l_new
                  CHANGING
                    cs_admin = ls_acc_balance-dbadmin ).
        APPEND ls_acc_balance TO <ft_new_entries>.
      ENDIF.

      CLEAR: l_new,
             l_changed.
    ENDLOOP.
  endmethod.


METHOD set_transactions_core.
    FIELD-SYMBOLS: <ft_transactions> TYPE ztrt_ccb_trns_tab.
    FIELD-SYMBOLS: <ft_new_entries> TYPE ztrt_ccb_trns_tab.
    DATA: l_new     TYPE flag,
          l_changed TYPE flag.
    ASSIGN im_data->* TO <ft_transactions>.

    ASSIGN new_transactions->* TO <ft_new_entries>.

    IF <ft_transactions> IS NOT ASSIGNED OR
       <ft_transactions> IS INITIAL.
      RETURN.
    ENDIF.
*    SORT <ft_transactions> BY accno1 trandate trantime det_no.
    SELECT * INTO TABLE @DATA(lt_old_data)
           FROM ztrt_ccb_trns
           FOR ALL ENTRIES IN @<ft_transactions>
           WHERE accno1 = @<ft_transactions>-accno1
           AND   cre_typ = @<ft_transactions>-cre_typ
           AND   cre_no = @<ft_transactions>-cre_no.

    LOOP AT <ft_transactions> INTO DATA(ls_transactions).
* { add by hjj 建设银行 20191101 2008 10015 10001交易存在相同时间，相同银行流水号问题 ，对相同流水号手动区分 20191128。
        LOOP AT <ft_transactions> INTO DATA(ls_rep)   WHERE accno1 = ls_transactions-accno1
                                                        AND  tran_flow = ls_transactions-tran_flow
                                                        AND  det_no < ls_transactions-det_no .
          EXIT."如果前面已经存在相同的流水号，则替换后面的流水号
        ENDLOOP.
        IF  sy-subrc = 0.
          ls_transactions-tran_flow = ls_transactions-tran_flow && '-' && ls_transactions-det_no.
        ENDIF.
*  }add by hjj 建设银行 20191101 2008 10015 10001交易存在相同银行流水号问题 ，对相同流水号手动区分 20191128。
* add by hjj  建设银行 结息没有银行交易流水 需手动添加 20190712
      IF ls_transactions-tran_flow IS INITIAL.
        ls_transactions-tran_flow =  'SAP'  && ls_transactions-trandate && ls_transactions-trantime && ls_transactions-det_no.
        CONDENSE ls_transactions-tran_flow.
      ENDIF.
* add by hjj  建设银行 结息没有银行交易流水  20190712

      CHECK filter_trans_by_shifton_date(
                  EXPORTING
                    im_s_sap_field = ls_transactions-sap_fields
                    im_transaction_date = ls_transactions-trandate+0(4) &&
                                          ls_transactions-trandate+5(2) &&
                                          ls_transactions-trandate+8(2) ) = 'X'.
      enqueue_transaction_core(
                   EXPORTING
                     im_bukrs = ls_transactions-sap_bukrs
                     im_hbkid = ls_transactions-sap_hbkid
                     im_hktid = ls_transactions-sap_hktid
                     im_yhzh = ls_transactions-accno1
                     im_trxno = ls_transactions-tran_flow
                   IMPORTING
                     ex_enqueue_failed = DATA(l_enqueue_failed) ).
      IF l_enqueue_failed = yes.
*        被锁定，不纳入本次处理
        CLEAR l_enqueue_failed.
        CONTINUE.
      ENDIF.

      READ TABLE lt_old_data INTO DATA(ls_old_data)
           WITH KEY accno1 = ls_transactions-accno1
                    cre_typ = ls_transactions-cre_typ
                    cre_no = ls_transactions-cre_no.
      IF sy-subrc <> 0.
*      new
        l_new = 'X'.
      ELSE.
        IF ls_transactions-trns_field <> ls_old_data-trns_field.
          l_changed = 'X'.
        ENDIF.
      ENDIF.

      IF l_new = 'X' OR
         l_changed = 'X'.
        ls_transactions-dbadmin = ls_old_data-dbadmin.
        set_admin_fields(
                  EXPORTING
                    im_new_entry = l_new
                  CHANGING
                    cs_admin = ls_transactions-dbadmin ).
        APPEND ls_transactions TO <ft_new_entries>.
      ELSE.
        dequeue_transaction_core(
                     EXPORTING
                       im_bukrs = ls_transactions-sap_bukrs
                       im_hbkid = ls_transactions-sap_hbkid
                       im_hktid = ls_transactions-sap_hktid
                       im_yhzh = ls_transactions-accno1
                       im_trxno = ls_transactions-tran_flow ).
      ENDIF.

      CLEAR: l_new,
             l_changed,
             ls_old_data.
    ENDLOOP.

  ENDMETHOD.
ENDCLASS.
