FUNCTION-POOL zfg_tr_bank.                   "MESSAGE-ID ..
*data dummy_msg type string.
* INCLUDE LZFG_TR_ANKD...                    " Local class definition
types: BEGIN OF gs_type_lock_payment_order,
       docno type ztrt_payment-paymorder,
       end of gs_type_lock_payment_order.
types: BEGIN OF gs_type_lock_bank,
       bank_ind type ztr_bank_indicator,
       end of gs_type_lock_bank.
data: gt_lock_payment_order
            type STANDARD TABLE OF gs_type_lock_payment_order.
data: gt_lock_bank
            type STANDARD TABLE OF gs_type_lock_bank.
data:gt_paymorder_buffer type ZTRS_PAYMORDER_BUFFER_TAB.
