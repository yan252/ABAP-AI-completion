FUNCTION ZFM_TR2_BANK_SQCX1_BOC.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     REFERENCE(IS_IN) TYPE  ZTR2S_BANK_SQCX1_IN
*"  EXPORTING
*"     REFERENCE(ES_OUT) TYPE  ZTR2S_BANK_SQCX1_OUT
*"--------------------------------------------------------------------
"发送XML定义
  TYPES:BEGIN OF ly_b2e0114,
          ibknum    TYPE string,  "联行号
          actacn    TYPE string,  "账号
          msgseq    TYPE string,  "票据标识号
          transtype TYPE string, "业务类型
        END OF ly_b2e0114.

  DATA:BEGIN OF ls_data,
         b2e0114-rq TYPE ly_b2e0114 OCCURS 0,
       END OF ls_data.

  "接受XML定义
  TYPES:BEGIN OF ly_b2e0114_rs,
          rspcod TYPE string,
          rspmsg TYPE string,
          agrno  TYPE string,  "承兑协议编号
        END OF ly_b2e0114_rs.

  DATA:BEGIN OF ls_response,
         rspcod     TYPE string,
         rspmsg     TYPE string,
         b2e0114-rs TYPE ly_b2e0114_rs OCCURS 0,
       END OF ls_response.
  DATA:response TYPE string.

  CONSTANTS: gc_action TYPE ztr_app_action_for_bank VALUE '301'.  "申请操作记录查询-单笔明细查询

  DATA(lo_xml) = NEW zcl_tr2_xml( ).

  APPEND INITIAL LINE TO ls_data-b2e0114-rq ASSIGNING FIELD-SYMBOL(<fs_data>).
  <fs_data>-ibknum = is_in-ibknum.
  <fs_data>-actacn = is_in-actacn.
  <fs_data>-msgseq = is_in-msgseq.
  <fs_data>-transtype = is_in-transtype.

  CALL FUNCTION 'ZFM_TR2_BANK_SEND'
    EXPORTING
      bank_ind    = 'BOC' "中国银行
      bank_action = gc_action
      data_in     = ls_data
      method      = 'POST'
    IMPORTING
      response    = response.

  lo_xml->convert_xml_to_abap( EXPORTING response = response bank_ind = 'BOC' bank_action = gc_action IMPORTING data = ls_response ).

  es_out-msgseq = is_in-msgseq.

  LOOP AT  ls_response-b2e0114-rs INTO DATA(ls_b2e0114_rs) .
    es_out-rspmsg = ls_b2e0114_rs-rspmsg.
    es_out-rspcod = ls_b2e0114_rs-rspcod.
    es_out-agrno = ls_b2e0114_rs-agrno.
  ENDLOOP.
  IF sy-subrc NE 0.
    IF ls_response-rspmsg IS NOT INITIAL.
      es_out-rspmsg = ls_response-rspmsg.
    ENDIF.
  ENDIF.

  CLEAR:ls_data,response,ls_response.





ENDFUNCTION.
