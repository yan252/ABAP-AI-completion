@AbapCatalog.sqlViewName: 'ZTRCDSAGN02'
@AbapCatalog.compiler.compareFilter: true
@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'ztrv_amt_agn-2'
define view ZDDL_AGN02 as select from ztrv_amt_agn {
mandt ,
jjbilln , 
bukrs ,
gjahr , 
belnr , 
buzei , 
wrbtr_agn , 
waers 
} 
where jjbilln <> '' and dflag = '' 
  
 