class ZCL_BANK_CMBC_FUNCTION_CHKSTA definition
  public
  inheriting from ZCL_BANK_FUNCTION_CHECKPAYM
  final
  create public .

public section.

  interfaces ZIF_CMBC_FUNCTION .
protected section.

  aliases INTERACTION_COUNT
    for ZIF_CMBC_FUNCTION~INTERACTION_COUNT .
  aliases GET_CURRENT_PACKAGE_ID
    for ZIF_CMBC_FUNCTION~GET_CURRENT_PACKAGE_ID .
  aliases WAIT
    for ZIF_CMBC_FUNCTION~WAIT .

  methods PROCESSING_RESPONSE_INTL_CORE
    redefinition .
private section.
ENDCLASS.



CLASS ZCL_BANK_CMBC_FUNCTION_CHKSTA IMPLEMENTATION.


  METHOD processing_response_intl_core.
    FIELD-SYMBOLS: <fs_response>        TYPE ztrs_cmbc_qryxfer_response.
    FIELD-SYMBOLS: <ft_sending_entries> TYPE ztrs_payment_check_status_tab.
    DATA: ls_bank_payment_return TYPE ztrs_payment_bank_return.

    super->processing_response_intl_core( ).

    DATA(ls_response_data) = get_current_response_data( ).
    ASSIGN ls_response_data-response_ref->* TO <fs_response>.

    ASSIGN sending_data_reference->* TO <ft_sending_entries>.

**      查询交易是单笔查询
    READ TABLE <ft_sending_entries> INTO DATA(ls_sending_entry)
         WITH KEY seqnumber = current_sending_sequence.
    IF sy-subrc <> 0.
*      unexpected error

      MESSAGE x091(ztr_bank_application)
              WITH function_config-bank_func
                   current_sending_sequence.
    ENDIF.

    MOVE: <fs_response>-responseheader-code TO ls_bank_payment_return-header-bank_rtncode,
          <fs_response>-responseheader-adjustcode TO ls_bank_payment_return-header-adjust_returncode,
          <fs_response>-responseheader-severity TO ls_bank_payment_return-header-bank_reqsts,
          <fs_response>-responseheader-message TO ls_bank_payment_return-header-bank_rtnmsg.


***      查询交易是单笔查询
*    READ TABLE <fs_response>-stream-row INTO DATA(ls_response_row) INDEX 1.
*    IF sy-subrc <> 0.
**  银行在报文抬头返回错误
*      MOVE: <fs_response>-stream-status TO ls_response_row-status,
*           <fs_response>-stream-statustext TO ls_response_row-statustext.
*    ENDIF.

*    APPEND VALUE ztrs_payment_bank_return_i( paymorder = ls_sending_entry-paymorder
*                                             doc1r = ls_sending_entry-paymorder
*                                             bank_rtnflg  = ls_response_row-stt
*                                             bank_rtncode = ls_response_row-status
*                                             bank_rtnmsg = ls_response_row-statustext )
*                 TO ls_bank_payment_return-items.

    IF <fs_response>-xdatabody-statuscode IS INITIAL.
*     xdatabody的状态没有返回代码，查询报错了，就在抬头层面报错
*      这个情况一般来说是
*      1）民生银行没有查询到该笔支付单信息，说明银行没有接收到该笔支付交易
*      2）或者发送查询的XML报文语法或格式错误
      APPEND VALUE #( paymorder = ls_sending_entry-paymorder
                      doc1r = ls_sending_entry-paymorder
                      bank_rtncode = <fs_response>-responseheader-code
                      bank_reqsts = <fs_response>-responseheader-severity
                      adjust_returncode = <fs_response>-responseheader-adjustcode
                      bank_rtnmsg = <fs_response>-responseheader-message )
                   TO ls_bank_payment_return-items.
    ELSE.
      APPEND VALUE #( paymorder = ls_sending_entry-paymorder
                      doc1r = ls_sending_entry-paymorder
                      bank_rtncode = <fs_response>-xdatabody-statuscode
                      bank_reqsts = <fs_response>-xdatabody-statusseverity
                      adjust_returncode = <fs_response>-xdatabody-bodyadjustcode
                      bank_rtnmsg = <fs_response>-xdatabody-statuserrmsg )
                   TO ls_bank_payment_return-items.
    ENDIF.
    update_status_in_instance( ls_bank_payment_return ).

    wait( ).

  ENDMETHOD.


  method ZIF_CMBC_FUNCTION~GET_CURRENT_PACKAGE_ID.

  endmethod.


  METHOD zif_cmbc_function~wait.
    zcl_cmbc_enhancement=>wait(
                    CHANGING
                      ch_interaction_count = interaction_count ).
  ENDMETHOD.
ENDCLASS.
