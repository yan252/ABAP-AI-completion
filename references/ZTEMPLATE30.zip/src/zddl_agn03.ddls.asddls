@AbapCatalog.sqlViewName: 'ZTRCDSAGN_SUM'
@AbapCatalog.compiler.compareFilter: true
@AbapCatalog.preserveKey: true
@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: '计划锁定总金额'
define view ZDDL_AGN03
as select from ztrv_amt_agn          
{
mandt,
bukrs,
gjahr,
belnr,
buzei,
zbelnr1,
sqdxh,
sum(wrbtr_agn) as WRBTR_AGN
}
where dflag = ''
  group by bukrs,
           gjahr ,
           belnr ,
           buzei , 
           zbelnr1 ,
           sqdxh 
  
 