*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_TR2_BANK_YDCL_CCBTOP.         " Global Declarations
  INCLUDE LZFG_TR2_BANK_YDCL_CCBUXX.         " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_TR2_BANK_YDCL_CCBF...         " Subroutines
* INCLUDE LZFG_TR2_BANK_YDCL_CCBO...         " PBO-Modules
* INCLUDE LZFG_TR2_BANK_YDCL_CCBI...         " PAI-Modules
* INCLUDE LZFG_TR2_BANK_YDCL_CCBE...         " Events
* INCLUDE LZFG_TR2_BANK_YDCL_CCBP...         " Local class implement.
* INCLUDE LZFG_TR2_BANK_YDCL_CCBT99.         " ABAP Unit tests
