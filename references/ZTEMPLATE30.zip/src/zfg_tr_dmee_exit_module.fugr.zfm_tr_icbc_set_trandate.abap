FUNCTION ZFM_TR_ICBC_SET_TRANDATE.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     VALUE(I_TREE_TYPE) TYPE  DMEE_TREETYPE_ABA
*"     VALUE(I_TREE_ID) TYPE  DMEE_TREEID_ABA
*"     VALUE(I_ITEM)
*"     VALUE(I_PARAM)
*"     VALUE(I_UPARAM)
*"  EXPORTING
*"     REFERENCE(O_VALUE)
*"     REFERENCE(C_VALUE)
*"     REFERENCE(N_VALUE)
*"     REFERENCE(P_VALUE)
*"  TABLES
*"      I_TAB
*"--------------------------------------------------------------------
FIELD-SYMBOLS <fs_fpayh> TYPE fpayh.

  ASSIGN COMPONENT 'FPAYH' OF STRUCTURE i_item TO <fs_fpayh>.
  IF sy-subrc = 0.
*工商银行测试系统时间和自然日期不一致，需要按照工行当前的日期设置交易日
    c_value = zcl_icbc_enhancement=>set_trandate( <fs_fpayh>-doc1r ).
  ENDIF.





ENDFUNCTION.
