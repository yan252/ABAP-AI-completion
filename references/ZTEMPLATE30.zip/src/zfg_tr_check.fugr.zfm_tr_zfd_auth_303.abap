FUNCTION ZFM_TR_ZFD_AUTH_303.
**"--------------------------------------------------------------------
**"*"局部接口：
**"  IMPORTING
**"     REFERENCE(BUKRS) TYPE  BUKRS
**"     REFERENCE(ZZFTYPE) TYPE  ZTR_ZFTYPE
**"  EXCEPTIONS
**"      ERR
**"--------------------------------------------------------------------
*DATA: lv_string  TYPE string.
*  IF NOT  ( zcl_tr_3024_gui=>auth = abap_true OR sy-sysid = 'ERP' ).
*    sy-subrc = 0.
*    RETURN.
*  ENDIF.
*  AUTHORITY-CHECK OBJECT 'Z_TR303'
*    ID 'BUKRS' FIELD bukrs
*    ID 'ZTR_ZFTYPE' FIELD zzftype.
*  IF sy-subrc <> 0.
*    zcl_wd_common=>get_dom_value(
*      EXPORTING
*        im_domnam = 'ZDM_TR_ZFTYPE'
*        im_domval = zzftype
*      RECEIVING
*        ex_desc   = lv_string
*    ).
*    MESSAGE e219(ztr05) WITH bukrs lv_string  RAISING err.
*  ENDIF.





ENDFUNCTION.
