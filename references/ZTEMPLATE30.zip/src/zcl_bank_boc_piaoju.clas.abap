class ZCL_BANK_BOC_PIAOJU definition
  public
  final
  create public .

public section.

  constants GC_IP type RFCDEST value '172.18.4.123' ##NO_TEXT.
  data GC_PORT type RFCDEST value '8080' ##NO_TEXT.
protected section.
private section.

  methods REQUEST_POST .
ENDCLASS.



CLASS ZCL_BANK_BOC_PIAOJU IMPLEMENTATION.


method REQUEST_POST.

  DATA: lv_url TYPE string.
  DATA: http_client         TYPE REF TO if_http_client,
        lv_return_cdata          TYPE string,
        lv_return_data           TYPE xstring.
  DATA: ls_http_header_fields TYPE ihttpnvp,
         lt_http_header_fields TYPE TABLE OF ihttpnvp,
         lv_message_length     TYPE i,
         lv_data_xstring       TYPE xstring,
         lv_leading_string     TYPE string,
         lv_leading_xstring    TYPE xstring,
         lr_conv_out           TYPE REF TO cl_abap_conv_out_ce.
  DATA: lr_conv_in            TYPE REF TO cl_abap_conv_in_ce.

  DATA: ls_log TYPE bal_s_msg.


  CONCATENATE 'http://' gc_ip  ':' gc_port '/B2EC/E2BServlet' INTO lv_url.

  lv_leading_string = '<?xml version="1.0" encoding="UTF-8"?><bocb2e version="120" security="true" locale="zh_CN">' .
*创建HTTP 连接
  CALL METHOD cl_http_client=>create_by_url
    EXPORTING
      url                = lv_url
    IMPORTING
      client             = http_client
    EXCEPTIONS
      argument_not_found = 1
      plugin_not_active  = 2
      internal_error     = 3
      OTHERS             = 4.
  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
               WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  ENDIF.


  lr_conv_out = cl_abap_conv_out_ce=>create( encoding = '8400' )."GBK

  CALL METHOD lr_conv_out->convert
    EXPORTING
      data   = lv_leading_string
    IMPORTING
      buffer = lv_leading_xstring.

DATA:LV_STRINGXX TYPE STRING.

CONCATENATE
lv_leading_string
'<head>'
    '<termid>E022011099095</termid>'
    '<trnid>04051003128</trnid>'
    '<custid>790252</custid>'
    '<cusopr>bocfanl1</cusopr>'
    '<trncod>b2e0005</trncod>'
    '<token>0D6886D4498DB958C471131A189DF9CF</token>'
  '</head>'
  '<trans>'
    '<trn-b2e0005-rq>'
      '<b2e0005-rq>'
        '<account>'
          '<ibknum>40142</ibknum>'
          '<actacn>800100001018196001</actacn>'
        '</account>'
      '</b2e0005-rq>'
    '</trn-b2e0005-rq>'
  '</trans>'
'</bocb2e>'
INTO LV_STRINGXX.


  http_client->request->set_cdata( data = LV_STRINGXX ).


http_client->request->set_header_field( name = 'server_protocol' value = 'HTTP/1.1' ).
http_client->request->set_header_field(
 EXPORTING
   name  = 'Content-Type'
   value = 'application/xml;charset=utf-8' ).


  http_client->propertytype_logon_popup = http_client->co_enabled .

  CALL METHOD http_client->request->set_method( 'POST' ).

*发送
*发送

  DATA:
    lo_excp TYPE REF TO cx_root.
  TRY.

     CALL METHOD http_client->send
*       EXPORTING
*         timeout                    = CO_TIMEOUT_DEFAULT
       EXCEPTIONS
         http_communication_failure = 1
         http_invalid_state         = 2
         http_processing_failed     = 3
         http_invalid_timeout       = 4
         others                     = 5.
      IF sy-subrc <> 0.
*        CLEAR:
*          ls_log.
*        ls_log-msgty = 'E'.
*        ls_log-msgid = 'ZFI_BOE01'.
*        ls_log-msgno = '004'.
*        APPEND ls_log TO et_messages.
*        RETURN.
      ENDIF.

     CALL METHOD http_client->receive
       EXCEPTIONS
         http_communication_failure = 1
         http_invalid_state         = 2
         http_processing_failed     = 3
         others                     = 4.
     IF sy-subrc <> 0.
*        CLEAR:
*          ls_log.
*        ls_log-msgty = 'E'.
*        ls_log-msgid = 'ZFI_BOE01'.
*        ls_log-msgno = '004'.
*        APPEND ls_log TO et_messages.
*        RETURN.
     ENDIF.

    CATCH cx_root INTO lo_excp.

*      CLEAR:
*        ls_log.
*
*      ls_log-msgty = 'E'.
*      ls_log-msgid = 'ZFI_BOE01'.
*      ls_log-msgno = '011'.
*
*      APPEND ls_log TO et_messages.
*      RETURN.

  ENDTRY.

  lv_return_cdata = http_client->response->get_cdata( ).
  lv_return_data  = http_client->response->get_data( ).
  IF lv_return_cdata(43) = '<html><head><title>Application Server Error'.
*500Networkconnectionbroken
*    CLEAR:ls_log.
*    ls_log-msgty = 'E'.
*    ls_log-msgid = 'ZFI_BOE01'.
*    ls_log-msgno = '010'.
*    APPEND ls_log TO et_messages.
*    RETURN.
  ENDIF.
*  WRITE: / return_str.
  CALL METHOD http_client->close.
  DATA: lv_return_msg TYPE string.

*  DATA l_cntbin   TYPE sdokcntbins.
*  DATA lv_output_length TYPE i.
*  DATA: lv_real_msg TYPE string.
*  TRY.
*TRY.
  CALL METHOD cl_abap_conv_in_ce=>create
    EXPORTING
      encoding    = '8400'
*     endian      =
*     replacement = '#'
*     ignore_cerr = ABAP_FALSE
      input       = lv_return_data
    RECEIVING
      conv        = lr_conv_in.
*TRY.
  CALL METHOD lr_conv_in->read
*  EXPORTING
*    n      = -1
*    view   =
    IMPORTING
      data   = lv_return_msg.
*    len    =
  .
*  ev_request_message_string = lv_return_msg.

*call screen 9001.

  endmethod.
ENDCLASS.
