FUNCTION ZFM_TR2_BANK_DBYD_CCB.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     REFERENCE(LS_IN) TYPE  ZTR2S_BANK_DBYD_IN
*"  EXPORTING
*"     REFERENCE(LS_OUT) TYPE  ZTR2S_BANK_DBYD_OUT
*"--------------------------------------------------------------------
TYPES: BEGIN OF ty_info,
           bktype1       TYPE string,
           bklistno1     TYPE string,
           bkrole        TYPE string,
           bkacctno1     TYPE string,
           bkbrchno1     TYPE string,
           bkbrchno2     TYPE string,
           bklevel1      TYPE string,
           bkprtfilename TYPE string,
           bk8date1      TYPE string,
           bkaddr        TYPE string,
           bklistno4     TYPE string,
           bktype2       TYPE string,
           bktype3       TYPE string,
           bkoldplatdate TYPE string,
           bkoldseq      TYPE string,
           bkdetail1     TYPE string,
           bkdetail2     TYPE string,
           bkelctsgn1    TYPE string,
         END OF ty_info.

  TYPES: BEGIN OF ty_tx,
           request_sn TYPE string,
           cust_id    TYPE string,
           user_id    TYPE string,
           password   TYPE string,
           tx_code    TYPE string,
           language   TYPE string,
           tx_info    TYPE ty_info,
           sign_info  TYPE string,
         END OF ty_tx.

  DATA: BEGIN OF ls_resp,
          request_sn  TYPE string,
          cust_id     TYPE string,
          tx_code     TYPE string,
          return_code TYPE string,
          return_msg  TYPE string,
          language    TYPE string,
          tx_info     TYPE string,
        END OF ls_resp.


*  DATA ls_tx TYPE ty_tx.
  DATA ls_tx TYPE ty_info.
  DATA:response  TYPE string.
  DATA(lo_xml) = NEW zcl_tr2_xml( ).

*  ls_tx-tx_info = CORRESPONDING #( ls_in ).
*  ls_tx-tx_info-bkelctsgn1 = '01'.
*  ls_tx-tx_info-bktype1 = '0001'.
*  ls_tx-tx_info-bkrole = 'RC01'.
*  if ls_in-BKTYPE2 is INITIAL.
*  ls_tx-tx_info-bktype2 = 'SU01'.
*  endif.

  ls_tx = CORRESPONDING #( ls_in ).
  ls_tx-bkelctsgn1 = '01'.
"  ls_tx-bktype1 = '0001'.
"  ls_tx-bkrole = 'RC01'.
  if ls_in-BKTYPE2 is INITIAL.
  ls_tx-bktype2 = 'SU01'.
  endif.

  CALL FUNCTION 'ZFM_TR2_BANK_SEND'
    EXPORTING
      bank_ind    = 'CCB' "建行
      bank_action = 'AKA' " 0改为AKA 20201015
      data_in     = ls_tx
      method      = 'POST'
      bukrs       = ''
      yhzh        = ''
    IMPORTING
      response    = response.

  "银行返回xml解析
  lo_xml->convert_xml_to_abap( EXPORTING response = response bank_ind = 'CCB' bank_action = 'AKA' IMPORTING data = ls_resp ).

  ls_out-return_code = ls_resp-return_code.
  ls_out-return_msg = ls_resp-return_msg.
  ls_out-request_sn = ls_resp-request_sn.





ENDFUNCTION.
