class ZCL_BANK_CNAPS_CODE definition
  public
  final
  create public .

public section.

  class-methods IF_SAME_BANK
    importing
      !IM_CODE1 type CLIKE
      !IM_CODE2 type CLIKE
    returning
      value(RE_SAME) type FLAG .
  class-methods IF_SAME_CITY
    importing
      !IM_CODE1 type CLIKE
      !IM_CODE2 type CLIKE
    returning
      value(RE_SAME) type FLAG .
  class-methods GET_CITYNAME
    importing
      !IM_CNAPSCODE type CLIKE
    returning
      value(RE_CITYNAME) type ZTR_CITYNAME .
  class-methods CHECK_CODE
    importing
      !IM_BANKL type BNKA-BANKL
    exceptions
      NOT_VALID .
protected section.
private section.
ENDCLASS.



CLASS ZCL_BANK_CNAPS_CODE IMPLEMENTATION.


METHOD check_code.
    DATA: l_rule_string TYPE string.
    DATA: l_valid TYPE flag.
    DATA: l_len TYPE i.
    DATA: l_bankl_string TYPE string.

    IF im_bankl IS INITIAL.
      MESSAGE e345(ztr_bank_application)
              RAISING not_valid.
    ENDIF.

    l_bankl_string = im_bankl.
    CONDENSE l_bankl_string.
    IF strlen( l_bankl_string ) <> 12.
      MESSAGE e347(ztr_bank_application)
              WITH l_bankl_string
              RAISING not_valid.
    ENDIF.

    IF l_bankl_string CN '0123456789'.
      MESSAGE e348(ztr_bank_application)
              WITH l_bankl_string
              RAISING not_valid.
    ENDIF.

    SELECT * INTO TABLE @DATA(lt_rule)
           FROM ztr_cnaps_rule.
    LOOP AT lt_rule INTO DATA(ls_rule).
      l_rule_string = ls_rule-rulecode.
      CONDENSE l_rule_string.
      l_len = strlen( l_rule_string ).

      IF im_bankl+0(l_len) = l_rule_string.
        l_valid = 'X'.
        EXIT.
      ENDIF.
    ENDLOOP.

    IF l_valid = space.
      MESSAGE e346(ztr_bank_application)
             WITH im_bankl
             RAISING not_valid.
    ENDIF.

  ENDMETHOD.


METHOD GET_CITYNAME.
    SELECT SINGLE cityname INTO re_cityname
           FROM ztrt_cnaps_city
           WHERE citycode = im_cnapscode+3(4).
  ENDMETHOD.


METHOD if_same_bank.
*    CNAPS 共十二位，规则如下:
* A XX NNNN  KKKK Z
*    A 代表银行类别，例如大型国有、外资银行等
*    XX 代表行别，例如中国银行、中信银行等
* AXX可以区别是否同一间银行
* NNNN 代表地区城市代码，例如5810代表广州市
* KKKK 代表银行分支机构
* Z 校验码
    IF im_code1+0(3) <> im_code2+0(3).
*      前三位确定一个银行
      re_same = space.
    ELSE.
      re_same = 'X'.
    ENDIF.
  ENDMETHOD.


method IF_SAME_CITY.
*    CNAPS 共十二位，规则如下:
* A XX NNNN  KKKK Z
*    A 代表银行类别，例如大型国有、外资银行等
*    XX 代表行别，例如中国银行、中信银行等
* AXX可以区别是否同一间银行
* NNNN 代表地区城市代码，例如5810代表广州市
* KKKK 代表银行分支机构
* Z 校验码
    IF im_code1+3(4) <> im_code2+3(4).
*      第四到第七位确定地区城市
      re_same = space.
    ELSE.
      re_same = 'X'.
    ENDIF.
  endmethod.
ENDCLASS.
