@AbapCatalog.sqlViewName: 'ZTRCDSAGN'
@AbapCatalog.compiler.compareFilter: true
@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: '周资金计划分配表'
define view ZDDL_AGN
as select from ztrv_amt_agn          
{
mandt,
bukrs,
gjahr,
belnr,
buzei,
zbelnr1,
sqdxh,
billn , 
itemn , 
jjbilln , 
jjitemn ,
sum(wrbtr_agn) as WRBTR_AGN
}
where dflag = ''
  group by bukrs,
           gjahr ,
           belnr ,
           buzei , 
           zbelnr1 ,
sqdxh,
           billn,
           itemn,
           jjbilln ,
           jjitemn
           
 
  
  
  
 