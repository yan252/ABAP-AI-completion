FUNCTION ZFM_TR_ACC_TRAN_TRIGGER_CHKSTA.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     VALUE(IM_T_PAYMORDER_BUFFER) TYPE  ZTRS_PAYMORDER_BUFFER_TAB
*"     VALUE(IM_BANK_INDICATOR) TYPE  ZTR_BANK_INDICATOR
*"--------------------------------------------------------------------
DATA: lt_paymorder_range TYPE ztrt_paymorder_range.

  PERFORM set_payord_to_range
                 USING im_t_paymorder_buffer
               CHANGING lt_paymorder_range.

  zcl_bank_general_query_engine=>query_payment_status(
                    im_t_paymorder_range      = lt_paymorder_range
                    im_trigger_by_acc_tranx   = 'X'
                    im_t_bank_ind_range       = VALUE #( ( sign   = 'I'
                                                           option = 'EQ'
                                                           low    = im_bank_indicator ) ) ).





ENDFUNCTION.
