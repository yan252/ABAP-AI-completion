FUNCTION ZTR_READ.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     VALUE(GCLIENT) LIKE  SEQG3-GCLIENT DEFAULT SY-MANDT
*"     VALUE(GNAME) LIKE  SEQG3-GNAME DEFAULT SPACE
*"     VALUE(GARG) LIKE  SEQG3-GARG DEFAULT SPACE
*"     VALUE(GUNAME) LIKE  SEQG3-GUNAME DEFAULT SY-UNAME
*"     VALUE(OPCODE2) TYPE  SY-CTYPE DEFAULT 1
*"  EXPORTING
*"     VALUE(NUMBER) LIKE  SY-TABIX
*"     VALUE(SUBRC) LIKE  SY-SUBRC
*"  TABLES
*"      ENQ STRUCTURE  SEQG7
*"--------------------------------------------------------------------
***********************************************************************
* internal data declarations
***********************************************************************
DATA: GRANULE LIKE SEQTA.

***********************************************************************
* convert selection parameters
***********************************************************************
  MOVE SPACE TO GRANULE.
  GRANULE-GNAME = GNAME.
  GRANULE-GARG  = GARG.

***********************************************************************
* internal table for storing the selected entries
***********************************************************************
  REFRESH ENQ.
  NUMBER = 0.

  CALL 'C_ENQUEUE' ID 'OPCODE'    FIELD 'Q'
                   ID 'OPCODE2'   FIELD OPCODE2
                   ID 'ENQTABLE'  FIELD ENQ-*SYS*
                   ID 'GRANULE'   FIELD GRANULE
                   ID 'ARG'       FIELD GARG
                   ID 'UNAME'     FIELD GUNAME
                   ID 'CLIENT'    FIELD GCLIENT.

  SUBRC = SY-SUBRC.

  IF SUBRC <> 0.

      CALL 'C_WRITE_SYSLOG_ENTRY'
            ID 'TYP' FIELD 'C'
            ID 'KEY' FIELD 'GEH'.

     EXIT.
  ENDIF.

  describe table enq lines number.





ENDFUNCTION.
