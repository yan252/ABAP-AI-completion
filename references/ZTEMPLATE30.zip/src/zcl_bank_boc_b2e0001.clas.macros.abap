*"* use this source file for any macro definitions you need
*"* in the implementation part of the class
*INCLUDE ztr_bank_message_including.
INCLUDE ztr_bank_boc_response.
