class ZCL_BANK_ENHANCEMENT_SERVICE definition
  public
  final
  create public .

public section.

  class-methods INSERT_LOGON_USER
    importing
      !IM_NAME type EPIC_BC_UD-COMMUSER
      !IM_DESCR type EPIC_BC_UD-DESCR
      !IM_NEW_PWD type RSECDATA
      !IM_REPEAT_PWD type RSECDATA
      !IM_O_LOGON_USER type ref to CL_EPIC_BANK_COMM_LOGON
    exporting
      !EX_ENHANCEMENT_DONE type FLAG
    raising
      CX_EPIC_BANK_COMM_LOGON .
protected section.
private section.

  class-data LOGON_TRANSACTION type SYTCODE value 'ZTR_BANK_LOGON' ##NO_TEXT.
ENDCLASS.



CLASS ZCL_BANK_ENHANCEMENT_SERVICE IMPLEMENTATION.


METHOD insert_logon_user.
    DATA lr_cx_epic_bank_comm_logon TYPE REF TO cx_epic_bank_comm_logon.
    DATA lt_abap_callstack TYPE abap_callstack.
    DATA ls_abap_callstack TYPE LINE OF abap_callstack.
    DATA lv_caller         TYPE syrepid.

    IF sy-tcode <> logon_transaction.
      ex_enhancement_done = space.
      RETURN.
    ELSE.
      SELECT SINGLE pgmna INTO @DATA(l_pgmna)
             FROM tstc
             WHERE tcode = @logon_transaction.
      IF l_pgmna IS NOT INITIAL.
        ex_enhancement_done = 'X'.
      ELSE.
        ex_enhancement_done = space.
        RETURN.
      ENDIF.
    ENDIF.

    CALL FUNCTION 'SYSTEM_CALLSTACK'
      EXPORTING
        max_level = 3
      IMPORTING
        callstack = lt_abap_callstack.

    READ TABLE lt_abap_callstack INTO ls_abap_callstack INDEX 3.
    lv_caller = ls_abap_callstack-mainprogram.

*    IF lv_caller <> 'EPIC_LOGON' . " only for program name EPIC_LOGON
    IF lv_caller <> l_pgmna.
      RAISE EXCEPTION TYPE cx_epic_bank_comm_logon
        EXPORTING
          textid    = cx_epic_bank_comm_logon=>illegal_caller
          mv_caller = lv_caller.
    ENDIF.


    " check authority
    IF  im_o_logon_user->s_has_authority( ) = abap_false.
      RAISE EXCEPTION TYPE cx_epic_bank_comm_logon
        EXPORTING
          textid = cx_epic_bank_comm_logon=>no_authorization.
    ENDIF.

    " check password
    IF im_new_pwd <> im_repeat_pwd.
      RAISE EXCEPTION TYPE cx_epic_bank_comm_logon
        EXPORTING
          textid = cx_epic_bank_comm_logon=>repeat_pwd_wrong.
    ENDIF.


    " first store the data in the secstore if sucessfull store data in the epic table
    TRY . " store password and guid with epic prefix
        im_o_logon_user->zzenhm_insert_user_secstore(
          EXPORTING
            iv_password = im_new_pwd ).
      CATCH cx_epic_bank_comm_logon INTO lr_cx_epic_bank_comm_logon.
        RAISE EXCEPTION TYPE cx_epic_bank_comm_logon
          EXPORTING
            previous = lr_cx_epic_bank_comm_logon.
    ENDTRY.

    " save data in epic table: EPIC_BC_UD
    im_o_logon_user->zzenhm_insert_user_definition(
        iv_new_name  = im_name
        iv_new_descr = im_descr ).

    COMMIT WORK.
  ENDMETHOD.
ENDCLASS.
