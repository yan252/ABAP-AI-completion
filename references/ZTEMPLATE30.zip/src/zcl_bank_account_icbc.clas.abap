class ZCL_BANK_ACCOUNT_ICBC definition
  public
  inheriting from ZCL_ABSTRACT_BANK_ACCOUNT
  final
  create public .

public section.
protected section.

  methods BANK_BALANCE_TO_SAP
    redefinition .
  methods BANK_TRANSACTIONS_TO_SAP
    redefinition .
  methods DEQUEUE_TRANSACTION
    redefinition .
  methods SET_ACCOUNT_BALANCE_CORE
    redefinition .
  methods SET_ACCOUNT_TABNAME
    redefinition .
  methods SET_HISTORY_ACC_BAL_CORE
    redefinition .
  methods SET_TRANSACTIONS_CORE
    redefinition .
  methods BANK_HISTORY_BALANCE_TO_SAP
    redefinition .
private section.

  methods CALCULATE_BALANCE_IN_TRANX
    importing
      !IM_DATA type ref to DATA
    returning
      value(RT_DATA) type ZTRT_ICBC_TRNS_TAB .
ENDCLASS.



CLASS ZCL_BANK_ACCOUNT_ICBC IMPLEMENTATION.


METHOD bank_balance_to_sap.
    FIELD-SYMBOLS: <ft_new_account_balance> TYPE STANDARD TABLE.
    DATA: ls_balance_ext TYPE ztrt_icbc_acbal.
    DATA: l_balance     TYPE ztr_icbc_usablebalance,
          l_balance_frz TYPE ztr_icbc_frzamt,
          l_balance_ttl TYPE ztrt_icbc_acbal-balance.


    ASSIGN new_account_balance->* TO <ft_new_account_balance>.
    IF <ft_new_account_balance> IS NOT ASSIGNED OR
       <ft_new_account_balance> IS INITIAL.
      RETURN.
    ENDIF.

    LOOP AT <ft_new_account_balance> INTO ls_balance_ext.
*      工商银行金额最小单位是分
      l_balance = ls_balance_ext-usablebalance / 100.
      l_balance_frz = ls_balance_ext-frzamt / 100.
      l_balance_ttl = ls_balance_ext-balance / 100.
      APPEND VALUE #(
                       bukrs        = ls_balance_ext-sap_bukrs
                       hbkid        = ls_balance_ext-sap_hbkid
                       hktid        = ls_balance_ext-sap_hktid
                       yhzh         = ls_balance_ext-accno
                       bank_ind     = bank_indicator
                       ZYUE_TTL     = l_balance_ttl
                       ZYUE_FRZ     = l_balance_frz
                       zyue         = l_balance
                       waers        = GET_ACCOUNT_CURRENCY( ls_balance_ext-sap_fields )
                       ) TO rt_balance.

    ENDLOOP.
  ENDMETHOD.


METHOD bank_history_balance_to_sap.
    FIELD-SYMBOLS: <ft_new_account_balance> TYPE STANDARD TABLE.
    DATA: ls_balance_ext TYPE ztrt_icbc_hacbal.
    DATA: l_balance_ttl TYPE ztrt_icbc_hacbal-amount.


    ASSIGN new_history_account_balance->* TO <ft_new_account_balance>.
    IF <ft_new_account_balance> IS NOT ASSIGNED OR
       <ft_new_account_balance> IS INITIAL.
      RETURN.
    ENDIF.

    LOOP AT <ft_new_account_balance> INTO ls_balance_ext.
*      工商银行金额最小单位是分
      l_balance_ttl = ls_balance_ext-amount / 100.
      APPEND VALUE #(
                       bukrs        = ls_balance_ext-sap_bukrs
                       hbkid        = ls_balance_ext-sap_hbkid
                       hktid        = ls_balance_ext-sap_hktid
                       yhzh         = ls_balance_ext-accno
                       bank_ind     = bank_indicator
                       zdate        = ls_balance_ext-zdate+0(4) &&
                                      ls_balance_ext-zdate+5(2) &&
                                      ls_balance_ext-zdate+8(2)
                       zyue_ttl       = l_balance_ttl
                       waers        = get_account_currency( ls_balance_ext-sap_fields )
                       ) TO rt_balance.

    ENDLOOP.
  ENDMETHOD.


METHOD bank_transactions_to_sap.
    FIELD-SYMBOLS: <ft_new_transactions> TYPE STANDARD TABLE.
    DATA: ls_transactions_ext TYPE ztrt_icbc_trns.
    DATA: l_amount TYPE ztr_bank_trxamt.
    DATA: l_balance TYPE ztr_icbc_trns_balance.

    ASSIGN new_transactions->* TO <ft_new_transactions>.
    IF <ft_new_transactions> IS NOT ASSIGNED OR
       <ft_new_transactions> IS INITIAL.
      RETURN.
    ENDIF.

    LOOP AT <ft_new_transactions> INTO ls_transactions_ext.
      DATA(l_shkzg) = zcl_icbc_enhancement=>convert_debit_and_credit_flag( ls_transactions_ext-drcrf ).
      DATA(ls_paymentkey) = get_paymkey_from_transaction( ls_transactions_ext-postscript ).

      CASE ls_transactions_ext-drcrf.
        WHEN '1'.
          l_amount = ls_transactions_ext-debitamount.
        WHEN '2'.
          l_amount = ls_transactions_ext-creditamount.
        WHEN OTHERS.
          CLEAR l_amount.
      ENDCASE.
**   要考虑银行红冲******2020.2.25
      IF ls_transactions_ext-updtranf = '3'.
        l_amount = - l_amount.
        IF  l_shkzg = 'H'.
          l_shkzg = 'S'.
        ELSE.
          l_shkzg = 'H'.
        ENDIF.
      ENDIF.
**   要考虑银行红冲******2020.2.25
***      工商银行金额最小单位是分
      l_amount = l_amount / 100.
      l_balance = ls_transactions_ext-balance / 100.

*-----Begin 对方名称中的全角和半角括号去除后存入字段BKOINH1中 金志强 Add by KLTDEV5 20190726
      "字符串转换
      DATA:lv_bkoinh TYPE string.
      lv_bkoinh = ls_transactions_ext-recipname.
      lv_bkoinh = convert_string( EXPORTING string = lv_bkoinh char = '(' ).
      lv_bkoinh = convert_string( EXPORTING string = lv_bkoinh char = ')' ).
      lv_bkoinh = convert_string( EXPORTING string = lv_bkoinh char = '（' ).
      lv_bkoinh = convert_string( EXPORTING string = lv_bkoinh char = '）' ).
*-----End 对方名称中的全角和半角括号去除后存入字段BKOINH1中 金志强 Add by KLTDEV5 20190726

      APPEND VALUE #(
                       bukrs        = ls_transactions_ext-sap_bukrs
                       hbkid        = ls_transactions_ext-sap_hbkid
                       hktid        = ls_transactions_ext-sap_hktid
                       yhzh         = ls_transactions_ext-accno
                       trxno        = ls_transactions_ext-onlysequence
                       bank_ind     = bank_indicator
                       trxdate      = ls_transactions_ext-busidate+0(4) &&
                                      ls_transactions_ext-busidate+5(2) &&
                                      ls_transactions_ext-busidate+8(2)
                       trxtime      = ls_transactions_ext-busitime+0(2) &&
                                      ls_transactions_ext-busitime+3(2) &&
                                      ls_transactions_ext-busitime+6(2)
                       shkzg        = l_shkzg
                       bkfse       = l_amount
                       trxamt        = convert_transamt_by_shkzg( im_shkzg = l_shkzg
                                                                 im_original_amt = l_amount )

*                       balamt       = CONV ztr_bank_balamt( ls_transactions_ext-balance )
                       balamt       = CONV ztr_bank_balamt( l_balance )
                       waers        = ls_transactions_ext-sap_waers
*                           对方开户行名称
                       bzbnka       = ls_transactions_ext-recipbkname1
*                           对方帐号
                       bzbnkn       = ls_transactions_ext-recipaccno
*                           对方账户名
                       bkoinh       = ls_transactions_ext-recipname
*                           附言
                       postscript_txt = ls_transactions_ext-postscript
*                           用途
                       usage_txt      = ls_transactions_ext-usecn
*                           摘要
                       abstract_txt = ls_transactions_ext-summary
*                           备注
                       comment_txt  = ls_transactions_ext-remark
                       paymentkey  = ls_paymentkey
                       zref_doc = ls_paymentkey-paymorder
                       intfdate     = system_info-datum
                       intftime     = system_info-uzeit
*                       kunnr2       = set_customer_code_by_name( ls_transactions_ext-recipname )
*                       lifnr        = set_vendor_code_by_name( ls_transactions_ext-recipname )
                       partner = set_partner_by_name( ls_transactions_ext-recipname  )
                       bkoinh1 = lv_bkoinh
                       ) TO rt_transactions.
      CLEAR ls_paymentkey.
    ENDLOOP.

    finished_sap_tranx_fields(
               CHANGING
                 ch_t_tranx = rt_transactions ).

  ENDMETHOD.


METHOD calculate_balance_in_tranx.
    FIELD-SYMBOLS: <ft_transactions> TYPE ztrt_icbc_trns_tab.
    data: l_last_date type sydatum.
*    data:l_last_date_db type ztrt_icbc_hacbal-zdate.

    ASSIGN im_data->* TO <ft_transactions>.

    IF <ft_transactions> IS NOT ASSIGNED OR
       <ft_transactions> IS INITIAL.
      RETURN.
    ENDIF.

    rt_data = <ft_transactions>.

    SORT rt_data BY accno
                    busidate
                    busitime.

    l_last_date = sy-datum - 1.
    DATA(l_last_date_db) = l_last_date+0(4) && '-' &&
                           l_last_date+4(2) && '-' &&
                           l_last_date+6(2).
    DATA(l_current_date_db) = sy-datum+0(4) && '-' &&
                              sy-datum+4(2) && '-' &&
                              sy-datum+6(2).

    SELECT accno,
           zdate,
           amount
           INTO TABLE @DATA(lt_current_balance)
           FROM ztrt_icbc_hacbal
           FOR ALL ENTRIES IN @rt_data
           WHERE accno = @rt_data-accno
           AND   zdate = @l_last_date_db.

    SORT lt_current_balance BY accno
                                 zdate.
    DELETE ADJACENT DUPLICATES FROM lt_current_balance
                   COMPARING accno
                             zdate.

    LOOP AT lt_current_balance ASSIGNING FIELD-SYMBOL(<fs_current_balance>).
*  将账户的余额日期设置为当前日期，视为当前余额
      <fs_current_balance>-zdate = l_current_date_db.
    ENDLOOP.

    LOOP AT rt_data ASSIGNING FIELD-SYMBOL(<fs_icbc_transaction>)
         WHERE busidate = l_current_date_db.
      READ TABLE lt_current_balance  ASSIGNING <fs_current_balance>
           WITH KEY accno = <fs_icbc_transaction>-accno
                    zdate = <fs_icbc_transaction>-busidate.
      IF sy-subrc = 0.
        CASE <fs_icbc_transaction>-drcrf.
          WHEN '1'.
*            转出
            <fs_icbc_transaction>-balance = <fs_current_balance>-amount - <fs_icbc_transaction>-debitamount.
          WHEN '2'.
*            转入
            <fs_icbc_transaction>-balance = <fs_current_balance>-amount + <fs_icbc_transaction>-creditamount.
        ENDCASE.
*当前余额
        <fs_current_balance>-amount = <fs_icbc_transaction>-balance.

      ENDIF.
    ENDLOOP.
  ENDMETHOD.


METHOD dequeue_transaction.
    DATA:ls_transaction TYPE ztrt_icbc_trns.

    LOOP AT im_t_transactions INTO ls_transaction.
      dequeue_transaction_core(
                     im_bukrs = ls_transaction-sap_bukrs
                     im_hbkid = ls_transaction-sap_hbkid
                     im_hktid = ls_transaction-sap_hktid
                     im_yhzh = ls_transaction-accno
                     im_trxno = ls_transaction-onlysequence ).
    ENDLOOP.

  ENDMETHOD.


METHOD set_account_balance_core.
    FIELD-SYMBOLS: <ft_acc_balance> TYPE ztrt_icbc_acbal_tab.
    FIELD-SYMBOLS:<ft_new_entries> TYPE ztrt_icbc_acbal_tab.
    DATA: l_new     TYPE flag,
          l_changed TYPE flag.

    ASSIGN im_data->* TO <ft_acc_balance>.

    ASSIGN new_account_balance->* TO <ft_new_entries>.

    IF <ft_acc_balance> IS INITIAL.
      RETURN.
    ENDIF.

    SELECT * INTO TABLE @DATA(lt_old_data)
           FROM ztrt_icbc_acbal
           FOR ALL ENTRIES IN @<ft_acc_balance>
           WHERE accno = @<ft_acc_balance>-accno.

    LOOP AT <ft_acc_balance> INTO DATA(ls_acc_balance).
      CHECK filter_accbal_by_shifton_date(
                  EXPORTING
                    im_s_sap_field = ls_acc_balance-sap_fields ) = 'X'.

      enqueue_balance_core(
                 EXPORTING
                   im_bukrs = ls_acc_balance-sap_bukrs
                   im_hbkid = ls_acc_balance-sap_hbkid
                   im_hktid = ls_acc_balance-sap_hktid
                 IMPORTING
                   ex_enqueue_failed = DATA(l_enqueue_failed) ).
      IF l_enqueue_failed = yes.
*        被锁定，不纳入本次处理
        CLEAR l_enqueue_failed.
        CONTINUE.
      ENDIF.

      READ TABLE lt_old_data INTO DATA(ls_old_data)
           WITH KEY accno = ls_acc_balance-accno.
      IF sy-subrc <> 0.
*      new
        l_new = 'X'.
      ELSE.
        IF ls_acc_balance-acc_field <> ls_old_data-acc_field.
          l_changed = 'X'.
        ENDIF.
      ENDIF.

      IF l_new = 'X' OR
         l_changed = 'X'.
        ls_acc_balance-dbadmin = ls_old_data-dbadmin.
        set_admin_fields(
                  EXPORTING
                    im_new_entry = l_new
                  CHANGING
                    cs_admin = ls_acc_balance-dbadmin ).
        APPEND ls_acc_balance TO <ft_new_entries>.
      ELSE.
        dequeue_balance_core(
                   EXPORTING
                     im_bukrs = ls_acc_balance-sap_bukrs
                     im_hbkid = ls_acc_balance-sap_hbkid
                     im_hktid = ls_acc_balance-sap_hktid ).
      ENDIF.

      CLEAR: l_new,
             l_changed.
    ENDLOOP.

  ENDMETHOD.


METHOD set_account_tabname.
    transaction_db_tabname = 'ZTRT_ICBC_TRNS'.
    account_balance_db_tabname = 'ZTRT_ICBC_ACBAL'.
    history_acc_balance_db_name = 'ZTRT_ICBC_HACBAL'.
    super->set_account_tabname( ).
  ENDMETHOD.


method SET_HISTORY_ACC_BAL_CORE.
  FIELD-SYMBOLS: <ft_acc_balance> TYPE ztrt_icbc_hacbal_tab.
    FIELD-SYMBOLS:<ft_new_entries> TYPE ztrt_icbc_hacbal_tab.
    DATA: l_new     TYPE flag,
          l_changed TYPE flag.

    ASSIGN im_data->* TO <ft_acc_balance>.

    ASSIGN NEW_HISTORY_ACCOUNT_BALANCE->* TO <ft_new_entries>.

    IF <ft_acc_balance> IS INITIAL.
      RETURN.
    ENDIF.

    SELECT * INTO TABLE @DATA(lt_old_data)
           FROM ztrt_icbc_hacbal
           FOR ALL ENTRIES IN @<ft_acc_balance>
           WHERE accno = @<ft_acc_balance>-accno
           and   zdate = @<ft_acc_balance>-zdate.

    LOOP AT <ft_acc_balance> INTO DATA(ls_acc_balance).
      CHECK filter_accbal_by_shifton_date(
                  EXPORTING
                    im_s_sap_field = ls_acc_balance-sap_fields
                    im_date = ls_acc_balance-zdate+0(4) &&
                              ls_acc_balance-zdate+5(2) &&
                              ls_acc_balance-zdate+8(2) ) = 'X'.

      READ TABLE lt_old_data INTO DATA(ls_old_data)
           WITH KEY accno = ls_acc_balance-accno
                    zdate = ls_acc_balance-zdate.
      IF sy-subrc <> 0.
*      new
        l_new = 'X'.
      ELSE.
        IF ls_acc_balance-acc_field <> ls_old_data-acc_field.
          l_changed = 'X'.
        ENDIF.
      ENDIF.

      IF l_new = 'X' OR
         l_changed = 'X'.
        ls_acc_balance-dbadmin = ls_old_data-dbadmin.
        set_admin_fields(
                  EXPORTING
                    im_new_entry = l_new
                  CHANGING
                    cs_admin = ls_acc_balance-dbadmin ).
        APPEND ls_acc_balance TO <ft_new_entries>.
      ENDIF.

      CLEAR: l_new,
             l_changed.
    ENDLOOP.
  endmethod.


METHOD set_transactions_core.
*    FIELD-SYMBOLS: <ft_transactions> TYPE ztrt_icbc_trns_tab.
    FIELD-SYMBOLS: <ft_new_entries> TYPE ztrt_icbc_trns_tab.
    DATA: l_new     TYPE flag,
          l_changed TYPE flag.

*    ASSIGN im_data->* TO <ft_transactions>.

    ASSIGN new_transactions->* TO <ft_new_entries>.

*    IF <ft_transactions> IS NOT ASSIGNED OR
*       <ft_transactions> IS INITIAL.
*      RETURN.
*    ENDIF.

    DATA(lt_icbc_trns) = calculate_balance_in_tranx( im_data ).
    IF lt_icbc_trns IS INITIAL.
      RETURN.
    ENDIF.

    SELECT * INTO TABLE @DATA(lt_old_data)
           FROM ztrt_icbc_trns
           FOR ALL ENTRIES IN @lt_icbc_trns
           WHERE accno = @lt_icbc_trns-accno
           AND   onlysequence = @lt_icbc_trns-onlysequence.

    LOOP AT lt_icbc_trns INTO DATA(ls_transactions).
      CHECK filter_trans_by_shifton_date(
                  EXPORTING
                    im_s_sap_field = ls_transactions-sap_fields
                    im_transaction_date = ls_transactions-busidate+0(4) &&
                                          ls_transactions-busidate+5(2) &&
                                          ls_transactions-busidate+8(2) ) = 'X'.

      enqueue_transaction_core(
                   EXPORTING
                     im_bukrs = ls_transactions-sap_bukrs
                     im_hbkid = ls_transactions-sap_hbkid
                     im_hktid = ls_transactions-sap_hktid
                     im_yhzh = ls_transactions-accno
                     im_trxno = ls_transactions-onlysequence
                   IMPORTING
                     ex_enqueue_failed = DATA(l_enqueue_failed) ).
      IF l_enqueue_failed = yes.
*        被锁定，不纳入本次处理
        CLEAR l_enqueue_failed.
        CONTINUE.
      ENDIF.


      READ TABLE lt_old_data INTO DATA(ls_old_data)
           WITH KEY accno = ls_transactions-accno
                    onlysequence = ls_transactions-onlysequence.
      IF sy-subrc <> 0.
*      new
        l_new = 'X'.
      ELSE.
        IF ls_transactions-trns_field <> ls_old_data-trns_field.
          l_changed = 'X'.
        ENDIF.
      ENDIF.

      IF l_new = 'X' OR
         l_changed = 'X'.
        ls_transactions-dbadmin = ls_old_data-dbadmin.
        set_admin_fields(
                  EXPORTING
                    im_new_entry = l_new
                  CHANGING
                    cs_admin = ls_transactions-dbadmin ).
        APPEND ls_transactions TO <ft_new_entries>.
      ELSE.
        dequeue_transaction_core(
                     EXPORTING
                       im_bukrs = ls_transactions-sap_bukrs
                       im_hbkid = ls_transactions-sap_hbkid
                       im_hktid = ls_transactions-sap_hktid
                       im_yhzh = ls_transactions-accno
                       im_trxno = ls_transactions-onlysequence ).
      ENDIF.

      CLEAR: l_new,
             l_changed,
             ls_old_data.
    ENDLOOP.

  ENDMETHOD.
ENDCLASS.
