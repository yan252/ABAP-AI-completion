FUNCTION ZFM_TR_ABC_ST_PROV.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     VALUE(I_TREE_TYPE) TYPE  DMEE_TREETYPE_ABA
*"     VALUE(I_TREE_ID) TYPE  DMEE_TREEID_ABA
*"     VALUE(I_ITEM)
*"     VALUE(I_PARAM)
*"     VALUE(I_UPARAM)
*"  EXPORTING
*"     REFERENCE(O_VALUE)
*"     REFERENCE(C_VALUE)
*"     REFERENCE(N_VALUE)
*"     REFERENCE(P_VALUE)
*"  TABLES
*"      I_TAB
*"--------------------------------------------------------------------
FIELD-SYMBOLS <ZTST> TYPE ZTRS_PAYM_STATUS_LIST.

  ASSIGN COMPONENT 'ZTRS_PAYM_STATUS_LIST' OF STRUCTURE i_item TO <ZTST>.
  DATA(craccno) =  <ZTST>-BNKN1.

  CONDENSE craccno NO-GAPS.
  DATA(LT) = STRLEN( craccno ).

  IF LT = 17.
    c_value = craccno+0(2).
*    accno1 = an+2(15).
*  ELSE.
*    accno1 = an.
  ENDIF.




*  DATA:ac(132) TYPE c.
*  ac = craccno.
*  zcl_abc_enhancement=>get_accno_prov( EXPORTING
*    accno = ac
*  IMPORTING
*    prov = c_value  ).





ENDFUNCTION.
