FUNCTION ZFM_TR_ABC_ST_ACCNO.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     VALUE(I_TREE_TYPE) TYPE  DMEE_TREETYPE_ABA
*"     VALUE(I_TREE_ID) TYPE  DMEE_TREEID_ABA
*"     VALUE(I_ITEM)
*"     VALUE(I_PARAM)
*"     VALUE(I_UPARAM)
*"  EXPORTING
*"     REFERENCE(O_VALUE)
*"     REFERENCE(C_VALUE)
*"     REFERENCE(N_VALUE)
*"     REFERENCE(P_VALUE)
*"  TABLES
*"      I_TAB
*"--------------------------------------------------------------------
FIELD-SYMBOLS <ztst> TYPE ztrs_paym_status_list.

  ASSIGN COMPONENT 'ZTRS_PAYM_STATUS_LIST' OF STRUCTURE i_item TO <ztst>.
  DATA(craccno) =  <ztst>-bnkn1.


  CONDENSE craccno NO-GAPS.
  DATA(lt) = strlen( craccno ).

  IF lt = 17.

    c_value = craccno+2(15).
  ELSE.
    c_value = craccno.
  ENDIF.





ENDFUNCTION.
