class ZCL_ICBC_ENHANCEMENT definition
  public
  final
  create public .

public section.

  class-methods SET_CIS
    returning
      value(RE_CIS) type STRING .
  class-methods SET_ID
    returning
      value(RE_ID) type EPIC_BC_USER .
  class-methods SET_TRANDATE
    importing
      !IM_DOC1R type CLIKE
    returning
      value(RE_DATE) type CHAR08 .
  class-methods SET_SIGNTIME
    importing
      !IM_DOC1R type CLIKE
    returning
      value(RE_TIME) type CHAR17 .
  class-methods SET_TRANTIME
    importing
      !IM_DOC1R type CLIKE
    returning
      value(RE_TIME) type CHAR9 .
  class-methods SET_SYSIOFLG
    importing
      !IM_S_FPAYH type FPAYH
    returning
      value(RE_VALUE) type CHAR01 .
  class-methods SET_ISSAMECITY
    importing
      !IM_S_FPAYH type FPAYH
    returning
      value(RE_VALUE) type CHAR01 .
  class-methods SET_POSTSCRIPT
    importing
      !IM_DOC1R type CLIKE
    returning
      value(RE_VALUE) type CHAR060 .
  class-methods SET_ERPSQN
    importing
      !IM_DOC1R type CLIKE
    returning
      value(RE_VALUE) type CHAR20 .
  class-methods BUILD_POST_FILE_PREFIX
    importing
      !IM_TRANSACTIONCODE type CLIKE
      !IM_PACKAGE_ID type CLIKE
      !IM_FILE_VERSION type CLIKE
      !IM_BANK_CODE type CLIKE
    returning
      value(RE_VALUE) type STRING .
  class-methods SET_BANK_DATE
    returning
      value(RE_DATE) type DATUM .
  class-methods GENERATE_PACKAGE_ID
    returning
      value(RE_PACKAGE_ID) type STRING .
  class-methods GET_PACKAGEID_FROM_SENDING_XML
    importing
      !IM_XML_STRING type STRING
      !IM_XML_XSTRING type XSTRING optional
    returning
      value(RE_PACKAGE_ID) type STRING .
  class-methods CONVERT_DEBIT_AND_CREDIT_FLAG
    importing
      !IM_DRCRF type ZTR_ICBC_DRCRF
    returning
      value(RE_SAP_VALUE) type SHKZG .
  class-methods SET_RECCITYNAME
    importing
      !IM_S_FPAYH type FPAYH
    returning
      value(RE_VALUE) type ZTR_CITYNAME .
protected section.
private section.
ENDCLASS.



CLASS ZCL_ICBC_ENHANCEMENT IMPLEMENTATION.


METHOD build_post_file_prefix.
    re_value = 'Version=' && im_file_version &&         "报文文件版本
               '&TransCode=' && im_transactioncode &&  "交易代码,相当于银行功能，例如APYENT
               '&BankCode=' && im_bank_code && "客户的归属单位，银行代码，都是102
               '&GroupCIS=' && set_cis( ) && "企业在银行的客户编码
               '&ID=' && set_id( ) && "客户的证书ID
               '&PackageID=' && im_package_id && "客户的指令包序列号
               '&Cert=' && "客户的证书公钥信息（进行BASE64编码；NC客户送空) - 金东为NC模式
               '&reqData='. "签名后的客户请求数据，(需要URLEncode，判断方法是查看发送数据中是否有“+”，如果存在说明没有做URLEncode.
    "由调用方补充&reqData=后面的信息信息
  ENDMETHOD.


method CONVERT_DEBIT_AND_CREDIT_FLAG.
    CASE IM_DRCRF.
      WHEN '1'.
*        借
        re_sap_value = 'H'.
      WHEN '2'.
*        贷
        re_sap_value = 'S'.
    ENDCASE.
  endmethod.


METHOD generate_package_id.
    DATA(ls_sequence) = zcl_bank_abstract_action=>get_action(
                                       )->get_bank( 'ICBC'
                                              )->get_enviroment( )->generate_date_sequence( ).
    re_package_id = ls_sequence-seqdate &&
                    ls_sequence-dateseq.
  ENDMETHOD.


METHOD get_packageid_from_sending_xml.
    DATA: l_leading_string TYPE string,
          l_real_string    TYPE string,
          l_real_xstring   TYPE xstring.

    SPLIT im_xml_string AT zif_icbc_constant=>xml_okay_prefix_code INTO l_leading_string l_real_string.
*    IF l_real_string IS INITIAL.
**      有可能调用之前还没组合reqData
*      l_real_xstring = l_leading_string.
*    ELSE.
*      l_real_xstring = l_real_string.
*    ENDIF.

    IF l_real_string IS INITIAL.
*  IM_XML_STRING目前还没组合成reqData的格式
      l_real_string = l_leading_string.
    ENDIF.

    IF l_real_string IS INITIAL.
      RETURN.
    ENDIF.

    l_real_string = cl_http_utility=>unescape_url( l_real_string ).

    FIND zif_icbc_constant=>xml_uppest_element_suffix IN l_real_string.
    IF sy-subrc = 0.
*     l_real_string目前还是一个XML
      CLEAR l_real_xstring.
    ELSE.
*      real string本身就是十六进制的了
      l_real_xstring = l_real_string.
      CLEAR l_real_string.
    ENDIF.

    IF l_real_xstring IS NOT INITIAL.
      cl_abap_conv_in_ce=>create( input = l_real_xstring )->read(
                                                 EXPORTING
                                                   n = xstrlen( l_real_xstring )
                                                 IMPORTING
                                                   data = l_real_string ).
    ENDIF.

    zcl_bank_data_mapping_engine=>get_element_value(
                                     EXPORTING
                                        im_xml_string = l_real_string
                                        im_xml_xstring = l_real_xstring
                                        im_t_fieldname = VALUE #( ( name = zif_icbc_constant=>fseqno_element_name ) )
                                     IMPORTING
                                       ex_t_element_values = DATA(lt_element_values) ).
    IF lt_element_values IS NOT INITIAL.
      re_package_id = lt_element_values[ 1 ]-data.
    ENDIF.
  ENDMETHOD.


METHOD set_bank_date.
**************************
*    工商银行测试系统的日期和自然日期不一致，
*    在测试过程中每隔一段时间都需要向工行技术人员
*    索取工行测试系统的日期，然后维护在ztrt_bank_date中
*    对于生产系统不需要维护这个表

*    如果在测试阶段发现D0087-企业签名时间与工行服务器时间间隔过长!的反馈消息
*    说明当前在ztrt_bank_date维护人日期过期了，请向工行技术人员重新索取最新日期然后维护这个表
**************************
    SELECT SINGLE bank_date INTO re_date
           FROM ztrt_bank_date
           WHERE bank_ind = 'ICBC'.
  ENDMETHOD.


METHOD set_cis.
    SELECT SINGLE * INTO @DATA(ls_bank_assignment)
          FROM ztrt_bank_ass
          WHERE bank_ind = 'ICBC'.
    IF sy-subrc <> 0.
*      the error should be remove by testing phase
      RETURN.
    ENDIF.

    SELECT COUNT( * ) INTO @DATA(l_count)
           FROM epic_bc_ud
           WHERE guid = @ls_bank_assignment-guid.
    IF l_count < 1.
*      the error should be remove by testing phase
      RETURN.
    ENDIF.

    re_cis = ls_bank_assignment-custid.

  ENDMETHOD.


METHOD set_erpsqn.
    SELECT SINGLE paymorder
           INTO re_value
           FROM ztrt_payment
           WHERE doc1r = im_doc1r.
  ENDMETHOD.


METHOD set_id.
    CALL FUNCTION 'ZFM_TR_BANK_LOGON_USER'
      EXPORTING
        im_bank_indicator = 'ICBC'
      IMPORTING
        ex_user           = re_id.
  ENDMETHOD.


method SET_ISSAMECITY.
      IF zcl_bank_cnaps_code=>if_same_city(
                                    EXPORTING
                                      im_code1 = im_s_fpayh-zbnky
                                      im_code2 = im_s_fpayh-bnkl1 ) = 'X'.
        re_value = '1'. "同城”
      ELSE.
        re_value = '2'." 异地
      ENDIF.
  endmethod.


METHOD SET_POSTSCRIPT.
    SELECT SINGLE paymorder
           INTO @data(l_order)
           FROM ztrt_payment
           WHERE doc1r = @im_doc1r.

   CONCATENATE zcl_bank_payment_entry=>transaction_reference_prefix "'APPTRATIONREFERENCE'
              l_order
              INTO re_value.

  ENDMETHOD.


METHOD set_reccityname.
    IF zcl_bank_cnaps_code=>if_same_bank(
                              EXPORTING
                                im_code1 = im_s_fpayh-zbnky
                                im_code2 = im_s_fpayh-bnkl1 ) = space.
*      只有同行才需要输入城市名称
      re_value = zcl_bank_cnaps_code=>get_cityname( im_s_fpayh-zbnky ).
    ENDIF.
  ENDMETHOD.


METHOD set_signtime.
    DATA: l_timestamp TYPE ztrt_dseq-update_timestamp.
    DATA: l_diff         TYPE p DECIMALS 6,
          l_milliseconds TYPE c LENGTH 3.

    SELECT SINGLE * INTO @DATA(ls_seq)
            FROM ztrt_dseq
            WHERE doc1r = @im_doc1r.
    IF sy-subrc = 0.
      CONVERT TIME STAMP ls_seq-update_timestamp
              TIME ZONE ls_seq-update_timezone
              INTO DATE DATA(l_date)
                   TIME DATA(l_time).
      CONVERT DATE l_date
              TIME l_time
              INTO TIME STAMP l_timestamp
              TIME ZONE ls_seq-update_timezone.

      l_milliseconds = ( ls_seq-update_timestamp - l_timestamp ) * 1000.
    ENDIF.

*    IF sy-mandt = '130' OR
*       sy-mandt = '150' or
*       sy-mandt = '310' or
*       sy-mandt = '300'.
*      l_date = set_bank_date( ).
*    ENDIF.
    DATA(l_icbc_testing_system_date) = set_bank_date( ).
    IF l_icbc_testing_system_date IS NOT INITIAL.
*      用工行测试系统的日期取代当前发送日期
*      如果不是生产系统，不要维护ztrt_bank_date，
*      那么这个代码就不生效
      l_date = l_icbc_testing_system_date.
    ENDIF.




    re_time = l_date && l_time && l_milliseconds.

  ENDMETHOD.


method SET_SYSIOFLG.
    IF zcl_bank_cnaps_code=>if_same_bank(
                              EXPORTING
                                im_code1 = im_s_fpayh-zbnky
                                im_code2 = im_s_fpayh-bnkl1 ) = 'X'.
      re_value = '1'. "系统内-同行
    ELSE.
      re_value = '2'. "系统外-他行
    ENDIF.
  endmethod.


METHOD set_trandate.
    SELECT SINGLE * INTO @DATA(ls_seq)
            FROM ztrt_dseq
            WHERE doc1r = @im_doc1r.
    IF sy-subrc = 0.
      CONVERT TIME STAMP ls_seq-update_timestamp
              TIME ZONE ls_seq-update_timezone
              INTO DATE DATA(l_date).
      re_date = l_date.
    ENDIF.

*    IF sy-mandt = '130' OR
*       sy-mandt = '150'.
*      re_date = CONV #( set_bank_date( ) ).
*    ENDIF.
  ENDMETHOD.


METHOD set_trantime.
    DATA: l_timestamp TYPE ztrt_dseq-update_timestamp.
    DATA: l_diff         TYPE p DECIMALS 6,
          l_milliseconds TYPE c LENGTH 3.
    SELECT SINGLE * INTO @DATA(ls_seq)
            FROM ztrt_dseq
            WHERE doc1r = @im_doc1r.
    IF sy-subrc = 0.
      CONVERT TIME STAMP ls_seq-update_timestamp
              TIME ZONE ls_seq-update_timezone
              INTO DATE DATA(l_date)
                   TIME DATA(l_time).
      CONVERT DATE l_date
              TIME l_time
              INTO TIME STAMP l_timestamp
              TIME ZONE ls_seq-update_timezone.

      l_milliseconds = ( ls_seq-update_timestamp - l_timestamp ) * 1000.
    ENDIF.

    re_time = l_time && l_milliseconds.

  ENDMETHOD.
ENDCLASS.
