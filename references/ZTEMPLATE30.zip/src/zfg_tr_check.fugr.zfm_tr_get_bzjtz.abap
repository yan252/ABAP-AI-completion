FUNCTION ZFM_TR_GET_BZJTZ.
**"--------------------------------------------------------------------
**"*"局部接口：
**"  IMPORTING
**"     REFERENCE(DOCNO) TYPE  ZTR_SJDOCNO OPTIONAL
**"     REFERENCE(ZJYDATE) TYPE  ZTR_JYDATE OPTIONAL
**"     REFERENCE(BZJ_TZ) TYPE  ZTR_BZJ_TZ OPTIONAL
**"  EXPORTING
**"     VALUE(SK) TYPE  ZTRT2002
**"  TABLES
**"      ITEM STRUCTURE  ZTR_S_BZJINFO
**"--------------------------------------------------------------------
*IF docno IS INITIAL AND bzj_tz IS INITIAL.
*    RETURN.
*  ENDIF.
*  DATA lt_tz TYPE STANDARD TABLE OF ztrt2199.
*  IF docno IS NOT INITIAL.
*    SELECT *
*       INTO TABLE @lt_tz
*       FROM ztrt2199
*       WHERE docno = @docno.
*
*    "外汇保证台账取最新的一条
*    SELECT SINGLE zzftype INTO @DATA(lv_whbzj) FROM ztrt2101 WHERE docno = @docno.
*  ELSE.
*    SELECT *
*      INTO TABLE @lt_tz
*      FROM ztrt2199
*      WHERE bzj_tz = @bzj_tz.
*
*    SELECT SINGLE aptype
*      INTO @DATA(lv_aptype)
*      FROM ztrt0061_head AS a
*      INNER JOIN ztrt0061_item AS b ON a~docno = b~docno
*      WHERE b~bzj_tzdh = @bzj_tz.
*
*    SELECT SINGLE zzftype INTO  lv_whbzj
*        FROM ztrt2199 AS a INNER JOIN ztrt2101 AS b ON a~docno = b~docno AND a~bukrs = b~bukrs
*       WHERE  bzj_tz =  bzj_tz..
*
*  ENDIF.
*
*  IF zjydate IS NOT INITIAL.
*    DELETE lt_tz[] WHERE zjydate > zjydate.
*  ENDIF.
*
*  " IF SY-SUBRC = 0.
*  SORT lt_tz BY bzj_tz ASCENDING zjydate DESCENDING erdat DESCENDING  erzet DESCENDING.
*  "如果是汇票兑付单，直接取最后一条保证金余额
*  IF lv_whbzj = 'B008'." lv_aptype = 'KLDF' OR
*    READ TABLE lt_tz INTO DATA(ls_tz) INDEX 1.
*    IF sy-subrc = 0.
*      LOOP AT lt_tz INTO ls_tz  WHERE bzj_tz = ls_tz-bzj_tz AND zjydate = ls_tz-zjydate AND erdat = ls_tz-erdat AND erzet = ls_tz-erzet.
*      ENDLOOP.
*      CLEAR lt_tz. APPEND ls_tz TO lt_tz. CLEAR ls_tz.
*    ENDIF.
*  ELSE.
*    READ TABLE lt_tz INTO ls_tz  INDEX 1.
*    IF sy-subrc = 0 .
*      IF ls_tz-fitype <> '5'.
*        LOOP AT lt_tz INTO ls_tz  WHERE bzj_tz = ls_tz-bzj_tz AND zjydate = ls_tz-zjydate AND erdat = ls_tz-erdat AND erzet = ls_tz-erzet AND fitype = '5'.
*          EXIT.
*        ENDLOOP.
*      ENDIF.
*      CLEAR lt_tz. APPEND ls_tz TO lt_tz. CLEAR ls_tz.
*    ENDIF.
*
*    "  DELETE ADJACENT DUPLICATES FROM lt_tz COMPARING bzj_tz.
*  ENDIF.
*  "  ENDIF.
*
*  LOOP AT lt_tz INTO ls_tz.
*    MOVE-CORRESPONDING ls_tz TO item.
*    APPEND item.
*  ENDLOOP.
**收款银行
*  IF item[] IS NOT INITIAL.
*    READ TABLE item INDEX 1.
*    SELECT SINGLE docno INTO @DATA(lv_docno) FROM ztrt2199
*      WHERE bzj_tz = @item-bzj_tz AND fitype = '1'.
*    IF sy-subrc = 0.
*      SELECT SINGLE * INTO sk FROM ztrt2002
*        WHERE docno = lv_docno.
*    ENDIF.
*  ENDIF.
*




ENDFUNCTION.
