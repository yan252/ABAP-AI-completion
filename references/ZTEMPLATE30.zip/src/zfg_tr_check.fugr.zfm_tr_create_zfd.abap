FUNCTION ZFM_TR_CREATE_ZFD.
**"--------------------------------------------------------------------
**"*"局部接口：
**"  IMPORTING
**"     VALUE(HEADER) TYPE  ZTRT2001
**"     VALUE(SKBANK) TYPE  ZTRT2002 OPTIONAL
**"     VALUE(FKBANK) TYPE  ZTRT2003 OPTIONAL
**"     VALUE(TEST) TYPE  CHAR1 OPTIONAL
**"  EXPORTING
**"     VALUE(DOCNO) TYPE  ZTR_ZFDOCNO
**"  TABLES
**"      GZMX STRUCTURE  ZTRT2004 OPTIONAL
**"      YFK STRUCTURE  ZTRT2005 OPTIONAL
**"      HP STRUCTURE  ZTRT2009 OPTIONAL
**"      RETURN STRUCTURE  BAPIRET2
**"--------------------------------------------------------------------
*ls_2001 = header.
*  ls_2002 = skbank.
*  ls_2003 = fkbank.
*  lt_2004 = gzmx[].
*  lt_2005 = yfk[].
*  lt_2009 = hp[].
*
*  CLEAR lt_return.
*  PERFORM frm_check_data.
*  IF lt_return IS NOT INITIAL.
*    return[] = lt_return.
*    RETURN.
*  ELSE.
*    IF test IS INITIAL.
*      PERFORM frm_save_zfd CHANGING docno.
******* start  - chengangrong
******* add by chengangrong for data encryption
*      IF lt_return IS NOT INITIAL.
**        error in encryption
**        data was not saved
*        CLEAR docno.
*        return[] = lt_return.
*        RETURN.
*      ENDIF.
*******  end - chengangrong
*      IF  ls_2001-zzffs = '30'  AND  ls_2001-zywtype = '40'  ."银企直连-资金平台（自动审批）的发送付款指令
*        PERFORM frm_send_pay_order.
*      ENDIF.
*    ENDIF.
*  ENDIF.
*
*  PERFORM frm_unlock_all.





ENDFUNCTION.
