*"* use this source file for any macro definitions you need
*"* in the implementation part of the class
INCLUDE ztr_bank_acc_rel_dmee_convert.
*INCLUDE ztr_bank_acc_generalquery_res.
