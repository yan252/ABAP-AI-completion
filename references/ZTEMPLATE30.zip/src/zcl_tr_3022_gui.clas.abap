class ZCL_TR_3022_GUI definition
  public
  final
  create public .

public section.

  class-methods CVT_TIME1
    importing
      !IV_IN type ANY
    exporting
      !EV_OUT type TIMS
    exceptions
      ERR .
  class-methods CVT_TIME2
    importing
      !IV_IN type ANY
    exporting
      !EV_OUT type TIMS
    exceptions
      ERR .
  class-methods CVT_TIME3
    importing
      !IV_IN type ANY
    exporting
      !EV_OUT type TIMS
    exceptions
      ERR .
  class-methods CVT_DATE1
    importing
      !IV_IN type ANY
    exporting
      !EV_OUT type D
    exceptions
      ERR .
  class-methods CVT_DATE2
    importing
      !IV_IN type ANY
    exporting
      !EV_OUT type D
    exceptions
      ERR .
  class-methods CVT_DATE3
    importing
      !IV_IN type ANY
    exporting
      !EV_OUT type D
    exceptions
      ERR .
  class-methods CVT_DATE4
    importing
      !IV_IN type ANY
    exporting
      !EV_OUT type D
    exceptions
      ERR .
  class-methods CVT_DATE5
    importing
      !IV_IN type ANY
    exporting
      !EV_OUT type D
    exceptions
      ERR .
  class-methods CVT_DATE6
    importing
      !IV_IN type ANY
    exporting
      !EV_OUT type D
    exceptions
      ERR .
  class-methods CVT_DATE7
    importing
      !IV_IN type ANY
    exporting
      !EV_OUT type D
    exceptions
      ERR .
  class-methods CVT_DATE8
    importing
      !IV_IN type ANY
    exporting
      !EV_OUT type D
    exceptions
      ERR .
  class-methods CVT_DATE9
    importing
      !IV_IN type ANY
    exporting
      !EV_OUT type D
    exceptions
      ERR .
  class-methods CVT_DATEA
    importing
      !IV_IN type ANY
    exporting
      !EV_OUT type D
    exceptions
      ERR .
  class-methods CVT_DATEB
    importing
      !IV_IN type ANY
    exporting
      !EV_OUT type D
    exceptions
      ERR .
  class-methods CVT_DATEC
    importing
      !IV_IN type ANY
    exporting
      !EV_OUT type D
    exceptions
      ERR .
  class-methods CVT_AMT1
    importing
      !IV_IN type ANY
    exporting
      !EV_OUT type ZTR_BKFSE
    exceptions
      ERR .
  class-methods CVT_AMT2
    importing
      !IV_IN type ANY
    exporting
      !EV_OUT type ZTR_BKFSE
    exceptions
      ERR .
  class-methods CVT_AMT3
    importing
      !IV_IN type ANY
    exporting
      !EV_OUT type ZTR_BKFSE
    exceptions
      ERR .
protected section.
private section.
ENDCLASS.



CLASS ZCL_TR_3022_GUI IMPLEMENTATION.


method CVT_AMT1.
   data lv_amt type char30.
   data: lcx_error type ref to cx_root.

   lv_amt = iv_in .
   do.
   replace ',' with space into lv_amt .
      if sy-subrc <> 0 . exit .endif.
   enddo .
   condense lv_amt no-gaps .
   try .
      ev_out = lv_amt.
      catch   cx_sy_conversion_error into lcx_error.
      raise err.
    endtry.
  endmethod.


METHOD cvt_amt2.
    DATA lv_amt TYPE char30.
    DATA: lcx_error TYPE REF TO cx_root.

    lv_amt = iv_in.

    DO.
      REPLACE ',' WITH space INTO lv_amt .
      IF sy-subrc <> 0 . EXIT .ENDIF.
    ENDDO .

    IF lv_amt CS '(' .
      REPLACE '(' WITH space INTO lv_amt .
      REPLACE ')' WITH space INTO lv_amt .
      CONDENSE lv_amt NO-GAPS .
      TRY .
          ev_out = 0 -  lv_amt.
        CATCH   cx_sy_conversion_error INTO lcx_error.
          RAISE err.
      ENDTRY.
    ELSE.
      CONDENSE lv_amt NO-GAPS .
      TRY .
          ev_out = lv_amt.
        CATCH   cx_sy_conversion_error INTO lcx_error.
          RAISE err.
      ENDTRY.
    ENDIF.



  ENDMETHOD.


METHOD cvt_amt3.
    DATA lv_amt TYPE char30.
    DATA lv_amt1 TYPE char30.

    DATA sign TYPE char1.
    DATA dec_point TYPE char1.
    DATA char1 TYPE char1.
    DATA site TYPE i.
    DATA len TYPE i."小数位数
    DATA: lcx_error TYPE REF TO cx_root.

    lv_amt = iv_in.

*    DO.
*      REPLACE ',' WITH space INTO lv_amt .
*      IF sy-subrc <> 0 . EXIT .ENDIF.
*    ENDDO .

    IF lv_amt CS '(' .
      REPLACE '(' WITH space INTO lv_amt .
      REPLACE ')' WITH space INTO lv_amt .
      CONDENSE lv_amt NO-GAPS .
      sign = abap_true.
    ELSE.
      CONDENSE lv_amt NO-GAPS .
    ENDIF.

    TRY .
        ev_out = lv_amt.
      CATCH   cx_sy_conversion_error INTO lcx_error.

        DO strlen( lv_amt ) TIMES VARYING char1 FROM lv_amt(1)
                                  NEXT lv_amt+1(1) RANGE lv_amt .
          IF char1 CO '0123456789'.
            CONCATENATE lv_amt1 char1 INTO lv_amt1.
            len = len + 1.
          ELSE.
            dec_point = char1.
            site = strlen( lv_amt1 ).
            len = 0.
          ENDIF.
        ENDDO.

        IF dec_point IS NOT INITIAL   .
          TRY.
              ev_out = lv_amt1 / ( 10 ** len   ).
            CATCH   cx_sy_conversion_error INTO lcx_error.
          ENDTRY.
        ENDIF.


    ENDTRY.
    IF sign = abap_true.
      ev_out = 0 - ev_out.
    ENDIF.

  ENDMETHOD.


METHOD cvt_date1.
*    DATA lv_date TYPE char10.
*    DATA: lcx_error TYPE REF TO cx_root.
*    DATA  yyyy TYPE numc4.
*    DATA  mm TYPE numc2.
*    DATA  dd TYPE numc2.
*    lv_date = iv_in .
*
*    FIND '/' IN lv_date.
*    IF sy-subrc = 0.
*      SPLIT lv_date AT '/' INTO  DATA(y)  DATA(m)  DATA(d)   .
*      yyyy = y.
*      mm   = m.
*      dd   = d.
*      lv_date = yyyy && mm && dd.
*    ENDIF.
*
*
*    CONDENSE lv_date NO-GAPS .
*    TRY .
*        ev_out = lv_date.
*      CATCH   cx_sy_conversion_error INTO lcx_error.
*        RAISE err.
*    ENDTRY.
    cvt_date4(
    EXPORTING
      iv_in  = iv_in
    IMPORTING
      ev_out = ev_out
    EXCEPTIONS
      err    = 1
      OTHERS = 2
      ).
    IF sy-subrc <> 0.
      RAISE err.
      RETURN.
    ENDIF.

    CALL FUNCTION 'DATE_CHECK_PLAUSIBILITY'
      EXPORTING
        date                      = ev_out
      EXCEPTIONS
        plausibility_check_failed = 1
        OTHERS                    = 2.
    IF sy-subrc <> 0.
      RAISE err.
    ENDIF.

  ENDMETHOD.


method CVT_DATE2.
  DATA lv_date TYPE char10.
  DATA: lcx_error TYPE REF TO cx_root.
  DATA  yyyy TYPE numc4.
  DATA  mm TYPE numc2.
  DATA  dd TYPE numc2.
  lv_date = iv_in .

  FIND '-' IN lv_date.
  IF sy-subrc = 0.
    SPLIT lv_date AT '-' INTO  DATA(y)  DATA(M)  DATA(d)   .
    yyyy = y.
    mm   = M.
    dd   = d.
    lv_date = yyyy && mm && dd.
  ENDIF.


  CONDENSE lv_date NO-GAPS .
  TRY .
    ev_out = lv_date.
  CATCH   cx_sy_conversion_error INTO lcx_error.
    RAISE err.
  ENDTRY.

  CALL FUNCTION 'DATE_CHECK_PLAUSIBILITY'
  EXPORTING
    DATE                      = ev_out
  EXCEPTIONS
    plausibility_check_failed = 1
    OTHERS                    = 2.
  IF sy-subrc <> 0.
    RAISE err.
  ENDIF.

  endmethod.


METHOD cvt_date3.
*    DATA lv_date TYPE char10.
*    DATA: lcx_error TYPE REF TO cx_root.
*    DATA  yyyy TYPE numc4.
*    DATA  mm TYPE numc2.
*    DATA  dd TYPE numc2.
*    lv_date = iv_in .
*
*    FIND '.' IN lv_date.
*    IF sy-subrc = 0.
*      SPLIT lv_date AT '.' INTO  DATA(y)  DATA(m)  DATA(d)   .
*      yyyy = y.
*      mm   = m.
*      dd   = d.
*      lv_date = yyyy && mm && dd.
*    ENDIF.
*
*
*    CONDENSE lv_date NO-GAPS .
*    TRY .
*        ev_out = lv_date.
*      CATCH   cx_sy_conversion_error INTO lcx_error.
*        RAISE err.
*    ENDTRY.

    cvt_date4(
      EXPORTING
        iv_in  = iv_in
      IMPORTING
        ev_out = ev_out
      EXCEPTIONS
        err    = 1
        OTHERS = 2
           ).
    IF sy-subrc <> 0.
      RAISE err.
      RETURN.
    ENDIF.

    CALL FUNCTION 'DATE_CHECK_PLAUSIBILITY'
      EXPORTING
        date                      = ev_out
      EXCEPTIONS
        plausibility_check_failed = 1
        OTHERS                    = 2.
    IF sy-subrc <> 0.
      RAISE err.
    ENDIF.

  ENDMETHOD.


METHOD cvt_date4.


*2018-01-01 04:18:29
*2018-01-10 16:24
*20180131 17:24:00
*1/31/18 0:50

    DATA : lv_date TYPE char10,
           lv_tmp  TYPE char10.
    DATA: lcx_error TYPE REF TO cx_root.

    DATA  yyyy TYPE numc4.
    DATA  mm TYPE numc2.
    DATA  dd TYPE numc2.
    DATA  spl TYPE c.
    lv_date = iv_in .
    CHECK lv_date IS NOT INITIAL.
    IF lv_date(4) BETWEEN '2010' AND '2099'.    "完整年度
*
*     do 2 times .
*      replace '.' with space into lv_date(10) .
*      replace '/' with space into lv_date(10) .
*      replace '-' with space into lv_date(10) .
*    enddo.
      spl = lv_date+4(1)."分割符
      IF spl NA '0123456789'.
        FIND spl IN lv_date(10).
        IF sy-subrc = 0.
          SPLIT lv_date(10) AT spl INTO  DATA(y)  DATA(m)  DATA(d)   .
          yyyy = y.
          mm   = m.
          IF strlen( d ) > 2.
            dd   = d(2).
          ELSE.
            dd   = d .
          ENDIF.
          lv_date = yyyy && mm && dd.
        ENDIF.
      ENDIF.


      CONDENSE lv_date NO-GAPS .

      TRY .
          ev_out = lv_date(8).
        CATCH   cx_sy_conversion_error INTO lcx_error.
          RAISE err.
      ENDTRY.


    ELSE.
      SPLIT lv_date AT space INTO lv_date lv_tmp.
      IF lv_date+7(1) = space.
        CONCATENATE '0' lv_date(7) INTO lv_date(8).
      ENDIF.
      CONCATENATE '20' lv_date+6(2) lv_date(2)  lv_date+3(02) INTO lv_date(8).

      TRY .
          ev_out = lv_date(8).
        CATCH   cx_sy_conversion_error INTO lcx_error.
          RAISE err.
      ENDTRY.

    ENDIF.


    CALL FUNCTION 'DATE_CHECK_PLAUSIBILITY'
      EXPORTING
        date                      = ev_out
      EXCEPTIONS
        plausibility_check_failed = 1
        OTHERS                    = 2.
    IF sy-subrc <> 0.
      RAISE err.
    ENDIF.



  ENDMETHOD.


METHOD cvt_date5.
*    7/31/2018>20180731
    DATA lv_date TYPE char10.
    DATA: lcx_error TYPE REF TO cx_root.

    SPLIT iv_in  AT '/' INTO DATA(lv_c1)  DATA(lv_c2) DATA(lv_c3) .

    lv_date(4) = lv_c3.

    DATA : lv_num TYPE numc2 .

    lv_num = lv_c1 .

    lv_date+4(2) = lv_num  .

    lv_num = lv_c2 .

    lv_date+6(2) = lv_num  .


    TRY .
        ev_out = lv_date.
      CATCH   cx_sy_conversion_error INTO lcx_error.
        RAISE err.
    ENDTRY.
  ENDMETHOD.


METHOD cvt_date6.
*    7/31/2018>20180731
    DATA lv_date TYPE char10.
    DATA: lcx_error TYPE REF TO cx_root.

*    2018/7/13>20180713

    SPLIT iv_in  AT '/' INTO DATA(lv_c1)  DATA(lv_c2) DATA(lv_c3) .

    lv_date(4) = lv_c1 .

    IF strlen( lv_c2 ) = 2 .
      lv_date+4(2) = lv_c2 .
    ELSE.
      lv_date+4(1) = '0'.
      lv_date+5(1) = lv_c2 .
    ENDIF.

    IF strlen( lv_c3 ) = 2 .
      lv_date+6(2) = lv_c3 .
    ELSE.
      lv_date+6(1) = '0'.
      lv_date+7(1) = lv_c3 .
    ENDIF.


    TRY .
        ev_out = lv_date.
      CATCH   cx_sy_conversion_error INTO lcx_error.
        RAISE err.
    ENDTRY.
  ENDMETHOD.


METHOD CVT_DATE7.
*DD/MM/YYYY>YYYYMMDD
    DATA lv_date TYPE char10.
    DATA: lcx_error TYPE REF TO cx_root.

    lv_date(4) = iv_in+6(4) .
    lv_date+4(2) = iv_in+3(2).
    lv_date+6(2) = iv_in(2).

    TRY .
        ev_out = lv_date.
      CATCH   cx_sy_conversion_error INTO lcx_error.
        RAISE err.
    ENDTRY.
  ENDMETHOD.


METHOD CVT_DATE8.

*DD-MM-YYYY>YYYYMMDD
    DATA lv_date TYPE char10.
    DATA: lcx_error TYPE REF TO cx_root.

    lv_date(4) = iv_in+6(4) .
    lv_date+4(2) = iv_in+3(2).
    lv_date+6(2) = iv_in(2).

    TRY .
        ev_out = lv_date.
      CATCH   cx_sy_conversion_error INTO lcx_error.
        RAISE err.
    ENDTRY.
  ENDMETHOD.


METHOD CVT_DATE9.
*31/7/2018>20180731

    DATA lv_date TYPE char10.
    DATA: lcx_error TYPE REF TO cx_root.

    SPLIT iv_in  AT '/' INTO DATA(lv_c1)  DATA(lv_c2) DATA(lv_c3) .

    lv_date(4) = lv_c3.

    DATA : lv_num TYPE numc2 .

    lv_num = lv_c1 .

    lv_date+6(2) = lv_num  .

    lv_num = lv_c2 .

    lv_date+4(2) = lv_num  .


    TRY .
        ev_out = lv_date.
      CATCH   cx_sy_conversion_error INTO lcx_error.
        RAISE err.
    ENDTRY.
  ENDMETHOD.


METHOD cvt_datea.

*1/31/18 0:50

    DATA : lv_date  TYPE char10,
           lv_date1 TYPE char10,
           lv_dd    TYPE char02,
           lv_mm    TYPE char02,
           lv_yy    TYPE char10,
           lv_tmp   TYPE char10,
           lv_numc2 TYPE numc2.

    DATA: lcx_error TYPE REF TO cx_root.

    lv_date1 = iv_in .

    SPLIT lv_date1 AT space INTO lv_date1 lv_tmp.

    SPLIT lv_date1 AT '/' INTO  lv_mm lv_dd lv_yy .

    lv_date(2)  = '20'.
    lv_date+2(2) = lv_yy.

    CLEAR lv_numc2 .
    lv_numc2 = lv_mm .
    lv_date+4(2) = lv_numc2 .

    CLEAR lv_numc2 .
    lv_numc2 = lv_dd .
    lv_date+6(2) = lv_numc2 .

    TRY .
        ev_out = lv_date(8).
      CATCH   cx_sy_conversion_error INTO lcx_error.
        RAISE err.
    ENDTRY.



  ENDMETHOD.


METHOD cvt_dateb.

*日期DD-Jun-YY>日期YYYYMMDD
    DATA  :lv_date  TYPE char10,
           lv_date1 TYPE char10,
           lv_dd    TYPE char02,
           lv_mm    TYPE char03,
           lv_yy    TYPE char02.
    DATA: lcx_error TYPE REF TO cx_root.

    lv_date1 = iv_in .

    SPLIT lv_date1 AT '-' INTO lv_dd lv_mm lv_yy.
    lv_date(2) = '20'.
    lv_date+2(4) = lv_yy .

    CASE lv_mm .
      WHEN 'Jan' OR 'JAN'.
        lv_date+4(2) = '01'.
      WHEN 'Feb' OR 'FEB'.
        lv_date+4(2) = '02'.
      WHEN 'Mar' OR 'MAR' .
        lv_date+4(2) = '03'.
      WHEN 'Apr' OR 'APR' .
        lv_date+4(2) = '04'.
      WHEN 'May' OR 'MAY'.
        lv_date+4(2) = '05'.
      WHEN 'Jun' OR 'JUN' .
        lv_date+4(2) = '06'.
      WHEN 'Jul' OR 'JUL'.
        lv_date+4(2) = '07'.
      WHEN 'Aug' OR 'AUG'.
        lv_date+4(2) = '08'.
      WHEN 'Sep' OR 'SEP'.
        lv_date+4(2) = '09'.
      WHEN 'Oct' OR 'OCT' .
        lv_date+4(2) = '10'.
      WHEN 'Nov' OR 'NOV'.
        lv_date+4(2) = '11'.
      WHEN 'Dec' OR 'DEC'.
        lv_date+4(2) = '12'.

    ENDCASE .

    IF lv_dd+1(1) = space.
      lv_date+6(1) = '0'.
      lv_date+7(1) = lv_dd(1)  .
    ELSE.
      lv_date+6(2) = lv_dd  .
    ENDIF.
    TRY .
        ev_out = lv_date.
      CATCH   cx_sy_conversion_error INTO lcx_error.
        RAISE err.
    ENDTRY.
  ENDMETHOD.


METHOD cvt_datec.

*    BREAK-POINT .
**    7/31/2018>20180731
    DATA lv_date TYPE char10.
    DATA: lcx_error TYPE REF TO cx_root.

*    2018/7/13>20180713

    DATA : lv_in TYPE char10 .

    SPLIT iv_in AT space INTO lv_in DATA(lv_other) .

    SPLIT lv_in  AT '/' INTO DATA(lv_c1)  DATA(lv_c2) DATA(lv_c3) .

    lv_date(4) = lv_c1 .

    IF strlen( lv_c2 ) = 2 .
      lv_date+4(2) = lv_c2 .
    ELSE.
      lv_date+4(1) = '0'.
      lv_date+5(1) = lv_c2 .
    ENDIF.

    IF strlen( lv_c3 ) = 2 .
      lv_date+6(2) = lv_c3 .
    ELSE.
      lv_date+6(1) = '0'.
      lv_date+7(1) = lv_c3 .
    ENDIF.


    TRY .
        ev_out = lv_date.
      CATCH   cx_sy_conversion_error INTO lcx_error.
        RAISE err.
    ENDTRY.
  ENDMETHOD.


METHOD cvt_time1.
    DATA : lv_tmp(10) TYPE c.
    DATA: lcx_error TYPE REF TO cx_root.
    lv_tmp = iv_in .
    REPLACE ALL OCCURRENCES OF  ':' IN lv_tmp WITH space  .

    CONDENSE lv_tmp NO-GAPS .
    SHIFT lv_tmp LEFT DELETING LEADING space.




    TRY .
        ev_out = lv_tmp.
      CATCH   cx_sy_conversion_error INTO lcx_error.
        RAISE err.
    ENDTRY.

  ENDMETHOD.


METHOD CVT_TIME2.
    DATA : lv_tmp(10) TYPE c.
    DATA: lcx_error TYPE REF TO cx_root.
    lv_tmp = iv_in .

    REPLACE ':' WITH space INTO lv_tmp .
    CONDENSE lv_tmp NO-GAPS .
    CONCATENATE lv_tmp '00' INTO lv_tmp .
    SHIFT lv_tmp LEFT DELETING LEADING space.

    TRY .
        ev_out = lv_tmp.
      CATCH   cx_sy_conversion_error INTO lcx_error.
        RAISE err.
    ENDTRY.
  ENDMETHOD.


METHOD cvt_time3.
    DATA : lv_tmp(10) TYPE c.
    DATA: lcx_error TYPE REF TO cx_root.
    lv_tmp = iv_in .

    SHIFT lv_tmp LEFT DELETING LEADING space.
    DATA(lv_n) = strlen( lv_tmp ) .
    IF lv_n = 5 .
      CONCATENATE '0' lv_tmp(5) into lv_tmp .
    ELSE.
      RETURN .
    ENDIF.

    TRY .
        ev_out = lv_tmp.
      CATCH   cx_sy_conversion_error INTO lcx_error.
        RAISE err.
    ENDTRY.
  ENDMETHOD.
ENDCLASS.
