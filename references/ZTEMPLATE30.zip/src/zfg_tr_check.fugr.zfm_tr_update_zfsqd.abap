FUNCTION ZFM_TR_UPDATE_ZFSQD.
**"--------------------------------------------------------------------
**"*"局部接口：
**"  IMPORTING
**"     VALUE(I_BUKRS) TYPE  BUKRS
**"     VALUE(I_BCATE) TYPE  ZTR_BILL_CATE
**"     VALUE(I_DOCNO) TYPE  ZTR_REF_DOCNO
**"     VALUE(I_STAT) TYPE  CHAR2
**"  EXPORTING
**"     VALUE(E_RETURN) TYPE  SYMSGTY
**"     VALUE(E_MESSAGE) TYPE  MSGTX
**"--------------------------------------------------------------------
*DATA lv_dflag TYPE delflg.
** 1--------判断支付申请单是否可作废-------------------
*  CALL FUNCTION 'ZFM_TR_QUERY_ZFSQD'
*    EXPORTING
*      i_bukrs   = i_bukrs
*      i_bcate   = i_bcate
*      i_docno   = i_docno
*    IMPORTING
*      e_return  = e_return
*      e_message = e_message.
*
*  TRANSLATE e_return USING '0S1E' .
*
*  CHECK e_return = 'S'.
*
*  lv_dflag = boolc(  i_stat = '21' OR i_stat = '23' OR i_stat = '29' ).
**  CASE i_stat.
**    WHEN '3'."作废
**      i_stat = '29'.
**    WHEN OTHERS.
**      RETURN.
**  ENDCASE.
*
*  SELECT  SINGLE * FROM ztrt2500_1 INTO @DATA(ls_zfsqd)
*        WHERE  ( docno = @i_docno  OR ref_docno = @i_docno )
*        AND  bukrs = @i_bukrs
*         AND bcate = @i_bcate .
*  IF sy-subrc = 0.
*    IF ls_zfsqd-dflag = ''.
*
*      UPDATE ztrt2500_1 SET zzfstatus = i_stat
*                              dflag = lv_dflag
*                               aedat = sy-datum
*                               aezet = sy-uzeit
*                               aenam = sy-uname
*                        WHERE docno =  ls_zfsqd-docno AND bukrs = i_bukrs AND bcate = i_bcate.
*      COMMIT WORK AND WAIT.
*      IF sy-subrc = 0.
*        e_return = 'S'.
*        e_message = '更新成功'.
*      ELSE.
*        e_return = 'E'.
*        e_message = '更新失败'.
*      ENDIF.
*    ELSE.
*      e_return = 'S'.
*      e_message = '支付申请单已被删除'.
*    ENDIF.
*  ELSE.
*    e_return = 'S'.
*    e_message = '未在TR中找到相关的支付申请单'.
*  ENDIF.
*
*
*


ENDFUNCTION.
