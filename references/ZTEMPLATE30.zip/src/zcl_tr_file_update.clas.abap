class ZCL_TR_FILE_UPDATE definition
  public
  inheriting from CL_WD_COMPONENT_ASSISTANCE
  create public .

public section.

  constants HTFJ type ZTR_BUSTYPE value 'TR_0001' ##NO_TEXT.
  constants CBFJ type ZTR_BUSTYPE value 'TR_0002' ##NO_TEXT.
  constants DWFJ type ZTR_BUSTYPE value 'TR_0003' ##NO_TEXT.
  constants CWFJ_CR type ZTR_BUSTYPE value 'TR_0005' ##NO_TEXT.
  constants CWFJ_HT type ZTR_BUSTYPE value 'TR_0006' ##NO_TEXT.
  constants JSTZD_HT type ZTR_BUSTYPE value 'TR_0011' ##NO_TEXT.
  constants JSTZD_CJ type ZTR_BUSTYPE value 'TR_0010' ##NO_TEXT.
  constants JSTZD_TZ type ZTR_BUSTYPE value 'TR_0012' ##NO_TEXT.
  constants JSTZD_BG_CJ type ZTR_BUSTYPE value 'TR_0013' ##NO_TEXT.
  constants JSTZD_BG_HZ type ZTR_BUSTYPE value 'TR_0014' ##NO_TEXT.
  constants DFFJ type ZTR_BUSTYPE value 'TR_0007' ##NO_TEXT.
  constants DKHT type ZTR_BUSTYPE value 'TR_0008' ##NO_TEXT.
  constants DKHT_TK type ZTR_BUSTYPE value 'TR_0009' ##NO_TEXT.
  constants FJ_JDSQ type ZTR_BUSTYPE value 'TR_0017' ##NO_TEXT.
  constants FJ_JDFK type ZTR_BUSTYPE value 'TR_0018' ##NO_TEXT.
  constants FJ_CDQR type ZTR_BUSTYPE value 'TR_0019' ##NO_TEXT.
  constants FJ_RZXX type ZTR_BUSTYPE value 'TR_0020' ##NO_TEXT.
  constants FJ_DFXX type ZTR_BUSTYPE value 'TR_0021' ##NO_TEXT.
  constants FJ_JDSQ_YH type ZTR_BUSTYPE value 'TR_0027' ##NO_TEXT.
  constants FJ_JDFK_YH type ZTR_BUSTYPE value 'TR_0028' ##NO_TEXT.
  constants FJ_CDQR_YH type ZTR_BUSTYPE value 'TR_0029' ##NO_TEXT.
  constants FJ_DFXX_YH type ZTR_BUSTYPE value 'TR_0031' ##NO_TEXT.
  constants TQHK type ZTR_BUSTYPE value 'TR_0032' ##NO_TEXT.
  constants FJ_SKPT type ZTR_BUSTYPE value 'TR_0033' ##NO_TEXT.
  constants FJ_QTSK type ZTR_BUSTYPE value 'TR_0034' ##NO_TEXT.
  constants FJ_KHTZ type ZTR_BUSTYPE value 'TR_0035' ##NO_TEXT.
  constants FJ_TKTZD type ZTR_BUSTYPE value 'TR_0036' ##NO_TEXT.
  constants FJ_JDSQ_RZ type ZTR_BUSTYPE value 'TR_0090' ##NO_TEXT.
  constants FJ_JDFK_RZ type ZTR_BUSTYPE value 'TR_0091' ##NO_TEXT.
  constants FJ_HKSQ_RZ type ZTR_BUSTYPE value 'TR_0092' ##NO_TEXT.
  constants FJ_JDSQ_DZ type ZTR_BUSTYPE value 'TR_0093' ##NO_TEXT.
  constants FJ_JDFK_DZ type ZTR_BUSTYPE value 'TR_0094' ##NO_TEXT.
  constants FJ_CDQR_DZ type ZTR_BUSTYPE value 'TR_0095' ##NO_TEXT.
  constants FJ_DFXX_DZ type ZTR_BUSTYPE value 'TR_0096' ##NO_TEXT.
  constants FJ_FKTZD type ZTR_BUSTYPE value 'TR_0097' ##NO_TEXT.
  constants FJ_FKCDTZD_1 type ZTR_BUSTYPE value 'TR_0098' ##NO_TEXT.
  constants FJ_FKCDTZD_2 type ZTR_BUSTYPE value 'TR_0099' ##NO_TEXT.
  constants FJ_FKCDTZD_3 type ZTR_BUSTYPE value 'TR_0100' ##NO_TEXT.
  constants FJ_JDSQ_TS type ZTR_BUSTYPE value 'TR_0101' ##NO_TEXT.
  constants FJ_JDFK_TS type ZTR_BUSTYPE value 'TR_0102' ##NO_TEXT.
  constants FJ_CDQR_TS type ZTR_BUSTYPE value 'TR_0103' ##NO_TEXT.
  constants FJ_DFXX_TS type ZTR_BUSTYPE value 'TR_0104' ##NO_TEXT.
  constants FJ_FKDADF type ZTR_BUSTYPE value 'TR_0106' ##NO_TEXT.
  constants FJ_FKDPJB type ZTR_BUSTYPE value 'TR_0111' ##NO_TEXT.
  constants FJ_FKDPCW type ZTR_BUSTYPE value 'TR_0112' ##NO_TEXT.
  constants FJ_FKDPDF type ZTR_BUSTYPE value 'TR_0113' ##NO_TEXT.
  constants FJ_BGJBXX type ZTR_BUSTYPE value 'TR_0107' ##NO_TEXT.
  constants FJ_QXBLXX type ZTR_BUSTYPE value 'TR_0108' ##NO_TEXT.
  constants FJ_HKJBXX type ZTR_BUSTYPE value 'TR_0109' ##NO_TEXT.
  constants FJ_JBXX type ZTR_BUSTYPE value 'TR_0110' ##NO_TEXT.
  constants FJ_9910 type ZTR_BUSTYPE value 'TR_0125' ##NO_TEXT.

  class-methods M_DOWNLOAD_FILE
    importing
      !IV_ATT_NO type ZT00040-ATT_NO .
protected section.
private section.
ENDCLASS.



CLASS ZCL_TR_FILE_UPDATE IMPLEMENTATION.


METHOD m_download_file.

    DATA: ls_zt00040 TYPE zt00040,
          lt_bin     TYPE TABLE OF tbl1024.

    DATA: lv_lenth     TYPE sapb-length,
          lv_xstring   TYPE xstring,
          lv_lt        TYPE i,
          lv_filename  TYPE string,
          lv_mimetp    TYPE w3conttype,
          lv_mime_type TYPE string.


    CHECK iv_att_no IS NOT INITIAL.

    SELECT SINGLE *
           INTO ls_zt00040
           FROM zt00040
          WHERE att_no EQ iv_att_no.

    CHECK sy-subrc EQ 0.

    "下载OpenText
    CALL FUNCTION 'ARCHIVOBJECT_GET_TABLE'
      EXPORTING
        archiv_id                = 'EA'
        document_type            = ls_zt00040-filetype
        archiv_doc_id            = ls_zt00040-arc_doc_id
      IMPORTING
        binlength                = lv_lenth
      TABLES
        binarchivobject          = lt_bin
      EXCEPTIONS
        error_archiv             = 1
        error_communicationtable = 2
        error_kernel             = 3
        OTHERS                   = 4.

    CHECK sy-subrc EQ 0.

    lv_lt = lv_lenth.

    "转换为XString
    CALL FUNCTION 'SCMS_BINARY_TO_XSTRING'
      EXPORTING
        input_length = lv_lt
      IMPORTING
        buffer       = lv_xstring
      TABLES
        binary_tab   = lt_bin
      EXCEPTIONS
        failed       = 1
        OTHERS       = 2.

    CHECK sy-subrc EQ 0.

    "获取MIME类型
    CALL FUNCTION 'SDOK_MIMETYPE_GET'
      EXPORTING
        extension = ls_zt00040-filetype
      IMPORTING
        mimetype  = lv_mimetp.

    lv_filename = ls_zt00040-att_name.
    lv_mime_type = lv_mimetp.

    "下载文件
    CALL METHOD cl_wd_runtime_services=>attach_file_to_response
      EXPORTING
        i_filename  = lv_filename
        i_content   = lv_xstring
        i_mime_type = lv_mime_type
*       i_in_new_window = ABAP_FALSE
*       i_inplace   = ABAP_FALSE
      .

  ENDMETHOD.
ENDCLASS.
