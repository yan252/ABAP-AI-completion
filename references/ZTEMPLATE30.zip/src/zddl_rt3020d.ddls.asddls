@AbapCatalog.sqlViewName: 'ZTRCDS3020D'
@AbapCatalog.compiler.compareFilter: true
@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: '应收未清项账龄表'
define view ZDDL_RT3020D 
as select from bsid as a inner join
               bseg as b on b.mandt = a.mandt
                    and b.bukrs = a.bukrs
                    and b.belnr = a.belnr
                    and b.gjahr = a.gjahr
                    and b.buzei = a.buzei
                  --  inner join 
                  --kna1 as c on a.kunnr = c.kunnr
                     -- and c.mandt = a.mandt
                        -- inner join 
                  --knb1 as d on a.kunnr = d.kunnr
                        -- and a.bukrs = d.bukrs
                        -- and a.mandt = d.mandt
{
a.mandt,
a.bukrs,
a.belnr,
a.gjahr,
a.buzei,
a.kunnr,
a.zlsch,
a.waers,
a.zterm,
a.sgtxt,
a.bvtyp,
a.shkzg,
case  
 when a.shkzg = 'H' then a.wrbtr * ( -1 )
 when a.shkzg = 'S' then a.wrbtr 
 else 0 end 
 as wrbtr ,
( case
  when ( b.koart = 'D' and b.shkzg = 'H' ) or ( b.koart = 'K' and b.shkzg = 'S' ) and b.rebzg = '' and a.zfbdt <> '00000000' then a.zfbdt 
  when ( b.koart = 'D' and b.shkzg = 'H' ) or ( b.koart = 'K' and b.shkzg = 'S' ) and b.rebzg = '' and a.zfbdt = '00000000' then a.bldat
  when a.zfbdt <> '00000000' and a.zbd3t <> 0                  then dats_add_days(a.zfbdt,CEIL(a.zbd3t),'NULL') 
  when a.zfbdt <> '00000000' and a.zbd3t = 0 and a.zbd2t <> 0  then dats_add_days(a.zfbdt,CEIL(a.zbd2t),'NULL') 
  when a.zfbdt <> '00000000' and a.zbd3t = 0 and a.zbd2t = 0   then dats_add_days(a.zfbdt,CEIL(a.zbd1t),'NULL') 
  when a.zfbdt  = '00000000' and a.zbd3t <> 0                  then dats_add_days(a.bldat,CEIL(a.zbd3t),'NULL') 
  when a.zfbdt  = '00000000' and a.zbd3t = 0 and a.zbd2t <> 0  then dats_add_days(a.bldat,CEIL(a.zbd2t),'NULL') 
  when a.zfbdt  = '00000000' and a.zbd3t = 0 and a.zbd2t = 0   then dats_add_days(a.bldat,CEIL(a.zbd1t),'NULL') 
  else a.zfbdt
  end )
  as zfbdt,
a.hkont,
b.rstgr,
b.vbel2,
b.posn2,
a.projk,
a.prctr
}
where a.zlspr = '' 
--  and a.xref3  not like 'P0%'
--  and a.xref3  not like 'C0%'
  --and c.sperr = ''
 -- and c.loevm = ''
  --and c.nodel = '' 
  --and d.sperr = ''
 -- and d.loevm = ''
  --and d.nodel = '' 
 
  
 