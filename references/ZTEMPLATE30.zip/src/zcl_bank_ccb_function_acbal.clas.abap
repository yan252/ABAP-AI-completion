class ZCL_BANK_CCB_FUNCTION_ACBAL definition
  public
  inheriting from ZCL_BANK_FUNCTION_ACCBALANCE
  final
  create public .

public section.
protected section.

  methods PROCESSING_RESPONSE_INTL_CORE
    redefinition .
private section.
ENDCLASS.



CLASS ZCL_BANK_CCB_FUNCTION_ACBAL IMPLEMENTATION.


METHOD processing_response_intl_core.
    CASE action.
      WHEN zif_bank_action=>action_is_account_balance.
*        当前余额
        processing_response_by_dbtable(
                    im_data_db_table              = 'ZTRT_CCB_ACBAL'
                    im_detail_response_component  = 'ITEM'
                    im_statuscode_componnet       = 'HEADER-RETURN_CODE'
                    im_statustext_component       = 'HEADER-RETURN_MSG'
                    im_db_account_number_field    = space
                    im_bank_entry_accnumber_field = space  ).
      WHEN zif_bank_action=>action_is_acc_history_balance.
*        历史余额
        processing_response_by_dbtable(
                    im_data_db_table              = 'ZTRT_CCB_HACBAL'
                    im_detail_response_component  = 'BODY-DETAILS'
                    im_statuscode_componnet       = 'HEADER-RETURN_CODE'
                    im_statustext_component       = 'HEADER-RETURN_MSG'
                    im_db_account_number_field    = space
                    im_bank_entry_accnumber_field = space  ).
    ENDCASE.

  ENDMETHOD.
ENDCLASS.
