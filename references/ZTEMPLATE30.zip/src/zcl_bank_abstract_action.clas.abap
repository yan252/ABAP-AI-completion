CLASS zcl_bank_abstract_action DEFINITION
  PUBLIC
  ABSTRACT
  CREATE PUBLIC .
  ##NEEDED
  PUBLIC SECTION.

    INTERFACES zif_bank_action .
    INTERFACES zif_messages .

    ALIASES action_is_account_balance
      FOR zif_bank_action~action_is_account_balance .
    ALIASES action_is_check_payments
      FOR zif_bank_action~action_is_check_payments .
    ALIASES action_is_get_transactions
      FOR zif_bank_action~action_is_get_transactions .
    ALIASES action_is_payment
      FOR zif_bank_action~action_is_payment .
    ALIASES get_action
      FOR zif_bank_action~get_action .
    ALIASES get_action_code
      FOR zif_bank_action~get_action_code .
    ALIASES get_bank
      FOR zif_bank_action~get_bank .
    ALIASES messages_copy_from_object
      FOR zif_messages~messages_copy_from_object .
    ALIASES publish_messages
      FOR zif_messages~publish_messages .

    METHODS constructor
      IMPORTING
        !im_action TYPE ztr_app_action_for_bank
      EXCEPTIONS
        action_error
        create_uuid_error .
    METHODS run .
    CLASS-METHODS create
      IMPORTING
        !im_action         TYPE ztr_app_action_for_bank
      RETURNING
        VALUE(ro_instance) TYPE REF TO zcl_bank_abstract_action .
    METHODS if_error
      RETURNING
        VALUE(re_error) TYPE flag .
    METHODS set_entries
      IMPORTING
        !im_t_entries TYPE STANDARD TABLE .
PROTECTED SECTION.
  ALIASES action
    FOR zif_bank_action~action .

  CONSTANTS yes TYPE flag VALUE 'X' ##NO_TEXT.
  CONSTANTS no TYPE flag VALUE space ##NO_TEXT.
  DATA messages TYPE REF TO zcl_message_collector .
  DATA action_uuid TYPE sysuuid_c22 .
  DATA banks_list TYPE ztrs_bank_tab .
  DATA entries_reference TYPE REF TO data .
  CLASS-DATA dummy_message TYPE string .

  METHODS create_bank
    IMPORTING
      !im_bank_indicator TYPE ztr_bank_indicator
    RETURNING
      VALUE(ro_instance) TYPE REF TO zif_bank .
  METHODS feedback_from_bank_core .
  METHODS prepare_core .
  METHODS run_for_specific_action_core .
private section.

  class-data INSTANCE type ref to ZIF_BANK_ACTION .

  methods RUN_CORE .
  methods RUN_BANK .
  methods FEEDBACK_FROM_BANK .
  methods PREPARE .
  methods RUN_FOR_SPECIFIC_ACTION .
  methods START_BANK_FEEDBACK .
  methods END_BANK_FEEDBACK .
  methods START_RUNNING_BANK .
  methods RUN_BANK_CORE .
  methods END_RUNNING_BANK .
  methods START_RUNNING .
  methods END_RUNNING .
  methods START_PREPARING .
  methods END_PREPARING .
  methods START_RUNNING_FOR_SPECIFIC .
  methods END_RUNNING_FOR_SPECIFIC .
ENDCLASS.



CLASS ZCL_BANK_ABSTRACT_ACTION IMPLEMENTATION.


  METHOD constructor.
    CONSTANTS: lc_program    TYPE syrepid VALUE 'ZCL_BANK_ABSTRACT_ACTION',
               lc_message_id TYPE symsgid VALUE 'ZTR_BANK_APPLICATION'.

    zcl_bank_enviroment=>s_check_action_from_external(
                             EXPORTING
                               im_action = im_action
                             EXCEPTIONS
                               blank_action = 1
                               not_found = 2
                               class_not_config = 3
                               formatted_structure_not_config = 4
                               formatted_structure_not_found = 5 ).
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid
              TYPE sy-msgty
              NUMBER sy-msgno
              WITH sy-msgv1
                   sy-msgv2
                   sy-msgv3
                   sy-msgv4
               RAISING action_error.
    ELSE.
      action = im_action.
    ENDIF.

*create the uuid for whole running session
    TRY.
        action_uuid = cl_system_uuid=>if_system_uuid_static~create_uuid_c22( ).
      CATCH cx_uuid_error.
        MESSAGE e001(ztr_bank_application)
         RAISING create_uuid_error.
    ENDTRY.

**create instance of message clooector
*    CREATE OBJECT messages
*      EXPORTING
*        i_message_key  = action_uuid
*        i_main_program = lc_program
*        i_class        = lc_message_id.

    messages = zcl_bank_logger_protocal=>add_message_collector(
                  EXPORTING
                    im_default_message_class = lc_message_id
                    im_mainprogram           = lc_program
                    im_uuid                  = action_uuid ).
  ENDMETHOD.


  METHOD create.
*    start log
    MESSAGE i103(ztr_bank_application)
            WITH im_action
                 zcl_bank_enviroment=>s_get_bank_action_text( im_action )
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = im_action ) ).
*end log

    zcl_bank_enviroment=>s_check_action_from_external(
                                      EXPORTING
                                        im_action                      = im_action
                                      IMPORTING
                                        ex_s_action                    = DATA(ls_action)
                                      EXCEPTIONS
                                        blank_action                   = 1
                                        not_found                      = 2
                                        class_not_config = 3
                                        formatted_structure_not_config = 4
                                        formatted_structure_not_found  = 5 ).
    IF sy-subrc <> 0.
*      we should skip the error by testing
*    start log
      MESSAGE ID sy-msgid
              TYPE sy-msgty
              NUMBER   sy-msgno
              WITH sy-msgv1
                   sy-msgv2
                   sy-msgv3
                   sy-msgv4
                   INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = im_action ) ).
*      zcl_bank_logger_protocal=>save_log( im_destory = yes ).
      RETURN.
*    end log
    ELSE.
*    start log
      MESSAGE i104(ztr_bank_application)
              WITH im_action
                   zcl_bank_enviroment=>s_get_bank_action_text( im_action )
                   ls_action-instance_class
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = im_action ) ).
*    end log
    ENDIF.

    CREATE OBJECT ro_instance TYPE (ls_action-instance_class)
           EXPORTING
             im_action = im_action
           EXCEPTIONS
             action_error = 1
             create_uuid_error = 2.
    IF sy-subrc <> 0.
*      we should skip the error by testing

*    start log
      FREE ro_instance.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = im_action ) ).
*      zcl_bank_logger_protocal=>save_log( im_destory = yes ).
      RETURN.
*    end log
    ELSE.
      instance = ro_instance.

*    start log
      MESSAGE i105(ztr_bank_application)
              WITH im_action
                   zcl_bank_enviroment=>s_get_bank_action_text( im_action )
                   ls_action-instance_class
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = im_action ) ).
*    end log
    ENDIF.
  ENDMETHOD.


  METHOD create_bank.


    READ TABLE banks_list ASSIGNING FIELD-SYMBOL(<ls_bank_list>)
         WITH KEY bank_ind = im_bank_indicator.
    IF sy-subrc <> 0.
      APPEND INITIAL LINE TO banks_list ASSIGNING <ls_bank_list>.
      <ls_bank_list>-bank_ind = im_bank_indicator.
      <ls_bank_list>-instance = zcl_abstract_bank=>create(
                                    im_bank_indicator = im_bank_indicator
                                    im_action = action ).
    ENDIF.

    ro_instance = <ls_bank_list>-instance.


  ENDMETHOD.


  METHOD end_bank_feedback.
*    start log
    MESSAGE i194(ztr_bank_application)
            WITH action
                 zcl_bank_enviroment=>s_get_bank_action_text( action )
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = action_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = action ) ).
*    end log
  ENDMETHOD.


  METHOD end_preparing.
*    start log
    MESSAGE i133(ztr_bank_application)
            WITH action
                 zcl_bank_enviroment=>s_get_bank_action_text( action )
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = action_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = action ) ).
*    end log
  ENDMETHOD.


  METHOD end_running.
*    start log
    MESSAGE i108(ztr_bank_application)
            WITH action
                 zcl_bank_enviroment=>s_get_bank_action_text( action )
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = action_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = action ) ).
*    end log
  ENDMETHOD.


  METHOD end_running_bank.
*    start log
    MESSAGE i149(ztr_bank_application)
            WITH action
                 zcl_bank_enviroment=>s_get_bank_action_text( action )
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = action_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = action ) ).
*    end log
  ENDMETHOD.


  METHOD end_running_for_specific.
*    start log
    MESSAGE i135(ztr_bank_application)
            WITH action
                 zcl_bank_enviroment=>s_get_bank_action_text( action )
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = action_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = action ) ).
*    end log
  ENDMETHOD.


  METHOD feedback_from_bank.
    start_bank_feedback( ).
    feedback_from_bank_core( ).
    end_bank_feedback( ).
  ENDMETHOD.


  METHOD feedback_from_bank_core.
*to be re-defined
  ENDMETHOD.


  method IF_ERROR.
    re_error = MESSAGES->if_error( ).
  endmethod.


  METHOD prepare.
    start_preparing( ).
    prepare_core( ).
    end_preparing( ).
  ENDMETHOD.


  method PREPARE_CORE.
*to be re-defined
  endmethod.


  METHOD run.
    start_running( ).
    run_core( ).
    end_running( ).
  ENDMETHOD.


  METHOD run_bank.
    start_running_bank( ).
    run_bank_core( ).
    end_running_bank( ).
  ENDMETHOD.


  METHOD run_bank_core.
    LOOP AT banks_list INTO DATA(ls_bank_list)
          WHERE instance IS BOUND.
      CHECK ls_bank_list-instance->if_error( ) = no.
      ls_bank_list-instance->run( ).
    ENDLOOP.
  ENDMETHOD.


  METHOD run_core.
    prepare( ).
    run_for_specific_action( ).
    run_bank( ).
    feedback_from_bank( ).
  ENDMETHOD.


  METHOD run_for_specific_action.
    start_running_for_specific( ).
    run_for_specific_action_core( ).
    end_running_for_specific( ).
  ENDMETHOD.


  method RUN_FOR_SPECIFIC_ACTION_CORE.
*to be re-defined
  endmethod.


  method SET_ENTRIES.
    FIELD-SYMBOLS: <ft_entries> TYPE STANDARD TABLE.

    CREATE DATA entries_reference LIKE im_t_entries.

    ASSIGN entries_reference->* TO <ft_entries>.

    <ft_entries> = im_t_entries.

*    start log
      MESSAGE i106(ztr_bank_application)
              WITH action
                   zcl_bank_enviroment=>s_get_bank_action_text( action )
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action ) ).
*    end log
  endmethod.


  METHOD start_bank_feedback.
*    start log
    MESSAGE i193(ztr_bank_application)
            WITH action
                 zcl_bank_enviroment=>s_get_bank_action_text( action )
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = action_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = action ) ).
*    end log
  ENDMETHOD.


  method START_PREPARING.
*    start log
    MESSAGE i132(ztr_bank_application)
            WITH action
                 zcl_bank_enviroment=>s_get_bank_action_text( action )
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = action_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = action ) ).
*    end log
  endmethod.


  METHOD start_running.
*    start log
    MESSAGE i107(ztr_bank_application)
            WITH action
                 zcl_bank_enviroment=>s_get_bank_action_text( action )
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = action_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = action ) ).
*    end log

  ENDMETHOD.


  METHOD start_running_bank.
*    start log
    MESSAGE i148(ztr_bank_application)
            WITH action
                 zcl_bank_enviroment=>s_get_bank_action_text( action )
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = action_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = action ) ).
*    end log
  ENDMETHOD.


  method START_RUNNING_FOR_SPECIFIC.
*    start log
    MESSAGE i134(ztr_bank_application)
            WITH action
                 zcl_bank_enviroment=>s_get_bank_action_text( action )
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = action_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = action ) ).
*    end log
  endmethod.


  method ZIF_BANK_ACTION~GET_ACTION.
    ro_instance = instance.
  endmethod.


  method ZIF_BANK_ACTION~GET_ACTION_CODE.
    re_action = action.
  endmethod.


  METHOD zif_bank_action~get_bank.
    READ TABLE banks_list INTO DATA(ls_bank_list)
          WITH KEY bank_ind = im_bank_indicator.
    ro_instance = ls_bank_list-instance.

    IF ro_instance IS NOT BOUND.
*      unexpected
      MESSAGE e081(ztr_bank_application)
              WITH im_bank_indicator.
    ENDIF.
  ENDMETHOD.


  METHOD zif_messages~messages_copy_from_object.
    messages_copy_from_object.
  ENDMETHOD.


  method ZIF_MESSAGES~PUBLISH_MESSAGES.
    PUBLISH_MESSAGES.
  endmethod.
ENDCLASS.
