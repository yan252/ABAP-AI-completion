class ZCL_TR_3021_GUI definition
  public
  final
  create public .

public section.

  class-methods GET_WITEM_AGN_AMT
    importing
      !IV_BGUID type GUID_32
      !IV_ITEMN type ZTR_ITEMN
    exporting
      !EV_AMT type ANY .
  class-methods GET_BP_AMT
    importing
      !IV_BUKRS type BUKRS
      !IV_ZBP type ZTR_BP
      !IV_WKPLV type ZTR_WPLV
      !IV_ZFD type ZTR_ZFDOCNO optional
    exporting
      !EV_KTOKK type KTOKK
      !EV_AMT type WRBTR
      !EV_WAERS type WAERS .
  class-methods GET_BP_AMT_DETAIL
    importing
      !IV_BUKRS type BUKRS optional
      !IV_ZBP type ZTR_BP optional
      !IV_ZFD type ZTR_ZFDOCNO optional
      !NO_ALV type BOOLEAN optional
    exporting
      !ET_CFMX type ZTRT_LIFNR_CFMX
      !EV_AMT type WRBTR
      !EV_WAERS type WAERS .
protected section.
private section.
ENDCLASS.



CLASS ZCL_TR_3021_GUI IMPLEMENTATION.


METHOD get_bp_amt.



    SELECT SINGLE waers FROM t001 INTO ev_waers WHERE bukrs = iv_bukrs .

    SELECT SINGLE ktokk FROM lfa1 INTO ev_ktokk WHERE lifnr = iv_zbp .


    " SELECT SINGLE edate INTO @DATA(lv_edate) FROM ztrt9011 WHERE zwplv = @iv_wkplv .
*---------超付校验可以根据架构配置 提前付款 20200811 ztrt9040_2 二级架构控制所有的资金计划取数，
    DATA(lv_edate) = sy-datum.
    "SELECT SINGLE date_tolerance FROM ztrt9040_2 INTO @DATA(lv_tler) WHERE bukrs = @iv_bukrs .
    SELECT SINGLE date_tolerance FROM ztrcds9040 INTO @DATA(lv_tler) WHERE bukrs = @iv_bukrs .
*--------"超付校验可以根据架构配置 提前付款 20200811  ------------------------------
    IF sy-subrc = 0 .
      lv_edate  = lv_edate + lv_tler .
    ENDIF.

    DATA :   gt_saknr      TYPE RANGE OF hkont  .
    SELECT * INTO TABLE @DATA(lt_9028) FROM ztrt9028.
    IF sy-subrc <> 0 .
      ev_amt = 0 . RETURN .
    ELSE.
      LOOP AT lt_9028 INTO DATA(ls_9028).
        APPEND  VALUE #( sign = 'I' option = 'EQ'  low = ls_9028-saknr  ) TO gt_saknr.
      ENDLOOP.
      "20200121 员工科目从配置表拿走，员工暂时不走计划，通过预估创建支付单
      "临时添加员工科目进行超付校验,否则预估支付申请也无法创建的支付单
      IF '0022410300' NOT IN gt_saknr.
        APPEND  VALUE #( sign = 'I' option = 'EQ'  low = '0022410300' ) TO gt_saknr.
      ENDIF.
*      “20200121
    ENDIF.
******* begin 20190605 跨币种支付，相对历史记录 汇率变大，取历史外币转换未本币计算。*******************************
*       ABAP-038-付款平台优化-20190702  ERDK930764
*     2)创建支付单ZTR00062，以及发送付款指令是时的超付校验逻辑：
*    取执行操作时间点的供应商未清项表（BSIK）的金额与未过账的支付单金额相比较
*    （排除以下状态16已过账，21已作废，23审批拒绝，29删除，62退回过账，64汇票已撤销，65总部审批拒绝），
*    如支付单金额 > 供应商未清项金额，则提示超付。
    DATA: lv_bwaers    TYPE waers,
          lv_amt_local TYPE wrbtr,
          lv_amt_zfd   TYPE wrbtr.
    DATA:lv_dmbtr_h TYPE  wrbtr,
         lv_dmbtr_s TYPE  wrbtr.
    " SELECT SUM( wrbtr ) AS wrbtr, waers FROM ztrcds3020h
    SELECT bukrs,  belnr,  gjahr,  buzei , wrbtr  , waers FROM ztrcds3020h "与明细可能会存在差异，不汇总 20200629
            INTO TABLE @DATA(lt_dmbtr_h)
            WHERE bukrs = @iv_bukrs
              AND  shkzg = 'H'
          AND zfbdt <= @lv_edate
*                AND zfbdt <= @sy-datum
              AND zlspr = @space
              AND hkont IN @gt_saknr
              AND lifnr = @iv_zbp
              AND hkont NOT IN ( '0022010300' ,'0022010200','0022010100' )
               .

    " SELECT SUM( wrbtr ) AS wrbtr, waers
    SELECT   bukrs,  belnr,  gjahr,  buzei , wrbtr, waers
      FROM ztrcds3020h INTO TABLE @DATA(lt_dmbtr_s)
      WHERE bukrs = @iv_bukrs AND  shkzg = 'S'
          AND lifnr = @iv_zbp
          AND hkont IN @gt_saknr
          AND hkont NOT IN ( '0022010300' ,'0022010200','0022010100' )
         .
*      借方清除部分清账且清账的贷方未到期20200722----------1
    IF lt_dmbtr_s[] IS NOT INITIAL.
      SELECT  bukrs,  belnr,  gjahr,  buzei ,rebzg,rebzj,rebzz INTO TABLE @DATA(lt_partclear)
        FROM ztrcds3020a
        FOR ALL ENTRIES IN @lt_dmbtr_s
        WHERE  bukrs = @lt_dmbtr_s-bukrs
        AND  rebzg = @lt_dmbtr_s-belnr
        AND  rebzj = @lt_dmbtr_s-gjahr
        AND  rebzz = @lt_dmbtr_s-buzei.
      SORT lt_partclear.
    ENDIF.
*      借方清除部分清账且清账的贷方未到期20200722 -------1



*        "公司本位币
    "  SELECT SINGLE waers INTO lv_bwaers FROM t001 WHERE bukrs = iv_bukrs.
    lv_bwaers = ev_waers.
********* H
    LOOP AT lt_dmbtr_h INTO DATA(ls_dmbtr).


      IF ls_dmbtr-waers NE lv_bwaers.
        DATA(otherwaers) = abap_true.
        CALL FUNCTION 'CONVERT_TO_LOCAL_CURRENCY'
          EXPORTING
            date             = sy-datum
            foreign_amount   = ls_dmbtr-wrbtr
            foreign_currency = ls_dmbtr-waers
            local_currency   = lv_bwaers
          IMPORTING
            local_amount     = ls_dmbtr-wrbtr
          EXCEPTIONS
            no_rate_found    = 1
            overflow         = 2
            no_factors_found = 3
            no_spread_found  = 4
            derived_2_times  = 5
            OTHERS           = 6.
        IF sy-subrc <> 0.
        ENDIF.
      ENDIF.
      lv_dmbtr_h = lv_dmbtr_h + ls_dmbtr-wrbtr.
    ENDLOOP.
***** S
    LOOP AT lt_dmbtr_s INTO ls_dmbtr.

*      借方清除部分清账且清账的贷方未到期20200722 -------2
      READ TABLE lt_partclear INTO DATA(ls_partclear) WITH  KEY bukrs = ls_dmbtr-bukrs
                                                                rebzg = ls_dmbtr-belnr
                                                                rebzj = ls_dmbtr-gjahr
                                                                rebzz = ls_dmbtr-buzei.
      IF sy-subrc = 0.
        READ TABLE lt_dmbtr_h INTO DATA(ls_h) WITH  KEY  bukrs = ls_partclear-bukrs
                                                         belnr = ls_partclear-belnr
                                                         gjahr = ls_partclear-gjahr
                                                         buzei = ls_partclear-buzei.
        IF sy-subrc <> 0.
          CONTINUE."借方已挂在未到期的贷方，不算入超付总额
        ENDIF.
      ENDIF.
*      借方清除部分清账且清账的贷方未到期20200722 -------2

      IF ls_dmbtr-waers NE lv_bwaers.
        otherwaers  = abap_true.
        CALL FUNCTION 'CONVERT_TO_LOCAL_CURRENCY'
          EXPORTING
            date             = sy-datum
            foreign_amount   = ls_dmbtr-wrbtr
            foreign_currency = ls_dmbtr-waers
            local_currency   = lv_bwaers
          IMPORTING
            local_amount     = ls_dmbtr-wrbtr
          EXCEPTIONS
            no_rate_found    = 1
            overflow         = 2
            no_factors_found = 3
            no_spread_found  = 4
            derived_2_times  = 5
            OTHERS           = 6.
        IF sy-subrc <> 0.
        ENDIF.
      ENDIF.
      lv_dmbtr_s  = lv_dmbtr_s + ls_dmbtr-wrbtr.
    ENDLOOP.

******* end 20190605 跨币种支付，汇率变化过大，取历史外币转换未本币计算。*******************************
*  支付单金额   （排除以下状态16已过账，21已作废，23审批拒绝，29删除，62退回过账，64汇票已撤销，65总部审批拒绝），

    " 合计一下就好了

    SELECT docno,zzfwaers,zzfwrbtr
      INTO TABLE @DATA(lt_zfd)
      FROM ztrt2001
      WHERE bukrs = @iv_bukrs AND zfmark = '20'
        AND zskno = @iv_zbp AND zywtype = '10'
        AND zzfstatus NOT IN ( '16','21','23','29','62','64','65','31'
*        AND (  zzfstatus = '10' "10  生成
*            OR zzfstatus = '11' "11  已提交
*            OR zzfstatus = '13' "13  审批通过
*            OR zzfstatus = '24' "24  执行付款
*            OR zzfstatus = '25' "25  付款确认
*            OR zzfstatus = '26' "26  支付失败
**               OR zzfstatus = '36'
*            OR zzfstatus = '33' "33  提交票面信息复核
*            OR zzfstatus = '34' "34  票面信息复核通过
      ).

    IF sy-subrc = 0.
      IF iv_zfd IS NOT INITIAL.
        DELETE lt_zfd WHERE docno = iv_zfd.
      ENDIF.
      LOOP AT lt_zfd INTO DATA(ls_zfd).
        IF ls_zfd-zzfwaers <> lv_bwaers.
          otherwaers  = abap_true.
          CLEAR lv_amt_local.
          CALL FUNCTION 'CONVERT_TO_LOCAL_CURRENCY'
            EXPORTING
*             CLIENT           = SY-MANDT
              date             = sy-datum
              foreign_amount   = ls_zfd-zzfwrbtr
              foreign_currency = ls_zfd-zzfwaers
              local_currency   = lv_bwaers
*             RATE             = 0
*             TYPE_OF_RATE     = 'M'
*             READ_TCURR       = 'X'
            IMPORTING
*             EXCHANGE_RATE    =
*             FOREIGN_FACTOR   =
              local_amount     = lv_amt_local
*             LOCAL_FACTOR     =
*             EXCHANGE_RATEX   =
*             FIXED_RATE       =
*             DERIVED_RATE_TYPE       =
            EXCEPTIONS
              no_rate_found    = 1
              overflow         = 2
              no_factors_found = 3
              no_spread_found  = 4
              derived_2_times  = 5
              OTHERS           = 6.
          IF sy-subrc <> 0.
* Implement suitable error handling here
          ENDIF.
          lv_amt_zfd = lv_amt_zfd + lv_amt_local.
        ELSE.
          lv_amt_zfd = ls_zfd-zzfwrbtr + lv_amt_zfd.
        ENDIF.
      ENDLOOP.
    ENDIF.
*  end
*-------------超付容差值----------------
    IF otherwaers  = abap_true.
      SELECT * FROM ztrt9044 INTO TABLE @DATA(lt_cfrcz)
            WHERE del_flg = ''
            AND dateb <= @sy-datum.
      SORT lt_cfrcz BY  dateb DESCENDING.
      READ TABLE lt_cfrcz INTO DATA(ls_cfrcz) INDEX 1.
    ENDIF.
*-------------超付容差值----------------

*供应商未清项金额 = 贷方金额 - 借方金额 - 未过账有效支付单金额 + 可超付容差
    ev_amt = lv_dmbtr_h - lv_dmbtr_s - lv_amt_zfd  + ls_cfrcz-aatop.
  ENDMETHOD.


METHOD get_bp_amt_detail.

*    DATA :   gt_saknr      TYPE RANGE OF hkont  .
*    DATA: lv_bwaers    TYPE waers,
*          lv_amt_local TYPE wrbtr,
*          lv_amt_zfd   TYPE wrbtr.
*    DATA:lv_dmbtr_h TYPE  wrbtr,
*         lv_dmbtr_s TYPE  wrbtr.
*    DATA:ls_cfmx TYPE ztrs_lifnr_cfmx.
**         lt_cfmx LIKE TABLE OF ls_cfmx.,
*    DATA butxt TYPE butxt.
*    DATA lv_lifnr TYPE lifnr.
*    DATA lv_bukrs TYPE bukrs.
*
*    IF  iv_zbp IS INITIAL OR iv_bukrs IS INITIAL.
*      DATA fields TYPE TABLE OF sval.
*      DATA returncode.
*      APPEND VALUE sval( tabname = 'LFA1'
*      fieldname = 'LIFNR' value = iv_zbp  ) TO fields.
*      APPEND VALUE sval( tabname = 'T001'
*      fieldname = 'BUKRS' value = iv_bukrs  ) TO fields.
*      CALL FUNCTION 'POPUP_GET_VALUES'
*        EXPORTING
*          no_value_check  = ' '
*          popup_title     = '超付检查明细-供应商选择'
*        IMPORTING
*          returncode      = returncode
*        TABLES
*          fields          = fields
*        EXCEPTIONS
*          error_in_fields = 1
*          OTHERS          = 2.
*
*      IF  sy-subrc = 0 AND returncode = ''.
*        LOOP AT  fields INTO DATA(ls).
*          IF ls-fieldname = 'LIFNR'.
*            lv_lifnr = |{ ls-value ALPHA = IN }|.
*          ELSEIF ls-fieldname = 'BUKRS'.
*            lv_bukrs = ls-value.
*          ENDIF.
*        ENDLOOP.
*      ELSE.
*        RETURN.
*      ENDIF.
*    ELSE.
*      lv_lifnr = iv_zbp.
*      lv_bukrs = iv_bukrs.
*    ENDIF.
*
*    SELECT SINGLE waers butxt FROM t001 INTO (ev_waers,butxt) WHERE bukrs = lv_bukrs .
*
*    SELECT COUNT(*) FROM lfa1  WHERE lifnr = lv_lifnr .
*    IF  sy-subrc <> 0.
*      MESSAGE s227(ztr02) WITH lv_lifnr DISPLAY LIKE 'W'.
*      RETURN.
*    ENDIF.
*
*    DATA(lv_edate) = sy-datum.
**    SELECT SINGLE edate INTO @DATA(lv_edate) FROM ztrt9011 WHERE zwplv = @iv_wkplv .
**---------超付校验可以根据架构配置 提前付款 20200811 ztrt9040_2 二级架构控制所有的资金计划取数，
*    SELECT SINGLE date_tolerance FROM ztrcds9040 INTO @DATA(lv_tler) WHERE bukrs = @iv_bukrs .
*    IF sy-subrc = 0 .
*      lv_edate  = lv_edate + lv_tler .
*    ENDIF.
*
*
*    SELECT * INTO TABLE @DATA(lt_9028) FROM ztrt9028.
*    IF sy-subrc <> 0 .
*      RETURN .
*    ELSE.
*      LOOP AT lt_9028 INTO DATA(ls_9028).
*        APPEND  VALUE #( sign = 'I' option = 'EQ'  low = ls_9028-saknr  ) TO gt_saknr.
*      ENDLOOP.
*      "20200121 员工科目从配置表拿走，员工暂时不走计划，通过预估创建支付单
*      "临时添加员工科目进行超付校验,否则预估支付申请也无法创建的支付单
*      IF '0022410300' NOT IN gt_saknr.
*        APPEND  VALUE #( sign = 'I' option = 'EQ'  low = '0022410300' ) TO gt_saknr.
*      ENDIF.
**      “20200121
*    ENDIF.
******** begin 20190605 跨币种支付，相对历史记录 汇率变大，取历史外币转换未本币计算。*******************************
**       ABAP-038-付款平台优化-20190702  ERDK930764
**     2)创建支付单ZTR00062，以及发送付款指令是时的超付校验逻辑：
**    取执行操作时间点的供应商未清项表（BSIK）的金额与未过账的支付单金额相比较
**    （排除以下状态16已过账，21已作废，23审批拒绝，29删除，62退回过账，64汇票已撤销，65总部审批拒绝），
**    如支付单金额 > 供应商未清项金额，则提示超付。
*
*
*    SELECT bukrs,belnr,gjahr, buzei,zfbdt, lifnr, wrbtr, waers,
*      wrbtr AS dmbtr ,waers AS bwaers,'0000000000' AS docno
*      FROM ztrcds3020h
*            INTO TABLE @DATA(lt_dmbtr_h)
*            WHERE bukrs = @lv_bukrs
*              AND  shkzg = 'H'
**            AND zfbdt <= @lv_edate
*              AND zfbdt <= @lv_edate
*              AND zlspr = @space
*              AND hkont IN @gt_saknr
*              AND lifnr = @lv_lifnr
*              AND hkont NOT IN ( '0022010300' ,'0022010200','0022010100' )
*             .
*
*
*
*    SELECT  bukrs, belnr, gjahr, buzei,zfbdt,lifnr,wrbtr, waers,
*      wrbtr AS dmbtr,waers AS bwaers,'0000000000' AS docno
*        FROM ztrcds3020h INTO TABLE @DATA(lt_dmbtr_s)
*        WHERE bukrs = @lv_bukrs AND  shkzg = 'S'
*            AND lifnr = @lv_lifnr
*            AND hkont IN @gt_saknr
*            AND hkont NOT IN ( '0022010300' ,'0022010200','0022010100' ).
**      借方清除部分清账且清账的贷方未到期20200722----------1
*    IF lt_dmbtr_s[] IS NOT INITIAL.
*      SELECT  bukrs,  belnr,  gjahr,  buzei ,rebzg,rebzj,rebzz INTO TABLE @DATA(lt_partclear)
*            FROM ztrcds3020a
*            FOR ALL ENTRIES IN @lt_dmbtr_s
*            WHERE  bukrs = @lt_dmbtr_s-bukrs
*            AND  rebzg = @lt_dmbtr_s-belnr
*            AND  rebzj = @lt_dmbtr_s-gjahr
*            AND  rebzz = @lt_dmbtr_s-buzei.
*      SORT lt_partclear.
*    ENDIF.
**      借方清除部分清账且清账的贷方未到期20200722 -------1
*
*
*
*
*
*
********** H
*    LOOP AT lt_dmbtr_h INTO DATA(ls_dmbtr).
*
*      IF ls_dmbtr-waers NE ev_waers.
*        DATA(otherwaers) = abap_true.
*        CALL FUNCTION 'CONVERT_TO_LOCAL_CURRENCY'
*          EXPORTING
*            date             = sy-datum
*            foreign_amount   = ls_dmbtr-wrbtr
*            foreign_currency = ls_dmbtr-waers
*            local_currency   = ev_waers
*          IMPORTING
*            local_amount     = ls_dmbtr-wrbtr
*          EXCEPTIONS
*            no_rate_found    = 1
*            overflow         = 2
*            no_factors_found = 3
*            no_spread_found  = 4
*            derived_2_times  = 5
*            OTHERS           = 6.
*        IF sy-subrc <> 0.
*        ENDIF.
*      ENDIF.
*      lv_dmbtr_h = lv_dmbtr_h + ls_dmbtr-wrbtr.
*
*
*      MOVE-CORRESPONDING ls_dmbtr TO ls_cfmx.
*      ls_cfmx-waers = ls_dmbtr-waers.
*      CLEAR ls_cfmx-docno.
*      APPEND ls_cfmx TO et_cfmx.
*      CLEAR ls_cfmx.
*
*    ENDLOOP.
****** S
*    LOOP AT lt_dmbtr_s INTO ls_dmbtr.
**      借方清除部分清账且清账的贷方未到期20200722 -------2
*      READ TABLE lt_partclear INTO DATA(ls_partclear) WITH  KEY bukrs = ls_dmbtr-bukrs
*            rebzg = ls_dmbtr-belnr
*            rebzj = ls_dmbtr-gjahr
*            rebzz = ls_dmbtr-buzei.
*      IF sy-subrc = 0.
*        READ TABLE lt_dmbtr_h INTO DATA(ls_h) WITH  KEY  bukrs = ls_partclear-bukrs
*              belnr = ls_partclear-belnr
*              gjahr = ls_partclear-gjahr
*              buzei = ls_partclear-buzei.
*        IF sy-subrc <> 0.
*          CONTINUE."借方已挂在未到期的贷方，不算入超付总额
*        ENDIF.
*      ENDIF.
**      借方清除部分清账且清账的贷方未到期20200722 -------2
*      IF ls_dmbtr-waers NE ev_waers.
*        otherwaers = abap_true.
*        CALL FUNCTION 'CONVERT_TO_LOCAL_CURRENCY'
*          EXPORTING
*            date             = sy-datum
*            foreign_amount   = ls_dmbtr-wrbtr
*            foreign_currency = ls_dmbtr-waers
*            local_currency   = ev_waers
*          IMPORTING
*            local_amount     = ls_dmbtr-wrbtr
*          EXCEPTIONS
*            no_rate_found    = 1
*            overflow         = 2
*            no_factors_found = 3
*            no_spread_found  = 4
*            derived_2_times  = 5
*            OTHERS           = 6.
*        IF sy-subrc <> 0.
*        ENDIF.
*      ENDIF.
*      lv_dmbtr_s  = lv_dmbtr_s + ls_dmbtr-wrbtr.
*
*      MOVE-CORRESPONDING ls_dmbtr TO ls_cfmx.
*      ls_cfmx-waers = ev_waers.
*      CLEAR ls_cfmx-docno.
*      ls_cfmx-dmbtr = 0 -  ls_cfmx-dmbtr.
*      ls_cfmx-wrbtr = 0 -  ls_cfmx-wrbtr.
*      APPEND ls_cfmx TO et_cfmx.
*      CLEAR ls_cfmx.
*
*    ENDLOOP.
*
******** end 20190605 跨币种支付，汇率变化过大，取历史外币转换未本币计算。*******************************
**  支付单金额   （排除以下状态16已过账，21已作废，23审批拒绝，29删除，62退回过账，64汇票已撤销，65总部审批拒绝），
*
*    " 合计一下就好了
*
*    SELECT docno,zzfwaers,zzfwrbtr,zzfstatus
*      INTO TABLE @DATA(lt_zfd)
*      FROM ztrt2001
*      WHERE bukrs = @lv_bukrs AND zfmark = '20'
*        AND zskno = @lv_lifnr AND zywtype = '10'
*        AND zzfstatus NOT IN ( '16','21','23','29','62','64','65','31'
**        AND (  zzfstatus = '10' "10  生成
**            OR zzfstatus = '11' "11  已提交
**            OR zzfstatus = '13' "13  审批通过
**            OR zzfstatus = '24' "24  执行付款
**            OR zzfstatus = '25' "25  付款确认
**            OR zzfstatus = '26' "26  支付失败
***               OR zzfstatus = '36'
**            OR zzfstatus = '33' "33  提交票面信息复核
**            OR zzfstatus = '34' "34  票面信息复核通过
*      ).
*
*    IF sy-subrc = 0.
*      IF iv_zfd IS NOT INITIAL.
*        DELETE lt_zfd WHERE docno = iv_zfd.
*      ENDIF.
*      LOOP AT lt_zfd INTO DATA(ls_zfd).
*        IF ls_zfd-zzfwaers <> ev_waers.
*          otherwaers  = abap_true.
*          CLEAR lv_amt_local.
*          CALL FUNCTION 'CONVERT_TO_LOCAL_CURRENCY'
*            EXPORTING
**             CLIENT           = SY-MANDT
*              date             = sy-datum
*              foreign_amount   = ls_zfd-zzfwrbtr
*              foreign_currency = ls_zfd-zzfwaers
*              local_currency   = ev_waers
**             RATE             = 0
**             TYPE_OF_RATE     = 'M'
**             READ_TCURR       = 'X'
*            IMPORTING
**             EXCHANGE_RATE    =
**             FOREIGN_FACTOR   =
*              local_amount     = lv_amt_local
**             LOCAL_FACTOR     =
**             EXCHANGE_RATEX   =
**             FIXED_RATE       =
**             DERIVED_RATE_TYPE       =
*            EXCEPTIONS
*              no_rate_found    = 1
*              overflow         = 2
*              no_factors_found = 3
*              no_spread_found  = 4
*              derived_2_times  = 5
*              OTHERS           = 6.
*          IF sy-subrc <> 0.
** Implement suitable error handling here
*          ENDIF.
*          lv_amt_zfd = lv_amt_zfd + lv_amt_local.
*
*          ls_cfmx-wrbtr =   lv_amt_local.
*        ELSE.
*          lv_amt_zfd = ls_zfd-zzfwrbtr + lv_amt_zfd.
*
*          ls_cfmx-wrbtr =   ls_zfd-zzfwrbtr.
*        ENDIF.
*
*        ls_cfmx-bukrs = lv_bukrs.
*        ls_cfmx-lifnr = lv_lifnr.
*        ls_cfmx-docno = ls_zfd-docno.
*        ls_cfmx-zzfstatus = ls_zfd-zzfstatus.
*        ls_cfmx-waers = ls_zfd-zzfwaers.
*        ls_cfmx-dmbtr = 0 - abs(  ls_zfd-zzfwrbtr ).
*        ls_cfmx-wrbtr = 0 - abs( ls_cfmx-wrbtr ).
*
*        APPEND ls_cfmx TO et_cfmx.
*        CLEAR ls_cfmx.
*      ENDLOOP.
*    ENDIF.
**  end
**-------------超付容差值----------------
*    IF otherwaers = abap_true.
*      SELECT * FROM ztrt9044 INTO TABLE @DATA(lt_cfrcz)
*            WHERE del_flg = ''
*            AND dateb <= @sy-datum.
*      SORT lt_cfrcz BY  dateb DESCENDING.
*      READ TABLE lt_cfrcz INTO DATA(ls_cfrcz) INDEX 1.
*      ls_cfmx-bukrs = lv_bukrs.
*      ls_cfmx-lifnr = lv_lifnr.
*      ls_cfmx-waers = ev_waers.
*      ls_cfmx-docno =  '计算误差容差值'.
*      ls_cfmx-dmbtr =  ls_cfrcz-aatop.
*      ls_cfmx-wrbtr =  ls_cfrcz-aatop.
*
*      APPEND ls_cfmx TO et_cfmx.
*      CLEAR ls_cfmx.
*    ENDIF.
**-------------超付容差值----------------
**供应商未清项金额 = 贷方金额 - 借方金额 - 未过账有效支付单金额
*    ev_amt = lv_dmbtr_h - lv_dmbtr_s - lv_amt_zfd + ls_cfrcz-aatop .
*    SORT et_cfmx BY zfbdt.
*
*
*****************************ALV显示明细*******************************
*    CHECK no_alv IS INITIAL.
*
*    DATA go_alv TYPE REF TO cl_salv_table.
*    DATA: lo_cols TYPE REF TO cl_salv_columns.
*    DATA  lr_column TYPE REF TO cl_salv_column_table.
*    DATA: lo_setting TYPE REF TO cl_salv_display_settings.
*    TRY.
*        cl_salv_table=>factory(
*        IMPORTING
*          r_salv_table = go_alv
*        CHANGING
*          t_table      = et_cfmx[] ).
*
*      CATCH cx_salv_msg.
*    ENDTRY.
*
*
*
*    IF go_alv IS BOUND.
*      lo_cols = go_alv->get_columns( ).
*      lo_cols->get_column( 'BUKRS' )->set_visible( '' ) .
*      lo_cols->get_column( 'LIFNR' )->set_visible( '' ) .
**      lr_column  ?= lo_cols->get_column( 'BUKRS' ).
**      lr_column->set_visible( '' ).
**      lr_column  ?= lo_cols->get_column( 'LIFNR' ).
**      lr_column->set_visible( '' ).
**   设置自动优化列宽度
*      lo_cols->set_optimize( 'X' ).
*
*      go_alv->set_screen_popup(
*      start_column = 1
*      end_column   = 100
*      start_line  = 1
*end_line = 50
*      ).
**   设置抬头
*      DATA lr_grid       TYPE REF TO cl_salv_form_layout_grid.
*      DATA  lr_header     TYPE REF TO cl_salv_form_header_info.
*      CREATE OBJECT: lr_grid.
*      lr_header = lr_grid->create_header_information(
*                                       row = 1
*                                       column = 1
*                                       text = |{ '供应商:' WIDTH = 14 }{ lv_lifnr ALPHA = OUT }—{ zcl_tr_3019_gui=>get_bp_name( i_bp = lv_lifnr ) }|
*                                       ).
*      lr_header = lr_grid->create_header_information(
*                                        row = 2
*                                        column = 1
*                                        text = |{ '截止到期日:' WIDTH = 14 }{ sy-datum DATE = USER }|
*                                        ).
*      lr_header = lr_grid->create_header_information(
*                                       row = 3
*                                       column = 1
*                                       text = |可支付金额(本位币):{ ev_amt WIDTH = 30 }; 本位币：{ ev_waers } |
*                                       ).
*      go_alv->set_top_of_list( lr_grid ).
*
**    合计
*      go_alv->get_aggregations( )->add_aggregation(
*      columnname = 'WRBTR'
*      aggregation = if_salv_c_aggregation=>total
*      ).
*
*      go_alv->get_functions( )->set_all( 'X' ).
*
*      lo_setting = go_alv->get_display_settings( ).
*      lo_setting->set_list_header(  '供应商超付检查明细' ).
*      go_alv->display( ).
*    ENDIF.

  ENDMETHOD.


method get_witem_agn_amt.

*   各类支付单找自己的占用金额  然后加在EV_AMT上

  endmethod.
ENDCLASS.
