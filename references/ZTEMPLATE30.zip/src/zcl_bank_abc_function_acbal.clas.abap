class ZCL_BANK_ABC_FUNCTION_ACBAL definition
  public
  inheriting from ZCL_BANK_FUNCTION_ACCBALANCE
  final
  create public .

public section.
protected section.

  methods PROCESSING_RESPONSE_INTL_CORE
    redefinition .
private section.
ENDCLASS.



CLASS ZCL_BANK_ABC_FUNCTION_ACBAL IMPLEMENTATION.


METHOD PROCESSING_RESPONSE_INTL_CORE.
    processing_response_by_dbtable(
                im_data_db_table              = 'ZTRT_ABC_ACBAL'
                im_detail_response_component  = 'ACC'"'XDATABODY-BALINFO'
                im_statuscode_componnet       = 'RESPCODE'
                im_statustext_component       = 'RESPINFO'
                im_db_account_number_field    = ''
                im_bank_entry_accnumber_field = ''  ).

  "  wait( ).
  ENDMETHOD.
ENDCLASS.
