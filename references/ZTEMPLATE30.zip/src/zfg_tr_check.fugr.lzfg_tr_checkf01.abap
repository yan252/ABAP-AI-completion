**&---------------------------------------------------------------------*
**&  包含                LZFG_TR_CHECKF01
**&---------------------------------------------------------------------*
*
*
**&---------------------------------------------------------------------*
**&  创建来自周资金计划的支付单（抬头-支付明细-收款银行）
**&---------------------------------------------------------------------*
*FORM frm_create_from_zwkplv USING VALUE(pv_bguid) TYPE guid_32
*                                  VALUE(pt_item) TYPE ztr_t_itemn
*                                  VALUE(pv_zzffs) TYPE ztr_zfd_zfs
*                                  VALUE(pv_zbskl) TYPE ztr_bsklflg
*                            CHANGING cv_msg   TYPE string.
*  TYPES:BEGIN OF lty_s_bank,
*          banks TYPE banks,
*          bankl TYPE bankk,
*          bankn TYPE bankn,
*          bkref TYPE bkref,
*        END OF lty_s_bank,
*
*        BEGIN OF lty_s_fund_flow,
*          fund_flow  TYPE ztr_fund_flow,
*          fund_flowd TYPE ztr_fund_flowd,
*        END OF lty_s_fund_flow.
*
*  DATA: lv_koart     TYPE koart,
*        lv_sk        TYPE char1,
*        ls_2004      TYPE ztrt2004, "挂账
*        ls_2005      TYPE ztrt2005, "预付款
*        lt_item      TYPE ztr_t_itemn,
*        lt_fund_flow TYPE STANDARD TABLE OF lty_s_fund_flow,
*        ls_fund_flow TYPE lty_s_fund_flow,
*        ls_bank      TYPE lty_s_bank.
*
*  IF pv_zzffs BETWEEN '51' AND '54'  .
*    "  IF pv_zzffs = '51' OR  pv_zzffs = '52' . "启用票据直联
*    IF pv_zbskl IS INITIAL .
*      MESSAGE s437(ztr01) INTO cv_msg.
*      RETURN.
*    ENDIF.
*
*    IF pv_zbskl = 'A'.
*      MESSAGE s445(ztr01) INTO cv_msg.
*      RETURN.
*    ENDIF.
*  ENDIF.
*
*  LOOP AT pt_item INTO DATA(ls_item).
**锁定周资金计划
*    CALL METHOD zcl_tr_3019_gui=>lock_witem
*      EXPORTING
*        iv_bguid = pv_bguid
*        iv_itemn = ls_item-itemn
*      EXCEPTIONS
*        err      = 1
*        OTHERS   = 2.
*    IF sy-subrc <> 0.
*      MESSAGE  ID sy-msgid TYPE 'S' NUMBER sy-msgno WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
*      INTO cv_msg.
**解锁已加锁的数据
*      IF lt_item IS NOT INITIAL.
*        PERFORM frm_unlock_witem USING lt_item pv_bguid.
*      ENDIF.
*      RETURN.
*    ELSE.
*      APPEND ls_item TO lt_item.
*    ENDIF.
*  ENDLOOP.
*
*
*
**========支付单具体信息
*  DATA: ls_wheader TYPE ztrt3018_01,
*        lt_zitem   TYPE STANDARD TABLE OF ztrt3018_02,
*        ls_zitem   TYPE ztrt3018_02.
*
*
*  SELECT SINGLE * INTO ls_wheader FROM ztrt3018_01
*    WHERE bguid = pv_bguid.
*
*  SELECT * INTO TABLE lt_zitem FROM  ztrt3018_02
*    FOR ALL ENTRIES IN pt_item
*    WHERE bguid = pv_bguid AND itemn = pt_item-itemn
*     AND dflag <> 'X'.
**现金流量项目描述
*  IF lt_zitem IS NOT INITIAL.
*    SELECT fund_flow fund_flowd INTO TABLE lt_fund_flow
*      FROM ztrt9026 FOR ALL ENTRIES IN lt_zitem
*      WHERE fund_flow = lt_zitem-fund_flow.
*  ENDIF.
*
*  READ TABLE lt_zitem INTO ls_zitem INDEX 1.
**抬头
*  ls_2001-bukrs = ls_wheader-bukrs.
*  ls_2001-zzffs = pv_zzffs.
*  SELECT SINGLE butxt INTO  ls_2001-butxt FROM t001 WHERE bukrs = ls_2001-bukrs.
*  ls_2001-zzfstatus = '10'.
*  ls_2001-zfmark = ls_zitem-ztr_bpt."收款方标识
*  ls_2001-zskno = ls_zitem-ztr_bp.
*  CASE ls_zitem-bcate.
*    WHEN '10'.
*      ls_2001-zywtype = '10'."挂账
*    WHEN '20'.
*      ls_2001-zywtype = '20'."预付
*    WHEN OTHERS.
*  ENDCASE.
*
*  CASE ls_2001-zzffs.
*    WHEN '10'.
*      ls_2001-zzftype = 'P003'.
*    WHEN '20' OR '30' OR '31' OR '32' OR '33'.
*      ls_2001-zzftype = 'P002'.
*    WHEN '51' OR '52' OR '53' OR '54'.
*      ls_2001-zzftype = 'P005'.
*      ls_2001-zbskl = pv_zbskl.
*    WHEN OTHERS.
*  ENDCASE.
*
*  ls_2001-zzfwaers = ls_zitem-waers."支付货币
*  ls_2001-zjhzfrq = ls_zitem-betdt."支付日期
**周资金计划版本
*  ls_2001-zweplv = ls_wheader-zwkplv.
**财年
**  ls_2001-gjahr = ls_zitem-gjahr.
**资金来源
*  ls_2001-zflowd_sc = ls_zitem-zjly.
**月计划版本号
*  ls_2001-zmplv = ls_wheader-zmplv.
*
**客商名称(收款账号)
*  CASE ls_2001-zfmark.
*    WHEN '10'."客户
*      "付款条件
*      lv_koart = 'D'.
*      SELECT SINGLE name1 INTO ls_2001-zsknam FROM kna1 WHERE kunnr = ls_2001-zskno.
**收款账-除现金支付外都有收款银行
*      IF ls_2001-zzffs <> '10'.
*        SELECT SINGLE banks bankl bankn bkref INTO ls_bank
*          FROM knbk
*          WHERE kunnr = ls_2001-zskno AND bvtyp = ls_2002-bvtyp.
*        IF sy-subrc <> 0.
*          lv_sk = abap_true.
*        ENDIF.
*      ENDIF.
*    WHEN '20'."供应商
*      "供应商
*      lv_koart = 'K'.
*      SELECT SINGLE name1 INTO ls_2001-zsknam FROM lfa1 WHERE lifnr = ls_2001-zskno.
**收款账户
*      IF ls_2001-zzffs <> '10'.
*        SELECT SINGLE banks bankl bankn bkref INTO ls_bank
*          FROM lfbk
*          WHERE lifnr = ls_2001-zskno AND bvtyp = ls_2002-bvtyp.
*        IF sy-subrc <> 0.
*          lv_sk = abap_true.
*        ENDIF.
*      ENDIF.
*    WHEN OTHERS.
*  ENDCASE.
*
**收款银行-客商银行信息
*  IF lv_sk IS NOT INITIAL.
*    MESSAGE s180(ztr01) INTO cv_msg.
*    PERFORM frm_unlock_witem USING pt_item pv_bguid.
*    RETURN.
*  ENDIF.
*  IF ls_2001-zzffs <> '10' AND ls_bank IS NOT INITIAL.
*    ls_2002-banks = ls_bank-banks.
*    ls_2002-zskbankl = ls_bank-bankl.
*    CONCATENATE ls_bank-bankn ls_bank-bkref INTO ls_2002-zskbnkn.
*    CONDENSE ls_2002-zskbnkn NO-GAPS.
**收款银行名称
*    SELECT SINGLE banka INTO ls_2002-zskbanka FROM bnka
*      WHERE banks = ls_bank-banks AND bankl = ls_bank-bankl.
*  ENDIF.
*
**付款明细
*  DATA:lv_xh  TYPE i.
*
*  LOOP AT lt_zitem INTO ls_zitem.
*    lv_xh = lv_xh + 1.
*    CASE ls_2001-zywtype.
*      WHEN '10'."挂账
*        ls_2004-zxh = lv_xh.
*        ls_2004-belnr = ls_zitem-belnr.
*        ls_2004-gjahr = ls_zitem-gjahr.
*        ls_2004-buzei = ls_zitem-buzei.
*        ls_2004-dqdate = ls_zitem-betdt.
*        ls_2004-wrbtr = ls_zitem-zzfje.
*        ls_2004-wrbtr_sy = ls_zitem-sjzfje.
*        ls_2004-wrbtr_zf = ls_zitem-jhzfe.
*        ls_2001-zzfwrbtr = ls_2001-zzfwrbtr +  ls_zitem-jhzfe.
*        READ TABLE lt_fund_flow INTO ls_fund_flow WITH KEY fund_flow = ls_zitem-fund_flow.
*        IF sy-subrc = 0.
*          ls_2004-zit_flowd = ls_fund_flow-fund_flowd.
*        ENDIF.
*        ls_2004-fund_flow = ls_zitem-fund_flow.
*        ls_2004-tmark = ls_zitem-zbz.
*        ls_2004-wbs = ls_zitem-projk.
*        ls_2004-xmms = ls_zitem-projt.
*        ls_2004-zwe_flowd = ls_zitem-itemn.
*        ls_2004-billn_yw = ls_zitem-zbelnr1.
*        ls_2004-bguid = ls_zitem-bguid.
*        IF ls_wheader-zjjhbb >= 20 AND ls_wheader-zjjhbb <= 99 ."紧急支付
*          ls_2004-jjmark = 'X'.
*        ENDIF.
**        ls_gzmx-zwe_flowd = ls_zitem-copyfrom."(待定)周资金计划项目
*        ls_2004-billn_yw = ls_zitem-zbelnr1.
**计算剩余计划可支付金额
*        PERFORM frm_get_wrbtr_sy USING ls_zitem-bguid ls_zitem-itemn ls_2001-docno
*                                 CHANGING ls_2004-wrbtr_sy.
*        ls_2004-wrbtr_zf = ls_2004-wrbtr_sy.
**付款条件
*        IF ls_zitem-zterm IS NOT INITIAL.
*          ls_2004-zterm = ls_zitem-zterm.
*          PERFORM frm_get_fktj USING ls_zitem-zterm CHANGING ls_2004-zfktj.
*        ENDIF.
*        APPEND ls_2004 TO lt_2004.
*        CLEAR ls_2004.
*      WHEN '20'."预付
*        ls_2005-zxh = lv_xh.
**        ls_yfk-BILLN = ls_zitem-belnr.
*        ls_2005-gjahr = ls_zitem-gjahr.
*        ls_2005-dqdate = ls_zitem-betdt.
*        READ TABLE lt_fund_flow INTO ls_fund_flow WITH KEY fund_flow = ls_zitem-fund_flow.
*        IF sy-subrc = 0.
*          ls_2005-zit_flowd = ls_fund_flow-fund_flowd.
*        ENDIF.
*        ls_2005-fund_flow = ls_zitem-fund_flow.
*        ls_2005-wrbtr = ls_zitem-zzfje.
*        ls_2005-wrbtr_sy = ls_zitem-sjzfje.
*        ls_2001-zzfwrbtr = ls_2001-zzfwrbtr +  ls_zitem-jhzfe.
*        ls_2005-tmark = ls_zitem-zbz.
*        ls_2005-wbs = ls_zitem-projk.
*        ls_2005-xmms = ls_zitem-projt.
*        ls_2005-zwe_flowd = ls_zitem-itemn.
*        ls_2005-billn_yw = ls_zitem-zbelnr1.
*        ls_2005-bguid = ls_zitem-bguid.
*        IF ls_wheader-zjjhbb >= 20 AND ls_wheader-zjjhbb <= 99 ."紧急支付
*          ls_2005-jjmark = 'X'.
*        ENDIF.
**计算剩余计划可支付金额
*        PERFORM frm_get_wrbtr_sy USING ls_zitem-bguid ls_zitem-itemn ls_2001-docno
*                                 CHANGING ls_2005-wrbtr_sy.
*        ls_2005-wrbtr_zf = ls_2005-wrbtr_sy.
**付款条件
*        IF ls_zitem-zterm IS NOT INITIAL.
*          ls_2005-zterm = ls_zitem-zterm.
*          PERFORM frm_get_fktj USING ls_zitem-zterm CHANGING ls_2005-zfktj.
*        ENDIF.
*        APPEND ls_2005 TO lt_2005.
*        CLEAR ls_2005.
*      WHEN OTHERS.
*    ENDCASE.
*  ENDLOOP.
*ENDFORM.
*
**&---------------------------------------------------------------------*
**& 解锁周资金计划行项目
**&---------------------------------------------------------------------*
*FORM frm_unlock_witem USING VALUE(pt_item) TYPE ztr_t_itemn
*                            VALUE(pv_bguid) TYPE guid_32.
*  LOOP AT pt_item INTO DATA(ls_item).
*    zcl_tr_3019_gui=>unlock_witem(
*        EXPORTING
*          iv_bguid =  pv_bguid   " 'CHAR' 格式的大写的 GUID
*          iv_itemn =  ls_item-itemn   " 资金计划项目
*        EXCEPTIONS
*          err      = 1
*          OTHERS   = 2
*      ).
*  ENDLOOP.
*ENDFORM.
*
*
**&---------------------------------------------------------------------*
**& 获取付款条件文本
**&---------------------------------------------------------------------*
*FORM frm_get_fktj USING VALUE(pv_zterm) TYPE dzterm
*                  CHANGING  cv_zfktj TYPE ztr_fktj.
*  DATA lv_txt TYPE text1_052.
*
*  zcl_tr_3019_gui=>get_payterm(
*    EXPORTING
*      iv_zterm = pv_zterm    " 付款条件代码
*    IMPORTING
*      ev_text1 = lv_txt    " 收付条款的自解释
*  ).
*
*  cv_zfktj = lv_txt.
*ENDFORM.
*
**&---------------------------------------------------------------------*
**& 获取剩余支付金额
**&---------------------------------------------------------------------*
*FORM frm_get_wrbtr_sy USING VALUE(pv_bguid) TYPE guid_32
*                            VALUE(pv_itemn) TYPE ztr_itemn
*                            VALUE(pv_docno) TYPE ztr_zfdocno
*                     CHANGING cv_wrbtr_sy TYPE ztr_wrbtr_sy.
*  DATA:lv_jhzfe TYPE ztr_jhzfe,
*       lt_bgui  TYPE STANDARD TABLE OF ztr_s_bgui,
*       ls_bgui  TYPE ztr_s_bgui,
*       lt_zjh   TYPE ztrt_3018_02,
*       ls_zjh   TYPE ztrt3018_02,
*       lt_zf    TYPE STANDARD TABLE OF ztr_s_zfje,
*       ls_zf    TYPE ztr_s_zfje.
*
*  ls_bgui-bguid = pv_bguid.
*  ls_bgui-itemn = pv_itemn.
*  APPEND ls_bgui TO lt_bgui.
*  zcl_tr_3019_gui=>get_detail(
*    EXPORTING
*      it_itemn =  lt_bgui   " 条目编号
*    IMPORTING
*      et_item  = lt_zjh     " 周资金计划行项
*  ).
*
*  READ TABLE lt_zjh INTO ls_zjh INDEX 1.
*  lv_jhzfe = ls_zjh-jhzfe.
*
*  CHECK lv_jhzfe > 0.
*  cv_wrbtr_sy = lv_jhzfe.
*  CALL FUNCTION 'ZFM_GET_ZFJE'
*    TABLES
*      items  = lt_bgui
*      result = lt_zf.
*  IF lt_zf IS NOT INITIAL.
*    IF pv_docno IS NOT INITIAL.
*      DELETE lt_zf WHERE docno = pv_docno.
*    ENDIF.
*    LOOP AT lt_zf INTO ls_zf.
*      cv_wrbtr_sy = cv_wrbtr_sy - ls_zf-wrbtr_zf.
*    ENDLOOP.
*  ENDIF.
*ENDFORM.
*
*
**&---------------------------------------------------------------------*
**& 获取付款银行相关
**&---------------------------------------------------------------------*
*FORM frm_get_fkbank USING VALUE(pv_hbkid) TYPE hbkid
*                          VALUE(pv_yhzh) TYPE ztr_yhzh.
*  DATA: lv_bankn TYPE bankn,
*        lv_refzl TYPE refzl,
*        lv_len   TYPE i,
*        lv_bankl TYPE bankk,
*        lv_hktid TYPE hktid.
*
**判断银行账户长短（标准18位）
*  lv_len = strlen( pv_yhzh ).
*  IF lv_len <= 18.
*    lv_bankn = pv_yhzh.
*  ELSE.
*    lv_bankn = pv_yhzh+0(18).
*    lv_len = lv_len - 18.
*    lv_refzl = pv_yhzh+18(lv_len).
*  ENDIF.
*  SELECT SINGLE hktid INTO lv_hktid
*      FROM t012k
*      WHERE bukrs = ls_2001-bukrs AND bankn = lv_bankn AND refzl = lv_refzl
*        AND hbkid = pv_hbkid.
*  IF sy-subrc = 0.
**银行名称
*    SELECT SINGLE bankl banks INTO (ls_2003-zfkbankl,ls_2003-banks) FROM t012
*      WHERE bukrs = ls_2001-bukrs AND hbkid = pv_hbkid.
*    IF sy-subrc = 0.
*      SELECT SINGLE banka INTO ls_2003-zfkbanka FROM bnka
*        WHERE banks = ls_2003-banks AND bankl = ls_2003-zfkbankl.
*    ENDIF.
*  ENDIF.
*ENDFORM.
*
*
**&---------------------------------------------------------------------*
**& 校验数据
**&---------------------------------------------------------------------*
*FORM frm_check_data.
*  PERFORM frm_check_mandatory.
*ENDFORM.
*
*
**&---------------------------------------------------------------------*
**& 检查必有字段和合法性
**&---------------------------------------------------------------------*
*FORM frm_check_mandatory.
*
*  DATA: lv_msgv   TYPE symsgv,
*        lv_msgv2  TYPE symsgv,
*        lv_msgv3  TYPE symsgv,
*        lv_msgv4  TYPE symsgv,
*        lv_sk     TYPE char1,
*        lv_xh     TYPE i,
*        lv_zf     TYPE dmbtr VALUE '9999999999.99',
*        lv_zjjhbb TYPE ztr_zjjhbb,
*        ls_0013   TYPE ztrt0013,
*        ls_lockw  TYPE lty_s_lockw,
*        lv_fk     TYPE char1.
*
**校验必有数据
**--------支付单抬头
**计划支付日期默认当前系统日期
*  ls_2001-zjhzfrq = sy-datum.
*  IF ls_2001-zbskl NE 'B'.   "20200326 开立不默认，需手动选择
*    ls_2001-zflowd_sc =  '10'."资金来源默认自有
*  ENDIF.
*  "支付方式
*  IF ls_2001-zzffs IS INITIAL.
*    PERFORM frm_add_message USING 'E' '001' '' '' '' ''.
*    RETURN.
*  ENDIF.
*
*  IF ls_2001-zzffs <> '10' AND ls_2001-zzffs <> '20' AND ls_2001-zzffs <> '30' AND ls_2001-zzffs <> '31'
*     AND ls_2001-zzffs <> '32' AND ls_2001-zzffs <> '33' AND ls_2001-zzffs <> '51' AND ls_2001-zzffs <> '52'
*     AND ls_2001-zzffs <> '99'
*     AND ls_2001-zzffs <> '53' AND ls_2001-zzffs <> '54'."票据直联测试20200602
*    PERFORM frm_add_message USING 'E' '004' '' '' '' ''.
*    RETURN.
*  ELSE.
*    CASE ls_2001-zzffs.
*      WHEN '10'."现金
*        CLEAR: ls_2002,ls_2003."不需要收付款银行信息
*        ls_2001-zzftype = 'P003'.
*      WHEN '20' OR '30' OR '31' OR '32' OR '33' OR '99'."支票-银企相关
*        ls_2001-zzftype = 'P002'.
*        IF ls_2002 IS INITIAL. "收款银行
*          IF ls_2001-zywtype <> '33'."资金调拨-取现
*            PERFORM frm_add_message USING 'E' '012' '' '' '' ''.
*            lv_sk = abap_true.
*          ENDIF.
*        ENDIF.
*
*        "资金调拨-取现需要现金日记账代码和科目
*        IF ls_2001-zywtype = '33'."资金调拨-取现
*          IF ls_2001-ztr_account IS INITIAL.
*            PERFORM frm_add_message USING 'E' '150' '' '' '' ''.
*          ENDIF.
*        ENDIF.
*
*        IF ls_2003-hbkid IS INITIAL OR ls_2003-hbkid IS INITIAL OR ls_2003-zfkbnkn IS INITIAL.
*          PERFORM frm_add_message USING 'E' '014' '' '' '' ''.
*          lv_fk = abap_true.
*        ENDIF.
*        IF ls_2001-zzffs = '30'
*         AND ls_2001-zywtype = '25'. "工资支付不可线上支付
*          PERFORM frm_add_message USING 'E' '000' '工资支付不可选择银企支付' '' '' ''.
*          RETURN..
*        ENDIF.
*      WHEN '51' OR '52' OR '53' OR '54'.
*        ls_2001-zzftype = 'P005'.
*        IF ls_2001-zbskl IS INITIAL.
*          PERFORM frm_add_message USING 'E' '013' '' '' '' ''.
*        ELSE.
*          CASE ls_2001-zbskl.
*            WHEN 'A'."背书
*              IF ls_2002 IS INITIAL."收款银行
*                PERFORM frm_add_message USING 'E' '012' '' '' '' ''.
*                lv_sk = abap_true.
*              ENDIF.
*              IF lt_2009 IS INITIAL AND  ( ls_2001-zywtype = '10' OR ls_2001-zywtype = '20' OR ls_2001-zywtype = '30' ).
*                PERFORM frm_add_message USING 'E' '082' '' '' '' ''.
*                RETURN.
*              ENDIF.
*
*              IF ls_2008-zhptype = '01'."纸票不需要付款银行
*                CLEAR ls_2003.
*              ENDIF.
*            WHEN 'B'."开立
*              IF ls_2002 IS INITIAL."收款银行
*                PERFORM frm_add_message USING 'E' '012' '' '' '' ''.
*                lv_sk = abap_true.
*              ENDIF.
*              CLEAR: ls_2003."创建时不需要付款银行
*              CLEAR:ls_2008,lt_2009."创建时，不需要汇票抬头和汇票详细信息
*            WHEN OTHERS.
*              PERFORM frm_add_message USING 'E' '015' '' '' '' ''.
*          ENDCASE.
*        ENDIF.
*        IF ( ls_2001-zzffs = '53' OR ls_2001-zzffs = '54' )
*         AND ls_2001-zywtype = '25'. "工资支付不可线上支付
*          PERFORM frm_add_message USING 'E' '000' '工资支付不可选择银企支付' '' '' ''.
*          RETURN..
*        ENDIF.
*      WHEN OTHERS.
*    ENDCASE.
*
*    IF ( zcl_tr_3024_gui=>auth = abap_true
*      OR sy-sysid = 'ERP' ) AND ls_2001-zfmark NE '99'."贷款还款创建不分配权限20200518
*      AUTHORITY-CHECK OBJECT 'Z_TR303'
*       ID 'BUKRS' FIELD ls_2001-bukrs
*       ID 'ZTR_ZFTYPE' FIELD ls_2001-zzftype.
*      IF sy-subrc <> 0.
*        lv_msgv = ls_2001-bukrs.
*        zcl_wd_common=>get_dom_value(
*      EXPORTING
*        im_domnam = 'ZDM_TR_ZFTYPE'
*        im_domval = ls_2001-zzftype
*      RECEIVING
*        ex_desc   = lv_msgv2
*    ).
*        PERFORM frm_add_message USING 'E' '219' lv_msgv lv_msgv2 '' ''.
*      ENDIF.
*    ENDIF.
*  ENDIF.
*  IF lv_sk IS NOT INITIAL OR lv_fk IS NOT INITIAL.
*    RETURN.
*  ENDIF.
*  "2020.2.14 资金集中平台 汇票划转可多笔票据生成一个支付单
*
*  IF lines( lt_2009 ) > 1 AND ls_2001-zywtype = '20'.
*    PERFORM frm_add_message USING 'E' '179' '' '' '' ''.
*  ENDIF.
*
*  "支付货币
*  IF ls_2001-zzfwaers IS INITIAL.
*    PERFORM frm_add_message USING 'E' '018' '' '' '' ''.
*  ENDIF.
*
*
*
*  "公司
*  IF ls_2001-bukrs IS INITIAL.
*    PERFORM frm_add_message USING 'E' '002' '' '' '' ''.
*    RETURN.
*  ELSE."取公司描述
*    SELECT SINGLE butxt INTO ls_2001-butxt FROM t001 WHERE bukrs = ls_2001-bukrs.
*    IF sy-subrc <> 0.
*      lv_msgv = ls_2001-bukrs.
*      PERFORM frm_add_message USING 'E' '003' lv_msgv '' '' ''.
*      RETURN.
*    ENDIF.
*  ENDIF.
*
*  "收款方
*  IF ls_2001-zywtype <> '33' "现金取款单不需要收款方
*    AND ls_2001-zywtype <> '50'AND ls_2001-zywtype <> '60' ."20200518 贷款还款无收款方标识  "投资支付不检查收款方编码
*    IF ls_2001-zfmark IS INITIAL OR ls_2001-zskno IS INITIAL .
*      PERFORM frm_add_message USING 'E' '005' '' '' '' ''.
*      RETURN.
*    ELSE."取收款方描述
*      " IF ( ls_2001-zywtype = '11' OR  ls_2001-zywtype = '22'  OR  ls_2001-zywtype = '13' ) AND ls_2001-zsknam IS NOT INITIAL.
*      IF ( ls_2001-zywtype IN zcl_tr_3019_gui=>get_zfsqd_range( ) OR ls_2001-zywtype = '11'  ) AND ls_2001-zsknam IS NOT INITIAL.
*        "其他暂借款收款方描述是系统外的20200703
*        "投标保证金也是系统外的20200714
*      ELSE.
*        CASE ls_2001-zfmark.
*          WHEN '10'."客户
*            SELECT SINGLE name1 INTO ls_2001-zsknam FROM kna1 WHERE kunnr = ls_2001-zskno.
*          WHEN '20'."供应商
*            SELECT SINGLE name1 INTO ls_2001-zsknam FROM lfa1 WHERE lifnr = ls_2001-zskno.
*          WHEN '99'."其他
*            IF ls_2001-zsknam IS INITIAL .
*              PERFORM frm_add_message USING 'E' '077' lv_msgv '' '' ''.
*            ENDIF.
*          WHEN OTHERS.
*            PERFORM frm_add_message USING 'E' '006' lv_msgv '' '' ''.
*            RETURN.
*        ENDCASE.
*        IF sy-subrc <> 0.
*          lv_msgv = ls_2001-zskno.
*          PERFORM frm_add_message USING 'E' '007' lv_msgv '' '' ''.
*          RETURN.
*        ENDIF.
*      ENDIF.
*    ENDIF.
*  ENDIF.
*
*  "业务单据类型
*  IF ls_2001-zywtype IS INITIAL.
*    PERFORM frm_add_message USING 'E' '008' '' '' '' ''.
*  ELSE.
*    CLEAR lt_lockw.
*    CASE ls_2001-zywtype.
*      WHEN '10'."应付挂账
*        IF ls_2001-zweplv IS INITIAL .
*          PERFORM frm_add_message USING 'E' '064' '' '' '' ''.
*        ENDIF.
*        CLEAR lt_2005.
*        IF lt_2004 IS INITIAL.
*          PERFORM frm_add_message USING 'E' '009' '' '' '' ''.
*        ELSE.
*          CLEAR: lv_xh,ls_2001-zzfwrbtr.
**加锁周资金计划
*          LOOP AT lt_2004 ASSIGNING FIELD-SYMBOL(<fs_2004>).
*            lv_xh = lv_xh + 1.
*            lv_msgv = lv_xh.
*
*            IF <fs_2004>-bguid IS INITIAL OR <fs_2004>-zwe_flowd IS INITIAL.
*              PERFORM frm_add_message USING 'E' '065' lv_msgv  '' '' ''.
*            ENDIF.
*
*            IF <fs_2004>-zterm IS INITIAL.
*              PERFORM frm_add_message USING 'E' '066' lv_msgv '' '' ''.
*            ENDIF.
*
*            IF <fs_2004>-dqdate IS INITIAL.
*              PERFORM frm_add_message USING 'E' '067' lv_msgv '' '' ''.
*            ENDIF.
*
*            IF <fs_2004>-belnr IS INITIAL.
*              PERFORM frm_add_message USING 'E' '068' lv_msgv '' '' ''.
*            ENDIF.
*
*            IF <fs_2004>-gjahr IS INITIAL.
*              PERFORM frm_add_message USING 'E' '069' lv_msgv '' '' ''.
*            ENDIF.
*
*            IF <fs_2004>-buzei IS INITIAL.
*              PERFORM frm_add_message USING 'E' '070' lv_msgv '' '' ''.
*            ENDIF.
*
*            IF <fs_2004>-wrbtr <= 0.
*              PERFORM frm_add_message USING 'E' '071' lv_msgv '' '' ''.
*            ENDIF.
*
*            IF <fs_2004>-wrbtr_zf <= 0.
*              PERFORM frm_add_message USING 'E' '072' lv_msgv '' '' ''.
*            ENDIF.
*
*            IF <fs_2004>-fund_flow IS INITIAL.
*              PERFORM frm_add_message USING 'E' '073' lv_msgv '' '' ''.
*            ENDIF.
*
*            IF <fs_2004>-fund_flow = 'D11' AND <fs_2004>-wbs IS INITIAL.
*              PERFORM frm_add_message USING 'E' '074' lv_msgv '' '' ''.
*            ENDIF.
*
*            lv_msgv = ls_lockw-bguid.
*            lv_msgv2 = ls_lockw-itemn.
*
*
*            <fs_2004>-zxh = lv_xh.
*
*            ls_lockw-bguid = <fs_2004>-bguid.
*            ls_lockw-itemn = <fs_2004>-zwe_flowd.
*            CALL METHOD zcl_tr_3019_gui=>lock_witem
*              EXPORTING
*                iv_bguid = <fs_2004>-bguid
*                iv_itemn = ls_lockw-itemn
*              EXCEPTIONS
*                err      = 1
*                OTHERS   = 2.
*            IF sy-subrc <> 0.
*              lv_msgv = <fs_2004>-zxh.
*              MESSAGE ID sy-msgid TYPE 'E' NUMBER sy-msgno WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 INTO lv_msgv2.
*              PERFORM frm_add_message USING 'E' '017' lv_msgv  lv_msgv2 '' ''.
*              RETURN.
*            ELSE.
*              APPEND ls_lockw TO lt_lockw.
*            ENDIF.
*
*            ls_2001-zzfwrbtr = ls_2001-zzfwrbtr + <fs_2004>-wrbtr_zf.
**计算剩余金额
*            PERFORM frm_get_wrbtr_sy USING ls_lockw-bguid ls_lockw-itemn '' CHANGING <fs_2004>-wrbtr_sy.
*            IF <fs_2004>-wrbtr_zf > <fs_2004>-wrbtr_sy.
*              lv_msgv3 = <fs_2004>-wrbtr_sy.
*              PERFORM frm_add_message USING 'E' '019' lv_msgv lv_msgv2 lv_msgv3 ''.
*            ENDIF.
**付款条件
*            IF <fs_2004>-zterm IS NOT INITIAL.
*              PERFORM frm_get_fktj USING <fs_2004>-zterm CHANGING <fs_2004>-zfktj.
*            ENDIF.
**现金流向项目描述
*            IF <fs_2004>-fund_flow IS NOT INITIAL.
*              SELECT SINGLE fund_flowd INTO <fs_2004>-zit_flowd FROM  ztrt9026 WHERE fund_flow = <fs_2004>-fund_flow.
*            ENDIF.
**项目描述
*            IF <fs_2004>-wbs IS NOT INITIAL.
*              SELECT SINGLE post1 INTO <fs_2004>-xmms FROM prps WHERE pspnr = <fs_2004>-wbs.
*            ENDIF.
*
**是否紧急支付
*            SELECT SINGLE zjjhbb INTO lv_zjjhbb FROM ztrt3018_01 WHERE bguid = <fs_2004>-bguid.
*            IF sy-subrc = 0 AND lv_zjjhbb >= 71 AND lv_zjjhbb <= 99.
*              <fs_2004>-jjmark = abap_true.
*            ENDIF.
*          ENDLOOP.
*        ENDIF.
*      WHEN '20' OR '12' OR '13' OR '21' OR '22' OR '25' ."预付申请单
*        IF ls_2001-zweplv IS INITIAL .
*          PERFORM frm_add_message USING 'E' '064' '' '' '' ''.
*        ENDIF.
*        IF ls_2001-zywtype NE '12' AND  ls_2001-zywtype NE '13'."退款单有凭证，直接记录，方便过账清账20200703
*          CLEAR lt_2004.
*        ENDIF.
*        IF ls_2001-zweplv IS INITIAL .
*          PERFORM frm_add_message USING 'E' '064' '' '' '' ''.
*        ENDIF.
*        IF lt_2005 IS INITIAL.
*          PERFORM frm_add_message USING 'E' '010' '' '' '' ''.
*        ELSE.
*          CLEAR: lv_xh,ls_2001-zzfwrbtr.
*          LOOP AT lt_2005 ASSIGNING FIELD-SYMBOL(<fs_2005>).
*            lv_xh = lv_xh + 1.
*            lv_msgv = lv_xh.
*
*            <fs_2005>-zxh = lv_xh.
*
*            IF <fs_2005>-bguid IS INITIAL OR <fs_2005>-zwe_flowd IS INITIAL.
*              PERFORM frm_add_message USING 'E' '065' lv_msgv  '' '' ''.
*            ENDIF.
*
*            IF <fs_2005>-zterm IS INITIAL.
*              PERFORM frm_add_message USING 'E' '066' lv_msgv '' '' ''.
*            ENDIF.
*
*            IF <fs_2005>-dqdate IS INITIAL.
*              PERFORM frm_add_message USING 'E' '067' lv_msgv '' '' ''.
*            ENDIF.
*
*            IF <fs_2005>-billn IS INITIAL.
*              PERFORM frm_add_message USING 'E' '075' lv_msgv '' '' ''.
*            ENDIF.
*
*            IF <fs_2005>-wrbtr <= 0.
*              PERFORM frm_add_message USING 'E' '071' lv_msgv '' '' ''.
*            ENDIF.
*
*            IF <fs_2005>-wrbtr_zf <= 0.
*              PERFORM frm_add_message USING 'E' '072' lv_msgv '' '' ''.
*            ENDIF.
*
*            IF <fs_2005>-fund_flow IS INITIAL.
*              PERFORM frm_add_message USING 'E' '073' lv_msgv '' '' ''.
*            ENDIF.
*
*            IF <fs_2005>-fund_flow = 'D11' AND <fs_2005>-wbs IS INITIAL.
*              PERFORM frm_add_message USING 'E' '074' lv_msgv '' '' ''.
*            ENDIF.
*
*
*            ls_lockw-bguid = <fs_2005>-bguid.
*            ls_lockw-itemn = <fs_2005>-zwe_flowd.
*            CALL METHOD zcl_tr_3019_gui=>lock_witem
*              EXPORTING
*                iv_bguid = <fs_2005>-bguid
*                iv_itemn = ls_lockw-itemn
*              EXCEPTIONS
*                err      = 1
*                OTHERS   = 2.
*            IF sy-subrc <> 0.
*              lv_msgv = <fs_2005>-zxh.
*              MESSAGE ID sy-msgid TYPE 'E' NUMBER sy-msgno WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 INTO lv_msgv2.
*              PERFORM frm_add_message USING 'E' '017' lv_msgv  lv_msgv2 '' ''.
*            ELSE.
*              APPEND ls_lockw TO lt_lockw.
*            ENDIF.
*
*            ls_2001-zzfwrbtr = ls_2001-zzfwrbtr + <fs_2005>-wrbtr_zf.
**计算剩余金额
*            PERFORM frm_get_wrbtr_sy USING ls_lockw-bguid ls_lockw-itemn '' CHANGING <fs_2005>-wrbtr_sy.
*            IF <fs_2005>-wrbtr_zf > <fs_2005>-wrbtr_sy.
*              lv_msgv = ls_lockw-bguid.
*              lv_msgv2 = ls_lockw-itemn.
*              lv_msgv3 = <fs_2005>-wrbtr_sy.
*              PERFORM frm_add_message USING 'E' '019' lv_msgv lv_msgv2 lv_msgv3 ''.
*            ENDIF.
**付款条件
*            IF <fs_2005>-zterm IS NOT INITIAL.
*              PERFORM frm_get_fktj USING <fs_2005>-zterm CHANGING <fs_2005>-zfktj.
*            ENDIF.
**现金流向项目描述
*            IF <fs_2005>-fund_flow IS NOT INITIAL.
*              SELECT SINGLE fund_flowd INTO <fs_2005>-zit_flowd FROM  ztrt9026 WHERE fund_flow = <fs_2005>-fund_flow.
*            ENDIF.
*
**项目描述
*            IF <fs_2005>-wbs IS NOT INITIAL.
*              SELECT SINGLE post1 INTO <fs_2005>-xmms FROM prps WHERE pspnr = <fs_2005>-wbs.
*            ENDIF.
*
**是否紧急支付
*            SELECT SINGLE zjjhbb INTO lv_zjjhbb FROM ztrt3018_01 WHERE bguid = <fs_2005>-bguid.
*            IF sy-subrc = 0 AND lv_zjjhbb >= 71 AND lv_zjjhbb <= 99.
*              <fs_2005>-jjmark = abap_true.
*            ENDIF.
*          ENDLOOP.
*        ENDIF.
*      WHEN '30' OR '31' OR '32' OR '40'."资金管理平台
*        IF lt_2005 IS INITIAL.
*          PERFORM frm_add_message USING 'E' '010' '' '' '' ''.
*        ELSE.
*          CLEAR lv_xh.
*          CLEAR  ls_2001-zzfwrbtr.
*          LOOP AT lt_2005 ASSIGNING FIELD-SYMBOL(<fs_zj>).
*            lv_xh = lv_xh + 1.
*            lv_msgv = lv_xh.
*
*            IF <fs_zj>-bguid  IS INITIAL  AND ls_2001-zywtype <> '33'.
*              PERFORM frm_add_message USING 'E' '084' lv_msgv '' '' ''.
**            ELSE.
**              <fs_zj>-billn = <fs_zj>-bguid.
*            ENDIF.
**
**            IF <fs_zj>-zwe_flowd IS INITIAL.
**              PERFORM frm_add_message USING 'E' '085' lv_msgv '' '' ''.
**            ENDIF.
**
**            IF <fs_zj>-zterm IS INITIAL.
**              PERFORM frm_add_message USING 'E' '066' lv_msgv '' '' ''.
**            ENDIF.
*
*            IF <fs_zj>-wrbtr <= 0.
*              PERFORM frm_add_message USING 'E' '071' lv_msgv '' '' ''.
*            ENDIF.
*
*            IF <fs_zj>-wrbtr_sy <= 0.
*              PERFORM frm_add_message USING 'E' '071' lv_msgv '' '' ''.
*            ENDIF.
*
*            IF <fs_zj>-wrbtr_zf <= 0.
*              PERFORM frm_add_message USING 'E' '072' lv_msgv '' '' ''.
*            ENDIF.
*
*            IF <fs_zj>-fund_flow IS INITIAL AND ls_2001-zywtype <> '33'.
*              PERFORM frm_add_message USING 'E' '073' lv_msgv '' '' ''.
*            ENDIF.
*
*
*            <fs_zj>-zxh = lv_xh.
**付款条件
**** 20191110    由于资金管理平台无付款条件与对方开户行类型，出口控制过账必输 ，故默认填充
*            IF <fs_zj>-zterm IS   INITIAL.
*              IF ls_2001-zzffs = '51' OR  ls_2001-zzffs = '52'  OR  ls_2001-zzffs = '53'
*                OR  ls_2001-zzffs = '54'.
*                <fs_zj>-zterm = '1B01'.
*              ELSE.
*                <fs_zj>-zterm = '1T01'.
*              ENDIF.
*            ENDIF.
**** 20191110    由于资金管理平台无付款条件与对方开户行类型，出口控制过账必输 ，故默认填充
*            IF <fs_zj>-zterm IS NOT INITIAL.
*              PERFORM frm_get_fktj USING <fs_zj>-zterm CHANGING <fs_zj>-zfktj.
*            ENDIF.
**现金流向项目描述
*            IF <fs_zj>-fund_flow IS NOT INITIAL.
*              SELECT SINGLE fund_flowd INTO <fs_zj>-zit_flowd FROM  ztrt9026 WHERE fund_flow = <fs_zj>-fund_flow.
*            ENDIF.
*            ls_2001-zzfwrbtr = ls_2001-zzfwrbtr + <fs_zj>-wrbtr_zf.
*          ENDLOOP.
*
*
*        ENDIF.
*      WHEN '33'."资金调拨-取现
*        IF lt_2005 IS INITIAL .
*          PERFORM frm_add_message USING 'E' '133' '' '' '' ''.
*        ELSE.
*          CLEAR lv_xh.
*          LOOP AT lt_2005 ASSIGNING FIELD-SYMBOL(<fs_qx>).
*            lv_xh = lv_xh + 1.
*            lv_msgv = lv_xh.
*            "现金取款单申请号
*            IF <fs_qx>-billn IS INITIAL.
*              PERFORM frm_add_message USING 'E' '134' '' '' '' ''.
*            ENDIF.
*
**            "周资金计划行项目
**            IF <fs_qx>-zwe_flowd IS INITIAL.
**              PERFORM frm_add_message USING 'E' '135' '' '' '' ''.
**            ENDIF.
*
*            "凭证货币金额
*            IF <fs_qx>-wrbtr <= 0.
*              PERFORM frm_add_message USING 'E' '071' lv_msgv '' '' ''.
*            ENDIF.
*
*            "凭证货币金额
*            IF <fs_qx>-wrbtr <= 0.
*              PERFORM frm_add_message USING 'E' '071' lv_msgv '' '' ''.
*            ENDIF.
*            "剩余支付金额，支付金额 = 取现金额
*            <fs_qx>-wrbtr_sy = <fs_qx>-wrbtr.
*            <fs_qx>-wrbtr_zf = <fs_qx>-wrbtr.
*
*            "现金流量项目
*            IF <fs_qx>-fund_flow IS INITIAL.
*              PERFORM frm_add_message USING 'E' '073' lv_msgv '' '' ''.
*            ENDIF.
*
*            "现金流向项目描述
*            IF <fs_qx>-fund_flow IS NOT INITIAL.
*              SELECT SINGLE fund_flowd INTO <fs_qx>-zit_flowd FROM  ztrt9026 WHERE fund_flow = <fs_qx>-fund_flow.
*            ENDIF.
*          ENDLOOP.
*        ENDIF.
*
*      WHEN '50'."贷款合同还款
*
*      WHEN '60'."投资支付
*
*
*      WHEN OTHERS.
*        SELECT SINGLE domvalue_l INTO ls_2001-zywtype FROM dd07t WHERE domname = 'ZDM_TR_YWTYPE' AND domvalue_l = ls_2001-zywtype  .
*        IF sy-subrc <> 0 .
*          PERFORM frm_add_message USING 'E' '011' '' '' '' ''.
*        ENDIF.
*    ENDCASE.
*    IF ls_2001-zfmark = '20' AND ls_2001-zywtype = '10'.
*      DATA: lv_amt     TYPE wrbtr,
*            lv_zbp     TYPE ztr_bp,
*            lv_bwaers  TYPE waers,
*            lv_amt_zfd TYPE wrbtr,ev_ktokk  TYPE ktokk,
*
*            lv_msg     TYPE sy-msgv1.
*      lv_zbp = ls_2001-zskno.
*      "公司本位币
*      SELECT SINGLE waers INTO lv_bwaers FROM t001
*        WHERE bukrs = ls_2001-bukrs.
*      zcl_tr_3021_gui=>get_bp_amt(
*           EXPORTING
*             iv_bukrs = ls_2001-bukrs    " 公司代码
*             iv_zbp   = lv_zbp    " 客商号
*             iv_wkplv = ls_2001-zweplv    " 周版本编号
**             iv_zfd   = ls_output-docno    " 支付单号
*           IMPORTING
*             ev_amt   = lv_amt    " 凭证货币金额
**             ev_waers =     " 货币码
*             ev_ktokk = ev_ktokk "供应商类型
*         ).
*      IF ev_ktokk <> 'S004'.
*        IF ls_2001-zzfwaers = lv_bwaers.
*          lv_amt_zfd = ls_2001-zzfwrbtr.
*        ELSE.
*          CALL FUNCTION 'CONVERT_TO_LOCAL_CURRENCY'
*            EXPORTING
**             CLIENT           = SY-MANDT
*              date             = sy-datum
*              foreign_amount   = ls_2001-zzfwrbtr
*              foreign_currency = ls_2001-zzfwaers
*              local_currency   = lv_bwaers
*            IMPORTING
*              local_amount     = lv_amt_zfd
*            EXCEPTIONS
*              no_rate_found    = 1
*              overflow         = 2
*              no_factors_found = 3
*              no_spread_found  = 4
*              derived_2_times  = 5
*              OTHERS           = 6.
*          IF sy-subrc <> 0.
** Implement suitable error handling here
*          ENDIF.
*        ENDIF.
*
*        IF lv_amt_zfd > lv_amt.
*          lv_msg = lv_amt.
*          CONDENSE lv_msg NO-GAPS.
*          PERFORM frm_add_message USING 'E' '294' lv_msg '' '' ''.
*        ENDIF.
*      ENDIF.
*    ENDIF.
*  ENDIF.
*
**------计划支付日期
*  IF ls_2001-zjhzfrq IS INITIAL.
*    ls_2001-zjhzfrq = sy-datum.
*    PERFORM frm_add_message USING 'W' '016' '' '' '' ''.
*  ENDIF.
*
**支付金额不能为0
*  IF ls_2001-zzfwrbtr <= 0.
*    PERFORM frm_add_message USING 'E' '029' '' '' '' ''.
*  ENDIF.
*
*
**----付款款银行存在性
*  IF lv_fk IS INITIAL AND ls_2003 IS NOT INITIAL.
**，通过简要建获取银行账号，名称等
*    IF ls_2003-hbkid IS NOT INITIAL AND ls_2003-hktid IS NOT INITIAL.
*      SELECT SINGLE * INTO ls_0013 FROM ztrt0013
*        WHERE bukrs = ls_2001-bukrs AND hbkid = ls_2003-hbkid
*         AND hktid = ls_2003-hktid  .
*      IF sy-subrc <> 0.
*        PERFORM frm_add_message USING 'E' '020' '' '' '' ''.
*      ELSE.
*        ls_2003-banks = ls_0013-banks.
*        ls_2003-zfkbankl = ls_0013-bankl.
*        ls_2003-zfkbnkn = ls_0013-yhzh.
*      ENDIF.
*    ELSE.
*      PERFORM frm_add_message USING 'E' '021' '' '' '' ''.
*    ENDIF.
*  ENDIF.
**-----------内地(非香港）银企直联时，校验付款账户与应付账款货币一致
*  SELECT COUNT(*) FROM ztrt2501 WHERE bukrs = ls_2001-bukrs.
*  IF sy-subrc NE 0 AND
*     lt_2004 IS NOT INITIAL AND ls_0013-waers IS NOT INITIAL AND
*    ( ls_2001-zzffs = '30' )." or  ls_2001-zzffs = '53'  or  ls_2001-zzffs = '54'  ).目前只发现 银行转账-银企
*    SELECT  belnr, waers FROM bkpf
*    INTO TABLE @DATA(lt_waers)
*      FOR ALL ENTRIES IN @lt_2004
*  WHERE belnr = @lt_2004-belnr
*    AND gjahr = @lt_2004-gjahr
*    AND bukrs = @ls_2001-bukrs
*    AND waers NE @ls_0013-waers.
*    IF sy-subrc = 0.
*      PERFORM frm_add_message USING 'E' '342' ''  ''  '' ''.
*    ENDIF.
*  ENDIF.
**校验支付金额
*  IF ls_2001-zzfwrbtr > lv_zf.
*    PERFORM frm_add_message USING 'E' '242' '' '' '' ''.
*  ENDIF.
*
**----收款银行
**校验客户/供应商中是否存在相应的银行主数据
*  IF lv_sk IS INITIAL AND ls_2002 IS NOT INITIAL
*    AND ls_2001-zywtype NE '50' "贷款主动支付的收款账户无法校验
*    AND ls_2001-zywtype NE '60'"  投资支付也无法校验
*   " AND ls_2001-zywtype NE '22'"  暂借款也无法校验
*    AND ls_2001-zywtype NE '11'."投标保证金的收款银行不在系统内 20200714 BUG
*
*    IF   ( ls_2002-is_tgzh = 'X' AND ls_2001-zywtype IN zcl_tr_3019_gui=>get_zfsqd_range( )  )  ."  其他支付申请不校验
*      CLEAR ls_2002-is_tgzh .
*    ELSE.
*      PERFORM frm_check_skbank.
*    ENDIF.
*
*  ENDIF.
*
*
**----检查背书汇票
*  IF ls_2001-zbskl = 'A' AND ( ls_2001-zzffs BETWEEN '51' AND '54' )
**  IF ls_2001-zbskl = 'A' AND ( ls_2001-zzffs = '51' OR ls_2001-zzffs = '52' )
*"    AND ( ls_2001-zywtype = '10' OR ls_2001-zywtype = '20' OR ls_2001-zywtype = '30'
*"    or ls_2001-zywtype = '12' OR ls_2001-zywtype = '21' or ls_2001-zywtype = '22' OR ls_2001-zywtype = '25'  ).
*    .
*    PERFORM frm_check_bshp.
*  ELSE.
*    CLEAR lt_2009.
*  ENDIF.
*ENDFORM.
*
*
**&---------------------------------------------------------------------*
**& 校验背书汇票的状态
**&---------------------------------------------------------------------*
*FORM frm_check_bshp.
*  DATA: lv_xh        TYPE i,
*        lv_docno_key TYPE ztr_docno_base,
*        ls_lockhp    TYPE lty_s_lockhp,
*        lv_msgv1     TYPE symsgv,
*        lv_error     TYPE char1,
*        lv_pjtype    TYPE ztr_hptype,
*        lv_msg       TYPE string,
*        lv_msgv2     TYPE symsgv.
*
***可背书票据状态
*  SELECT ztran_status INTO TABLE @DATA(lt_status) FROM ztrt0101 WHERE biz_type = '14' .
*  IF sy-subrc <> 0.
*    PERFORM frm_add_message USING 'E' '037' '' '' '' ''.
*    RETURN.
*  ENDIF.
*
*  CLEAR ls_2008.
*  LOOP AT lt_2009 INTO DATA(ls_2009).
*    IF ls_2009-docno_key IS INITIAL OR ls_2009-zjsno IS INITIAL.
*      PERFORM frm_add_message USING 'E' '024' '' '' '' ''.
*      RETURN.
*    ELSE.
**校验汇票版本是否存在
*      SELECT SINGLE docno_key INTO lv_docno_key FROM ztrt0070 WHERE docno_key = ls_2009-docno_key
*                                                                AND zjsno = ls_2009-zjsno
*                                                                AND bukrs = ls_2001-bukrs.
*      IF sy-subrc <> 0.
**        CALL FUNCTION 'ZFM_LOCK_ZTRT0070'
**          EXPORTING
**            docno_key = ls_2009-docno_key
**            bukrs     = ls_2001-bukrs
**            zjsno     = ls_2009-zjsno
**          IMPORTING
**            ev_error  = lv_error
**            ev_msg    = lv_msg.
**        IF lv_error IS NOT INITIAL.
**          lv_msgv1 = lv_msg.
**          PERFORM frm_add_message USING 'E' '000' lv_msgv1 '' '' ''.
**          RETURN.
**        ELSE.
**          ls_lockhp-docno_key = ls_2009-docno_key.
**          ls_lockhp-zjsno = ls_2009-zjsno.
**          APPEND ls_lockhp TO lt_lockhp.
**        ENDIF.
**      ELSE.
*        lv_msgv1 = ls_2009-docno_key.
*        lv_msgv2 = ls_2009-zjsno.
*        PERFORM frm_add_message USING 'E' '025' lv_msgv1 lv_msgv2 '' ''.
*      ENDIF.
*    ENDIF.
*  ENDLOOP.
*
*  SELECT ztrt0050~docno_key,ztrt0050~draft AS zpj_no,ztrt0050~zboety AS zpj_type,
*         ztrt0050~date_cp AS zcp_date,ztrt0050~date_dq AS zdq_date,ztrt0050~draft_wrbtr AS zhpje,
*         zjsno,ztran_status,bank_ind,bankl,banka
*    INTO TABLE @DATA(lt_key)
*    FROM ztrt0050 INNER JOIN ztrt0070
*    ON ztrt0050~docno_key = ztrt0070~docno_key
*    FOR ALL ENTRIES IN @lt_2009
*    WHERE bukrs = @ls_2001-bukrs AND ztrt0070~docno_key = @lt_2009-docno_key
*      AND ztrt0070~zjsno = @lt_2009-zjsno.
*  CLEAR ls_2008-zbspjje.
*  LOOP AT lt_2009 ASSIGNING FIELD-SYMBOL(<fs_2009>).
*    CASE <fs_2009>-zpj_type.
*      WHEN '10' OR '20'."纸票
*        IF ls_2008-zhptype IS INITIAL.
*          ls_2008-zhptype = '01'.
*        ELSE.
*          IF ls_2008-zhptype = '02'.
*            PERFORM frm_add_message USING 'E' '151' '' '' '' ''.
*            RETURN.
*          ENDIF.
*        ENDIF.
*      WHEN '15' OR '25'."银票
*        IF ls_2008-zhptype IS INITIAL.
*          ls_2008-zhptype = '02'.
*        ELSE.
*          IF ls_2008-zhptype = '01'.
*            PERFORM frm_add_message USING 'E' '151' '' '' '' ''.
*            RETURN.
*          ENDIF.
*        ENDIF.
*      WHEN OTHERS.
*    ENDCASE.
*    lv_xh = lv_xh + 1.
*    <fs_2009>-zxh = lv_xh.
*    READ TABLE lt_key INTO DATA(ls_key) WITH KEY docno_key = <fs_2009>-docno_key
*                                                 zjsno = <fs_2009>-zjsno.
*    IF sy-subrc = 0.
**j校验票据状态  20191226 再次增加状态校验
**      READ TABLE lt_status TRANSPORTING NO FIELDS WITH KEY ztran_status = ls_key-ztran_status.
**      IF sy-subrc <> 0.
**        lv_msgv1 = <fs_2009>-zpj_no.
**        PERFORM frm_add_message USING 'E' '038' lv_msgv1 '' '' ''.
**        CONTINUE.
**      ENDIF.
*      ls_2008-zbspjje = ls_2008-zbspjje + ls_key-zhpje.
*
*      ls_2008-cewrbtr = ls_2001-zzfwrbtr - ls_2008-zbspjje.
*
*      MOVE-CORRESPONDING ls_key TO <fs_2009>.
*    ENDIF.
*  ENDLOOP.
*
*  IF ls_2008-cewrbtr <> 0.
*    PERFORM frm_add_message USING 'E' '063' '' '' '' ''.
*    RETURN.
*  ENDIF.
*ENDFORM.
*
*
*
**&---------------------------------------------------------------------*
**& 校验收款银行是否在主数据中存在
**&---------------------------------------------------------------------*
*FORM frm_check_skbank.
**  DATA: BEGIN OF ls_sys,
**          bankn TYPE bankn,
**          bkref TYPE bkref,
**        END OF ls_sys.
*  DATA: lv_bankn  TYPE bankn,
*        lv_len    TYPE i,
*        lv_bukrs  TYPE bukrs,
*        lv_skbnkn TYPE ztr_skbankn,
*        lv_vbund  TYPE rassc,
*        lv_bkref  TYPE bkref.
*
*  IF ls_2002 IS INITIAL.
*    PERFORM frm_add_message USING 'E' '022' '' '' '' ''.
*  ELSE.
**    lv_len = strlen( ls_2002-zskbnkn ).
**    IF lv_len > 18.
**      lv_bankn = ls_2002-zskbnkn+0(18).
**      lv_len = lv_len - 18.
**      lv_bkref = ls_2002-zskbnkn+18(lv_len).
**    ELSE.
**      lv_bankn = ls_2002-zskbnkn.
**    ENDIF.
**----银行名称
*    SELECT SINGLE banka INTO ls_2002-zskbanka FROM bnka
*      WHERE banks =  ls_2002-banks AND bankl = ls_2002-zskbankl.
*    IF sy-subrc <> 0.
*      PERFORM frm_add_message USING 'E' '229' '' '' '' '' .
*      RETURN.
*    ENDIF.
*    CASE ls_2001-zfmark.
*      WHEN '10'."客户
**        SELECT SINGLE banks, bankl, bankn, bkref, bvtyp INTO @DATA(ls_sys) FROM knbk
**          WHERE kunnr = @ls_2001-zskno AND banks = @ls_2002-banks
**            AND bankl = @ls_2002-zskbankl AND bankn = @lv_bankn
**            AND bkref = @lv_bkref ."AND bvtyp = ls_2002-bvtyp.  "20191104 去除付款类型，可以只根据账户号匹配
*        SELECT SINGLE bankn, bkref, bvtyp  FROM knbk
*        WHERE kunnr = @ls_2001-zskno AND banks = @ls_2002-banks
*        AND bankl = @ls_2002-zskbankl AND bankn && bkref = @ls_2002-zskbnkn
*        INTO @DATA(ls_sys) .
*
*      WHEN '20'."供应商
**        SELECT SINGLE bankn bkref bvtyp INTO CORRESPONDING FIELDS OF ls_sys FROM lfbk
**          WHERE lifnr = ls_2001-zskno AND banks = ls_2002-banks
**            AND bankl = ls_2002-zskbankl AND bankn = lv_bankn
**            AND bkref = lv_bkref.  ." AND bvtyp = ls_2002-bvtyp."20191104 去除付款类型，可以只根据账户号匹配
*        SELECT SINGLE bankn, bkref, bvtyp  FROM lfbk
*        WHERE lifnr = @ls_2001-zskno AND banks = @ls_2002-banks
*         AND bankl = @ls_2002-zskbankl AND bankn && bkref = @ls_2002-zskbnkn
*          INTO CORRESPONDING FIELDS OF @ls_sys.
*      WHEN OTHERS.
*    ENDCASE.
*    IF sy-subrc <> 0.
*      IF  ls_2002-hbkid IS INITIAL OR ls_2002-hktid IS INITIAL .
*        PERFORM frm_add_message USING 'E' '023' '' '' '' '' .
*      ELSE.
*        lv_skbnkn = ls_sys-bankn && ls_sys-bkref.
*        CONDENSE lv_skbnkn NO-GAPS.
*        IF lv_skbnkn <> ls_2002-zskbnkn.
*          DATA lv_m1 TYPE symsgv.
*          lv_m1 = |{ ls_2001-zskno ALPHA = OUT }|.
*          PERFORM frm_add_message USING 'E' '228'   lv_m1   '' '' '' .
*          RETURN.
*        ENDIF.
**对应的公司代码
*        IF ls_2001-zywtype = '30' OR ls_2001-zywtype = '31' OR  ls_2001-zywtype = '40'.
*          CASE ls_2001-zfmark.
*            WHEN '10'."客户
*              SELECT SINGLE vbund INTO lv_vbund FROM kna1
*                WHERE kunnr = ls_2001-zskno.
*            WHEN '20'."供应商
*              SELECT SINGLE vbund INTO lv_vbund FROM lfa1
*                WHERE lifnr = ls_2001-zskno.
*            WHEN OTHERS.
*          ENDCASE.
*          IF sy-subrc = 0.
*            CALL FUNCTION 'CONVERSION_EXIT_MATN1_OUTPUT'
*              EXPORTING
*                input  = lv_vbund
*              IMPORTING
*                output = lv_bukrs.
*
*            SELECT SINGLE * INTO @DATA(ls_0013) FROM ztrt0013
*            WHERE bukrs = @lv_bukrs AND hbkid = @ls_2002-hbkid
*             AND hktid = @ls_2002-hktid.
*            IF sy-subrc <> 0.
*              PERFORM frm_add_message USING 'E' '083' '' '' '' ''.
*            ELSE.
*              ls_2002-banks = ls_0013-banks.
*              ls_2002-zskbankl = ls_0013-bankl.
*              ls_2002-zskbnkn = ls_0013-yhzh.
*              ls_2002-zskwaers = ls_0013-waers.
*              "?合作银行问题
*            ENDIF.
*          ELSE.
*            PERFORM frm_add_message USING 'E' '090' '' '' '' ''.
*          ENDIF.
*        ENDIF.
*      ENDIF.
*    ENDIF.
**** 20191110    由于资金管理平台无付款条件与对方开户行类型，出口控制过账必输 ，故默认填充
*    IF ls_sys-bvtyp IS NOT INITIAL.
*      ls_2002-bvtyp    =   ls_sys-bvtyp.
*      IF ls_2002-zskwaers IS INITIAL.
*        ls_2002-zskwaers =   ls_sys-bvtyp(3).
*      ENDIF.
*    ELSE.
*      PERFORM frm_add_message USING 'E' '318' '' '' '' ''.
*    ENDIF.
**** 20191110    由于资金管理平台无付款条件与对方开户行类型，出口控制过账必输 ，故默认填充
**
*  ENDIF.
*ENDFORM.
*
*
*
**&---------------------------------------------------------------------*
**& 添加信息
**&---------------------------------------------------------------------*
*FORM frm_add_message USING VALUE(msgtyp) TYPE bapi_mtype
*                           VALUE(msgno) TYPE symsgno
*                           VALUE(msgv1) TYPE symsgv
*                           VALUE(msgv2) TYPE symsgv
*                           VALUE(msgv3) TYPE symsgv
*                           VALUE(msgv4) TYPE symsgv.
*  DATA ls_return TYPE bapiret2.
*  ls_return-type = msgtyp.
*  ls_return-id = 'ZTR05'.
*  ls_return-number = msgno.
*  ls_return-message_v1 = msgv1.
*  ls_return-message_v2 = msgv2.
*  ls_return-message_v3 = msgv3.
*  ls_return-message_v4 = msgv4.
*  CONDENSE ls_return-message_v1 NO-GAPS.
*  CONDENSE ls_return-message_v2 NO-GAPS.
*  CONDENSE ls_return-message_v3 NO-GAPS.
*  CONDENSE ls_return-message_v4 NO-GAPS.
*  APPEND ls_return TO lt_return.
*
*ENDFORM.
*
**&---------------------------------------------------------------------*
**& 保存支付单
**&---------------------------------------------------------------------*
*FORM frm_save_zfd CHANGING cv_docno TYPE ztr_zfdocno.
*
*  DATA lv_type TYPE ztr_doctype.
*
*  lv_type = ls_2001-zzftype.
*  CALL FUNCTION 'ZFM_GET_RANGE_NR'
*    EXPORTING
*      iv_doctype     = lv_type
*      iv_config_type = 'P0'
*    IMPORTING
*      ev_docno       = ls_2001-docno.
*
*  ls_2001-erdat = sy-datum.
*  ls_2001-erzet = sy-uzeit.
*  ls_2001-ernam = sy-uname.
*  ls_2001-zzfstatus = '10'.
*
*  IF ls_2002 IS NOT INITIAL.
*    ls_2002-docno = ls_2001-docno.
*  ENDIF.
*
*  IF ls_2003 IS NOT INITIAL.
*    ls_2003-docno = ls_2001-docno.
*  ENDIF.
*****start-SSF Plugin-Chengangrong
****  支付单加密
*
*  IF zcl_captical_encryptor=>if_from_webdynpro( ) = space.
*    CALL FUNCTION 'ZFM_TR_PAYMORDER_ENCRYPTION_S'
*      EXPORTING
*        im_s_2001      = ls_2001
*        im_s_2002      = ls_2002
*        im_s_2003      = ls_2003
*        im_commit_work = space
*      IMPORTING
*        ex_ssfuuid     = ls_2001-ssfuuid
*      EXCEPTIONS
*        error          = 1
*        OTHERS         = 2.
*  ELSE.
*    CALL FUNCTION 'ZFM_TR_PAYMORD_ENCRY_FROM_WDS'
*      EXPORTING
*        im_s_2001        = ls_2001
*        im_s_2002        = ls_2002
*        im_s_2003        = ls_2003
*        im_zzftype       = ls_2001-zzftype
*      IMPORTING
*        ex_ssfuuid       = ls_2001-ssfuuid
*      EXCEPTIONS
*        user_not_found   = 1
*        cant_create_mode = 2
*        ssf_error        = 3
*        enqueue_error    = 4
*        OTHERS           = 5.
*  ENDIF.
*  IF sy-subrc <> 0.
*    MESSAGE ID sy-msgid
*            TYPE sy-msgty
*            NUMBER sy-msgno
*            WITH sy-msgv1
*                 sy-msgv2
*                 sy-msgv3
*                 sy-msgv4
*            INTO DATA(l_dummy).
*    APPEND VALUE #( id = sy-msgid
*                    number = sy-msgno
*                    type = 'E'
*                    message_v1 = sy-msgv1
*                    message_v2 = sy-msgv2
*                    message_v3 = sy-msgv3
*                    message_v4 = sy-msgv4
*                    message = l_dummy ) TO lt_return.
**    出错了，不保存支付单
*    RETURN.
*  ENDIF.
*****End-SSF Plugin-Chengangrong
*
*  CASE ls_2001-zywtype.
*    WHEN '10' OR '11'."挂账
*      LOOP AT lt_2004 ASSIGNING FIELD-SYMBOL(<fs_2004>).
*        <fs_2004>-docno = ls_2001-docno.
*      ENDLOOP.
*      "WHEN '20' OR '30' OR '31' OR '32' OR '40' OR '33' OR '50' OR '60'. change 20200609
*    WHEN '12' OR '13'.
*      LOOP AT lt_2004 ASSIGNING  <fs_2004> .
*        <fs_2004>-docno = ls_2001-docno.
*      ENDLOOP.
*      LOOP AT lt_2005 ASSIGNING FIELD-SYMBOL(<fs_2005>).
*        <fs_2005>-docno = ls_2001-docno.
*      ENDLOOP.
*    WHEN OTHERS.
*      LOOP AT lt_2005 ASSIGNING  <fs_2005> .
*        <fs_2005>-docno = ls_2001-docno.
*      ENDLOOP.
*  ENDCASE.
*
*  IF ( ls_2001-zzffs BETWEEN '51' AND '54' )  AND ls_2001-zbskl = 'A'."只有创建背书才有票据相关
**  IF ( ls_2001-zzffs = '51' OR ls_2001-zzffs = '52' )  AND ls_2001-zbskl = 'A'."只有创建背书才有票据相关
*    ls_2008-docno = ls_2001-docno.
*    LOOP AT lt_2009 ASSIGNING FIELD-SYMBOL(<fs_2009>).
*      <fs_2009>-docno = ls_2001-docno.
*    ENDLOOP.
*  ENDIF.
*
*  IF ( ls_2001-zywtype = '40' OR auto_apro = abap_true ) AND ls_2001-zzffs = '30'."资金平台-自动审批（银企直连）
*    ls_2001-zzfstatus = '13'."审批通过
*  ENDIF.
*  MODIFY ztrt2001 FROM ls_2001.
*  IF ls_2002 IS NOT INITIAL.
*    MODIFY ztrt2002 FROM ls_2002.
*  ENDIF.
*
*  IF ls_2003 IS NOT INITIAL.
*    MODIFY ztrt2003 FROM ls_2003.
*  ENDIF.
*
**  CASE ls_2001-zywtype.   change 20210428
**    WHEN '10' OR '11'."挂账
**      MODIFY ztrt2004 FROM TABLE lt_2004.
**      "  WHEN '20' OR '30' OR '31' OR '32' OR '40' OR '33' OR '50' OR '60'.change 20200609
**    WHEN '12'.
**      MODIFY ztrt2004 FROM TABLE lt_2004.
**      MODIFY ztrt2005 FROM TABLE lt_2005.
**    WHEN OTHERS.
**      MODIFY ztrt2005 FROM TABLE lt_2005.
**  ENDCASE.
*
*  MODIFY ztrt2004 FROM TABLE lt_2004.
*  MODIFY ztrt2005 FROM TABLE lt_2005.
*
*  IF ( ls_2001-zzffs BETWEEN '51' AND '54' ) AND ls_2001-zbskl = 'A'.
**  IF ( ls_2001-zzffs = '51' OR ls_2001-zzffs = '52') AND ls_2001-zbskl = 'A'.
*    MODIFY ztrt2008 FROM ls_2008.
*    MODIFY ztrt2009 FROM TABLE lt_2009.
**更改背书状态
*    IF lt_2009 IS NOT INITIAL.
*      SELECT * INTO TABLE @DATA(lt_0070) FROM ztrt0070
*        FOR ALL ENTRIES IN @lt_2009
*        WHERE bukrs = @ls_2001-bukrs AND docno_key = @lt_2009-docno_key
*          AND zjsno = @lt_2009-zjsno.
*      IF sy-subrc = 0.
*        LOOP AT lt_0070 ASSIGNING FIELD-SYMBOL(<fs_0070>).
*          <fs_0070>-ztran_status = '140'."票据支付申请录入
*        ENDLOOP.
*        MODIFY ztrt0070 FROM TABLE lt_0070.
*      ENDIF.
*    ENDIF.
*  ENDIF.
*  cv_docno = ls_2001-docno.
*
******start - chengangrong
**  COMMIT WORK.
*  COMMIT WORK AND WAIT.
**  IF ls_2001-ssfuuid IS NOT INITIAL.
***    有可能没有完成更新，理论上会导致的问题：
***    在同一个SESSION中这个子程序完成后，如果后续会对支付单状态进行修改（例如马上发送银企直连），那么需要重新加密
***    如果本次更新没实际完成会导致后面的重新加密产生新的加密UUID，从而导致一个支付单对应两个加密UUID
***    这样会继续导致以后对支付单verify校验时出现“一个支付单对应两个加密UUID“的报错
***
***    目前只有资金集中平台的销售公司转工厂TT划款会有支付单创建后马上发送银企直连的情况
***    这个业务场景将不考虑加密，因此实际上应该不会出现需要两次加密的情况
**    zcl_captical_encryptor=>check_uuid_if_updated( ls_2001-ssfuuid ).
**  ENDIF.
******end - chengangrong
*
*ENDFORM.
*
**&---------------------------------------------------------------------*
**& 解锁已经加锁的东西
**&---------------------------------------------------------------------*
*FORM frm_unlock_all.
*  IF lt_lockw IS NOT INITIAL.
*    LOOP AT lt_lockw INTO DATA(ls_lockw).
*      zcl_tr_3019_gui=>unlock_witem(
*         EXPORTING
*           iv_bguid =  ls_lockw-bguid   " 'CHAR' 格式的大写的 GUID
*           iv_itemn =  ls_lockw-itemn   " 资金计划项目
*         EXCEPTIONS
*           err      = 1
*           OTHERS   = 2
*       ).
*    ENDLOOP.
*  ENDIF.
*
*  IF lt_lockhp IS NOT INITIAL.
*    LOOP AT lt_lockhp INTO DATA(ls_lockhp).
*      CALL FUNCTION 'ZFM_UNLOCK_ZTRT0070'
*        EXPORTING
*          docno_key = ls_lockhp-docno_key
*          bukrs     = ls_2001-bukrs
*          zjsno     = ls_lockhp-zjsno.
*    ENDLOOP.
*  ENDIF.
*
*  CLEAR: ls_2001,ls_2002,ls_2003,lt_2005,lt_2005,lt_lockw,lt_lockhp.
*
*ENDFORM.
*
**&---------------------------------------------------------------------*
**& 发送支付单
**&---------------------------------------------------------------------*
*FORM frm_send_pay_order.
*  DATA: lt_pays TYPE ztrs_paymentorder_list_tab,
*        ls_2099 TYPE ztrt2099, "日志
*        ls_pays TYPE ztrs_paymentorder_list.
*****start-SSF Plugin-Chengangrong
*  DATA: l_new_status TYPE ztrt2001-zzfstatus VALUE '24'.
*  CALL FUNCTION 'ZFM_TR_PAYMORDER_COMPARION_S'
*    EXPORTING
*      im_docno   = ls_2001-docno
*      im_zzftype = ls_2001-zzftype
*    EXCEPTIONS
*      error      = 1
*      OTHERS     = 2.
*  IF sy-subrc <> 0.
*    MESSAGE ID sy-msgid
*            TYPE sy-msgty
*            NUMBER sy-msgno
*            WITH sy-msgv1
*                 sy-msgv2
*                 sy-msgv3
*                 sy-msgv4
*            INTO DATA(l_dummy).
*    APPEND VALUE #( id = sy-msgid
*                    number = sy-msgno
*                    type = sy-msgty
*                    message_v1 = sy-msgv1
*                    message_v2 = sy-msgv2
*                    message_v3 = sy-msgv3
*                    message_v4 = sy-msgv4
*                    message = l_dummy ) TO lt_return.
*    l_new_status = '21'. "作废
*  ENDIF.
*****End-SSF Plugin-Chengangrong
**先加锁支付单
*  CALL FUNCTION 'ZFM_LOCK_ZTRT2001'
*    EXPORTING
*      iv_docno = ls_2001-docno.
**  ls_pays-paymorder = ls_2001-docno.
**  APPEND ls_pays TO lt_pays.
**  CALL FUNCTION 'ZFM_TR_BANK_MEDIUM_PAYMENT_API'
**    STARTING NEW TASK ls_2001-docno
**    DESTINATION 'NONE'
**    EXPORTING
**      im_t_order_list = lt_pays.
*
*
*  ls_2099-docno = ls_2001-docno.
*  ls_2099-erdat = sy-datum.
*  ls_2099-erzet = sy-uzeit.
*  ls_2099-zaction = 'C'.
*  ls_2099-userid = 'ADMIN'.
*  ls_2099-old_status = '13'.
*****start-SSF Plugin-Chengangrong
**  ls_2099-new_stauts = '24'.
*  ls_2099-new_stauts = l_new_status.
*****End-SSF Plugin-Chengangrong
*  MODIFY ztrt2099 FROM ls_2099.
*
**跟新支付单状态
*****start-SSF Plugin-Chengangrong
**  UPDATE ztrt2001 SET zzfstatus = '24' WHERE docno = ls_2001-docno.
*  UPDATE ztrt2001
*         SET zzfstatus = l_new_status
*         WHERE docno = ls_2001-docno.
*****End-SSF Plugin-Chengangrong
*
**银企直连需要支付单的状态为24(已支付)才执行发送银行
*  ls_pays-paymorder = ls_2001-docno.
*  APPEND ls_pays TO lt_pays.
*  CALL FUNCTION 'ZFM_TR_BANK_MEDIUM_PAYMENT_API'
*    STARTING NEW TASK ls_2001-docno
*    DESTINATION 'NONE'
*    EXPORTING
*      im_t_order_list = lt_pays.
*
**解锁支付单
*  CALL FUNCTION 'ZFM_UNLOCK_ZTRT2001'
*    EXPORTING
*      iv_docno = ls_2001-docno.
*  COMMIT WORK.
*ENDFORM.
**&---------------------------------------------------------------------*
**&      Form  UPDATE_BANK_IND
**&---------------------------------------------------------------------*
**       text
**----------------------------------------------------------------------*
**      -->P_LS_TR0014_BANKS  text
**      -->P_LS_TR0014_BANKL  text
**      -->P_LS_TR0014_BANK_IND  text
**----------------------------------------------------------------------*
*FORM update_bank_ind  USING    u_banks TYPE bnka-banks
*                               u_bankl TYPE bnka-bankl
*                               u_bank_ind TYPE bnka-bank_ind.
**  DO 1000 TIMES.
**    SELECT COUNT( * ) INTO @DATA(l_count)
**           FROM bnka
**           WHERE banks = @u_banks
**           AND   bankl = @u_bankl.
**    IF sy-subrc = 0.
**      UPDATE bnka SET bank_ind = u_bank_ind
**             WHERE banks = u_banks
**             AND   bankl = u_bankl.
**      exit.
**    ELSE.
**      WAIT UP TO '0.1' SECONDS.
**    ENDIF.
**  ENDDO.
*
*  DATA(l_task) = u_banks && u_bankl.
*  CALL FUNCTION 'ZFM_TR_UPD_BANK_IND_TO_BNKA'
*    STARTING NEW TASK l_task
*    DESTINATION 'NONE'
*    EXPORTING
*      im_banks    = u_banks
*      im_bankl    = u_bankl
*      im_bank_ind = u_bank_ind.
*
*ENDFORM.
