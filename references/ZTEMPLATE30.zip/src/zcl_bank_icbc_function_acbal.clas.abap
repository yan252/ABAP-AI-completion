class ZCL_BANK_ICBC_FUNCTION_ACBAL definition
  public
  inheriting from ZCL_BANK_FUNCTION_ACCBALANCE
  final
  create public .

public section.

  interfaces ZIF_ICBC_FUNCTION .

  aliases GET_CURRENT_PACKAGE_ID
    for ZIF_ICBC_FUNCTION~GET_CURRENT_PACKAGE_ID .
protected section.

  methods PROCESSING_RESPONSE_INTL_CORE
    redefinition .
private section.
ENDCLASS.



CLASS ZCL_BANK_ICBC_FUNCTION_ACBAL IMPLEMENTATION.


  METHOD processing_response_intl_core.
    CASE action.
      WHEN zif_bank_action=>action_is_account_balance.
*        当前余额
        processing_response_by_dbtable(
                    im_data_db_table = 'ZTRT_ICBC_ACBAL'
                    im_detail_response_component = 'OUT'
                    im_statuscode_componnet = 'PUB-RETCODE'
                    im_statustext_component = 'PUB-RETMSG'
                    im_db_account_number_field = 'ACCNO'
                    im_bank_entry_accnumber_field = 'ACCNO'  ).
      WHEN zif_bank_action=>action_is_acc_history_balance.
*        历史余额
        processing_response_by_dbtable(
                    im_data_db_table = 'ZTRT_ICBC_HACBAL'
                    im_detail_response_component = 'OUT-RD'
                    im_statuscode_componnet = 'PUB-RETCODE'
                    im_statustext_component = 'PUB-RETMSG'
                    im_db_account_number_field = 'ACCNO'
                    im_bank_entry_accnumber_field = ''  ).
    ENDCASE.
  ENDMETHOD.


  method ZIF_ICBC_FUNCTION~GET_CURRENT_PACKAGE_ID.
    INCLUDE ztri_bank_icbc_func_packageid.
  endmethod.
ENDCLASS.
