class ZCL_BANK_FILE_ADJUSTER definition
  public
  abstract
  create public .

public section.

  interfaces ZIF_RESPONSE_FILE_ADJUSTER .
  interfaces ZIF_SENDING_FILE_ADJUSTER .

  aliases ADJUST_FUNCTION_SENDING_FILES
    for ZIF_SENDING_FILE_ADJUSTER~ADJUST .
  aliases ADJUST_RESPONSE_CLIENT_DATA
    for ZIF_RESPONSE_FILE_ADJUSTER~ADJUST .

  methods CONSTRUCTOR
    importing
      !IM_BANK_INDICATOR type ZTR_BANK_INDICATOR .
  class-methods GET_SENDING_ADJUSTER
    importing
      !IM_BANK_INDICATOR type ZTR_BANK_INDICATOR
    returning
      value(RO_INSTANCE) type ref to ZIF_SENDING_FILE_ADJUSTER .
  class-methods GET_RESPONSE_ADJUSTER
    importing
      !IM_BANK_INDICATOR type ZTR_BANK_INDICATOR
    returning
      value(RO_INSTANCE) type ref to ZIF_RESPONSE_FILE_ADJUSTER .
  class-methods CREATE
    importing
      !IM_BANK_INDICATOR type ZTR_BANK_INDICATOR
    returning
      value(RO_INSTANCE) type ref to ZCL_BANK_FILE_ADJUSTER .
protected section.

  data BANK_INDICATOR type ZTR_BANK_INDICATOR .
  class-data INSTANCE type ref to ZCL_BANK_FILE_ADJUSTER .

  methods GET_CURRENT_SENDING_DATA_REF
    importing
      !IM_STEP type ZTR_APP_ACTION_STEP
    returning
      value(RO_REFERENCE) type ref to DATA .
private section.

  methods IF_SAME_BANK
    importing
      !IM_NEW_BANK_INDICATOR type ZTR_BANK_INDICATOR
    returning
      value(RE_SAME) type FLAG .
ENDCLASS.



CLASS ZCL_BANK_FILE_ADJUSTER IMPLEMENTATION.


  METHOD CONSTRUCTOR.
    bank_indicator = im_bank_indicator.
  ENDMETHOD.


  METHOD create.

    IF instance IS BOUND.
      IF instance->if_same_bank( im_bank_indicator ) = space.
*        已经是新的银行了，上次的调整器不再适用
        free instance.
      ENDIF.
    ENDIF.

    IF instance IS NOT BOUND.
      SELECT SINGLE file_adjust_class INTO @DATA(l_class)
             FROM ztrt_bank
             WHERE bank_ind = @im_bank_indicator.
      IF l_class IS INITIAL.
        RETURN.
      ENDIF.

      CREATE OBJECT instance TYPE (l_class)
             EXPORTING
               im_bank_indicator = im_bank_indicator.
    ENDIF.

    ro_instance = instance.

  ENDMETHOD.


  METHOD get_current_sending_data_ref.
    ro_reference =
           zcl_bank_abstract_action=>get_action(                    "get current running action
                             )->get_bank( bank_indicator         "get current running bank
                                        )->get_bank_function( im_step
                                               )->get_sending_data_reference( ).
  ENDMETHOD.


  METHOD get_response_adjuster.
    ro_instance ?= create( im_bank_indicator ).
  ENDMETHOD.


  METHOD GET_SENDING_ADJUSTER.
    ro_instance ?= create( im_bank_indicator ).
  ENDMETHOD.


  METHOD if_same_bank.
    IF bank_indicator = im_new_bank_indicator.
      re_same = 'X'.
    ELSE.
      re_same = space.
    ENDIF.

  ENDMETHOD.


  METHOD zif_response_file_adjuster~adjust.
    ex_cdata = im_original_cdata.
    ex_xdata = im_original_xdata.

  ENDMETHOD.


  method ZIF_SENDING_FILE_ADJUSTER~ADJUST.
  endmethod.
ENDCLASS.
