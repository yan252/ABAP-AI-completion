*----------------------------------------------------------------------*
***INCLUDE LZFG_TR_BANKF01.
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  SET_DBADMIN
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_us_system_info  text
*      -->P_L_ENTRY_COUNT  text
*      <--P_LS_NEW_ENTRY_DBADMIN  text
*----------------------------------------------------------------------*
FORM set_dbadmin  USING    us_system_info TYPE zbcs_system_info
                           us_db_admin TYPE ztrs_dbadmin
                           u_db_count TYPE sydbcnt
                  CHANGING cs_dbadmin TYPE ztrs_dbadmin.
  MOVE: us_system_info-timestamp TO cs_dbadmin-update_timestamp,
        us_system_info-timezone TO cs_dbadmin-update_timezone.
  IF u_db_count <= 0.
    MOVE: us_system_info-datum TO cs_dbadmin-erdat,
          us_system_info-uzeit TO cs_dbadmin-erzet,
          us_system_info-uname TO cs_dbadmin-ernam.
  ELSE.
    MOVE: us_db_admin-erdat TO cs_dbadmin-erdat,
          us_db_admin-erzet TO cs_dbadmin-erzet,
          us_db_admin-ernam TO cs_dbadmin-ernam.

    MOVE: us_system_info-datum TO cs_dbadmin-aedat,
          us_system_info-uzeit TO cs_dbadmin-aezet,
          us_system_info-uname TO cs_dbadmin-aenam.
  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  FRM_GET_UPLOAD_FILE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      <--P_LV_FILE_PATH  text
*----------------------------------------------------------------------*
FORM frm_get_upload_file CHANGING ctp_file TYPE rlgrap-filename. "#EC CALLED
  DATA: ltp_full_file_path TYPE string,
        ltp_user_action    TYPE i.

  CALL FUNCTION 'GUI_FILE_LOAD_DIALOG'
    IMPORTING
      fullpath    = ltp_full_file_path
      user_action = ltp_user_action.

  IF ltp_user_action NE '0'.
    MESSAGE s095(ztr_bank_application).
    EXIT.
  ELSE.
    ctp_file = ltp_full_file_path.
  ENDIF.
ENDFORM.                    " FRM_GET_UPLOAD_FILE
*&---------------------------------------------------------------------*
*&      Form  SPLIT_PAYMENT_BY_ACTION
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_IM_T_ORDER_LIST  text
*      <--P_LT_ORDER_LIST_001  text
*      <--P_LT_ORDER_LIST_M01  text
*----------------------------------------------------------------------*
*FORM split_payment_by_action  USING    ut_order_list TYPE ztrs_paymentorder_list_tab
*                              CHANGING ct_order_list_001 TYPE ztrs_paymentorder_list_tab
*                                       ct_order_list_m01 TYPE ztrs_paymentorder_list_tab.
*  DATA: lt_order_list_m01_key TYPE ztrs_paymentorder_list_tab.
*
*
*  SELECT docno,
*         zzftype
*         INTO TABLE @DATA(lt_2001)
*         FROM ztrt2001
*         FOR ALL ENTRIES IN @ut_order_list
*         WHERE docno = @ut_order_list-paymorder.
*
*  LOOP AT ut_order_list INTO DATA(ls_order_list).
*    READ TABLE lt_2001 INTO DATA(ls_2001)
*         WITH KEY docno = ls_order_list-paymorder.
*    CLEAR ls_order_list-draft_zxh.
*    IF ls_2001-zzftype = 'P005'.
*      APPEND ls_order_list TO lt_order_list_m01_key.
*    ELSE.
*      APPEND ls_order_list TO ct_order_list_001.
*    ENDIF.
*  ENDLOOP.
*
*  IF lt_order_list_m01_key IS NOT INITIAL.
*    SORT lt_order_list_m01_key BY paymorder.
*    DELETE ADJACENT DUPLICATES FROM lt_order_list_m01_key COMPARING paymorder.
*    SELECT docno,
*           zxh
*           INTO TABLE @DATA(lt_2009)
*           FROM ztrt2009
*           FOR ALL ENTRIES IN @lt_order_list_m01_key
*           WHERE docno = @lt_order_list_m01_key-paymorder.
*    LOOP AT lt_order_list_m01_key INTO ls_order_list.
*      LOOP AT lt_2009 INTO DATA(ls_2009)
*           WHERE docno = ls_order_list-paymorder.
*        APPEND VALUE #( paymorder = ls_2009-docno
*                        draft_zxh = ls_2009-zxh )
*                      TO ct_order_list_m01.
*      ENDLOOP.
*      IF sy-subrc <> 0.
**      不应该出现这样的错误
**      让这个记录过去，在后续的处理中报错和进行日志记录
*        APPEND ls_order_list TO ct_order_list_m01.
*      ENDIF.
*    ENDLOOP.
*  ENDIF.
*
*ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  BANK_PAYMENT_INTERFACE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_LT_ORDER_LIST_001  text
*      -->P_ZIF_BANK_ACTION=>ACTION_IS_PAY  text
*----------------------------------------------------------------------*
*FORM bank_payment_interface  USING ut_order_list TYPE ztrs_paymentorder_list_tab
*                                    u_action TYPE ztr_app_action_for_bank.
*******  log
*  IF zcl_bank_logger_protocal=>receive_paymorder_in_api(
*                                im_action       = zif_bank_action=>action_is_payment
*                                im_t_order_list = ut_order_list ) = space.
*    RETURN.
*  ENDIF.
*******  log end
*  DATA(lo_action) = zcl_bank_abstract_action=>create( u_action ).
*  IF lo_action IS BOUND.
*    lo_action->set_entries( ut_order_list ).
*    lo_action->run( ).
*  ENDIF.
*  zcl_bank_logger_protocal=>end_logs( u_action ).
*ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  CHECK_PAYMORDER_STATUS_IN_DB
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_IM_T_ORDER_LIST  text
*----------------------------------------------------------------------*
*FORM check_paymorder_status_in_db  USING    ut_order_list TYPE ztrs_paymentorder_list_tab.
*  DATA: lt_order_list TYPE ztrs_paymentorder_list_tab.
*
*  lt_order_list = ut_order_list.
*  SORT lt_order_list BY paymorder.
*  DELETE ADJACENT DUPLICATES FROM lt_order_list COMPARING paymorder.
*
*******  支付平台在调用银企直连的时候支付单状态有可能没完成更新数据库
*******  会导致银企直连报错
*******  这个子程序检查支付单的状态是否真正更新了
*******  循环1000次，如果10000次循环都还没更新完数据库，只能让银企直连报错了
*  DO 1000 TIMES.
*    LOOP AT lt_order_list INTO DATA(ls_order).
*      SELECT SINGLE zzfstatus INTO @DATA(l_status)
*              FROM ztrt2001
*              WHERE docno = @ls_order-paymorder.
*      IF l_status = '24'.
*        DELETE lt_order_list WHERE paymorder = ls_order-paymorder.
*      ENDIF.
*    ENDLOOP.
*    IF lt_order_list IS INITIAL.
*      EXIT.
*    ENDIF.
*  ENDDO.
*ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  SET_PAYMENT_ORDER_BUFFER
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_IM_T_PAYMORDER_BUFFER  text
*----------------------------------------------------------------------*
FORM set_payment_order_buffer  USING
            ut_paymorder_buffer TYPE ztrs_paymorder_buffer_tab.
  gt_paymorder_buffer = ut_paymorder_buffer.
  SORT gt_paymorder_buffer BY docno.
  DELETE ADJACENT DUPLICATES FROM gt_paymorder_buffer COMPARING ALL FIELDS.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  SET_PAYORD_TO_RANGE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_IM_T_PAYMORDER_BUFFER  text
*      <--P_LT_PAYMORDER_RANGE  text
*----------------------------------------------------------------------*
FORM set_payord_to_range
       USING ut_paymorder_buffer TYPE ztrs_paymorder_buffer_tab
    CHANGING ct_paymorder_range TYPE ztrt_paymorder_range.

  CALL FUNCTION 'ZFM_TR_SET_PAYMORDER_BUFFER'
    EXPORTING
      im_t_paymorder_buffer = ut_paymorder_buffer.

  CALL FUNCTION 'ZFM_TR_PAYMORD_BUFFER_TO_RANGE'
    IMPORTING
      et_range = ct_paymorder_range.
ENDFORM.
