FUNCTION ZFM_TR_CCB_UPDATE_TRANS_PAGE.
*"--------------------------------------------------------------------
*"*"更新函数模块：
*"
*"*"局部接口：
*"  IMPORTING
*"     VALUE(IM_S_PAGE) TYPE  ZTRT_CCB_TRNS_P
*"--------------------------------------------------------------------
MODIFY ztrt_ccb_trns_p FROM im_s_page.





ENDFUNCTION.
