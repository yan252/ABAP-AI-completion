@AbapCatalog.sqlViewName: 'ZTRCDS9040'
@AbapCatalog.compiler.compareFilter: true
@AccessControl.authorizationCheck: #CHECK 
@EndUserText.label: '组织架构配置表'
define view ZDDL_SOURCE_9040
as select from ztrt9040_1
{
mandt,
'    ' as BUKRS_UP,
bukrs,
burks_type,
bp_mode,
lclx,
date_tolerance,
ope_state,
online_dat,
zcontact,
zaddr_tel,
erdat,
erzet,
ernam,
aedat,
aezet,
aenam
}
union
select from ztrt9040_2
{
mandt,
bukrs_up,
bukrs,
burks_type,
bp_mode,
lclx,
date_tolerance,
ope_state,
online_dat,
zcontact,
zaddr_tel,
erdat,
erzet,
ernam,
aedat,
aezet,
aenam
}
union
select from ztrt9040_3
{
mandt,
bukrs_up,
bukrs,
burks_type,
bp_mode,
lclx,
date_tolerance,
ope_state,
online_dat,
zcontact,
zaddr_tel,
erdat,
erzet,
ernam,
aedat,
aezet,
aenam
}
union
select from ztrt9040_4
{
mandt,
bukrs_up,
bukrs,
burks_type,
bp_mode,
lclx,
date_tolerance,
ope_state,
online_dat,
zcontact,
zaddr_tel,
erdat,
erzet,
ernam,
aedat,
aezet,
aenam
}
union
select from ztrt9040_5
{
mandt,
bukrs_up,
bukrs,
burks_type,
bp_mode,
lclx,
date_tolerance,
ope_state,
online_dat,
zcontact,
zaddr_tel,
erdat,
erzet,
ernam,
aedat,
aezet,
aenam
} 
 
  
 