class ZCL_ABSTRACT_BANK definition
  public
  abstract
  create public .

public section.

  interfaces ZIF_BANK .
  interfaces ZIF_MESSAGES .

  aliases CREATE
    for ZIF_BANK~CREATE .
  aliases EXPORT_AFTER_PROCESSED
    for ZIF_BANK~EXPORT_AFTER_PROCESSED .
  aliases GET_BANK_FUNCTION
    for ZIF_BANK~GET_BANK_FUNCTION .
  aliases GET_ENVIROMENT
    for ZIF_BANK~GET_ENVIROMENT .
  aliases IF_ERROR
    for ZIF_BANK~IF_ERROR .
  aliases MESSAGES_COPY_FROM_OBJECT
    for ZIF_MESSAGES~MESSAGES_COPY_FROM_OBJECT .
  aliases PUBLISH_MESSAGES
    for ZIF_MESSAGES~PUBLISH_MESSAGES .
  aliases RUN
    for ZIF_BANK~RUN .
  aliases SET_SINGLE_ENTRY
    for ZIF_BANK~SET_SINGLE_ENTRY .

  methods CONSTRUCTOR
    importing
      !IM_BANK_INDICATOR type ZTR_BANK_INDICATOR
      !IM_ACTION type ZTR_APP_ACTION_FOR_BANK
    exceptions
      CREATE_UUID_ERROR
      ACTION_ERROR .
protected section.

  constants YES type FLAG value 'X' ##NO_TEXT.
  constants NO type FLAG value SPACE ##NO_TEXT.
  data BANK_INDICATOR type ZTR_BANK_INDICATOR .
  data MESSAGES type ref to ZCL_MESSAGE_COLLECTOR .
  data INSTANCE_UUID type SYSUUID_C22 .
  data SENDING_ENTRIES_REFERENCE type ZTRS_SENDING_DATA_REFERENCE_T .
  data RESPONSE_DATA type ZTRS_BANK_RESPONSE_TAB .
  class-data DUMMY_MESSAGE type STRING .
  data ERROR_STEP type ZTRS_ERROR_STEP .
  data INSTANCE_INTERNAL_ERROR type ZTR_ERROR_CODE_IN_BANKINSTANCE value '01' ##NO_TEXT.
  data FILE_ERROR type ZTR_ERROR_CODE_IN_BANKINSTANCE value '02' ##NO_TEXT.
  data FILE_SENDING_ERROR type ZTR_ERROR_CODE_IN_BANKINSTANCE value '03' ##NO_TEXT.
  data RESPONSE_ERROR type ZTR_ERROR_CODE_IN_BANKINSTANCE value '04' ##NO_TEXT.
  data RFC_INIT_ERROR type ZTR_ERROR_CODE_IN_BANKINSTANCE value '05' ##NO_TEXT.
  data CURRENT_PROCESSING_STEP type ZTR_APP_ACTION_STEP .
  data ACTION_TEXT type DD07V-DDTEXT .
  data ENVIROMENT type ref to ZCL_BANK_ENVIROMENT .
  data CURRENT_ACTION type ZTR_APP_ACTION_FOR_BANK .
  data STEP_FUNCTIONS type ZTRS_BANK_STEP_FUNCTION_TAB .
  data CURRENT_DESTINATION type RFCDEST .
  data CURRENT_LINKAGE_ADDRESS type STRING .

  methods SET_ERROR_STEP
    importing
      !IM_INSTANCE_ERROR_CODE type ZTR_ERROR_CODE_IN_BANKINSTANCE .
  methods SET_PROCESSING_STEP
    importing
      !IM_STEP type ZTR_APP_ACTION_STEP optional .
  methods COPY_ENVIROMENT_ERROR_MESSAGES
    importing
      !IM_ERROR_CODE type ZTR_ERROR_CODE_IN_BANKINSTANCE .
  methods SEND
    returning
      value(RE_SEND) type FLAG .
  methods RECEIVE_FROM_CLIENT .
  methods INIT_CLIENT
    importing
      !IM_CURRENT_DESTINATION type ZTR_RFCDEST
      !IM_LINKAGE_ADDRESS type STRING optional .
  methods CREATE_CLIENT
    importing
      !IM_DESTINATION type ZTR_RFCDEST
      !IM_CREATE_BY_URL type FLAG optional
      !IM_LINKAGE_ADDRESS type STRING optional .
  methods DESTROY_CLIENT .
  methods SET_BANK_FUNCTION
    returning
      value(RO_INSTANCE) type ref to ZIF_BANK_FUNCTION .
  methods RUN_FUNCTION .
  methods START_RUNNING
    returning
      value(RE_ERROR) type FLAG .
  methods END_RUNNING .
  methods RUN_CORE .
  methods START_SENDING
    exporting
      !EX_CFILE_REF type ref to DATA
      !EX_XFILE_REF type ref to DATA
      !EX_FILE_UUID type SYSUUID_C22
      !EX_SENDING_SEQUENCE type INT4
      !EX_STOP_FLAG type FLAG .
  methods END_SENDING
    importing
      !IM_CFILE_REF type ref to DATA
      !IM_XFILE_REF type ref to DATA
      !IM_FILE_UUID type SYSUUID_C22
      !IM_SENDING_SEQUENCE type INT4 .
  methods SEND_CORE
    importing
      !IM_CFILE_REF type ref to DATA
      !IM_XFILE_REF type ref to DATA
      !IM_FILE_UUID type SYSUUID_C22
      !IM_SENDING_SEQUENCE type INT4
    exporting
      !EX_SEND type FLAG .
  methods START_RECEIVING .
  methods RECEIVE_CORE
    exporting
      value(EX_RESPONSE_CDATA) type ref to DATA
      !EX_RESPONSE_XDATA type ref to DATA .
  methods END_RECEIVING
    importing
      value(IM_RESPONSE_CDATA_REF) type ref to DATA
      value(IM_RESPONSE_XDATA_REF) type ref to DATA .
  methods CREATE_CLIENT_LINKAGE_ADDRESS
    returning
      value(RE_URL) type STRING .
  methods WAITING .
private section.

  methods NEW_FUNCTION
    returning
      value(RO_INSTANCE) type ref to ZIF_BANK_FUNCTION .
  methods SET_ENVIROMENT .
ENDCLASS.



CLASS ZCL_ABSTRACT_BANK IMPLEMENTATION.


  METHOD constructor.
    CONSTANTS: lc_program    TYPE syrepid VALUE 'ZCL_BANK_APP_ABSTRACT_BANK',
               lc_message_id TYPE symsgid VALUE 'ZTR_BANK_APPLICATION'.

    TRY.
        instance_uuid = cl_system_uuid=>if_system_uuid_static~create_uuid_c22( ).
      CATCH cx_uuid_error.
        MESSAGE e001(ztr_bank_application)
         RAISING create_uuid_error.
    ENDTRY.

    bank_indicator = im_bank_indicator.
    current_action = im_action.

    messages = zcl_bank_logger_protocal=>add_message_collector(
                 EXPORTING
                   im_default_message_class = lc_message_id
                   im_mainprogram           = lc_program
                   im_uuid                  = instance_uuid ).
**create instance of message clooector
*    CREATE OBJECT messages
*      EXPORTING
*        i_message_key  = instance_uuid
*        i_main_program = lc_program
*        i_class        = lc_message_id.

    zcl_bank_enviroment=>s_check_action_from_external(
                             EXPORTING
                               im_action                       = current_action
                             EXCEPTIONS
                               blank_action                    = 1
                               not_found                       = 2
                               class_not_config                = 3
                               formatted_structure_not_config  = 4
                               formatted_structure_not_found   = 5 ).
    IF sy-subrc <> 0.
      MESSAGE ID     sy-msgid
              TYPE   sy-msgty
              NUMBER sy-msgno
              WITH   sy-msgv1
                     sy-msgv2
                     sy-msgv3
                     sy-msgv4
               RAISING action_error.
    ENDIF.

    set_processing_step( ).
    set_enviroment( ).
  ENDMETHOD.


  METHOD copy_enviroment_error_messages.
    IF enviroment->if_error( ) = yes.
      set_error_step( im_error_code ).
      enviroment->publish_messages(
                    IMPORTING
                      et_messages = DATA(lt_messages) ).
      messages->import_messages( lt_messages ).
    ENDIF.
  ENDMETHOD.


  method CREATE_CLIENT.
##NEEDED
*    to be re-defined
  endmethod.


METHOD create_client_linkage_address.
ENDMETHOD.


METHOD destroy_client.
*    to be re-defined
ENDMETHOD.


  METHOD end_receiving.
    DATA(lo_function) = get_bank_function( current_processing_step ).

    lo_function->import_response(
                  EXPORTING
                     im_cdata_ref = im_response_cdata_ref
                     im_xdata_ref = im_response_xdata_ref ).

    IF lo_function->if_error( ) = yes.
      messages_copy_from_object( lo_function ).
      set_error_step( response_error ).
    ENDIF.

    DATA(ls_bank_function) = enviroment->get_function_by_step( current_processing_step ).
    DATA(ls_sending_file) = lo_function->get_current_sending_file( ).
    DATA(ls_response_file) = lo_function->get_current_response_file( ).

*start log
    MESSAGE i187(ztr_bank_application)
            WITH bank_indicator
                 zcl_bank_enviroment=>s_get_bank_action_text( current_action )
                 current_processing_step
                 ls_bank_function-bank_func
            INTO dummy_message.

    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = instance_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = current_action
                      bank_ind     = bank_indicator
                      bank_func    = ls_bank_function-bank_func
                      step         = current_processing_step
                      file_uuid    = ls_response_file-file_uuid
                      counter_file_uuid    = ls_sending_file-file_uuid
                      file_direction = 'R' ) ).
*end log
  ENDMETHOD.


  METHOD end_running.
    CALL FUNCTION 'ZFM_TR_DELOCK_BANK'
      EXPORTING
        im_bank_ind = bank_indicator.

    destroy_client( ).
*    start log
    MESSAGE i151(ztr_bank_application)
            WITH current_action
                 zcl_bank_enviroment=>s_get_bank_action_text( current_action )
                 bank_indicator
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = instance_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = current_action
                      bank_ind     = bank_indicator ) ).
*end log
  ENDMETHOD.


  METHOD end_sending.
    DATA(ls_function) = enviroment->get_function_by_step( current_processing_step ).
    MESSAGE i172(ztr_bank_application)
            WITH bank_indicator
                 ls_function-bank_func
                 im_file_uuid
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = instance_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = current_action
                      bank_ind     = bank_indicator
                      bank_func    = ls_function-bank_func
                      step         = current_processing_step
                      file_uuid    = im_file_uuid
                      file_direction = 'C' ) ).
  ENDMETHOD.


  METHOD init_client.
    IF current_destination = im_current_destination AND
       current_linkage_address = im_linkage_address.
      RETURN.
    ENDIF.

*      销毁旧连接
    destroy_client( ).

*      设置当前的连接目标或地址
    current_destination = im_current_destination.
    current_linkage_address = im_linkage_address.

    SELECT SINGLE dynaimc_link INTO @DATA(l_url_flag)
           FROM ztrt_httprfcdest
           WHERE destination = @im_current_destination.

*连接
    create_client(
              im_destination         = current_destination
              im_linkage_address     = im_linkage_address
              im_create_by_url       = l_url_flag ).

  ENDMETHOD.


  METHOD new_function.
    ro_instance = zcl_abstract_bank_function=>create(
                                    im_bank_indicator = bank_indicator
                                    im_action         = current_action
                                    im_step           = current_processing_step ).

    APPEND VALUE #( bank_ind     = bank_indicator
                    bank_action  = current_action
                    step         = current_processing_step
                    instance     = ro_instance )
                 TO step_functions .
  ENDMETHOD.


METHOD receive_core.
*    to be re-defined
ENDMETHOD.


  METHOD receive_from_client.
    start_receiving( ).
    receive_core(
          IMPORTING
            ex_response_cdata = DATA(l_cdata)
            ex_response_xdata = DATA(l_xdata) ).

    end_receiving(
       EXPORTING
         im_response_cdata_ref = l_cdata
         im_response_xdata_ref = l_xdata ).
  ENDMETHOD.


  method RUN_CORE.
*    DATA: l_sending_xml_xstring TYPE xstring.

    set_processing_step( ).

    enviroment->get_main_step( ).
    copy_enviroment_error_messages( instance_internal_error ).
*    return_if_error.
    IF if_error( ) = yes.
      RETURN.
    ENDIF.

    LOOP AT enviroment->get_steps( ) INTO DATA(ls_step).
      set_processing_step( ls_step-step ).

      copy_enviroment_error_messages( instance_internal_error ).
      IF if_error( ) = yes.
        EXIT.
      ENDIF.

      run_function( ).
      IF if_error( ) = yes.
        EXIT.
      ENDIF.

    ENDLOOP.
  endmethod.


  METHOD run_function.
*    start log
    DATA(ls_function) = enviroment->get_function_by_step( current_processing_step ).
    MESSAGE i155(ztr_bank_application)
            WITH bank_indicator
                 zcl_bank_enviroment=>s_get_bank_action_text( current_action )
                 current_processing_step
                 ls_function-bank_func
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = instance_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = current_action
                      bank_ind     = bank_indicator
                      bank_func    = ls_function-bank_func
                      step         = current_processing_step ) ).
*end log

    DATA(lo_function) = set_bank_function( ).

    IF lo_function IS NOT BOUND.
      RETURN.
    ENDIF.

    IF lo_function->if_stop( ) = yes.
      RETURN.
    ENDIF.

    lo_function->set_sending_data_reference( sending_entries_reference ).

    lo_function->create_files( ).

    IF lo_function->if_error( ) = yes.
      messages_copy_from_object( lo_function ).
      set_error_step( file_error ).
      RETURN.
    ENDIF.

    copy_enviroment_error_messages( instance_internal_error ).
    IF if_error( ) = yes.
      RETURN.
    ENDIF.

    DO.
      IF send( ) = yes.
        IF if_error( ) = yes.
          EXIT.
        ENDIF.

        receive_from_client( ).
        IF if_error( ) = yes.
          EXIT.
        ENDIF.
      ENDIF.

      IF lo_function->if_sending_finished( ) = yes.
        EXIT.
      ENDIF.

    ENDDO.
  ENDMETHOD.


  METHOD send.
    start_sending(
          IMPORTING
            ex_cfile_ref = DATA(l_cfile_ref)
            ex_xfile_ref = DATA(l_xfile_ref)
            ex_file_uuid = DATA(l_file_uuid)
            ex_sending_sequence = DATA(l_sending_sequence)
            ex_stop_flag = DATA(l_stop_send) ).
    IF l_stop_send = yes.
      set_error_step( file_error ).
      RETURN.
    ENDIF.

    send_core(
         EXPORTING
           im_cfile_ref = l_cfile_ref
           im_xfile_ref = l_xfile_ref
           im_file_uuid = l_file_uuid
           im_sending_sequence = l_sending_sequence
         IMPORTING
           ex_send = re_send ).
    IF re_send = yes.
      end_sending(
           EXPORTING
             im_cfile_ref = l_cfile_ref
             im_xfile_ref = l_xfile_ref
             im_file_uuid = l_file_uuid
             im_sending_sequence = l_sending_sequence ).
    ENDIF.
  ENDMETHOD.


METHOD send_core.
*    to be re-defined
ENDMETHOD.


  METHOD set_bank_function.
*    start log
    DATA(ls_function) = enviroment->get_function_by_step( current_processing_step ).
    MESSAGE i156(ztr_bank_application)
            WITH bank_indicator
                 zcl_bank_enviroment=>s_get_bank_action_text( current_action )
                 current_processing_step
                 ls_function-bank_func
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = instance_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = current_action
                      bank_ind     = bank_indicator
                      bank_func    = ls_function-bank_func
                      step         = current_processing_step ) ).
*end log

    READ TABLE step_functions INTO DATA(ls_step_function)
            WITH KEY bank_ind       = bank_indicator
                     bank_action    = current_action
                     step           = current_processing_step.
    IF sy-subrc = 0.
      ro_instance = ls_step_function-instance.
    ELSE.
      ro_instance = new_function( ).
    ENDIF.

*    start log
    MESSAGE i157(ztr_bank_application)
            WITH bank_indicator
                 zcl_bank_enviroment=>s_get_bank_action_text( current_action )
                 current_processing_step
                 ls_function-bank_func
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = instance_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = current_action
                      bank_ind     = bank_indicator
                      bank_func    = ls_function-bank_func
                      step         = current_processing_step ) ).
*end log
  ENDMETHOD.


  METHOD set_enviroment.
    enviroment = zcl_bank_enviroment=>create(
                            im_bank_indicator = bank_indicator
                            im_action         = current_action ).
    IF enviroment IS NOT BOUND.
*    start log
      MESSAGE e065(ztr_bank_application)
              WITH bank_indicator
                   current_action
                   zcl_bank_enviroment=>s_get_bank_action_text( current_action )
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = instance_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = current_action
                        bank_ind     = bank_indicator ) ).
      set_error_step( instance_internal_error ).
*    end log


*      add_system_msg_and_return_02 065
*                                   bank_indicator
*                                   current_action
*                                   instance_internal_error.
    ELSE.
      copy_enviroment_error_messages( instance_internal_error ).
    ENDIF.
  ENDMETHOD.


  METHOD set_error_step.
    error_step-step                = current_processing_step.
    error_step-instance_error_code = im_instance_error_code.
    DATA(lo_function) = get_bank_function( current_processing_step ).
    IF lo_function IS BOUND.
      error_step-bank_return = lo_function->get_response_header_status( ).
    ENDIF.
  ENDMETHOD.


  METHOD set_processing_step.
    current_processing_step = im_step.

*    start log
    MESSAGE i140(ztr_bank_application)
            WITH current_action
                 zcl_bank_enviroment=>s_get_bank_action_text( current_action )
                 bank_indicator
                 current_processing_step
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = INSTANCE_UUID
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = current_action
                      bank_ind     = bank_indicator ) ).
*end log
  ENDMETHOD.


  METHOD start_receiving.
    DATA(ls_function) = enviroment->get_function_by_step( current_processing_step ).
    DATA(ls_sending_file) = get_bank_function( current_processing_step )->get_current_sending_file( ).
    MESSAGE i174(ztr_bank_application)
            WITH bank_indicator
                 zcl_bank_enviroment=>s_get_bank_action_text( current_action )
                 current_processing_step
                 ls_function-bank_func
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = instance_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = current_action
                      bank_ind     = bank_indicator
                      bank_func    = ls_function-bank_func
                      step         = current_processing_step
                      counter_file_uuid    = ls_sending_file-file_uuid
                      file_direction = 'R' ) ).
    WAIT UP TO 1 SECONDS.

  ENDMETHOD.


  METHOD start_running.
*    start log
    MESSAGE i150(ztr_bank_application)
            WITH current_action
                 zcl_bank_enviroment=>s_get_bank_action_text( current_action )
                 bank_indicator
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = instance_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = current_action
                      bank_ind     = bank_indicator ) ).
*end log

    waiting( ).

    re_error = no.
  ENDMETHOD.


  METHOD start_sending.

*    start log
    DATA(ls_function) = enviroment->get_function_by_step( current_processing_step ).
    MESSAGE i168(ztr_bank_application)
            WITH bank_indicator
                 zcl_bank_enviroment=>s_get_bank_action_text( current_action )
                 current_processing_step
                 ls_function-bank_func
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = instance_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = current_action
                      bank_ind     = bank_indicator
                      bank_func    = ls_function-bank_func
                      step         = current_processing_step ) ).
*end log

    DATA(lo_function) = get_bank_function( current_processing_step ).
    IF lo_function IS NOT BOUND.
      MESSAGE i169(ztr_bank_application)
              WITH bank_indicator
                   zcl_bank_enviroment=>s_get_bank_action_text( current_action )
                   current_processing_step
                   ls_function-bank_func
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = instance_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = current_action
                        bank_ind     = bank_indicator
                        bank_func    = ls_function-bank_func
                        step         = current_processing_step ) ).
*end log
      ex_stop_flag = yes.
      RETURN.
    ENDIF.

    lo_function->get_sending_file(
           IMPORTING
             ex_cfile_ref = ex_cfile_ref
             ex_xfile_ref = ex_xfile_ref
             ex_file_uuid = ex_file_uuid
             ex_sending_sequence = ex_sending_sequence
             ex_do_not_send = ex_stop_flag ).

    IF ex_stop_flag = yes.

      MESSAGE i312(ztr_bank_application)
              WITH bank_indicator
                   zcl_bank_enviroment=>s_get_bank_action_text( current_action )
                   current_processing_step
                   ls_function-bank_func
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = instance_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = current_action
                        bank_ind     = bank_indicator
                        bank_func    = ls_function-bank_func
                        step         = current_processing_step
                        file_uuid    = ex_file_uuid
                        file_direction = 'C' ) ).
      RETURN.
    ELSE.
      ASSIGN ex_cfile_ref->* TO FIELD-SYMBOL(<f_cfile>).
      ASSIGN ex_xfile_ref->* TO FIELD-SYMBOL(<f_xfile>).
      IF ( <f_cfile> IS NOT ASSIGNED OR
           <f_cfile> IS INITIAL )  OR
         ( <f_xfile> IS NOT ASSIGNED OR
           <f_xfile> IS INITIAL ).
        MESSAGE i170(ztr_bank_application)
                WITH bank_indicator
                     zcl_bank_enviroment=>s_get_bank_action_text( current_action )
                     current_processing_step
                     ls_function-bank_func
                INTO dummy_message.
        zcl_bank_logger_protocal=>add_log(
                 VALUE #( uuid         = instance_uuid
                          msgid        = sy-msgid
                          msgno        = sy-msgno
                          msgty        = sy-msgty
                          msgv1        = sy-msgv1
                          msgv2        = sy-msgv2
                          msgv3        = sy-msgv3
                          msgv4        = sy-msgv4
                          message      = dummy_message
                          bank_action  = current_action
                          bank_ind     = bank_indicator
                          bank_func    = ls_function-bank_func
                          step         = current_processing_step
                          file_uuid    = ex_file_uuid
                          file_direction = 'C' ) ).
*end log
        ex_stop_flag = yes.
        RETURN.
      ELSE.
        MESSAGE i171(ztr_bank_application)
                WITH bank_indicator
                     zcl_bank_enviroment=>s_get_bank_action_text( current_action )
                     current_processing_step
                     ls_function-bank_func
                INTO dummy_message.
        zcl_bank_logger_protocal=>add_log(
                 VALUE #( uuid         = instance_uuid
                          msgid        = sy-msgid
                          msgno        = sy-msgno
                          msgty        = sy-msgty
                          msgv1        = sy-msgv1
                          msgv2        = sy-msgv2
                          msgv3        = sy-msgv3
                          msgv4        = sy-msgv4
                          message      = dummy_message
                          bank_action  = current_action
                          bank_ind     = bank_indicator
                          bank_func    = ls_function-bank_func
                          step         = current_processing_step
                          file_uuid    = ex_file_uuid
                          file_direction = 'C' ) ).
*end log
        ex_stop_flag = no.
        RETURN.
      ENDIF.
    ENDIF.
  ENDMETHOD.


  METHOD waiting.
    DO 1000 TIMES.
      CALL FUNCTION 'ZFM_TR_LOCK_BANK'
        EXPORTING
          im_bank_ind    = bank_indicator
        EXCEPTIONS
          foreign_lock   = 1
          system_failure = 2
          OTHERS         = 3.
      IF sy-subrc <> 0.
        WAIT UP TO 1 SECONDS.
      ELSE.
*        如果等待了1000秒还无法执行，就让程序继续
        EXIT.
      ENDIF.
    ENDDO.
  ENDMETHOD.


  METHOD zif_bank~create.
    DATA(l_class) = zcl_bank_enviroment=>s_get_bank_instance_class( im_bank_indicator ).

*    start log
    MESSAGE i136(ztr_bank_application)
            WITH im_action
                 zcl_bank_enviroment=>s_get_bank_action_text( im_action )
                 im_bank_indicator
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = im_action
                      bank_ind     = im_bank_indicator ) ).

    MESSAGE i139(ztr_bank_application)
            WITH im_action
                 zcl_bank_enviroment=>s_get_bank_action_text( im_action )
                 im_bank_indicator
                 l_class
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = im_action
                      bank_ind     = im_bank_indicator ) ).
*    end log

    CREATE OBJECT ro_instance TYPE (l_class)
           EXPORTING
             im_bank_indicator    = im_bank_indicator
             im_action            = im_action
           EXCEPTIONS
             create_uuid_error    = 1
             action_error         = 2.
    IF sy-subrc <> 0.
*  the error is crital error
*  it should be removed inn testing phase
      MESSAGE ID     sy-msgid
              TYPE   sy-msgty
              NUMBER sy-msgno
              WITH   sy-msgv1
                     sy-msgv2
                     sy-msgv3
                     sy-msgv4
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = im_action
                        bank_ind     = im_bank_indicator ) ).
    ELSE.
*    start log
      MESSAGE i137(ztr_bank_application)
              WITH im_action
                   zcl_bank_enviroment=>s_get_bank_action_text( im_action )
                   im_bank_indicator
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = im_action
                        bank_ind     = im_bank_indicator ) ).
*    end log
    ENDIF.
  ENDMETHOD.


  METHOD zif_bank~export_after_processed.
    DATA: l_data TYPE REF TO data.
    FIELD-SYMBOLS: <ft_data> TYPE STANDARD TABLE.

    CREATE DATA l_data LIKE et_entries.
    ASSIGN l_data->* TO <ft_data>.

    LOOP AT step_functions INTO DATA(ls_step_function)
            WHERE bank_ind      = bank_indicator
            AND   bank_action   = current_action
            AND   step          = enviroment->get_main_step( ).
      ls_step_function-instance->export_after_processed(
                  IMPORTING
                    et_entries = <ft_data> ).
      APPEND LINES OF <ft_data> TO et_entries.
    ENDLOOP.

    IF if_error( ) = yes.
      ex_s_error_step-int = error_step.
      ex_s_error_step-msg  = messages->concatenate( ).
    ENDIF.

  ENDMETHOD.


  method ZIF_BANK~GET_BANK_FUNCTION.
    READ TABLE step_functions INTO DATA(ls_step_function)
            WITH KEY bank_ind      = bank_indicator
                     bank_action   = current_action
                     step          = im_step.
    IF sy-subrc = 0.
      ro_instance = ls_step_function-instance.
    ENDIF.

    IF ro_instance IS NOT BOUND.
*      unexpected error
      MESSAGE e080(ztr_bank_application)
              WITH bank_indicator
                   current_action
                   im_step.
    ENDIF.
  endmethod.


  method ZIF_BANK~GET_ENVIROMENT.
    ro_enviroment = enviroment.
  endmethod.


  METHOD zif_bank~if_error.
    re_error = messages->if_error( ).
  ENDMETHOD.


  METHOD zif_bank~run.
    IF start_running( ) = no.
      run_core( ).
    ENDIF.
    end_running( ).
  ENDMETHOD.


  METHOD zif_bank~set_single_entry.
    DATA ls_line_ref TYPE ztrs_sending_data_reference.
    DATA: ls_log_business_data TYPE ztrs_bank_log_businessdata.
    FIELD-SYMBOLS: "<ft_entry> TYPE STANDARD TABLE,
                   <f_field>  TYPE any.

    CREATE DATA ls_line_ref-data LIKE im_s_entry.
    ASSIGN ls_line_ref-data->* TO FIELD-SYMBOL(<ls_line>).

    <ls_line> = im_s_entry.

    APPEND ls_line_ref TO sending_entries_reference.

*    start log
    CASE current_action.
      WHEN zif_bank_action=>action_is_payment OR
           zif_bank_action=>action_is_check_payments.
        ASSIGN COMPONENT 'ENTUUID' OF STRUCTURE im_s_entry TO <f_field>.
        IF sy-subrc = 0.
          ls_log_business_data-log_obj = <f_field>.
        ENDIF.

        ASSIGN COMPONENT 'PAYMORDER' OF STRUCTURE im_s_entry TO <f_field>.
        IF sy-subrc = 0.
          ls_log_business_data-paymorder = <f_field>.
        ENDIF.
        ls_log_business_data-bank_ind = bank_indicator.
        ls_log_business_data-bank_action = current_action.
        ls_log_business_data-log_obj = zcl_bank_application_logger=>log_object_type_payment_entry.
      WHEN zif_bank_action=>action_is_account_balance OR
            zif_bank_action=>action_is_get_transactions.
        ls_log_business_data-bank_ind = bank_indicator.
        ls_log_business_data-bank_action = current_action.
        ls_log_business_data-log_obj = zcl_bank_application_logger=>log_object_type_bank_account.
    ENDCASE.

    MESSAGE i138(ztr_bank_application)
            WITH current_action
                 zcl_bank_enviroment=>s_get_bank_action_text( current_action )
                 bank_indicator
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = instance_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = ls_log_business_data-bank_action
                      bank_ind     = ls_log_business_data-bank_ind
                      log_obj      = ls_log_business_data-log_obj
                      log_obj_type = ls_log_business_data-log_obj_type
                      paymorder    = ls_log_business_data-paymorder
                       ) ).
*    end log
  ENDMETHOD.


  METHOD zif_messages~messages_copy_from_object.
    messages_copy_from_object.
  ENDMETHOD.


  METHOD zif_messages~publish_messages.
    publish_messages.
  ENDMETHOD.
ENDCLASS.
