class ZCL_TR_BAPI_F4_MODIFY definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_ESH_IF_F4_MODIFY_STEP .
protected section.
private section.
ENDCLASS.



CLASS ZCL_TR_BAPI_F4_MODIFY IMPLEMENTATION.


  method IF_ESH_IF_F4_MODIFY_STEP~MODIFY_SEARCH_HELP.

        IF cs_callcontrol-step =  'SELONE'  OR
     cs_callcontrol-step =  'PRESEL1'.
"银行费用提交时输入的成本中心需为‘ F' 类型
      GET PARAMETER ID 'PCA_KOSAR' FIELD DATA(lr_kosar).
      CHECK  lr_kosar = 'F'.

      LOOP AT ct_shlp_tab ASSIGNING FIELD-SYMBOL(<cs_shlp_tab>).
        READ TABLE <cs_shlp_tab>-fieldprop ASSIGNING FIELD-SYMBOL(<fs_shlp>) WITH  KEY fieldname =  'KOSAR'    .
        IF  sy-subrc = 0.
          <fs_shlp>-defaultval = 'PCA_KOSAR'.
        ENDIF.
      ENDLOOP.
    ENDIF.
  endmethod.
ENDCLASS.
