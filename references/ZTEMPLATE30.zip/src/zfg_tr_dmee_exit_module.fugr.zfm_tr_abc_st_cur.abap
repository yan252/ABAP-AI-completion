FUNCTION ZFM_TR_ABC_ST_CUR.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     VALUE(I_TREE_TYPE) TYPE  DMEE_TREETYPE_ABA
*"     VALUE(I_TREE_ID) TYPE  DMEE_TREEID_ABA
*"     VALUE(I_ITEM)
*"     VALUE(I_PARAM)
*"     VALUE(I_UPARAM)
*"  EXPORTING
*"     REFERENCE(O_VALUE)
*"     REFERENCE(C_VALUE)
*"     REFERENCE(N_VALUE)
*"     REFERENCE(P_VALUE)
*"  TABLES
*"      I_TAB
*"--------------------------------------------------------------------
FIELD-SYMBOLS <ztst> TYPE ztrs_paym_status_list.

  ASSIGN COMPONENT 'ZTRS_PAYM_STATUS_LIST' OF STRUCTURE i_item TO <ztst>.
  DATA(payno) =  <ztst>-doc1r.

  DATA:payno1(10) TYPE c.
  payno1 = payno.

  SELECT SINGLE zzfwaers
    INTO  @DATA(cur)
    FROM ztrt2001
    WHERE docno = @payno1.


    SELECT SINGLE curcode
      INTO  c_value
      FROM ztrt_abc_cur
      WHERE cur = cur.





ENDFUNCTION.
