FUNCTION ZFM_TR_PAYMORDER_ENCRYPTION_M.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     REFERENCE(IM_COMMIT_WORK) TYPE  FLAG OPTIONAL
*"     REFERENCE(IM_ZZFTYPE) TYPE  ZTRT2001-ZZFTYPE OPTIONAL
*"  EXPORTING
*"     REFERENCE(EX_T_MAPPING) TYPE  ZTRS_SSF_MAPPING_TAB
*"  TABLES
*"      IT_2001 TYPE  ZTRT2001_TAB OPTIONAL
*"      IT_2101 TYPE  ZTRT2101_TAB OPTIONAL
*"      IT_2002 TYPE  ZTRT2002_TAB OPTIONAL
*"      IT_2003 TYPE  ZTRT2003_TAB OPTIONAL
*"  EXCEPTIONS
*"      ERROR
*"--------------------------------------------------------------------
DATA: ls_mapping TYPE ztrs_ssf_mapping.
  DATA: ls_2001 TYPE ztrt2001,
        ls_2002 TYPE ztrt2002,
        ls_2003 TYPE ztrt2003,
        ls_2101 TYPE ztrt2101.

  IF im_zzftype = 'P004'.
    LOOP AT it_2101 INTO ls_2101.

      READ TABLE it_2002 INTO ls_2002
           WITH KEY docno = ls_2101-docno.

      READ TABLE it_2003 INTO ls_2003
           WITH KEY docno = ls_2101-docno.
      CALL FUNCTION 'ZFM_TR_PAYMORDER_ENCRYPTION_S'
        EXPORTING
          im_s_2101      = ls_2101
          im_s_2002      = ls_2002
          im_s_2003      = ls_2003
          im_zzftype     = im_zzftype
          im_commit_work = im_commit_work
        IMPORTING
          ex_ssfuuid     = ls_mapping-uuid
        EXCEPTIONS
          error          = 1
          OTHERS         = 2.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid
                TYPE sy-msgty
                NUMBER sy-msgno
                WITH sy-msgv1
                     sy-msgv2
                     sy-msgv3
                     sy-msgv4
                RAISING error.
      ELSE.
        ls_mapping-object_code = ls_2101-docno.
        APPEND ls_mapping TO ex_t_mapping.
      ENDIF.

      CLEAR: ls_2002,
             ls_2003,
             ls_mapping.
    ENDLOOP.
  ELSE.
    LOOP AT it_2001 INTO ls_2001.

      READ TABLE it_2002 INTO ls_2002
           WITH KEY docno = ls_2001-docno.

      READ TABLE it_2003 INTO ls_2003
           WITH KEY docno = ls_2001-docno.
      CALL FUNCTION 'ZFM_TR_PAYMORDER_ENCRYPTION_S'
        EXPORTING
          im_s_2001      = ls_2001
          im_s_2002      = ls_2002
          im_s_2003      = ls_2003
          im_zzftype     = im_zzftype
          im_commit_work = im_commit_work
        IMPORTING
          ex_ssfuuid     = ls_mapping-uuid
        EXCEPTIONS
          error          = 1
          OTHERS         = 2.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid
                TYPE sy-msgty
                NUMBER sy-msgno
                WITH sy-msgv1
                     sy-msgv2
                     sy-msgv3
                     sy-msgv4
                RAISING error.
      ELSE.
        ls_mapping-object_code = ls_2001-docno.
        APPEND ls_mapping TO ex_t_mapping.
      ENDIF.

      CLEAR: ls_2002,
             ls_2003,
             ls_mapping.
    ENDLOOP.
  ENDIF.





ENDFUNCTION.
