*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZTRT9003........................................*
DATA:  BEGIN OF STATUS_ZTRT9003                      .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZTRT9003                      .
CONTROLS: TCTRL_ZTRT9003
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZTRT9003                      .
TABLES: ZTRT9003                       .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
