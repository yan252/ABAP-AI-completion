FUNCTION ZFM_TR_00192_APPROVE_FROM_OA.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     REFERENCE(IM_OA_REFERENCE) TYPE  ZOAT00020-REF_NO
*"     REFERENCE(IM_OA_STATUS) TYPE  ZOASTATUS
*"  EXPORTING
*"     REFERENCE(EX_RETURN) TYPE  ZOA_RETURN
*"--------------------------------------------------------------------
DATA: l_doc_number TYPE ztrt0192h-docno,
        l_doc_item   TYPE ztrt0192i-zitemno,
        lt_items     TYPE ztrs_00192_submit_item_tab.


  l_doc_number = im_oa_reference+0(10).
  l_doc_item = im_oa_reference+10(4).
  IF l_doc_item IS NOT INITIAL AND
      l_doc_number <> '0000'.
    APPEND VALUE #( zitemno = l_doc_item )
          TO lt_items.
  ENDIF.

  TRY.
      DATA(lo_instance) = zcl_tr_capital_platform_doc=>create(
                                              im_not_read_doc = space
                                              im_document_number = l_doc_number ).
    CATCH zcx_creation_error INTO DATA(lo_exception).
      ex_return = 'E'."error
      RETURN.
  ENDTRY.

  IF lo_instance IS NOT BOUND.
    ex_return = 'E'."error
    RETURN.
  ENDIF.

  CASE im_oa_status.
    WHEN 'F'.
*      审批通过
      lo_instance->approve( lt_items ).
    WHEN 'J'.
*      审批拒绝
      lo_instance->reject( lt_items ).
    WHEN 'T'.
*      审批退回
      lo_instance->return( lt_items ).
  ENDCASE.

  IF lo_instance->if_error( ) = 'X'.
    ex_return = 'E'."error
  ELSE.
    ex_return = 'S'."okay
  ENDIF.





ENDFUNCTION.
