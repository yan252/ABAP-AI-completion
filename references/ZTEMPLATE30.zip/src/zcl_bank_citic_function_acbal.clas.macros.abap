*"* use this source file for any macro definitions you need
*"* in the implementation part of the class
*INCLUDE ztr_bank_citic_file_adjust.
