FUNCTION ZFM_TR2_BANK_CHECK_STATUS_CBI.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     REFERENCE(LT_IN) TYPE  ZLTTR2_BANK_CHECK_STATUS_IN
*"  EXPORTING
*"     REFERENCE(LT_OUT) TYPE  ZLTTR2_BANK_CHECK_STATUS_OUT
*"--------------------------------------------------------------------
DATA:BEGIN OF ls_data,
         action      TYPE string,
         username    TYPE string,
         clientid    TYPE string,
         type        TYPE string,
         controlflag TYPE string,
       END OF ls_data.

  TYPES:BEGIN OF ly_row,
          stt        TYPE string,
          status     TYPE string,
          statustext TYPE string,
        END OF ly_row.

  DATA:BEGIN OF ls_response,
         status     TYPE string,
         statustext TYPE string,
         clientid   TYPE string,
         row        TYPE ly_row OCCURS 0,
       END OF ls_response.

  DATA:response TYPE string.

  DATA:temp_in TYPE zlttr2_bank_check_status_in.

  DATA:lv_log_uuid TYPE ztrt9504-log_uuid.


  DATA(lo_xml) = NEW zcl_tr2_xml( ).

  temp_in = CORRESPONDING #( lt_in[] ).

  SORT temp_in BY shdocno .
*  DELETE ADJACENT DUPLICATES FROM temp_in COMPARING accountno.

  LOOP AT temp_in INTO DATA(ls_in).
*    APPEND INITIAL LINE TO ls_data-stream ASSIGNING FIELD-SYMBOL(<fs_data>).
    ls_data-action = 'DLCIDSTT'.
    ls_data-username = zcl_citic_enhancement=>get_user_name( ).
    ls_data-clientid = ls_in-shdocno.

    CALL FUNCTION 'ZFM_TR2_BANK_SEND'
      EXPORTING
        bank_ind    = 'CBI' "中信国际
        bank_action = '003' "交易状态查询
        data_in     = ls_data
        method      = 'POST'
      IMPORTING
        response    = response
        loguuid     = lv_log_uuid.

    lo_xml->convert_xml_to_abap( EXPORTING response = response bank_ind = 'CBI' bank_action = '003' IMPORTING data = ls_response ).
    IF ls_response IS NOT INITIAL.
      APPEND INITIAL LINE TO lt_out ASSIGNING FIELD-SYMBOL(<fs_out>).
      IF ls_response-row IS NOT INITIAL.
        <fs_out>-bank_rtncode  = ls_response-row[ 1 ]-status.
        <fs_out>-bank_rtnmsg = ls_response-row[ 1 ]-statustext.
        <fs_out>-shdocno = ls_in-shdocno.
        <fs_out>-bank_ind = ls_in-bank_ind.
      ELSE.
        <fs_out>-bank_rtncode  = ls_response-status.
        <fs_out>-bank_rtnmsg = ls_response-statustext.
        <fs_out>-shdocno = ls_in-shdocno.
        <fs_out>-bank_ind = ls_in-bank_ind.
      ENDIF.
      <fs_out>-log_uuid = lv_log_uuid.
    ENDIF.

    CLEAR:ls_data,ls_response,response.
  ENDLOOP.





ENDFUNCTION.
