class ZCL_BANK_BOC_FUNCTION_TRANX definition
  public
  inheriting from ZCL_BANK_FUNCTION_TRANSACTIONS
  final
  create public .

public section.

  interfaces ZIF_BOC_FUNCTION .

  methods ZIF_BANK_FUNCTION~SET_SENDING_DATA_REFERENCE
    redefinition .
protected section.

  methods CHECK_RESPONSE_IF_FINISHED
    redefinition .
  methods PROCESSING_RESPONSE_INTL_CORE
    redefinition .
private section.
ENDCLASS.



CLASS ZCL_BANK_BOC_FUNCTION_TRANX IMPLEMENTATION.


  METHOD check_response_if_finished.
    FIELD-SYMBOLS: <fs_response>        TYPE ztrs_boc_b2e0035_response.
    CONSTANTS: c_startrecord TYPE string VALUE 'begnum',
               c_pagenumber  TYPE string VALUE 'recnum'.

    DATA(ls_sending_xml_ref) = get_sending_file_by_sequence( current_sending_sequence ).
    ASSIGN ls_sending_xml_ref-cfile->* TO FIELD-SYMBOL(<f_xml_string>).
    ASSIGN ls_sending_xml_ref-xfile->* TO FIELD-SYMBOL(<f_xml_xstring>).

    zcl_bank_data_mapping_engine=>get_element_value(
                                     EXPORTING
                                       im_xml_string = <f_xml_string>
                                       im_t_fieldname = VALUE ztrs_fieldname_tab( ( name = c_startrecord )
                                                                                  ( name = c_pagenumber ) )
                                     IMPORTING
                                       ex_t_return_errors = DATA(lt_return_errors)
                                       ex_t_element_values = DATA(lt_element_values) ).

    IF lt_return_errors IS NOT INITIAL.
      messages->add_message_set( lt_return_errors ).
      current_response_is_finished = yes.
      RETURN.
    ENDIF.

    READ TABLE lt_element_values ASSIGNING FIELD-SYMBOL(<fs_startrecord>)
         WITH KEY name = c_startrecord.

    READ TABLE lt_element_values ASSIGNING FIELD-SYMBOL(<fs_pagenumber>)
         WITH KEY name = c_pagenumber.

    DATA(ls_response_data) = get_current_response_data( ).
    ASSIGN ls_response_data-response_ref->* TO <fs_response>.

    IF ( <fs_response>-totalnum < <fs_pagenumber>-data ) OR
        ( <fs_response>-trans IS INITIAL ) OR
       ( <fs_response>-h_status-rspcod = 'B001' OR
         <fs_response>-h_status-rspcod = 'B003' ).
*      当前没有返回明细记录，或返回明细记录小于请求的条目数，视为完成
      current_response_is_finished = yes.
      RETURN.
    ENDIF.

*  not finished
    <fs_startrecord>-data = <fs_startrecord>-data + function_config-max_resp_item.
    SHIFT <fs_startrecord>-data LEFT DELETING LEADING '0'.
    CONDENSE <fs_startrecord>-data.
    <fs_pagenumber>-data = function_config-max_resp_item.
    SHIFT <fs_pagenumber>-data LEFT DELETING LEADING '0'.
    CONDENSE <fs_pagenumber>-data.

    zcl_bank_data_mapping_engine=>reset_element_value(
                                     EXPORTING
                                       im_t_element_values = lt_element_values
                                     IMPORTING
                                       et_return_errors = lt_return_errors
                                     CHANGING
                                       ch_xml_xstring = <f_xml_xstring>
                                       ch_xml_string = <f_xml_string> ).
    IF lt_return_errors IS NOT INITIAL.
      messages->add_message_set( lt_return_errors ).
      current_response_is_finished = yes.
      RETURN.
    ELSE.
      current_response_is_finished = no.
    ENDIF.

  ENDMETHOD.


  METHOD processing_response_intl_core.

    processing_response_by_dbtable(
                im_data_db_table = 'ZTRT_BOC_TRNS'
                im_detail_response_component = 'TRANS'
                im_statuscode_componnet = 'H_STATUS-RSPCOD'
                im_statustext_component = 'H_STATUS-RSPMSG'
                im_db_account_number_field = 'ACTACN'
                IM_BANK_ENTRY_ACCNUMBER_FIELD = space  ).
  ENDMETHOD.


  METHOD zif_bank_function~set_sending_data_reference.
    FIELD-SYMBOLS: <ft_data> TYPE ztrs_general_bank_acc_medium_t.
    DATA: lt_data TYPE ztrs_general_bank_acc_medium_t.
    DATA: l_date_temp    TYPE datum,
          l_high_date    TYPE datum,
          l_current_date TYPE sydatum.
    DATA: l_yesterday     TYPE sydatum,
          l_two_years_ago TYPE sydatum.
    CONSTANTS: c_month_period TYPE t5a4a-dlymo VALUE '06'. "中国银行交易明细查询的日期范围不能超过6个自然月
    CONSTANTS: c_year TYPE t5a4a-dlyyr VALUE '02'."中国银行交易明细查询的日期范围早于当前日期的两年前

    super->set_sending_data_reference( im_data_reference ).

    l_current_date = zcl_boc_enhancement=>set_bank_date( ).
    IF l_current_date IS INITIAL.
      l_current_date = sy-datum.
    ENDIF.

    ASSIGN sending_data_reference->* TO <ft_data>.

    CALL FUNCTION 'RP_CALC_DATE_IN_INTERVAL'
      EXPORTING
        date      = l_current_date
        days      = '00'
        months    = '00'
        signum    = '-'
        years     = c_year
      IMPORTING
        calc_date = l_two_years_ago.

    l_yesterday = l_current_date - 1.

    LOOP AT <ft_data> INTO DATA(ls_data).
      IF ls_data-start_date < l_two_years_ago.
*        查询的开始日期小于两年前，自动设置为两年前的日期
        ls_data-start_date = l_two_years_ago.
      ENDIF.

      IF ls_data-end_date >= l_current_date.
*        中国银行交易明细查询日期范围不能超过当天
*        查询当天的明细和和查询当天前的历史明细不一样
*        当天查询xml中type 节点为2001
*        历史查询xml中type 节点为2002
*        type的值由函数ZFM_TR_BOC_B2E0035_TYPE_GET决定
*        用户输入的查询期间包含当天，需要对查询数据进行拆分
        APPEND VALUE #( bankn = ls_data-bankn
                        start_date = l_current_date
                        end_date = l_current_date
                        sap_fields = ls_data-sap_fields )
                        TO lt_data.
*        把查询结束日期重新设置为昨天
        ls_data-end_date = l_yesterday.
      ENDIF.

      IF ls_data-end_date < ls_data-start_date.
        CONTINUE.
      ENDIF.

      l_high_date = ls_data-end_date.

      DO.
*        l_date_temp = ls_data-start_date + c_date_range.
        CALL FUNCTION 'RP_CALC_DATE_IN_INTERVAL'
          EXPORTING
            date      = ls_data-start_date
            days      = '00'
            months    = c_month_period
            signum    = '+'
            years     = '00'
          IMPORTING
            calc_date = l_date_temp.


        IF l_high_date > l_date_temp.
          ls_data-end_date = l_date_temp.
          APPEND ls_data TO lt_data.
          ls_data-start_date = l_date_temp + 1.
        ELSE.
          ls_data-end_date = l_high_date.
          APPEND ls_data TO lt_data.
          EXIT.
        ENDIF.
      ENDDO.
    ENDLOOP.

    <ft_data> = lt_data.
  ENDMETHOD.


  METHOD zif_boc_function~raise_b2eerror.
    raise_b2eerror.
    check_response_if_finished( ).
  ENDMETHOD.
ENDCLASS.
