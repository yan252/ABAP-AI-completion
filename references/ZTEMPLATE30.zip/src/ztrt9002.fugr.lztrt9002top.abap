FUNCTION-POOL ZTRT9002                   MESSAGE-ID SV.

* INCLUDE LZTRT9002D...                      " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZTRT9002T00                            . "view rel. data dcl.
