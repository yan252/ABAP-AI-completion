class ZCL_BANK_FUNCTION_CHECKPAYM definition
  public
  inheriting from ZCL_ABSTRACT_BANK_FUNCTION
  create public .

public section.

  interfaces ZIF_BANK_FUNCTION_PAYM_RELATE .
protected section.

  aliases UPDATE_PAYMENT_ENTRY
    for ZIF_BANK_FUNCTION_PAYM_RELATE~UPDATE_PAYMENT_ENTRY .

  methods UPDATE_STATUS_IN_INSTANCE
    importing
      !IM_S_STANDARD_RESPONSE type ZTRS_PAYMENT_BANK_RETURN .

  methods CONVERT_DATA_TO_DMEE_TYPE
    redefinition .
private section.
ENDCLASS.



CLASS ZCL_BANK_FUNCTION_CHECKPAYM IMPLEMENTATION.


  METHOD convert_data_to_dmee_type.
*    FIELD-SYMBOLS <ft_entries> TYPE STANDARD TABLE .
    FIELD-SYMBOLS: <ft_dmee_table> TYPE ztrs_dmee_payment_status_tab.
    DATA: ls_dmee_type TYPE ztrs_dmee_payment_status.

    CREATE DATA re_dmee_table_ref TYPE ztrs_dmee_payment_status_tab.
    ASSIGN re_dmee_table_ref->* TO <ft_dmee_table>.

    LOOP AT im_t_raw_data ASSIGNING FIELD-SYMBOL(<fs_entry>).
      MOVE-CORRESPONDING <fs_entry> TO ls_dmee_type-ztrs_paym_status_list.
      APPEND ls_dmee_type TO <ft_dmee_table>.
    ENDLOOP.

  ENDMETHOD.


  METHOD update_status_in_instance.

*    paym_update_in_instance ztrs_payment_check_status_tab.

    FIELD-SYMBOLS: <ft_related_entries> TYPE ztrs_payment_check_status_tab.
    INCLUDE ztri_payment_entry_from_bank.
  ENDMETHOD.


  METHOD zif_bank_function_paym_relate~update_payment_entry.
    DATA:lo_action_interface TYPE REF TO zif_bank_action_payment_relate.
    DATA(lo_action) = zcl_bank_abstract_action=>get_action( ).
    lo_action_interface ?= lo_action.

    IF lo_action_interface IS NOT BOUND.
      RETURN.
    ENDIF.

    lo_action_interface->update_entry_from_external(
                          EXPORTING
                            im_bank_indicator = bank_indicator
                            im_feedback_from_bank = im_feedback_from_bank
                            im_delete_entry_instance = yes ).

  ENDMETHOD.
ENDCLASS.
