*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZTRT9010
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZTRT9010            .

  PERFORM TABLEPROC.

ENDFUNCTION.
