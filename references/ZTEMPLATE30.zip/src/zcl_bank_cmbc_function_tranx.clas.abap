class ZCL_BANK_CMBC_FUNCTION_TRANX definition
  public
  inheriting from ZCL_BANK_FUNCTION_TRANSACTIONS
  final
  create public .

public section.

  interfaces ZIF_CMBC_FUNCTION .

  aliases GET_CURRENT_PACKAGE_ID
    for ZIF_CMBC_FUNCTION~GET_CURRENT_PACKAGE_ID .
protected section.

  aliases INTERACTION_COUNT
    for ZIF_CMBC_FUNCTION~INTERACTION_COUNT .
  aliases WAIT
    for ZIF_CMBC_FUNCTION~WAIT .

  methods CHECK_RESPONSE_IF_FINISHED
    redefinition .
  methods PROCESSING_RESPONSE_INTL_CORE
    redefinition .
private section.
ENDCLASS.



CLASS ZCL_BANK_CMBC_FUNCTION_TRANX IMPLEMENTATION.


  METHOD check_response_if_finished.
    FIELD-SYMBOLS: <fs_response>        TYPE ztrs_cmbc_qrydtl_response.

    DATA(ls_response_data) = get_current_response_data( ).
    ASSIGN ls_response_data-response_ref->* TO <fs_response>.

    IF <fs_response>-xdatabody-totalnum < function_config-max_resp_item OR
       <fs_response>-xdatabody-dtlinfo IS INITIAL.
*      返回的明细项目小于每次接受返回的条目数据，说明查询已经结束
      current_response_is_finished = yes.
      RETURN.
    ENDIF.

    DATA(ls_sending_xml_ref) = get_sending_file_by_sequence( current_sending_sequence ).
    ASSIGN ls_sending_xml_ref-cfile->* TO FIELD-SYMBOL(<f_xml_string>).
    ASSIGN ls_sending_xml_ref-xfile->* TO FIELD-SYMBOL(<f_xml_xstring>).

    zcl_bank_data_mapping_engine=>get_element_value(
                                     EXPORTING
                                       im_xml_string = <f_xml_string>
                                       im_t_fieldname = VALUE ztrs_fieldname_tab( ( name = zif_cmbc_constant=>xml_startno_element_name )
                                                                                  ( name = zif_cmbc_constant=>xml_endno_element_name ) )
                                     IMPORTING
                                       ex_t_return_errors = DATA(lt_return_errors)
                                       ex_t_element_values = DATA(lt_element_values) ).
    IF lt_return_errors IS NOT INITIAL.
      messages->add_message_set( lt_return_errors ).
      current_response_is_finished = yes.
      RETURN.
    ENDIF.
    READ TABLE lt_element_values ASSIGNING FIELD-SYMBOL(<fs_startno>)
         WITH KEY name = zif_cmbc_constant=>xml_startno_element_name.

    READ TABLE lt_element_values ASSIGNING FIELD-SYMBOL(<fs_endno>)
         WITH KEY name = zif_cmbc_constant=>xml_endno_element_name.

    <fs_startno>-data = <fs_startno>-data + function_config-max_resp_item.
    SHIFT <fs_startno>-data LEFT DELETING LEADING '0'.
    CONDENSE <fs_startno>-data.
    <fs_endno>-data = <fs_endno>-data + function_config-max_resp_item.
    SHIFT <fs_endno>-data LEFT DELETING LEADING '0'.
    CONDENSE <fs_endno>-data.

    zcl_bank_data_mapping_engine=>reset_element_value(
                                     EXPORTING
                                       im_t_element_values = lt_element_values
                                     IMPORTING
                                       et_return_errors = lt_return_errors
                                     CHANGING
                                       ch_xml_xstring = <f_xml_xstring>
                                       ch_xml_string = <f_xml_string> ).
    IF lt_return_errors IS NOT INITIAL.
      messages->add_message_set( lt_return_errors ).
      current_response_is_finished = yes.
      RETURN.
    ELSE.
      current_response_is_finished = no.
    ENDIF.

  ENDMETHOD.


  METHOD processing_response_intl_core.
    processing_response_by_dbtable(
                im_data_db_table = 'ZTRT_CMBC_TRNS'
                im_detail_response_component = 'XDATABODY-DTLINFO'
                im_statuscode_componnet = 'RESPONSEHEADER-CODE'
                im_statustext_component = 'RESPONSEHEADER-MESSAGE'
                im_db_account_number_field = 'ACNTNO'
                IM_BANK_ENTRY_ACCNUMBER_FIELD = 'ACNTNO'  ).

    wait( ).
  ENDMETHOD.


  method ZIF_CMBC_FUNCTION~GET_CURRENT_PACKAGE_ID.

  endmethod.


  method ZIF_CMBC_FUNCTION~WAIT.
    zcl_cmbc_enhancement=>wait(
                    CHANGING
                      ch_interaction_count = interaction_count ).
  endmethod.
ENDCLASS.
