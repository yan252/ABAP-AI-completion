FUNCTION ZFM_TR_00192_ENQUEUE_EDOC.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     REFERENCE(IM_DOCNO_KEY) TYPE  ZTR_DOCNO_BASE
*"     REFERENCE(IM_BUKRS) TYPE  BUKRS
*"     REFERENCE(IM_ZJSNO) TYPE  ZTR_JSNO
*"  EXCEPTIONS
*"      ERROR
*"--------------------------------------------------------------------
READ TABLE gt_070_key ASSIGNING FIELD-SYMBOL(<fs_070_key>)
        WITH KEY docno_key = im_docno_key
                 bukrs = im_bukrs
                 zjsno = im_zjsno.
  IF sy-subrc = 0.
    RETURN.
  ENDIF.

  CALL FUNCTION 'ENQUEUE_EZTRT0050'
    EXPORTING
      mode_ztrt0050  = 'E'
      mandt          = sy-mandt
      docno_key      = im_docno_key
      x_docno_key    = ' '
      _scope         = '2'
      _wait          = ' '
      _collect       = ' '
    EXCEPTIONS
      foreign_lock   = 1
      system_failure = 2
      OTHERS         = 3.
  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid
            TYPE sy-msgty
            NUMBER sy-msgno
            WITH sy-msgv1
                 sy-msgv2
                 sy-msgv3
                 sy-msgv4
            RAISING error.
  ENDIF.

  CALL FUNCTION 'ENQUEUE_EZTRT0070'
    EXPORTING
      mode_ztrt0070  = 'E'
      mandt          = sy-mandt
      docno_key      = im_docno_key
      bukrs          = im_bukrs
      zjsno          = im_zjsno
      x_docno_key    = ' '
      x_bukrs        = ' '
      x_zjsno        = ' '
      _scope         = '2'
      _wait          = ' '
      _collect       = ' '
    EXCEPTIONS
      foreign_lock   = 1
      system_failure = 2
      OTHERS         = 3.
  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid
            TYPE sy-msgty
            NUMBER sy-msgno
            WITH sy-msgv1
                 sy-msgv2
                 sy-msgv3
                 sy-msgv4
            RAISING error.
  ENDIF.

  APPEND INITIAL LINE TO gt_070_key ASSIGNING <fs_070_key>.

  MOVE: im_docno_key TO <fs_070_key>-docno_key,
        im_bukrs TO <fs_070_key>-bukrs,
        im_zjsno TO <fs_070_key>-zjsno.





ENDFUNCTION.
