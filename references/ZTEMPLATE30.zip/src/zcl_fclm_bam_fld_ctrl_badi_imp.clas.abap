class ZCL_FCLM_BAM_FLD_CTRL_BADI_IMP definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_FCLM_BAM_FIELDS_CONTROL .
protected section.
private section.
ENDCLASS.



CLASS ZCL_FCLM_BAM_FLD_CTRL_BADI_IMP IMPLEMENTATION.


  method IF_FCLM_BAM_FIELDS_CONTROL~ADDITIONAL_CHECK.
  endmethod.


  method IF_FCLM_BAM_FIELDS_CONTROL~NOTE_CONTROL.
  endmethod.
ENDCLASS.
