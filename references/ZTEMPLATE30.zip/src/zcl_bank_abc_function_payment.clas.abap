class ZCL_BANK_ABC_FUNCTION_PAYMENT definition
  public
  inheriting from ZCL_BANK_FUNCTION_PAYMENT
  final
  create public .

public section.
protected section.

  methods PROCESSING_RESPONSE_INTL_CORE
    redefinition .
private section.
ENDCLASS.



CLASS ZCL_BANK_ABC_FUNCTION_PAYMENT IMPLEMENTATION.


METHOD processing_response_intl_core.

    FIELD-SYMBOLS: <ft_sending_entries> TYPE ztrs_payment_entry_tab.
    FIELD-SYMBOLS: <fs_response>        TYPE any."ztrs_abc_cfrt02_response."ztrs_Abc_payment_response.
    DATA: ls_bank_payment_return TYPE ztrs_payment_bank_return.

    super->processing_response_intl_core( ).

    ASSIGN sending_data_reference->* TO <ft_sending_entries>.


    READ TABLE <ft_sending_entries> INTO DATA(ls_sending_entry)
         WITH KEY seqnumber = current_sending_sequence.
    IF sy-subrc <> 0.
*      unexpected error
      MESSAGE x091(ztr_bank_application)
              WITH function_config-bank_func
                   current_sending_sequence.
    ENDIF.

    DATA(ls_response_data) = get_current_response_data( ).

    ASSIGN ls_response_data-response_ref->* TO <fs_response>.

    ASSIGN COMPONENT 'RESPCODE' OF STRUCTURE <fs_response> TO FIELD-SYMBOL(<respcode>).

    MOVE: <respcode> TO ls_bank_payment_return-header-bank_rtncode.

*    MOVE: <fs_response>-respcode TO ls_bank_payment_return-header-bank_rtncode.

    ASSIGN COMPONENT 'RESPINFO' OF STRUCTURE <fs_response> TO FIELD-SYMBOL(<respinfo>).
    ASSIGN COMPONENT 'RXTINFO' OF STRUCTURE <fs_response> TO FIELD-SYMBOL(<rxtinfo>).
    ASSIGN COMPONENT 'CCTRANSCODE' OF STRUCTURE <fs_response> TO FIELD-SYMBOL(<cctranscode>).
    ls_bank_payment_return-header-bank_rtnmsg = <respinfo> && '-'  && <rxtinfo>.
    "  ls_bank_payment_return-header-bank_rtnmsg = <fs_response>-respinfo && '-'  && <fs_response>-rxtinfo.

*1.CFRT02交易的应答报文中<RespCode>值为0000且<WaitFlag>值为0，表示交易成功;
*    <RespCode>值为0000且<WaitFlag>值为1，表示交易落地，需要用CQRA61交易查落地交易处理结果;
*    <RespCode>值为0001且<WaitFlag>值为1，表示交易落地，需要用CQRA61交易查落地交易处理结果;
*    <RespCode>值为9999、CICS、0996、1001，表示交易结果未知、需要用CQRT04交易做查证;
*    <RespCode>的值非0000、0001、9999、CICS、0996、1001，表示交易失败。
*2.CFRT21、CFRT73交易的应答报文中<RespCode>值为0000，表示交易成功;
*    <RespCode>值为9999、CICS、0996、1001，表示交易结果未知、需要用CQRT04交易做查证;
*    <RespCode>的值非0000、9999、CICS、0996、1001，表示交易失败。

    DATA:adre(5).
*    IF  <respcode> = '9999'
*    OR <respcode> = 'CICS'
*    OR <respcode> = '0996'
*    OR <respcode> = '1001'
*    OR <respcode> = '0000'
*    OR ( <cctranscode> = 'CFRT02' AND  <respcode> = '0001' ).
*
*    ELSE.
*
*      adre  = 'FFFFFF'."表示交易失败。
*
*    ENDIF.




    ASSIGN COMPONENT 'RESPSEQNO' OF STRUCTURE <fs_response> TO FIELD-SYMBOL(<respseqno>).
    DATA:wf TYPE c.
    IF <cctranscode> = 'CFRT02'.
      ASSIGN COMPONENT 'CORP' OF STRUCTURE <fs_response> TO FIELD-SYMBOL(<corp>).
      ASSIGN COMPONENT 'WAITFLAG' OF STRUCTURE <corp> TO FIELD-SYMBOL(<waitflag>).
      IF <waitflag> = '1'.
        wf = <waitflag>."''未落地，1'."落地处理
      ENDIF.
    ENDIF.

*银行返回码是否已维护，没维护的报未知错误
    SELECT SINGLE bank_rtncode INTO  @data(rc)
      FROM ztrt_bank_rtncod
      WHERE bank_ind = 'ABC'
      AND   bank_rtncode = @<respcode>
      AND   bank_reqsts = @wf.
    IF rc IS INITIAL.
      SELECT SINGLE bank_rtncode INTO  rc  "再找没维护是否落地标识的
            FROM ztrt_bank_rtncod
            WHERE bank_ind = 'ABC'
            AND   bank_rtncode = <respcode>
            AND   bank_reqsts = ''.
      IF rc IS INITIAL.
        adre  = 'FFFFFF'."表示未知错误。
      ENDIF.
    ENDIF.
    CLEAR:rc.



    APPEND VALUE #( paymorder = ls_sending_entry-paymorder
                    doc1r = ls_sending_entry-paymorder
                    bank_rtncode = <respcode>
                    bank_reqsts = wf
                    adjust_returncode = adre
                    bank_rtnmsg = <respinfo> && '-' && <rxtinfo>
                   bank_tran_number = <respseqno> )
              TO ls_bank_payment_return-items.

*    APPEND VALUE #( paymorder = ls_sending_entry-paymorder
*                    doc1r = ls_sending_entry-paymorder
*                    bank_rtncode = <fs_response>-respcode
*                    bank_reqsts = <fs_response>-corp-waitflag
*                    adjust_returncode = adre
*                    bank_rtnmsg = <fs_response>-respinfo &&  '-'  && <fs_response>-rxtinfo
*                    bank_tran_number = <fs_response>-respseqno )
*                 TO ls_bank_payment_return-items.

    update_status_in_instance( ls_bank_payment_return ).

  ENDMETHOD.
ENDCLASS.
