FUNCTION ZFM_TR_CITIC_RETURNCODE_UPLOAD.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     REFERENCE(IM_BANK_FUNC) TYPE  ZTRT_PAYMENT-BANK_FUNC OPTIONAL
*"--------------------------------------------------------------------
DATA: lv_file_path TYPE rlgrap-filename.
  DATA: lta_excel_table TYPE issr_alsmex_tabline.
  DATA: lst_excel_data TYPE alsmex_tabline.
*  DATA: lv_tabix TYPE sy-tabix.
  PERFORM frm_get_upload_file
              CHANGING
                 lv_file_path.

  CALL FUNCTION 'ALSM_EXCEL_TO_INTERNAL_TABLE'
    EXPORTING
      filename                = lv_file_path
      i_begin_col             = 1
      i_begin_row             = 1
      i_end_col               = 9
      i_end_row               = 65536
    TABLES
      intern                  = lta_excel_table
    EXCEPTIONS
      inconsistent_parameters = 1
      upload_ole              = 2.
  IF sy-subrc NE 0.
*  should not happen,
*  or excel application in user frontend is 2003 but the template is 2007 or above
    MESSAGE e096(ztr_bank_application).
  ENDIF.
  DELETE lta_excel_table WHERE row = 1.
  SORT lta_excel_table BY row col.


  DATA: lt_bank_code TYPE TABLE OF ztrt_bank_rtncod,
        ls_bank_code TYPE  ztrt_bank_rtncod,
        lt_func_code TYPE TABLE OF ztrt_bfun_rtncod,
        ls_func_code TYPE ztrt_bfun_rtncod.
  LOOP AT lta_excel_table INTO lst_excel_data.
*    REPLACE '"' WITH space INTO lst_excel_data-value.
*    CONDENSE lst_excel_data-value.
*    ADD 1 TO lv_tabix.
    CASE lst_excel_data-col.
      WHEN 1.
        MOVE: lst_excel_data-value TO ls_bank_code-bank_ind.
      WHEN 2.
        MOVE: lst_excel_data-value TO ls_bank_code-bank_rtncode.
      WHEN 3.
        MOVE: lst_excel_data-value TO ls_bank_code-bank_reqsts.
      WHEN 4.
        MOVE: lst_excel_data-value TO ls_bank_code-bank_rtnflg.
      WHEN 5.
        MOVE: lst_excel_data-value TO ls_bank_code-bank_rtnmsg.
      WHEN 6.
        MOVE: lst_excel_data-value TO ls_bank_code-rtntype.
      WHEN 7.
        MOVE: lst_excel_data-value TO ls_bank_code-entstatus.
    ENDCASE.

    AT END OF row.
      CASE ls_bank_code-bank_ind.
        WHEN 'CITIC'.
          APPEND ls_bank_code TO lt_bank_code.
          ls_bank_code-bank_rtnflg = '0'.
          APPEND ls_bank_code TO lt_bank_code.
          ls_bank_code-bank_rtnflg = '1'.
          APPEND ls_bank_code TO lt_bank_code.
          ls_bank_code-bank_rtnflg = '2'.
          APPEND ls_bank_code TO lt_bank_code.
          ls_bank_code-bank_rtnflg = '3'.
          APPEND ls_bank_code TO lt_bank_code.
          ls_bank_code-bank_rtnflg = '4'.
          APPEND ls_bank_code TO lt_bank_code.
          CASE im_bank_func.
            WHEN 'DLOUTTRN'.
              DELETE lt_bank_code WHERE bank_rtnflg IS NOT INITIAL .
          ENDCASE.
      ENDCASE.
      APPEND ls_bank_code TO lt_bank_code.
      CLEAR ls_bank_code.
*      CLEAR lv_tabix.
    ENDAT.
  ENDLOOP.

  IF im_bank_func IS NOT INITIAL.
    LOOP AT lt_bank_code INTO ls_bank_code.
      MOVE-CORRESPONDING ls_bank_code TO ls_func_code.
      MOVE im_bank_func TO ls_func_code-bank_func.
      APPEND ls_func_code TO lt_func_code.
    ENDLOOP.
    MODIFY ztrt_bfun_rtncod FROM TABLE lt_func_code.
  ELSE.
    DATA: lt_bank_code_text TYPE TABLE OF ztrt_bank_rtncot,
          ls_bank_code_text TYPE ztrt_bank_rtncot.
    LOOP AT lt_bank_code INTO ls_bank_code.
      MOVE-CORRESPONDING ls_bank_code TO ls_bank_code_text.
      MOVE sy-langu TO ls_bank_code_text-spras.
      MOVE ls_bank_code-bank_rtnmsg TO ls_bank_code_text-ltext.
      APPEND ls_bank_code_text TO lt_bank_code_text.
    ENDLOOP.
    MODIFY ztrt_bank_rtncod FROM TABLE lt_bank_code.
    MODIFY ztrt_bank_rtncot FROM TABLE lt_bank_code_text.
  ENDIF.





ENDFUNCTION.
