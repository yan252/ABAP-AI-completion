*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_TR_COMMONTOP.                 " Global Declarations
  INCLUDE LZFG_TR_COMMONUXX.                 " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_TR_COMMONF...                 " Subroutines
* INCLUDE LZFG_TR_COMMONO...                 " PBO-Modules
* INCLUDE LZFG_TR_COMMONI...                 " PAI-Modules
* INCLUDE LZFG_TR_COMMONE...                 " Events
* INCLUDE LZFG_TR_COMMONP...                 " Local class implement.
* INCLUDE LZFG_TR_COMMONT99.                 " ABAP Unit tests

INCLUDE lzfg_tr_commonf01.
