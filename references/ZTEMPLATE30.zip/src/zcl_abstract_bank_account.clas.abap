class ZCL_ABSTRACT_BANK_ACCOUNT definition
  public
  abstract
  create public .

public section.

  class-data DUMMY_MESSAGE type STRING .

  methods CONSTRUCTOR
    importing
      !IM_BANK_INDICATOR type ZTR_BANK_INDICATOR
      !IM_ACTION type ZTR_APP_ACTION_FOR_BANK .
  class-methods CREATE
    importing
      !IM_BANK_INDICATOR type ZTR_BANK_INDICATOR
      !IM_ACTION type ZTR_APP_ACTION_FOR_BANK
    returning
      value(RO_INSTANCE) type ref to ZCL_ABSTRACT_BANK_ACCOUNT .
  methods SET_DATA
    importing
      !IM_DATA type ref to DATA .
  methods IF_ERROR
    returning
      value(RE_ERROR) type FLAG .
  methods CONVERT_STRING
    importing
      !STRING type STRING
      !CHAR type STRING
    returning
      value(STRING_CONV) type STRING .
protected section.

  data BANK_INDICATOR type ZTR_BANK_INDICATOR .
  data ACTION type ZTR_APP_ACTION_FOR_BANK .
  data SYSTEM_INFO type ZBCS_SYSTEM_INFO .
  data ACCOUNT_UUID type SYSUUID_C22 .
  data MESSAGES type ref to ZCL_MESSAGE_COLLECTOR .
  data TRANSACTION_DB_TABNAME type TABNAME .
  data ACCOUNT_BALANCE_DB_TABNAME type TABNAME .
  data HISTORY_ACC_BALANCE_DB_NAME type TABNAME .
  data NEW_TRANSACTIONS type ref to DATA .
  data NEW_ACCOUNT_BALANCE type ref to DATA .
  data NEW_HISTORY_ACCOUNT_BALANCE type ref to DATA .
  constants YES type FLAG value 'X' ##NO_TEXT.
  constants NO type FLAG value SPACE ##NO_TEXT.
  data SAP_NEW_TRANSACTIONS type ZTRT_BANK_TRANS_TAB .
  data SAP_NEW_ACCOUNT_BALANCE type ZTRT2090_TAB .
  data SAP_NEW_HISTORY_ACC_BALANCE type ZTRT2091_TAB .

  methods SET_ADMIN_FIELDS
    importing
      !IM_NEW_ENTRY type FLAG
    changing
      !CS_ADMIN type ZTRS_DBADMIN .
  methods SET_DATA_CORE
    importing
      !IM_DATA type ref to DATA .
  methods SET_TRANSACTIONS_CORE
    importing
      !IM_DATA type ref to DATA .
  methods SET_ACCOUNT_BALANCE_CORE
    importing
      !IM_DATA type ref to DATA .
  methods SET_HISTORY_ACC_BAL_CORE
    importing
      !IM_DATA type ref to DATA .
  methods SET_ACCOUNT_TABNAME .
  methods BANK_TRANSACTIONS_TO_SAP
    returning
      value(RT_TRANSACTIONS) type ZTRT_BANK_TRANS_TAB .
  methods BANK_HISTORY_BALANCE_TO_SAP
    returning
      value(RT_BALANCE) type ZTRT2091_TAB .
  methods BANK_BALANCE_TO_SAP
    returning
      value(RT_BALANCE) type ZTRT2090_TAB .
  methods CONVERT_TRANSAMT_BY_SHKZG
    importing
      !IM_SHKZG type SHKZG
      !IM_ORIGINAL_AMT type ANY
    returning
      value(RE_CONVERTTED_AMT) type ZTR_BKFSE .
  methods SET_CUSTOMER_CODE_BY_NAME
    importing
      !IM_NAME type CLIKE
    returning
      value(RE_CODE) type KUNNR .
  methods SET_VENDOR_CODE_BY_NAME
    importing
      !IM_NAME type CLIKE
    returning
      value(RE_CODE) type LIFNR .
  methods GET_PAYMKEY_FROM_TRANSACTION
    importing
      !IM_RAW_TEXT type CLIKE
      !IM_PATTERN type CLIKE default 'APPTRANSACTIONREFERENCE'
    returning
      value(RE_KEY) type ZTRS_PAYMENT_KEYFIELDS .
  methods FINISHED_SAP_TRANX_FIELDS
    changing
      !CH_T_TRANX type ZTRT_BANK_TRANS_TAB .
  methods SET_PARTNER_BY_NAME
    importing
      !IM_NAME type CLIKE
    returning
      value(RE_PARTNER) type ZTRS_BANK_TRANS_PARTNER .
  methods CHECK_BANK_ACC_SHIFTON_DATE .
  methods UPDATE_PAYMENT_STATUS .
  methods FILTER_ACCBAL_BY_SHIFTON_DATE
    importing
      !IM_S_SAP_FIELD type ZTRS_ACCOUNT_SAP_FIELDS
      !IM_DATE type DATUM optional
    returning
      value(RE_VALID) type FLAG .
  methods FILTER_TRANS_BY_SHIFTON_DATE
    importing
      !IM_S_SAP_FIELD type ZTRS_ACCOUNT_SAP_FIELDS
      !IM_TRANSACTION_DATE type DATUM
    returning
      value(RE_VALID) type FLAG .
  methods GET_ACCOUNT_SHIFTON_DATE
    importing
      !IM_S_SAP_FIELD type ZTRS_ACCOUNT_SAP_FIELDS
    returning
      value(RE_DATE) type SYDATUM .
  methods ENQUEUE_TRANSACTION_CORE
    importing
      !IM_BUKRS type BUKRS
      !IM_HBKID type HBKID
      !IM_HKTID type HKTID
      !IM_YHZH type CLIKE
      !IM_TRXNO type CLIKE
    exporting
      !EX_ENQUEUE_FAILED type FLAG .
  methods DEQUEUE_TRANSACTION_CORE
    importing
      !IM_BUKRS type BUKRS
      !IM_HBKID type HBKID
      !IM_HKTID type HKTID
      !IM_YHZH type CLIKE
      !IM_TRXNO type CLIKE .
  methods DEQUEUE_TRANSACTION
    importing
      !IM_T_TRANSACTIONS type STANDARD TABLE .
  methods ENQUEUE_BALANCE_CORE
    importing
      !IM_BUKRS type BUKRS
      !IM_HBKID type HBKID
      !IM_HKTID type HKTID
    exporting
      !EX_ENQUEUE_FAILED type FLAG .
  methods DEQUEUE_BALANCE
    importing
      !IM_T_BALANCE type STANDARD TABLE .
  methods DEQUEUE_BALANCE_CORE
    importing
      !IM_BUKRS type BUKRS
      !IM_HBKID type HBKID
      !IM_HKTID type HKTID .
  methods GET_ACCOUNT_CURRENCY
    importing
      !IM_S_ACCOUNT_KEY type ZTRS_ACCOUNT_SAP_FIELDS
    returning
      value(RE_WAERS) type WAERS .
private section.

  methods SET_TRANSACTIONS
    importing
      !IM_DATA type ref to DATA .
  methods SET_ACCOUNT_BALANCE
    importing
      !IM_DATA type ref to DATA .
  methods SET_HISTORY_ACCOUNT_BALANCE
    importing
      !IM_DATA type ref to DATA .
  methods CONVERT_TRANX_INTO_SAP .
  methods CONVERT_ACCBALANCE_INTO_SAP .
  methods CONVERT_HISACCBAL_INTO_SAP .
  methods UPDATE_TRANSACTIONS .
  methods UPDATE_ACCOUNT_BALANCE .
  methods UPDATE_HISTORY_ACCOUNT_BALANCE .
  methods SET_DATA_STARTING
    importing
      !IM_DATA type ref to DATA
    returning
      value(RE_CONTINUE) type FLAG .
  methods SET_DATA_ENDING .
  methods SET_TRANSACTIONS_STARTING
    importing
      !IM_DATA type ref to DATA
    returning
      value(RE_CONTINUE) type FLAG .
  methods SET_TRANSACTIONS_ENDING .
  methods SET_ACCOUNT_BALANCE_STARTING
    importing
      !IM_DATA type ref to DATA
    returning
      value(RE_CONTINUE) type FLAG .
  methods SET_ACCOUNT_BALANCE_ENDING .
  methods SET_HISTORY_ACC_BAL_STARTING
    importing
      !IM_DATA type ref to DATA
    returning
      value(RE_CONTINUE) type FLAG .
  methods SET_HISTORY_ACC_BAL_ENDING .
  methods CHECK_ACCOUNT_OBJECT
    importing
      !IM_DATA type ref to DATA
      !IM_TABNAME type TABNAME
      !IM_NEW_ENTRIES_DATA_REFERENCE type ref to DATA .
  methods FILTER_NEW_TRANSACTIONS
    importing
      !IM_T_SAP_TRANSACTIONS type ZTRT_BANK_TRANS_TAB .
  methods FILTER_NEW_ACCOUNT_BALANCE
    importing
      !IM_T_SAP_ACCOUNT_BALANCE type ZTRT2090_TAB .
  methods FILTER_NEW_HIS_ACC_BALANCE
    importing
      !IM_T_SAP_HIS_ACC_BALANCE type ZTRT2091_TAB .
  methods UPDATE_SAP_TRANSACTIONS
    importing
      !IM_T_SAP_TRANSACTIONS type ZTRT_BANK_TRANS_TAB .
ENDCLASS.



CLASS ZCL_ABSTRACT_BANK_ACCOUNT IMPLEMENTATION.


##NEEDED
  method BANK_BALANCE_TO_SAP.
*    to be re-defined
  endmethod.


##NEEDED
  method BANK_HISTORY_BALANCE_TO_SAP.
*    to be re-defined
  endmethod.


METHOD bank_transactions_to_sap.
* to be re-defined
    finished_sap_tranx_fields(
                 CHANGING
                   ch_t_tranx = rt_transactions ).
  ENDMETHOD.


METHOD check_account_object.
    data: lo_import_data_descr type ref to cl_abap_tabledescr,
          lo_new_entry_data_descr type ref to cl_abap_tabledescr.

    IF im_tabname IS INITIAL OR
       im_new_entries_data_reference IS NOT BOUND.
      MESSAGE e212(ztr_bank_application)
              WITH bank_indicator
                   action
                   zcl_bank_enviroment=>s_get_bank_action_text( action )
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = account_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator ) ).
      RETURN.
    ENDIF.

*    DATA(ls_import_data_ddic) = cl_abap_tabledescr=>describe_by_data_ref( im_data )->get_ddic_header( ).
*    DATA(ls_new_entries_ddic) = cl_abap_tabledescr=>describe_by_data_ref( im_new_entries_data_reference )->get_ddic_header( ).
lo_import_data_descr ?= cl_abap_tabledescr=>describe_by_data_ref( im_data ).
DATA(ls_import_data_ddic) = lo_import_data_descr->get_table_line_type( )->get_ddic_header( ).
lo_new_entry_data_descr ?= cl_abap_tabledescr=>describe_by_data_ref( im_new_entries_data_reference ).
DATA(ls_new_entries_ddic) = lo_new_entry_data_descr->get_table_line_type( )->get_ddic_header( ).

    IF ls_import_data_ddic-tabname <> im_tabname.
      MESSAGE e213(ztr_bank_application)
              WITH bank_indicator
                   action
                   zcl_bank_enviroment=>s_get_bank_action_text( action )
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = account_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator ) ).
      RETURN.
    ENDIF.

    IF ls_new_entries_ddic-tabname <> im_tabname.
      MESSAGE e214(ztr_bank_application)
              WITH bank_indicator
                   action
                   zcl_bank_enviroment=>s_get_bank_action_text( action )
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = account_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator ) ).
      RETURN.
    ENDIF.
  ENDMETHOD.


method CHECK_BANK_ACC_SHIFTON_DATE.
  endmethod.


METHOD constructor.
    CONSTANTS: lc_program    TYPE syrepid VALUE 'ZCL_ABSTRACT_BANK_ACCOUNT',
               lc_message_id TYPE symsgid VALUE 'ZTR_BANK_APPLICATION'.

    bank_indicator = im_bank_indicator.
    action = im_action.
    system_info  = zcl_global_technical_service=>get_system_info( ).

    TRY.
        account_uuid = cl_system_uuid=>if_system_uuid_static~create_uuid_c22( ).
      CATCH cx_uuid_error.
        MESSAGE e001(ztr_bank_application).
    ENDTRY.

    messages = zcl_bank_logger_protocal=>add_message_collector(
                 EXPORTING
                   im_default_message_class = lc_message_id
                   im_mainprogram           = lc_program
                   im_uuid                  = account_uuid ).
  ENDMETHOD.


METHOD convert_accbalance_into_sap.

    MESSAGE i256(ztr_bank_application)
            WITH bank_indicator
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = account_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = action
                      bank_ind     = bank_indicator ) ).


    filter_new_account_balance(  bank_balance_to_sap( ) ).


    MESSAGE i257(ztr_bank_application)
            WITH bank_indicator
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = account_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = action
                      bank_ind     = bank_indicator ) ).
  ENDMETHOD.


METHOD convert_hisaccbal_into_sap.
    MESSAGE i365(ztr_bank_application)
            WITH bank_indicator
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = account_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = action
                      bank_ind     = bank_indicator ) ).


    filter_new_his_acc_balance(  bank_history_balance_to_sap( ) ).


    MESSAGE i366(ztr_bank_application)
            WITH bank_indicator
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = account_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = action
                      bank_ind     = bank_indicator ) ).
  ENDMETHOD.


METHOD CONVERT_STRING.

    STRING_CONV = STRING.
    REPLACE ALL OCCURRENCES OF CHAR IN STRING_CONV WITH ''.

  ENDMETHOD.


METHOD convert_transamt_by_shkzg.
    CASE im_shkzg.
      WHEN 'H'.
        re_convertted_amt = im_original_amt * -1.
      WHEN 'S'.
        re_convertted_amt = im_original_amt.
    ENDCASE.
  ENDMETHOD.


METHOD convert_tranx_into_sap.
    MESSAGE i215(ztr_bank_application)
            WITH bank_indicator
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = account_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = action
                      bank_ind     = bank_indicator ) ).

    filter_new_transactions(  bank_transactions_to_sap( ) ).

    MESSAGE i216(ztr_bank_application)
            WITH bank_indicator
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = account_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = action
                      bank_ind     = bank_indicator ) ).
  ENDMETHOD.


METHOD create.
    MESSAGE i206(ztr_bank_application)
            WITH im_bank_indicator
                 im_action
                 zcl_bank_enviroment=>s_get_bank_action_text( im_action )
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = im_action
                      bank_ind     = im_bank_indicator ) ).

    DATA(l_class) = zcl_bank_enviroment=>s_get_bank_acc_instance_class( im_bank_indicator ).

    MESSAGE i207(ztr_bank_application)
            WITH im_bank_indicator
                 l_class
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = im_action
                      bank_ind     = im_bank_indicator ) ).

    CREATE OBJECT ro_instance TYPE (l_class)
           EXPORTING
             im_bank_indicator    = im_bank_indicator
             im_action            = im_action.

    MESSAGE i208(ztr_bank_application)
            WITH im_bank_indicator
                 im_action
                 zcl_bank_enviroment=>s_get_bank_action_text( im_action )
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = im_action
                      bank_ind     = im_bank_indicator ) ).
  ENDMETHOD.


METHOD dequeue_balance.
    DATA:ls_sap_fields TYPE ztrs_account_sap_fields.

    LOOP AT im_t_balance ASSIGNING FIELD-SYMBOL(<fs_balance>).
      MOVE-CORRESPONDING <fs_balance> TO ls_sap_fields.
      dequeue_balance_core(
                      im_bukrs = ls_sap_fields-sap_bukrs
                      im_hbkid = ls_sap_fields-sap_hbkid
                      im_hktid = ls_sap_fields-sap_hktid ).
    ENDLOOP.
  ENDMETHOD.


METHOD dequeue_balance_core.
    CALL FUNCTION 'DEQUEUE_EZTRT2090'
      EXPORTING
        mode_ztrt2090 = 'E'
        mandt         = sy-mandt
        bukrs         = im_bukrs
        hbkid         = im_hbkid
        hktid         = im_hktid
        x_bukrs       = ' '
        x_hbkid       = ' '
        x_hktid       = ' '
        _scope        = '3'
        _synchron     = ' '
        _collect      = ' '.
  ENDMETHOD.


method DEQUEUE_TRANSACTION.
  endmethod.


METHOD dequeue_transaction_core.
    DATA: BEGIN OF ls_trans_key,
            bukrs TYPE bukrs,
            hbkid TYPE hbkid,
            hktid TYPE hktid,
            yhzh  TYPE ztr_yhzh,
            trxno TYPE ztr_bank_trxno,
          END OF ls_trans_key.

    MOVE: im_bukrs TO ls_trans_key-bukrs,
          im_hbkid TO ls_trans_key-hbkid,
          im_hktid TO ls_trans_key-hktid,
          im_yhzh TO ls_trans_key-yhzh,
          im_trxno TO ls_trans_key-trxno.

    CALL FUNCTION 'DEQUEUE_EZTRT_BANK_TRANS'
      EXPORTING
        mode_ztrt_bank_trans = 'E'
        mandt                = sy-mandt
        bukrs                = ls_trans_key-bukrs
        hbkid                = ls_trans_key-hbkid
        hktid                = ls_trans_key-hktid
        yhzh                 = ls_trans_key-yhzh
        trxno                = ls_trans_key-trxno
        x_bukrs              = ' '
        x_hbkid              = ' '
        x_hktid              = ' '
        x_yhzh               = ' '
        x_trxno              = ' '
        _scope               = '3'
        _synchron            = ' '
        _collect             = ' '.

  ENDMETHOD.


METHOD enqueue_balance_core.
    CALL FUNCTION 'ENQUEUE_EZTRT2090'
      EXPORTING
        mode_ztrt2090  = 'E'
        mandt          = sy-mandt
        bukrs          = im_bukrs
        hbkid          = im_hbkid
        hktid          = im_hktid
        x_bukrs        = ' '
        x_hbkid        = ' '
        x_hktid        = ' '
        _scope         = '2'
        _wait          = ' '
        _collect       = ' '
      EXCEPTIONS
        foreign_lock   = 1
        system_failure = 2
        OTHERS         = 3.
    IF sy-subrc <> 0.
      ex_enqueue_failed = yes.

      MESSAGE e364(ztr_bank_application)
              WITH im_bukrs
                   im_hbkid
                   IM_HKTID
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = account_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator ) ).
    ENDIF.

  ENDMETHOD.


METHOD enqueue_transaction_core.
    DATA: BEGIN OF ls_trans_key,
            bukrs TYPE bukrs,
            hbkid TYPE hbkid,
            hktid TYPE hktid,
            yhzh  TYPE ztr_yhzh,
            trxno TYPE ztr_bank_trxno,
          END OF ls_trans_key.

    MOVE: im_bukrs TO ls_trans_key-bukrs,
          im_hbkid TO ls_trans_key-hbkid,
          im_hktid TO ls_trans_key-hktid,
          im_yhzh TO ls_trans_key-yhzh,
          im_trxno TO ls_trans_key-trxno.

    CALL FUNCTION 'ENQUEUE_EZTRT_BANK_TRANS'
      EXPORTING
        mode_ztrt_bank_trans = 'E'
        mandt                = sy-mandt
        bukrs                = ls_trans_key-bukrs
        hbkid                = ls_trans_key-hbkid
        hktid                = ls_trans_key-hktid
        yhzh                 = ls_trans_key-yhzh
        trxno                = ls_trans_key-trxno
        x_bukrs              = ' '
        x_hbkid              = ' '
        x_hktid              = ' '
        x_yhzh               = ' '
        x_trxno              = ' '
        _scope               = '2'
        _wait                = ' '
        _collect             = ' '
      EXCEPTIONS
        foreign_lock         = 1
        system_failure       = 2
        OTHERS               = 3.
    IF sy-subrc <> 0.
      ex_enqueue_failed = yes.

      MESSAGE e363(ztr_bank_application)
              WITH ls_trans_key-yhzh
                   ls_trans_key-trxno
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = account_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator ) ).
    ENDIF.

  ENDMETHOD.


METHOD filter_accbal_by_shifton_date.
    DATA(l_shifton_date) = get_account_shifton_date( im_s_sap_field ).

    IF l_shifton_date IS INITIAL.
*  账户尚未切换
      re_valid = space.
      RETURN.
    ENDIF.

    IF im_date IS INITIAL.
      IF sy-datum < l_shifton_date.
*      当前日期小于切换日期
        re_valid = space.
        RETURN.
      ENDIF.
    ELSE.
      IF im_date < l_shifton_date.
*      指定日期小于切换日期
        re_valid = space.
        RETURN.
      ENDIF.
    ENDIF.

    re_valid = 'X'.

  ENDMETHOD.


METHOD filter_new_account_balance.
*  DATA: lt_sap_account_balance TYPE ZTRT2090_TAB.
    DATA: l_new     TYPE flag,
          l_changed TYPE flag.

    SELECT * INTO TABLE @DATA(lt_sap_balance_old)
            FROM ztrt2090
            FOR ALL ENTRIES IN @im_t_sap_account_balance
            WHERE bukrs = @im_t_sap_account_balance-bukrs
            AND   hbkid = @im_t_sap_account_balance-hbkid
            AND   hktid = @im_t_sap_account_balance-hktid
            AND   yhzh = @im_t_sap_account_balance-yhzh.

    LOOP AT im_t_sap_account_balance INTO DATA(ls_sap_balance).
      READ TABLE lt_sap_balance_old INTO DATA(ls_sap_balance_old)
            WITH KEY bukrs = ls_sap_balance-bukrs
                     hbkid = ls_sap_balance-hbkid
                     hktid = ls_sap_balance-hktid
                     yhzh = ls_sap_balance-yhzh.
      IF sy-subrc <> 0.
*      new
        l_new = 'X'.
      ELSE.
        IF ls_sap_balance-acc_field <> ls_sap_balance_old-acc_field.
          l_changed = 'X'.
        ENDIF.
      ENDIF.

      IF l_new = 'X' OR
         l_changed = 'X'.
        ls_sap_balance-dbadmin = ls_sap_balance_old-dbadmin.
        set_admin_fields(
                  EXPORTING
                    im_new_entry = l_new
                  CHANGING
                    cs_admin = ls_sap_balance-dbadmin ).
        APPEND ls_sap_balance TO sap_new_account_balance.
      ENDIF.

      CLEAR: l_new,
             l_changed,
             ls_sap_balance_old.

    ENDLOOP.

  ENDMETHOD.


METHOD filter_new_his_acc_balance.
    DATA: l_new     TYPE flag,
          l_changed TYPE flag.

    SELECT * INTO TABLE @DATA(lt_sap_balance_old)
            FROM ztrt2091
            FOR ALL ENTRIES IN @IM_T_SAP_HIS_ACC_BALANCE
            WHERE bukrs = @IM_T_SAP_HIS_ACC_BALANCE-bukrs
            AND   hbkid = @IM_T_SAP_HIS_ACC_BALANCE-hbkid
            AND   hktid = @IM_T_SAP_HIS_ACC_BALANCE-hktid
            AND   zdate = @IM_T_SAP_HIS_ACC_BALANCE-zdate.

    LOOP AT IM_T_SAP_HIS_ACC_BALANCE INTO DATA(ls_sap_balance).
      READ TABLE lt_sap_balance_old INTO DATA(ls_sap_balance_old)
            WITH KEY bukrs = ls_sap_balance-bukrs
                     hbkid = ls_sap_balance-hbkid
                     hktid = ls_sap_balance-hktid
                     zdate = ls_sap_balance-zdate.
      IF sy-subrc <> 0.
*      new
        l_new = 'X'.
      ELSE.
        IF ls_sap_balance-acc_field <> ls_sap_balance_old-acc_field.
          l_changed = 'X'.
        ENDIF.
      ENDIF.

      IF l_new = 'X' OR
         l_changed = 'X'.
        ls_sap_balance-dbadmin = ls_sap_balance_old-dbadmin.
        set_admin_fields(
                  EXPORTING
                    im_new_entry = l_new
                  CHANGING
                    cs_admin = ls_sap_balance-dbadmin ).
        APPEND ls_sap_balance TO SAP_NEW_HISTORY_ACC_BALANCE.
      ENDIF.

      CLEAR: l_new,
             l_changed,
             ls_sap_balance_old.

    ENDLOOP.
  ENDMETHOD.


METHOD filter_new_transactions.
*    DATA: lt_sap_tranx TYPE ztrt_bank_trans_tab.
    DATA: l_new     TYPE flag,
          l_changed TYPE flag.

    IF im_t_sap_transactions IS INITIAL.
      RETURN.
    ENDIF.

    SELECT * INTO TABLE @DATA(lt_sap_tranx_old)
            FROM ztrt_bank_trans
            FOR ALL ENTRIES IN @im_t_sap_transactions
            WHERE bukrs = @im_t_sap_transactions-bukrs
            AND   hbkid = @im_t_sap_transactions-hbkid
            AND   hktid = @im_t_sap_transactions-hktid
            AND   yhzh = @im_t_sap_transactions-yhzh
            AND   trxno = @im_t_sap_transactions-trxno.

    LOOP AT im_t_sap_transactions INTO DATA(ls_sap_tranx).
      READ TABLE lt_sap_tranx_old INTO DATA(ls_sap_tranx_old)
            WITH KEY bukrs = ls_sap_tranx-bukrs
                     hbkid = ls_sap_tranx-hbkid
                     hktid = ls_sap_tranx-hktid
                     yhzh = ls_sap_tranx-yhzh
                     trxno = ls_sap_tranx-trxno.
      IF sy-subrc <> 0.
*      new
        l_new = 'X'.
      ELSE.
        IF ls_sap_tranx-trns_field <> ls_sap_tranx_old-trns_field.
          l_changed = 'X'.
        ENDIF.
      ENDIF.

      IF l_new = 'X' OR
         l_changed = 'X'.
        ls_sap_tranx-dbadmin = ls_sap_tranx_old-dbadmin.
**        ls_sap_tranx-checkup = ls_sap_tranx_old-checkup.
**        IF l_changed = 'X'.
**          ls_sap_tranx-checkup-zref_doc = ls_sap_tranx-paymorder.
**        ENDIF.
        set_admin_fields(
                  EXPORTING
                    im_new_entry = l_new
                  CHANGING
                    cs_admin = ls_sap_tranx-dbadmin ).
        APPEND ls_sap_tranx TO sap_new_transactions.
      ENDIF.

      CLEAR: l_new,
             l_changed,
             ls_sap_tranx_old.

    ENDLOOP.


  ENDMETHOD.


METHOD filter_trans_by_shifton_date.

    DATA(l_shifton_date) = get_account_shifton_date( im_s_sap_field ).

    IF l_shifton_date IS INITIAL.
*  账户尚未切换
      re_valid = space.
      RETURN.
    ENDIF.

    IF sy-datum < l_shifton_date.
*      当前日期小于切换日期
      re_valid = space.
      RETURN.
    ENDIF.

    IF im_transaction_date < l_shifton_date.
*      交易日期日期小于切换日期
      re_valid = space.
      RETURN.
    ENDIF.

    re_valid = 'X'.
  ENDMETHOD.


METHOD finished_sap_tranx_fields.
    DATA: lt_tranx TYPE ztrt_bank_trans_tab.

    IF ch_t_tranx IS INITIAL.
      RETURN.
    ENDIF.

    lt_tranx = ch_t_tranx.
    SORT lt_tranx BY bukrs
                     hbkid
                     hktid.
    DELETE ADJACENT DUPLICATES FROM lt_tranx
          COMPARING bukrs
                    hbkid
                    hktid.
    SELECT bukrs,
           hbkid,
           hktid,
           banks,
           hkont
           INTO TABLE @DATA(lt_0013)
           FROM ztrt0013
           FOR ALL ENTRIES IN @lt_tranx
           WHERE bukrs = @lt_tranx-bukrs
           AND   hbkid = @lt_tranx-hbkid
           AND   hktid = @lt_tranx-hktid.

    LOOP AT ch_t_tranx ASSIGNING FIELD-SYMBOL(<fs_tranx>).
      READ TABLE lt_0013 INTO DATA(ls_0013)
           WITH KEY bukrs = <fs_tranx>-bukrs
                    hbkid = <fs_tranx>-hbkid
                    hktid = <fs_tranx>-hktid.
      IF sy-subrc = 0.
        <fs_tranx>-banks = ls_0013-banks.
        <fs_tranx>-hkont = ls_0013-hkont.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.


METHOD get_account_currency.
    SELECT SINGLE waers INTO re_waers
           FROM ztrt0013
           WHERE bukrs = IM_S_ACCOUNT_KEY-sap_bukrs
           AND   hbkid = IM_S_ACCOUNT_KEY-sap_hbkid
           AND   hktid = IM_S_ACCOUNT_KEY-sap_hktid.
  ENDMETHOD.


METHOD get_account_shifton_date.
    SELECT SINGLE datum INTO re_date
                FROM ztrt_bank_shift
                WHERE bukrs = im_s_sap_field-sap_bukrs
                AND   hbkid = im_s_sap_field-sap_hbkid
                AND   hktid = im_s_sap_field-sap_hktid.
  ENDMETHOD.


METHOD get_paymkey_from_transaction.
    DATA: l_string TYPE string.

    IF im_raw_text IS INITIAL.
      RETURN.
    ENDIF.

    l_string = im_raw_text.

    FIND im_pattern
         IN l_string.

    IF sy-subrc <> 0.
      RETURN.
    ENDIF.

    REPLACE im_pattern
            IN l_string
            WITH space.
    CONDENSE l_string.

    IF strlen( l_string ) <> 10.
*      小于或大于支付单的长度（支付单十个字符）
      RETURN.
    ENDIF.

    re_key-paymorder = l_string.

  ENDMETHOD.


METHOD if_error.
    re_error = messages->if_error( ).
  ENDMETHOD.


METHOD set_account_balance.
    IF set_account_balance_starting( im_data ) = yes.
      set_account_balance_core( im_data ).
    ENDIF.
    set_account_balance_ending( ).
  ENDMETHOD.


##NEEDED
  method SET_ACCOUNT_BALANCE_CORE.
*    to be re-defined
  endmethod.


METHOD set_account_balance_ending.
    CONVERT_ACCBALANCE_INTO_SAP( ).
    update_account_balance( ).
  ENDMETHOD.


METHOD set_account_balance_starting.
    re_continue = yes.

    check_account_object(
               im_data = im_data
               im_tabname = account_balance_db_tabname
               im_new_entries_data_reference = new_account_balance ).
    IF if_error( ) = yes.
      re_continue = no.
      RETURN.
    ENDIF.

    MESSAGE i209(ztr_bank_application)
            WITH bank_indicator
                 action
                 zcl_bank_enviroment=>s_get_bank_action_text( action )
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = account_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = action
                      bank_ind     = bank_indicator ) ).
  ENDMETHOD.


METHOD set_account_tabname.
    IF transaction_db_tabname IS NOT INITIAL.
      CREATE DATA new_transactions TYPE TABLE OF (transaction_db_tabname).
    ENDIF.

    IF account_balance_db_tabname IS NOT INITIAL.
      CREATE DATA new_account_balance TYPE TABLE OF (account_balance_db_tabname).
    ENDIF.

    if HISTORY_ACC_BALANCE_DB_NAME is NOT INITIAL.
      CREATE DATA NEW_HISTORY_ACCOUNT_BALANCE TYPE TABLE OF (HISTORY_ACC_BALANCE_DB_NAME).
    endif.
  ENDMETHOD.


METHOD set_admin_fields.
    MOVE: system_info-timestamp TO cs_admin-update_timestamp,
          system_info-timezone TO cs_admin-update_timezone.

    IF im_new_entry = 'X'.
      MOVE: system_info-datum TO cs_admin-erdat,
            system_info-uzeit TO cs_admin-erzet,
            system_info-uname TO cs_admin-ernam.
    ELSE.
      MOVE: system_info-datum TO cs_admin-aedat,
            system_info-uzeit TO cs_admin-aezet,
            system_info-uname TO cs_admin-aenam.
    ENDIF.

  ENDMETHOD.


METHOD set_customer_code_by_name.
##WARN_OK
    SELECT SINGLE kunnr INTO re_code
           FROM kna1
           WHERE ( ktokd = 'Z001'
           or    ktokd = 'Z003' )
           and   name1 = im_name.
  ENDMETHOD.


METHOD set_data.
    IF set_data_starting( im_data ) = yes.
      set_data_core( im_data ).
    ENDIF.
    set_data_ending( ).
  ENDMETHOD.


METHOD set_data_core.
    CASE action.
      WHEN zif_bank_action=>action_is_get_transactions.
        set_transactions( im_data ).
      WHEN zif_bank_action=>action_is_account_balance.
        set_account_balance( im_data ).
      WHEN zif_bank_action=>action_is_acc_history_balance.
        set_history_account_balance( im_data ).
    ENDCASE.
  ENDMETHOD.


METHOD set_data_ending.
    MESSAGE i210(ztr_bank_application)
            WITH bank_indicator
                 action
                 zcl_bank_enviroment=>s_get_bank_action_text( action )
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = account_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = action
                      bank_ind     = bank_indicator ) ).

  ENDMETHOD.


METHOD set_data_starting.

    MESSAGE i209(ztr_bank_application)
            WITH bank_indicator
                 action
                 zcl_bank_enviroment=>s_get_bank_action_text( action )
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = account_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = action
                      bank_ind     = bank_indicator ) ).

    set_account_tabname( ).
    re_continue = yes.
    ASSIGN im_data->* TO FIELD-SYMBOL(<ft_data>).
    IF <ft_data> IS NOT ASSIGNED OR
       <ft_data> IS INITIAL.
      MESSAGE i211(ztr_bank_application)
              WITH bank_indicator
                   action
                   zcl_bank_enviroment=>s_get_bank_action_text( action )
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = account_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator ) ).

      re_continue = no.
    ENDIF.

  ENDMETHOD.


METHOD set_history_account_balance.
    IF set_history_acc_bal_starting( im_data ) = yes.
      set_history_acc_bal_core( im_data ).
    ENDIF.
    set_history_acc_bal_ending( ).
  ENDMETHOD.


##NEEDED
  method SET_HISTORY_ACC_BAL_CORE.
*    to be re-defined
  endmethod.


METHOD set_history_acc_bal_ending.
    convert_hisaccbal_into_sap( ).
    update_history_account_balance( ).
  ENDMETHOD.


METHOD set_history_acc_bal_starting.
    re_continue = yes.

    check_account_object(
               im_data = im_data
               im_tabname = history_acc_balance_db_name
               im_new_entries_data_reference = new_history_account_balance ).
    IF if_error( ) = yes.
      re_continue = no.
      RETURN.
    ENDIF.

    MESSAGE i209(ztr_bank_application)
            WITH bank_indicator
                 action
                 zcl_bank_enviroment=>s_get_bank_action_text( action )
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = account_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = action
                      bank_ind     = bank_indicator ) ).
  ENDMETHOD.


METHOD set_partner_by_name.
    re_partner-lifnr2 = set_vendor_code_by_name( im_name ).
    re_partner-kunnr2  = set_customer_code_by_name( im_name ).
    re_partner-lifnr = re_partner-lifnr2.
    re_partner-kunnr = re_partner-kunnr2.
  ENDMETHOD.


METHOD set_transactions.
    IF set_transactions_starting( im_data ) = yes.
      set_transactions_core( im_data ).
    ENDIF.
    set_transactions_ending( ).
  ENDMETHOD.


##NEEDED
  method SET_TRANSACTIONS_CORE.
*    to be re-defined
  endmethod.


METHOD set_transactions_ending.
    convert_tranx_into_sap( ).
    update_transactions( ).
  ENDMETHOD.


METHOD set_transactions_starting.

    re_continue = yes.

    check_account_object(
               im_data = im_data
               im_tabname = transaction_db_tabname
               im_new_entries_data_reference = new_transactions ).
    IF if_error( ) = yes.
      re_continue = no.
      RETURN.
    ENDIF.

    MESSAGE i209(ztr_bank_application)
            WITH bank_indicator
                 action
                 zcl_bank_enviroment=>s_get_bank_action_text( action )
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = account_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = action
                      bank_ind     = bank_indicator ) ).

  ENDMETHOD.


METHOD set_vendor_code_by_name.
##WARN_OK
    SELECT SINGLE lifnr INTO re_code
           FROM lfa1
           WHERE ( KTOKK = 'S001'
           or    KTOKK = 'S003' )
           and   name1 = im_name.
  ENDMETHOD.


METHOD update_account_balance.
    FIELD-SYMBOLS: <ft_account_balance> TYPE STANDARD TABLE.
    DATA l_lines TYPE i.

    ASSIGN new_account_balance->* TO <ft_account_balance>.
    IF <ft_account_balance> IS ASSIGNED AND
       <ft_account_balance> IS NOT INITIAL.
*      ASSIGN new_account_balance->* TO <ft_account_balance>.
      MODIFY (account_balance_db_tabname) FROM TABLE <ft_account_balance>.
      l_lines = lines( <ft_account_balance> ).
    ENDIF.


    MESSAGE i221(ztr_bank_application)
            WITH bank_indicator
                 action
                 zcl_bank_enviroment=>s_get_bank_action_text( action )
                 l_lines
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = account_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = action
                      bank_ind     = bank_indicator ) ).

    IF sap_new_account_balance IS NOT INITIAL.
      MODIFY ztrt2090 FROM TABLE sap_new_account_balance.
    ENDIF.
    l_lines = lines( sap_new_account_balance ).

    MESSAGE i222(ztr_bank_application)
            WITH bank_indicator
                 action
                 zcl_bank_enviroment=>s_get_bank_action_text( action )
                 l_lines
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = account_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = action
                      bank_ind     = bank_indicator ) ).

    COMMIT WORK AND WAIT.

    IF <ft_account_balance> IS ASSIGNED AND
       <ft_account_balance> IS NOT INITIAL.
      dequeue_balance( <ft_account_balance> ).
    ENDIF.
  ENDMETHOD.


METHOD update_history_account_balance.
    FIELD-SYMBOLS: <ft_account_balance> TYPE STANDARD TABLE.
    DATA l_lines TYPE i.

    ASSIGN new_history_account_balance->* TO <ft_account_balance>.
    IF <ft_account_balance> IS ASSIGNED AND
       <ft_account_balance> IS NOT INITIAL.
      MODIFY (history_acc_balance_db_name) FROM TABLE <ft_account_balance>.
      l_lines = lines( <ft_account_balance> ).
    ENDIF.


    MESSAGE i367(ztr_bank_application)
            WITH bank_indicator
                 action
                 zcl_bank_enviroment=>s_get_bank_action_text( action )
                 l_lines
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = account_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = action
                      bank_ind     = bank_indicator ) ).

    IF sap_new_history_acc_balance IS NOT INITIAL.
      MODIFY ztrt2091 FROM TABLE sap_new_history_acc_balance.
    ENDIF.
    l_lines = lines( sap_new_account_balance ).

    MESSAGE i368(ztr_bank_application)
            WITH bank_indicator
                 action
                 zcl_bank_enviroment=>s_get_bank_action_text( action )
                 l_lines
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = account_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = action
                      bank_ind     = bank_indicator ) ).

    COMMIT WORK AND WAIT.

  ENDMETHOD.


METHOD update_payment_status.
    DATA:lt_paymorder_buffer TYPE ztrs_paymorder_buffer_tab.
    DATA l_task TYPE char20.

    LOOP AT sap_new_transactions INTO DATA(ls_transaction)
          WHERE paymorder IS NOT INITIAL .
      APPEND VALUE #( docno = ls_transaction-paymorder ) TO lt_paymorder_buffer.
    ENDLOOP.

    IF lt_paymorder_buffer IS INITIAL.
      RETURN.
    ENDIF.

    SORT lt_paymorder_buffer BY docno.
    DELETE ADJACENT DUPLICATES FROM lt_paymorder_buffer COMPARING ALL FIELDS.

    l_task = bank_indicator &&
             sy-datum &&
             sy-uzeit.

    CALL FUNCTION 'ZFM_TR_ACC_TRAN_TRIGGER_CHKSTA' DESTINATION 'NONE'
      STARTING NEW TASK l_task
      EXPORTING
        im_t_paymorder_buffer = lt_paymorder_buffer
        im_bank_indicator     = bank_indicator.

  ENDMETHOD.


METHOD update_sap_transactions.
    DATA: lt_old_transactions TYPE ztrt_bank_trans_tab.
    DATA: l_lines TYPE i.

    IF im_t_sap_transactions IS INITIAL.
      RETURN.
    ENDIF.

    SELECT * INTO TABLE lt_old_transactions
           FROM ztrt_bank_trans
           FOR ALL ENTRIES IN im_t_sap_transactions
           WHERE bukrs = im_t_sap_transactions-bukrs
           AND   hbkid = im_t_sap_transactions-hbkid
           AND   hktid = im_t_sap_transactions-hktid
           AND   yhzh = im_t_sap_transactions-yhzh
           AND   trxno = im_t_sap_transactions-trxno.

    LOOP AT im_t_sap_transactions INTO DATA(ls_new_transaction).
      READ TABLE lt_old_transactions INTO DATA(ls_old_transaction)
           WITH KEY bukrs = ls_new_transaction-bukrs
                    hbkid = ls_new_transaction-hbkid
                    hktid = ls_new_transaction-hktid
                    yhzh = ls_new_transaction-yhzh
                    trxno = ls_new_transaction-trxno.
      IF sy-subrc = 0.
        IF ls_new_transaction-balamt <> ls_old_transaction-balamt." OR
*            ls_new_transaction-zref_doc <> ls_old_transaction-zref_doc OR
*            ls_new_transaction-zgroup <> ls_old_transaction-zgroup OR
*            ls_new_transaction-zgroup_ac <> ls_old_transaction-zgroup_ac.
          l_lines = l_lines + 1.
          UPDATE ztrt_bank_trans
                 SET balamt    = ls_new_transaction-balamt
*                     zref_doc = ls_new_transaction-zref_doc
*                     zgroup = ls_new_transaction-zgroup
*                     zgroup_ac = ls_new_transaction-zgroup_ac
                     aedat = ls_new_transaction-aedat
                     aenam = ls_new_transaction-aenam
                     aezet = ls_new_transaction-aezet
                 WHERE bukrs = ls_new_transaction-bukrs
                 AND   hbkid = ls_new_transaction-hbkid
                 AND   hktid = ls_new_transaction-hktid
                 AND   yhzh = ls_new_transaction-yhzh
                 AND   trxno = ls_new_transaction-trxno.
        ENDIF.
      ELSE.
        l_lines = l_lines + 1.
        INSERT ztrt_bank_trans FROM ls_new_transaction.
      ENDIF.
    ENDLOOP.

    l_lines = lines( sap_new_transactions ).

    MESSAGE i220(ztr_bank_application)
            WITH bank_indicator
                 action
                 zcl_bank_enviroment=>s_get_bank_action_text( action )
                 l_lines
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = account_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = action
                      bank_ind     = bank_indicator ) ).
  ENDMETHOD.


METHOD update_transactions.
    DATA: l_lines TYPE i.

    FIELD-SYMBOLS: <ft_transactions> TYPE STANDARD TABLE.
    ASSIGN new_transactions->* TO <ft_transactions>.
    IF  <ft_transactions> IS ASSIGNED AND
         <ft_transactions> IS NOT INITIAL.
      l_lines = lines( <ft_transactions> ).
      MODIFY (transaction_db_tabname) FROM TABLE <ft_transactions>.
    ENDIF.

    MESSAGE i219(ztr_bank_application)
            WITH bank_indicator
                 action
                 zcl_bank_enviroment=>s_get_bank_action_text( action )
                 l_lines
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = account_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = action
                      bank_ind     = bank_indicator ) ).




    IF sap_new_transactions IS NOT INITIAL.
      SORT sap_new_transactions  BY bukrs
                                    hbkid
                                    hktid
                                    yhzh
                                    trxno.
      zcl_tr_3024_gui=>chang_item(
                          CHANGING
                            it_item = sap_new_transactions ).
      update_sap_transactions( sap_new_transactions ).
*      MODIFY ztrt_bank_trans FROM TABLE sap_new_transactions.
      update_payment_status( ).
    ENDIF.
*    l_lines = lines( sap_new_transactions ).
*
*    MESSAGE i220(ztr_bank_application)
*            WITH bank_indicator
*                 action
*                 zcl_bank_enviroment=>s_get_bank_action_text( action )
*                 l_lines
*            INTO dummy_message.
*    zcl_bank_logger_protocal=>add_log(
*             VALUE #( uuid         = account_uuid
*                      msgid        = sy-msgid
*                      msgno        = sy-msgno
*                      msgty        = sy-msgty
*                      msgv1        = sy-msgv1
*                      msgv2        = sy-msgv2
*                      msgv3        = sy-msgv3
*                      msgv4        = sy-msgv4
*                      message      = dummy_message
*                      bank_action  = action
*                      bank_ind     = bank_indicator ) ).

    COMMIT WORK AND WAIT.

    IF  <ft_transactions> IS ASSIGNED AND
     <ft_transactions> IS NOT INITIAL.
      dequeue_transaction( <ft_transactions> ).
    ENDIF.
  ENDMETHOD.
ENDCLASS.
