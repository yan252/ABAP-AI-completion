FUNCTION-POOL ZFG_TR_CHECK_TEST_V2.                 "MESSAGE-ID ..

TYPES: BEGIN OF lty_s_lockw,"锁定的周资金计划的行项目
         bguid TYPE guid_32,
         itemn TYPE ztr_itemn,
       END OF lty_s_lockw,

       BEGIN OF lty_s_lockhp,"锁住的汇票
         docno_key TYPE ztr_docno_base,
         zjsno     TYPE ztr_jsno,
       END OF lty_s_lockhp.

* INCLUDE LZFG_TR_CHECKD...                  " Local class definition

DATA: ls_2001   TYPE ztrt2001, "支付单抬头
      ls_2002   TYPE ztrt2002, "支付单信息-收款银行信息
      ls_2003   TYPE ztrt2003, "支付单-付款银行信息
      lt_2004   TYPE STANDARD TABLE OF ztrt2004, "付款明细-挂账
      lt_2005   TYPE STANDARD TABLE OF ztrt2005, "付款明细-预付款
*      ls_2006 TYPE ztrt2006,"支付单-银行转账支付信息
*      ls_2007 TYPE ztrt2007,"
      ls_2008   TYPE ztrt2008, "支付单-汇票支付单抬头
      lt_return TYPE STANDARD TABLE OF bapiret2,
      lt_lockhp TYPE STANDARD TABLE OF lty_s_lockhp,
      lt_lockw  TYPE STANDARD TABLE OF lty_s_lockw,
      lt_2009   TYPE STANDARD TABLE OF ztrt2009. "支付单-汇票支付行项目
