FUNCTION ZFM_TR_BANK_CHKPAYM_CORE.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     VALUE(IM_T_ENTRY_LIST) TYPE  ZTRS_PAYMENTENTRY_LIST_TAB
*"     VALUE(IM_BANK_ACTION) TYPE  ZTR_APP_ACTION_FOR_BANK
*"         DEFAULT '004'
*"     VALUE(IM_TRIGGER_BY_ACC_TRANX) TYPE  CHAR01 OPTIONAL
*"--------------------------------------------------------------------
******  log
  IF zcl_bank_logger_protocal=>receive_payment_entry_in_api(
*                                im_action       = zif_bank_action=>action_is_check_payments
                                im_action       = im_bank_action
                                im_t_entry_list = im_t_entry_list ) = space.
    RETURN.
  ENDIF.
******  log end
*  DATA(lo_action) = zcl_bank_abstract_action=>create( zif_bank_action=>action_is_check_payments ).
  DATA(lo_action) = zcl_bank_abstract_action=>create( im_bank_action ).
  IF lo_action IS BOUND.
    IF im_trigger_by_acc_tranx = 'X'.
      zcl_bank_payment_entry=>set_triger_by_account_tranx( ).
    ENDIF.
    lo_action->set_entries( im_t_entry_list ).
    lo_action->run( ).
  ENDIF.

*  zcl_bank_logger_protocal=>end_logs( 'X' ).
  zcl_bank_logger_protocal=>end_logs( im_bank_action ).





ENDFUNCTION.
