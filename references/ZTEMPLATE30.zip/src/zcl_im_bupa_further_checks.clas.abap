class ZCL_IM_BUPA_FURTHER_CHECKS definition
  public
  final
  create public .

public section.

  interfaces IF_EX_BUPA_FURTHER_CHECKS .
protected section.
private section.
ENDCLASS.



CLASS ZCL_IM_BUPA_FURTHER_CHECKS IMPLEMENTATION.


METHOD if_ex_bupa_further_checks~check_central.

*(SAPLZZOKTBUPA_BDT)GT_ZBUT0000NXTYNR_D[1]-ZZBANKS
*(SAPLZZOKTBUPA_BDT)GT_ZBUT0000NXTYNR[1]-ZZBANKS
*    break-point .

    CHECK zcl_tr_3019_gui=>mv_bp_no_check = abap_false.

    IF  is_but000-bu_group <> 'A002' .
      RETURN .
    ENDIF.
    DATA lv_text TYPE text100.

    FIELD-SYMBOLS: <fs_tab> TYPE ANY TABLE.

    DATA(lt_tab) = '(SAPLZZOKTBUPA_BDT)GT_ZBUT0000NXTYNR[]'.  "[1]-ZZBANKS'.
    "ZZBANKL'.
    ASSIGN (lt_tab) TO <fs_tab> .

    IF <fs_tab> IS NOT ASSIGNED .
      RETURN .
    ENDIF.

    IF <fs_tab> IS INITIAL .
      MESSAGE e154(ztr01)  INTO lv_text.
      CALL FUNCTION 'ISU_CRM_IL_BAPIRET2_FILL'
        CHANGING
          ct_msg = et_return.
      RETURN.

    ELSE.

    ENDIF.



    LOOP AT <fs_tab> ASSIGNING FIELD-SYMBOL(<fs_line>).

      IF sy-tabix = 2.
        MESSAGE e153(ztr02)  INTO lv_text.
        CALL FUNCTION 'ISU_CRM_IL_BAPIRET2_FILL'
          CHANGING
            ct_msg = et_return.
        EXIT.
      ENDIF.

      ASSIGN COMPONENT 'ZZBANKS' OF STRUCTURE  <fs_line> TO FIELD-SYMBOL(<fs_banks>).
      ASSIGN COMPONENT 'ZZBANKL' OF STRUCTURE  <fs_line> TO FIELD-SYMBOL(<fs_bankl>).
      ASSIGN COMPONENT 'ZZBANK_IND' OF STRUCTURE  <fs_line> TO FIELD-SYMBOL(<fs_ind>).
      IF <fs_banks> IS INITIAL OR <fs_bankl> IS INITIAL .
        MESSAGE e154(ztr01) INTO lv_text.
        CALL FUNCTION 'ISU_CRM_IL_BAPIRET2_FILL'
          CHANGING
            ct_msg = et_return.
        EXIT.
      ELSE.
        SELECT SINGLE bank_ind INTO @DATA(lv_ind)  FROM bnka WHERE banks = @<fs_banks>
                                                               AND bankl = @<fs_bankl> .
        IF sy-subrc <> 0 .
          MESSAGE e154(ztr02) INTO lv_text.
          CALL FUNCTION 'ISU_CRM_IL_BAPIRET2_FILL'
            CHANGING
              ct_msg = et_return.
          EXIT.
        ELSE.
          IF  <fs_ind>  IS INITIAL AND lv_ind IS NOT INITIAL .
            <fs_ind> = lv_ind .
          ELSE.
            IF lv_ind IS NOT INITIAL AND <fs_ind> <> lv_ind AND <fs_banks> = 'CN'.
              MESSAGE e152(ztr02) INTO lv_text.
              CALL FUNCTION 'ISU_CRM_IL_BAPIRET2_FILL'
                CHANGING
                  ct_msg = et_return.
              EXIT.
            ENDIF.
          ENDIF.


        ENDIF.
      ENDIF.
    ENDLOOP.




  ENDMETHOD.
ENDCLASS.
