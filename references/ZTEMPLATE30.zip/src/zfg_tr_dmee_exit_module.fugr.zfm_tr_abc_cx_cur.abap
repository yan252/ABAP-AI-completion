FUNCTION ZFM_TR_ABC_CX_CUR.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     VALUE(I_TREE_TYPE) TYPE  DMEE_TREETYPE_ABA
*"     VALUE(I_TREE_ID) TYPE  DMEE_TREEID_ABA
*"     VALUE(I_ITEM)
*"     VALUE(I_PARAM)
*"     VALUE(I_UPARAM)
*"  EXPORTING
*"     REFERENCE(O_VALUE)
*"     REFERENCE(C_VALUE)
*"     REFERENCE(N_VALUE)
*"     REFERENCE(P_VALUE)
*"  TABLES
*"      I_TAB
*"--------------------------------------------------------------------
FIELD-SYMBOLS <ztst> TYPE ztrs_dmee_account_list.

  ASSIGN COMPONENT 'ZTRS_DMEE_ACCOUNT_LIST' OF STRUCTURE i_item TO <ztst>.

  DATA:wr(3),
       wr1(5) .
  SELECT SINGLE waers
    FROM ztrt0013
    INTO @DATA(waers)
    WHERE  yhzh = @<ztst>-bankn .
  wr1 = waers.
  CONDENSE wr1.
  wr = wr1+0(3).
  SELECT SINGLE curcode
    INTO  c_value
    FROM ztrt_abc_cur
    WHERE cur = wr.





ENDFUNCTION.
