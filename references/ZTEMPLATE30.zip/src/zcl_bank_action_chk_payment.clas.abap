class ZCL_BANK_ACTION_CHK_PAYMENT definition
  public
  inheriting from ZCL_BANK_ABSTRACT_ACTION
  final
  create public .

public section.

  interfaces ZIF_BANK_ACTION_PAYMENT_RELATE .
protected section.

  methods FEEDBACK_FROM_BANK_CORE
    redefinition .
  methods PREPARE_CORE
    redefinition .
  methods RUN_FOR_SPECIFIC_ACTION_CORE
    redefinition .
private section.

  data PAYMENT_ENTRIES type ZTRS_PAYMENTORDER_ENTRY_TAB .

  methods CREATE_PAYMENTRY_BY_ENTRY
    importing
      !IM_UUID type ZTR_PAYMENT_ENTRY_UUID
    returning
      value(RO_INSTANCE) type ref to ZCL_BANK_PAYMENT_ENTRY .
  methods UPDATE_PAYMENT_ENTRY
    importing
      !IM_BANK_INDICATOR type ZTR_BANK_INDICATOR
      !IM_FEEDBACK_FROM_BANK type ZTRT_PAYMENT_ENTRY_FROM_BANK
      !IM_S_BANK_ERROR_STEP type ZTRS_ERROR_STEP_EXT optional
      !IM_DELETE_ENTRY_INSTANCE type FLAG optional
      !IM_FROM_EXTERNAL type FLAG optional .
  methods LOCK_PAYMENT_ORDER
    importing
      !IM_DOCNO type ZTRT2001-DOCNO
    returning
      value(RE_IF_LOCKED) type FLAG .
  methods DELOCK_PAYMENT_ORDER
    importing
      !IM_DOCNO type ZTRT2001-DOCNO .
ENDCLASS.



CLASS ZCL_BANK_ACTION_CHK_PAYMENT IMPLEMENTATION.


METHOD create_paymentry_by_entry.

    SELECT SINGLE entry_cls INTO @DATA(l_entry_class)
           FROM ztrt_act_entry
           WHERE action = @action.
    IF sy-subrc = 0.
      CREATE OBJECT ro_instance TYPE (l_entry_class)
        EXPORTING
          im_creation_type    = zcl_bank_payment_entry=>create_from_payment_entry
          im_uuid             = im_uuid
        EXCEPTIONS
          creation_type_error = 1
          create_uuid_error   = 2
          uuid_error          = 3.
      IF sy-subrc <> 0.
*      unexpected technical error
*      the error should by solved by testing
        MESSAGE ID sy-msgid
                TYPE sy-msgty
                NUMBER sy-msgno
                WITH sy-msgv1
                     sy-msgv2
                     sy-msgv3
                     sy-msgv4.
      ENDIF.
    ELSE.
      MESSAGE e265
              WITH action.
    ENDIF.
  ENDMETHOD.


method DELOCK_PAYMENT_ORDER.
    CALL FUNCTION 'ZFM_TR_DELOCK_PAYMENTORDER'
      EXPORTING
        im_docno = im_docno.
  endmethod.


METHOD feedback_from_bank_core.
    DATA: lt_response_entries TYPE ztrt_payment_entry_from_bank.

    LOOP AT banks_list INTO DATA(ls_bank_list)
          WHERE instance IS BOUND.
      ls_bank_list-instance->export_after_processed(
        IMPORTING
          et_entries = lt_response_entries
          ex_s_error_step = DATA(ls_error_step) ).

      update_payment_entry(
               EXPORTING
                  im_bank_indicator = ls_bank_list-bank_ind
                  im_feedback_from_bank = lt_response_entries
                  im_s_bank_error_step = ls_error_step ).
      CLEAR: lt_response_entries,
             ls_error_step.
    ENDLOOP.
  ENDMETHOD.


METHOD lock_payment_order.
    CALL FUNCTION 'ZFM_TR_LOCK_PAYMENTORDER'
      EXPORTING
        im_docno       = im_docno
      EXCEPTIONS
        foreign_lock   = 1
        system_failure = 2
        OTHERS         = 3.

    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid
              TYPE sy-msgty
              NUMBER sy-msgno
              WITH sy-msgv1
                   sy-msgv2
                   sy-msgv3
                   sy-msgv4
              INTO dummy_message.
      MESSAGE w339(ztr_bank_application)
              WITH dummy_message
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        paymorder    = im_docno
                        bank_action  = action ) ).
    ELSE.
      re_if_locked = yes.
    ENDIF.
  ENDMETHOD.


METHOD prepare_core.
    DATA: ls_payment_entry                 TYPE ztrs_paymentorder_entry.
    FIELD-SYMBOLS: <ft_payment_entry_list> TYPE ztrs_paymententry_list_tab.

    ASSIGN entries_reference->* TO <ft_payment_entry_list>.

    LOOP AT <ft_payment_entry_list> ASSIGNING FIELD-SYMBOL(<fs_entry>).
      IF lock_payment_order( ls_payment_entry-key-paymorder ) = no.
        CONTINUE.
      ENDIF.
      ls_payment_entry-instance = create_paymentry_by_entry( <fs_entry>-entuuid ).
      ls_payment_entry-instance->set_entry( ).
      ls_payment_entry-instance->set_status_from_transaction( ).
      IF ls_payment_entry-instance->if_check_status( ) = no OR
          ls_payment_entry-instance->if_triger_by_account_tranx( ) = yes.
        delock_payment_order( ls_payment_entry-key-paymorder ).
        CONTINUE.
      ENDIF.
      ls_payment_entry-entuuid  = <fs_entry>-entuuid.
      ls_payment_entry-doc1r    = ls_payment_entry-instance->get_reference_doc( ).
      ls_payment_entry-paymorder = ls_payment_entry-doc1r.
      ls_payment_entry-bank_ind = ls_payment_entry-instance->get_bank_indicator( ).
      ls_payment_entry-key = ls_payment_entry-instance->get_payment_key( ).

      APPEND ls_payment_entry TO payment_entries.
      CLEAR ls_payment_entry.
    ENDLOOP.
  ENDMETHOD.


method RUN_FOR_SPECIFIC_ACTION_CORE.
    LOOP AT payment_entries
          INTO DATA(ls_payment_entry)
          WHERE instance IS BOUND.
      IF ls_payment_entry-instance->if_error( ) = no.
        create_bank( ls_payment_entry-instance->get_bank_indicator( ) )->set_single_entry( ls_payment_entry-instance->export_entry( ) ).
      ELSE.
        ls_payment_entry-instance->destroy( ).
        FREE ls_payment_entry-instance.
        DELETE payment_entries WHERE entuuid = ls_payment_entry-entuuid.
**        "end with error on SAP applicaion level
      ENDIF.
    ENDLOOP.
  endmethod.


METHOD update_payment_entry.
*    start log
    IF im_from_external = space.
      MESSAGE i195(ztr_bank_application)
              WITH action
                   zcl_bank_enviroment=>s_get_bank_action_text( action )
                   im_bank_indicator
              INTO dummy_message.
    ELSE.
      MESSAGE i361(ztr_bank_application)
              WITH action
                   zcl_bank_enviroment=>s_get_bank_action_text( action )
                   im_bank_indicator
              INTO dummy_message.
    ENDIF.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = action_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = action
                      bank_ind     =  im_bank_indicator ) ).
*    end log
    LOOP AT payment_entries INTO DATA(ls_payment_entry)
          WHERE bank_ind = im_bank_indicator.
      READ TABLE im_feedback_from_bank INTO DATA(ls_feedback_from_bank)
            WITH KEY doc1r = ls_payment_entry-doc1r.
*           WITH KEY bank_ind = ls_payment_entry-bank_ind
*                    paymorder  = ls_payment_entry-paymorder.
      IF sy-subrc <> 0.
*        没有执行发送到银行的步骤或发送失败
        CLEAR ls_feedback_from_bank.
        IF im_s_bank_error_step-int IS INITIAL.
          IF im_from_external IS INITIAL.
*          程序错误
            MESSAGE x997 WITH 'UPDATE_PAYMENT_ENTRY'.
          ELSE.
            CONTINUE.
          ENDIF.
        ENDIF.
      ENDIF.
      ls_payment_entry-instance->feedback_from_bank(
                     EXPORTING
                       im_s_bank_feedback = ls_feedback_from_bank
                       im_s_bank_error_step = im_s_bank_error_step ).

      IF im_from_external = space.
        delock_payment_order( ls_payment_entry-paymorder ).
      ELSE.
        IF im_delete_entry_instance IS NOT INITIAL.
          delock_payment_order( ls_payment_entry-paymorder ).
          DELETE payment_entries WHERE bank_ind = ls_payment_entry-bank_ind
                                 AND   doc1r = ls_payment_entry-doc1r.
        ENDIF.
      ENDIF.
    ENDLOOP.

*    start log
    IF im_from_external = space.
      MESSAGE i196(ztr_bank_application)
              WITH action
                   zcl_bank_enviroment=>s_get_bank_action_text( action )
                   im_bank_indicator
              INTO dummy_message.
    ELSE.
      MESSAGE i362(ztr_bank_application)
              WITH action
                   zcl_bank_enviroment=>s_get_bank_action_text( action )
                   im_bank_indicator
              INTO dummy_message.
    ENDIF.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = action_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = action
                      bank_ind = im_bank_indicator  ) ).
*    end log
  ENDMETHOD.


METHOD zif_bank_action_payment_relate~update_entry_from_external.
    update_payment_entry(
             EXPORTING
                im_bank_indicator = im_bank_indicator
                im_feedback_from_bank = im_feedback_from_bank
                im_s_bank_error_step = im_s_bank_error_step
                im_delete_entry_instance = im_delete_entry_instance
                im_from_external = yes  ).
  ENDMETHOD.
ENDCLASS.
