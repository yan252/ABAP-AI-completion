*"* use this source file for any type of declarations (class
*"* definitions, interfaces or type declarations) you need for
*"* components in the private section
CLASS lcl_receiver DEFINITION.
  PUBLIC SECTION.
    DATA: container TYPE REF TO cl_gui_dialogbox_container.
    DATA: grid TYPE REF TO cl_gui_alv_grid.
    METHODS constructor.
    METHODS: on_close
        FOR EVENT close
        OF cl_gui_dialogbox_container.
  PROTECTED SECTION.

  PRIVATE SECTION.

ENDCLASS.                    "lcl_receiver DEFINITION
