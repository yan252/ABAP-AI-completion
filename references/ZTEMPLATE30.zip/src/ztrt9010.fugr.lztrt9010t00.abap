*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZTRT9010........................................*
DATA:  BEGIN OF STATUS_ZTRT9010                      .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZTRT9010                      .
CONTROLS: TCTRL_ZTRT9010
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZTRT9010                      .
TABLES: ZTRT9010                       .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
