class ZCL_WD_TREE definition
  public
  final
  create public .

public section.

  class-data IS_TREE_ALL type ZSTREE001 .

  class-methods INIT_TREE
    importing
      !EMBEDDING_POSITION type STRING
      !LT_TREE type ZSTREE001_TAB
      !L_VIEW_CONTROLLER_API type ref to IF_WD_VIEW_CONTROLLER
      !SOURCE_WINDOW_NAME type STRING
      !SOURCE_VUSAGE_NAME type STRING
      !SOURCE_PLUG_NAME type STRING
      !TARGET_PLUG_NAME type STRING default 'DEFAULT'
      !TARGET_VIEW_NAME type STRING default 'W_WINDOW'
      !IN_TREE_NAME type STRING optional
      !IN_TREE_ROOT_NAME type STRING optional .
  class-methods GET_TREE_INFONODE
    exporting
      !ES_TREENODE type ZSTREE001 .
  class-methods SET_TREE_INFONODE
    importing
      !LS_TREENODE type ZSTREE001 .
protected section.
private section.
ENDCLASS.



CLASS ZCL_WD_TREE IMPLEMENTATION.


METHOD get_tree_infonode.
    es_treenode = is_tree_all.
  ENDMETHOD.


METHOD init_tree.
    DATA wa_cmp_usage   TYPE wdapi_component_usage.
*    DATA l_view_controller_api TYPE REF TO if_wd_view_controller.
    DATA l_component_api       TYPE REF TO if_wd_component.
    DATA l_intf_controller     TYPE REF TO ziwci_wd_ab_0001.

    wa_cmp_usage-used_component       = 'ZWD_AB_0001'.
    wa_cmp_usage-embedding_position   = embedding_position. "当前VIEW需要显示的Containerelement

    TRY.
        wa_cmp_usage-component_usage = l_view_controller_api->prepare_dynamic_navigation(
                source_window_name          = source_window_name
                source_vusage_name          = source_vusage_name
                source_plug_name            = source_plug_name
                target_component_name       = wa_cmp_usage-used_component
                target_view_name            = target_view_name
                target_plug_name            = target_plug_name
                target_embedding_position   = wa_cmp_usage-embedding_position ).
      CATCH cx_wd_runtime_repository.
        RAISE EXCEPTION TYPE cx_wdr_rt_exception.
    ENDTRY.

    IF wa_cmp_usage-component_usage->has_active_component( ) IS NOT INITIAL.
      wa_cmp_usage-component_usage->delete_component( ).
    ENDIF.

    wa_cmp_usage-component_usage->create_component( wa_cmp_usage-used_component ).
    l_intf_controller ?= wa_cmp_usage-component_usage->get_interface_controller( ).
    l_intf_controller->dyn_tree(
     in_tree_tab = lt_tree
     in_tree_name = in_tree_name
     in_tree_root_name = in_tree_root_name ).

  ENDMETHOD.


METHOD set_tree_infonode.
    is_tree_all =  ls_treenode.
  ENDMETHOD.
ENDCLASS.
