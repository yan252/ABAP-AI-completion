FUNCTION ZFM_TR_BOCOM_CERT_NO.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     VALUE(I_TREE_TYPE) TYPE  DMEE_TREETYPE_ABA
*"     VALUE(I_TREE_ID) TYPE  DMEE_TREEID_ABA
*"     VALUE(I_ITEM)
*"     VALUE(I_PARAM)
*"     VALUE(I_UPARAM)
*"  EXPORTING
*"     REFERENCE(O_VALUE)
*"     REFERENCE(C_VALUE)
*"     REFERENCE(N_VALUE)
*"     REFERENCE(P_VALUE)
*"  TABLES
*"      I_TAB
*"--------------------------------------------------------------------
FIELD-SYMBOLS:  <FS_FPAYH> TYPE FPAYH.

  ASSIGN COMPONENT 'FPAYH' OF STRUCTURE I_ITEM TO <FS_FPAYH>.


  C_VALUE = CONV #( <FS_FPAYH>-DOC1R ).





ENDFUNCTION.
