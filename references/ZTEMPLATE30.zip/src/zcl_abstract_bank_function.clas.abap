class ZCL_ABSTRACT_BANK_FUNCTION definition
  public
  abstract
  create public .

public section.

  interfaces ZIF_BANK_FUNCTION .
  interfaces ZIF_MESSAGES .

  aliases CREATE
    for ZIF_BANK_FUNCTION~CREATE .
  aliases CREATE_FILES
    for ZIF_BANK_FUNCTION~CREATE_FILES .
  aliases EXPORT_AFTER_PROCESSED
    for ZIF_BANK_FUNCTION~EXPORT_AFTER_PROCESSED .
  aliases GET_CURRENT_RESPONSE_DATA
    for ZIF_BANK_FUNCTION~GET_CURRENT_RESPONSE_DATA .
  aliases GET_CURRENT_RESPONSE_FILE
    for ZIF_BANK_FUNCTION~GET_CURRENT_RESPONSE_FILE .
  aliases GET_CURRENT_RESPONSE_SEQUENCE
    for ZIF_BANK_FUNCTION~GET_CURRENT_RESPONSE_SEQUENCE .
  aliases GET_CURRENT_SENDING_FILE
    for ZIF_BANK_FUNCTION~GET_CURRENT_SENDING_FILE .
  aliases GET_CURRENT_SENDING_SEQUENCE
    for ZIF_BANK_FUNCTION~GET_CURRENT_SENDING_SEQUENCE .
  aliases GET_FUNCTION_CONFIG
    for ZIF_BANK_FUNCTION~GET_FUNCTION_CONFIG .
  aliases GET_RESPONSE_DATA_BY_SEQUENCE
    for ZIF_BANK_FUNCTION~GET_RESPONSE_DATA_BY_SEQUENCE .
  aliases GET_RESPONSE_FILE_BY_SEQUENCE
    for ZIF_BANK_FUNCTION~GET_RESPONSE_FILE_BY_SEQUENCE .
  aliases GET_RESPONSE_HEADER_STATUS
    for ZIF_BANK_FUNCTION~GET_RESPONSE_HEADER_STATUS .
  aliases GET_SENDING_DATA_REFERENCE
    for ZIF_BANK_FUNCTION~GET_SENDING_DATA_REFERENCE .
  aliases GET_SENDING_FILE
    for ZIF_BANK_FUNCTION~GET_SENDING_FILE .
  aliases GET_SENDING_FILE_BY_SEQUENCE
    for ZIF_BANK_FUNCTION~GET_SENDING_FILE_BY_SEQUENCE .
  aliases IF_CURRENT_RESPONSING_FINISHED
    for ZIF_BANK_FUNCTION~IF_CURRENT_RESPONSING_FINISHED .
  aliases IF_ERROR
    for ZIF_BANK_FUNCTION~IF_ERROR .
  aliases IF_SENDING_FINISHED
    for ZIF_BANK_FUNCTION~IF_SENDING_FINISHED .
  aliases IF_STOP
    for ZIF_BANK_FUNCTION~IF_STOP .
  aliases IMPORT_RESPONSE
    for ZIF_BANK_FUNCTION~IMPORT_RESPONSE .
  aliases MESSAGES_COPY_FROM_OBJECT
    for ZIF_MESSAGES~MESSAGES_COPY_FROM_OBJECT .
  aliases PUBLISH_MESSAGES
    for ZIF_MESSAGES~PUBLISH_MESSAGES .
  aliases SET_SENDING_DATA_REFERENCE
    for ZIF_BANK_FUNCTION~SET_SENDING_DATA_REFERENCE .

  methods CONSTRUCTOR
    importing
      !IM_BANK_INDICATOR type ZTR_BANK_INDICATOR
      !IM_ACTION type ZTR_APP_ACTION_FOR_BANK
      !IM_STEP type ZTR_APP_ACTION_STEP
    exceptions
      ERROR .
protected section.

  constants YES type FLAG value 'X' ##NO_TEXT.
  constants NO type FLAG value SPACE ##NO_TEXT.
  data MESSAGES type ref to ZCL_MESSAGE_COLLECTOR .
  data BANK_INDICATOR type ZTR_BANK_INDICATOR .
  data ACTION type ZTR_APP_ACTION_FOR_BANK .
  data STEP type ZTR_APP_ACTION_STEP .
  data FUNCTION_CONFIG type ZTRT_BANK_FUNC .
  data SENDING_DATA_REFERENCE type ref to DATA .
  data RESPONSE_FILES type ZTRS_BANK_RESPONSE_FILE_TAB .
  data SENDING_FILES type ZTRS_BANK_SENDING_FILE_TAB .
  data RESPONSE_DATA type ZTRS_BANK_RESPONSE_DATA_TAB .
  data ACTION_FORMATTED_RESPONSE_DATA type ref to DATA .
  data INSTANCE_UUID type SYSUUID_C22 .
  data CURRENT_SENDING_SEQUENCE type I .
  data CURRENT_RESPONSE_SEQUENCE type I .
  data CURRENT_RESPONSE_IS_FINISHED type FLAG .
  class-data DUMMY_MESSAGE type STRING .
  constants ENTRY_SENDING_SEQUENCE_FIELD type FIELDNAME value 'SEQNUMBER' ##NO_TEXT.
  data FILE_ADJUSTER type ref to ZIF_SENDING_FILE_ADJUSTER .

  methods APPEND_RESPONSE_DATA
    importing
      !IM_RESPONSE_DATA_REF type ref to DATA .
  methods LOG_FILE
    importing
      !IM_UUID type SYSUUID_C22
      !IM_T_MESSAGES type BAPIRET2_TAB optional
      !IM_XREF type ref to DATA
      !IM_CREF type ref to DATA
      !IM_T_RAW_DATA type STANDARD TABLE optional
      !IM_FILE_DIRECTION type CHAR01 .
  methods GET_NEXT_SENDING_FILE
    exporting
      !EX_CFILE_REF type ref to DATA
      !EX_XFILE_REF type ref to DATA
      !EX_FILE_UUID type SYSUUID_C22
      !EX_SENDING_SEQUENCE type INT4 .
  methods IF_ENVIROMENT_ERROR
    returning
      value(RE_ERROR) type FLAG .
  methods CONVERT_DATA_TO_DMEE_TYPE
    importing
      !IM_T_RAW_DATA type STANDARD TABLE
    returning
      value(RE_DMEE_TABLE_REF) type ref to DATA .
  methods SET_CURRENT_SEQUENCE
    importing
      !IM_SENDING_SEQUENCE type I .
  methods CHECK_RESPONSE_IF_FINISHED .
  methods CONTINUE
    exporting
      !EX_CFILE_REF type ref to DATA
      !EX_XFILE_REF type ref to DATA
      !EX_FILE_UUID type SYSUUID_C22
      !EX_SENDING_SEQUENCE type INT4 .
  methods CREATE_FILE_GENERAL .
  methods ADJUST_FILE_AFTER_CREATION .
  methods PROCESS_RESPONSE_INTERNAL .
  methods CREATE_ACTION_FORMATTED_DATA .
  methods APPEND_SENDING_FILE
    importing
      !IM_RAW_DATA type STANDARD TABLE .
  methods GET_BANK_RETURN_CODE_INFO
    importing
      !IM_RETURN_CODE type CLIKE
      !IM_REQUEST_STATUS type ZTR_BANK_REQUEST_STATUS
      !IM_REQUEST_RESULT type ZTR_BANK_REQUEST_RESULT
    returning
      value(RS_RTNCODE_INFO) type ZTRS_BANK_RTNCODE_INFO .
  methods IMPORT_XML_RESPONSE .
  methods START_IMPORTING_RESPONSE
    importing
      !IM_CDATA_REF type ref to DATA
      !IM_XDATA_REF type ref to DATA
    returning
      value(RE_CONTINUE) type FLAG .
  methods IMPORTING_RESPONSE_CORE .
  methods END_IMPORTING_RESPONSE .
  methods APPEND_RESPONSING_FILE
    importing
      !IM_CDATA_REF type ref to DATA
      !IM_XDATA_REF type ref to DATA
      !IM_FILE_UUID type SYSUUID_C22 .
  methods START_PROCESSING_RESPONSE_INTL .
  methods PROCESSING_RESPONSE_INTL_CORE .
  methods END_PROCESSING_RESPONSE_INTL .
  methods GET_ORIGINAL_ENTRIES
    importing
      !IM_SENDING_SEQUENCE type INT4 optional
    returning
      value(RE_ENTRIES_REF) type ref to DATA .
  methods RESET_SENDING_FILE_UUID .
  methods ADJUST_RESPONSING_XML_B4_CONV
    changing
      !CH_XML_STRING type STRING
      !CH_XML_XSTRING type XSTRING .
  methods APPEND_INITIAL_RESPONSE .
private section.
ENDCLASS.



CLASS ZCL_ABSTRACT_BANK_FUNCTION IMPLEMENTATION.


  METHOD adjust_file_after_creation.
    DATA: lt_log_protocal_return TYPE ztab_bapiret2.
    DATA: l_sending_data_for_log_ref TYPE REF TO data.
    FIELD-SYMBOLS:<ft_sending_data>         TYPE STANDARD TABLE,
                  <ft_sending_data_for_log> TYPE STANDARD TABLE.

    DATA(lo_adjuster) = zcl_bank_file_adjuster=>get_sending_adjuster( bank_indicator ).
    IF lo_adjuster IS NOT BOUND.
      RETURN.
    ENDIF.
    lo_adjuster->adjust(
                      EXPORTING
                        im_action = action
                        im_step = step
                      IMPORTING
                        ex_t_return = DATA(lt_returns)
                       CHANGING
                         ch_data = sending_files ).
    MOVE-CORRESPONDING lt_returns TO lt_log_protocal_return.
    zcl_bank_logger_protocal=>import_messages(
                       im_uuid = instance_uuid
                       im_t_messages = lt_log_protocal_return
                       im_s_log_businessdata_data = VALUE #(
                                                      bank_ind = bank_indicator
                                                      bank_action = action
                                                      bank_func = function_config-bank_func
                                                      step = step
                                                      file_direction = 'C' ) ).
    ASSIGN sending_data_reference->* TO <ft_sending_data>.
    CREATE DATA l_sending_data_for_log_ref LIKE <ft_sending_data>.
    ASSIGN l_sending_data_for_log_ref->* TO <ft_sending_data_for_log>.

    LOOP AT sending_files INTO DATA(ls_sending_file).
      LOOP AT <ft_sending_data> ASSIGNING FIELD-SYMBOL(<fs_sending_data>).
        ASSIGN COMPONENT entry_sending_sequence_field OF STRUCTURE <fs_sending_data> TO FIELD-SYMBOL(<f_seqnumber>).
        IF sy-subrc <> 0.
          EXIT.
        ENDIF.

        CHECK <f_seqnumber> = ls_sending_file-sending_sequence.

        APPEND <fs_sending_data> TO <ft_sending_data_for_log>.
      ENDLOOP.
      log_file( im_uuid = ls_sending_file-file_uuid
                im_xref = ls_sending_file-xfile
                im_cref = ls_sending_file-cfile
                im_t_raw_data = <ft_sending_data_for_log>
                im_file_direction = 'C' ).

      CLEAR <ft_sending_data_for_log>.
    ENDLOOP.
  ENDMETHOD.


  method ADJUST_RESPONSING_XML_B4_CONV.
*    to be re-defined
  endmethod.


  method APPEND_INITIAL_RESPONSE.
    data: lo_initial_response type ref to data.

    create data lo_initial_response type (function_config-struc_res).

    append_response_data( lo_initial_response ).

  endmethod.


  METHOD append_response_data.
    DATA(ls_response_file) = get_current_response_file( ).

*    APPEND VALUE ztrs_bank_response_data(
*                       file_uuid           = ls_response_file-file_uuid
*                       sending_sequence    = current_sending_sequence
*                       response_sequence   = current_response_sequence
*                       response_ref        = im_response_data_ref )
*                       TO response_data.

*im_response_data_ref引用的可能是一个局部变量，而ls_response_data-response_ref是实例全局的属性
*如果不采用重新创建引用的方式，那么response_data中的response_ref字段有可能是FREED STACK的一个引用，
*相当于一个全局引用内存指向一个本地变量内存
*FREED STACK并非一个实例全局的内存方式，而是指向一个本地变量，这样的引用程序处理会报错
*所以需要修改成下面的方式，直接创建实例全局属性的引用指向.

    DATA: ls_response_data TYPE ztrs_bank_response_data.

    ASSIGN im_response_data_ref->* TO FIELD-SYMBOL(<fs_imported_data>).

    CREATE DATA ls_response_data-response_ref LIKE <fs_imported_data>.

    ASSIGN ls_response_data-response_ref->* TO FIELD-SYMBOL(<fs_response_ref>).

    <fs_response_ref> = <fs_imported_data>.

    ls_response_data-file_uuid           = ls_response_file-file_uuid.
    ls_response_data-sending_sequence    = current_sending_sequence.
    ls_response_data-response_sequence   = current_response_sequence.

    APPEND ls_response_data TO response_data.

  ENDMETHOD.


  METHOD APPEND_RESPONSING_FILE.
* add count to current response sequence
    ADD 1 TO current_response_sequence.

    APPEND VALUE #(
                   file_uuid = im_file_uuid
                   sending_sequence = current_sending_sequence
                   response_sequence = current_response_sequence
                   cfile = im_cdata_ref
                   xfile = im_xdata_ref )
            TO response_files.

  ENDMETHOD.


  METHOD append_sending_file.
    DATA(l_sending_ref) = convert_data_to_dmee_type( im_raw_data ).

    TRY.
        DATA(l_xml_uuid) = cl_system_uuid=>if_system_uuid_static~create_uuid_c22( ).
      CATCH cx_uuid_error.
*        start log
        MESSAGE e001(ztr_bank_application)
                INTO dummy_message.
        zcl_bank_logger_protocal=>add_log(
                 VALUE #( uuid         = instance_uuid
                          msgid        = sy-msgid
                          msgno        = sy-msgno
                          msgty        = sy-msgty
                          msgv1        = sy-msgv1
                          msgv2        = sy-msgv2
                          msgv3        = sy-msgv3
                          msgv4        = sy-msgv4
                          message      = dummy_message
                          bank_action  = action
                          bank_ind     = bank_indicator
                          bank_func    = function_config-bank_func
                          step         = step ) ).
*        end log
        RETURN.
    ENDTRY.

*start log
    MESSAGE i175(ztr_bank_application)
            WITH bank_indicator
                 function_config-bank_func
                 function_config-tree_type
                 function_config-tree_id
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = instance_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = action
                      bank_ind     = bank_indicator
                      bank_func    = function_config-bank_func
                      step         = step
                      file_uuid    = l_xml_uuid
                      file_direction = 'C' ) ).
*    end log

    ASSIGN l_sending_ref->* TO FIELD-SYMBOL(<ft_sending_data>).
    zcl_bank_data_mapping_engine=>sap_to_dmee_file(
                                  EXPORTING
                                    im_tree_type     = function_config-tree_type
                                    im_tree_id       = function_config-tree_id
                                    im_sap_data      = <ft_sending_data>
                                    im_encoding      = function_config-encoding
                                  IMPORTING
                                    ex_cfile         = DATA(l_cfile_ref)
                                    ex_xfile         = DATA(l_xfile_ref)
                                    et_return_errors = DATA(lt_file_return_errors) ).
    IF lt_file_return_errors IS INITIAL.
      APPEND VALUE ztrs_bank_sending_file( file_uuid        = l_xml_uuid
                                           sending_sequence = lines( sending_files ) + 1
                                           cfile            = l_cfile_ref
                                           xfile            = l_xfile_ref
                                           sended           = space )
                   TO sending_files.
      SORT sending_files BY sending_sequence.
    ELSE.
*      messages->add_message_set( lt_file_return_errors ).
      LOOP AT lt_file_return_errors INTO DATA(ls_file_return_error).
        zcl_bank_logger_protocal=>add_log(
                 VALUE #( uuid         = instance_uuid
                          msgid        = ls_file_return_error-id
                          msgno        = ls_file_return_error-number
                          msgty        = ls_file_return_error-type
                          msgv1        = ls_file_return_error-message_v1
                          msgv2        = ls_file_return_error-message_v2
                          msgv3        = ls_file_return_error-message_v3
                          msgv4        = ls_file_return_error-message_v4
                          message      = ls_file_return_error-message
                          bank_action  = action
                          bank_ind     = bank_indicator
                          bank_func    = function_config-bank_func
                          step         = step ) ).
*        end log
      ENDLOOP.
    ENDIF.

    log_file(
            im_uuid           = l_xml_uuid
            im_t_messages    = lt_file_return_errors
            im_xref           = l_xfile_ref
            im_cref           = l_cfile_ref
            im_t_raw_data     = im_raw_data
            im_file_direction = 'C' ).

  ENDMETHOD.


  METHOD check_response_if_finished.
*    need to re-define if require
    current_response_is_finished = yes.

    DATA(ls_sending_file) = get_current_sending_file( ).
    DATA(ls_response_file) = get_current_response_file( ).
*    DATA(ls_bank) = zcl_bank_enviroment=>create(
*                               im_bank_indicator = bank_indicator
*                               im_action = action )->get_bank( ).

    MESSAGE i190(ztr_bank_application)
            WITH bank_indicator
                 function_config-bank_func
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = instance_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = action
                      bank_ind     = bank_indicator
                      bank_func    = function_config-bank_func
                      step         = step
                      file_uuid    = ls_response_file-file_uuid
                      counter_file_uuid    = ls_sending_file-file_uuid
                      file_direction = 'R' ) ).
  ENDMETHOD.


  METHOD constructor.
    CONSTANTS: lc_program    TYPE syrepid VALUE 'ZCL_BANK_APP_ABSTRACT_BANK',
               lc_message_id TYPE symsgid VALUE 'ZTR_BANK_APPLICATION'.
    zcl_bank_enviroment=>s_get_function_by_step(
                                EXPORTING
                                  im_bank_indicator  = im_bank_indicator
                                  im_action          = im_action
                                  im_step            = im_step
                                IMPORTING
                                  ex_s_bank_function = function_config
                                 EXCEPTIONS
                                   error             = 1 ).
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid
              TYPE sy-msgty
              NUMBER sy-msgno
              WITH sy-msgv1
                   sy-msgv2
                   sy-msgv3
                   sy-msgv4.
      RAISE error.
    ENDIF.

    MOVE: im_bank_indicator TO bank_indicator,
          im_action         TO action,
          im_step           TO step.

    TRY.
        instance_uuid = cl_system_uuid=>if_system_uuid_static~create_uuid_c22( ).
      CATCH cx_uuid_error.
        MESSAGE e001(ztr_bank_application)
         RAISING error.
    ENDTRY.

    messages = zcl_bank_logger_protocal=>add_message_collector(
                 EXPORTING
                   im_default_message_class = lc_message_id
                   im_mainprogram           = lc_program
                   im_uuid                  = instance_uuid ).


*    CREATE OBJECT messages
*      EXPORTING
*        i_message_key  = instance_uuid
*        i_main_program = lc_program
*        i_class        = lc_message_id.


  ENDMETHOD.


  METHOD continue.
*    need to be re-define if require

    FREE: ex_cfile_ref,
          ex_xfile_ref.
    LOOP AT sending_files
         ASSIGNING FIELD-SYMBOL(<fs_files>)
         WHERE sending_sequence = current_sending_sequence.
      ex_cfile_ref         = <fs_files>-cfile.
      ex_xfile_ref         = <fs_files>-xfile.
      ex_file_uuid         = <fs_files>-file_uuid.
      ex_sending_sequence  = <fs_files>-sending_sequence.
      EXIT.
    ENDLOOP.

  ENDMETHOD.


  METHOD convert_data_to_dmee_type.
*    need to be re-defined
  ENDMETHOD.


  METHOD create_action_formatted_data.
    CHECK action_formatted_response_data IS NOT BOUND.

    zcl_bank_enviroment=>s_check_action_from_external(
                           EXPORTING
                              im_action                       = action
                           IMPORTING
                              ex_s_action                     = DATA(ls_action)
                           EXCEPTIONS
                              blank_action                    = 1
                              not_found                       = 2
                              class_not_config                = 3
                              formatted_structure_not_config  = 4
                              formatted_structure_not_found   = 5 ).
    IF sy-subrc <> 0.
*     unexpected error
      MESSAGE ID sy-msgid
              TYPE sy-msgty
              NUMBER sy-msgno
              WITH sy-msgv1
                   sy-msgv2
                   sy-msgv3
                   sy-msgv4.
    ENDIF.

    MESSAGE i191(ztr_bank_application)
            WITH bank_indicator
                 action
                 zcl_bank_enviroment=>s_get_bank_action_text( action )
                 function_config-bank_func
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = instance_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = action
                      bank_ind     = bank_indicator
                      bank_func    = function_config-bank_func
                      step         = step ) ).

    CREATE DATA action_formatted_response_data
               TYPE STANDARD TABLE OF (ls_action-formatted_struc_res).
  ENDMETHOD.


  METHOD create_file_general.
    FIELD-SYMBOLS: <ft_original_entries>      TYPE STANDARD TABLE,
                   <ft_original_entries_temp> TYPE STANDARD TABLE.
*    FIELD-SYMBOLS: <ft_sending_data_entries> TYPE STANDARD TABLE,
*                   <ft_file_raw_data>        TYPE STANDARD TABLE.
    DATA: l_original_temp_ref TYPE REF TO data.

    DATA(l_max_item) = function_config-max_send_item.
    IF l_max_item IS INITIAL.
      l_max_item = 1.
    ENDIF.

    ASSIGN sending_data_reference->* TO <ft_original_entries>.
    CREATE DATA l_original_temp_ref LIKE <ft_original_entries>.
    ASSIGN l_original_temp_ref->* TO <ft_original_entries_temp>.

    LOOP AT <ft_original_entries>
         ASSIGNING FIELD-SYMBOL(<fs_original_entry>).
      DATA(l_tabix) = sy-tabix.
      ASSIGN COMPONENT entry_sending_sequence_field
                       OF STRUCTURE <fs_original_entry>
                       TO FIELD-SYMBOL(<f_sequence>).
      <f_sequence> = lines( sending_files ) + 1.
      APPEND <fs_original_entry> TO <ft_original_entries_temp>.
      CHECK ( lines( <ft_original_entries_temp> ) = l_max_item  ) OR
            ( l_tabix = lines( <ft_original_entries> ) ).
      append_sending_file( <ft_original_entries_temp> ).
      IF if_error( ) = yes.
        EXIT.
      ENDIF.
      CLEAR <ft_original_entries_temp>.
    ENDLOOP.

  ENDMETHOD.


  METHOD end_importing_response.
    DATA(ls_sending_file) = get_current_sending_file( ).
    DATA(ls_response_file) = get_current_response_file( ).
*    DATA(ls_bank) = zcl_bank_enviroment=>create(
*                               im_bank_indicator = bank_indicator
*                               im_action = action )->get_bank( ).

    MESSAGE i186(ztr_bank_application)
            WITH bank_indicator
                 function_config-bank_func
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = instance_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = action
                      bank_ind     = bank_indicator
                      bank_func    = function_config-bank_func
                      step         = step
                      file_uuid    = ls_response_file-file_uuid
                      counter_file_uuid    = ls_sending_file-file_uuid
                      file_direction = 'R' ) ).

  ENDMETHOD.


  METHOD end_processing_response_intl.
    DATA(ls_sending_file) = get_current_sending_file( ).
    DATA(ls_response_file) = get_current_response_file( ).
*    DATA(ls_bank) = zcl_bank_enviroment=>create(
*                               im_bank_indicator = bank_indicator
*                               im_action = action )->get_bank( ).

    MESSAGE i189(ztr_bank_application)
            WITH bank_indicator
                 function_config-bank_func
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = instance_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = action
                      bank_ind     = bank_indicator
                      bank_func    = function_config-bank_func
                      step         = step
                      file_uuid    = ls_response_file-file_uuid
                      counter_file_uuid    = ls_sending_file-file_uuid
                      file_direction = 'R' ) ).

    reset_sending_file_uuid( ).
  ENDMETHOD.


  METHOD get_bank_return_code_info.

    DATA(lo_enviroment) = zcl_bank_enviroment=>create(
                                                 im_bank_indicator = bank_indicator
                                                 im_action = action ).
    lo_enviroment->get_bank_return_code_info(
                      EXPORTING
                        im_bank_func = function_config-bank_func
                        im_return_code = im_return_code
                        im_request_status = im_request_status
                        im_request_result = im_request_result
                      IMPORTING
                        ex_s_rtncode_info = rs_rtncode_info
                      EXCEPTIONS
                        return_code_not_found = 1 ).
    IF sy-subrc <> 0 OR
       rs_rtncode_info-rtntype IS INITIAL.
*      配置错误
*      未来保证资金安全，对于这个情况把返回码全部设置成成功
      CLEAR rs_rtncode_info.
      rs_rtncode_info-bank_ind = bank_indicator.
      rs_rtncode_info-bank_func = function_config-bank_func.
      rs_rtncode_info-bank_rtncode = im_return_code.
      rs_rtncode_info-bank_reqsts = im_request_status.
      rs_rtncode_info-bank_rtnflg = im_request_result.
      rs_rtncode_info-rtntype = 'S'.
      rs_rtncode_info-frontend_rtn = space.
    ENDIF.




  ENDMETHOD.


  METHOD get_next_sending_file.
    FREE: ex_cfile_ref,
          ex_xfile_ref.
    LOOP AT sending_files
         ASSIGNING FIELD-SYMBOL(<fs_files>)
         WHERE sended = space.
      ex_cfile_ref         = <fs_files>-cfile.
      ex_xfile_ref         = <fs_files>-xfile.
      ex_file_uuid         = <fs_files>-file_uuid.
      ex_sending_sequence  = <fs_files>-sending_sequence.
      <fs_files>-sended    = yes.
      set_current_sequence( <fs_files>-sending_sequence ).
*      current_sending_sequence = <fs_files>-sending_sequence.
      EXIT.
    ENDLOOP.
  ENDMETHOD.


  METHOD get_original_entries.
    FIELD-SYMBOLS: <ft_original_entries> TYPE STANDARD TABLE,
                   <ft_related_entries>  TYPE STANDARD TABLE.

    ASSIGN sending_data_reference->* TO <ft_original_entries>.
    CHECK <ft_original_entries> IS ASSIGNED.
    CREATE DATA re_entries_ref LIKE <ft_original_entries>.
    ASSIGN re_entries_ref->* TO <ft_related_entries>.

    IF im_sending_sequence IS SUPPLIED.
      LOOP AT <ft_original_entries>
           ASSIGNING FIELD-SYMBOL(<fs_original_entry>).
        ASSIGN COMPONENT entry_sending_sequence_field
                         OF STRUCTURE <fs_original_entry>
                         TO FIELD-SYMBOL(<f_sequence>).
        CHECK <f_sequence> = im_sending_sequence.
        APPEND <fs_original_entry> TO <ft_related_entries>.
      ENDLOOP.
    ELSE.
      <ft_related_entries> = <ft_original_entries>.
    ENDIF.
  ENDMETHOD.


  METHOD if_enviroment_error.
    re_error = zcl_bank_enviroment=>create(
                                   im_bank_indicator = bank_indicator
                                   im_action = action )->if_error( ).
  ENDMETHOD.


  METHOD importing_response_core.
    DATA(ls_sending_file) = get_current_sending_file( ).
    DATA(ls_response_file) = get_current_response_file( ).
    DATA(ls_bank) = zcl_bank_enviroment=>create(
                               im_bank_indicator = bank_indicator
                               im_action = action )->get_bank( ).

    CASE ls_bank-comm_type.
      WHEN '1'.
*        http
        import_xml_response( ).
      WHEN OTHERS.
*start log
        MESSAGE e179(ztr_bank_application)
                WITH ls_bank-bank_ind
                     ls_bank-comm_type
                INTO dummy_message.
        zcl_bank_logger_protocal=>add_log(
                 VALUE #( uuid         = instance_uuid
                          msgid        = sy-msgid
                          msgno        = sy-msgno
                          msgty        = sy-msgty
                          msgv1        = sy-msgv1
                          msgv2        = sy-msgv2
                          msgv3        = sy-msgv3
                          msgv4        = sy-msgv4
                          message      = dummy_message
                          bank_action  = action
                          bank_ind     = bank_indicator
                          bank_func    = function_config-bank_func
                          step         = step
                          file_uuid    = ls_response_file-file_uuid
                          counter_file_uuid    = ls_sending_file-file_uuid
                          file_direction = 'R' ) ).
        RETURN.
*    end log
    ENDCASE.

  ENDMETHOD.


  METHOD import_xml_response.
    DATA: l_string  TYPE string,
          l_xstring TYPE xstring.

    DATA(ls_sending_file) = get_current_sending_file( ).
    DATA(ls_response_file) = get_current_response_file( ).
*    DATA(ls_bank) = zcl_bank_enviroment=>create(
*                               im_bank_indicator = bank_indicator
*                               im_action = action )->get_bank( ).

    ASSIGN ls_response_file-cfile->* TO FIELD-SYMBOL(<f_cdata>).
    IF <f_cdata> IS ASSIGNED .
      l_string = <f_cdata>.
    ENDIF.
    ASSIGN ls_response_file-xfile->* TO FIELD-SYMBOL(<f_xdata>).
    IF <f_xdata> IS ASSIGNED .
      l_xstring = <f_xdata>.
    ENDIF.

    adjust_responsing_xml_b4_conv(
         CHANGING
           ch_xml_string = l_string
           ch_xml_xstring = l_xstring ).

    MESSAGE i185(ztr_bank_application)
            WITH bank_indicator
                 function_config-bank_func
                 function_config-trans_res
                 function_config-struc_res
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = instance_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = action
                      bank_ind     = bank_indicator
                      bank_func    = function_config-bank_func
                      step         = step
                      file_uuid    = ls_response_file-file_uuid
                      counter_file_uuid    = ls_sending_file-file_uuid
                      file_direction = 'R' ) ).

    append_response_data(  zcl_bank_data_mapping_engine=>convert_xml_to_sap(
                                             im_xml_structure      = function_config-struc_res
                                             im_xml_transformation = function_config-trans_res
                                             im_xml_xstring        = l_xstring
                                             im_xml_string        = l_string ) ).

  ENDMETHOD.


  METHOD log_file.
    zcl_bank_logger_protocal=>log_file(
                             im_file_uuid      = im_uuid
                             im_bank_indicator = bank_indicator
                             im_action         = action
                             im_step           = step
                             im_function       = function_config-bank_func
                             im_cfile          = im_cref
                             im_xfile          = im_xref
                             im_file_direction = im_file_direction ).
  ENDMETHOD.


  METHOD processing_response_intl_core.
    check_response_if_finished( ).
  ENDMETHOD.


  METHOD process_response_internal.
    start_processing_response_intl( ).
    processing_response_intl_core( ).
    end_processing_response_intl( ).
  ENDMETHOD.


  METHOD reset_sending_file_uuid.
    DATA: l_original_uuid TYPE sysuuid_c22.

    IF current_response_is_finished = yes OR
       if_error( ) = yes.
      RETURN.
    ENDIF.

*      当前反馈尚未完成（一般是查询类的功能，例如账户交易明细等）
*      新的XML在前面已经创建，目前当前发送序号current_sending_sequence对应的sending_files
*      记录已经是新的文件，但文件UUID还是旧的UUID，应该为新的文件重新分配UUID

    READ TABLE sending_files ASSIGNING FIELD-SYMBOL(<fs_sending_file>)
         WITH KEY sending_sequence = current_sending_sequence.
    IF sy-subrc <> 0.
*        start log
*      程序错误，这个不应该发生
      MESSAGE e259(ztr_bank_application)
              WITH current_sending_sequence
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = instance_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator
                        bank_func    = function_config-bank_func
                        step         = step ) ).
*        end log
      RETURN.
    ELSE.
      l_original_uuid = <fs_sending_file>-file_uuid.
    ENDIF.


    TRY.
        DATA(l_xml_uuid) = cl_system_uuid=>if_system_uuid_static~create_uuid_c22( ).
      CATCH cx_uuid_error.
*        start log
        MESSAGE e001(ztr_bank_application)
                INTO dummy_message.
        zcl_bank_logger_protocal=>add_log(
                 VALUE #( uuid         = instance_uuid
                          msgid        = sy-msgid
                          msgno        = sy-msgno
                          msgty        = sy-msgty
                          msgv1        = sy-msgv1
                          msgv2        = sy-msgv2
                          msgv3        = sy-msgv3
                          msgv4        = sy-msgv4
                          message      = dummy_message
                          file_uuid     = l_original_uuid
                          bank_action  = action
                          bank_ind     = bank_indicator
                          bank_func    = function_config-bank_func
                          step         = step ) ).
*        end log
        RETURN.
    ENDTRY.

    MESSAGE i260(ztr_bank_application)
            WITH l_xml_uuid
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = instance_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      file_uuid     = l_xml_uuid
                      counter_file_uuid = l_original_uuid
                      bank_action  = action
                      bank_ind     = bank_indicator
                      bank_func    = function_config-bank_func
                      step         = step ) ).


    <fs_sending_file>-file_uuid = l_xml_uuid.

  ENDMETHOD.


  METHOD set_current_sequence.
    current_sending_sequence = im_sending_sequence.
*    the sending sequence had been changed,
*     reset the response sequence for new sending sequence
    CLEAR current_response_sequence.
* clear the finished flag for RESPONSE
    CLEAR current_response_is_finished.
  ENDMETHOD.


  METHOD start_importing_response.
    FIELD-SYMBOLS: <ft_related_entries>  TYPE STANDARD TABLE.
    DATA l_original_temp_ref TYPE REF TO data.
    FIELD-SYMBOLS: <f_cdata> TYPE any,
                   <f_xdata> TYPE any.
    DATA: l_response_not_valid TYPE flag.
*    DATA: l_string  TYPE string,
*          l_xstring TYPE xstring.

    re_continue = yes.

    DATA(ls_sending_file) = get_current_sending_file( ).

    MESSAGE i180(ztr_bank_application)
            WITH bank_indicator
                 function_config-bank_func
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = instance_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = action
                      bank_ind     = bank_indicator
                      bank_func    = function_config-bank_func
                      step         = step
                      counter_file_uuid    = ls_sending_file-file_uuid
                      file_direction = 'R' ) ).

    TRY.
        DATA(l_file_uuid) = cl_system_uuid=>if_system_uuid_static~create_uuid_c22( ).
      CATCH cx_uuid_error.
        MESSAGE e001(ztr_bank_application)
                INTO dummy_message.
        zcl_bank_logger_protocal=>add_log(
                 VALUE #( uuid         = instance_uuid
                          msgid        = sy-msgid
                          msgno        = sy-msgno
                          msgty        = sy-msgty
                          msgv1        = sy-msgv1
                          msgv2        = sy-msgv2
                          msgv3        = sy-msgv3
                          msgv4        = sy-msgv4
                          message      = dummy_message
                          bank_action  = action
                          bank_ind     = bank_indicator
                          bank_func    = function_config-bank_func
                          step         = step
                          counter_file_uuid = ls_sending_file-file_uuid
                          file_direction = 'R' ) ).

        re_continue = no.
        RETURN.
    ENDTRY.

    append_responsing_file(
                   im_cdata_ref = im_cdata_ref
                    im_xdata_ref = im_xdata_ref
                    im_file_uuid = l_file_uuid ).


*    ASSIGN sending_data_reference->* TO <ft_original_entries>.
*    CREATE DATA l_original_temp_ref LIKE <ft_original_entries>.
*    ASSIGN l_original_temp_ref->* TO <ft_related_entries>.
*
*    LOOP AT <ft_original_entries>
*         ASSIGNING FIELD-SYMBOL(<fs_original_entry>).
*      ASSIGN COMPONENT entry_sending_sequence_field
*                       OF STRUCTURE <fs_original_entry>
*                       TO FIELD-SYMBOL(<f_sequence>).
*      CHECK <f_sequence> = current_sending_sequence.
*      APPEND <fs_original_entry> TO <ft_related_entries>.
*    ENDLOOP.

    l_original_temp_ref = get_original_entries( current_sending_sequence ).
    ASSIGN l_original_temp_ref->* TO <ft_related_entries>.
    log_file(
            im_uuid           = l_file_uuid
            im_xref           = im_xdata_ref
            im_cref           = im_cdata_ref
            im_t_raw_data     = <ft_related_entries>
            im_file_direction = 'R' ).

    IF im_cdata_ref IS NOT BOUND AND
       im_xdata_ref IS NOT BOUND.
      l_response_not_valid = yes.
    ELSE.
      ASSIGN im_cdata_ref->* TO <f_cdata>.
      ASSIGN im_xdata_ref->* TO <f_xdata>.
      IF ( <f_cdata> IS NOT ASSIGNED OR
           <f_cdata> IS INITIAL ) OR
          ( <f_xdata> IS NOT ASSIGNED OR
           <f_xdata> IS INITIAL ).
        l_response_not_valid = yes.
      ENDIF.
    ENDIF.

    IF l_response_not_valid = yes.
      APPEND_INITIAL_RESPONSE( ).
      MESSAGE e181(ztr_bank_application)
              WITH bank_indicator
                   function_config-bank_func
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = instance_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator
                        bank_func    = function_config-bank_func
                        step         = step
                        counter_file_uuid    = ls_sending_file-file_uuid
                        file_direction = 'R' ) ).

      re_continue = no.
      RETURN.

    ENDIF.
  ENDMETHOD.


  METHOD start_processing_response_intl.
    DATA(ls_sending_file) = get_current_sending_file( ).
    DATA(ls_response_file) = get_current_response_file( ).
*    DATA(ls_bank) = zcl_bank_enviroment=>create(
*                               im_bank_indicator = bank_indicator
*                               im_action = action )->get_bank( ).

    MESSAGE i188(ztr_bank_application)
            WITH bank_indicator
                 function_config-bank_func
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = instance_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = action
                      bank_ind     = bank_indicator
                      bank_func    = function_config-bank_func
                      step         = step
                      file_uuid    = ls_response_file-file_uuid
                      counter_file_uuid    = ls_sending_file-file_uuid
                      file_direction = 'R' ) ).
  ENDMETHOD.


  METHOD zif_bank_function~create.
    zcl_bank_enviroment=>s_get_function_by_step(
                                EXPORTING
                                  im_bank_indicator  = im_bank_indicator
                                  im_action          = im_action
                                  im_step            = im_step
                                IMPORTING
                                  ex_s_bank_function = DATA(ls_bank_function)
                                 EXCEPTIONS
                                   error             = 1 ).
    IF sy-subrc <> 0.
      MESSAGE ID      sy-msgid
              TYPE    sy-msgty
              NUMBER  sy-msgno
              WITH    sy-msgv1
                      sy-msgv2
                      sy-msgv3
                      sy-msgv4
                      INTO dummy_message.

      zcl_bank_logger_protocal=>add_log(
               VALUE #( msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = im_action
                        bank_ind     = im_bank_indicator
*                      bank_func    = ls_function-bank_func
                        step         = im_step ) ).
      RETURN.
    ELSE.
      MESSAGE i159(ztr_bank_application)
              WITH im_bank_indicator
                   zcl_bank_enviroment=>s_get_bank_action_text( im_action )
                   im_step
                   ls_bank_function-bank_func
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = im_action
                        bank_ind     = im_bank_indicator
                        bank_func    = ls_bank_function-bank_func
                        step         = im_step ) ).

      MESSAGE i158(ztr_bank_application)
              WITH im_bank_indicator
                   ls_bank_function-bank_func
                   ls_bank_function-instance_class
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = im_action
                        bank_ind     = im_bank_indicator
                        bank_func    = ls_bank_function-bank_func
                        step         = im_step ) ).
    ENDIF.

    CREATE OBJECT ro_instance TYPE (ls_bank_function-instance_class)
           EXPORTING
             im_bank_indicator = im_bank_indicator
             im_action         = im_action
             im_step           = im_step
           EXCEPTIONS
             error             = 1.
    IF sy-subrc <> 0.
      MESSAGE ID      sy-msgid
              TYPE    sy-msgty
              NUMBER  sy-msgno
              WITH    sy-msgv1
                      sy-msgv2
                      sy-msgv3
                      sy-msgv4
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = im_action
                        bank_ind     = im_bank_indicator
                        bank_func    = ls_bank_function-bank_func
                        step         = im_step ) ).
      FREE ro_instance.
    ELSE.
      MESSAGE i160(ztr_bank_application)
              WITH im_bank_indicator
                   ls_bank_function-bank_func
                   ls_bank_function-instance_class
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = im_action
                        bank_ind     = im_bank_indicator
                        bank_func    = ls_bank_function-bank_func
                        step         = im_step ) ).
    ENDIF.
  ENDMETHOD.


  METHOD zif_bank_function~create_files.
    MESSAGE i162(ztr_bank_application)
            WITH bank_indicator
                 function_config-bank_func
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = instance_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = action
                      bank_ind     = bank_indicator
                      bank_func    = function_config-bank_func
                      step         = step ) ).

    create_file_general( ).
    adjust_file_after_creation( ).

    IF sending_files IS INITIAL.
*        start log
      MESSAGE e077(ztr_bank_application)
              WITH function_config-bank_func
              INTO dummy_message.
    ELSE.
      MESSAGE i163(ztr_bank_application)
              WITH bank_indicator
                   function_config-bank_func
              INTO dummy_message.
    ENDIF.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = instance_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator
                        bank_func    = function_config-bank_func
                        step         = step ) ).
*        end log
  ENDMETHOD.


  METHOD zif_bank_function~export_after_processed.
    ASSIGN action_formatted_response_data->* TO FIELD-SYMBOL(<ft_formatted_data>).
    IF <ft_formatted_data> IS ASSIGNED.
      et_entries = <ft_formatted_data>.
    ENDIF.

*    CREATE DATA re_entries_reference LIKE <ft_formatted_data>.
*    ASSIGN re_entries_reference->* TO FIELD-SYMBOL(<ft_entries>).
*    <ft_entries> = <ft_formatted_data>.
  ENDMETHOD.


  METHOD zif_bank_function~get_current_response_data.
    re_response_data = get_response_data_by_sequence(
                                   im_sending_sequence = current_sending_sequence
                                   im_response_sequence = current_response_sequence ).
  ENDMETHOD.


  METHOD zif_bank_function~get_current_response_file.
    re_file = get_response_file_by_sequence(
                       im_sending_sequence = current_sending_sequence
                       IM_RESPONSE_SEQUENCE = current_response_sequence ).
  ENDMETHOD.


  METHOD zif_bank_function~get_current_response_sequence.
    re_sequence = current_response_sequence.
  ENDMETHOD.


  method ZIF_BANK_FUNCTION~GET_CURRENT_SENDING_FILE.
   re_file = get_sending_file_by_sequence( current_sending_sequence ).
  endmethod.


  METHOD zif_bank_function~get_current_sending_sequence.
    re_sequence = current_sending_sequence.
  ENDMETHOD.


  method ZIF_BANK_FUNCTION~GET_FUNCTION_CONFIG.
    rs_function = function_config.
  endmethod.


  METHOD zif_bank_function~get_response_data_by_sequence.
    READ TABLE response_data INTO re_response_data
          WITH KEY sending_sequence  = im_sending_sequence
                   response_sequence = im_response_sequence.
    IF sy-subrc <> 0 OR
       re_response_data-response_ref IS NOT BOUND.
*      unexpected error
*      change at 2020.3.27 临时增加消息保存，以检查生产后台job报错问题。
      "  ROLLBACK WORK.
*      zcl_bank_logger_protocal=>add_log( VALUE #( msgid = 'ZTR_BANK_APPLICATION'
*                                         msgno = 079
*                                         msgty = 'E'
*                                         msgv1 = function_config-bank_func
*                                         msgv2 = im_sending_sequence
*                                         msgv3 = im_response_sequence )
*       ).
*
*      zcl_bank_logger_protocal=>save_log( ).
*
*      COMMIT WORK.
      "LOG-POINT ID DEMO_CHECKPOINT_GROUP FIELDS response_data[]  .


      MESSAGE e079(ztr_bank_application)
      WITH function_config-bank_func
            im_sending_sequence
            im_response_sequence.
    ENDIF.
  ENDMETHOD.


  METHOD zif_bank_function~get_response_file_by_sequence.
    FREE: re_file-cfile,
          re_file-xfile.
    CLEAR re_file.

    LOOP AT response_files INTO re_file
         WHERE sending_sequence = im_sending_sequence
         AND   response_sequence = im_response_sequence.
*      IF im_x_reference = yes.
*        re_file = ls_sending_file-xfile.
*      ELSE.
*        re_file = ls_sending_file-cfile.
*      ENDIF.
      EXIT.
    ENDLOOP.

*    IF re_file-cfile IS NOT BOUND AND
*        re_file-xfile IS NOT BOUND.
**      unexpected
*      MESSAGE e184(ztr_bank_application)
*              WITH function_config-bank_func
*                   im_sending_sequence
*                   im_response_sequence.
*    ENDIF.
  ENDMETHOD.


  method ZIF_BANK_FUNCTION~GET_RESPONSE_HEADER_STATUS.
*    to be re-define
  endmethod.


  METHOD zif_bank_function~get_sending_data_reference.

    ASSIGN sending_data_reference->* TO FIELD-SYMBOL(<ft_reference>).

    CREATE DATA ro_reference like <ft_reference>.

    ASSIGN ro_reference->* TO FIELD-SYMBOL(<ft_export_reference>).

    <ft_export_reference> = <ft_reference>.

  ENDMETHOD.


  METHOD zif_bank_function~get_sending_file.
    IF current_sending_sequence IS INITIAL OR
       if_current_responsing_finished( ) = yes.
      get_next_sending_file(
                     IMPORTING
                       ex_cfile_ref        = ex_cfile_ref
                       ex_xfile_ref        = ex_xfile_ref
                       ex_sending_sequence = ex_sending_sequence
                       ex_file_uuid        = ex_file_uuid ).
    ELSE.
      continue(
                IMPORTING
                   ex_cfile_ref        = ex_cfile_ref
                   ex_xfile_ref        = ex_xfile_ref
                   ex_sending_sequence = ex_sending_sequence
                   ex_file_uuid        = ex_file_uuid ).
    ENDIF.

    IF ex_cfile_ref IS NOT BOUND OR
       ex_xfile_ref IS NOT BOUND.
      MESSAGE i167(ztr_bank_application)
              WITH bank_indicator
                   function_config-bank_func
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = instance_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator
                        bank_func    = function_config-bank_func
                        step         = step
                        file_uuid    = ex_file_uuid
                        file_direction = 'C' ) ).
    ENDIF.
  ENDMETHOD.


  METHOD zif_bank_function~get_sending_file_by_sequence.
    FREE: re_file-cfile,
          re_file-xfile.
    clear re_file.

    LOOP AT sending_files INTO re_file
         WHERE sending_sequence = im_sequence.
*      IF im_x_reference = yes.
*        re_file = ls_sending_file-xfile.
*      ELSE.
*        re_file = ls_sending_file-cfile.
*      ENDIF.
      exit.
    ENDLOOP.

    IF re_file-cfile IS NOT BOUND and
        re_file-xfile is NOT BOUND.
*      unexpected
      MESSAGE e082(ztr_bank_application)
              WITH function_config-bank_func
                   im_sequence.
    ENDIF.
  ENDMETHOD.


  METHOD zif_bank_function~if_current_responsing_finished.
    re_finished = current_response_is_finished.
  ENDMETHOD.


  method ZIF_BANK_FUNCTION~IF_ERROR.
    re_error = messages->if_error( ).
  endmethod.


  METHOD zif_bank_function~if_sending_finished.
    IF current_response_is_finished = yes.
      re_finished = yes.
      LOOP AT sending_files TRANSPORTING NO FIELDS
           WHERE sended = space.
        re_finished = no.
        EXIT.
      ENDLOOP.
    ELSE.
      re_finished = no.
    ENDIF.
  ENDMETHOD.


  method ZIF_BANK_FUNCTION~IF_STOP.
  endmethod.


  METHOD zif_bank_function~import_response.

    IF start_importing_response(
                    im_cdata_ref = im_cdata_ref
                    im_xdata_ref = im_xdata_ref ) = yes.
      importing_response_core( ).
    ENDIF.

    end_importing_response( ).

    process_response_internal( ).
  ENDMETHOD.


  METHOD zif_bank_function~set_sending_data_reference.
    FIELD-SYMBOLS: <ft_data> TYPE STANDARD TABLE.
    DATA: l_line_ref TYPE REF TO data.
    CREATE DATA sending_data_reference
           TYPE STANDARD TABLE OF (function_config-struc_in).

    CREATE DATA l_line_ref TYPE (function_config-struc_in).
    ASSIGN l_line_ref->* TO FIELD-SYMBOL(<fs_data>).

    ASSIGN sending_data_reference->* TO <ft_data>.

    LOOP AT im_data_reference INTO DATA(ls_data_reference)
          WHERE data IS BOUND.
      ASSIGN ls_data_reference-data->* TO FIELD-SYMBOL(<fs_source>).
      MOVE-CORRESPONDING <fs_source> TO <fs_data>.
      APPEND <fs_data> TO <ft_data>.
      CLEAR <fs_data>.
    ENDLOOP.
  ENDMETHOD.


  METHOD zif_messages~messages_copy_from_object.
    messages_copy_from_object.
  ENDMETHOD.


  METHOD zif_messages~publish_messages.
    publish_messages.
  ENDMETHOD.
ENDCLASS.
