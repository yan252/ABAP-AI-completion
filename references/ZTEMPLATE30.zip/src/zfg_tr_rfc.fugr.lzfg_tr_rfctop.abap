FUNCTION-POOL ZFG_TR_RFC.                   "MESSAGE-ID ..

* INCLUDE LZFG_TR_RFCD...                    " Local class definition
