*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZTRT9002........................................*
DATA:  BEGIN OF STATUS_ZTRT9002                      .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZTRT9002                      .
CONTROLS: TCTRL_ZTRT9002
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZTRT9002                      .
TABLES: ZTRT9002                       .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
