FUNCTION ZFM_TR_CCB_SET_PAYMENT_TX_CODE.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     VALUE(I_TREE_TYPE) TYPE  DMEE_TREETYPE_ABA
*"     VALUE(I_TREE_ID) TYPE  DMEE_TREEID_ABA
*"     VALUE(I_ITEM)
*"     VALUE(I_PARAM)
*"     VALUE(I_UPARAM)
*"  EXPORTING
*"     REFERENCE(O_VALUE)
*"     REFERENCE(C_VALUE)
*"     REFERENCE(N_VALUE)
*"     REFERENCE(P_VALUE)
*"  TABLES
*"      I_TAB
*"--------------------------------------------------------------------
ASSIGN COMPONENT 'FPAYH' OF STRUCTURE i_item TO FIELD-SYMBOL(<fs_fpayh>).
  c_value = zcl_ccb_enhancement=>set_payment_tx_code( <fs_fpayh> ).





ENDFUNCTION.
