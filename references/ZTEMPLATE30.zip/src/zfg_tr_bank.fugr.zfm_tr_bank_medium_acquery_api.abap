FUNCTION ZFM_TR_BANK_MEDIUM_ACQUERY_API.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     REFERENCE(IM_T_ACCOUNT) TYPE  ZTRS_BANK_ACCOUNT_TAB
*"     REFERENCE(IM_ACTION) TYPE  ZTR_APP_ACTION_FOR_BANK
*"--------------------------------------------------------------------
******  log
  IF zcl_bank_logger_protocal=>receive_bank_account_in_api(
                                im_action       = im_action
                                im_t_account_list = im_t_account ) = space.
    RETURN.
  ENDIF.
******  log end
  DATA(lo_action) = zcl_bank_abstract_action=>create( im_action ).
  IF lo_action IS BOUND.
    lo_action->set_entries( im_t_account ).
    lo_action->run( ).
  ENDIF.
*  zcl_bank_logger_protocal=>end_logs( 'X' ).
  zcl_bank_logger_protocal=>end_logs( im_action ).





ENDFUNCTION.
