class ZCL_CCB_ENHANCEMENT definition
  public
  final
  create public .

public section.

  interfaces ZIF_CCB_CONSTANTS .

  class-methods SET_CUST_ID
    returning
      value(RE_VALUE) type STRING .
  class-methods SET_USER_ID
    returning
      value(RE_VALUE) type EPIC_BC_USER .
  class-methods SET_PASSWORD
    returning
      value(RE_VALUE) type STRING .
  class-methods SET_PAYMENT_TX_CODE
    importing
      !IM_S_FPAYH type FPAYH
    returning
      value(RE_VALUE) type STRING .
  class-methods SET_CHK_RECVNAME
    returning
      value(RE_VALUE) type STRING .
  class-methods GENERATE_REQUEST_SN
    returning
      value(RE_VALUE) type STRING .
  class-methods CONVERT_DEBIT_AND_CREDIT_FLAG
    importing
      !IM_CCB_VALE type CLIKE
    returning
      value(RE_SAP_VALUE) type SHKZG .
  class-methods SET_TRANSACTION_DETAIL_PAGE
    importing
      !IM_S_DMEE type ZTRS_DMEE_ACCOUNT
    returning
      value(RE_PAGE) type STRING .
protected section.
private section.

  aliases BANK_INDICATOR
    for ZIF_CCB_CONSTANTS~BANK_INDICATOR .
  aliases TX_CODE_PAYMENT_NOT_SAME_BANK
    for ZIF_CCB_CONSTANTS~TX_CODE_PAYMENT_NOT_SAME_BANK .
  aliases TX_CODE_PAYMENT_SAME_BANK
    for ZIF_CCB_CONSTANTS~TX_CODE_PAYMENT_SAME_BANK .
ENDCLASS.



CLASS ZCL_CCB_ENHANCEMENT IMPLEMENTATION.


method CONVERT_DEBIT_AND_CREDIT_FLAG.
    CASE IM_CCB_VALE.
      WHEN '0'.
*        银行借方相当于企业贷方
        re_sap_value = 'H'.
      WHEN '1'.
*        银行贷方相当于企业借方
        re_sap_value = 'S'.
    ENDCASE.
  endmethod.


METHOD generate_request_sn.
    DATA: l_timestamp         TYPE timestampl,
          l_timestamp_string  TYPE string,
          l_timestamp_decimal TYPE string..

*只用于查询报文的REQUEST_SN产生
*支付报文不使用这个方法，为了避免重复交易，支付报文采取的是支付单号码

    GET TIME STAMP FIELD l_timestamp.


    l_timestamp_string = l_timestamp.

    REPLACE '.' WITH space INTO l_timestamp_string.

    CONDENSE l_timestamp_string NO-GAPS.

    IF strlen( l_timestamp_string ) <= 16."报文的REQUEST_SN长度为16个字符
*  timestamp这不可能小于16个字符的
      re_value = l_timestamp_string.
    ELSE.
      re_value = l_timestamp_string+0(16)."报文的REQUEST_SN长度为16个字符
    ENDIF.
  ENDMETHOD.


METHOD set_chk_recvname.
    IF sy-mandt = '130' OR
       sy-mandt = '150' OR
       sy-mandt = '310' OR
       sy-mandt = '300'.
*      测试系统
*      由于银行提供的测试账户可能存在账户名不对的情况，
*      或者由测试人员、用户建立的测试账户不可能和银行测试系统的匹配
*      因此在设置支付报文的CHK_RECVNAME元素为0，代表告知银行系统
*      不用校验收款账户名称
      re_value = '0'.
    ELSE.
*      生产系统
*      告诉银行系统需要校验收款账户名称是否和银行的一致
      re_value = '1'.
    ENDIF.
  ENDMETHOD.


method SET_CUST_ID.
    SELECT SINGLE * INTO @DATA(ls_bank_assignment)
          FROM ztrt_bank_ass
          WHERE bank_ind = @bank_indicator.
    IF sy-subrc <> 0.
*      the error should be remove by testing phase
      RETURN.
    ENDIF.

    SELECT COUNT( * ) INTO @DATA(l_count)
           FROM epic_bc_ud
           WHERE guid = @ls_bank_assignment-guid.
    IF l_count < 1.
*      the error should be remove by testing phase
      RETURN.
    ENDIF.

    re_value = ls_bank_assignment-custid.
  endmethod.


method SET_PASSWORD.
    CALL FUNCTION 'ZFM_TR_BANK_LOGON_USER'
      EXPORTING
        im_bank_indicator = bank_indicator
      IMPORTING
        ex_pasword        = re_value.
  endmethod.


method SET_PAYMENT_TX_CODE.
    IF zcl_bank_cnaps_code=>if_same_bank(
                              EXPORTING
                                im_code1 = im_s_fpayh-zbnky
                                im_code2 = im_s_fpayh-bnkl1 ) = 'X'.
      re_value = tx_code_payment_same_bank.
    ELSE.
     re_value = tx_code_payment_not_same_bank.
    ENDIF.
  endmethod.


METHOD set_transaction_detail_page.
    SELECT SINGLE * INTO @DATA(ls_page)
           FROM ztrt_ccb_trns_p
           WHERE bank_ind = 'CCB'
           AND   yhzh = @im_s_dmee-ztrs_dmee_account_list-bankn
           AND   start_date = @im_s_dmee-ztrs_dmee_account_list-start_date
           AND   end_date = @im_s_dmee-ztrs_dmee_account_list-end_date.
    IF sy-subrc <> 0 OR
        ls_page-page_full = 'X'.
*      第一页
      re_page = ls_page-zpage + 1.
    ELSE.
      re_page = ls_page-zpage.
    ENDIF.

    SHIFT re_page LEFT DELETING LEADING '0'.

    CONDENSE re_page NO-GAPS.

  ENDMETHOD.


method SET_USER_ID.
    CALL FUNCTION 'ZFM_TR_BANK_LOGON_USER'
      EXPORTING
        im_bank_indicator = bank_indicator
      IMPORTING
        ex_user           = re_value.
  endmethod.
ENDCLASS.
