class ZCL_BANK_BOC_B2E0043 definition
  public
  inheriting from ZCL_ABSTRACT_BANK_FUNCTION
  final
  create public .

public section.

  interfaces ZIF_BOC_FUNCTION .
protected section.

  methods ADJUST_FILE_AFTER_CREATION
    redefinition .
  methods CONVERT_DATA_TO_DMEE_TYPE
    redefinition .
  methods PROCESSING_RESPONSE_INTL_CORE
    redefinition .
private section.

  aliases RAISE_B2EERROR
    for ZIF_BOC_FUNCTION~RAISE_B2EERROR .
ENDCLASS.



CLASS ZCL_BANK_BOC_B2E0043 IMPLEMENTATION.


  METHOD adjust_file_after_creation.
    boc_adjust_file.
  ENDMETHOD.


  METHOD convert_data_to_dmee_type.

    FIELD-SYMBOLS: <ft_b2e0043>   TYPE STANDARD TABLE,
                   <ft_dmee_data> TYPE STANDARD TABLE,
                   <fs_b2e0043>   TYPE ztrs_boc_org_request.

    CREATE DATA re_dmee_table_ref TYPE ztrs_boc_b2e0043_request_tab.

    ASSIGN re_dmee_table_ref->* TO <ft_dmee_data>.

    APPEND INITIAL LINE TO <ft_dmee_data> ASSIGNING FIELD-SYMBOL(<fs_dmee_data>).
    ASSIGN COMPONENT 'ZTRS_BOC_B2E0043_REQUEST_FIELD' OF STRUCTURE <fs_dmee_data> TO FIELD-SYMBOL(<fs_request>).

    ASSIGN sending_data_reference->* TO <ft_b2e0043>.
    READ TABLE <ft_b2e0043> INDEX 1 ASSIGNING <fs_b2e0043>.

    MOVE-CORRESPONDING <fs_b2e0043> TO <fs_request>.
*
  ENDMETHOD.


  METHOD processing_response_intl_core.
    FIELD-SYMBOLS: <fs_response>        TYPE ztrs_boc_b2e0043_response.
    FIELD-SYMBOLS: <ft_formatted_data>  TYPE STANDARD TABLE.

    super->processing_response_intl_core( ).
    DATA(ls_response_data) = get_current_response_data( ).
    ASSIGN ls_response_data-response_ref->* TO <fs_response>.

    create_action_formatted_data( ).
    ASSIGN action_formatted_response_data->* TO <ft_formatted_data>.

    BREAK-POINT.

  ENDMETHOD.


  METHOD zif_boc_function~raise_b2eerror.
    raise_b2eerror.
    check_response_if_finished( ).
  ENDMETHOD.
ENDCLASS.
