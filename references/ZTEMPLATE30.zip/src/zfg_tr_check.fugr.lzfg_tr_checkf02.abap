**&---------------------------------------------------------------------*
**&  包含                LZFG_TR_CHECKF02
**&---------------------------------------------------------------------*
*FORM show_data.
*  DATA: lt_fieldcat TYPE lvc_t_fcat,
*        ls_layout   TYPE lvc_s_layo.
*  DATA: ls_fieldcat           LIKE LINE OF lt_fieldcat,
*        it_special_groups_lvc TYPE  lvc_t_sgrp.
*  DEFINE ftcat.
*
*    ls_fieldcat-fieldname = &1.
*    ls_fieldcat-scrtext_l    = &2.
*    ls_fieldcat-no_out    = &3.
*    ls_fieldcat-do_sum    = &4.
*    ls_fieldcat-no_zero = &5.
*    ls_fieldcat-outputlen = &6.
*    ls_fieldcat-emphasize = &7.
*    ls_fieldcat-sp_group = &7.
*    APPEND ls_fieldcat TO lt_fieldcat.
*    CLEAR ls_fieldcat.
*  END-OF-DEFINITION.
*
*
*  ls_layout-cwidth_opt = 'X'.
*
*  ftcat:
*        'BUKRS' '公司代码'  '' '' '' '' 'C101',
*        'ALV_KEY' '查询的单据'  '' '' '' '' 'C101'.
*  ls_fieldcat-no_sum = 'X'.
*  ftcat:    'WRBTR' '单据总额'  '' '' '' '' 'C101'.
*
*  IF lv_yx_only NE 2.
*    gs_col-jjbilln =    boolc( gs_col-jjbilln = '' )."标记互转
*    ftcat: 'JJBILLN'  '紧急支出计划单号'  gs_col-jjbilln '' '' '' 'C100',
*           'STATUST'  '紧急计划支出单状态' gs_col-jjbilln '' '' '' 'C100',
*           'JJITEMN'  '紧急计划序号' gs_col-jjbilln '' '' '' 'C100'.
*
*    gs_col-pbilln =    boolc( gs_col-pbilln = '' )."标记互转
*    ftcat:
*           'PBILLN'  '预估支付单'  gs_col-pbilln '' '' ''  'C200',
*           'STATUST_YG'  '预估支付单状态' gs_col-pbilln '' '' '' 'C200'.
*
*    gs_col-zwkplv =    boolc( gs_col-zwkplv = '' )."标记互转
*    ftcat:
*           'ZWKPLV'  '周版本编号' gs_col-zwkplv '' '' ''  'C500',
*           'ZJJHBB'  '资金计划版本'  gs_col-zwkplv '' '' ''  'C500',
*           'ITEMN'  '资金计划项目' gs_col-zwkplv '' '' ''  'C500',
*           'STATUS_T'  '资金计划状态' gs_col-zwkplv '' '' ''  'C500',
*           'WAERS'  '货币码' gs_col-zwkplv '' '' '' '',
*           'JHZFE'  '计划锁定金额' gs_col-zwkplv '' '' '' ''.
*
*  ENDIF.
*  gs_col-zfd =    boolc( gs_col-zfd = '' )."标记互转
*  ftcat: 'DOCNO'  '支付单号' gs_col-zfd '' '' ''  'C300',
*         'ZZFSTATUS_T'  '支付状态' gs_col-zfd '' '' ''  'C300',
*         'ZZFWAERS'  '支付货币' gs_col-zfd '' '' '' 'C300',
*         'ZZFWRBTR'  '支付金额' gs_col-zfd '' '' ''  'C300'.
*
*
*  it_special_groups_lvc = VALUE lvc_t_sgrp(  ( sp_group = 'C100' text  = '紧急支出计划')
*  ( sp_group = 'C200' text  = '预估支付单')
*  ( sp_group = 'C500' text  = '周资金计划')
*  ( sp_group = 'C300' text  = '支付单')
*  ).
*
*  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY_LVC'
*    EXPORTING
*      i_callback_program       = sy-repid
*      is_layout_lvc            = ls_layout
*      it_fieldcat_lvc          = lt_fieldcat
*      it_special_groups_lvc    = it_special_groups_lvc
*      i_callback_pf_status_set = 'PF_STATUS_SET'
*      i_callback_user_command  = 'USER_COMMAND'
*      i_screen_start_column    = i_screen_start_column
*      i_screen_start_line      = i_screen_start_line
*      i_screen_end_column      = i_screen_end_column
*      i_screen_end_line        = i_screen_end_line
*    TABLES
*      t_outtab                 = gt_alv
*    EXCEPTIONS
*      program_error            = 1
*      OTHERS                   = 2.
*  IF sy-subrc <> 0.
** Implement suitable error handling here
*  ENDIF.
*  .
*ENDFORM.
*
*FORM  pf_status_set USING rt_extab TYPE slis_t_extab .
*
*  SET PF-STATUS '0100'.
*
*ENDFORM.
*
*FORM user_command USING r_ucomm TYPE sy-ucomm rs_selfield TYPE slis_selfield.
*  IF r_ucomm =  'INF'.
*
*    CALL FUNCTION 'DSYS_SHOW_FOR_F1HELP'
*      EXPORTING
*        dokclass   = 'RE'
*        dokname    = 'ZTRE03001'
*        short_text = 'X'
*      EXCEPTIONS
*        OTHERS     = 1.      "#EC *
*  ENDIF.
*
*ENDFORM.
