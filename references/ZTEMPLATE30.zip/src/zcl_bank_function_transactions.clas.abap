class ZCL_BANK_FUNCTION_TRANSACTIONS definition
  public
  inheriting from ZCL_ABSTRACT_BANK_FUNCTION
  create public .

public section.
protected section.

  methods PROCESSING_RESPONSE_BY_DBTABLE
    importing
      !IM_DATA_DB_TABLE type TABNAME
      !IM_DETAIL_RESPONSE_COMPONENT type CLIKE
      !IM_STATUSCODE_COMPONNET type CLIKE
      !IM_STATUSTEXT_COMPONENT type CLIKE
      !IM_DB_ACCOUNT_NUMBER_FIELD type CLIKE
      !IM_BANK_ENTRY_ACCNUMBER_FIELD type CLIKE .

  methods CONVERT_DATA_TO_DMEE_TYPE
    redefinition .
private section.
ENDCLASS.



CLASS ZCL_BANK_FUNCTION_TRANSACTIONS IMPLEMENTATION.


METHOD convert_data_to_dmee_type.
    general_acc_dmee_convert.
  ENDMETHOD.


METHOD processing_response_by_dbtable.
***    这个METHOD主要迎合大部分银行交易明细查询的返回
***    目前大部分银行的交易明细查询都是单个账户查询，也就是一个账户一个XML文件
***    因此当前返回的数据都是当前查询账户的数据
*    processing_response_by_dbtable.
    INCLUDE ztr_bank_acc_generalquery_res.
  ENDMETHOD.
ENDCLASS.
