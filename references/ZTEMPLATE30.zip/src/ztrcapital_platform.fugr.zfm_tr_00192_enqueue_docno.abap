FUNCTION ZFM_TR_00192_ENQUEUE_DOCNO.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     REFERENCE(IM_DOCNO) TYPE  ZTR_0192_DOCNO
*"  EXCEPTIONS
*"      ERROR
*"--------------------------------------------------------------------
READ TABLE gt_docno ASSIGNING FIELD-SYMBOL(<fs_docno>)
        WITH KEY docno = im_docno.
  IF sy-subrc = 0.
    RETURN.
  ENDIF.

  CALL FUNCTION 'ENQUEUE_EZTRT0192H'
    EXPORTING
      mode_ztrt0192h = 'E'
      mandt          = sy-mandt
      docno          = im_docno
      x_docno        = ' '
      _scope         = '2'
      _wait          = ' '
      _collect       = ' '
    EXCEPTIONS
      foreign_lock   = 1
      system_failure = 2
      OTHERS         = 3.

  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid
            TYPE sy-msgty
            NUMBER sy-msgno
            WITH sy-msgv1
                 sy-msgv2
                 sy-msgv3
                 sy-msgv4
            RAISING error.
  ENDIF.
  APPEND INITIAL LINE TO gt_docno ASSIGNING <fs_docno>.

  MOVE: im_docno TO <fs_docno>-docno.





ENDFUNCTION.
