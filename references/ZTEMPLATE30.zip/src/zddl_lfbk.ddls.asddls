@AbapCatalog.sqlViewName: 'ZTRCDSLFBK'
@AbapCatalog.compiler.compareFilter: true
@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: '供应商开户行压缩'
define view ZDDL_LFBK as select distinct  from lfbk { 
 mandt ,
 lifnr , 
 bvtyp     
} where bankl <> 'ZZZZZZ'
 
  
 