class ZCL_BANK_ENVIROMENT definition
  public
  final
  create public .

public section.

  constants BANK_RETURN_CODE_IS_SUCCESS type ZTR_BANK_RTNCODE_TYPE value 'S' ##NO_TEXT.
  constants BANK_RETURN_CODE_IS_FAILED type ZTR_BANK_RTNCODE_TYPE value 'F' ##NO_TEXT.
  constants BANK_RETURN_CODE_IS_IN_PROCESS type ZTR_BANK_RTNCODE_TYPE value 'P' ##NO_TEXT.
  constants BANK_RETURN_CODE_IS_UNKNOW type ZTR_BANK_RTNCODE_TYPE value 'X' ##NO_TEXT.
  constants DATESEQ_NOT_RELATED type ZTR_SEQUENCE_CONTROL value SPACE ##NO_TEXT.
  constants DATESEQ_BY_BANK type ZTR_SEQUENCE_CONTROL value '1' ##NO_TEXT.
  constants DATESEQ_BY_MAINSTEP_FUNCTION type ZTR_SEQUENCE_CONTROL value '2' ##NO_TEXT.

  methods CONSTRUCTOR
    importing
      !IM_BANK_INDICATOR type ZTRT_BANK-BANK_IND
      !IM_ACTION type ZTRT_ACTION-BANK_ACTION .
  methods CHECK_BANK .
  methods GET_BANK
    returning
      value(RS_BANK) type ZTRT_BANK .
  methods CHECK_BANK_ACTION .
  methods CHECK_ACTION .
  methods GET_BANK_ACTION
    returning
      value(RS_BANK_ACTION) type ZTRT_BANK_ACTION .
  methods GET_ACTION
    returning
      value(RS_ACTION) type ZTRT_ACTION .
  methods CHECK_STEPS .
  methods GET_STEPS
    returning
      value(RT_BANK_ACTION_STEPS) type ZTRT_BANK_ACTION_STEP_TAB .
  class-methods CREATE
    importing
      !IM_BANK_INDICATOR type ZTRT_BANK-BANK_IND
      !IM_ACTION type ZTRT_ACTION-BANK_ACTION
    returning
      value(RO_INSTANCE) type ref to ZCL_BANK_ENVIROMENT .
  methods IF_ERROR
    returning
      value(RE_ERROR) type FLAG .
  methods GET_BANK_FUNCTION
    importing
      !IM_BANK_FUNCTION type ZTR_BANK_FUNCTION
    returning
      value(RS_BANK_FUNCTION) type ZTRT_BANK_FUNC .
  methods CHECK .
  methods PUBLISH_MESSAGES
    exporting
      !ET_MESSAGES type ZTAB_BAPIRET2 .
  methods GET_MAIN_STEP
    returning
      value(RE_MAIN_STEP) type ZTR_APP_ACTION_STEP .
  methods GET_MAIN_STEP_INPUT_STRUCTURE
    returning
      value(RE_STRUCTURE) type TABNAME .
  methods GET_SINGLE_STEP
    importing
      !IM_STEP type ZTR_APP_ACTION_STEP
    returning
      value(RS_STEP) type ZTRT_BKACT_STEP .
  methods GET_FUNCTION_NAME_BY_STEP
    importing
      !IM_STEP type ZTR_APP_ACTION_STEP
    returning
      value(RE_FUNCTION) type ZTRT_BANK_FUNC-BANK_FUNC .
  methods GET_FUNCTION_BY_STEP
    importing
      !IM_STEP type ZTR_APP_ACTION_STEP
    returning
      value(RS_BANK_FUNCTION) type ZTRT_BANK_FUNC .
  methods GET_FUNCTION_TEXT
    importing
      !IM_LANGU type SYLANGU default SY-LANGU
      !IM_BANK_FUNCTION type ZTR_BANK_FUNCTION
    returning
      value(RE_TEXT) type ZTR_BANK_FUNCTION_LTEXT .
  methods GET_BANK_RETURN_CODE_INFO
    importing
      !IM_BANK_FUNC type ZTR_BANK_FUNCTION
      !IM_RETURN_CODE type CLIKE
      !IM_REQUEST_STATUS type ZTR_BANK_REQUEST_STATUS
      !IM_REQUEST_RESULT type ZTR_BANK_REQUEST_RESULT
    exporting
      value(EX_S_RTNCODE_INFO) type ZTRS_BANK_RTNCODE_INFO
    exceptions
      RETURN_CODE_NOT_FOUND .
  methods GET_BANK_RETURN_CODE_TYPE
    importing
      !IM_BANK_FUNC type ZTR_BANK_FUNCTION
      !IM_RETURN_CODE type CLIKE
      !IM_REQUEST_STATUS type ZTR_BANK_REQUEST_STATUS
      !IM_REQUEST_RESULT type ZTR_BANK_REQUEST_RESULT
    returning
      value(RE_TYPE) type ZTR_BANK_RTNCODE_TYPE .
  class-methods S_CHECK_ACTION_FROM_EXTERNAL
    importing
      !IM_ACTION type ZTR_APP_ACTION_FOR_BANK
    exporting
      !EX_S_ACTION type ZTRT_ACTION
    exceptions
      BLANK_ACTION
      NOT_FOUND
      CLASS_NOT_CONFIG
      FORMATTED_STRUCTURE_NOT_CONFIG
      FORMATTED_STRUCTURE_NOT_FOUND .
  class-methods S_GET_BANK_ACC_INSTANCE_CLASS
    importing
      !IM_BANK_INDICATOR type ZTR_BANK_INDICATOR
    returning
      value(RE_INSTANCE_CLASS) type ZTRT_BANK-INSTANCE_CLASS
    exceptions
      NOT_FOUND .
  class-methods S_GET_BANK_INSTANCE_CLASS
    importing
      !IM_BANK_INDICATOR type ZTR_BANK_INDICATOR
    returning
      value(RE_INSTANCE_CLASS) type ZTRT_BANK-INSTANCE_CLASS .
  class-methods S_DETERMINE_BANK_INSTANCE_CLS
    importing
      !IM_COMMUNICATION_TYPE type ZTR_COMMUNICATION_TYPE
    returning
      value(RE_INSTANCE_CLASS) type ZTR_BANK_INSTANCE_CLASS .
  class-methods S_GET_FUNCTION_BY_STEP
    importing
      !IM_BANK_INDICATOR type ZTR_BANK_INDICATOR
      !IM_ACTION type ZTR_APP_ACTION_FOR_BANK
      !IM_STEP type ZTR_APP_ACTION_STEP
    exporting
      value(EX_S_BANK_FUNCTION) type ZTRT_BANK_FUNC
    exceptions
      ERROR .
  class-methods S_GET_BANK_ACTION_TEXT
    importing
      !IM_ACTION type ZTR_APP_ACTION_FOR_BANK
    returning
      value(RE_TEXT) type ZTR_APP_ACTION_FOR_BANK_LTEXT .
  class-methods S_GET_STATUS_BY_ERROR_STEP
    importing
      !IM_BANK_IND type ZTR_BANK_INDICATOR
      !IM_ACTION type ZTR_APP_ACTION_FOR_BANK
      !IM_STEP type ZTR_APP_ACTION_STEP
      !IM_INSTANCE_ERR type ZTR_ERROR_CODE_IN_BANKINSTANCE
    exporting
      !E_STATUS type ZTR_ENTSTATUS
    exceptions
      NOT_FOUND .
  methods GENERATE_DATE_SEQUENCE
    returning
      value(RS_SEQUENCE) type ZTRS_SEQUENCE_CONTROL .
protected section.
private section.

  class-data DUMMY_MESSAGE type STRING .
  data YES type CHAR01 value 'X' ##NO_TEXT.
  data NO type CHAR01 value SPACE ##NO_TEXT.
  data MESSAGES type ref to ZCL_MESSAGE_COLLECTOR .
  data BANK_INDICATOR type ZTRT_BANK-BANK_IND .
  data ACTION type ZTRT_ACTION-BANK_ACTION .
  data ACTION_TEXT type DD07V-DDTEXT .
  class-data ENVIROMENTS type ZTRS_BANK_ENVIROMENT_TAB .
  data BANK_SETTING type ZTRT_BANK .
  data ACTION_SETTING type ZTRT_ACTION .
  data BANK_ACTION_SETTING type ZTRT_BANK_ACTION .
  data BANK_ACTION_STEPS type ZTRT_BANK_ACTION_STEP_TAB .
  data FUNCTIONS type ZTRT_BANK_FUNC_TAB .
  data ENVIROMENT_UUID type SYSUUID_C22 .
  data INSTANCE_DATE type DATUM .

  methods CHECK_SINGLE_STEP
    importing
      !IM_S_STEP type ZTRT_BKACT_STEP .
  methods CHECK_DESTINATION_OF_STEP
    importing
      !IM_STEP type ZTRT_ACTION_STEP-STEP
      !IM_DESTINATION type ZTRT_ACTION_STEP-DESTINATION .
  methods CHECK_BANK_FUNCTION
    importing
      !IM_BANK_FUNCTION type ZTR_BANK_FUNCTION
      !IM_STEP type ZTR_APP_ACTION_STEP .
  methods CHECK_STRUC_IN_OF_FUNCTION
    importing
      !IM_BANK_FUNCTION type ZTR_BANK_FUNCTION
      !IM_STRUCTURE type TABNAME .
  methods CHECK_TREE_TYPE_OF_FUNCTION
    importing
      !IM_BANK_FUNCTION type ZTR_BANK_FUNCTION
      !IM_TREE_TYPE type ZTR_TREE_TYPE .
  methods CHECK_TREE_ID_OF_FUNCTION
    importing
      !IM_BANK_FUNCTION type ZTR_BANK_FUNCTION
      !IM_TREE_TYPE type ZTR_TREE_TYPE
      !IM_TREE_ID type ZTR_TREE_ID .
  methods CHECK_STRUC_RES_OF_FUNCTION
    importing
      !IM_BANK_FUNCTION type ZTR_BANK_FUNCTION
      !IM_STRUCTURE type ZTR_STRUC_RES .
  methods CHECK_TRANSFORMATION_OF_FUNC
    importing
      !IM_BANK_FUNCTION type ZTR_BANK_FUNCTION
      !IM_TRANSFORMATION type ZTR_RESPONSE_TRANSFORMATION .
  methods CHECK_MAINSTEP_IN_STEPS .
  methods CHECK_DATE_SEQ_CONTROL_BY_BANK .
  methods CHECK_DATE_SEQ_CONTROL_BY_FUNC
    importing
      !IM_BANK_FUNCTION type ZTR_BANK_FUNCTION .
  methods CHECK_SEQUENCE_DATE .
ENDCLASS.



CLASS ZCL_BANK_ENVIROMENT IMPLEMENTATION.


METHOD check.
    check_bank( ).

    check_action( ).

    check_bank_action( ).

    check_steps( ).

  ENDMETHOD.


METHOD check_action.
    get_action( ).
    IF if_error( ) = yes.
      RETURN.
    ENDIF.
*    return_if_error.
  ENDMETHOD.


METHOD check_bank.
    CONSTANTS: lc_comm_type_domain TYPE dd07l-domname VALUE 'ZDM_TR_COMMUNICATION_TYPE'.

    get_bank( ).
    IF if_error( ) = yes.
      RETURN.
    ENDIF.
*    return_if_error.

    IF bank_setting-active = no.
      MESSAGE e021(ztr_bank_application)
              WITH bank_indicator
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = enviroment_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator ) ).
      RETURN.
*      add_system_msg_and_return_01 021
*                                   bank_indicator.
    ENDIF.

    IF bank_setting-destination IS INITIAL.
      MESSAGE e022(ztr_bank_application)
              WITH bank_indicator
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = enviroment_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator ) ).
      RETURN.
*      add_system_msg_and_return_01 022
*                                   bank_indicator.
    ENDIF.

    SELECT SINGLE * INTO @DATA(ls_destination)
         FROM rfcdes
         WHERE rfcdest = @bank_setting-destination.
    IF sy-subrc <> 0.
      MESSAGE e023(ztr_bank_application)
              WITH bank_indicator
                   bank_setting-destination
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = enviroment_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator ) ).
      RETURN.
*      add_system_msg_and_return_02 023
*                                   bank_indicator
*                                   bank_setting-destination.

    ENDIF.

    DATA(l_text) = zcl_global_technical_service=>get_domain_text(
                                     im_ingnore_error = yes
                                     im_domain_name = lc_comm_type_domain
                                     im_domain_value = bank_setting-comm_type ).
    CASE bank_setting-comm_type.
      WHEN space.
        MESSAGE e024(ztr_bank_application)
                WITH bank_indicator
                INTO dummy_message.
        zcl_bank_logger_protocal=>add_log(
                 VALUE #( uuid         = enviroment_uuid
                          msgid        = sy-msgid
                          msgno        = sy-msgno
                          msgty        = sy-msgty
                          msgv1        = sy-msgv1
                          msgv2        = sy-msgv2
                          msgv3        = sy-msgv3
                          msgv4        = sy-msgv4
                          message      = dummy_message
                          bank_action  = action
                          bank_ind     = bank_indicator ) ).
        RETURN.
*        add_system_msg_and_return_01 024
*                                     bank_indicator.
      WHEN '1'.
*        http/https
        IF ls_destination-rfctype <> 'G'.
*和逻辑目标的类型不一致
          MESSAGE e026(ztr_bank_application)
                  WITH bank_indicator
                       l_text
                       bank_setting-destination
                  INTO dummy_message.
          zcl_bank_logger_protocal=>add_log(
                   VALUE #( uuid         = enviroment_uuid
                            msgid        = sy-msgid
                            msgno        = sy-msgno
                            msgty        = sy-msgty
                            msgv1        = sy-msgv1
                            msgv2        = sy-msgv2
                            msgv3        = sy-msgv3
                            msgv4        = sy-msgv4
                            message      = dummy_message
                            bank_action  = action
                            bank_ind     = bank_indicator ) ).
          RETURN.
*          add_system_msg_and_return_03 026
*                                       bank_indicator
*                                       l_text
*                                       bank_setting-destination.
        ENDIF.
      WHEN OTHERS.
        MESSAGE e025(ztr_bank_application)
                 WITH bank_indicator
                      l_text
                 INTO dummy_message.
        zcl_bank_logger_protocal=>add_log(
                 VALUE #( uuid         = enviroment_uuid
                          msgid        = sy-msgid
                          msgno        = sy-msgno
                          msgty        = sy-msgty
                          msgv1        = sy-msgv1
                          msgv2        = sy-msgv2
                          msgv3        = sy-msgv3
                          msgv4        = sy-msgv4
                          message      = dummy_message
                          bank_action  = action
                          bank_ind     = bank_indicator ) ).
        RETURN.
*        add_system_msg_and_return_02 025
*                                     bank_indicator
*                                     l_text.
    ENDCASE.


    check_date_seq_control_by_bank( ).

  ENDMETHOD.


METHOD CHECK_BANK_ACTION.
    get_bank_action( ).
*    return_if_error.
    IF if_error( ) = yes.
      RETURN.
    ENDIF.

    IF bank_action_setting-mainstep IS INITIAL.
      MESSAGE e041(ztr_bank_application)
              WITH bank_indicator
                   action
                   action_text
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = enviroment_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator ) ).
      RETURN.
*      add_system_msg_and_return_03 041
*                                   bank_indicator
*                                   action
*                                   action_text.
    ELSE.
      check_mainstep_in_steps( ).
    ENDIF.
  ENDMETHOD.


METHOD check_bank_function.
    IF im_bank_function IS INITIAL.
      MESSAGE e063(ztr_bank_application)
              WITH bank_indicator
                   action
                   im_step
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = enviroment_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator ) ).
      RETURN.
*      add_system_msg_and_return_03 063
*                                   bank_indicator
*                                   action
*                                   im_step.
    ENDIF.

    DATA(ls_bank_function) = get_bank_function( im_bank_function ).
*    return_if_error.
    IF if_error( ) = yes.
      RETURN.
    ENDIF.

    check_struc_in_of_function( im_bank_function = im_bank_function
                                im_structure = ls_bank_function-struc_in ).

    check_tree_type_of_function( im_bank_function = im_bank_function
                                 im_tree_type = ls_bank_function-tree_type ).

    IF ls_bank_function-tree_type IS NOT INITIAL.
      check_tree_id_of_function( im_bank_function = im_bank_function
                                   im_tree_type = ls_bank_function-tree_type
                                   im_tree_id = ls_bank_function-tree_id ).
    ENDIF.

    check_transformation_of_func( im_bank_function = im_bank_function
                                  im_transformation = ls_bank_function-trans_res ).

    check_struc_res_of_function( im_bank_function = im_bank_function
                                 im_structure = ls_bank_function-struc_res ).

    check_date_seq_control_by_func( im_bank_function ).
  ENDMETHOD.


METHOD check_date_seq_control_by_bank.
*    DATA l_date TYPE sydatum.

    IF bank_setting-seqcontrol <> '1'.
      RETURN.
    ENDIF.

    DATA(l_text) = zcl_global_technical_service=>get_domain_text(
                               im_ingnore_error = yes
                               im_domain_name = 'ZDM_TR_SEQUENCE_CONTROL'
                               im_domain_value = bank_setting-seqcontrol ).

    IF bank_setting-seqobject IS INITIAL.
      MESSAGE e297(ztr_bank_application)
               WITH bank_indicator
                    bank_setting-seqcontrol
                    l_text
               INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = enviroment_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator ) ).
      RETURN.
    ENDIF.

    IF bank_setting-seqnrrangenr IS INITIAL.
      MESSAGE e305(ztr_bank_application)
               WITH bank_indicator
                    bank_setting-seqcontrol
                    l_text
               INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = enviroment_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator ) ).
      RETURN.
    ENDIF.

    CALL FUNCTION 'NUMBER_GET_INFO'
      EXPORTING
        nr_range_nr        = bank_setting-seqnrrangenr
        object             = bank_setting-seqobject
      EXCEPTIONS
        interval_not_found = 1
        object_not_found   = 2
        OTHERS             = 3.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid
              TYPE sy-msgty
              NUMBER sy-msgno
              WITH sy-msgv1
                   sy-msgv2
                   sy-msgv3
                   sy-msgv4
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = enviroment_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator ) ).
      RETURN.
    ENDIF.

*    l_date = sy-datum.

    SELECT COUNT( * ) INTO @DATA(l_count)
           FROM ztrt_bank_dseq
           WHERE bank_ind = @bank_indicator
           AND   seqbank_func = @space
           AND   seqdate = @sy-datum.
    IF l_count < 1.
      MESSAGE e300(ztr_bank_application)
               WITH bank_indicator
                    sy-datum
               INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = enviroment_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator ) ).
      RETURN.
    ENDIF.

    check_sequence_date( ).

  ENDMETHOD.


METHOD check_date_seq_control_by_func.
*    DATA l_date TYPE sydatum.

    DATA(ls_bank) = get_bank( ).

    IF ls_bank-seqcontrol <> '2' OR
        if_error( ) = yes.
      RETURN.
    ENDIF.

    DATA(ls_bank_function) = get_bank_function( im_bank_function ).

    IF if_error( ) = yes.
      RETURN.
    ENDIF.


    DATA(l_text) = zcl_global_technical_service=>get_domain_text(
                               im_ingnore_error = yes
                               im_domain_name = 'ZDM_TR_SEQUENCE_CONTROL'
                               im_domain_value = ls_bank-seqcontrol ).

    IF ls_bank_function-seqobject IS INITIAL.
      MESSAGE e301(ztr_bank_application)
               WITH bank_indicator
                    ls_bank_function-bank_func
                    ls_bank-seqcontrol
                    l_text
               INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = enviroment_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator ) ).
      RETURN.
    ENDIF.

    IF ls_bank_function-seqnrrangenr IS INITIAL.
      MESSAGE e306(ztr_bank_application)
               WITH bank_indicator
                    ls_bank-seqcontrol
                    l_text
               INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = enviroment_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator ) ).
      RETURN.
    ENDIF.

    CALL FUNCTION 'NUMBER_GET_INFO'
      EXPORTING
        nr_range_nr        = ls_bank_function-seqnrrangenr
        object             = ls_bank_function-seqobject
      EXCEPTIONS
        interval_not_found = 1
        object_not_found   = 2
        OTHERS             = 3.
    IF sy-subrc <> 0.
      MESSAGE id sy-msgid
              type sy-msgty
              number sy-msgno
              with sy-msgv1
                   sy-msgv2
                   sy-msgv3
                   sy-msgv4
              into dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = enviroment_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator ) ).
      RETURN.
    ENDIF.

*    CLEAR l_count.
*    l_date = sy-datum.

    SELECT COUNT( * ) INTO @data(l_count)
           FROM ztrt_bank_dseq
           WHERE bank_ind = @bank_indicator
           AND   seqbank_func = @im_bank_function
           AND   seqdate = @sy-datum.
    IF l_count < 1.
      MESSAGE e303(ztr_bank_application)
               WITH bank_indicator
                    im_bank_function
                    sy-datum
               INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = enviroment_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator ) ).
      RETURN.
    ENDIF.

  ENDMETHOD.


METHOD check_destination_of_step.
    SELECT COUNT( * ) INTO @DATA(l_count)
          FROM rfcdes
          WHERE rfcdest = @im_destination.
    IF l_count <= 0.
      MESSAGE e044(ztr_bank_application)
              WITH bank_indicator
                   action
                   im_step
                   im_destination
             INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = enviroment_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator ) ).
      RETURN.
*      add_system_msg_and_return_04 044
*                                   bank_indicator
*                                   action
*                                   im_step
*                                   im_destination.
    ENDIF.
  ENDMETHOD.


METHOD check_mainstep_in_steps.
    LOOP AT get_steps( ) TRANSPORTING NO FIELDS
             WHERE bank_ind = bank_indicator
             AND   bank_action = action
             AND   step = get_main_step( ).
      EXIT.
    ENDLOOP.
    IF if_error( ) = no.
      IF sy-subrc <> 0.
      MESSAGE e043(ztr_bank_application)
              WITH bank_indicator
                   action
                   action_text
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = enviroment_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator ) ).
      RETURN.

*        add_system_msg_and_return_03 043
*                                     bank_indicator
*                                     action
*                                     action_text.
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD check_sequence_date.
    IF sy-datum = instance_date and
        bank_setting-seqcontrol <> dateseq_not_related.
      RETURN.
    ENDIF.

*    非常异常的情况，一般情况下不太可能出现这个错误
*    出现这个问题的原因可能是在每天最后几秒银企直连功能被运行而且触发了银行环境实例化
*    在银企直连运行到这一步的时候恰好出现当前日期和银行环境实例化的日期不一致
*    例如2018-09-01的23:59:58银企直连功能被运行而且银行环境也在这个时候实例化
*    但运行到这个步骤的时候日期已经进入了2018-09-02，而在这一刻我们给银行的
*    交易流水号（按日期）还没进行初始化

    MESSAGE e304(ztr_bank_application)
             WITH bank_indicator
                  INSTANCE_DATE
                  sy-datum
             INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = enviroment_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = action
                      bank_ind     = bank_indicator ) ).
  ENDMETHOD.


METHOD check_single_step.
    IF im_s_step-step IS INITIAL.
      MESSAGE e060(ztr_bank_application)
              with bank_indicator
                   action
                   action_text
               INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = enviroment_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator ) ).
      return.
*      add_system_msg_03 060
*                        bank_indicator
*                        action
*                        action_text.
    ENDIF.

    IF im_s_step-destination IS NOT INITIAL.
      check_destination_of_step(
               im_step = im_s_step-step
               im_destination = im_s_step-destination ).
    ENDIF.

    check_bank_function( im_step = im_s_step-step
                         im_bank_function = im_s_step-bank_func ).

  ENDMETHOD.


METHOD check_steps.
    get_steps( ).
*    return_if_error.
    if if_error( ) = yes.
      return.
      endif.

    LOOP AT bank_action_steps INTO DATA(ls_step).
      check_single_step( ls_step ).
    ENDLOOP.

  ENDMETHOD.


METHOD check_struc_in_of_function.
    IF im_structure IS INITIAL.
      MESSAGE e051(ztr_bank_application)
              WITH bank_indicator
                   im_bank_function
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = enviroment_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator ) ).
      RETURN.
*      add_system_msg_and_return_02 051
*                                   bank_indicator
*                                   im_bank_function.
    ELSE.
      zcl_global_technical_service=>check_table(
            EXPORTING
              im_tabname = im_structure
            EXCEPTIONS
              not_found = 1 ).
      IF sy-subrc <> 0.
*        add_system_msg_and_return.
        MESSAGE ID sy-msgid
                TYPE sy-msgty
                NUMBER sy-msgno
                WITH sy-msgv1
                     sy-msgv2
                     sy-msgv3
                     sy-msgv4
               INTO dummy_message.
        zcl_bank_logger_protocal=>add_log(
                 VALUE #( uuid         = enviroment_uuid
                          msgid        = sy-msgid
                          msgno        = sy-msgno
                          msgty        = sy-msgty
                          msgv1        = sy-msgv1
                          msgv2        = sy-msgv2
                          msgv3        = sy-msgv3
                          msgv4        = sy-msgv4
                          message      = dummy_message
                          bank_action  = action
                          bank_ind     = bank_indicator ) ).
        RETURN.
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD check_struc_res_of_function.
    IF im_structure IS INITIAL.
      MESSAGE e040(ztr_bank_application)
              WITH bank_indicator
                   im_bank_function
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = enviroment_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator ) ).
      RETURN.

*      add_system_msg_and_return_02 040
*                                   bank_indicator
*                                   im_bank_function.
    ELSE.
      zcl_global_technical_service=>check_table(
            EXPORTING
              im_tabname = im_structure
            EXCEPTIONS
              not_found = 1 ).
      IF sy-subrc <> 0.
*        add_system_msg_and_return.
        MESSAGE ID sy-msgid
                TYPE sy-msgty
                NUMBER sy-msgno
                WITH sy-msgv1
                     sy-msgv2
                     sy-msgv3
                     sy-msgv4
               INTO dummy_message.
        zcl_bank_logger_protocal=>add_log(
         VALUE #( uuid         = enviroment_uuid
                  msgid        = sy-msgid
                  msgno        = sy-msgno
                  msgty        = sy-msgty
                  msgv1        = sy-msgv1
                  msgv2        = sy-msgv2
                  msgv3        = sy-msgv3
                  msgv4        = sy-msgv4
                  message      = dummy_message
                  bank_action  = action
                  bank_ind     = bank_indicator ) ).
        RETURN.
      ENDIF.
    ENDIF.
  ENDMETHOD.


method CHECK_TRANSFORMATION_OF_FUNC.
  endmethod.


METHOD check_tree_id_of_function.
    IF im_tree_id IS INITIAL.
      MESSAGE e031(ztr_bank_application)
              WITH bank_indicator
                   im_bank_function
                   im_tree_type
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = enviroment_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator ) ).
      RETURN.

*      add_system_msg_and_return_03 031
*                                   bank_indicator
*                                   im_bank_function
*                                   im_tree_type.
    ELSE.
      SELECT COUNT( * ) INTO @DATA(l_count)
             FROM dmee_tree
             WHERE tree_type = @im_tree_type
             AND   tree_id   = @im_tree_id.
      IF l_count <= 0.
      MESSAGE e031(ztr_bank_application)
              WITH bank_indicator
                   im_bank_function
                   im_tree_type
                   im_tree_id
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = enviroment_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator ) ).
      RETURN.

*        add_system_msg_and_return_04 036
*                                     bank_indicator
*                                     im_bank_function
*                                     im_tree_type
*                                     im_tree_id.
      ENDIF.
    ENDIF.
  ENDMETHOD.


method CHECK_TREE_TYPE_OF_FUNCTION.
    IF im_tree_type IS INITIAL.
      MESSAGE e033(ztr_bank_application)
              with bank_indicator
                   im_bank_function
              into dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = enviroment_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator ) ).
      return.
*      add_system_msg_and_return_02 033
*                                   bank_indicator
*                                   im_bank_function.
    ELSE.
      SELECT COUNT( * ) INTO @DATA(l_count)
             FROM dmee_tree_type
             WHERE tree_type = @im_tree_type.
      IF l_count <= 0.
      MESSAGE e032(ztr_bank_application)
              with bank_indicator
                   im_bank_function
                   im_tree_type
              into dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = enviroment_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator ) ).
      return.
*        add_system_msg_and_return_03 032
*                                     bank_indicator
*                                     im_bank_function
*                                     im_tree_type.
      ENDIF.
    ENDIF.
  endmethod.


METHOD constructor.
    CONSTANTS: lc_program    TYPE syrepid VALUE 'ZCL_BANK_PAYMENT_ENTRY',
               lc_message_id TYPE symsgid VALUE 'ZTR_BANK_APPLICATION'.
*    CONSTANTS: lc_action_domain TYPE dd07l-domname VALUE 'ZDM_TR_APP_ACTION_FOR_BANK'.

    bank_indicator = im_bank_indicator.
    action = im_action.
    instance_date = sy-datum.

    TRY.
        enviroment_uuid = cl_system_uuid=>if_system_uuid_static~create_uuid_c22( ).
      CATCH cx_uuid_error.
        MESSAGE e001(ztr_bank_application).
    ENDTRY.

    messages = zcl_bank_logger_protocal=>add_message_collector(
                 EXPORTING
                   im_default_message_class = lc_message_id
                   im_mainprogram           = lc_program
                   im_uuid                  = enviroment_uuid ).

    IF bank_indicator IS INITIAL.
*    start log
      MESSAGE e061(ztr_bank_application)
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = enviroment_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = im_action
                        bank_ind     = im_bank_indicator ) ).
      RETURN.
*end log

*      add_system_msg_and_return_00 061.
    ENDIF.

    IF action IS INITIAL.
*    start log
      MESSAGE e062(ztr_bank_application)
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = enviroment_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = im_action
                        bank_ind     = im_bank_indicator ) ).
      RETURN.
*end log

*      add_system_msg_and_return_00 062.
    ENDIF.

    get_bank( ).

    get_action( ).

    get_steps( ).


    SELECT SINGLE ltext INTO action_text
           FROM ztrt_actiont
           WHERE bank_action = action.

  ENDMETHOD.


METHOD CREATE.
    READ TABLE enviroments INTO DATA(ls_enviroment)
         WITH KEY bank_ind    = im_bank_indicator
                  bank_action = im_action.
    IF sy-subrc <> 0.
      ls_enviroment-bank_ind    = im_bank_indicator.
      ls_enviroment-bank_action = im_action.
      CREATE OBJECT ls_enviroment-instance
        EXPORTING
          im_bank_indicator = im_bank_indicator
          im_action         = im_action.
      APPEND ls_enviroment TO enviroments.

*start log
*    start log
    MESSAGE i141(ztr_bank_application)
            WITH im_action
                 zcl_bank_enviroment=>s_get_bank_action_text( im_action )
                 im_bank_indicator
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = im_action
                      bank_ind     = im_bank_indicator ) ).
*end log
    ENDIF.

    ro_instance = ls_enviroment-instance.
  ENDMETHOD.


METHOD generate_date_sequence.
    DATA l_date TYPE sydatum.

    IF if_error( ) = yes.
      RETURN.
    ENDIF.

    CASE bank_setting-seqcontrol.
      WHEN dateseq_not_related.
*        不相关
        RETURN.
      WHEN dateseq_by_bank.
*        按照银行
        MOVE: bank_setting-seqcontrol TO rs_sequence-seqcontrol,
              instance_date TO rs_sequence-seqdate,
              bank_setting-seqobject TO rs_sequence-seqobject,
              bank_setting-seqnrrangenr TO rs_sequence-seqnrrangenr.
      WHEN dateseq_by_mainstep_function.
*        按照银行功能
        DATA(ls_bank_function) = get_function_by_step( get_main_step( ) ).

        MOVE: bank_setting-seqcontrol TO rs_sequence-seqcontrol,
              instance_date TO rs_sequence-seqdate,
              ls_bank_function-bank_func TO rs_sequence-seqbank_func,
              ls_bank_function-seqobject TO rs_sequence-seqobject,
              ls_bank_function-seqnrrangenr TO rs_sequence-seqnrrangenr.
    ENDCASE.

    l_date = sy-datum.
    check_sequence_date( ).
    IF if_error( ) = yes.
      CLEAR rs_sequence.
      RETURN.
    ENDIF.

    CALL FUNCTION 'NUMBER_GET_NEXT'
      EXPORTING
        nr_range_nr             = bank_setting-seqnrrangenr
        object                  = rs_sequence-seqobject
      IMPORTING
        number                  = rs_sequence-dateseq
      EXCEPTIONS
        interval_not_found      = 1
        number_range_not_intern = 2
        object_not_found        = 3
        quantity_is_0           = 4
        quantity_is_not_1       = 5
        interval_overflow       = 6
        buffer_overflow         = 7
        OTHERS                  = 8.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid
              TYPE sy-msgty
              NUMBER sy-msgno
              WITH sy-msgv1
                   sy-msgv2
                   sy-msgv3
                   sy-msgv4
                   INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = enviroment_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator ) ).
      RETURN.
    ENDIF.

    check_sequence_date( ).
    IF if_error( ) = yes.
      CLEAR rs_sequence.
    ENDIF.
  ENDMETHOD.


METHOD get_action.

*    IF action IS INITIAL.
*      add_system_msg_and_return_00 062.
*    ENDIF.
*
*    IF action_setting-bank_action <> action.
*      CLEAR action_setting.
*    ENDIF.
*
*    IF action_setting IS INITIAL.
*      SELECT SINGLE * INTO action_setting
*            FROM ztrt_action
*            WHERE bank_action = action.
*      IF sy-subrc <> 0.
*        add_system_msg_and_return_01 078
*                                     action.
*      ENDIF.
*    ENDIF.
*
*    rs_action = action_setting.

    zcl_bank_enviroment=>s_check_action_from_external(
                           EXPORTING
                              im_action = action
                           IMPORTING
                              ex_s_action = action_setting
                           EXCEPTIONS
                              blank_action = 1
                              not_found = 2
                              class_not_config = 3
                              formatted_structure_not_config = 4
                              formatted_structure_not_found = 5 ).
    IF sy-subrc <> 0.
*    start log
      MESSAGE ID sy-msgid
              TYPE sy-msgty
              NUMBER sy-msgno
              WITH sy-msgv1
                   sy-msgv2
                   sy-msgv3
                   sy-msgv4
              INTO dummy_message.

      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = enviroment_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator ) ).
      return.
*end log
*      MESSAGE ID sy-msgid
*              TYPE sy-msgty
*              NUMBER sy-msgno
*              WITH sy-msgv1
*                   sy-msgv2
*                   sy-msgv3
*                   sy-msgv4
*              INTO dummy_message.
*      add_system_msg_and_return.
    ENDIF.

  ENDMETHOD.


METHOD get_bank.

    IF bank_indicator IS INITIAL.
*    start log
      MESSAGE e061(ztr_bank_application)
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = enviroment_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator ) ).
      return.
*end log
*      add_system_msg_and_return_00 061.
    ENDIF.

    IF bank_setting-bank_ind <> bank_indicator.
      CLEAR bank_setting.
    ENDIF.

    IF bank_setting IS INITIAL.
      SELECT SINGLE * INTO bank_setting
             FROM ztrt_bank
             WHERE bank_ind = bank_indicator.
      IF sy-subrc <> 0.
*    start log
        MESSAGE e020(ztr_bank_application)
                WITH bank_indicator
                INTO dummy_message.
        zcl_bank_logger_protocal=>add_log(
                 VALUE #( uuid         = enviroment_uuid
                          msgid        = sy-msgid
                          msgno        = sy-msgno
                          msgty        = sy-msgty
                          msgv1        = sy-msgv1
                          msgv2        = sy-msgv2
                          msgv3        = sy-msgv3
                          msgv4        = sy-msgv4
                          message      = dummy_message
                          bank_action  = action
                          bank_ind     = bank_indicator ) ).
        return.
*end log
*        add_system_msg_and_return_01 020 bank_indicator.
      ENDIF.
    ENDIF.

    rs_bank = bank_setting.

  ENDMETHOD.


METHOD GET_BANK_ACTION.

    IF bank_indicator IS INITIAL.
      MESSAGE e061(ztr_bank_application)
              into dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = enviroment_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator ) ).
      RETURN.
*      add_system_msg_and_return_00 061.
    ENDIF.

    IF action IS INITIAL.
*      add_system_msg_and_return_00 062.
      MESSAGE e061(ztr_bank_application)
              into dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = enviroment_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator ) ).
      RETURN.
    ENDIF.

    IF bank_action_setting-bank_ind <> bank_indicator OR
       bank_action_setting-bank_action <> action.
      CLEAR bank_action_setting.
    ENDIF.

    IF bank_action_setting IS INITIAL.
      SELECT SINGLE * INTO bank_action_setting
            FROM ZTRT_BANK_ACTION
            WHERE bank_ind = bank_indicator
            AND   bank_action = action.
      IF sy-subrc <> 0.
      MESSAGE e034(ztr_bank_application)
              with bank_indicator
                   action
                   action_text
              into dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = enviroment_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator ) ).
      RETURN.
*        add_system_msg_and_return_03 034
*                                     bank_indicator
*                                     action
*                                     action_text.
      ENDIF.
    ENDIF.

    rs_bank_action = bank_action_setting.

  ENDMETHOD.


METHOD get_bank_function.
    READ TABLE functions INTO rs_bank_function
           WITH KEY bank_ind = bank_indicator
                    bank_func = im_bank_function.
    IF sy-subrc <> 0.
      SELECT SINGLE * INTO rs_bank_function
              FROM ztrt_bank_func
              WHERE bank_ind = bank_indicator
              AND   bank_func = im_bank_function.
      IF sy-subrc <> 0.
        MESSAGE e064(ztr_bank_application)
                with bank_indicator
                     im_bank_function
                into dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = enviroment_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator ) ).
      return.

*        add_system_msg_and_return_02 064
*                                     bank_indicator
*                                     im_bank_function.
      ELSE.
        APPEND rs_bank_function TO functions.
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD get_bank_return_code_info.
    SELECT SINGLE * INTO CORRESPONDING FIELDS OF ex_s_rtncode_info
           FROM ztrt_bfun_rtncod
           WHERE bank_ind = bank_indicator
           AND   bank_func = im_bank_func
           AND   bank_rtncode = im_return_code
           AND   bank_reqsts = im_request_status
           AND   bank_rtnflg = im_request_result.
    IF sy-subrc <> 0.
      SELECT SINGLE * INTO CORRESPONDING FIELDS OF ex_s_rtncode_info
             FROM ztrt_bank_rtncod
             WHERE bank_ind = bank_indicator
             AND   bank_rtncode = im_return_code
             AND   bank_reqsts = im_request_status
             AND   bank_rtnflg = im_request_result.
      IF sy-subrc <> 0.
        DATA(l_msg) = TEXT-001 &&
                      bank_indicator &&
                      TEXT-002 &&
                      im_bank_func &&
                      TEXT-003 &&
                      im_return_code &&
                      TEXT-004 &&
                      im_request_status &&
                      TEXT-005 &&
                      im_request_result.
        MESSAGE e099(ztr_bank_application)
                WITH l_msg
                RAISING return_code_not_found.
      ENDIF.
    ENDIF.
    SELECT SINGLE ltext INTO ex_s_rtncode_info-ltext
           FROM ztrt_bank_rtncot
           WHERE bank_ind = bank_indicator
           AND   bank_rtncode = im_return_code
           AND   bank_reqsts = im_request_status
           AND   bank_rtnflg = im_request_result
           AND   spras = sy-langu.


  ENDMETHOD.


METHOD get_bank_return_code_type.
    SELECT SINGLE rtntype INTO re_type
           FROM ztrt_bfun_rtncod
           WHERE bank_ind = bank_indicator
           AND   bank_func = im_bank_func
           AND   bank_rtncode = im_return_code
           AND   bank_reqsts = im_request_status
           AND   bank_rtnflg = im_request_result.
    IF sy-subrc <> 0.
      SELECT SINGLE rtntype INTO re_type
             FROM ztrt_bank_rtncod
             WHERE bank_ind = bank_indicator
             AND   bank_rtncode = im_return_code
             AND   bank_reqsts = im_request_status
             AND   bank_rtnflg = im_request_result.
    ENDIF.
    IF re_type IS INITIAL.
      re_type = bank_return_code_is_unknow.
    ENDIF.
  ENDMETHOD.


METHOD get_function_by_step.
    DATA(ls_step) = get_single_step( im_step ).
*    return_if_error.
    IF if_error( ) = yes.
      RETURN.
    ENDIF.
    rs_bank_function = get_bank_function( ls_step-bank_func ).
  ENDMETHOD.


METHOD get_function_name_by_step.
    DATA(ls_step) = get_single_step( im_step ).
*    return_if_error.
    IF if_error( ) = yes.
      RETURN.
    ENDIF.
    re_function = ls_step-bank_func.
  ENDMETHOD.


METHOD get_function_text.
    DATA l_langu TYPE sylangu.

    IF im_langu IS INITIAL.
      l_langu = sy-langu.
    ELSE.
      l_langu = im_langu.
    ENDIF.

    SELECT SINGLE ltext INTO re_text
           FROM ztrt_bank_funct
           WHERE bank_ind = bank_indicator
           AND   bank_func = im_bank_function
           AND   spras = l_langu.

  ENDMETHOD.


METHOD get_main_step.
    get_bank_action( ).
*    return_if_error.
    if if_error( ) = yes.
      return.
      endif.

    re_main_step = bank_action_setting-mainstep.

  ENDMETHOD.


METHOD get_main_step_input_structure.
    get_action( ).
    get_steps( ).

*    return_if_error. "不应该有错误
    IF if_error( ) = yes.
      RETURN.
    ENDIF.

    READ TABLE bank_action_steps INTO DATA(ls_step)
          WITH KEY bank_ind = bank_action_setting-bank_ind
                   bank_action = bank_action_setting-bank_action
                   step = bank_action_setting-mainstep.
    IF sy-subrc <> 0.
*      不应该有错误
      MESSAGE e043(ztr_bank_application)
              WITH bank_indicator
                   action
                   action_text
*                   im_step
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = enviroment_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator ) ).
      RETURN.
*      add_system_msg_and_return_03 043
*                                   bank_indicator
*                                   action
*                                   action_text.
    ENDIF.

    DATA(ls_bank_function) = get_bank_function( ls_step-bank_func ).
*    return_if_error."不应该有错误
    IF if_error( ) = yes.
      RETURN.
    ENDIF.

    re_structure = ls_bank_function-struc_in.
    IF re_structure IS INITIAL.
      MESSAGE e045(ztr_bank_application)
              WITH bank_indicator
                   action
                   action_text
*                   im_step
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = enviroment_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator ) ).
      RETURN.

*      add_system_msg_and_return_03 045
*                                   bank_indicator
*                                   action
*                                   action_text.
    ENDIF.

  ENDMETHOD.


METHOD get_single_step.
    get_action( ).
    get_steps( ).

*    return_if_error. "不应该有错误
if if_error( ) = yes.
  return.
  endif.

    READ TABLE bank_action_steps INTO rs_step
          WITH KEY bank_ind       = bank_action_setting-bank_ind
                   bank_action    = bank_action_setting-bank_action
                   step           = im_step.
    IF sy-subrc <> 0.
*      不应该有错误
      MESSAGE e066(ztr_bank_application)
              WITH bank_indicator
                   action
                   action_text
                   im_step
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = enviroment_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator ) ).
      RETURN.

*      add_system_msg_and_return_04 066
*                                   bank_indicator
*                                   action
*                                   action_text
*                                   im_step.
    ENDIF.
  ENDMETHOD.


METHOD get_steps.
    IF bank_indicator IS INITIAL.
*    start log
      MESSAGE e061(ztr_bank_application)
              INTO dummy_message.
      zcl_bank_logger_protocal=>add_log(
               VALUE #( uuid         = enviroment_uuid
                        msgid        = sy-msgid
                        msgno        = sy-msgno
                        msgty        = sy-msgty
                        msgv1        = sy-msgv1
                        msgv2        = sy-msgv2
                        msgv3        = sy-msgv3
                        msgv4        = sy-msgv4
                        message      = dummy_message
                        bank_action  = action
                        bank_ind     = bank_indicator ) ).
      return.
*end log

*      add_system_msg_and_return_00 061.
    ENDIF.

    IF action IS INITIAL.
*    start log
    MESSAGE e062(ztr_bank_application)
            INTO dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = enviroment_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = action
                      bank_ind     = bank_indicator ) ).
    return.
*end log
*      add_system_msg_and_return_00 062.
    ENDIF.

    LOOP AT bank_action_steps TRANSPORTING NO FIELDS
          WHERE bank_ind <> bank_indicator
          AND   bank_action <> action.
      EXIT.
    ENDLOOP.
    IF sy-subrc = 0 OR
       bank_action_steps IS INITIAL.
      CLEAR bank_action_steps.
      SELECT * INTO TABLE bank_action_steps
             FROM ztrt_bkact_step
             WHERE bank_ind = bank_indicator
             AND   bank_action = action.
      IF sy-subrc <> 0.
*        start log
        MESSAGE e042(ztr_bank_application)
                with bank_indicator
                     action
                     action_text
                into dummy_message.
    zcl_bank_logger_protocal=>add_log(
             VALUE #( uuid         = enviroment_uuid
                      msgid        = sy-msgid
                      msgno        = sy-msgno
                      msgty        = sy-msgty
                      msgv1        = sy-msgv1
                      msgv2        = sy-msgv2
                      msgv3        = sy-msgv3
                      msgv4        = sy-msgv4
                      message      = dummy_message
                      bank_action  = action
                      bank_ind     = bank_indicator ) ).
    return.
*    end log

*        add_system_msg_and_return_03 042
*                                     bank_indicator
*                                     action
*                                     action_text.
      ELSE.
        DATA(ls_bank) = get_bank( ).
        LOOP AT bank_action_steps ASSIGNING FIELD-SYMBOL(<fs_step>)
              WHERE destination IS INITIAL.
          <fs_step>-destination = ls_bank-destination.
        ENDLOOP.
      ENDIF.
    ENDIF.

    rt_bank_action_steps = bank_action_steps.

    sort rt_bank_action_steps by bank_ind
                                 bank_action
                                 step.
  ENDMETHOD.


method IF_ERROR.
    re_error = messages->if_error( ).
  endmethod.


METHOD publish_messages.
    messages->publish_messages(
            EXPORTING
              i_published_mode = zcl_message_collector=>internal_mode
             IMPORTING
              et_messages      = et_messages ).
  ENDMETHOD.


METHOD s_check_action_from_external.
    IF im_action IS INITIAL.
      MESSAGE e083(ztr_bank_application)
               RAISING blank_action.
    ENDIF.


    SELECT SINGLE * INTO ex_s_action
            FROM ztrt_action
            WHERE bank_action = im_action.
    IF sy-subrc <> 0.
      MESSAGE e069(ztr_bank_application)
              WITH im_action
              RAISING not_found.
    ENDIF.

    SELECT SINGLE ltext INTO @DATA(l_text)
            FROM  ztrt_actiont
            WHERE bank_action = @im_action
            AND   spras       = @sy-langu.

    IF ex_s_action-instance_class IS INITIAL.
      MESSAGE e071(ztr_bank_application)
              WITH im_action
                   l_text
              RAISING class_not_config.
    ENDIF.

    IF ex_s_action-formatted_struc_res IS INITIAL.
      MESSAGE e084(ztr_bank_application)
              WITH im_action
                   l_text
              RAISING formatted_structure_not_config.
    ELSE.
      zcl_global_technical_service=>check_table(
                        EXPORTING
                          im_tabname = ex_s_action-formatted_struc_res
                        EXCEPTIONS
                          not_found  = 1 ).
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid
                TYPE sy-msgty
                NUMBER sy-msgno
                WITH sy-msgv1
                     sy-msgv2
                     sy-msgv3
                     sy-msgv4
                RAISING formatted_structure_not_found.
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD S_DETERMINE_BANK_INSTANCE_CLS.
    CONSTANTS: c_http_mode TYPE ztr_communication_type VALUE '1'.

    CASE im_communication_type.
      WHEN c_http_mode.
        re_instance_class = 'ZCL_BANK_HTTP_BANK'.
      WHEN OTHERS.
*        IT SHOULD SKIP BY TESTING
        MESSAGE e998(ztr_bank_application)
                WITH im_communication_type
                     zcl_global_technical_service=>get_domain_text(
                         im_ingnore_error = abap_true
                         im_domain_name   = 'ZDM_TR_COMMUNICATION_TYPE'
                         im_domain_value  = c_http_mode ).
    ENDCASE.
  ENDMETHOD.


METHOD S_GET_BANK_ACC_INSTANCE_CLASS.
    SELECT SINGLE account_class INTO re_instance_class
            FROM ztrt_bank
            WHERE bank_ind = im_bank_indicator.
    IF sy-subrc <> 0 or
        re_instance_class is INITIAL.
      MESSAGE e098 WITH im_bank_indicator
              RAISING not_found.
    ENDIF.
  ENDMETHOD.


method S_GET_BANK_ACTION_TEXT.
    select single ltext into re_text
           FROM ztrt_actiont
           where bank_action = im_action
           and   spras = sy-langu.
  endmethod.


METHOD s_get_bank_instance_class.
    SELECT SINGLE * INTO @DATA(ls_bank)
            FROM ztrt_bank
            WHERE bank_ind = @im_bank_indicator.
    IF sy-subrc <> 0.
      MESSAGE e020 WITH im_bank_indicator.
    ENDIF.

    IF ls_bank-instance_class IS INITIAL.
      re_instance_class = zcl_bank_enviroment=>s_determine_bank_instance_cls( ls_bank-comm_type ).
    ELSE.
      re_instance_class = ls_bank-instance_class.
    ENDIF.
  ENDMETHOD.


METHOD S_GET_FUNCTION_BY_STEP.
    SELECT SINGLE * INTO @DATA(ls_bank_action_step)
                    FROM ztrt_bkact_step
                    WHERE bank_ind = @im_bank_indicator
                    AND   bank_action = @im_action
                    AND   step = @im_step.
    IF sy-subrc <> 0.
*      remove the error by testing
      MESSAGE e072(ztr_bank_application)
              WITH im_bank_indicator
                   im_action
                   im_step
              RAISING error.
    ENDIF.

    IF ls_bank_action_step-bank_func IS INITIAL.
      MESSAGE e073(ztr_bank_application)
              WITH im_bank_indicator
                   im_action
                   im_step
                   ls_bank_action_step-bank_func
               RAISING error.
    ENDIF.

    SELECT SINGLE * INTO @DATA(ls_bank_function)
           FROM ztrt_bank_func
           WHERE bank_ind = @ls_bank_action_step-bank_ind
           AND   bank_func = @ls_bank_action_step-bank_func.
    IF sy-subrc <> 0.
      MESSAGE e074(ztr_bank_application)
              WITH im_bank_indicator
                   ls_bank_action_step-bank_func
              RAISING error.
    ENDIF.

    IF ls_bank_function-instance_class IS INITIAL.
      MESSAGE e075(ztr_bank_application)
              WITH im_bank_indicator
                   ls_bank_action_step-bank_func
               RAISING error.
    ENDIF.

    ex_s_bank_function = ls_bank_function.
  ENDMETHOD.


METHOD s_get_status_by_error_step.
    SELECT SINGLE entstatus INTO e_status
           FROM ztrt_steperr_map
           WHERE bank_ind = im_bank_ind
           AND   bank_action = im_action
           AND   step = im_step
           AND   instance_err = im_instance_err.
    IF sy-subrc <> 0.
      SELECT SINGLE entstatus INTO e_status
            FROM ztrt_entbk_map
            WHERE instance_err = im_instance_err.
*      IF sy-subrc <> 0.
**      critical technical error
*        MESSAGE e226 WITH im_bank_ind
*                          im_action
*                          im_step
*                          im_instance_err
*                     RAISING not_found.
*      ENDIF.
    ENDIF.

    IF e_status IS INITIAL.
      MESSAGE e226 WITH im_bank_ind
                        im_action
                        im_step
                        im_instance_err
                   RAISING not_found.
    ENDIF.

  ENDMETHOD.
ENDCLASS.
