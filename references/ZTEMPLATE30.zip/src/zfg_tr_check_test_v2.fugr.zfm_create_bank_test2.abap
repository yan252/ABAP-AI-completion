FUNCTION ZFM_CREATE_BANK_TEST2.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     REFERENCE(DOCNO) TYPE  ZTR_DOCNO
*"     REFERENCE(TEST) TYPE  CHAR1 OPTIONAL
*"  EXPORTING
*"     REFERENCE(MSG) TYPE  STRING
*"     REFERENCE(BANKL) TYPE  BANKK
*"--------------------------------------------------------------------
DATA ls_tr0014 TYPE ztrt0014.
  DATA lv_numc TYPE numc10.
  DATA lv_bankl TYPE bankk.
  DATA lr_bankl TYPE RANGE OF bnka-bankl.
  DATA ls_bankl LIKE LINE OF lr_bankl.


  CLEAR msg.
  SELECT SINGLE * INTO ls_tr0014
    FROM ztrt0014
    WHERE docno = docno.
  IF sy-subrc <> 0.
    msg = TEXT-e01.
    RETURN.
  ENDIF.


  IF ls_tr0014-banks <> 'CN' AND ls_tr0014-bankl IS INITIAL.
    ls_bankl-sign = 'I'.
    ls_bankl-option = 'CP'.
    ls_bankl-low = '1*'.
    APPEND ls_bankl TO lr_bankl.
    clear lv_bankl.
    SELECT MAX( bankl ) INTO lv_bankl FROM bnka
      WHERE banks = ls_tr0014-banks AND bankl IN lr_bankl.
    IF sy-subrc <> 0 or lv_bankl IS INITIAL.
      ls_tr0014-bankl = '1000000000'.
    ELSE.
      lv_numc =  lv_bankl.
      lv_numc = lv_numc + 1.
      ls_tr0014-bankl = lv_numc.
    ENDIF.
  ENDIF.

*创建
  DATA: ls_address TYPE bapi1011_address,
        ls_return  TYPE bapiret2,
        lv_city    TYPE banks,
        lv_bank    TYPE bankk.

  ls_address-bank_name = ls_tr0014-banka.
  ls_address-street = ls_tr0014-stras.
  ls_address-city = ls_tr0014-ort01.
  ls_address-swift_code = ls_tr0014-swift.
  ls_address-bank_no = ls_tr0014-bnklz.
  ls_address-bank_branch = ls_tr0014-brnch.
  ls_address-region = ls_tr0014-provz.

  SET PARAMETER ID 'BDOCU' FIELD docno.

  CALL FUNCTION 'BAPI_BANK_CREATE'
    EXPORTING
      bank_ctry           = ls_tr0014-banks
      bank_key            = ls_tr0014-bankl
      bank_address        = ls_address
      i_xupdate           = ''
      i_check_before_save = test
    IMPORTING
      return              = ls_return
      bankcountry         = lv_city
      bankkey             = lv_bank.
  IF ls_return-type <> 'E' AND  ls_return-type <> 'A'.
    IF test IS INITIAL.
      bankl = ls_tr0014-bankl.
      UPDATE ztrt0014 SET bankl = ls_tr0014-bankl WHERE docno = docno.
      COMMIT WORK.
    ENDIF.
  ELSE.
    msg = ls_return-message.
  ENDIF.





ENDFUNCTION.
