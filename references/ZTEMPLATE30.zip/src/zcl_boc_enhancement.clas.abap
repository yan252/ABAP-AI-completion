class ZCL_BOC_ENHANCEMENT definition
  public
  final
  create public .

public section.

  class-methods GET_B2E0035_CHECKING_TYPE
    importing
      !IM_START_DATE type DATUM
    returning
      value(RE_TYPE) type CHAR004 .
  class-methods CONVERT_DEBIT_AND_CREDIT_FLAG
    importing
      !IM_DIRECTION type ZTR_BOC_DIRECTION
    returning
      value(RE_SAP_VALUE) type SHKZG .
  class-methods SPLIT_INTERINFO
    importing
      !IM_INTERINFO_TEXT type ZTR_BOC_INTERINFO
    returning
      value(RT_SPLITTED_TABLE) type ZTRS_BOC_INTERINFO_TAB .
  class-methods GET_INTERINFO_PARTIALLY
    importing
      !IM_INTERINFO_CODE type ZTR_BOC_INTERINFO_CODE
      !IM_INTERINFO_TEXT type ZTR_BOC_INTERINFO
    returning
      value(R_TEXT) type STRING .
  class-methods GET_DARFTTYPE
    importing
      !IM_SAP_DRAFTTYPE type ZTR_EDOC_DRAFTTYPE
    returning
      value(RE_BOC_DRAFTTYPE) type STRING .
  class-methods GET_TRANSFERFLG
    importing
      !IM_SAP_TRANSFERFLG type ZTR_DRAFT_TRANSFERFLG
    returning
      value(RE_BOC_TRANSFERFLG) type STRING .
  class-methods GET_AUTOREC
    importing
      !IM_SAP_AUTOREC type ZTR_DRAFT_AUTO_RECEIVE
    returning
      value(RE_BOC_AUTOREC) type STRING .
  class-methods GET_AUTOACP
    importing
      !IM_SAP_AUTOACP type ZTR_DRAFT_AUTO_ACCEPT
    returning
      value(RE_BOC_AUTOACP) type STRING .
  class-methods SET_BOCFLAG
    importing
      !IM_S_FPAYH type FPAYH
    returning
      value(RE_VALUE) type CHAR01 .
  class-methods SET_BANK_DATE
    returning
      value(RE_DATE) type SYDATUM .
protected section.
private section.
ENDCLASS.



CLASS ZCL_BOC_ENHANCEMENT IMPLEMENTATION.


METHOD convert_debit_and_credit_flag.

    CASE im_direction.
      WHEN '1'.
*        来账
        re_sap_value = 'S'.
      WHEN '2'.
*        往账
        re_sap_value = 'H'.
    ENDCASE.



  ENDMETHOD.


METHOD get_autoacp.
    IF im_sap_autoacp = 'X'.
      re_boc_autoacp = '1'.
    ELSE.
      re_boc_autoacp = '0'.
    ENDIF.
  ENDMETHOD.


METHOD GET_AUTOREC.
    IF im_sap_autorec = 'X'.
      re_boc_autorec = '1'.
    ELSE.
      re_boc_autorec = '0'.
    ENDIF.
  ENDMETHOD.


METHOD get_b2e0035_checking_type.
*    im_start_date 不应该大于系统当天

    DATA(l_current_date) = zcl_boc_enhancement=>set_bank_date( ).
    IF l_current_date IS INITIAL.
      l_current_date = sy-datum.
    ENDIF.
    IF im_start_date = l_current_date .
*      当日查询
      re_type = '2001'.
    ELSE.
*      历史查询
      re_type = '2002'.
    ENDIF.

*    2005(T+1 查询T日夜间批量交易) - 不使用这个类型
  ENDMETHOD.


METHOD get_darfttype.
    CASE im_sap_drafttype.
      WHEN '15'.
*        电子银票
        re_boc_drafttype = 'AC01'.
      WHEN '25'.
*        电子商票
        re_boc_drafttype = 'AC02'.
    ENDCASE.
  ENDMETHOD.


METHOD get_interinfo_partially.
    READ TABLE split_interinfo( im_interinfo_text ) INTO DATA(ls_data)
         WITH KEY interinfo_code = im_interinfo_code.
    r_text = ls_data-text_value .
  ENDMETHOD.


METHOD get_transferflg.
    IF im_sap_transferflg = 'X'.
*      可以转让
      re_boc_transferflg = 'EM00'.
    ELSE.
*      不可以转让
      re_boc_transferflg = 'EM01'.
    ENDIF.
  ENDMETHOD.


method SET_BANK_DATE.
**************************
*    中国银行银行测试系统的日期有可能和自然日期不一致，
**************************
    SELECT SINGLE bank_date INTO re_date
           FROM ztrt_bank_date
           WHERE bank_ind = 'BOC'.
  endmethod.


METHOD set_bocflag.
    IF zcl_bank_cnaps_code=>if_same_bank(
                              EXPORTING
                                im_code1 = im_s_fpayh-zbnky
                                im_code2 = im_s_fpayh-bnkl1 ) = 'X'.
*      收付款方都是中行账户
      re_value = '1'.
    ELSE.
*      付款方不是中行账户
      re_value = '0'.
    ENDIF.
  ENDMETHOD.


METHOD split_interinfo.

    IF im_interinfo_text IS INITIAL.
      RETURN.
    ENDIF.

    SPLIT im_interinfo_text AT '//' INTO TABLE DATA(lt_string).

    LOOP AT lt_string INTO DATA(l_string).
      CHECK l_string IS NOT INITIAL.
      APPEND VALUE #( interinfo_code = l_string+0(1)
                      text_value = l_string+2 )
                     TO rt_splitted_table.
    ENDLOOP.
  ENDMETHOD.
ENDCLASS.
