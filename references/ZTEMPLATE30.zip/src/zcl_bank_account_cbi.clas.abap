class ZCL_BANK_ACCOUNT_CBI definition
  public
  inheriting from ZCL_ABSTRACT_BANK_ACCOUNT
  final
  create public .

public section.

  class-methods GET_CHAR_LAST
    importing
      !IV_DATA type STRING
      !IV_LENGTH type I
    returning
      value(RV_DATA) type STRING .
protected section.

  methods BANK_BALANCE_TO_SAP
    redefinition .
  methods BANK_TRANSACTIONS_TO_SAP
    redefinition .
  methods SET_ACCOUNT_BALANCE_CORE
    redefinition .
  methods SET_ACCOUNT_TABNAME
    redefinition .
  methods SET_TRANSACTIONS_CORE
    redefinition .
  methods DEQUEUE_TRANSACTION
    redefinition .
private section.
ENDCLASS.



CLASS ZCL_BANK_ACCOUNT_CBI IMPLEMENTATION.


METHOD bank_balance_to_sap.
    FIELD-SYMBOLS: <ft_new_account_balance> TYPE STANDARD TABLE.
    DATA: ls_balance_ext TYPE ztrt_citic_acbal.

    ASSIGN new_account_balance->* TO <ft_new_account_balance>.
    IF <ft_new_account_balance> IS NOT ASSIGNED OR
       <ft_new_account_balance> IS INITIAL.
      RETURN.
    ENDIF.

    LOOP AT <ft_new_account_balance> INTO ls_balance_ext.
      APPEND VALUE #(
                       bukrs        = ls_balance_ext-sap_bukrs
                       hbkid        = ls_balance_ext-sap_hbkid
                       hktid        = ls_balance_ext-sap_hktid
                       yhzh         = ls_balance_ext-accountno
                       bank_ind     = bank_indicator
                       zyue_ttl     = ls_balance_ext-balance
                       zyue_frz     = ls_balance_ext-forzenamt
                       zyue         = ls_balance_ext-usablebalance + ls_balance_ext-lawptlmt
                       waers        = get_account_currency( ls_balance_ext-sap_fields )
                       ) TO rt_balance.

    ENDLOOP.
  ENDMETHOD.


METHOD bank_transactions_to_sap.
    FIELD-SYMBOLS: <ft_new_transactions> TYPE STANDARD TABLE.
    DATA: ls_transactions_ext TYPE ztrt_citic_trns.
    DATA: lv_waers TYPE waers.
    DATA: lv_bkfse TYPE ztrt_bank_trans-bkfse.

    ASSIGN new_transactions->* TO <ft_new_transactions>.
    IF <ft_new_transactions> IS NOT ASSIGNED OR
       <ft_new_transactions> IS INITIAL.
      RETURN.
    ENDIF.

    LOOP AT <ft_new_transactions> INTO ls_transactions_ext.
      DATA(l_shkzg) = zcl_citic_enhancement=>convert_debit_and_credit_flag( ls_transactions_ext-creditdebitflag ).
      "DATA(ls_paymentkey) = get_paymkey_from_transaction( ls_transactions_ext-abstract ).
*-----Begin 对方名称中的全角和半角括号去除后存入字段BKOINH1中 金志强 Add by KLTDEV5 20190726
      "字符串转换
      DATA:lv_bkoinh TYPE string.
      lv_bkoinh = ls_transactions_ext-oppaccountname.
      lv_bkoinh = convert_string( EXPORTING string = lv_bkoinh char = '(' ).
      lv_bkoinh = convert_string( EXPORTING string = lv_bkoinh char = ')' ).
      lv_bkoinh = convert_string( EXPORTING string = lv_bkoinh char = '（' ).
      lv_bkoinh = convert_string( EXPORTING string = lv_bkoinh char = '）' ).
*-----End 对方名称中的全角和半角括号去除后存入字段BKOINH1中 金志强 Add by KLTDEV5 20190726

*&BEGIN-------------------------------------------------------------
*&币种
*&CHANGE DATE: 12.03.2020
*&AUTHOR    : HANDXXJ
*&------------------------------------------------------------------
      CLEAR: lv_waers.
      lv_bkfse = ls_transactions_ext-tranamount.
      zcl_elec_receipt_cbi=>currency_trans( EXPORTING iv_waers = ls_transactions_ext-sap_waers  CHANGING ev_netwr = lv_bkfse ). "发生额
      zcl_elec_receipt_cbi=>currency_trans( EXPORTING iv_waers = ls_transactions_ext-sap_waers  CHANGING ev_netwr = ls_transactions_ext-balance ).  "交易后余额

      "原有金额
      lv_waers = zcl_cbi_dlcbitrn_enhancement=>convert_waers_internal( COND #( WHEN ls_transactions_ext-oridebitcry IS NOT INITIAL THEN ls_transactions_ext-oridebitcry
                                                                                                     ELSE ls_transactions_ext-oricreditcry ) ).
      IF lv_waers IS NOT INITIAL.
        IF ls_transactions_ext-oridebitamt IS NOT INITIAL.
          zcl_elec_receipt_cbi=>currency_trans( EXPORTING iv_waers = lv_waers  CHANGING ev_netwr = ls_transactions_ext-oridebitamt ).
        ELSEIF ls_transactions_ext-oricreditamt IS NOT INITIAL.
          zcl_elec_receipt_cbi=>currency_trans( EXPORTING iv_waers = lv_waers  CHANGING ev_netwr = ls_transactions_ext-oricreditamt ).
        ENDIF.
      ENDIF.
*&END---------------------------------------------------------------

      APPEND VALUE ztrt_bank_trans(
                       bukrs        = ls_transactions_ext-sap_bukrs
                       hbkid        = ls_transactions_ext-sap_hbkid
                       hktid        = ls_transactions_ext-sap_hktid
                       yhzh         = ls_transactions_ext-accountno
                       trxno        = ls_transactions_ext-trandate && ls_transactions_ext-hosttrancode
                                      && ls_transactions_ext-tranrefno+0(25) && ls_transactions_ext-tranamount
                       bank_ind     = bank_indicator
                       trxdate      = ls_transactions_ext-trandate
                       trxtime      = ls_transactions_ext-trantime
                       shkzg        = l_shkzg
*                       bkfse       = ls_transactions_ext-tranamount
                       bkfse       = lv_bkfse "Modify by handxxj 20201203
                       trxamt        = convert_transamt_by_shkzg( im_shkzg = l_shkzg
*                                                                 im_original_amt = ls_transactions_ext-tranamount )
                                                                 im_original_amt = lv_bkfse ) "Modify by handxxj 20201203
                       balamt       = ls_transactions_ext-balance
                       waers        = ls_transactions_ext-sap_waers
                       bzbnka       = ls_transactions_ext-oppopenbankname
                       bzbnkn       = COND #( WHEN ls_transactions_ext-oppaccountno IS NOT INITIAL THEN ls_transactions_ext-oppaccountno
                                              WHEN ls_transactions_ext-oppaccountno IS INITIAL AND ls_transactions_ext-creditdebitflag = 'D'
                                              AND  ls_transactions_ext-abstract+0(19) = 'Transfer Withdrawal' AND ls_transactions_ext-tranrefno+13(12) = ls_transactions_ext-accountno
                                              THEN ls_transactions_ext-tranrefno+0(12) )
                       bkoinh       = ls_transactions_ext-oppaccountname
                       abstract_txt = ls_transactions_ext-abstract
                       bankref      = COND #( WHEN ls_transactions_ext-tranrefno+0(2) = '89' THEN ls_transactions_ext-tranrefno+0(16)
                                              WHEN ls_transactions_ext-tranrefno+0(4) = '0089' THEN ls_transactions_ext-tranrefno+0(14)
                                              ELSE ls_transactions_ext-tranrefno )
                       refstep     = COND #( WHEN ls_transactions_ext-tranrefno+0(2) = '89' OR ls_transactions_ext-tranrefno+0(4) = '0089'
                                             THEN get_char_last( iv_data = |{ ls_transactions_ext-tranrefno }| iv_length = 6 ) )
                       paymorder = COND #( WHEN ls_transactions_ext-clientid IS NOT INITIAL THEN ls_transactions_ext-clientid
                                         WHEN ls_transactions_ext-abstract+0(23) = zcl_bank_payment_entry=>transaction_reference_prefix THEN ls_transactions_ext-abstract+24(10) )

                      "paymentkey   = ls_paymentkey
                      zref_doc = COND #( WHEN ls_transactions_ext-clientid IS NOT INITIAL THEN ls_transactions_ext-clientid
                                         WHEN ls_transactions_ext-abstract+0(23) = zcl_bank_payment_entry=>transaction_reference_prefix THEN ls_transactions_ext-abstract+24(10) )
                      intfdate     = system_info-datum
                      intftime     = system_info-uzeit
                      oriamt       = COND #( WHEN ls_transactions_ext-oridebitamt IS NOT INITIAL THEN ls_transactions_ext-oridebitamt
                                             ELSE ls_transactions_ext-oricreditamt )
*                      oriccy       = zcl_cbi_dlcbitrn_enhancement=>convert_waers_internal( COND #( WHEN ls_transactions_ext-oridebitcry IS NOT INITIAL THEN ls_transactions_ext-oridebitcry
*                                                                                                   ELSE ls_transactions_ext-oricreditcry ) )
                      oriccy       = lv_waers   "Modify by handxxj 20201203

*                                       kunnr2       = set_customer_code_by_name( ls_transactions_ext-oppaccountname )
*                                       lifnr        = set_vendor_code_by_name( ls_transactions_ext-oppaccountname )
                      partner = set_partner_by_name( ls_transactions_ext-oppaccountname )
                      bkoinh1 = lv_bkoinh
) TO rt_transactions.

    ENDLOOP.

    SORT rt_transactions BY bukrs
                            hbkid
                            hktid
                            yhzh
                            trxno.

    DELETE ADJACENT DUPLICATES FROM rt_transactions COMPARING bukrs
                                                              hbkid
                                                              hktid
                                                              yhzh
                                                              trxno.

    finished_sap_tranx_fields(
               CHANGING
                 ch_t_tranx = rt_transactions ).

  ENDMETHOD.


method DEQUEUE_TRANSACTION.
    DATA:ls_transaction TYPE ztrt_citic_trns.

    LOOP AT im_t_transactions INTO ls_transaction.
      dequeue_transaction_core(
                     im_bukrs = ls_transaction-sap_bukrs
                     im_hbkid = ls_transaction-sap_hbkid
                     im_hktid = ls_transaction-sap_hktid
                     im_yhzh = ls_transaction-accountno
                     im_trxno = ls_transaction-sumtranno ).
    ENDLOOP.
  endmethod.


METHOD get_char_last.
    CHECK iv_data IS NOT INITIAL.

    DATA(lv_length) = strlen( iv_data ).
    CHECK lv_length > iv_length.
    CHECK iv_length > 0.

    DATA(lv_begin) = lv_length - iv_length.

    rv_data = iv_data+lv_begin(iv_length).
  ENDMETHOD.


METHOD SET_ACCOUNT_BALANCE_CORE.
    FIELD-SYMBOLS: <ft_acc_balance> TYPE ztrt_citic_acbal_tab.
    FIELD-SYMBOLS:<ft_new_entries> TYPE ztrt_citic_acbal_tab.
    DATA: l_new     TYPE flag,
          l_changed TYPE flag.

    ASSIGN im_data->* TO <ft_acc_balance>.

    assign NEW_ACCOUNT_BALANCE->* to <ft_new_entries>.

    IF <ft_acc_balance> IS INITIAL.
      RETURN.
    ENDIF.

    SELECT * INTO TABLE @DATA(lt_old_data)
           FROM ztrt_citic_acbal
           FOR ALL ENTRIES IN @<ft_acc_balance>
           WHERE accountno = @<ft_acc_balance>-accountno.

    LOOP AT <ft_acc_balance> INTO DATA(ls_acc_balance).
      CHECK filter_accbal_by_shifton_date(
                  EXPORTING
                    im_s_sap_field = ls_acc_balance-sap_fields ) = 'X'.
      enqueue_balance_core(
                 EXPORTING
                   im_bukrs = ls_acc_balance-sap_bukrs
                   im_hbkid = ls_acc_balance-sap_hbkid
                   im_hktid = ls_acc_balance-sap_hktid
                 IMPORTING
                   ex_enqueue_failed = DATA(l_enqueue_failed) ).
      IF l_enqueue_failed = yes.
*        被锁定，不纳入本次处理
        CLEAR l_enqueue_failed.
        CONTINUE.
      ENDIF.

      READ TABLE lt_old_data INTO DATA(ls_old_data)
           WITH KEY accountno = ls_acc_balance-accountno.
      IF sy-subrc <> 0.
*      new
        l_new = 'X'.
      ELSE.
        IF ls_acc_balance-acc_field <> ls_old_data-acc_field.
          l_changed = 'X'.
        ENDIF.
      ENDIF.

      IF l_new = 'X' OR
         l_changed = 'X'.
        ls_acc_balance-dbadmin = ls_old_data-dbadmin.
        set_admin_fields(
                  EXPORTING
                    im_new_entry = l_new
                  CHANGING
                    cs_admin = ls_acc_balance-dbadmin ).
        APPEND ls_acc_balance TO <ft_new_entries>.
      ELSE.
        dequeue_balance_core(
                   EXPORTING
                     im_bukrs = ls_acc_balance-sap_bukrs
                     im_hbkid = ls_acc_balance-sap_hbkid
                     im_hktid = ls_acc_balance-sap_hktid ).
      ENDIF.

      CLEAR: l_new,
             l_changed.
    ENDLOOP.

  ENDMETHOD.


METHOD SET_ACCOUNT_TABNAME.
    transaction_db_tabname = 'ZTRT_CITIC_TRNS'.
    account_balance_db_tabname = 'ZTRT_CITIC_ACBAL'.
    super->SET_ACCOUNT_TABNAME( ).
  ENDMETHOD.


METHOD set_transactions_core.
    FIELD-SYMBOLS: <ft_transactions> TYPE ztrt_citic_trns_tab.
    FIELD-SYMBOLS: <ft_new_entries> TYPE ztrt_citic_trns_tab.
    DATA: l_new     TYPE flag,
          l_changed TYPE flag.

    ASSIGN im_data->* TO <ft_transactions>.

    ASSIGN new_transactions->* TO <ft_new_entries>.

    IF <ft_transactions> IS NOT ASSIGNED OR
       <ft_transactions> IS INITIAL.
      RETURN.
    ENDIF.

    LOOP AT <ft_transactions> ASSIGNING FIELD-SYMBOL(<fs_transactions>).
      <fs_transactions>-sumtranno = <fs_transactions>-trandate && <fs_transactions>-hosttrancode
                                            && <fs_transactions>-tranrefno+0(25) && <fs_transactions>-tranamount.
    ENDLOOP.


    SELECT * INTO TABLE @DATA(lt_old_data)
           FROM ztrt_citic_trns
           FOR ALL ENTRIES IN @<ft_transactions>
           WHERE accountno = @<ft_transactions>-accountno
           AND   sumtranno = @<ft_transactions>-sumtranno.

    LOOP AT <ft_transactions> INTO DATA(ls_transactions).
      CHECK filter_trans_by_shifton_date(
                  EXPORTING
                    im_s_sap_field = ls_transactions-sap_fields
                    im_transaction_date = CONV #( ls_transactions-trandate ) ) = 'X'.
      enqueue_transaction_core(
                   EXPORTING
                     im_bukrs = ls_transactions-sap_bukrs
                     im_hbkid = ls_transactions-sap_hbkid
                     im_hktid = ls_transactions-sap_hktid
                     im_yhzh = ls_transactions-accountno
                     im_trxno = ls_transactions-sumtranno
                   IMPORTING
                     ex_enqueue_failed = DATA(l_enqueue_failed) ).
      IF l_enqueue_failed = yes.
*        被锁定，不纳入本次处理
        CLEAR l_enqueue_failed.
        CONTINUE.
      ENDIF.

      READ TABLE lt_old_data INTO DATA(ls_old_data)
           WITH KEY accountno = ls_transactions-accountno
                    sumtranno = ls_transactions-sumtranno.
      IF sy-subrc <> 0.
*      new
        l_new = 'X'.
      ELSE.
        IF ls_transactions-trns_field <> ls_old_data-trns_field.
          l_changed = 'X'.
        ENDIF.
      ENDIF.

      IF l_new = 'X' OR
         l_changed = 'X'.
        ls_transactions-dbadmin = ls_old_data-dbadmin.
        set_admin_fields(
                  EXPORTING
                    im_new_entry = l_new
                  CHANGING
                    cs_admin = ls_transactions-dbadmin ).
        APPEND ls_transactions TO <ft_new_entries>.
      ELSE.
        dequeue_transaction_core(
                     EXPORTING
                       im_bukrs = ls_transactions-sap_bukrs
                       im_hbkid = ls_transactions-sap_hbkid
                       im_hktid = ls_transactions-sap_hktid
                       im_yhzh = ls_transactions-accountno
                       im_trxno = ls_transactions-sumtranno ).
      ENDIF.

      CLEAR: l_new,
             l_changed,
             ls_old_data.
    ENDLOOP.

  ENDMETHOD.
ENDCLASS.
