class ZCL_BANK_BOC_FUNCTION_M04 definition
  public
  inheriting from ZCL_BANK_FUNCTION_CHECKPAYM
  final
  create public .

public section.

  interfaces ZIF_BOC_FUNCTION .

  aliases RAISE_B2EERROR
    for ZIF_BOC_FUNCTION~RAISE_B2EERROR .
protected section.

  methods ADJUST_RESPONSING_XML_B4_CONV
    redefinition .
  methods PROCESSING_RESPONSE_INTL_CORE
    redefinition .
private section.
ENDCLASS.



CLASS ZCL_BANK_BOC_FUNCTION_M04 IMPLEMENTATION.


  METHOD adjust_responsing_xml_b4_conv.
*    中国银行b2e0529返回的报文里含有两个status节点
*    SAPd transformation不能区分
*    因此在调用transformation之前先将其中一个(汇票处理状态)status节点
*    进行修饰

*    re_string = im_string.

    LOOP AT zcl_global_technical_service=>get_domain_values( 'ZDM_TR_BOC_B2E0529_STATUS' )
              INTO DATA(ls_domain_value).
*      原来的节点
      DATA(l_as_element) = '<status>' &&
                           ls_domain_value-domvalue_l &&
                           '</status>'.
*      修饰后的节点
      DATA(l_tobe_element) = '<zstatus>' &&
                             ls_domain_value-domvalue_l &&
                             '</zstatus>'.
      REPLACE ALL OCCURRENCES OF l_as_element
          IN ch_xml_string
          WITH l_tobe_element.
    ENDLOOP.

    CLEAR ch_xml_xstring.

    CALL FUNCTION 'SCMS_STRING_TO_XSTRING'
      EXPORTING
        text   = ch_xml_string
      IMPORTING
        buffer = ch_xml_xstring
      EXCEPTIONS
        failed = 1
        OTHERS = 2.
    IF sy-subrc <> 0.
*      let it be
      EXIT.
    ENDIF.

  ENDMETHOD.


  METHOD processing_response_intl_core.
    FIELD-SYMBOLS: <fs_response>        TYPE ztrs_boc_b2e0529_response.
    DATA: ls_bank_payment_return TYPE ztrs_payment_bank_return.
    FIELD-SYMBOLS: <ft_sending_entries> TYPE ztrs_payment_check_status_tab.

    super->processing_response_intl_core( ).

    DATA(ls_response_data) = get_current_response_data( ).
    ASSIGN ls_response_data-response_ref->* TO <fs_response>.

    ASSIGN sending_data_reference->* TO <ft_sending_entries>.

    MOVE: <fs_response>-h_status-rspcod TO ls_bank_payment_return-header-bank_rtncode,
          <fs_response>-h_status-rspmsg  TO ls_bank_payment_return-header-bank_rtnmsg.
    LOOP AT <fs_response>-trans INTO DATA(ls_transaction).
      READ TABLE <ft_sending_entries> INTO DATA(ls_sending_entry)
            WITH KEY bank_tran_number = ls_transaction-obssid.
      IF sy-subrc <> 0.
*        unexpected error
        MESSAGE x091(ztr_bank_application)
                WITH function_config-bank_func
                     ls_transaction-obssid.
      ENDIF.

      APPEND VALUE ztrs_payment_bank_return_i( paymorder = ls_sending_entry-paymorder
                                               bank_msgseq = ls_transaction-msgseq
                                               DRAFT_ZPJ_NO = ls_transaction-draftno
                                               doc1r = ls_sending_entry-doc1r
                                               draft_zxh = ls_sending_entry-draft_zxh
                                               bank_rtncode = ls_transaction-rspcod
                                               bank_rtnmsg = ls_transaction-rspmsg
                                               bank_tran_number = ls_transaction-obssid
                                               BANK_RTNFLG = ls_transaction-status )
                   TO ls_bank_payment_return-items.
    ENDLOOP.

    update_status_in_instance( ls_bank_payment_return ).


  ENDMETHOD.


  METHOD ZIF_BOC_FUNCTION~RAISE_B2EERROR.
    raise_b2eerror.
    check_response_if_finished( ).
  ENDMETHOD.
ENDCLASS.
