FUNCTION ZFM_SET_FLOW.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     REFERENCE(IV_TYPE) TYPE  CHAR1
*"     REFERENCE(IV_SNRO) TYPE  NROBJ OPTIONAL
*"     REFERENCE(IV_RANGE) TYPE  CHAR2 OPTIONAL
*"  CHANGING
*"     REFERENCE(RC_DATALOG) TYPE  ANY
*"--------------------------------------------------------------------
*by yuanfeng 2017.11.16"------------------------------------------------


  FIELD-SYMBOLS: <fs_line>  TYPE any,         "结构
                 <fs_field> TYPE any.         "字段
  ASSIGN ('RC_DATALOG') TO <fs_line>.

  "创建
  IF iv_type = 'C'.

    "NR 生成
    IF iv_snro IS NOT INITIAL.
      ASSIGN COMPONENT 'BILLN' OF STRUCTURE <fs_line> TO <fs_field>.
      IF sy-subrc = 0.
        DATA(lv_number) = VALUE ztr_billn( ).

        CALL FUNCTION 'NUMBER_RANGE_ENQUEUE'
          EXPORTING
            object           = iv_snro
          EXCEPTIONS
            foreign_lock     = 1
            object_not_found = 2
            system_failure   = 3
            OTHERS           = 4.

        "是否要加锁？
        CALL FUNCTION 'NUMBER_GET_NEXT'
          EXPORTING
            nr_range_nr = iv_range
            object      = iv_snro
          IMPORTING
            number      = lv_number.

        CALL FUNCTION 'NUMBER_RANGE_DEQUEUE'
          EXPORTING
            object           = iv_snro
          EXCEPTIONS
            foreign_lock     = 1
            object_not_found = 2
            system_failure   = 3
            OTHERS           = 4.

        <fs_field> = lv_number.
      ENDIF.
    ENDIF.

    "状态初始化
    ASSIGN COMPONENT 'STATS' OF STRUCTURE <fs_line> TO <fs_field>.
    IF sy-subrc = 0.
      <fs_field>  = |10|. "单据初始化已创建
    ENDIF.
    "状态初始化
    ASSIGN COMPONENT 'STATUS' OF STRUCTURE <fs_line> TO <fs_field>.
    IF sy-subrc = 0.
      <fs_field>  = |10|. "单据初始化已创建
    ENDIF.

    ASSIGN COMPONENT 'ERNAM' OF STRUCTURE <fs_line> TO <fs_field>.
    IF sy-subrc = 0.
      <fs_field>  = sy-uname. "创建人
    ENDIF.

    ASSIGN COMPONENT 'ERDAT' OF STRUCTURE <fs_line> TO <fs_field>.
    IF sy-subrc = 0.
      <fs_field>  = sy-datum. "创建日期
    ENDIF.

    ASSIGN COMPONENT 'ERZET' OF STRUCTURE <fs_line> TO <fs_field>.
    IF sy-subrc = 0.
      <fs_field>  = sy-uzeit.  "创建时间
    ENDIF.

    ASSIGN COMPONENT 'TIMESTAMP' OF STRUCTURE <fs_line> TO <fs_field>.
    IF sy-subrc = 0.
      GET TIME STAMP FIELD <fs_field>.  "创建详细时间戳
    ENDIF.
  ENDIF.

  "审批
  IF iv_type = 'A'.
    ASSIGN COMPONENT 'ANAME' OF STRUCTURE <fs_line> TO <fs_field>.
    IF sy-subrc = 0.
      <fs_field>  = sy-uname. "审批人
    ENDIF.

    ASSIGN COMPONENT 'ADATE' OF STRUCTURE <fs_line> TO <fs_field>.
    IF sy-subrc = 0.
      <fs_field>  = sy-datum. "审批日期
    ENDIF.

    ASSIGN COMPONENT 'ATIME' OF STRUCTURE <fs_line> TO <fs_field>.
    IF sy-subrc = 0.
      <fs_field>  = sy-uzeit.  "审批时间
    ENDIF.

    ASSIGN COMPONENT 'TIMESTAMP' OF STRUCTURE <fs_line> TO <fs_field>.
    IF sy-subrc = 0.
      GET TIME STAMP FIELD <fs_field>.  "审批详细时间戳
    ENDIF.
  ENDIF.

  ASSIGN COMPONENT 'AENAM' OF STRUCTURE <fs_line> TO <fs_field>.
  IF sy-subrc = 0.
    <fs_field>  = sy-uname. "更新账号
  ENDIF.

  ASSIGN COMPONENT 'AEDAT' OF STRUCTURE <fs_line> TO <fs_field>.
  IF sy-subrc = 0.
    <fs_field>  = sy-datum. "更新日期
  ENDIF.

  ASSIGN COMPONENT 'AEZET' OF STRUCTURE <fs_line> TO <fs_field>.
  IF sy-subrc = 0.
    <fs_field>  = sy-uzeit.  "更新时间
  ENDIF.

  ASSIGN COMPONENT 'TIMESTAMP_UPD' OF STRUCTURE <fs_line> TO <fs_field>.
  IF sy-subrc = 0.
    GET TIME STAMP FIELD <fs_field>.  "更新详细时间戳
  ENDIF.





ENDFUNCTION.
