FUNCTION ZFM_TR_ZFD_AUTH_309.
**"--------------------------------------------------------------------
**"*"局部接口：
**"  IMPORTING
**"     REFERENCE(BUKRS) TYPE  BUKRS
**"     REFERENCE(ACTIVE) TYPE  ZTR_BTK_ACT
**"  EXCEPTIONS
**"      ERR
**"--------------------------------------------------------------------
*DATA lv_string TYPE string.
*
*  IF NOT  ( zcl_tr_3024_gui=>auth = abap_true OR sy-sysid = 'ERP' ).
*    sy-subrc = 0.
*    RETURN.
*  ENDIF.
*  AUTHORITY-CHECK OBJECT 'Z_TR309'
*   ID 'BUKRS' FIELD bukrs
*   ID 'ZTR_TKACT' FIELD active.
*  IF sy-subrc <> 0.
*    zcl_wd_common=>get_dom_value(
*      EXPORTING
*        im_domnam = 'ZDMTR_BTK_ACT'
*        im_domval = active
*      RECEIVING
*        ex_desc   = lv_string
*    ).
*    MESSAGE e224(ztr05) WITH lv_string RAISING err.
*  ENDIF.
*
*
*


ENDFUNCTION.
