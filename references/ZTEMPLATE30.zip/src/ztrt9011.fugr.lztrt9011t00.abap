*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZTRT9011........................................*
DATA:  BEGIN OF STATUS_ZTRT9011                      .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZTRT9011                      .
CONTROLS: TCTRL_ZTRT9011
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZTRT9011                      .
TABLES: ZTRT9011                       .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
