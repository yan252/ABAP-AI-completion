FUNCTION ZFM_TR_UPDATE_KLHPSTATUS.
**"--------------------------------------------------------------------
**"*"局部接口：
**"  IMPORTING
**"     REFERENCE(DOCNO) TYPE  ZTR_ZFDOCNO
**"--------------------------------------------------------------------
*DATA: lv_zzfstatus TYPE ztr_zfstatus,
*        lv_bukrs     TYPE bukrs,
*        lv_hpstatus  TYPE ztr_ztran_status.
**支付单状态
*  SELECT SINGLE bukrs zzfstatus  INTO (lv_bukrs,lv_zzfstatus ) FROM ztrt2001
*    WHERE docno = docno AND zbskl = 'B'.
*  CHECK sy-subrc = 0.
*  SELECT * INTO TABLE @DATA(lt_2009) FROM ztrt2009
*    WHERE docno = @docno.
*  CHECK sy-subrc = 0.
*  LOOP AT lt_2009 INTO DATA(ls_2009).
*    CLEAR lv_hpstatus.
*    CASE lv_zzfstatus.
*      WHEN '34'."票面通过（冲销后的状态）
*        lv_hpstatus = '220'."汇票支付取消过账
*      WHEN '56'."撤销申请
*        lv_hpstatus = '225'.".汇票未用退回申请
*      WHEN '57'."汇票确认退回
*        lv_hpstatus = '230'.
*      WHEN '64'."退回冲销
*        lv_hpstatus = '231'."汇票已作废
*      WHEN '16'."过账
*        lv_hpstatus = '200'."支付成功
*      WHEN OTHERS.
*    ENDCASE.
*    IF lv_hpstatus IS NOT INITIAL.
*      UPDATE ztrt0060 SET ztran_status = lv_hpstatus
*      WHERE docno_key = ls_2009-docno_key AND bukrs = lv_bukrs.
*    ENDIF.
*  ENDLOOP.
*
*
*


ENDFUNCTION.
