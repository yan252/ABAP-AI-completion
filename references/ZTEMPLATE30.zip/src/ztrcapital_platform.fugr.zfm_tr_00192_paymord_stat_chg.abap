FUNCTION ZFM_TR_00192_PAYMORD_STAT_CHG.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  IMPORTING
*"     REFERENCE(IM_DOCNO) TYPE  ZTRT2001-DOCNO
*"     REFERENCE(IM_NEW_STATUS) TYPE  ZTRT2001-ZZFSTATUS
*"     REFERENCE(IM_COMMIT_WORK) TYPE  FLAG OPTIONAL
*"  EXCEPTIONS
*"      ERROR
*"--------------------------------------------------------------------
SELECT SINGLE zywtype INTO @DATA(l_zywtype)
         FROM ztrt2001
         WHERE docno = @im_docno.
  IF sy-subrc <> 0.
    MESSAGE e197(ztr04)
            WITH im_docno
            RAISING error.
  ENDIF.

  CASE l_zywtype.
    WHEN '30' OR'40'.
*30 - 销售公司转款到工厂-汇票划转单
*40 - 销售公司转款到工厂-TT划转单
*支付单的状态变更不影响单据的信息，因此退出
      RETURN.
    WHEN '31' OR '32'.
*31 - 工厂转款到销售公司-TT划转单
*32 - 资金调拨单
      CASE im_new_status.
        WHEN '21' OR '23' OR '29'.
*         支付单作废或拒绝，需要清空单据项目中的支付单号码
          PERFORM clear_paymord USING im_docno
                                      im_commit_work.

        WHEN OTHERS.
          RETURN.
      ENDCASE.

    WHEN '50'.
      CASE im_new_status.
        WHEN '21' OR '23' OR '29'.
*         支付单作废或拒绝，需要更新单据的状态
          SELECT SINGLE a~docno INTO @DATA(lr_docno)
                FROM ztrt0097 AS a INNER JOIN ztrt2005 AS b ON a~docno = b~billn
                INNER JOIN ztrt2001 AS c ON b~docno = c~docno
                WHERE b~docno = @im_docno
                AND c~zywtype = @l_zywtype
               ." AND c~zzfstatus NOT IN ('21','23', '29','64','65' ).
          IF sy-subrc <> 0.
            UPDATE ztrt0097 SET paymorder = '' "del_ind = abap_true
            WHERE docno = lr_docno.
          ENDIF.

        WHEN OTHERS.
          RETURN.
      ENDCASE.

  ENDCASE.





ENDFUNCTION.
