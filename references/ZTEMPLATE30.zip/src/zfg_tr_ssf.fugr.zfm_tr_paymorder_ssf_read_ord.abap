FUNCTION ZFM_TR_PAYMORDER_SSF_READ_ORD.
*"--------------------------------------------------------------------
*"*"局部接口：
*"  EXPORTING
*"     REFERENCE(EX_S_PAYM_SSF) TYPE  ZTRT_PAYM_SSF
*"     REFERENCE(EX_S_2101_SSF) TYPE  ZTRT2101_SSF
*"     REFERENCE(EX_S_2001_SSF) TYPE  ZTRT2001_SSF
*"     REFERENCE(EX_S_2002_SSF) TYPE  ZTRT2002_SSF
*"     REFERENCE(EX_S_2003_SSF) TYPE  ZTRT2003_SSF
*"     REFERENCE(EX_S_2001) TYPE  ZTRT2001
*"     REFERENCE(EX_S_2101) TYPE  ZTRT2101
*"     REFERENCE(EX_S_2002) TYPE  ZTRT2002
*"     REFERENCE(EX_S_2003) TYPE  ZTRT2003
*"  EXCEPTIONS
*"      ERROR
*"--------------------------------------------------------------------
SELECT SINGLE * INTO ex_s_paym_ssf
         FROM ztrt_paym_ssf
         WHERE uname = sy-uname
         AND   datum = sy-datum.
  IF sy-subrc <> 0.
    MESSAGE e334(ztr_bank_application)
            WITH sy-uname
                 sy-datum
             RAISING error.
  ENDIF.

  IF ex_s_paym_ssf-zzftype = 'P004'.
    SELECT SINGLE * INTO ex_s_2101_ssf
           FROM ztrt2101_ssf
           WHERE uname = ex_s_paym_ssf-uname
           AND   datum = ex_s_paym_ssf-datum.
    IF sy-subrc <> 0.
      MESSAGE e335(ztr_bank_application)
              WITH ex_s_paym_ssf-uname
                   ex_s_paym_ssf-datum
               RAISING error.
    ENDIF.

    MOVE-CORRESPONDING ex_s_2101_ssf TO ex_s_2101.
  ELSE.
    SELECT SINGLE * INTO ex_s_2001_ssf
           FROM ztrt2001_ssf
           WHERE uname = ex_s_paym_ssf-uname
           AND   datum = ex_s_paym_ssf-datum.
    IF sy-subrc <> 0.
      MESSAGE e336(ztr_bank_application)
              WITH ex_s_paym_ssf-uname
                   ex_s_paym_ssf-datum
               RAISING error.
    ENDIF.

    MOVE-CORRESPONDING ex_s_2001_ssf TO ex_s_2001.
  ENDIF.

  SELECT SINGLE * INTO ex_s_2002_ssf
         FROM ztrt2002_ssf
         WHERE uname = ex_s_paym_ssf-uname
         AND   datum = ex_s_paym_ssf-datum.
  IF sy-subrc <> 0.
    MESSAGE e337(ztr_bank_application)
            WITH ex_s_paym_ssf-uname
                 ex_s_paym_ssf-datum
             RAISING error.
  ENDIF.
  MOVE-CORRESPONDING ex_s_2002_ssf TO ex_s_2002.

  SELECT SINGLE * INTO ex_s_2003_ssf
         FROM ztrt2003_ssf
         WHERE uname = ex_s_paym_ssf-uname
         AND   datum = ex_s_paym_ssf-datum.
  IF sy-subrc <> 0.
    MESSAGE e338(ztr_bank_application)
            WITH ex_s_paym_ssf-uname
                 ex_s_paym_ssf-datum
             RAISING error.
  ENDIF.
  MOVE-CORRESPONDING ex_s_2003_ssf TO ex_s_2003.





ENDFUNCTION.
