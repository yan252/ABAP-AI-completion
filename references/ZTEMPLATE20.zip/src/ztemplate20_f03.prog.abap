*&---------------------------------------------------------------------*
*&  包含                ZTRE08151_F03
*&---------------------------------------------------------------------*

FORM FRM_IMPORT_DATA .
  DATA: LT_RETU TYPE TABLE OF BAPIRET2 WITH HEADER LINE.
  DATA: LS_HEAD TYPE BAPI2017_GM_HEAD_01.
  DATA: LT_ITEM TYPE TABLE OF BAPI2017_GM_ITEM_CREATE WITH HEADER LINE.
  DATA: LV_DOCUMENT LIKE BAPI2017_GM_HEAD_RET-MAT_DOC.
  DATA: LV_DOCYEAR LIKE BAPI2017_GM_HEAD_RET-DOC_YEAR.

  DATA: LT_SELECTED_ROWS TYPE LVC_T_ROW.  " 存储选中行的索引
  DATA: LS_SELECTED_ROW  TYPE LVC_S_ROW.

* 获取选中的行索引
  CALL METHOD GO_GRID->GET_SELECTED_ROWS
    IMPORTING
      ET_INDEX_ROWS = LT_SELECTED_ROWS.

  IF LT_SELECTED_ROWS IS NOT INITIAL.
    " 遍历选中的行
    LOOP AT LT_SELECTED_ROWS INTO LS_SELECTED_ROW.
      " 通过索引获取对应的数据
      READ TABLE GT_DATA ASSIGNING <DATA> INDEX LS_SELECTED_ROW-INDEX.
      IF SY-SUBRC = 0 AND <DATA>-SQDOCNO IS INITIAL.
        " 在这里处理选中的数据
        "      WRITE: / '选中行数据:', gs_alv-field1, gs_alv-field2.
        PERFORM FRM_CHECK_DATA USING <DATA>.
        IF <DATA>-ICON  <> ICON_RED_LIGHT.
          PERFORM FRM_CREATE.
        ENDIF.
      ENDIF.
    ENDLOOP.
  ENDIF.


  MESSAGE S001(00) WITH '处理完成'.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  FRM_CREATE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM FRM_CREATE .

*
*  IF SY-SUBRC = 0.
*    LS_DATA-ICON  = ICON_GREEN_LIGHT. " ICON_RED_LIGHT. " 设置状态图标，例如绿色圆点
*    LS_DATA-MESSG = '创建成功'.
*    MOVE LS_DATA TO <DATA>.
*    COMMIT WORK.
*    PERFORM  FRM_SET_BP_EXPAND CHANGING LV_MSGTX LV_SUCC."保存后自动扩展BP
*  ELSE.
*    ROLLBACK WORK.
*    LS_DATA-ICON  = ICON_RED_LIGHT. " ICON_RED_LIGHT. " 设置状态图标，例如绿色圆点
*    LS_DATA-MESSG = '创建失败'.
*  ENDIF.


ENDFORM.
