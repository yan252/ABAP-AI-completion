*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_EXECLTOP.                     " Global Declarations
  INCLUDE LZFG_EXECLUXX.                     " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_EXECLF...                     " Subroutines
* INCLUDE LZFG_EXECLO...                     " PBO-Modules
* INCLUDE LZFG_EXECLI...                     " PAI-Modules
* INCLUDE LZFG_EXECLE...                     " Events
* INCLUDE LZFG_EXECLP...                     " Local class implement.
* INCLUDE LZFG_EXECLT99.                     " ABAP Unit tests
