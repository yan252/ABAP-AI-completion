*&*********************************************************************
*& PROGRAM NAME        : ZLME00900
*& Module Name         :
*& Apply Author        :
*& Author              :
*& Started on          :  2020-07-01
*& Transaction         : ZLME00900
*& Program type        : Report
*& Program ID          : ZLME00900
*& Program Description : 功能描述。。。。。。
*&*&*******************************************************************
*& REVISION LOG                                                       *
*&                                                                    *
*& LOG#    DATE       AUTHOR       DESCRIPTION                        *
*& ----    ----       ------       -----------                        *
*& 0001   2020-07-01  XXX     Initial Creation
*&*********************************************************************
REPORT ZTEMPLATE20.
TABLES SSCRFIELDS.
*INCLUDE ZLMN00001.

DATA: G_PATH    TYPE  LOCALFILE.
DATA: G_FORMKEY LIKE  WWWDATATAB.



TYPES: BEGIN OF TY_DATA ,
         KEY(200).
    INCLUDE STRUCTURE ZTRT9300_HEAD.
TYPES: CHECK(1),
       MESSG    TYPE MSGTX,
       ICON     TYPE ICON_D,


       SQTYPE_T TYPE CHAR20,
       SQSTAT_T TYPE CHAR20,
       SFTQSH_T TYPE CHAR20,
       TZMD_T   TYPE CHAR20,
       TZDL_T   TYPE CHAR20,
       TZXL_T   TYPE CHAR20,


       END OF TY_DATA.
DATA: GT_DATA TYPE TABLE OF TY_DATA,
      GS_DATA TYPE TY_DATA.
FIELD-SYMBOLS:<DATA> TYPE TY_DATA.

TYPES: BEGIN OF TY_DATA_I ,
         KEY(200).
    INCLUDE STRUCTURE ZTRT9300_ITEM.

TYPES: CHECK(1),
END OF TY_DATA_I.
DATA: GT_DATA_I TYPE TABLE OF TY_DATA_I,
      GS_DATA_I TYPE TY_DATA_I.
DATA: GV_ERROR(1).

"ALV对象
DATA: GT_FIELD  TYPE LVC_T_FCAT.
DATA: GS_FIELD  TYPE LVC_S_FCAT.
DATA: GS_LAYOUT TYPE LVC_S_LAYO.
DATA: GS_VARIANT TYPE DISVARIANT.
DATA: GO_GRID TYPE REF TO CL_GUI_ALV_GRID.
DATA: GT_EVENTS TYPE SLIS_T_EVENT.

DEFINE BULID_FIELDLOG.

  GS_FIELD-FIELDNAME = &1.

  GS_FIELD-REPTEXT = &2.
  GS_FIELD-COLTEXT = &2.
  GS_FIELD-SCRTEXT_L = &2.
  GS_FIELD-SCRTEXT_M = &2.
  GS_FIELD-SCRTEXT_S = &2.


  GS_FIELD-REF_TABLE  = &3.
  GS_FIELD-REF_FIELD = &4.
  GS_FIELD-EDIT = &5.
  GS_FIELD-LZERO = &6.
  GS_FIELD-NO_ZERO = &7.
  GS_FIELD-JUST = &8.
  GS_FIELD-KEY = &9.

  GS_FIELD-COL_OPT = 'X'.

  IF &1 EQ 'ZSEL'.
    GS_FIELD-CHECKBOX = 'X'.
  ENDIF.

  APPEND GS_FIELD TO GT_FIELD.
  CLEAR GS_FIELD.
END-OF-DEFINITION.

PARAMETERS: P_BUKRS TYPE ZTRT9300_HEAD-BUKRS  MEMORY ID BUK, "公司代码
            P_FILEN TYPE RLGRAP-FILENAME  MEMORY ID FLE.
SELECTION-SCREEN: FUNCTION KEY 5.

INCLUDE ZTEMPLATE20_F01.
INCLUDE ZTEMPLATE20_F02.
INCLUDE ZTEMPLATE20_F03.



INITIALIZATION.
  SSCRFIELDS-FUNCTXT_05 = TEXT-901.

AT SELECTION-SCREEN ON VALUE-REQUEST FOR P_FILEN.
  PERFORM FRM_FILE_HELP  USING P_FILEN.

*AT SELECTION-SCREEN ON P_MLINE.
*  IF P_MLINE > 330.
*    MESSAGE E001(00) WITH '最大凭证行数：330'.
*  ENDIF.

AT SELECTION-SCREEN.
  IF SSCRFIELDS-UCOMM = 'FC05'.
    "从SMW0下载模板
    PERFORM FRM_DOWN_EXCEL_TEMPLATE USING G_PATH
                                          G_FORMKEY
                                          'ZTRE08151'
                                          '\投资合同申请单批量导入模板.XLSX'.
  ENDIF.



START-OF-SELECTION.
  PERFORM FRM_CHECK.
  PERFORM FRM_UPLOAD_FILE TABLES GT_DATA
                    USING  P_FILEN
                           1
                           2
                           30.
  IF GT_DATA IS INITIAL.
    MESSAGE S001(00) WITH '上传文件中无数据' DISPLAY LIKE 'E'.
    STOP.
  ENDIF.
  PERFORM FRM_PROCESS_DATA.
  PERFORM FRM_BUILT_FIELD.
  PERFORM FRM_BUILT_LAYOUT.
  PERFORM FRM_OUTPUT_ALV.


*&---------------------------------------------------------------------*
*& Form FRM_PROCESS_DATA
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM FRM_PROCESS_DATA.
  " 对导入数据数据进行处理，转换成ALV显示的数据格式
  " 初始化一些默认数据。并检查一数据有的有效性，比如必输字段是否有值，字段值是否合法等。
  DATA:LV_DATE TYPE D.


  LOOP AT GT_DATA ASSIGNING FIELD-SYMBOL(<DATA>).
    " 设置默认值 ：TZDL=001 银行类、TZXL=0101 通知存款、 申请类型=10 银行类投资申请
    PERFORM FRM_SET_DATA_INI USING <DATA>. " 初始化数据


    <DATA>-KEY = SY-TABIX.
    PERFORM FRM_CHECK_DATA USING <DATA>.
    IF <DATA>-ICON = ICON_RED_LIGHT. " 如果检查过程中发现数据有问题，图标会被设置成红色灯，此时不进行后续处理
      CONTINUE.
    ENDIF.

*其它数据处理

  ENDLOOP.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  FRM_BUILT_LAYOUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM FRM_BUILT_LAYOUT .
  GS_LAYOUT-INFO_FNAME = 'COLOR'.
  GS_LAYOUT-ZEBRA      = 'X'.
  GS_LAYOUT-BOX_FNAME = 'CHECK'.
  GS_LAYOUT-CWIDTH_OPT = 'A'.
  GS_VARIANT = VALUE #( REPORT = SY-REPID HANDLE = '0001' ).
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  FRM_OUTPUT_ALV
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
" -----------------------------------------------------------------------
FORM FRM_OUTPUT_ALV .
  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY_LVC'
    EXPORTING
      I_CALLBACK_PROGRAM       = SY-REPID
      IT_FIELDCAT_LVC          = GT_FIELD
      IS_LAYOUT_LVC            = GS_LAYOUT
      IS_VARIANT               = GS_VARIANT
      I_CALLBACK_USER_COMMAND  = 'FRM_USER_COMMAND'
      I_CALLBACK_PF_STATUS_SET = 'FRM_PF_STATUS'
      I_SAVE                   = 'A'
      I_DEFAULT                = 'X'
    TABLES
      T_OUTTAB                 = GT_DATA.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  USER_COMMAND
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->UCOMM      text
*      -->SELFIELD   text
*----------------------------------------------------------------------*
FORM FRM_USER_COMMAND USING UCOMM LIKE SY-UCOMM
                     SELFIELD TYPE SLIS_SELFIELD.
  IF GO_GRID IS INITIAL.
    CALL FUNCTION 'GET_GLOBALS_FROM_SLVC_FULLSCR'
      IMPORTING
        E_GRID = GO_GRID.
  ENDIF.
  CALL METHOD GO_GRID->CHECK_CHANGED_DATA.

  CASE UCOMM.
    WHEN 'POST'.
      PERFORM FRM_IMPORT_DATA.
*      GS_LAYOUT-NO_TOOLBAR = 'X'.
*      CALL METHOD GO_GRID->SET_FRONTEND_LAYOUT
*        EXPORTING
*          IS_LAYOUT = GS_LAYOUT.
      CALL METHOD GO_GRID->REFRESH_TABLE_DISPLAY.
  ENDCASE.
ENDFORM.                    "USER_COMMAND
*&---------------------------------------------------------------------*
*&      Form  PF_STATUS
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM FRM_PF_STATUS USING RT_EXTAB TYPE SLIS_T_EXTAB.
  DATA: BEGIN OF LT_FCD OCCURS 0,
          FCODE LIKE SY-UCOMM,
        END OF LT_FCD.

  SET PF-STATUS 'PFSATUS' EXCLUDING LT_FCD.
  SET TITLEBAR 'TITLE01'.
ENDFORM.                    "PF_STATUS

*&---------------------------------------------------------------------*
*& Form FRM_BULIT_FIELD1
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM FRM_BUILT_FIELD.
  BULID_FIELDLOG
    'ICON' '状态' 'ICON' 'NAME' '' '' '' '' 'X'.
  BULID_FIELDLOG:
       'MESSG' '消息' '' '' '' '' '' '' 'X',
       'SQTYPE_T' '申请单类型' '' '' '' '' '' '' '',
       'SQSTAT_T' '申请状态' '' '' '' '' '' '' '',
       'SFTQSH_T' '是否会提前赎回' '' '' '' '' '' '' '',
       'TZMD_T' '投资目的' '' '' '' '' '' '' '',
       'TZDL_T' '投资大类' '' '' '' '' '' '' '',
       'TZXL_T' '投资小类' '' '' '' '' '' '' ''.

  PERFORM FRM_GET_FIELDS TABLES GT_FIELD
                         USING  'ZTRT9300_HEAD'.
  LOOP AT GT_FIELD INTO GS_FIELD.
    CASE GS_FIELD-FIELDNAME.
      WHEN 'QTSM' OR 'YJCZSX' OR 'DS_BUKRS' OR 'RANL' OR 'CSTZSQD'
          OR 'FIELD3' OR 'FIELD4' OR 'FIELD5' OR 'FIELD6'
          OR 'FIELD20' OR 'FIELD21' OR 'FIELD22' OR 'FIELD23'  OR 'FIELD24'  OR 'FIELD25'  OR 'FIELD26'
          OR 'YYSXJQCB' OR 'QTCKYE' OR 'QTCKJQLL' OR 'DKJZLL'  OR 'CKJZLL'  OR 'YHJTYZJLL'
          OR 'TZLB' OR 'FXLB_BZ' OR 'FIELD8' OR 'FIELD8_1' OR 'FIELD12' OR 'FIELD12_1' OR 'FIELD16' OR 'FIELD17' OR 'FIELD18'
          OR 'FIELD19' OR 'FIELD19_1' OR 'FIELD20' OR 'FIELD21' OR 'FIELD22' OR 'FIELD23' OR 'FIELD24'
          OR 'FIELD25' OR 'FIELD26' OR 'ZDELE' OR 'SPWC_DATE' OR 'AEDAT' OR 'AEZET' OR 'AENAM'
          OR 'SQTYPE' OR 'SQSTAT' OR 'SFTQSH' OR 'TZMD' OR 'TZDL' OR 'TZXL' .
        GS_FIELD-NO_OUT = 'X'.
      WHEN 'SQTYPE_T' OR 'SQSTAT_T' OR 'SFTQSH_T' OR 'TZMD_T' OR 'TZDL_T' OR 'TZXL_T' .
        GS_FIELD-COL_POS = 5.
    ENDCASE.
    MODIFY GT_FIELD FROM GS_FIELD.
  ENDLOOP.


*       SQSTAT_t TYPE char20,
*       SFTQSH_t TYPE char20,
*       TZDL_t TYPE char20,
*       TZXL_t TYPE char20,


ENDFORM.
*&---------------------------------------------------------------------*
*& Form FRM_SET_DATA
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> <FS>
*&---------------------------------------------------------------------*
FORM FRM_SET_DATA  USING    PS_DATA LIKE LINE OF GT_DATA PV_MESSAGE.
  MOVE-CORRESPONDING PS_DATA TO GS_DATA.
  GS_DATA-MESSG = PV_MESSAGE.
  IF PV_MESSAGE IS NOT INITIAL.
    GS_DATA-ICON = '@5C@'.
    GV_ERROR = 'X'.
  ENDIF.
*  GS_DATA-KEY = |{ GS_DATA-WERKS }/{ GS_DATA-BWART }/{ GS_DATA-BUDAT }/{ GS_DATA-BKTXT }|.
  APPEND GS_DATA TO GT_DATA.
ENDFORM.
*&---------------------------------------------------------------------*
*& Form FRM_IMPORT_DATA
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Form FRM_REFRESH_ERROR
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> LT_RETU
*&      --> LV_GRPNO
*&---------------------------------------------------------------------*
FORM FRM_REFRESH_ERROR  TABLES   PT_RETU STRUCTURE BAPIRET2
                        USING    PV_GRPNO.
*  DATA LV_MESSAGE(255).
*  LOOP AT GT_DATA ASSIGNING FIELD-SYMBOL(<LFS_DATA>) WHERE GRPNO = PV_GRPNO.
*    <LFS_DATA>-ICON = ''.
*    <LFS_DATA>-MESSG = ''.
*  ENDLOOP.
*
*  LOOP AT PT_RETU WHERE ( TYPE = 'A' OR TYPE = 'E' ) AND ROW NE '' AND PARAMETER = 'GOODSMVT_ITEM'.
*    READ TABLE GT_DATA ASSIGNING <LFS_DATA> WITH KEY GRPNO = PV_GRPNO ZINDX = PT_RETU-ROW.
*    IF SY-SUBRC = 0.
*      <LFS_DATA>-ICON = '@5C@'.
*      <LFS_DATA>-MESSG = |{ <LFS_DATA>-MESSG }[{ PT_RETU-MESSAGE }]|.
*    ENDIF.
*  ENDLOOP.
*
*  LOOP AT PT_RETU WHERE ( TYPE = 'A' OR TYPE = 'E' ) AND ROW NE ''.
*    EXIT.
*  ENDLOOP.
*  IF SY-SUBRC NE 0.
*    LOOP AT PT_RETU WHERE TYPE = 'A' OR TYPE = 'E'.
*      LV_MESSAGE = |{ LV_MESSAGE }[{ PT_RETU-MESSAGE }]|.
*    ENDLOOP.
*    LOOP AT GT_DATA ASSIGNING <LFS_DATA> WHERE GRPNO = PV_GRPNO.
*      <LFS_DATA>-ICON = '@5C@'.
*      <LFS_DATA>-MESSG = LV_MESSAGE.
*    ENDLOOP.
*  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  FRM_CHECK_AUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM FRM_CHECK .
  IF P_BUKRS IS INITIAL.
    MESSAGE S000(ZTR201) DISPLAY LIKE 'E' WITH '公司代码必须输入'.
    LEAVE LIST-PROCESSING.
  ELSEIF P_FILEN IS INITIAL.
    MESSAGE S000(ZTR201) DISPLAY LIKE 'E' WITH '上载文件必须输入并有效'.
    LEAVE LIST-PROCESSING.
  ENDIF.

  SELECT SINGLE *
    INTO @DATA(LS_T001)
    FROM T001
    WHERE BUKRS = @P_BUKRS.
  IF SY-SUBRC <> 0.
    MESSAGE S000(ZTR201) DISPLAY LIKE 'E' WITH '输入的公司无效'.
    LEAVE LIST-PROCESSING.
  ENDIF.
  AUTHORITY-CHECK OBJECT 'Z_TR456'
           ID 'BUKRS' FIELD P_BUKRS
           ID 'ZTR_ACTTZ' FIELD '10'.
  IF SY-SUBRC <> 0.
    MESSAGE S000(ZTR201) DISPLAY LIKE 'E' WITH '你没有公司' P_BUKRS '创建投资合同的权限'.
    LEAVE LIST-PROCESSING.
  ENDIF.
ENDFORM.
