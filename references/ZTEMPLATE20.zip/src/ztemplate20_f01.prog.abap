*&---------------------------------------------------------------------*
*&  包含                ZLMN00001
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  FRM_POPUP_MESSAGE
*&---------------------------------------------------------------------*
*       弹出可供选择的消息提示
*----------------------------------------------------------------------*
*      -->P_TITLE    text
*      -->P_TEXT     text
*      -->P_CANCEL   text
*      -->P_ANS      text
*----------------------------------------------------------------------*
FORM FRM_POPUP_MESSAGE  USING P_TITLE
                              P_TEXT
                              P_CANCEL
                     CHANGING P_ANS.
  CLEAR P_ANS.
  DATA LV_ANSWER(1).
  CLEAR P_ANS.
  "调用函数:  会话框确实带目标规格的处理步骤
  CALL FUNCTION 'POPUP_TO_CONFIRM_WITH_VALUE'
    EXPORTING
      DEFAULTOPTION  = 'Y'
      OBJECTVALUE    = ''
*     TEXT_AFTER     = ' '
      TEXT_BEFORE    = P_TEXT
      TITEL          = P_TITLE
*     START_COLUMN   = 25
*     START_ROW      = 6
      CANCEL_DISPLAY = P_CANCEL
    IMPORTING
      ANSWER         = LV_ANSWER
    EXCEPTIONS
      TEXT_TOO_LONG  = 1
      OTHERS         = 2.
  P_ANS = SWITCH #( LV_ANSWER WHEN 'J' THEN '1'
                              WHEN 'N' THEN '2'
                              WHEN 'A' THEN 'A'
                              ELSE '' ).
ENDFORM.                    "FRM_POPUP_MESSAGE
*&---------------------------------------------------------------------*
*& Form FRM_MESSAGE_BUILD
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> LT_RET
*&      --> P_
*&      --> P_
*&      --> P_
*&      --> P_
*&      --> LS03_EBELN1
*&---------------------------------------------------------------------*
FORM FRM_MESSAGE_BUILD  TABLES   PT_RET STRUCTURE BAPIRET2
                        USING    PV_ID
                                 PV_NO
                                 PV_TYPE
                                 PV_V1 PV_V2 PV_V3 PV_V4.
  DATA LS_RETURN TYPE BAPIRET2.
  LS_RETURN-ID = PV_ID.
  LS_RETURN-NUMBER = PV_NO.
  LS_RETURN-MESSAGE_V1 = PV_V1.
  LS_RETURN-MESSAGE_V2 = PV_V2.
  LS_RETURN-MESSAGE_V3 = PV_V3.
  LS_RETURN-MESSAGE_V4 = PV_V4.
  CALL FUNCTION 'BAPI_MESSAGE_GETDETAIL'
    EXPORTING
      ID         = LS_RETURN-ID
      NUMBER     = LS_RETURN-NUMBER
      TEXTFORMAT = 'SCR'
      MESSAGE_V1 = LS_RETURN-MESSAGE_V1
      MESSAGE_V2 = LS_RETURN-MESSAGE_V2
      MESSAGE_V3 = LS_RETURN-MESSAGE_V3
      MESSAGE_V4 = LS_RETURN-MESSAGE_V4
    IMPORTING
      MESSAGE    = LS_RETURN-MESSAGE.
  LS_RETURN-TYPE = PV_TYPE.
  APPEND LS_RETURN TO PT_RET.
ENDFORM.
FORM FRM_MESSAGE_BUILD1  TABLES   PT_RET STRUCTURE BAPIRET1
                        USING    PV_ID
                                 PV_NO
                                 PV_TYPE
                                 PV_V1 PV_V2 PV_V3 PV_V4.
  DATA LS_RETURN TYPE BAPIRET2.
  LS_RETURN-ID = PV_ID.
  LS_RETURN-NUMBER = PV_NO.
  LS_RETURN-MESSAGE_V1 = PV_V1.
  LS_RETURN-MESSAGE_V2 = PV_V2.
  LS_RETURN-MESSAGE_V3 = PV_V3.
  LS_RETURN-MESSAGE_V4 = PV_V4.
  CALL FUNCTION 'BAPI_MESSAGE_GETDETAIL'
    EXPORTING
      ID         = LS_RETURN-ID
      NUMBER     = LS_RETURN-NUMBER
      TEXTFORMAT = 'SCR'
      MESSAGE_V1 = LS_RETURN-MESSAGE_V1
      MESSAGE_V2 = LS_RETURN-MESSAGE_V2
      MESSAGE_V3 = LS_RETURN-MESSAGE_V3
      MESSAGE_V4 = LS_RETURN-MESSAGE_V4
    IMPORTING
      MESSAGE    = LS_RETURN-MESSAGE.
  LS_RETURN-TYPE = PV_TYPE.
  APPEND LS_RETURN TO PT_RET.
ENDFORM.
*&---------------------------------------------------------------------*
*& Form FRM_DISPLAY_MESSAGE
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> T_RETURN
*&---------------------------------------------------------------------*
FORM FRM_DISPLAY_MESSAGE  TABLES   PT_RETURN STRUCTURE BAPIRET2.
  DATA LT_LOG TYPE TABLE OF ESP1_MESSAGE_WA_TYPE WITH HEADER LINE.
  REFRESH LT_LOG.
  LOOP AT PT_RETURN INTO DATA(LS_MSG).
    LT_LOG[] = VALUE #( BASE LT_LOG[]
                      ( MSGID = LS_MSG-ID
                        MSGTY = LS_MSG-TYPE
                        MSGNO = LS_MSG-NUMBER
                        MSGV1 = LS_MSG-MESSAGE_V1
                        MSGV2 = LS_MSG-MESSAGE_V2
                        MSGV3 = LS_MSG-MESSAGE_V3
                        MSGV4 = LS_MSG-MESSAGE_V4
                      ) ).
  ENDLOOP.
  CALL FUNCTION 'C14Z_MESSAGES_SHOW_AS_POPUP'
    TABLES
      I_MESSAGE_TAB = LT_LOG[].
ENDFORM.
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_G_PATH  text
*      -->P_G_FORMKEY  text
*      -->P_0057   text
*----------------------------------------------------------------------*
FORM FRM_DOWN_EXCEL_TEMPLATE  USING    L_PATH     TYPE LOCALFILE
                                        L_FORMKEY  LIKE WWWDATATAB
                                        L_FILE     TYPE CHAR20
                                        L_NAME     TYPE CHAR40.
  PERFORM FRM_SEARCH_HELP_PATH CHANGING L_PATH.
  CONCATENATE 'MI' L_FILE INTO L_FORMKEY.
  CONCATENATE L_PATH L_NAME INTO L_PATH.
  CALL FUNCTION 'DOWNLOAD_WEB_OBJECT'
    EXPORTING
      KEY         = L_FORMKEY
      DESTINATION = L_PATH
    CHANGING
      TEMP        = L_PATH.
ENDFORM.                    " DOWN_EXCEL_TEMPLATE
*&---------------------------------------------------------------------*
*&      Form  FILE_HELP
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_P_FNAME  text
*----------------------------------------------------------------------*
FORM FRM_FILE_HELP  USING    L_FNAME LIKE RLGRAP-FILENAME.
  CALL FUNCTION 'WS_FILENAME_GET'
    EXPORTING
      MASK             = ' Excel Files (*.xls;*.xlsx)|*.xls;*.xlsx|All Files (*.*)|*.*|'(101)
      TITLE            = '选择文件'(100)
    IMPORTING
      FILENAME         = L_FNAME
    EXCEPTIONS
      INV_WINSYS       = 1
      NO_BATCH         = 2
      SELECTION_CANCEL = 3
      SELECTION_ERROR  = 4
      OTHERS           = 5.
  IF SY-SUBRC <> 0 AND SY-SUBRC <> 3.
    MESSAGE 'SELECT FILE ERROR！' TYPE 'E'.
  ENDIF.
ENDFORM.                    " FILE_HELP
*&---------------------------------------------------------------------*
*&      Form  SEARCH_HELP_PATH
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      <--P_L_PATH  text
*----------------------------------------------------------------------*
FORM FRM_SEARCH_HELP_PATH  CHANGING P_PATH.
  DATA: LW_PATH TYPE STRING .
  CALL METHOD CL_GUI_FRONTEND_SERVICES=>DIRECTORY_BROWSE
    EXPORTING
      WINDOW_TITLE         = '选择文件目录'
*     initial_folder       = 'C:\TEMP'
    CHANGING
      SELECTED_FOLDER      = LW_PATH
    EXCEPTIONS
      CNTL_ERROR           = 1
      ERROR_NO_GUI         = 2
      NOT_SUPPORTED_BY_GUI = 3
      OTHERS               = 4.
  IF SY-SUBRC <> 0.
    MESSAGE ID SY-MSGID TYPE SY-MSGTY NUMBER SY-MSGNO
               WITH SY-MSGV1 SY-MSGV2 SY-MSGV3 SY-MSGV4.
  ENDIF.
  P_PATH = LW_PATH .
ENDFORM.                    " SEARCH_HELP_PATH
*&---------------------------------------------------------------------*
*&      Form  UPLOAD_FILE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_P_FNAME  text
*----------------------------------------------------------------------*
FORM FRM_UPLOAD_FILE
  TABLES P_TAB  TYPE STANDARD TABLE
  USING  P_FILE TYPE RLGRAP-FILENAME
         NUM1   TYPE I
         NUM2   TYPE I
         NUM3   TYPE I.

  " TODO: variable is assigned but never used (ABAP cleaner)
*  FIELD-SYMBOLS <FT_TAB> TYPE STANDARD TABLE.

  DATA L_MESS    TYPE C LENGTH 30.
  DATA LC_INTERN TYPE ZALSMEX_TABLINE OCCURS 0 WITH HEADER LINE.
  TYPES:
    BEGIN OF TY_TABLINE,
      ROW   TYPE NUMC10,
      COL   TYPE KCD_EX_COL_N,
      VALUE TYPE CHAR1024,
    END OF TY_TABLINE.

  DATA LS_EXCEL    TYPE TY_TABLINE.
  DATA LS_TEMPL    TYPE ZALSMEX_TABLINE.
  DATA LT_EXCEL    TYPE TABLE OF TY_TABLINE.
  DATA LT_TITLE    TYPE TABLE OF TY_TABLINE.
  DATA L_FIELDNAME TYPE FIELDNAME.
  " TODO: variable is assigned but never used (ABAP cleaner)
  " DATA L_COL_COUNT TYPE I.
  " TODO: variable is assigned but never used (ABAP cleaner)
*  DATA TR_TABLE    TYPE REF TO CL_ABAP_TABLEDESCR.
*  DATA TR_STRUCT   TYPE REF TO CL_ABAP_STRUCTDESCR.
*  DATA FS_TABLE    TYPE REF TO DATA.
*  DATA FS_STRUCT   TYPE REF TO DATA.
*  DATA TD_COMP     TYPE CL_ABAP_STRUCTDESCR=>COMPONENT_TABLE.
*  FIELD-SYMBOLS <FS_TABLE>  TYPE STANDARD TABLE.
  " TODO: variable is assigned but never used (ABAP cleaner)
*  FIELD-SYMBOLS <FS_STRUCT> TYPE ANY.
  FIELD-SYMBOLS <FIELD> TYPE ANY.


  CALL FUNCTION 'ZFM_EXCEL_TO_INTERNAL_TABLE2'
    EXPORTING
      FILENAME                = P_FILE
      I_BEGIN_COL             = NUM1
      I_BEGIN_ROW             = NUM2
      I_END_COL               = NUM3
      I_END_ROW               = 9999
    TABLES
      INTERN                  = LC_INTERN
    EXCEPTIONS
      INCONSISTENT_PARAMETERS = 1
      UPLOAD_OLE              = 2
      OTHERS                  = 3.
  IF SY-SUBRC <> 0.
    CONCATENATE '文件' P_FILE '导入错误，请检查!' INTO L_MESS.
    MESSAGE L_MESS TYPE 'S' DISPLAY LIKE 'E'.
    LEAVE LIST-PROCESSING.
  ENDIF.

  " 提取抬头标识字段...
  LOOP AT LC_INTERN INTO LS_TEMPL.
    CLEAR LS_EXCEL.
    IF LS_TEMPL-ROW = '0001'.
      MOVE-CORRESPONDING LS_TEMPL TO LS_EXCEL.
      APPEND LS_EXCEL TO LT_TITLE.
    ELSE.
      MOVE-CORRESPONDING LS_TEMPL TO LS_EXCEL.
      APPEND LS_EXCEL TO LT_EXCEL.
    ENDIF.
  ENDLOOP.
  IF LT_EXCEL IS INITIAL.
    RETURN.
  ENDIF.
  SORT LT_EXCEL BY ROW
                   COL.
  LOOP AT LT_EXCEL INTO LS_EXCEL.
    DATA(LV_ROW) = SY-TABIX.

    AT NEW ROW.
      APPEND INITIAL LINE TO GT_DATA ASSIGNING FIELD-SYMBOL(<DATA>).
    ENDAT.
    READ TABLE LT_TITLE INTO DATA(LS_TITLE)
         WITH KEY COL = LS_EXCEL-COL.
    IF SY-SUBRC <> 0.
      CONTINUE.
    ELSE.
      L_FIELDNAME = LS_TITLE-VALUE.
      CONDENSE L_FIELDNAME.
    ENDIF.

    ASSIGN COMPONENT L_FIELDNAME OF STRUCTURE <DATA> TO <FIELD>.
    IF SY-SUBRC <> 0.
      CONTINUE.
    ENDIF.
    <FIELD> = LS_EXCEL-VALUE.

    AT END OF ROW.


    ENDAT.
  ENDLOOP.
ENDFORM.
*&---------------------------------------------------------------------*
*& Form FRM_CHECK_DATE
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> <FS>_BUDAT
*&      <-- LV_INVALID
*&---------------------------------------------------------------------*
FORM FRM_CHECK_DATE  USING    PV_DATE
                     CHANGING PV_INVALID.
  CLEAR PV_INVALID.
  CALL FUNCTION 'RP_CHECK_DATE'
    EXPORTING
      DATE         = PV_DATE
    EXCEPTIONS
      DATE_INVALID = 1
      OTHERS       = 2.
  IF SY-SUBRC <> 0.
    PV_INVALID = 'X'.
  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*& Form FRM_CONVERT_ALPHA
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> <FS>_KUNNR
*&---------------------------------------------------------------------*
FORM FRM_CONVERT_ALPHA  USING    PR_DATA.
  CHECK PR_DATA IS NOT INITIAL.
  CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
    EXPORTING
      INPUT  = PR_DATA
    IMPORTING
      OUTPUT = PR_DATA.
ENDFORM.
*&---------------------------------------------------------------------*
*& Form FRM_CONVERT_MATNR
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> <FS>_MATNR
*&---------------------------------------------------------------------*
FORM FRM_CONVERT_MATNR  USING    PV_MATNR.
  CHECK PV_MATNR IS NOT INITIAL.
  CALL FUNCTION 'CONVERSION_EXIT_MATN1_INPUT'
    EXPORTING
      INPUT        = PV_MATNR
    IMPORTING
      OUTPUT       = PV_MATNR
    EXCEPTIONS
      LENGTH_ERROR = 1
      OTHERS       = 2.
ENDFORM.
*&---------------------------------------------------------------------*
*& Form FRM_CONVERT_MATNR
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> <FS>_MATNR
*&---------------------------------------------------------------------*
FORM FRM_CONVERT_LENUM  USING    PV_LENUM.
  CHECK PV_LENUM IS NOT INITIAL.
  CALL FUNCTION 'CONVERSION_EXIT_LENUM_INPUT'
    EXPORTING
      INPUT           = PV_LENUM
    IMPORTING
      OUTPUT          = PV_LENUM
    EXCEPTIONS
      CHECK_FAILED    = 1
      NOT_NUMERIC     = 2
      T344_GET_FAILED = 3
      WRONG_LENGTH    = 4
      OTHERS          = 5.
ENDFORM.
*&-------------------------------------------------------------*
*& Form FRM_GET_FIELDS
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> LT_FIELDS
*&      --> GT_FIELD
*&      --> P_
*&---------------------------------------------------------------------*
FORM FRM_GET_FIELDS  TABLES   PT_FIELD STRUCTURE LVC_S_FCAT
USING    PV_NAME.
  DATA LT_FIELDS LIKE TABLE OF DFIES WITH HEADER LINE.
  CALL FUNCTION 'DDIF_FIELDINFO_GET'
    EXPORTING
      TABNAME        = PV_NAME
    TABLES
      DFIES_TAB      = LT_FIELDS
    EXCEPTIONS
      NOT_FOUND      = 1
      INTERNAL_ERROR = 2
      OTHERS         = 3.
  CALL FUNCTION 'LVC_FIELDCATALOG_MERGE'
    EXPORTING
*     I_BUFFER_ACTIVE        =
      I_STRUCTURE_NAME       = PV_NAME
      I_CLIENT_NEVER_DISPLAY = 'X'
      I_BYPASSING_BUFFER     = 'X'
*     I_INTERNAL_TABNAME     =
    CHANGING
      CT_FIELDCAT            = PT_FIELD[]
    EXCEPTIONS
      INCONSISTENT_INTERFACE = 1
      PROGRAM_ERROR          = 2
      OTHERS                 = 3.
  LOOP AT PT_FIELD INTO DATA(LS_FIELD).
    DATA(LV_LEN) = STRLEN( LS_FIELD-FIELDNAME ) - 4.
    IF LV_LEN > 0.
      IF LS_FIELD-FIELDNAME+LV_LEN(4) = '_TXT'.
        READ TABLE PT_FIELD INTO DATA(ZS_FIELD) WITH KEY FIELDNAME = LS_FIELD-FIELDNAME(LV_LEN).
        IF SY-SUBRC NE 0.
          DELETE PT_FIELD.
          CONTINUE.
        ENDIF.
      ENDIF.
    ENDIF.
    IF LS_FIELD-REPTEXT = ''.
      READ TABLE LT_FIELDS WITH KEY FIELDNAME = LS_FIELD-FIELDNAME.
      IF SY-SUBRC = 0.
        LS_FIELD-REPTEXT = LT_FIELDS-FIELDTEXT.
        LS_FIELD-SCRTEXT_L = LT_FIELDS-FIELDTEXT.
        LS_FIELD-SCRTEXT_M = LT_FIELDS-FIELDTEXT.
        LS_FIELD-SCRTEXT_S = LT_FIELDS-FIELDTEXT.
      ENDIF.
    ENDIF.
    MODIFY PT_FIELD FROM LS_FIELD.
  ENDLOOP.
ENDFORM.
*&---------------------------------------------------------------------*
*& Form FRM_CONVERT_UNIT
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> <FS>_MEINS
*&---------------------------------------------------------------------*
FORM FRM_CONVERT_UNIT  USING    PV_MEINS.
  CHECK PV_MEINS IS NOT INITIAL.
  CALL FUNCTION 'CONVERSION_EXIT_CUNIT_INPUT'
    EXPORTING
      INPUT          = PV_MEINS
    IMPORTING
      OUTPUT         = PV_MEINS
    EXCEPTIONS
      UNIT_NOT_FOUND = 1
      OTHERS         = 2.
ENDFORM.
*&---------------------------------------------------------------------*
*& Form FRM_GET_PRCTR
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> LT_PRCTR
*&      --> LV_KHINR
*&---------------------------------------------------------------------*
FORM FRM_GET_PRCTR TABLES PT_PRCTR STRUCTURE CEPC
                     USING PV_KHINR.

  CHECK PV_KHINR IS NOT INITIAL.
  CLEAR: PT_PRCTR[], PT_PRCTR.
  SELECT *
    INTO CORRESPONDING FIELDS OF TABLE PT_PRCTR
    FROM CEPC
  WHERE KHINR = PV_KHINR.
ENDFORM.
*&---------------------------------------------------------------------*
*& Form FRM_GET_PRCTR_GROUP
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> LT_PRCTR
*&      --> LV_KHINR
*&---------------------------------------------------------------------*
FORM FRM_GET_SUB USING P_TAB TYPE CL_ABAP_STRUCTDESCR=>COMPONENT_TABLE CHANGING P_ALL TYPE CL_ABAP_STRUCTDESCR=>COMPONENT_TABLE.
  LOOP AT P_TAB INTO DATA(L_ROW).
    DATA:TR_STRUCT_CAST TYPE REF TO CL_ABAP_STRUCTDESCR,
         TD_INNER       TYPE CL_ABAP_STRUCTDESCR=>COMPONENT_TABLE.
    IF L_ROW-AS_INCLUDE EQ 'X'.
      TR_STRUCT_CAST ?= L_ROW-TYPE.
      TD_INNER = TR_STRUCT_CAST->GET_COMPONENTS( ).
      PERFORM FRM_GET_SUB USING TD_INNER CHANGING P_ALL."recursive
    ELSE.
      APPEND L_ROW TO P_ALL.
    ENDIF.
  ENDLOOP.
ENDFORM.

FORM FRM_CHECK_DATA USING PS_DATA TYPE TY_DATA.
*
*
*  IF PS_DATA-SQTYPE IS INITIAL.
*    PS_DATA-ICON  = ICON_RED_LIGHT. " 设置状态图标，例如绿色圆点
*    PS_DATA-MESSG = '申请类型不能为空'.
*    RETURN.
*  ENDIF.



ENDFORM.

FORM FRM_SET_DATA_INI USING PS_DATA TYPE TY_DATA.



ENDFORM.
