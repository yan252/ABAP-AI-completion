@EndUserText.label: '配送单明细'
@Metadata.allowExtensions:true

@UI.createHidden: true  // 强制隐藏
define view entity ZI_Delivery_I
  as select from zpot_delv_i as _item

  association        to parent ZI_Delivery_H            as _Header
    on $projection.DelvNo = _Header.DelvNo

  association [0..1] to        I_Material               as _Material
    on $projection.Matnr = _Material.Material
  association [0..1] to I_MaterialText as _MaterialText on $projection.Matnr = _MaterialText.Material
                and _MaterialText.Language = $session.system_language

  
  association [0..1] to        R_PurchasingDocumentItem as _PurchasingDocumentItem
    on  $projection.Ebeln = _PurchasingDocumentItem.PurchasingDocument
    and $projection.Ebelp = _PurchasingDocumentItem.PurchasingDocumentItem

  association [0..1] to        I_UnitOfMeasure          as _UnitOfMeasure
    on $projection.Meins = _UnitOfMeasure.UnitOfMeasure

{

@UI.facet: [
  {
    label: '{@i18n>@SalesArea}',
    targetQualifier: 'OrgData',
    type: #FIELDGROUP_REFERENCE,
    purpose: #HEADER
  } ]
  
  
  key _item.delv_no                         as DelvNo,
  key _item.item_no                         as ItemNo,

      _item.ebeln                           as Ebeln,
      _item.ebelp                           as Ebelp,
      @ObjectModel.text.association: '_MaterialText'
      @Consumption.valueHelpDefinition: [ { entity: { name: 'I_MaterialVH', element: 'Material' } } ]
      _item.matnr                           as Matnr,
      @Semantics.quantity.unitOfMeasure: 'Meins'
      _item.delv_qty                        as DelvQty,

      @Semantics.quantity.unitOfMeasure: 'Meins'
      _PurchasingDocumentItem.OrderQuantity as OrderQuantity,

      _item.meins                           as Meins,
     @Semantics.quantity.unitOfMeasure: 'Meins'
     _item.delv_qty                        as RadialIntegerValue,//用于显示进度的圆形图表
//计算进度百分比（0-100） */
      cast( case when _PurchasingDocumentItem.OrderQuantity = 0 then 0
           else cast( _item.delv_qty * 100 as abap.dec(5,0) ) / _PurchasingDocumentItem.OrderQuantity
      end as abap.dec( 8, 0 ) ) as DeliveryPercent,
      // 关键性（根据进度值）
      case when _item.delv_qty > _PurchasingDocumentItem.OrderQuantity then 1//红色
           when _item.delv_qty = _PurchasingDocumentItem.OrderQuantity then 3//绿色
           else 0
      end as ProgressCriticality,

      _Header,
      _Material,
      _PurchasingDocumentItem,
      _UnitOfMeasure,
      _MaterialText
}
