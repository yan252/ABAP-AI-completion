@AccessControl.authorizationCheck: #NOT_REQUIRED

@EndUserText.label: '供应商配送单维护明细'

@Metadata.allowExtensions: true
@Metadata.ignorePropagatedAnnotations: true
@ObjectModel.usageType:{
    serviceQuality: #X,
    sizeCategory: #S,
    dataClass: #MIXED
}
define view entity ZC_DELIVERY_I
  as projection on ZI_Delivery_I

{
  key DelvNo,
  key ItemNo,

      Ebeln,
      Ebelp,
      Matnr,

      @Semantics.quantity.unitOfMeasure: 'Meins'
      DelvQty,

      @Semantics.quantity.unitOfMeasure: 'Meins'
      RadialIntegerValue, // 用于显示进度的圆形图表

      @Semantics.quantity.unitOfMeasure: 'Meins'
      OrderQuantity,

      Meins,
      DeliveryPercent,
      ProgressCriticality,
      /* Associations */
      _Header: redirected to parent ZC_DELIVERY_H,

      _Material,
      _MaterialText,
      _PurchasingDocumentItem,
      _UnitOfMeasure
}
