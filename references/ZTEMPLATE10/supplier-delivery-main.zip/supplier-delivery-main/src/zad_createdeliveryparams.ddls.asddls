@EndUserText.label: '创建配送单参数'
define abstract entity ZAD_CreateDeliveryParams
{
 key DeliveryPerson : abap.char(40);
  Phone          : abap.char(20);
  ExpectedDate   : abap.dats;
  ExpectedTime   : abap.tims;
  @UI.hidden: true
  SelectedItemsJson : abap.string;
}

