
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: '供应商配送单状态帮助'
@VDM.viewType: #BASIC
@ObjectModel.usageType.serviceQuality: #C
@ObjectModel.usageType.sizeCategory: #L
@ObjectModel.resultSet.sizeCategory: #XS
@ObjectModel.usageType.dataClass: #TRANSACTIONAL
@ObjectModel.semanticKey:['Status']
@ObjectModel.representativeKey: 'Status'
@Search.searchable: true
@Consumption.ranked: true
@ObjectModel.dataCategory:#VALUE_HELP

define view entity ZI_DELIVERY_STATUS_VH 
as select from dd07t
  association [0..1] to I_Language  as _Language  on $projection.Language = _Language.Language
{
      @ObjectModel.foreignKey.association: '_Language'
      @Semantics.language: true
  key cast( dd07t.ddlanguage as spras preserving type )                      as Language, 
      @ObjectModel.text.element: ['StatusText']
  key cast(dd07t.domvalue_l  as zdelv_status )                 as Status, 
  

      @Consumption.hidden: true
      dd07t.domvalue_l                                                       as DomainValue,
      @Search.defaultSearchElement: true
      @Search.fuzzinessThreshold: 0.8
      @Search.ranking: #HIGH
      @Semantics.text: true
      cast( dd07t.ddtext as val_text preserving type )                       as StatusText,
      _Language
  
}
where
      dd07t.domname  = 'ZDDELV_STATUS'
  and dd07t.as4local = 'A'
  and dd07t.as4vers  = '0000'
  and dd07t.ddlanguage = $session.system_language
