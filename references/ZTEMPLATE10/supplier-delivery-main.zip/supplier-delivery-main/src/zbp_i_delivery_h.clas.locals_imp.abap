CLASS lhc_DeliveryHeader DEFINITION INHERITING FROM CL_ABAP_BEHAVIOR_HANDLER.
  PRIVATE SECTION.

    METHODS GET_INSTANCE_FEATURES FOR INSTANCE FEATURES
      IMPORTING KEYS REQUEST REQUESTED_FEATURES FOR DeliveryHeader RESULT RESULT.

    METHODS GET_INSTANCE_AUTHORIZATIONS FOR INSTANCE AUTHORIZATION
      IMPORTING KEYS REQUEST REQUESTED_AUTHORIZATIONS FOR DeliveryHeader RESULT RESULT.

    METHODS APPROVE FOR MODIFY
      IMPORTING KEYS FOR ACTION DeliveryHeader~APPROVE RESULT RESULT.

    METHODS cancelApproval FOR MODIFY
      IMPORTING KEYS FOR ACTION DeliveryHeader~cancelApproval RESULT RESULT.

    METHODS confirmDelivery FOR MODIFY
      IMPORTING KEYS FOR ACTION DeliveryHeader~confirmDelivery RESULT RESULT.

    METHODS PRINT FOR MODIFY
      IMPORTING KEYS FOR ACTION DeliveryHeader~PRINT.

    METHODS softDelete FOR MODIFY
      IMPORTING KEYS FOR ACTION DeliveryHeader~softDelete RESULT RESULT.

    METHODS ValidateEDate FOR VALIDATE ON SAVE
      IMPORTING KEYS FOR DeliveryHeader~ValidateEDate.

ENDCLASS.
CLASS lhc_DeliveryHeader IMPLEMENTATION.
  METHOD GET_INSTANCE_FEATURES.
    READ ENTITIES OF ZI_Delivery_H IN LOCAL MODE
         ENTITY DeliveryHeader
         FIELDS ( DelvNo Status )    " 需要的业务字段
         WITH CORRESPONDING #( KEYS )
         RESULT DATA(LT_HEADER)
         FAILED FAILED.

    RESULT = VALUE #( FOR LS_HEADER IN LT_HEADER
                      ( %KEY                              = LS_HEADER-%KEY
                        %IS_DRAFT                         = LS_HEADER-%IS_DRAFT
                        %FEATURES-%UPDATE                 = COND #( WHEN LS_HEADER-Status = '10'
                                                                    THEN IF_ABAP_BEHV=>FC-O-ENABLED
                                                                    ELSE IF_ABAP_BEHV=>FC-O-DISABLED )
                        %FEATURES-%ACTION-EDIT         = COND #( WHEN LS_HEADER-Status = '10'
                                                                    THEN IF_ABAP_BEHV=>FC-O-ENABLED
                                                                    ELSE IF_ABAP_BEHV=>FC-O-DISABLED )
                        %FEATURES-%ACTION-APPROVE         = COND #( WHEN LS_HEADER-Status = '10'
                                                                    THEN IF_ABAP_BEHV=>FC-O-ENABLED
                                                                    ELSE IF_ABAP_BEHV=>FC-O-DISABLED )
                        %FEATURES-%ACTION-cancelApproval  = COND #( WHEN LS_HEADER-Status = '20'
                                                                    THEN IF_ABAP_BEHV=>FC-O-ENABLED
                                                                    ELSE IF_ABAP_BEHV=>FC-O-DISABLED )
                        %FEATURES-%ACTION-confirmDelivery = COND #( WHEN LS_HEADER-Status = '20'
                                                                    THEN IF_ABAP_BEHV=>FC-O-ENABLED
                                                                    ELSE IF_ABAP_BEHV=>FC-O-DISABLED )
                        %FEATURES-%ACTION-softDelete      = COND #( WHEN LS_HEADER-Status = '10'
                                                                    THEN IF_ABAP_BEHV=>FC-O-ENABLED
                                                                    ELSE IF_ABAP_BEHV=>FC-O-DISABLED )
                        %FEATURES-%ASSOC-_ITEM            = COND #( WHEN LS_HEADER-Status = '10'
                                                                    THEN IF_ABAP_BEHV=>FC-f-UNRESTRICTED
                                                                    ELSE IF_ABAP_BEHV=>FC-f-READ_ONLY ) ) ).
  ENDMETHOD.

  METHOD GET_INSTANCE_AUTHORIZATIONS.
  ENDMETHOD.



  METHOD cancelApproval.
    READ ENTITIES OF ZI_Delivery_H IN LOCAL MODE
         ENTITY DeliveryHeader
         FIELDS ( DelvNo Status )
         WITH CORRESPONDING #( KEYS )
         RESULT DATA(LT_HEADER)
         FAILED FAILED
         REPORTED REPORTED.

    " 收集需要取消审批（状态为 '20'）的实体实例
    DATA LT_UPDATE TYPE TABLE FOR UPDATE ZI_Delivery_H.
    DATA Ls_UPDATE LIKE LINE OF LT_UPDATE.

    LOOP AT LT_HEADER INTO DATA(LS_HEADER) WHERE STATUS = '20'.
      " 准备更新请求：将状态改为 '10'（未审批）
      MOVE-CORRESPONDING LS_HEADER TO LS_UPDATE.
      LS_UPDATE-STATUS = '10'.
      APPEND LS_UPDATE TO LT_UPDATE.

    ENDLOOP.

    " 执行更新
    IF LT_UPDATE IS NOT INITIAL.
      MODIFY ENTITIES OF ZI_Delivery_H IN LOCAL MODE
             ENTITY DeliveryHeader
             UPDATE FIELDS ( STATUS )
             WITH LT_UPDATE
             FAILED DATA(LT_MOD_FAILED)
             REPORTED DATA(LT_MOD_REPORTED).
      FAILED = CORRESPONDING #( BASE ( FAILED ) LT_MOD_FAILED ).
      REPORTED = CORRESPONDING #( BASE ( REPORTED ) LT_MOD_REPORTED ).
    ENDIF.

    " ---------- 正确填充 RESULT ----------
    DATA LT_SUCCESS_KEYS TYPE STANDARD TABLE OF ZI_Delivery_H WITH EMPTY KEY.
    LOOP AT LT_UPDATE INTO LS_UPDATE.
      IF NOT LINE_EXISTS( LT_MOD_FAILED-DELIVERYHEADER[ %KEY = LS_UPDATE-%KEY  ] ).
        APPEND INITIAL LINE TO LT_SUCCESS_KEYS ASSIGNING FIELD-SYMBOL(<FS_KEY>).
        <FS_KEY>-DELVNO = LS_UPDATE-DELVNO.
      ENDIF.
    ENDLOOP.

    IF LT_SUCCESS_KEYS IS NOT INITIAL.
      READ ENTITIES OF ZI_Delivery_H IN LOCAL MODE
           ENTITY DeliveryHeader
           ALL FIELDS
           WITH CORRESPONDING #( LT_SUCCESS_KEYS )
           RESULT DATA(LT_FINAL)
           FAILED FAILED
           REPORTED REPORTED.

      " 将纯实体数据赋值给 RESULT 的 %PARAM 字段
      LOOP AT LT_FINAL INTO DATA(LS_ENTITY).
        APPEND INITIAL LINE TO RESULT ASSIGNING FIELD-SYMBOL(<FS_RESULT>).
        MOVE-CORRESPONDING LS_ENTITY TO <FS_RESULT>-%PARAM.
        <FS_RESULT>-%KEY = LS_ENTITY-%KEY.
      ENDLOOP.

    ENDIF.
  ENDMETHOD.

  METHOD confirmDelivery.

    READ ENTITIES OF ZI_Delivery_H IN LOCAL MODE
         ENTITY DeliveryHeader
         FIELDS ( DelvNo Status )    " 需要的业务字段
         WITH CORRESPONDING #( KEYS )
         RESULT DATA(LT_HEADER)
         FAILED FAILED.

    LOOP AT LT_HEADER INTO DATA(Ls_HEADER).
      " 检查是否可取消审批：例如状态 = '20
      IF Ls_HEADER-Status = '20'.
        UPDATE ZPOT_DELV_H
          SET Status = '30'
          WHERE DELV_NO = Ls_HEADER-DelvNo.
      ELSE.
        " 记录失败行到 reported 但不加入 failed？或者加入 failed 但不报错？
        " 为了不弹错误框，可以将失败行信息放入 reported 但不放入 failed，这样前端会在成功消息中显示附加信息
        APPEND VALUE #( %MSG = NEW_MESSAGE( ID       = '00'
                                            NUMBER   = '001'
                                            SEVERITY = IF_ABAP_BEHV_MESSAGE=>SEVERITY-INFORMATION
                                            V1       = '配送单状态不为20，不能发货 ：'
                                            V2       = Ls_HEADER-DelvNo ) )
               TO REPORTED-DeliveryHeader.
      ENDIF.
    ENDLOOP.

  ENDMETHOD.

  METHOD PRINT.
   "调用SMARTFORMS 打印

  ENDMETHOD.

  METHOD softDelete.

    READ ENTITIES OF ZI_Delivery_H IN LOCAL MODE
         ENTITY DeliveryHeader
         FIELDS ( DelvNo Status )    " 需要的业务字段
         WITH CORRESPONDING #( KEYS )
         RESULT DATA(LT_HEADER)
         FAILED FAILED.

    LOOP AT LT_HEADER INTO DATA(Ls_HEADER).
      " 检查是否可审批：例如状态 = '10
      IF Ls_HEADER-Status = '10'.
        UPDATE ZPOT_DELV_H
          SET Status = '90'
          WHERE DELV_NO = Ls_HEADER-DelvNo.
      ELSE.
        " 记录失败行到 reported 但不加入 failed？或者加入 failed 但不报错？
        " 为了不弹错误框，可以将失败行信息放入 reported 但不放入 failed，这样前端会在成功消息中显示附加信息
        APPEND VALUE #( %MSG = NEW_MESSAGE( ID       = '00'
                                            NUMBER   = '001'
                                            SEVERITY = IF_ABAP_BEHV_MESSAGE=>SEVERITY-INFORMATION
                                            V1       = '配送单状态不为10，不能删除标记 ：'
                                            V2       = Ls_HEADER-DelvNo ) )
               TO REPORTED-DeliveryHeader.
      ENDIF.
    ENDLOOP.

  ENDMETHOD.

  METHOD ValidateEDate.

    READ ENTITIES OF ZI_Delivery_H IN LOCAL MODE
         ENTITY DeliveryHeader
         ALL FIELDS    " 需要的业务字段
         WITH CORRESPONDING #( KEYS )
         RESULT DATA(LT_HEADER).

  DATA(today) = cl_abap_context_info=>get_system_date( ).
"理论上这里只会有一行
  LOOP AT LT_HEADER INTO DATA(Ls_HEADER).
    " 1. 清除该实例在 'VALIDATE_EDATE' 区域的所有旧状态消息
    "    这一步是每次必执行的，用于清除任何残留的旧消息。
    APPEND VALUE #( %tky = ls_header-%tky
                    %state_area = 'VALIDATE_EDATE' )      " 只带区域，不带消息
      TO reported-deliveryheader.
    IF Ls_HEADER-ExpectedDate < today.

      " 将不合规实例放入 failed，阻止保存
      APPEND VALUE #( %tky = Ls_HEADER-%tky ) TO failed-DeliveryHeader.

      " 生成错误消息，并标记字段
      APPEND VALUE #(
          %tky        = Ls_HEADER-%tky
          %state_area = 'VALIDATE_EDATE'
          %msg        = new_message(
              id       = '00'
              number   = '001'
              severity = if_abap_behv_message=>severity-error
              v1       = |预计发货日期 { Ls_HEADER-ExpectedDate } 不能早于当前日期 { today }|
          )
          %element-ExpectedDate = if_abap_behv=>mk-on
      ) TO reported-DeliveryHeader.


    ENDIF.
  ENDLOOP.

  ENDMETHOD.


  METHOD APPROVE.
    READ ENTITIES OF ZI_Delivery_H IN LOCAL MODE
         ENTITY DeliveryHeader
         ALL FIELDS
         WITH CORRESPONDING #( KEYS )
         RESULT DATA(LT_HEADER)
         FAILED FAILED
         REPORTED REPORTED.

    " 收集需要审批（状态为 '10'）的实体实例
    DATA LT_UPDATE TYPE TABLE FOR UPDATE ZI_Delivery_H.
    DATA Ls_UPDATE LIKE LINE OF LT_UPDATE.

    LOOP AT LT_HEADER INTO DATA(LS_HEADER) WHERE STATUS = '10'.
      " 准备更新请求：将状态改为 '20'（已审批）
      MOVE-CORRESPONDING LS_HEADER TO LS_UPDATE.
      LS_UPDATE-STATUS = '20'.
      APPEND LS_UPDATE TO LT_UPDATE.

    ENDLOOP.

    " 执行更新
    IF LT_UPDATE IS NOT INITIAL.
      MODIFY ENTITIES OF ZI_Delivery_H IN LOCAL MODE
             ENTITY DeliveryHeader
             UPDATE FIELDS ( STATUS )
             WITH LT_UPDATE
             FAILED DATA(LT_MOD_FAILED)
             REPORTED DATA(LT_MOD_REPORTED).
      FAILED = CORRESPONDING #( BASE ( FAILED ) LT_MOD_FAILED ).
      REPORTED = CORRESPONDING #( BASE ( REPORTED ) LT_MOD_REPORTED ).
    ENDIF.

    " ---------- 正确填充 RESULT ----------
    DATA LT_SUCCESS_KEYS TYPE STANDARD TABLE OF ZI_Delivery_H WITH EMPTY KEY.
    LOOP AT LT_UPDATE INTO LS_UPDATE.
      IF NOT LINE_EXISTS( LT_MOD_FAILED-DELIVERYHEADER[ %KEY = LS_UPDATE-%KEY  ] ).
        APPEND INITIAL LINE TO LT_SUCCESS_KEYS ASSIGNING FIELD-SYMBOL(<FS_KEY>).
        <FS_KEY>-DELVNO = LS_UPDATE-DELVNO.
      ENDIF.
    ENDLOOP.

    IF LT_SUCCESS_KEYS IS NOT INITIAL.
      READ ENTITIES OF ZI_Delivery_H IN LOCAL MODE
           ENTITY DeliveryHeader
           ALL FIELDS
           WITH CORRESPONDING #( LT_SUCCESS_KEYS )
           RESULT DATA(LT_FINAL)
           FAILED FAILED
           REPORTED REPORTED.

      " 将纯实体数据赋值给 RESULT 的 %PARAM 字段
      LOOP AT LT_FINAL INTO DATA(LS_ENTITY).
        APPEND INITIAL LINE TO RESULT ASSIGNING FIELD-SYMBOL(<FS_RESULT>).
        MOVE-CORRESPONDING LS_ENTITY TO <FS_RESULT>-%PARAM.
        <FS_RESULT>-%KEY = LS_ENTITY-%KEY.
      ENDLOOP.

    ENDIF.
  ENDMETHOD.


ENDCLASS.

CLASS lhc_DeliveryItem DEFINITION INHERITING FROM CL_ABAP_BEHAVIOR_HANDLER.
  PRIVATE SECTION.

    METHODS GET_INSTANCE_FEATURES FOR INSTANCE FEATURES
      IMPORTING KEYS REQUEST REQUESTED_FEATURES FOR DeliveryItem RESULT RESULT.

    METHODS GET_INSTANCE_AUTHORIZATIONS FOR INSTANCE AUTHORIZATION
      IMPORTING KEYS REQUEST REQUESTED_AUTHORIZATIONS FOR DeliveryItem RESULT RESULT.

    METHODS ValidatePO FOR VALIDATE ON SAVE
      IMPORTING KEYS FOR DeliveryItem~ValidatePO.
    METHODS DeterminePO FOR DETERMINE ON MODIFY
      IMPORTING keys FOR DeliveryItem~DeterminePO.
    METHODS ValidateDELVQTY FOR VALIDATE ON SAVE
      IMPORTING keys FOR DeliveryItem~ValidateDELVQTY.

ENDCLASS.

CLASS lhc_DeliveryItem IMPLEMENTATION.
  METHOD GET_INSTANCE_FEATURES.
    " 当前为编辑
    READ ENTITIES OF ZI_Delivery_H IN LOCAL MODE
         ENTITY DeliveryHeader
         FIELDS ( DelvNo Status )    " 需要的业务字段
         WITH CORRESPONDING #( KEYS )
         RESULT DATA(LT_HEADER)
         FAILED FAILED.
    READ TABLE LT_HEADER INTO DATA(LS_HEADER) INDEX 1. " 这个方法在FIORI中正常应该只会有一个单。

    RESULT = VALUE #( FOR LS_KEYS IN KEYS
                      ( %KEY                   = LS_KEYS-%KEY
                        %IS_DRAFT              = LS_KEYS-%IS_DRAFT
                        %FEATURES-%UPDATE      = COND #( WHEN LS_HEADER-Status = '10'
                                                         THEN IF_ABAP_BEHV=>FC-O-ENABLED
                                                         ELSE IF_ABAP_BEHV=>FC-O-DISABLED )
                        %FEATURES-%DELETE      = COND #( WHEN LS_HEADER-Status = '10'
                                                         THEN IF_ABAP_BEHV=>FC-O-ENABLED
                                                         ELSE IF_ABAP_BEHV=>FC-O-DISABLED )
                        %FEATURES-%FIELD-Ebeln = COND #( WHEN ls_keys-ItemNo IS INITIAL  " 新行
                                                     THEN if_abap_behv=>fc-f-mandatory  " 可编辑
                                                     ELSE if_abap_behv=>fc-f-read_only )   "  旧数据不能编辑采购订单，此处注意与按钮的差异
                        %FEATURES-%FIELD-Ebelp = COND #( WHEN ls_keys-ItemNo IS INITIAL  " 新行
                                                     THEN if_abap_behv=>fc-f-mandatory  " 可编辑
                                                     ELSE if_abap_behv=>fc-f-read_only )   "  旧数据不能编辑采购订单，此处注意与按钮的差异
                          ) ) .
  ENDMETHOD.

  METHOD ValidatePO.
    DATA L_ERROR   TYPE FLAG.

    READ ENTITIES OF ZI_Delivery_H IN LOCAL MODE
         ENTITY DeliveryItem   " 通过根实体的关联路径访问明细
         ALL FIELDS
         WITH CORRESPONDING #( KEYS )
         RESULT DATA(LT_ITEM). " 此读出的是所有的IT
    READ ENTITIES OF ZI_Delivery_H IN LOCAL MODE
         ENTITY DeliveryHeader BY \_ITEM   " 通过根实体的关联路径访问明细
         ALL FIELDS
         WITH CORRESPONDING #( KEYS )
         RESULT DATA(LT_BYITEM). " 此读出的是所有的IT

    IF LT_ITEM IS NOT INITIAL.
      SELECT EBELN,EBELP,MATNR,MENGE,MEINS
        INTO TABLE @DATA(LT_EKPO)
        FROM EKPO
        FOR ALL ENTRIES IN @LT_ITEM
        WHERE EBELN = @LT_ITEM-EBELN
          AND EBELP = @LT_ITEM-EBELP
          AND RETPO = '' " 没有返回订单的
          AND WEPOS = 'X' " 收货
          AND ELIKZ = '' " 没有交货完成的
          AND MENGE > 0.
    ENDIF.
    SORT LT_EKPO BY EBELN
                    EBELP.
    LOOP AT LT_item INTO DATA(Ls_item).
      " 1. 清除该实例在 'VALIDATE_EDATE' 区域的所有旧状态消息
      "    这一步是每次必执行的，用于清除任何残留的旧消息。
      APPEND VALUE #( %TKY                 = LS_item-%TKY
                      %PATH-DELIVERYHEADER = CORRESPONDING #( LS_ITEM-%TKY ) " 这里必须
                      %STATE_AREA          = 'VALIDATE_PO' )      " 只带区域，不带消息
             TO REPORTED-DeliveryItem.
      READ TABLE LT_EKPO INTO DATA(Ls_EKPO) WITH KEY EBELN = LS_ITEM-EBELN
                                                     EBELP = LS_ITEM-EBELP
           BINARY SEARCH.
      IF SY-SUBRC <> 0.

        " 将不合规实例放入 failed，阻止保存
        APPEND VALUE #( %TKY = Ls_item-%TKY ) TO FAILED-DeliveryItem.
        " 生成错误消息，并标记字段
        APPEND VALUE #( %TKY                 = Ls_item-%TKY
                        %PATH-DELIVERYHEADER = CORRESPONDING #( LS_ITEM-%TKY ) " 这里必须
                        %STATE_AREA          = 'VALIDATE_PO'
                        %MSG                 = NEW_MESSAGE( ID       = '00'
                                                            NUMBER   = '001'
                                                            SEVERITY = IF_ABAP_BEHV_MESSAGE=>SEVERITY-ERROR
                                                            V1       = |采购订单没有有效的需配送数量| )
                        %ELEMENT-EBELN       = IF_ABAP_BEHV=>MK-ON
                        %ELEMENT-EBELP       = IF_ABAP_BEHV=>MK-ON )
               TO REPORTED-DeliveryItem.
        L_ERROR = 'X'.

      ENDIF.
      " 判断同一订单项目号不能重复
      LOOP AT LT_BYITEM INTO DATA(LS_BYITEM) WHERE     %PID  <> Ls_item-%PID
                                                   AND EBELN  = LS_ITEM-EBELN AND EBELP = LS_ITEM-EBELP.
        EXIT.
      ENDLOOP.
      IF LS_BYITEM IS NOT INITIAL. " 订单项目号重复
        APPEND VALUE #( %TKY = Ls_item-%TKY ) TO FAILED-DeliveryItem.
        " 生成错误消息，并标记字段
        APPEND VALUE #( %TKY                 = Ls_item-%TKY
                        %PATH-DELIVERYHEADER = CORRESPONDING #( LS_ITEM-%TKY ) " 这里必须
                        %STATE_AREA          = 'VALIDATE_PO'
                        %MSG                 = NEW_MESSAGE( ID       = '00'
                                                            NUMBER   = '001'
                                                            SEVERITY = IF_ABAP_BEHV_MESSAGE=>SEVERITY-ERROR
                                                            V1       = |订单项目已在此配送单{ LS_BYITEM-ITEMNO }中存在| )
                        %ELEMENT-EBELN       = IF_ABAP_BEHV=>MK-ON
                        %ELEMENT-EBELP       = IF_ABAP_BEHV=>MK-ON )
               TO REPORTED-DeliveryItem.
        L_ERROR = 'X'.
      ENDIF.
      CLEAR LS_BYITEM.
      IF L_ERROR <> ''.
        CONTINUE.
      ENDIF.


    ENDLOOP.
  ENDMETHOD.

  METHOD GET_INSTANCE_AUTHORIZATIONS.
  ENDMETHOD.

  METHOD DeterminePO.
    DATA LT_UPDATE TYPE TABLE FOR UPDATE ZI_Delivery_I.

    READ ENTITIES OF ZI_Delivery_H IN LOCAL MODE
         ENTITY DeliveryItem   " 通过根实体的关联路径访问明细
         ALL FIELDS
         WITH CORRESPONDING #( KEYS )
         RESULT DATA(LT_ITEM). " 此读出的是所有的IT
    IF LT_ITEM IS NOT INITIAL.
      SELECT EBELN,EBELP,MATNR,MENGE,MEINS
        INTO TABLE @DATA(LT_EKPO)
        FROM EKPO
        FOR ALL ENTRIES IN @LT_ITEM
        WHERE EBELN = @LT_ITEM-EBELN
          AND EBELP = @LT_ITEM-EBELP
          AND RETPO = '' " 没有返回订单的
          AND WEPOS = 'X' " 收货
          AND ELIKZ = '' " 没有交货完成的
          AND MENGE > 0.
    ENDIF.
    SORT LT_EKPO BY EBELN
                    EBELP.
    CLEAR LT_UPDATE.
    LOOP AT LT_item INTO DATA(Ls_item).
      READ TABLE LT_EKPO INTO DATA(Ls_EKPO) WITH KEY EBELN = LS_ITEM-EBELN
                                                     EBELP = LS_ITEM-EBELP
           BINARY SEARCH.
      IF SY-SUBRC <> 0.
        CONTINUE.
      ENDIF.

      APPEND INITIAL LINE TO LT_UPDATE ASSIGNING FIELD-SYMBOL(<UPDATE>).
      MOVE-CORRESPONDING LS_ITEM TO <UPDATE>.

      <UPDATE>-MATNR         = Ls_EKPO-MATNR.
      <UPDATE>-DELVQTY       = Ls_EKPO-MENGE.
      <UPDATE>-OrderQuantity = Ls_EKPO-MENGE.
      <UPDATE>-MEINS         = Ls_EKPO-MEINS.
    ENDLOOP.

    MODIFY ENTITIES OF ZI_Delivery_H IN LOCAL MODE
           ENTITY DeliveryItem
           UPDATE FIELDS ( MATNR DELVQTY OrderQuantity MEINS )
           WITH LT_UPDATE
           " TODO: variable is assigned but never used (ABAP cleaner)
           FAILED DATA(LT_FAILED)
           " TODO: variable is assigned but never used (ABAP cleaner)
           REPORTED DATA(LT_REPORTED).
  ENDMETHOD.

  METHOD ValidateDELVQTY.
    READ ENTITIES OF ZI_Delivery_H IN LOCAL MODE
         ENTITY DeliveryItem   " 通过根实体的关联路径访问明细
         ALL FIELDS
         WITH CORRESPONDING #( KEYS )
         RESULT DATA(LT_ITEM). " 此读出的是所有的IT
    LOOP AT LT_ITEM INTO DATA(LS_ITEM).
      APPEND VALUE #( %TKY                 = LS_item-%TKY
                      %PATH-DELIVERYHEADER = CORRESPONDING #( LS_ITEM-%TKY ) " 这里必须
                      %STATE_AREA          = 'VALIDATE_DELVQTY' )      " 只带区域，不带消息
             TO REPORTED-DeliveryItem.
      IF LS_ITEM-DELVQTY <= LS_ITEM-OrderQuantity. " 实际业务应该用可配送数量来比较
        CONTINUE.
      ENDIF.

      " 将不合规实例放入 failed，阻止保存
      APPEND VALUE #( %TKY = Ls_item-%TKY ) TO FAILED-DeliveryItem.
      " 生成错误消息，并标记字段
      APPEND VALUE #( %TKY                 = Ls_item-%TKY
                      %PATH-DELIVERYHEADER = CORRESPONDING #( LS_ITEM-%TKY ) " 这里必须
                      %STATE_AREA          = 'VALIDATE_DELVQTY'
                      %MSG                 = NEW_MESSAGE( ID       = '00'
                                                          NUMBER   = '001'
                                                          SEVERITY = IF_ABAP_BEHV_MESSAGE=>SEVERITY-ERROR
                                                          V1       = |最大可配送数量为{ LS_ITEM-OrderQuantity }| )
                      %ELEMENT-DELVQTY       = IF_ABAP_BEHV=>MK-ON  )
             TO REPORTED-DeliveryItem.
    ENDLOOP.
  ENDMETHOD.

ENDCLASS.

CLASS lsc_ZI_DELIVERY_H DEFINITION INHERITING FROM CL_ABAP_BEHAVIOR_SAVER.
  PROTECTED SECTION.

    METHODS ADJUST_NUMBERS REDEFINITION.

    METHODS CLEANUP_FINALIZE REDEFINITION.

ENDCLASS.

CLASS lsc_ZI_DELIVERY_H IMPLEMENTATION.
  METHOD ADJUST_NUMBERS.
    DATA L_MAX_ITEMNO TYPE ZI_DELIVERY_I-ItemNo.

    SELECT DELVNO,ITEMNO INTO TABLE @DATA(LT_DELIVERY_I)
      FROM ZI_DELIVERY_I
      FOR ALL ENTRIES IN @MAPPED-DeliveryItem
      WHERE DELVNO = @MAPPED-DeliveryItem-%TMP-DELVNO.
    DATA LS_DELIVERY_I LIKE LINE OF LT_DELIVERY_I.
    SORT LT_DELIVERY_I BY DELVNO
                          ITEMNO DESCENDING.
    LOOP AT MAPPED-DeliveryItem ASSIGNING FIELD-SYMBOL(<DELIVERYITEM>).
      ASSIGN LT_DELIVERY_I[ DELVNO = <DELIVERYITEM>-%TMP-DELVNO ] TO FIELD-SYMBOL(<LS_DELIVERY_I>).
      IF SY-SUBRC = 0.
        " 1. 生成最终编号的逻辑
        <LS_DELIVERY_I>-ITEMNO += 10.
        L_MAX_ITEMNO = <LS_DELIVERY_I>-ITEMNO.
      ELSE.
         L_MAX_ITEMNO = 10.
        LS_DELIVERY_I-DelvNo = <DELIVERYITEM>-%TMP-DELVNO.
        LS_DELIVERY_I-ITEMNO = 10.
        INSERT LS_DELIVERY_I INTO TABLE LT_DELIVERY_I.

      ENDIF.

      <DELIVERYITEM>-DelvNo = <DELIVERYITEM>-%TMP-DELVNO.
      <DELIVERYITEM>-ITEMNO = L_MAX_ITEMNO.
    ENDLOOP.
  ENDMETHOD.

  METHOD CLEANUP_FINALIZE.
  ENDMETHOD.

ENDCLASS.
