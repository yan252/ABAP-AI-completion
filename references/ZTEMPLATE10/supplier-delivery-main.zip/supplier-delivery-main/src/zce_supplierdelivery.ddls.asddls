@EndUserText.label: '可配送采购订单列表'

@ObjectModel.query.implementedBy: 'ABAP:ZCL_CE_SUPPLIER_DELIVERY'

@Search.searchable: false

@UI.headerInfo: { typeName: '可配送采购订单列表',
                  typeNamePlural: '可配送采购订单列表',
                  title: { type: #STANDARD, value: 'Ebeln' },
                  description.value: 'Ebelp' }


         
@UI.lineItem: [ { criticality: 'ColorCode' } ]

define root custom entity ZCE_SupplierDelivery

{
      @UI.facet: [ { id:              'HeaderFacet1',
                     purpose:         #HEADER,
                     type:            #FIELDGROUP_REFERENCE,
                     //label:           'Object Page - Header Facet',
                     targetQualifier: 'HeaderItems1', // Refers to lineItems with @UI.fieldGroup: [{qualifier: 'HeaderItems'}]
                     position:         10 },
                     { id:              'HeaderFacet2',
                     purpose:         #HEADER,
                     type:            #FIELDGROUP_REFERENCE,
                     //label:           'Object Page - Header Facet',
                     targetQualifier: 'HeaderItems2', // Refers to lineItems with @UI.fieldGroup: [{qualifier: 'HeaderItems'}]
                     position:         20 },

                     { id:          'GeneralInfo',
                     purpose:     #STANDARD,
                     type:        #IDENTIFICATION_REFERENCE,
                     label:       '基本信息',
                     position:    20 } ]


      @UI.lineItem: [ { position: 10 } ]
      @UI.selectionField: [ { position: 10 } ]

      @Consumption.valueHelpDefinition: [  { entity:  { name: 'I_PurchasingDocumentStdVH', element: 'PurchasingDocument' }
                                       }]
  key Ebeln          : ebeln;

      @UI.lineItem: [ { position: 20 } ]
  key Ebelp          : ebelp;

      @UI.fieldGroup: [ { qualifier: 'HeaderItems1', position: 20 } ]
      @UI.lineItem: [ { position: 220, importance: #LOW } ]
      Lifnr         : lifnr;

      @UI.fieldGroup: [ { qualifier: 'HeaderItems1', position: 30, label: '供应商名称' } ]
      @UI.lineItem: [ { position: 230, label: '供应商名称', importance: #LOW } ]
      NAme1         : name1;


      @Consumption.valueHelpDefinition: [ { entity: { name: 'I_MaterialVH', element: 'Material' } } ]
      @UI.fieldGroup: [ { qualifier: 'HeaderItems2', position: 40 } ]
      @UI.lineItem: [ { position: 40, cssDefault.width: '100px' } ]
      @UI.selectionField: [ { position: 40 } ]
      Matnr          : matnr;

      @UI.fieldGroup: [ { qualifier: 'HeaderItems2', position: 50 } ]
      @UI.lineItem: [ { position: 50, cssDefault.width: '200px' } ]
      // @UI.selectionField: [ { position: 50 } ]
      Maktx          : maktx;

      @Semantics.quantity.unitOfMeasure: 'meins'
      @UI.identification: [ { position: 60, label: '订单数量' } ]
      @UI.lineItem: [ { position: 60, label: '订单数量', cssDefault.width: '150px', importance: #LOW } ]
      OrderQty       : menge_d; // 订单数量

      @Semantics.quantity.unitOfMeasure: 'meins'
      @UI.identification: [ { position: 70, label: '已收货量' } ]
      @UI.lineItem: [ { position: 70, label: '已收货量', cssDefault.width: '150px', importance: #LOW } ]
      ReceivedQty    : menge_d; // 已收货量

      @Semantics.quantity.unitOfMeasure: 'meins'
      @UI.identification: [ { position: 80, label: '在途量' } ]
      @UI.lineItem: [ { position: 80, label: '在途量', cssDefault.width: '150px', importance: #LOW } ]
      IntransitQty   : menge_d;  // 在途量 = 配送单中未确认配送的数量

      @Semantics.quantity.unitOfMeasure: 'meins'
      @UI.identification: [ { position: 90, label: '可配送量' } ]
      @UI.lineItem: [ { position: 90, label: '可配送量', cssDefault.width: '150px' } ]
      AvailableQty   : menge_d;  // 可配送量 = 订单数量 - 已收货量 - 在途量

      @Semantics.quantity.unitOfMeasure: 'meins'
      @UI.identification: [ { position: 100, label: '本次配送量' } ]
      @UI.lineItem: [ { position: 100, criticality: 'ColorCode', label: '本次配送量', cssDefault.width: '150px' } ]
      ThisDeliveryQty: menge_d;  // 本次配送量（前端可修改）

      @UI.hidden: true
      @UI.lineItem: [ { position: 110 } ]
      meins       : meins;

      @UI.hidden: true
      DelvNo : zdelv_no;   // 


      @UI.lineItem: [ { exclude: true, position: 920, importance: #LOW } ]
      @UI.selectionField: [ { position: 920 } ]
      @Consumption.filter: { mandatory: true, selectionType: #SINGLE }//必输入，只输入单值 ，
      UKEY: zukey;

      // 最后定义一个虚拟字段放置 Action 按钮
      @UI.hidden: true
      @UI.lineItem: [ { type: #FOR_ACTION,
                        dataAction: 'createDelivery',
                        label: '创建配送单',
                        position: 10,
                        //determining: true,//把按钮放到页脚区域后，#CHANGE_SET无效
                        invocationGrouping: #CHANGE_SET 
                        },
                      { type: #FOR_ACTION,
                        dataAction: 'appendToDelivery',
                        label: '追加到配送单',
                        position: 20,
                        invocationGrouping: #CHANGE_SET } ]


      dummy_action : abap.int1;

      // 增加辅助字段
      @UI.hidden: true
      ColorCode : abap.int2;   // 仅声明，不计算值，前端根据可配送量和订单数量计算出颜色值，0-红色（可配送量=0），1-黄色（可配送量>0且<订单数量），2-绿色（可配送量=订单数量）
}
