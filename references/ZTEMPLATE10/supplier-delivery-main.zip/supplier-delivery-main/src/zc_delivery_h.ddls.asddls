@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: '供应商配送单维护'
@Metadata.allowExtensions: true
//@Metadata.ignorePropagatedAnnotations: true


@UI.lineItem: [ { criticality: 'ColorCode' } ]
define root view entity ZC_DELIVERY_H 
provider contract transactional_query
as projection on ZI_Delivery_H
{
    key DelvNo,
      //@Consumption.valueHelpDefinition: [ { entity: { name: 'I_Supplier_VH', element: 'Supplier' } } ]
      
    Lifnr,
    Status,
    DeliveryPerson,
    Phone,
    ExpectedDate,
    ExpectedTime,
    CreatedAt,
    CreatedBy,
    CreatedByt,
    LastChangedAt,
    Ukey,
    StatusText,
    dummy_action,
    ColorCode,
    /* Associations */
    _Supplier,
    _item : redirected to composition child ZC_DELIVERY_I
}
