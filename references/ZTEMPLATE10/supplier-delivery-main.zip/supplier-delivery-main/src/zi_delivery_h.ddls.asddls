
@AccessControl.authorizationCheck: #NOT_REQUIRED

@EndUserText.label: '配送单头'

@Metadata.allowExtensions: true
//@Metadata.ignorePropagatedAnnotations: true

@UI.lineItem: [ { criticality: 'ColorCode' } ]

define root view entity ZI_Delivery_H
  as select from zpot_delv_h    as _HEADER

    inner join   zpot_delv_user as _USER   on _USER.lifnr = _HEADER.lifnr

  composition [0..*] of ZI_Delivery_I         as _item

  association [0..1] to ZC_Supplier           as _Supplier
    on _Supplier.Supplier = _HEADER.lifnr

  association [0..1] to ZI_DELIVERY_STATUS_VH as _STATUSVH
    on
        _STATUSVH.Language = $session.system_language
    and _STATUSVH.Status   = _HEADER.status

{
  key _HEADER.delv_no         as DelvNo,

      //@ObjectModel.text.association: '_Supplier'
     // @ObjectModel.foreignKey.association: '_Supplier'
     // @Consumption.semanticObject: 'Supplier'
     @ObjectModel: { text.element: [ '_Supplier.SupplierName' ] }
      _HEADER.lifnr           as Lifnr,

      @Consumption.valueHelpDefinition: [ { entity: { name: 'ZI_DELIVERY_STATUS_VH', element: 'Status' } } ]
      @ObjectModel.text.element: [ 'StatusText' ]
      _HEADER.status          as Status,

      _HEADER.delivery_person as DeliveryPerson,
      _HEADER.phone           as Phone,
      _HEADER.expected_date   as ExpectedDate,
      _HEADER.expected_time   as ExpectedTime,
      _HEADER.created_at      as CreatedAt,
      _HEADER.created_by      as CreatedBy,
      _HEADER.created_byt     as CreatedByt,
      _HEADER.last_changed_at as LastChangedAt,
      //  @UI.hidden: true
      _USER.ukey              as Ukey,

      @UI.hidden: true // 可选择在 UI 上隐藏此字段
      _STATUSVH.StatusText    as StatusText,

      // 最后定义一个虚拟字段放置 Action 按钮
      @UI.hidden: true
      ''                      as dummy_action,

      //// 10（生成）时正常色0，20（审批）时黄色2，30（配送中）时蓝色5，40（已收货）时绿色 3，90（删除）时红色1
      // 动态颜色计算字段
      case _HEADER.status
        when '10' then 0   // 正常色（中性）
        when '20' then 2   // 黄色（关键）
        when '30' then 2   // 5为蓝色（信息）但此应该只在ODATAV4上才支持，所以现也显示了黄色2
        when '40' then 3   // 绿色（正）
        when '90' then 1   // 红色（负）
        else 0
      end                     as ColorCode,


      _item,
      _Supplier
}
