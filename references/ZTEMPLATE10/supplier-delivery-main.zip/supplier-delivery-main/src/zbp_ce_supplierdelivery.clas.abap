CLASS zbp_ce_supplierdelivery DEFINITION PUBLIC ABSTRACT FINAL FOR BEHAVIOR OF zce_supplierdelivery.
ENDCLASS.

CLASS zbp_ce_supplierdelivery IMPLEMENTATION.
ENDCLASS.
