@EndUserText.label: '追加配送单参数'
define abstract entity ZAD_AppendToDeliveryParams

{
      @Consumption.valueHelpDefinition: [ { entity: { name: 'ZI_Delivery_H', element: 'DelvNo' },
      distinctValues: true,
      useForValidation: true,
      additionalBinding: [
        {
          localConstant: '10',           // 固定值 10
          element: 'Status',              // 映射到 ZI_Delivery_H 的 Status 字段
          usage: #FILTER                  // 用作过滤条件
        }
      ]
  } ]

  key DeliveryNo : abap.char(12);
}
