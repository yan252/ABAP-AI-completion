CLASS ZCL_CE_SUPPLIER_DELIVERY DEFINITION
  PUBLIC FINAL
  CREATE PUBLIC.

public section.

  interfaces IF_RAP_QUERY_PROVIDER .

  types:
    "! Range option with the semantics of selection table criteria (see ABAP Keyword Documentation on "<em>SELECT-OPTIONS</em>" for allowed values for each component)
    BEGIN OF ty_range_option,
      sign   TYPE c LENGTH 1,
      option TYPE c LENGTH 2,
      low    TYPE string,
      high   TYPE string,
    END OF ty_range_option .
  types:
    "! Ranges-table-compatible format (see ABAP Keyword Documentation for "TYPES - RANGE OF")
    tt_range_option TYPE STANDARD TABLE OF ty_range_option WITH EMPTY KEY .
  types:
    BEGIN OF ty_name_range_pairs,
      name  TYPE string,
      range TYPE tt_range_option,
    END OF ty_name_range_pairs .
  types:
    "! List of range tables along with the element that they refer to
    tt_name_range_pairs TYPE STANDARD TABLE OF ty_name_range_pairs WITH EMPTY KEY .
  types:
    tt_result TYPE STANDARD TABLE OF zce_supplierdelivery WITH EMPTY KEY .

  CLASS-METHODS  GET_DATA
    importing
      value(PT_RANGE_EBELN) type TT_RANGE_OPTION optional
      value(PT_RANGE_EBELP) type TT_RANGE_OPTION optional
      value(PT_RANGE_MATNR) type TT_RANGE_OPTION optional
      value(PT_RANGE_UKEY) type TT_RANGE_OPTION optional
    returning
      value(PT_RESULT) type TT_RESULT .
protected section.
private section.
ENDCLASS.



CLASS ZCL_CE_SUPPLIER_DELIVERY IMPLEMENTATION.


  METHOD IF_RAP_QUERY_PROVIDER~SELECT.
    DATA LT_RESULT      TYPE TABLE OF ZCE_SUPPLIERDELIVERY.
    DATA LT_RESULT_PAGE TYPE TABLE OF ZCE_SUPPLIERDELIVERY.
    DATA LV_TOTAL       TYPE INT8.
    DATA LV_UKEY        TYPE ZUKEY.
    DATA LV_DETAIL      TYPE FLAG.

    DATA(L_is_data_requested) = io_request->is_data_requested( ).
    " TODO: variable is assigned but never used (ABAP cleaner)
    DATA(LV_SEARCH) = IO_REQUEST->GET_SEARCH_EXPRESSION( ).
    " 1. 获取过滤条件
    TRY.
        DATA(LO_FILTER) = IO_REQUEST->GET_FILTER( ).
        DATA(LT_RANGES) = LO_FILTER->GET_AS_RANGES( ).
      CATCH CX_RAP_QUERY_FILTER_NO_RANGE INTO DATA(LX_NO_RANGE). " TODO: variable is assigned but never used (ABAP cleaner)
        " 转为允许的异常类型

    ENDTRY.
    IF LT_RANGES IS INITIAL.
      IO_RESPONSE->SET_DATA( LT_RESULT ).
      IO_RESPONSE->SET_TOTAL_NUMBER_OF_RECORDS( LV_TOTAL ).
      RETURN.
    ENDIF.


    READ TABLE LT_RANGES INTO DATA(LS_RANGES) WITH KEY NAME = 'EBELN'.
    IF SY-SUBRC = 0.
      DATA(LT_RANGE_EBELN) = LS_RANGES-RANGE.
    ENDIF.
    READ TABLE LT_RANGES INTO LS_RANGES WITH KEY NAME = 'MATNR'.
    IF SY-SUBRC = 0.
      DATA(LT_RANGE_MATNR) = LS_RANGES-RANGE.
    ENDIF.
    READ TABLE LT_RANGES INTO LS_RANGES WITH KEY NAME = 'UKEY'.
    IF SY-SUBRC = 0.
      DATA(LT_RANGE_UKEY) = LS_RANGES-RANGE.
    ENDIF.

    READ TABLE LT_RANGES INTO LS_RANGES WITH KEY NAME = 'EBELP'.
    IF SY-SUBRC = 0.
      DATA(LT_RANGE_EBELP) = LS_RANGES-RANGE.
    ENDIF.

    " 当LT_RANGE_EBELP不为空，且只有一行单值时，表示显示明细页，此时不检查显示UKEY输入框，所以不校验UKEY；当LT_RANGE_EBELP为空时，表示显示列表页，此时校验UKEY输入框的值必须有且只能有一个单值。
    DATA(L_LINES) = LINES( LT_RANGE_EBELP ).
    IF L_LINES = 1.
      IF LT_RANGE_EBELP[ 1 ]-OPTION = 'EQ' AND LT_RANGE_EBELP[ 1 ]-LOW IS NOT INITIAL.
        " 明细页，不校验UKEY输入框的值
        LV_DETAIL = 'X'.
      ENDIF.
    ENDIF.
    IF LV_DETAIL IS INITIAL.
      " 查询页，UKEY,只能输入单值且必输
      L_LINES = LINES( LT_RANGE_UKEY ).
      IF L_LINES = 0.
        RAISE EXCEPTION NEW ZCX_RAP_QUERY_ERROR( TEXTID = VALUE SCX_T100KEY( MSGID = '00'
                                                                             MSGNO = '001'
                                                                             ATTR1 = '用户KEY不能为空' ) ).
      ELSEIF L_LINES > 1.
        RAISE EXCEPTION NEW ZCX_RAP_QUERY_ERROR( TEXTID = VALUE SCX_T100KEY( MSGID = '00'
                                                                             MSGNO = '001'
                                                                             ATTR1 = '用户KEY只能输入准确单值' ) ).
      ELSE. "=1
        LV_UKEY = LT_RANGE_UKEY[ 1 ]-LOW.
        IF LT_RANGE_UKEY[ 1 ]-OPTION <> 'EQ'.
          RAISE EXCEPTION NEW ZCX_RAP_QUERY_ERROR( TEXTID = VALUE SCX_T100KEY( MSGID = '00'
                                                                               MSGNO = '001'
                                                                               ATTR1 = '用户KEY不能为空' ) ).
        ENDIF.

      ENDIF.
      IF LT_RANGE_EBELN IS INITIAL AND LT_RANGE_MATNR IS INITIAL.
        " RAISE EXCEPTION NEW ZCX_RAP_QUERY_ERROR( TEXTID = VALUE SCX_T100KEY( MSGID = '00'
        "                                                                      MSGNO = '001'
        "                                                                      ATTR1 = '采购订单号和物料号不能同时为空' ) ).
      ENDIF.
    ENDIF.
    " 2. GET_DATA读取采购订单数据
    LT_RESULT = GET_DATA(
      EXPORTING
        PT_RANGE_EBELN = LT_RANGE_EBELN
        PT_RANGE_EBELP = LT_RANGE_EBELP
        PT_RANGE_MATNR = LT_RANGE_MATNR
        PT_RANGE_UKEY  = LT_RANGE_UKEY

    ).
*
IF LV_DETAIL IS INITIAL."点击 查询
   " 删除没有可配送量的数据。
    DELETE LT_RESULT WHERE AVAILABLEQTY <= 0.
ENDIF.

    LOOP AT LT_RESULT ASSIGNING FIELD-SYMBOL(<RESULT>).
      <RESULT>-UKEY = LV_UKEY.
      " 根据可配送量设置行颜色，0-红色（可配送量=0），1-黄色（可配送量>0且<订单数量），2-绿色（可配送量=订单数量）
      IF <RESULT>-ORDERQTY = <RESULT>-ThisDeliveryQty AND <RESULT>-ThisDeliveryQty > 0.
        <RESULT>-COLORCODE = 0.   "无色
      ELSEif <RESULT>-ThisDeliveryQty > 0.
        <RESULT>-COLORCODE = 2.   " Warning (橙黄)
      ELSE.
        <RESULT>-COLORCODE = 3.   " 绿色
      ENDIF.

    ENDLOOP.
    " 7. 分页处理
    LV_TOTAL = LINES( LT_RESULT ).          " 总记录数
    DATA(LO_PAGING) = IO_REQUEST->GET_PAGING( ).
    DATA(LV_OFFSET) = LO_PAGING->GET_OFFSET( ).
    DATA(LV_LIMIT)  = LO_PAGING->GET_PAGE_SIZE( ).
    IF LV_LIMIT > 0.
      DATA(LV_START) = LV_OFFSET + 1.
      DATA(LV_END)   = LV_OFFSET + LV_LIMIT.
      DATA(LV_IDX)   = 0.

      LOOP AT LT_RESULT INTO DATA(LS_ROW).
        LV_IDX = SY-TABIX.
        IF LV_IDX BETWEEN LV_START AND LV_END.
          APPEND LS_ROW TO LT_RESULT_PAGE.
        ENDIF.
      ENDLOOP.

      LT_RESULT = LT_RESULT_PAGE.
    ENDIF.
    SORT LT_RESULT BY EBELN DESCENDING EBELP .
    " 8. 返回数据
    IO_RESPONSE->SET_DATA( LT_RESULT ).
    IO_RESPONSE->SET_TOTAL_NUMBER_OF_RECORDS( LV_TOTAL ).
  ENDMETHOD.


  method GET_DATA.

      CLEAR PT_RESULT.

    SELECT A~EBELN,
           A~EBELP,
           A~MATNR,
           A~MENGE AS ORDERQTY,
           A~MEINS,
           B~LIFNR,
           C~NAME1
      FROM EKPO AS A
             INNER JOIN
               EKKO AS B ON A~EBELN = B~EBELN
                 INNER JOIN
                   LFA1 AS C ON B~LIFNR = C~LIFNR
                     INNER JOIN
                       ZPOT_DELV_USER AS D ON D~LIFNR = B~LIFNR
      INTO TABLE @DATA(LT_EKPO)
      WHERE A~EBELN IN @PT_RANGE_EBELN
        AND A~EBELP IN @PT_RANGE_EBELP
        aND b~BSART in ( 'NB', 'ZNB' ,'YNB' ) " 只查询标准订单和框架订单)
        AND A~RETPO = '' " 没有返回订单的
        AND A~MATNR IN @PT_RANGE_MATNR
        "AND A~WEPOS = 'X'"收货
        AND A~ELIKZ  = '' " 没有交货完成的
        AND D~UKEY  IN @PT_RANGE_UKEY
        .

    IF LT_EKPO IS INITIAL.
      RETURN.
    ENDIF.

    " 3. 批量获取物料描述
    SELECT MATNR, MAKTX FROM MAKT
      INTO TABLE @DATA(LT_MAKT)
      FOR ALL ENTRIES IN @LT_EKPO
      WHERE MATNR = @LT_EKPO-MATNR
        AND SPRAS = @SY-LANGU.

    " 4. 批量获取已收货量（从EKBE）
    TYPES: BEGIN OF TY_EKBE_SUM,
             EBELN TYPE EKBE-EBELN,
             EBELP TYPE EKBE-EBELP,
             MENGE TYPE EKBE-MENGE,
           END OF TY_EKBE_SUM.
    DATA LT_EKBE_SUM        TYPE SORTED TABLE OF TY_EKBE_SUM WITH UNIQUE KEY EBELN EBELP.
    DATA LS_EKBE_SUM        LIKE LINE OF LT_EKBE_SUM.
    DATA LT_ZPOT_DELV_I_SUM TYPE SORTED TABLE OF TY_EKBE_SUM WITH UNIQUE KEY EBELN EBELP.
    DATA LS_ZPOT_DELV_I_SUM LIKE LINE OF LT_EKBE_SUM.

    SELECT EBELN,
           EBELP,
           ZEKKN,
           VGABE,
           GJAHR,
           BELNR,
           BUZEI,
           SHKZG,
           MENGE
      FROM EKBE
      INTO TABLE @DATA(LT_EKBE)
      FOR ALL ENTRIES IN @LT_EKPO
      WHERE EBELN = @LT_EKPO-EBELN
        AND EBELP = @LT_EKPO-EBELP
        AND BEWTP = 'E'.  " 收货 WE
    LOOP AT LT_EKBE INTO DATA(LS_EKBE).
      LS_EKBE_SUM-EBELN = LS_EKBE-EBELN.
      LS_EKBE_SUM-EBELP = LS_EKBE-EBELP.
      IF LS_EKBE-SHKZG = 'H'.
        LS_EKBE-MENGE = - LS_EKBE-MENGE.
      ENDIF.
      LS_EKBE_SUM-MENGE = LS_EKBE-MENGE.
      COLLECT LS_EKBE_SUM INTO LT_EKBE_SUM.
    ENDLOOP.
    " 5. 批量获取在途量（从ZPOT_DELV_I）
    SELECT I~* INTO TABLE @DATA(LT_ZPOT_DELV_I)
      FROM ZPOT_DELV_I AS I
             INNER JOIN
               ZPOT_DELV_H AS H ON H~DELV_NO = I~DELV_NO
      FOR ALL ENTRIES IN @LT_EKPO
      WHERE I~EBELN   = @LT_EKPO-EBELN
        AND I~EBELP   = @LT_EKPO-EBELP
        AND H~STATUS IN ( '10', '20', '30' ).  " 10生成,20审批,30配送中
    LOOP AT LT_ZPOT_DELV_I INTO DATA(LS_ZPOT_DELV).
      LS_ZPOT_DELV_I_SUM-EBELN = LS_ZPOT_DELV-EBELN.
      LS_ZPOT_DELV_I_SUM-EBELP = LS_ZPOT_DELV-EBELP.
      LS_ZPOT_DELV_I_SUM-MENGE = LS_ZPOT_DELV-DELV_QTY.
      COLLECT LS_ZPOT_DELV_I_SUM INTO LT_ZPOT_DELV_I_SUM.
    ENDLOOP.

    " 6. 组装结果，计算可配送量
    LOOP AT LT_EKPO ASSIGNING FIELD-SYMBOL(<FS_EKPO>).
"        appEND iNITIAL LINE TO PT_RESULT ASSIGNING FIELD-SYMBOL(<RESULT>).
      DATA(LS_RESULT) = CORRESPONDING ZCE_SUPPLIERDELIVERY( <FS_EKPO> ).

      " 物料描述
      READ TABLE LT_MAKT INTO DATA(LS_MAKT) WITH KEY MATNR = <FS_EKPO>-MATNR BINARY SEARCH.
      LS_RESULT-MAKTX = LS_MAKT-MAKTX.

      " 已收货量
      READ TABLE LT_EKBE_SUM INTO LS_EKBE_SUM WITH KEY EBELN = <FS_EKPO>-EBELN
                                                       EBELP = <FS_EKPO>-EBELP
           BINARY SEARCH.
      IF SY-SUBRC = 0.
        LS_RESULT-RECEIVEDQTY = LS_EKBE_SUM-MENGE.
      ENDIF.

      " 在途量
      READ TABLE LT_ZPOT_DELV_I_SUM INTO LS_ZPOT_DELV_I_SUM WITH KEY EBELN = <FS_EKPO>-EBELN
                                                                     EBELP = <FS_EKPO>-EBELP.
      IF SY-SUBRC = 0.
        LS_RESULT-INTRANSITQTY = LS_ZPOT_DELV_I_SUM-MENGE.
      ENDIF.

      " 计算可配送量
      LS_RESULT-AVAILABLEQTY = LS_RESULT-ORDERQTY - LS_RESULT-RECEIVEDQTY - LS_RESULT-INTRANSITQTY.
      IF LS_RESULT-AVAILABLEQTY < 0.
        LS_RESULT-AVAILABLEQTY = 0.
      ENDIF.

      " 本次配送量默认可配送量
      IF LS_RESULT-AVAILABLEQTY > 0.
        LS_RESULT-THISDELIVERYQTY = LS_RESULT-AVAILABLEQTY.
      ELSE.
        LS_RESULT-THISDELIVERYQTY = 0.
      ENDIF.
      APPEND LS_RESULT TO PT_RESULT.
    ENDLOOP.
    " 删除没有可配送量的数据。
"    DELETE PT_RESULT WHERE AVAILABLEQTY <= 0.


  endmethod.
ENDCLASS.
