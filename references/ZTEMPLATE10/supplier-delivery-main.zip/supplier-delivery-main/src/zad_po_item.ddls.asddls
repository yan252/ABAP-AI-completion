@EndUserText.label: '采购订单行项'
define abstract entity ZAD_PO_Item

{
  Ebeln          : ebeln;
  Ebelp          : ebelp;

  @Semantics.quantity.unitOfMeasure: 'meins'
  ThisDeliveryQty: menge_d;

  Meins          : meins;   // 单位，可选
  Lifnr          : lifnr;   // 供应商（如需分组）
  UKEY: zukey;
}
