CLASS lhc_ZCE_SupplierDelivery DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.

    METHODS get_instance_authorizations FOR INSTANCE AUTHORIZATION
      IMPORTING keys REQUEST requested_authorizations FOR SUPPLIERDELIVERY RESULT result.
    METHODS GET_INSTANCE_FEATURES FOR INSTANCE FEATURES
      IMPORTING KEYS REQUEST REQUESTED_FEATURES FOR SUPPLIERDELIVERY RESULT RESULT.


    METHODS read FOR READ
      IMPORTING keys FOR READ SUPPLIERDELIVERY RESULT result.

    METHODS lock FOR LOCK
      IMPORTING keys FOR LOCK SUPPLIERDELIVERY.

    METHODS appendToDelivery FOR MODIFY
      IMPORTING keys FOR ACTION SUPPLIERDELIVERY~appendToDelivery
                RESULT result.

    METHODS createDelivery FOR MODIFY
      IMPORTING keys FOR ACTION SUPPLIERDELIVERY~createDelivery
                RESULT result.

ENDCLASS.

CLASS lhc_ZCE_SupplierDelivery IMPLEMENTATION.
  METHOD GET_INSTANCE_FEATURES.
    READ ENTITIES OF ZCE_SupplierDelivery IN LOCAL MODE
         ENTITY SUPPLIERDELIVERY
         all FIELDS      " 需要的业务字段
         WITH CORRESPONDING #( KEYS )
         RESULT DATA(LT_HEADER)
         FAILED FAILED.

    RESULT = VALUE #( FOR LS_HEADER IN LT_HEADER
                      ( %KEY                              = LS_HEADER-%KEY
                        %FEATURES-%ACTION-createDelivery         = COND #( WHEN LS_HEADER-THISDELIVERYQTY > 0
                                                                    THEN IF_ABAP_BEHV=>FC-O-ENABLED
                                                                    ELSE IF_ABAP_BEHV=>FC-O-DISABLED )
                        %FEATURES-%ACTION-appendToDelivery         = COND #( WHEN LS_HEADER-THISDELIVERYQTY > 0
                                                                    THEN IF_ABAP_BEHV=>FC-O-ENABLED
                                                                    ELSE IF_ABAP_BEHV=>FC-O-DISABLED )
                             ) ).
  ENDMETHOD.
  METHOD get_instance_authorizations.
  ENDMETHOD.

  METHOD READ.
    "    BREAK S2465.
    " 1. GET_DATA读取采购订单数据，此片一定是有采购订单号及项目号。的，且是前端选中的行数据
    DATA LT_RANGE_EBELN TYPE TT_RANGE_OPTION.
    DATA LT_RANGE_EBELP TYPE TT_RANGE_OPTION.

    LOOP AT KEYS INTO DATA(LS_KEY).
      LT_RANGE_EBELN = VALUE #( BASE LT_RANGE_EBELN
                                ( SIGN = 'I' OPTION = 'EQ' LOW = LS_KEY-EBELN ) ).
      LT_RANGE_EBELP = VALUE #( BASE LT_RANGE_EBELP
                                ( SIGN = 'I' OPTION = 'EQ' LOW = LS_KEY-EBELP ) ).
    ENDLOOP.

    DATA(LT_RESULT) = ZCL_CE_SUPPLIER_DELIVERY=>GET_DATA( PT_RANGE_EBELN = LT_RANGE_EBELN
                                                          PT_RANGE_EBELP = LT_RANGE_EBELP ).
    " 项目号可能有多个，需要按订单号及项目号对应
    LOOP AT LT_RESULT INTO DATA(LS_RESULT).
    DATA(L_INDEX) = SY-TABIX.
      READ TABLE KEYS INTO LS_KEY WITH KEY EBELN = LS_RESULT-EBELN
                                           EBELP = LS_RESULT-EBELP.
      IF SY-SUBRC <> 0.
        DELETE LT_RESULT INDEX L_INDEX.
      ENDIF.
    ENDLOOP.
*    " 2. 将读取到的数据返回给前端
    RESULT = CORRESPONDING #( LT_RESULT ).
  ENDMETHOD.

  METHOD lock.
  ENDMETHOD.

  METHOD APPENDTODELIVERY.
    DATA LT_DN_ITEM TYPE TABLE OF ZPOT_DELV_I.
    DATA LS_DN_ITEM TYPE ZPOT_DELV_I.

    " BREAK S2465.
    READ ENTITIES OF ZCE_SUPPLIERDELIVERY IN LOCAL MODE
         ENTITY SUPPLIERDELIVERY
         FIELDS ( EBELN EBELP THISDELIVERYQTY ) WITH CORRESPONDING #( KEYS )
         RESULT DATA(LT_SELECTED_PO)
         FAILED FAILED
         REPORTED REPORTED.
    READ TABLE KEYS INTO DATA(LS_KEY) INDEX 1. " 一定有值，因为前端是按行选中的，

    SELECT MAX( ITEM_NO ) INTO @DATA(L_ITEM_NO)
      FROM ZPOT_DELV_I
      WHERE DELV_NO = @LS_KEY-%PARAM-DeliveryNo.
    IF SY-SUBRC <> 0.
      APPEND VALUE #( %MSG = NEW_MESSAGE( ID       = '00'
                                          NUMBER   = '001'
                                          SEVERITY = IF_ABAP_BEHV_MESSAGE=>SEVERITY-ERROR
                                          V1       = '请输入有效的配送单' ) )
             TO REPORTED-SUPPLIERDELIVERY.
      RETURN.

    ENDIF.
    LOOP AT LT_SELECTED_PO INTO DATA(LS_PO) WHERE THISDELIVERYQTY > 0.
      L_ITEM_NO += 10.
      LS_DN_ITEM-DELV_NO  = LS_KEY-%PARAM-DeliveryNo.
      LS_DN_ITEM-ITEM_NO  = L_ITEM_NO.
      LS_DN_ITEM-EBELN    = LS_PO-EBELN.
      LS_DN_ITEM-EBELP    = LS_PO-EBELP.
      LS_DN_ITEM-MATNR    = LS_PO-MATNR.
      LS_DN_ITEM-DELV_QTY = LS_PO-THISDELIVERYQTY.
      LS_DN_ITEM-MEINS    = LS_PO-MEINS.
      APPEND LS_DN_ITEM TO LT_DN_ITEM.
    ENDLOOP.
    MODIFY ZPOT_DELV_I FROM TABLE LT_DN_ITEM.

    " 将纯实体数据赋值给 RESULT 的 %PARAM 字段
    LOOP AT LT_SELECTED_PO INTO LS_PO WHERE THISDELIVERYQTY > 0.
      APPEND INITIAL LINE TO RESULT ASSIGNING FIELD-SYMBOL(<FS_RESULT>).
      MOVE-CORRESPONDING LS_PO TO <FS_RESULT>-%PARAM.
      <FS_RESULT>-%KEY = LS_PO-%KEY.
      <FS_RESULT>-%PARAM-AvailableQty    = 0. " 可配送量
      <FS_RESULT>-%PARAM-ThisDeliveryQty = 0. " 本次可配送数据修改为0
      <FS_RESULT>-%PARAM-COLORCODE       = 3.   " 绿色
    ENDLOOP.
  ENDMETHOD.

  METHOD CREATEDELIVERY.
    " BREAK S2465.

    DATA LS_DN_HEADER TYPE ZPOT_DELV_H.
    DATA LT_DN_HEADER TYPE TABLE OF ZPOT_DELV_H.
    DATA LT_DN_ITEM   TYPE TABLE OF ZPOT_DELV_I.
    DATA LS_DN_ITEM   TYPE ZPOT_DELV_I.

    DATA LV_DN_NO     TYPE ZDELV_NO.

    " 1. 获取选中的采购订单行
    READ ENTITIES OF ZCE_SUPPLIERDELIVERY IN LOCAL MODE
         ENTITY SUPPLIERDELIVERY
         FIELDS ( EBELN EBELP THISDELIVERYQTY ) WITH CORRESPONDING #( KEYS )
         RESULT DATA(LT_SELECTED_PO)
         FAILED FAILED
         REPORTED REPORTED.
    IF LT_SELECTED_PO IS INITIAL.
      " 无选中数据，返回错误
      APPEND VALUE #( %MSG = NEW_MESSAGE( ID       = '00'
                                          NUMBER   = '001'
                                          SEVERITY = IF_ABAP_BEHV_MESSAGE=>SEVERITY-ERROR
                                          V1       = '没有找到可配送采购订单' ) )
             TO REPORTED-SUPPLIERDELIVERY.
      RETURN.
    ENDIF.

    READ TABLE KEYS INTO DATA(LS_KEY) INDEX 1. " 一定有值，因为前端是按行选中的，

    " 按选择行的供应商分组创建多个配送单。
    LOOP AT LT_SELECTED_PO INTO DATA(LS_PO)
         GROUP BY LS_PO-LIFNR
         INTO DATA(LT_GROUP).
      " 2. 生成配送单号
      CALL FUNCTION 'NUMBER_GET_NEXT'
        EXPORTING NR_RANGE_NR = '10'
                  OBJECT      = 'ZDELV_NO'
        IMPORTING NUMBER      = LV_DN_NO.

      " 3. 创建配送单头
      LS_DN_HEADER-DELV_NO         = LV_DN_NO.
      LS_DN_HEADER-LIFNR           = LT_GROUP.  " 生成状态
      LS_DN_HEADER-STATUS          = '10'.  " 生成状态
      LS_DN_HEADER-DELIVERY_PERSON = LS_KEY-%PARAM-DELIVERYPERSON.
      LS_DN_HEADER-PHONE           = LS_KEY-%PARAM-PHONE.
      LS_DN_HEADER-EXPECTED_DATE   = LS_KEY-%PARAM-EXPECTEDDATE.
      LS_DN_HEADER-EXPECTED_TIME   = LS_KEY-%PARAM-EXPECTEDTIME.
      LS_DN_HEADER-CREATED_AT      = SY-UNAME.
      LS_DN_HEADER-CREATED_BY      = SY-DATUM.
      LS_DN_HEADER-CREATED_BYT     = SY-UZEIT.
      APPEND LS_DN_HEADER TO LT_DN_HEADER.
      LOOP AT GROUP LT_GROUP INTO DATA(LS_GROUP) WHERE THISDELIVERYQTY > 0.
        LS_DN_ITEM-DELV_NO  = LV_DN_NO.
        LS_DN_ITEM-ITEM_NO  = SY-TABIX * 10.
        LS_DN_ITEM-EBELN    = LS_GROUP-EBELN.
        LS_DN_ITEM-EBELP    = LS_GROUP-EBELP.
        LS_DN_ITEM-MATNR    = LS_GROUP-MATNR.
        LS_DN_ITEM-DELV_QTY = LS_GROUP-THISDELIVERYQTY.
        LS_DN_ITEM-MEINS    = LS_GROUP-MEINS.
        APPEND LS_DN_ITEM TO LT_DN_ITEM.
      ENDLOOP.
    ENDLOOP.
    "

    " 4. 将配送单数据保存到数据库
    MODIFY ZPOT_DELV_H FROM TABLE LT_DN_HEADER.
    MODIFY ZPOT_DELV_I FROM TABLE LT_DN_ITEM.

    " 5. 返回成功消息
    APPEND VALUE #( %MSG = NEW_MESSAGE( ID       = '00'
                                        NUMBER   = '001'
                                        SEVERITY = IF_ABAP_BEHV_MESSAGE=>SEVERITY-SUCCESS
                                        V1       = '配送单'
                                        V2       = LV_DN_NO
                                        V3       = '创建成功' ) )
           TO REPORTED-SUPPLIERDELIVERY.

    " 将纯实体数据赋值给 RESULT 的 %PARAM 字段
    LOOP AT LT_SELECTED_PO INTO LS_PO.
      APPEND INITIAL LINE TO RESULT ASSIGNING FIELD-SYMBOL(<FS_RESULT>).
      MOVE-CORRESPONDING LS_PO TO <FS_RESULT>-%PARAM.
      <FS_RESULT>-%KEY = LS_PO-%KEY.
      <FS_RESULT>-%PARAM-AvailableQty    = 0. " 可配送量
      <FS_RESULT>-%PARAM-ThisDeliveryQty = 0. " 本次可配送数据修改为0
      <FS_RESULT>-%PARAM-COLORCODE = 3.   " 绿色
    ENDLOOP.
  ENDMETHOD.

ENDCLASS.

CLASS lsc_ZCE_SUPPLIERDELIVERY DEFINITION INHERITING FROM cl_abap_behavior_saver.
  PROTECTED SECTION.

    METHODS finalize REDEFINITION.

    METHODS check_before_save REDEFINITION.

    METHODS save REDEFINITION.

    METHODS cleanup REDEFINITION.

    METHODS cleanup_finalize REDEFINITION.

ENDCLASS.

CLASS lsc_ZCE_SUPPLIERDELIVERY IMPLEMENTATION.

  METHOD finalize.
  ENDMETHOD.

  METHOD check_before_save.
  ENDMETHOD.

  METHOD save.
  ENDMETHOD.

  METHOD cleanup.
  ENDMETHOD.

  METHOD cleanup_finalize.
  ENDMETHOD.

ENDCLASS.
