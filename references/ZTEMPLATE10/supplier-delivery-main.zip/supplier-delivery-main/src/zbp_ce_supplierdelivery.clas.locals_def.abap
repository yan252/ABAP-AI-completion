*"* use this source file for any type of declarations (class
*"* definitions, interfaces or type declarations) you need for
*"* components in the private section

  types:
    "! Range option with the semantics of selection table criteria (see ABAP Keyword Documentation on "<em>SELECT-OPTIONS</em>" for allowed values for each component)
    BEGIN OF ty_range_option,
      sign   TYPE c LENGTH 1,
      option TYPE c LENGTH 2,
      low    TYPE string,
      high   TYPE string,
    END OF ty_range_option .
  types:
    "! Ranges-table-compatible format (see ABAP Keyword Documentation for "TYPES - RANGE OF")
    tt_range_option TYPE STANDARD TABLE OF ty_range_option WITH EMPTY KEY .
